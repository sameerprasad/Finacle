set serveroutput on size 1000000
set feedback off
set verify off
set linesize 500
set pages 0
set trims on
set termout off
set numformat 999D09
spool &3
select decode(a.tax_type,'C','CBDT','CBEC')||'|'||a.tax_tran_id||'|'||a.tax_tran_date||'|'||a.tax_tran_type||'|'||b.name||'|'||b.tran_id||'|'||decode(b.ASSESSEE_CODE,'',b.pan_tan_no,b.ASSESSEE_CODE)||'|'||substr(b.cin_no,length(cin_no)-4,5)||'|'||b.CHEQUE_DEP_DATE||'|'||b.realisation_date||'|'||decode(b.entity_creation_flg,'N','Entry','Verify')||'|'||b.RCRE_USER_ID||'|'||b.RCRE_TIME||'|'||b.VFD_USER_ID||'|'||b.VFD_TIME 
from ici_gbm_challan_master b,icici_gbm_trn_hdr a 
where a.tax_tran_id = b.tax_tran_id and a.tax_tran_date = b.tax_tran_date and b.sol_id='&2' and b.realisation_date='&1' and b.entity_creation_flg='&4' and b.del_flg='N'
/
spool off
