-- Program Name    : fsgPspTmpDump.sql
-- Author          : Mandar Raddi
-- Date Written	   : 27-Feb-2001
--
-- -----------------------------------------------------------------------------------#   
-- Brief Description :                                                                #
-- -----------------------------------------------------------------------------------#
-- This PL/SQL program is responsible for creating Customer ID and Accout ID lists    #
-- in the PSP_TMP table for the given Sol ID. These two lists are required in the     #
-- Customer Statement generation process. This program creates the List id as         # 
-- Run ID (Input to the program) + 'C' for customer ids and Run ID + 'A' for accounts #
-- for the customers.                                                                 #
-- -----------------------------------------------------------------------------------# 
--                                 Version History                                    #
-- -----------------------------------------------------------------------------------#
--   Ver.No |     Date   |    Author    |           Reason For Change                 #
-- -----------------------------------------------------------------------------------#
--     1    | 27-02-2001 | Mandar Raddi | Initial Release                             #
-- -----------------------------------------------------------------------------------#

set serveroutput on size 1000000
set feedback off
set verify   off
set termout   off
set pages 0
set linesize 512
set trims on
spool &1-&2-&3-&4

variable maxIdType char(1);
-- -------------------------#
-- Start of DELCARE Section 
-- -------------------------#

DECLARE
cnt					number;
firstAcc			GAM.FORACID%Type;
beginCustId			ICICI_CUST_REG.CUST_ID%Type;
endCustId			ICICI_CUST_REG.CUST_ID%Type;
ciftCustId			ICICI_CUST_REG.CUST_ID%Type;
-- ciftEmailId			ICICI_CUST_REG.EMAIL_ID%Type;
ciftStmtReqd		ICICI_CUST_REG.PBK_FLAG%Type;
stmtReqd			CHAR;
cmgCustStatCode		CMG.CUST_STAT_CODE%Type;
gamForacid			GAM.FORACID%Type;
gamAcid				GAM.ACID%Type;
custSolId			PSP_TMP.HOME_SOL_ID%Type;
custRecType			VARCHAR(3);
custSubRecType		VARCHAR(3);
pspCustListId		PSP_TMP.LISTID%Type;
pspAcctListId		PSP_TMP.LISTID%Type;
endOfCiftCursor     NUMBER;
endOfGamCursor      NUMBER;
acctFound			NUMBER;
gamTxn				NUMBER;
chooseThisCustId    CHAR;
custStatSelectFlag  CHAR;
-- Sri 3.7.02 begin
stmtFreq			char;
custSel				char;
custStat			CMG.CUST_STAT_CODE%Type;
accExist			number(1);
cfgKeyVal			varchar(5);
-- Sri 3.7.02 end
custStatArr 		iciArray.arrayType;
custStatCodes		VARCHAR2(100);
custStatCnt			NUMBER(5);
commitCnt			NUMBER(5);
step				NUMBER(5);
likeStr				varchar2(25);
idType				CHAR(1);
dispMode      		CHAR;
	
cmgTitleName		varchar2(200);
cmgAddr1			CMG.cust_comu_addr1%TYPE;
cmgAddr2			CMG.cust_comu_addr2%TYPE;
cmgCityCode			CMG.cust_comu_city_code%TYPE;
cmgStateCode		CMG.cust_comu_state_code%TYPE;
cmgCntryCode		CMG.cust_comu_cntry_code%TYPE;
cmgPinCode			CMG.cust_comu_pin_code%TYPE;
cmgPhone1			CMG.cust_comu_phone_num_1%TYPE;
cmgPhone2			CMG.cust_comu_phone_num_2%TYPE;
cityDesc			RCT.ref_desc%TYPE;
stateDesc			RCT.ref_desc%TYPE;
cntryDesc			RCT.ref_desc%TYPE;
frmDate             CMG.date_of_birth%TYPE;
toDate              CMG.date_of_birth%TYPE;
carRec				varchar2(500);
runId				varchar2(10);

CURSOR ciftCur IS
SELECT	CUST_ID, home_sol_id
FROM ICICI_CUST_REG
WHERE	CUST_ID BETWEEN beginCustId AND endCustId
AND	pbk_flag='Y'
ORDER BY cust_id;


CURSOR gamCur IS 
SELECT	acid,foracid
FROM	GAM
WHERE	CUST_ID = ciftCustId
AND	(SCHM_TYPE = 'SBA' OR ACCT_PREFIX = '05' OR ACCT_PREFIX = '51')
AND	((ACCT_CLS_FLG = 'N' AND ACCT_OPN_DATE <= '&8') OR
	 (ACCT_CLS_FLG = 'Y' AND ACCT_CLS_DATE > '&7' AND ACCT_CLS_DATE <= '&8'))

AND	ENTITY_CRE_FLG = 'Y'
order by foracid;
-- --------------------------------------------------------------------------------#
-- PROCEDURE to Select customer details from CMG. The customer id is selected from #
-- ICICI_CUST_REG for the input SOL ID                                                 #
-- --------------------------------------------------------------------------------#

PROCEDURE getCmgData(dummy NUMBER) IS
BEGIN
	BEGIN
		step := 3;
		SELECT	cust_title_code || '.' || cust_name,
				cust_comu_addr1,
				cust_comu_addr2,
				cust_comu_city_code,
				cust_comu_state_code,
				cust_comu_cntry_code,
				cust_comu_pin_code,
				cust_comu_phone_num_1,
				cust_comu_phone_num_2,
				cust_stat_code
		INTO	cmgTitleName,
				cmgAddr1,
				cmgAddr2,
				cmgCityCode,
				cmgStateCode,
				cmgCntryCode,
				cmgPinCode,
				cmgPhone1,
				cmgPhone2,
				cmgCustStatCode
		FROM	CMG
		WHERE	CUST_ID = ciftCustId;

		if (cmgCityCode is not null) then
			BEGIN
			SELECT	ref_desc
			INTO	cityDesc
			FROM	RCT
			WHERE	ref_rec_type = '01'
			AND		ref_code = cmgCityCode;
			EXCEPTION WHEN OTHERS THEN NULL;
			END;
		else
			cityDesc := '';
		end if;

		if (cmgStateCode is not null) then
			BEGIN
			SELECT	ref_desc
			INTO	stateDesc
			FROM	RCT
			WHERE	ref_rec_type = '02'
			AND		ref_code = cmgStateCode;
			EXCEPTION WHEN OTHERS THEN NULL;
			END;
		else
			stateDesc := '';
		end if;

		if (cmgCntryCode is not null) then
			BEGIN
			SELECT	ref_desc
			INTO	cntryDesc
			FROM	RCT
			WHERE	ref_rec_type = '03'
			AND		ref_code = cmgCntryCode;
			EXCEPTION WHEN OTHERS THEN NULL;
			END;
		else
			cntryDesc := '';
		end if;

		EXCEPTION
		WHEN NO_DATA_FOUND THEN 
			chooseThisCustId := 'N';
			RETURN;
	END;

	chooseThisCustId := 'Y';

END getCmgData;


PROCEDURE insertPspTmp( pspListId VARCHAR2,
	                pspEntityId VARCHAR2,
	                pspEntityType CHAR,
			pspHomeSolId VARCHAR2) IS
BEGIN
	step := 5;
	INSERT INTO
	PSP_TMP
		(LISTID
		,ENTITY_ID
		,ID_TYPE
		,HOME_SOL_ID)
	VALUES
		(pspListId
		,pspEntityId
		,pspEntityType
		,'PBK');
END insertPspTmp;


PROCEDURE processGamCursor( dummy NUMBER) IS
BEGIN
step := 4;
FOR gamCur_rec in gamCur
LOOP --{
    begin
	IF( gamCur%NOTFOUND ) then
		endOfGamCursor := 1;
		RETURN;
	END IF; 
	gamTxn := 0;
	acctFound := 1;	
	insertPspTmp(pspAcctListId, gamCur_rec.foracid, idType, custSolId);
	if (cnt = 0) then
		firstAcc := gamCur_rec.foracid;
		cnt := 1;
	end if;
    end;
end loop;
END processGamCursor;
		

PROCEDURE processCiftCursor( dummy NUMBER ) IS
BEGIN
	step := 2;
	FETCH ciftCur 
	INTO ciftCustId,
		custSolId;

	IF (ciftCur%NOTFOUND) then
		endOfCiftCursor := 1;
		RETURN;
	END IF;

	chooseThisCustId := 'Y';
	getCmgData(0);

	IF (chooseThisCustId = 'N') THEN
		RETURN;
	END IF;

	endOfGamCursor := 0;
	acctFound := 0;
	cnt := 0;
	stmtReqd := 'Y';
	firstAcc := '';
	processGamCursor(0);
	insertPspTmp(pspCustListId, ciftCustId, idType, custSolId);
	dbms_output.put_line('PBK'              || '|' ||
                                ciftCustId              || '|01|0|' ||
                                ' '             || '|' ||
                                ltrim(rtrim(cmgTitleName))    || '|' ||
                                ltrim(rtrim(cmgAddr1))                || '|' ||
                                ltrim(rtrim(cmgAddr2))               || '|' ||
                                ltrim(rtrim(cityDesc))              || '|' ||
                                ltrim(rtrim(stateDesc)) || '|' ||
                                ltrim(rtrim(cntryDesc)) || ' - ' ||
                                ltrim(rtrim(cmgPinCode)) || '|' ||
                                cmgCustStatCode || '|' ||
                     			'Y' ||'|'||firstAcc|| '|' ||'CustomerStateMent');
END processCiftCursor;


BEGIN
	cnt					:= 0;
	runId				:= '&1';
	custSolId			:= '&2';
	idType				:= '&4';
	beginCustId			:= lpad('&5', 9);
	endCustId			:= lpad('&6', 9);
	frmDate             := '&7';
	toDate              := '&8';
	pspCustListId		:= runId||'PBK'||idType||'_C';
	pspAcctListId		:= runId||'PBK'||idType||'_A';

	commitCnt := 0;

	custRecType			:= '01';
	custSubRecType		:= '0';

	likeStr		:= runId||'PBK'||idType||'_%';

	step := 1;
	iciArray.construct(custStatCodes, ',' , custStatCnt, custStatArr);

	DELETE FROM
		PSP_TMP
	WHERE
		LISTID LIKE likeStr 
		AND home_sol_id = 'PBK';
	
	COMMIT;

	dbms_output.put_line('PBK'              || '|' ||
                                lpad(' ',9)              || '|00|0|' ||
                                frmDate             || '|' ||
                                toDate    || '|' ||
                               ' '                 || '|' ||
                                ' '               || '|' ||
                                ' '              || '|' ||
                                ' ' || '|' ||
                                ' ' || '  ' ||
                                ' ' || '|' ||
                                ' ' ||'|'||' '|| '|' ||' ');
	OPEN ciftCur;

	endOfCiftCursor := 0;

	WHILE (endOfCiftCursor = 0) LOOP
		processCiftCursor(0);
		commitCnt := commitCnt + 1;
		IF (commitCnt = 1000) THEN
			COMMIT;
			commitCnt := 0;
		END IF;
	END LOOP;

	CLOSE ciftCur;

	COMMIT;

	EXCEPTION
	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('<#ORA-ERROR#>');
		DBMS_OUTPUT.PUT_LINE('Cust Id/Account Id list creation failed at step...'||step);
		DBMS_OUTPUT.PUT_LINE('Cust Id '||ciftCustId);
		DBMS_OUTPUT.PUT_LINE('Check SQL error,  and try again');
		DBMS_OUTPUT.PUT_LINE('Sql Error Code is        : ' || SQLCODE );
		DBMS_OUTPUT.PUT_LINE('SQL Error Description is : '|| SQLERRM);
		ROLLBACK;
		DBMS_OUTPUT.PUT_LINE('Currenct Chunk rolled back.');
END;
/
spool off
