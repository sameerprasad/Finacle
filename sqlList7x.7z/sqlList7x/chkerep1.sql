-- report of bm's checklist
set serveroutput on
set linesize 1024
spool chkerep1
declare
cursor chkcur is 
select sol_id, user_id,insdate,instime,morneve,resp1,reason1,resp2,reason2,
resp3,reason3,resp4,reason4,resp5,reason5,resp6,reason6,resp7,reason7,
resp8,reason8,resp9,reason9,resp10,reason10
from icibmchk where insdate = '01.01.2002' and morneve = 'E';
sol		number;
begin
	for chkrec in chkcur
	loop
		dbms_output.put_line(chkrec.sol_id||'|'||chkrec.resp1||' '||chkrec.reason1||'|'||chkrec.resp2||' '||chkrec.reason2||'|'||chkrec.resp3||' '||chkrec.reason3||'|'||chkrec.resp4||' '||chkrec.reason4||'|'||chkrec.resp5||' '||chkrec.reason5||'|'||chkrec.resp6||' '||chkrec.reason6||'|'||chkrec.resp7||' '||chkrec.reason7||'|'||chkrec.resp8||' '||chkrec.reason8||'|'||chkrec.resp9||' '||chkrec.reason9||'|'||chkrec.resp10||' '||chkrec.reason10||'|');	
	end loop;
end;
/
spool off
exit
