set head off
set verify off
set feedback off

spool tmp1.lst

select 'TMPREP.TEMP.maturityDate="' || to_char(TAM.MATURITY_DATE, 'yyyymmdd') || '"' 
from 
	GAM, TAM 
where 
	GAM.FORACID = '&1'
and    	GAM.ACID = TAM.ACID
/
spool off
