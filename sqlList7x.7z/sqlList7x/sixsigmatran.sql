#clear screen
set echo off 
set termout on
set pause off
set verify off
whenever sqlerror exit sql.sqlcode
set colsep |
set linesize 600
set pages 66

accept solid    prompt "Sol id 				   :"
accept start_date prompt "Enter Start Date       : "
accept end_date   prompt "Enter End Date         : "
accept userid   prompt "Enter User ID in quots [ex :'ABC01','XYZ02']"
spool sixsigmatran
select d.sol_id,g.foracid "Acct-No.",
    d.tran_id,
    d.tran_type||'/'||tran_sub_type,
    d.entry_user_id,
	d.tran_date,
    to_char(d.entry_date,'hh24:mi:ss'),
    d.rcre_user_id,
    to_char(d.rcre_time, 'hh24:mi:ss'),
    d.pstd_user_id,
    to_char(d.pstd_date, 'hh24:mi:ss'),
    d.vfd_user_id,
    to_char(d.vfd_date, 'hh24:mi:ss'),
    d.tran_crncy_code,
    substr(g.acct_name,1,15) "Acct-Name",
    d.tran_amt,
d.ref_num,
--  (d.tran_amt * decode(d.part_tran_type,'D',1,0)),
--  (d.tran_amt * decode(d.part_tran_type,'C',1,0)),
    substr(d.tran_particular,1,15) "Tran-Particular"
from ctd d,  gam g
where d.tran_date >='&start_date' 
and d.tran_date <='&end_date' 
and d.acid = g.acid
and d.sol_id = &solid
and part_tran_type='C'
and d.rcre_user_id in (&userid)
order by d.tran_date

/
spool off
exit
