----
SET SERVEROUTPUT ON SIZE 1000000
set head off echo off verify off feedback off trims on 
	Declare
	failFlg		varchar2(5) := 'Y';	
	schlid		varchar2(16) := '&1';
	loc_school_name	icici_rct.ref_desc%type;

Begin
		Begin
		--{
			Select ref_desc,
					'N'
			  into loc_school_name,failFlg
   			  from icici_rct
			  where ref_code = schlid
				and ref_rec_type = '11';
			Exception
			when no_data_found then
				failFlg := 'Y';
				loc_school_name := NULL;
		--}
		End;
		if failFlg = 'N' then
			dbms_output.put_line(loc_school_name);
		else
			dbms_output.put_line('XXXX');
		end if;
--}
End;
/
