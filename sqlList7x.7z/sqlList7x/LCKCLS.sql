--##############################################################################################
--#                     File Name       : LCKCLS.sql
--#                     Author : Arun Kumar (BBSSL)
--#                     Report : LOCKER OPEN AND CLOSE REPORT
--#                     Date   :
--#                     Module  : LOCKER
--#                     Called Menu     : LOCKRPT
--#                     Called By       : LCKCLS.com
--##############################################################################################

create or replace package LCKCLS_pack AS
procedure LCKCLS_proc(
			inp_str IN VARCHAR2,
			out_retcode OUT NUMBER,
			out_rec OUT VARCHAR2
		     );
end LCKCLS_pack;
/
create or replace package body LCKCLS_pack AS
v_sol_id		GAM.sol_id%TYPE;
v_date1			date;
v_date2			date;
v_issue_date		date;
v_surr_date		date;
v_lock_no		CLMT.LOCKER_NUM%TYPE;
v_lock_type		CLMT.locker_type%TYPE;
v_key_no		WLCKM.KEY_NUM%TYPE;
v_cust_id		CMG.cust_id%TYPE;
v_cust_name		CMG.cust_name%TYPE;
v_status		VARCHAR2(30);
v_lock_period		CLMT.locker_period%TYPE;
v_reason		LCSM.REASON%TYPE;

CURSOR C1(v_sol_id  GAM.sol_id%TYPE,v_date1 date,v_date2 date) IS
SELECT DISTINCT 
		WLCKM.locker_num,
		WLCKM.locker_type,
		wlckm.key_num,
		TO_DATE(clmt.issue_date,'DD-MM-YYYY'),
		DECODE(wlckm.status,'A','AVAILABLE','B','FOR BANK USE','L','LOST','U','USED','S','SURRENDER','F','FREEZE')stat,
		clmt.cust_id,
		CLMT.LOCKER_PERIOD,
		NULL "surrender_date",
		NULL "reason"
FROM	       
		WLCKM,clmt
WHERE	     
		CLMT.LOCKER_NUM = WLCKM.LOCKER_NUM
AND	        CLMT.SOL_ID = v_sol_id
AND	        CLMT.issue_date BETWEEN TO_DATE(v_date1,'dd-mm-yyyy') AND TO_DATE(v_date2,'dd-mm-yyyy')
AND		WLCKM.status = 'U'
AND		CLMT.RENEWAL_DATE IS NULL
AND		CLMT.del_flg != 'Y'
AND		CLMT.ENTITY_CRE_FLG != 'N'

UNION

SELECT DISTINCT
		WLCKM.locker_num,
		clmt.locker_type,
		clmt.locker_key_num,
		clmt.issue_date,
		DECODE(wlckm.status,'A','AVAILABLE','B','FOR BANK USE','L','LOST','U','USED','S','SURRENDER','F','FREEZE')stat,
		LCSM.cust_id,
		clmt.locker_period,
		TO_DATE((SUBSTR(LCSM.SURRENDER_DATE,1,10)),'DD-MM-YYYY'),
		LCSM.REASON
FROM 
		WLCKM,LCSM,clmt
WHERE 
		WLCKM.LOCKER_NUM = LCSM.lock_no
AND		lcsm.lock_no = clmt.locker_num 
AND		wlckm.sol_id = clmt.sol_id
AND	        TO_DATE(SUBSTR(LCSM.SURRENDER_DATE,1,10),'dd-mm-yyyy') BETWEEN TO_DATE(v_date1,'dd-mm-yyyy') AND TO_DATE(v_date2,'dd-mm-yyyy')
AND	        WLCKM.SOL_ID    = v_sol_id
AND	        WLCKM.status = 'S'
AND		WLCKM.DEL_FLG != 'Y'
AND		WLCKM.ENTITY_CRE_FLG = 'Y'
ORDER BY 5 DESC;

OutArr	basp0099.ArrayType;
	PROCEDURE LCKCLS_proc
	(
		inp_str IN varchar2,
		out_retcode OUT number,
		out_rec OUT varchar2
	) AS
BEGIN
	out_retcode := 0;
	IF (NOT C1%ISOPEN) THEN
		basp0099.formInputArr(inp_str,outArr);
			v_sol_id	:=	outArr(0);
			v_date1	:=	outArr(1);
			v_date2	:=      outArr(2);
	OPEN C1(v_sol_id,v_date1,v_date2);
	END IF;	

	IF(C1%ISOPEN) THEN
		FETCH C1 INTO
				v_lock_no,
				v_lock_type,
				v_key_no,
				v_issue_date,
				v_status,
				v_cust_id,
				v_lock_period,
				v_surr_date,
				v_reason;
	END IF;

	IF(C1%NOTFOUND) THEN
		close C1;
		out_retcode :=1;
		return;
	END IF;

	BEGIN
		SELECT
			cust_name
		INTO
			v_cust_name
		FROM
			cmg
		WHERE
			cust_id = v_cust_id;
		EXCEPTION
			WHEN NO_DATA_FOUND THEN
			v_cust_name := NULL;
	END;			


					out_rec := 
							v_lock_no		||'|'||
							v_lock_type		||'|'||
							v_key_no		||'|'||
							v_issue_date		||'|'||
							v_status		||'|'||
							v_cust_id		||'|'||
							v_cust_name		||'|'||
							v_lock_period		||'|'||
							v_surr_date		||'|'||
							v_reason;
					return;
end LCKCLS_proc;
end LCKCLS_pack;
/
drop public synonym LCKCLS_pack
/
create or replace public synonym LCKCLS_pack for LCKCLS_pack
/
grant execute on LCKCLS_pack to tbautil, tbacust, tbagen,tbaadm
/
			
	
			     
		    
		     
