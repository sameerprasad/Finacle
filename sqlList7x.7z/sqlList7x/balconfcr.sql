rem   Script for creating data file FOR od/cc balance confirmation- LETTERS -
rem   for the given DATE. - only debit balance a/cs selected.
rem        Input parameters in command line
rem     
rem        Tables accessed: CMG, GAM, RCT, EAB.
rem        Author Mukesh Kumar Jain (AHLETGEN Version)
rem
rem        This is the version for GPLG 
rem 
rem     Parameters :-
rem     1 - spool file name (populated by GPLG)
rem     2 - Scheme code
rem     3 - Account prefix
rem     4 - Low account number
rem     5 - High account number
rem     6 - Date on which debit interest run took  place
rem
rem     Following defaults are being used by this SQL :-
rem     - Extension counter code = '00'
rem     - Default city and state codes are '*' (That is, if these
rem       values are not available in CMG)

set echo off
set termout off
set pause off
set feedback off
set verify off
whenever sqlerror exit sql.sqlcode
set linesize 500
set pagesize 0
set heading off
set space 0

set numformat 999999999999.99
column tran_date_bal justify left

SPOOL  &1
select  a.cust_id,
  '|',  a.cust_title_code, 
  '|',  a.cust_name,
  '|',  a.cust_comu_addr1, 
  '|',  a.cust_comu_addr2,
  '|',  x.ref_desc, 
  '|',  y.ref_desc,
  '|',  a.cust_comu_pin_code, 
  '|',  substr(b.foracid,5,2), 
  '|',  ltrim(substr(b.foracid,7,6),0), 
  '|',  ltrim(to_char(abs (c.tran_date_bal),'b999999999999.99')),
  '|',  upper('&2'),
  '|' 
from cmg a, eab c, rct x, rct y, gam b
where b.sol_id='&3' and 
(b.gl_sub_head_code between '05010' and '05050'
or b.gl_sub_head_code between '60010' and '63090')
and   c.acid = b.acid
and   c.tran_date_bal > 0
and   a.cust_id = b.cust_id  
and   b.cust_id != '999999999' 
and   b.acct_cls_flg != 'Y'             
and   x.ref_rec_type = '01'
and   nvl(a.cust_comu_city_code,'*') = x.ref_code
and   y.ref_rec_type = '02'
and   nvl(a.cust_comu_state_code, '*') = y.ref_code
and   c.eod_date = (select max(m.eod_Date) from eab m
		where m.acid = b.acid
		and m.eod_date <= to_date(upper('&2'),'DD-MON-YYYY'))
order by 1
/
spool off
ttitle off
btitle off
whenever sqlerror continue
set termout on
set feedback on
set verify on
set heading on
clear breaks 
set echo on
exit
