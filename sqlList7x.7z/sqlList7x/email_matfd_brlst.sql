set head off
set feedback off
set verify off
set pages 0
spool br
select sol_id from sol order by sol_id;
exit

