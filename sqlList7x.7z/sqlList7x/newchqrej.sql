--set head off echo off feedback off verify off pagesi 0 trims on term off
set serveroutput on  size 1000000
set linesi 300

spool chqreject

declare

cursor c1 is
select foracid,cust_id,substr(acct_name,1,45) ac,clg_zone_date,instrmnt_num,clg_zone_code,rejected_date,
instrmnt_amt,rej_type,rej_code_1,rej_code_2,rej_code_3,rej_code_4,rej_code_5
from crt,gam
where    gam.acid = crt.acid
and   rejected_date between '&1' and '&2'
and   instrmnt_amt >= 10000000
and   rej_type = 'I'
and   schm_type in ('SBA','CAA','ODA','LAA','CCA','PCA','FBA','BIA')
and   ( rej_code_1 in ('03','02','04','01') or rej_code_2 in ('03','02','04','01') or
rej_code_3 in ('03','02','04','01') or rej_code_4 in ('03','02','04','01') or
rej_code_5 in ('03','02','04','01'))
order by foracid,rejected_date;

gcus cmg.cust_stat_code%type;
gconst cmg.cust_const%type;
fr gam.foracid%type := 'A';
lcusttt cmg.cust_title_code%type;
ladd1       cmg.cust_comu_addr1%type;
ladd2       cmg.cust_comu_addr2%type;
lcc     cmg.cust_comu_city_code%type;
lsc     cmg.cust_comu_state_code%type;
lpc     cmg.cust_comu_pin_code%type;
lccdes   rct.ref_desc%type;
lscdes  rct.ref_desc%type;
rejdesc1 crc.clg_rej_desc%type;
rejdesc2 crc.clg_rej_desc%type;
rejdesc3 crc.clg_rej_desc%type;
rejdesc4 crc.clg_rej_desc%type;
rejdesc5 crc.clg_rej_desc%type;
fw utl_file.file_type;
fz utl_file.file_type;
f4 utl_file.file_type;
f3 utl_file.file_type;
kount number :=0;
srlnum number := 1;
rejdt crt.rejected_date%type;

begin

fw := utl_file.fopen('/tmp','chqfull','w');
fz := utl_file.fopen('/tmp','chqtoday','w');
f4 := utl_file.fopen('/tmp','chqcust4','w');
f3 := utl_file.fopen('/tmp','chqcust3','w');


for i in c1
loop


	begin
		select clg_rej_desc into rejdesc1 from crc where clg_rej_code = i.rej_code_1;
		select clg_rej_desc into rejdesc2 from crc where clg_rej_code = i.rej_code_2;
		select clg_rej_desc into rejdesc3 from crc where clg_rej_code = i.rej_code_3;
		select clg_rej_desc into rejdesc4 from crc where clg_rej_code = i.rej_code_4;
		select clg_rej_desc into rejdesc5 from crc where clg_rej_code = i.rej_code_5;

	exception
		when others then null;
	end;

	if (( fr != i.foracid ) and ( fr != 'A' ))
	then
		
		select cust_title_code,cust_comu_addr1,cust_comu_addr2,cust_comu_city_code,cust_comu_state_code,
		cust_comu_pin_code,cust_stat_code,cust_const into lcusttt,ladd1,ladd2,lcc,lsc,lpc,gcus,gconst 
		from cmg where cust_id = i.cust_id;

		begin
			select ref_desc into lccdes from rct  where ref_rec_type = '01' and ref_code = lcc;

		exception
			when no_data_found then lccdes := null;
		end;


		begin
			select ref_desc into lscdes from rct b where ref_rec_type = '02' and ref_code = lsc;

		exception
			when no_data_found then lscdes := null;
		end;

	end if;

	utl_file.put_line(fw,lcusttt           ||'|'||
                        i.ac              ||'|'||
                        ladd1             ||'|'||
                        ladd2             ||'|'||
                        lccdes            ||'|'||
                        lpc               ||'|'||
                        lscdes            ||'|'||
                        i.foracid         ||'|'||
								i.clg_zone_date	||'|'||
								i.instrmnt_num		||'|'||
								i.instrmnt_amt);

	dbms_output.put_line(i.foracid||'|'||fr||'|'||kount);

	if ( i.rejected_date = '&2' )
	then
		

      utl_file.put_line(fz,i.foracid            ||'|'||
                           i.ac                 ||'|'||
                           gcus                 ||'|'||
                           gconst               ||'|'||
                           i.clg_zone_date      ||'|'||
                           i.clg_zone_code      ||'|'||
                           i.instrmnt_num       ||'|'||
                           i.instrmnt_amt       ||'|'||
                           rejdesc1             ||'|'||
                           rejdesc2             ||'|'||
                           rejdesc3             ||'|'||
                           rejdesc4             ||'|'||
                           rejdesc5             ||'|'||
                           srlnum);

	end if;
	

	if ( rejdt = '&2')
	then

		dbms_output.put_line(kount);
		if (( fr != i.foracid ) and ( fr != 'A' ))
		then

			if ( kount > 3 )
			then
				utl_file.put_line(f4,fr);
			elsif ( kount = 3 )
			then
				utl_file.put_line(f3,fr);
			end if;

			srlnum := 1;
		else
			srlnum := srlnum + 1;

		end if;

	end if;

	if (( fr != i.foracid ) and ( fr != 'A' ))
	then

		kount := 1;

	elsif (( fr = i.foracid ) or ( fr = 'A' ))
	then

		kount := kount + 1;

	end if;

	fr := i.foracid;
	rejdt := i.rejected_date;
end loop;

end;
/
