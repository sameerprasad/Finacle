set pages 0 verify off feedback off termout off trims on
spool camsa.lst
select concat('stmt',to_char(add_months(last_day(db_stat_date), -1) , 'YYYYMMDD')) from gct;
spool off
