prompt 'Creation of Menu option PPFINT :'

select 'Adding the new menu option PPFINT...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'PPFINT';
end;
/
delete mod where mop_id = 'PPFINT';
set escape \

insert into mod values ('PPFINT','Y','N','U','http://$W/finbranch/','custom/PPFINTCAL.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','120','999','','999','999','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'PPFINT';
insert into oat values ('PPFINT', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
insert into oat values ('PPFINT', 'DB', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
insert into oat values ('PPFINT', 'OP', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);


delete mod_txt where mop_id = 'PPFINT';

insert into mod_txt values ('PPFINT', 'INFENG', 'PPFINT', 'PPF Interest Calculator', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

commit
/
