--##############################################################################################
--#                     File Name       : LCKISS.sql
--#                     Author : Ashwani Bhat (BBSSL)
--#                     Report : Locker Issued Report
--#                     Date   :
--#                     Module  : LOCKER
--#                     Called Menu     : LOCKRPT
--##############################################################################################
SET SERVEROUTPUT ON SIZE 1000000;
SET VERIFY OFF
SET TERMOUT OFF
SET TRIMSPOOL ON
SET ECHO OFF
SET FEEDBACK OFF
SET EMBEDDED ON
SET LINES 400
SET HEAD OFF
SET PAGES 0
CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES  
SPOOL LCKISS.lst

DECLARE
	solid			GAM.SOL_ID%TYPE:='&1';
	date1 			DATE:='&2';
	date2			DATE:='&3';
	v_issue_date		DATE;
	v_lock_num		CLMT.LOCKER_NUM%TYPE;
	v_lock_size		CLMT.LOCKER_SIZE%TYPE;
	v_key_num		CLMT.LOCKER_KEY_NUM%TYPE;
	v_cust_name		CMG.CUST_NAME%TYPE;
	v_oper_acnt		CLMT.OPER_ACNT%TYPE;
	v_pin_code		CMG.CUST_COMU_PIN_CODE%TYPE;
	v_cust_id		CMG.CUST_ID%TYPE;
	v_addr1			CMG.CUST_COMU_ADDR1%TYPE;
	v_addr2			CMG.CUST_COMU_ADDR1%TYPE;
	v_state			CMG.CUST_COMU_ADDR1%TYPE;
	v_city			CMG.CUST_COMU_ADDR1%TYPE;
	city_name		CMG.CUST_COMU_ADDR1%TYPE;
	state_name		CMG.CUST_COMU_ADDR1%TYPE;
	v_oper_mode		CLMT.OPERATION_MODE%TYPE;
	v_renewal_date 		DATE;
	v_sur_date		DATE;
	v_status		C_SVRSETVAR.VARIABLE_VALUE%TYPE;
	v_rent_paid		LCPD.PAID_AMOUNT%TYPE;
	v_paid_date		DATE;
	v_due_date		DATE;

CURSOR c1 (solid GAM.SOL_ID%TYPE,date1 DATE,date2 DATE) IS
SELECT	LOCKER_NUM, 
	LOCKER_KEY_NUM,
        LOCKER_SIZE,
        ISSUE_DATE,
        OPER_ACNT,
        CUST_ID,
        RENEWAL_DATE,
	DUE_DATE
FROM CLMT 
WHERE SOL_ID = solid
AND ISSUE_DATE BETWEEN to_date(date1,'dd-mm-yyyy') AND to_date(date2,'dd-mm-yyyy')
AND DEL_FLG !='Y'
AND ENTITY_CRE_FLG = 'Y';

BEGIN
	OPEN c1(solid,date1,date2);
	LOOP
	--{
		FETCH c1
		INTO	
			v_lock_num,
			v_key_num,
			v_lock_size,
			v_issue_date,
			v_oper_acnt,
			v_cust_id,
			v_renewal_date,
			v_due_date;
		
		IF c1%NOTFOUND THEN
			CLOSE c1;
			EXIT;
		END IF;
		
		
		BEGIN
			SELECT  CUST_NAME,
				trim(CUST_COMU_ADDR1),
	                        trim(CUST_COMU_ADDR2),
		                trim(CUST_COMU_CITY_CODE),
			        trim(CUST_COMU_STATE_CODE),
				trim(CUST_COMU_PIN_CODE)
			INTO    v_cust_name,
	                        v_addr1,
		                v_addr2,
			        v_city,
				v_state,
	                        v_pin_code
		        FROM    CMG
			WHERE   CUST_ID=v_cust_id;
	                EXCEPTION WHEN NO_DATA_FOUND THEN
		        	v_cust_name:=NULL;
				v_addr1:=NULL;
                		v_addr2:=NULL;
	                	v_state:=NULL;
		        	v_city:=NULL;
				v_pin_code:=NULL;
	        END;
	
		BEGIN
	                SELECT  trim(REF_DESC)
	                INTO    city_name
	                FROM    RCT
	                WHERE   REF_CODE=v_city
	                AND     REF_REC_TYPE='01';
	                EXCEPTION WHEN NO_DATA_FOUND THEN
		                city_name:=NULL;
		END;
	
	        BEGIN
	                SELECT  trim(REF_DESC)
	                INTO    state_name
	                FROM    RCT
	                WHERE   REF_CODE=v_state
	                AND     REF_REC_TYPE='02';
	                EXCEPTION WHEN NO_DATA_FOUND THEN
			        state_name:=NULL;
	        END;

		BEGIN
			SELECT	WLCKM.SURRENDER_DATE,
				C_SVRSETVAR.VARIABLE_VALUE
			INTO	v_sur_date,
				v_status
			FROM WLCKM,C_SVRSETVAR
			WHERE WLCKM.SOL_ID = solid
			AND WLCKM.LOCKER_NUM = v_lock_num
			AND WLCKM.KEY_NUM = v_key_num
			AND WLCKM.STATUS = c_svrsetvar.variable_name
			AND C_SVRSETVAR.MODULE_NAME = 'LOCKER'
			AND C_SVRSETVAR.SUB_MODULE_NAME = 'LCKM';
			EXCEPTION WHEN NO_DATA_FOUND THEN
			        v_sur_date:=NULL;
				v_status := NULL;
		END;
	
		BEGIN
			SELECT	PAID_AMOUNT,
				TRAN_DATE
			INTO	v_rent_paid,
				v_paid_date
			FROM LCPD
			WHERE SOL_ID = solid
			AND CUST_ID = v_cust_id
			AND LOCKER_NUMBER = v_lock_num
			AND REMARKS = 'LOCKER RENT'
			AND DEL_FLG = 'N'
			AND ROWID IN (SELECT MAX(ROWID) FROM LCPD
						WHERE SOL_ID = solid
						AND CUST_ID = v_cust_id
						AND LOCKER_NUMBER = v_lock_num
						AND REMARKS = 'LOCKER RENT'
						AND DEL_FLG = 'N')

;
			EXCEPTION WHEN NO_DATA_FOUND THEN
				v_rent_paid := NULL;
				v_paid_date := NULL;
		END;


	   	
	   	
	
	   
		DBMS_OUTPUT.PUT_LINE (	
				v_lock_num	||'|'||
				v_key_num	||'|'||
				v_issue_date	||'|'||
				v_cust_name	||'|'||
				v_oper_acnt	||'|'||
				v_cust_id	||'|'||
				v_addr1		||'|'||
				v_addr2		||'|'||
				city_name	||'|'||
				state_name	||'|'||
	   			v_pin_code	||'|'||
				v_renewal_date	||'|'||
				v_sur_date	||'|'||
				v_status	||'|'||
				v_rent_paid	||'|'||
				v_paid_date	||'|'||
				v_due_date);
	--}		
	END LOOP;				
	   			
END;	   			
/
SPOOL OFF

