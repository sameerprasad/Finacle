
set serveroutput on
set pages 0
set verify off
set feedback off
set termout off
set lines 200
set trimspool on
set numf 9999999999999999999999.99
spool &4..cblo

DECLARE

loc_date varchar(100);
loc_date1 varchar(100);
file_tran_date varchar(100);
loc_file_name varchar(100);
loc_tran_id varchar(100);
loc_tran_perticular varchar(100);
loc_dr_foracid varchar(100);
loc_cr_foracid varchar(100);
loc_tran_type  char(2);
loc_file_nom char(6);
loc_eff_bal number(20,2);
loc_dif_amt number(20,2);
loc_mt204_oblig_bal number(20,2) :=0;
loc_mt202_oblig_bal number(20,2) :=0;
tot_sftg_bal number(20,2) :=0;
loc_oblig_bal number(20,2);
loc_oblig_amt number(20,2);
loc_sft_amt number(20,2);
loc_ccil_acctno varchar(100) := '&1';
temp_yymmdd varchar(100);
temp_chr_bal varchar(100);
secutype varchar(100);
field20 varchar(100);
run_srl_num	varchar(10);
visited	integer :=0;
loc_seq_no      varchar(10);
seq	integer :=0;
sql_foracid  varchar(16);
sql_tran_perti varchar(100);
sql_amt1 number(20,2);
sql_amt2 number(20,2);
sql_trandate varchar(100);
sql_tranid varchar(10);
file_chk_cnt integer :=0;

cursor CUR_FILE_NAMES is
select distinct file_name from ici_ccil where TRAN_DATE=file_tran_date and upper(file_name) like '%CBLO%'  order by substr(FILE_NAME,11,5) desc;

cursor CUR_MT202 is
select CRFORACID,CUST_NAME,OBLIG_AMT,EFFECTIVE_AVIL_BAL,TRAN_PARTICULAR,TRAN_ID,to_char(TRAN_DATE,'YYMMDD') TRNDT,TRAN_DATE
from ici_ccil
where upper(file_name)=upper(loc_file_name) and TRAN_TYPE='C' and DEL_FLG='N';

cursor CUR_MT204 is
select DRFORACID,CUST_NAME,OBLIG_AMT, EFFECTIVE_AVIL_BAL,TRAN_PARTICULAR,TRAN_ID,to_char(TRAN_DATE,'YYMMDD') TRNDT,TRAN_DATE
from ici_ccil
where upper(file_name)=upper(loc_file_name) and TRAN_TYPE='D' and DEL_FLG='N';


BEGIN

select upper(substr(loc_file_name,10,5)) into loc_file_nom from dual;
 DBMS_OUTPUT.PUT_LINE('{1:F01'||'&2'||'00000000000}{2:O940'||'&3'||'XN}{4:');

select to_char(db_stat_date,'DD-MM-YYYY') into file_tran_date from gct;
select (count(1) +1) into seq from ICI_CCIL_REP where to_char(tran_date,'DD-MM-YYYY')=(select to_char(max(pstd_date),'DD-MM-YYYY') from dtd);
for f1 in CUR_FILE_NAMES LOOP

loc_file_name := f1.file_name;

select count(1) into file_chk_cnt from ici_ccil_rep where file_name=loc_file_name;

if (file_chk_cnt < 1) then

---{ Check alredy generated


select upper(substr(loc_file_name,5,4)) into secutype from dual;

select to_char(db_stat_date,'YYYYMMDD') into loc_date1 from gct;

select lpad(count(distinct file_name),7,0) into run_srl_num from ici_ccil where tran_date=(select db_stat_date from gct);
select upper(substr(loc_file_name,10,5)) into loc_file_nom from dual;

field20 := loc_date1||run_srl_num;

if ((loc_file_nom = 'MT204') and (visited = 0)) then

	visited := visited +1;
 ---select CRFORACID,TRAN_PARTICULAR,EFFECTIVE_AVIL_BAL,to_char(TRAN_DATE,'YYMMDD') into loc_cr_foracid,loc_tran_perticular,loc_eff_bal,loc_date from ici_ccil 
--- where upper(file_name) =upper(loc_file_name) and CRFORACID is not null and rownum=1;
 select CRFORACID,TRAN_PARTICULAR,EFFECTIVE_AVIL_BAL,to_char(TRAN_DATE,'YYMMDD') into loc_cr_foracid,loc_tran_perticular,loc_eff_bal,loc_date from ici_ccil 
 where DRFORACID='&3' and CRFORACID is not null and tran_date=file_tran_date and
 rowid = (select min(rowid) from ici_ccil where DRFORACID='&3' and CRFORACID is not null and tran_date=file_tran_date);
  DBMS_OUTPUT.PUT_LINE(':20:'||field20);
  DBMS_OUTPUT.PUT_LINE(':25:'||loc_ccil_acctno);
  DBMS_OUTPUT.PUT_LINE(':28C:37/1');
  DBMS_OUTPUT.PUT_LINE(':60F:C'||loc_date||'INR'||trim(replace(to_char(loc_eff_bal,999999999999999999990.99),'.',',')));
end if;

if (loc_file_nom = 'MT204') then
 for c in CUR_MT204 loop

        begin
                select SFT_AMOUNT into loc_sft_amt
                from ici_ccil_sft where upper(file_name) =upper(loc_file_name)
                                        and  FORACID = c.DRFORACID ;
        EXCEPTION
        WHEN NO_DATA_FOUND then
                loc_sft_amt :=0;
        end;
                loc_oblig_amt := c.OBLIG_AMT - loc_sft_amt;
		tot_sftg_bal := tot_sftg_bal + loc_sft_amt;


	DBMS_OUTPUT.PUT_LINE(':61:'||c.TRNDT||'D'||trim(replace(to_char(loc_oblig_amt,999999999999999999990.99),'.',','))||'STLM'||c.TRAN_PARTICULAR||'//'||c.DRFORACID);
	DBMS_OUTPUT.PUT_LINE(':86:CBLO PAYIN PROCEEDS');

	Select to_char(PSTD_DATE,'DD/MM/YYYY  hh24:mi:ss') into sql_trandate from dtd where tran_id=c.tran_id and tran_date=c.TRAN_DATE and acid=(Select acid from gam where foracid=c.DRFORACID) and rownum=1;
        sql_foracid := c.DRFORACID;
        sql_tran_perti := c.TRAN_PARTICULAR;
        sql_amt1 := loc_oblig_amt;
--        sql_trandate := c.TRAN_DATE;
        sql_tranid := c.tran_id;
        select lpad(to_char(seq),5,'0') into loc_seq_no  from dual;
        insert into ICI_CCIL_REP values(loc_file_name,loc_ccil_acctno,sql_foracid,'C',TO_DATE(sql_trandate,'DD/MM/YYYY  hh24:mi:ss'),sql_amt1,loc_eff_bal,sql_tran_perti,sql_tranid,loc_seq_no,'N','1419','CBLO');
	seq := seq +1;
        commit;
 end loop;
 Select sum(OBLIG_AMT) into loc_oblig_bal from ici_ccil where upper(file_name)=upper(loc_file_name) and TRAN_TYPE='D'  and DEL_FLG='N';
 loc_mt204_oblig_bal := loc_mt204_oblig_bal + loc_oblig_bal;
end if;


if ((loc_file_nom = 'MT202') and (visited = 0))  then
 visited := visited +1;
 select DRFORACID,TRAN_PARTICULAR,EFFECTIVE_AVIL_BAL,to_char(TRAN_DATE,'YYMMDD') into loc_dr_foracid,loc_tran_perticular,loc_eff_bal,loc_date from ici_ccil 
 where upper(file_name) =upper(loc_file_name) and DRFORACID is not null and rownum=1;
  DBMS_OUTPUT.PUT_LINE(':20:'||field20);
  DBMS_OUTPUT.PUT_LINE(':25:'||loc_ccil_acctno);
  DBMS_OUTPUT.PUT_LINE(':28C:37/1');
  DBMS_OUTPUT.PUT_LINE(':60F:C'||loc_date||'INR'||trim(replace(to_char(loc_eff_bal,999999999999999999990.99),'.',',')));

end if;

if (loc_file_nom = 'MT202') then

 for c in CUR_MT202 loop

        begin
                select SFT_AMOUNT into loc_sft_amt
                from ici_ccil_sft where upper(file_name) =upper(loc_file_name)
                                        and  FORACID = c.CRFORACID and tran_id = c.TRAN_ID;
        EXCEPTION
        WHEN NO_DATA_FOUND then
                loc_sft_amt :=0;
        end;
                loc_oblig_amt := c.OBLIG_AMT - loc_sft_amt;
		tot_sftg_bal := tot_sftg_bal + loc_sft_amt;

	DBMS_OUTPUT.PUT_LINE(':61:'||c.TRNDT||'C'||trim(replace(to_char(loc_oblig_amt,999999999999999999990.99),'.',','))||'STLM'||c.TRAN_PARTICULAR||'//'||c.CRFORACID);
	DBMS_OUTPUT.PUT_LINE(':86:CBLO PAYOUT PROCEEDS');
	Select to_char(PSTD_DATE,'DD/MM/YYYY  hh24:mi:ss') into sql_trandate from dtd where tran_id=c.tran_id and tran_date=c.TRAN_DATE and acid=(Select acid from gam where foracid=c.CRFORACID) and rownum=1;
        sql_foracid := c.CRFORACID;
        sql_tran_perti := c.TRAN_PARTICULAR;
        sql_amt1 := loc_oblig_amt;
--        sql_trandate := c.TRAN_DATE;
        sql_tranid := c.tran_id;
        select lpad(to_char(seq),5,'0') into loc_seq_no  from dual;
        insert into ICI_CCIL_REP values(loc_file_name,loc_ccil_acctno,sql_foracid,'D',TO_DATE(sql_trandate,'DD/MM/YYYY  hh24:mi:ss'),sql_amt1,loc_eff_bal,sql_tran_perti,sql_tranid,loc_seq_no,'N','1418','CBLO');
	seq := seq +1;
        commit;
 end loop;
 Select sum(OBLIG_AMT) into loc_oblig_bal from ici_ccil where upper(file_name)=upper(loc_file_name) and TRAN_TYPE='C' and DEL_FLG='N';
 loc_mt202_oblig_bal := loc_mt202_oblig_bal + loc_oblig_bal;
end if;

end if;

end loop;
loc_dif_amt := loc_eff_bal + loc_mt204_oblig_bal - loc_mt202_oblig_bal - tot_sftg_bal;
DBMS_OUTPUT.PUT_LINE(':62F:C'||loc_date||'INR'||trim(replace(to_char(loc_dif_amt,999999999999999999990.99),'.',',')));
DBMS_OUTPUT.PUT_LINE('-}');
end;
/
spool off;
