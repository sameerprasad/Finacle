spool fexcons.lst
-- This script is prepared for updating revaluationaccount bacid
-- to EXFX-OTHERS for branches   and seed database
-- author murali reviewed by Shashi
select schm_Code, fcnr_Reval_bacid, crncy_code
from csp
where crncy_code != 'INR'
/
update csp
set fcnr_reval_bacid='EXFX-OTHERS'
where crncy_code !='INR'
/
select schm_Code, fcnr_Reval_bacid, crncy_code
from csp
where crncy_code != 'INR'
/
set heading on
-- for updating Report codes in GSPM
-- by murali
-- to bring about consistancy in tran report code vis a vis schm_code

insert into rct values
('10','EEUSB','N','EEFC EURO SB','UPDATED',sysdate,'UPDATED',sysdate)
/
commit
/
insert into rct values
('10','CFDEU','N','FCNR CUM FD EURO','UPDATED',sysdate,'UPDATED',sysdate)
/
commit
/
insert into rct values
('10','CFEEU','N','EEFC CUM- EURO','UPDATED',sysdate,'UPDATED',sysdate)
/
commit
/
insert into rct values
('10','FDHEU','N','FCNR -TRAD-HLY EUR','UPDATED',sysdate,'UPDATED',sysdate)
/
commit
/
insert into rct values
('10','RFEUH','N','RFC-TRAD-PLAN-HRLY-EUR','UPDATED',sysdate,'UPDATED',sysdate)
/
commit
/
insert into rct values
('10','REUSB','N','RFC -EUR-SB','UPDATED',sysdate,'UPDATED',sysdate)
/
commit
/
insert into rct values
('10','EFEUH','N','EEFC HYRLY TRAD PLAN EURO','UPDATED',sysdate,'UPDATED',sysdate)
/
commit
/
insert into rct values
('10','CFREU','N','RFC CUM PLAN EURO','UPDATED',sysdate,'UPDATED',sysdate)
/
commit
/
insert into rct values
('10','EFEUD','N','EUR -D-FIXED DEPOSIT','UPDATED',sysdate,'UPDATED',sysdate)  
/
commit
/
insert into rct values
('10','RFEUD','N','RFC-EUF-D-FIXED DEPOSIT','UPDATED',sysdate,'UPDATED',sysdate)
/
commit
/
insert into rct values
('10','EEUCA','N','FC EUR CURRENT ACCOUNT','UPDATED',sysdate,'UPDATED',sysdate)
/
commit
/
insert into rct values
('10','SBNRE','N','SAVINGS BANK NRE','UPDATED',sysdate,'UPDATED',sysdate)
/
commit
/
-updates str tables with the above report codes where the report codes are wrong
update STR
set tran_rpt_code = schm_code 
where tran_rpt_code = 'EUSSB'
and schm_code = 'EEUSB' 
/
update STR
set tran_rpt_code = schm_code 
where tran_rpt_code = 'CFDDM'
and schm_code = 'CFDEU' 
/
update STR
set tran_rpt_code = schm_code 
where tran_rpt_code = 'CFEUS'
and schm_code = 'CFEEU' 
/
update STR
set tran_rpt_code = schm_code 
where tran_rpt_code = 'FDHDM'
and schm_code = 'FDHEU' 
/
update STR
set tran_rpt_code = schm_code 
where tran_rpt_code = 'RFUSH'
and schm_code = 'RFEUH' 
/
update STR
set tran_rpt_code = schm_code 
where tran_rpt_code = 'RUSSB'
and schm_code = 'REUSB' 
/
update STR
set tran_rpt_code = schm_code 
where tran_rpt_code = 'EFUSH'
and schm_code = 'EFEUH' 
/
update STR
set tran_rpt_code = schm_code 
where tran_rpt_code = 'CFRUS'
and schm_code = 'CFREU' 
/
update STR
set tran_rpt_code = schm_code 
where tran_rpt_code = 'EFDMD'
and schm_code = 'EFEUD' 
/
update STR
set tran_rpt_code = schm_code 
where tran_rpt_code = 'RFUSD'
and schm_code = 'RFEUD' 
/
-- This will insert the values of EEUCA as tran report code in schm_code EEUCA
insert into str
values ('EEUCA','EEUCA','EUR',999999999999.00,999999999999.00)
/
commit
/
insert into str
values ('SBNRE','SBNRE','EUR',999999999999.00,999999999999.00)
/
commit
/
update csp
set int_debit_rpt_code = schm_code,
	int_credit_rpt_code = schm_code
where schm_code = 'SBNRE'
/
spool off
exit
