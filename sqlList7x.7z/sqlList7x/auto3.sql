rem - Report accepts set_id as input
set pages 60
set lines 165
set newp 0
set echo off
set termout off
set verify off
set feedback off
set trimspool on
set heading on

column A heading 'CUST ID' format a6
column B heading 'ACC NUM' format a12
column C heading 'Deposit Amt' format b999,99,99,999.99
column D heading 'Balance Amt' format b999,99,99,999.99
column M heading 'Maturity Amt' format b999,99,99,999.99
column E heading 'Open date' format a10
column F heading 'Maturity |date' format a10
column G heading 'Value date' format a10
column H heading 'Period ' format a6
column I heading 'Inventory ' format a10
column J heading 'Num Printed ' format b999
column K heading 'AR|FLAG' format a4
column L heading 'Int Code'  format a8

break on sol_id skip page on report

column today new_value to_dt
column setid new_value solset
column soldesc new_value solname

select to_char(db_stat_date,'DD-MON-YYYY') today from gct;
select sol.sol_id,sol.sol_desc soldesc,sst.set_id setid
from sol, sst
where sol.sol_id=sst.sol_id
and set_id='&1';

ttitle center 'ICICI BANKING CORPORATION LIMITED ' skip 1 -
center 'LIST OF TERM DEPOSIT ACCOUNTS MATURING UP TO ' to_dt ' WITH SAFE-CUSTODY FLAG AS Y' skip 1 -
center ' SOLSET - ' solset skip 1 -
center ' SOLNAME - ' solname skip 1 -
center ' ------------------- ' skip 2 -

btitle right ' AUTHORISED SIGNATORY ' skip 1 -

break on soldesc skip page on report

spool auto3.&1

select s.sol_desc soldesc,g.foracid B, substr(g.acct_name,1,20) NAME,
t.deposit_amount C, (g.clr_bal_amt+g.un_clr_bal_amt) D,g.acct_opn_date E, 
t.open_effective_date G, t.maturity_date F,maturity_amount M,substr(drt.print_remarks,1,10) RMKS, receipt_alpha||'/'||srl_num I,print_count J,auto_renewal_flg K
from gam g, tam t, sol s, drt
where t.acid = g.acid
and drt.acid=g.acid
and g.sol_id in (select sol_id from sst where set_id='&1')
and t.maturity_date <= (select db_stat_date from gct)
and g.acct_cls_flg != 'Y'
and g.entity_cre_flg = 'Y'
and t.safe_custody_flg='Y'
and g.sol_id=s.sol_id
order by 1,2,F,B
/
spool off
exit
