set serveroutput on size 1000000
set feedback off
set verify off
set linesize 500
spool cbt_status.lst
declare
chq_stat 	  varchar2(500);
chq_alpha 	  varchar2(10);
start_num	  number(10);
chq_lv_stat       varchar(2);
cur_num	          number(10);
cur_num1          number(10);
cur_num2          number(10);
total_num         number(10);
output_num  	  number(10);
cust_name   	  varchar2(85);
cust_addr1  	  varchar2(45);
cust_addr2     	  varchar2(45);
cust_city_code    varchar2(5);
cust_state_code   varchar2(5);
cust_city	  varchar2(25);
cust_state	  varchar2(25);
cust_pin_code     varchar2(6);
fp                utl_file.file_type;

CURSOR GAM_SEL is 
SELECT 
acid,
cust_id,
foracid
FROM gam 
WHERE   foracid = '&1'
and chq_alwd_flg ='Y';

CURSOR CBT_SEL( inpacid varchar )  is 
SELECT chq_num_of_lvs,
	   begin_chq_num,
       nvl(begin_chq_alpha,'*'),
       chq_lvs_stat
FROM CBT
where acid=inpacid;


BEGIN

fp:= utl_file.fopen('/tmp','cbt_status.lst','w');

for gam_rec in gam_sel LOOP --{


if ( gam_sel%notfound ) 
then
close gam_sel;
exit;
end if;

select 
cust_title_code ||' '|| cust_name,
cust_comu_addr1,
cust_comu_addr2,
cust_comu_city_code,
cust_comu_state_code,
cust_comu_pin_code
into 
cust_name,
cust_addr1,
cust_addr2,
cust_city_code,
cust_state_code,
cust_pin_code
from 
CMG 
where cust_id = gam_rec.cust_id;

BEGIN

SELECT  REF_DESC INTO cust_city
            FROM    RCT
            WHERE   REF_REC_TYPE='01' AND
                    REF_CODE=cust_city_code;


SELECT  REF_DESC INTO cust_state
            FROM    RCT
            WHERE   REF_REC_TYPE='02' AND
                    REF_CODE=cust_state_code;

EXCEPTION
WHEN NO_DATA_FOUND then 
cust_state:='*';
cust_city:='*';

END;


open cbt_sel(gam_rec.acid) ;
while ( cbt_sel %ISOPEN) LOOP --{

fetch cbt_sel
into total_num,
start_num,
chq_alpha,
chq_stat;

if ( cbt_sel%notfound) 
then 
close cbt_sel;
exit;
end if;


cur_num:=0;
cur_num1:=0;
cur_num2:=0;
start_num:=start_num-1;
while (cur_num < total_num)
loop
cur_num1:=instr(chq_stat,'U');
cur_num2:=instr(chq_stat,'C');
if (cur_num1 < cur_num2  and cur_num1 > 0 ) 
	then
		cur_num:= cur_num1;
		chq_lv_stat:='U';
	elsif (cur_num2 >0 ) then
		cur_num:=cur_num2;
		chq_lv_stat:='C';
else 
	cur_num := cur_num1;
	chq_lv_stat:='U';
end if;
if (cur_num < 1) 
then
exit;
end if;
output_num:=cur_num + start_num;
start_num:=start_num + cur_num;
dbms_output.put_line(gam_rec.foracid||'|'||chq_alpha||'|'||output_num||'|'||chq_lv_stat||'|'||cust_name||'|'||cust_addr1||'|'||cust_addr2||'|'||cust_city||'|'||cust_state||'|'||cust_pin_code);
chq_stat:=substr(chq_stat,cur_num+1);
if ( chq_stat is null  ) 
then
exit;
end if;
end loop;

end loop;--}
end loop;--}

exception
	     when no_data_found then 
         dbms_output.put_line(' NO DATA FOUND AT STEP ');	
		 when others then
         dbms_output.put_line('error has occured '||sqlcode||'   '||sqlerrm);
end;
/
spool off
