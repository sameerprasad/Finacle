set head off
set pages 0
set verify off
set feedback off
spool custstmt.lst
select foracid||'|'||cust_id||'|'||tran_date_bal||'|'
FROM EAB A,GAM 
where 
GAM.SOL_ID  =   '&1' AND
GAM.ACCT_OPN_DATE   <=  '&4' AND
GAM.CUST_ID         >=  lpad('&2',9) AND
GAM.CUST_ID         <=  lpad('&3',9) AND
GAM.ACCT_CRNCY_CODE = '&5'
AND
GAM.DEL_FLG         !=  'Y' AND
GAM.ACCT_OWNERSHIP != 'O' AND
GAM.ENTITY_CRE_FLG = 'Y' 
and A.ACID= GAM.ACID 
and  EOD_DATE IN (
SELECT MAX(EOD_DATE) FROM EAB B
WHERE B.ACID = A.ACID  AND EOD_DATE <='&4' AND END_EOD_DATE >='&4')
ORDER BY GAM.CUST_ID, GAM.ACCT_CRNCY_CODE, GAM.FORACID;
spool off
