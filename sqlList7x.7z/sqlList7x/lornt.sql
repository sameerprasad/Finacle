--##############################################################################################
--#                     File Name       : lornt.sql
--#                     Author : Ashwani Bhat (BBSSL)
--#                     Report : RENT PAID RECIPT REPORT
--#                     Date   :
--#                     Module  : LOCKER
--#                     Called Menu     : LOCKRPT
--#                     Called By       : lornt.com
--##############################################################################################

CREATE OR REPLACE PACKAGE lornt_pack AS

    PROCEDURE lornt_proc (
		inp_str IN varchar2,
		out_retcode OUT number,
		out_rec OUT varchar2
		);

	END lornt_pack;
/

CREATE OR REPLACE PACKAGE BODY lornt_pack AS  

v_cust_name		cmg.cust_name%type;
v_disc_rent_amt		clmt.disc_rent_amt%type;
v_renewal_date		clmt.renewal_date%type;
v_due_date		clmt.due_date%type;
v_issue_date		clmt.issue_date%type;
v_locker_num		clmt.locker_num%type;
v_locker_type		clmt.locker_type%type;

v_sol_id		clmt.sol_id%type;
v_date			date;
v_address		varchar2(200);


CURSOR lornt (v_sol_id  clmt.sol_id%type, v_date  date) IS

select		cmg.cust_name,
		clmt.disc_rent_amt, 
		decode(renewal_date,null,issue_date,renewal_date),
		due_date,
		clmt.issue_date,
		clmt.locker_num,
		clmt.locker_type
from		clmt, cmg
where		clmt.cust_id = cmg.cust_id
and		clmt.sol_id = v_sol_id
and		decode(renewal_date,null,issue_date, clmt.renewal_date) = to_date(v_date,'dd-mm-yyyy');

OutArr	basp0099.ArrayType;

	PROCEDURE lornt_proc
	(
		inp_str IN varchar2,
		out_retcode  OUT number,
		out_rec  OUT varchar2
	) AS

BEGIN
	out_retcode := 0;
	
	IF (NOT lornt%ISOPEN) THEN
		basp0099.formInputArr(inp_str,outArr);
		v_sol_id := outArr(0);
		v_date := outArr(1);
		

	OPEN lornt (v_sol_id, v_date);

	END IF;
			IF (lornt%ISOPEN) then

				FETCH lornt INTO
					v_cust_name,	
					v_disc_rent_amt,
					v_renewal_date,	
					v_due_date,
					v_issue_date,	
					v_locker_num,	
					v_locker_type;
			END IF;

			IF (lornt%NOTFOUND) THEN

				close lornt;
				out_retcode := 1;
				return;

			END IF;
begin
	select 	br_name||','||br_addr_1||','||br_addr_2||','||br_city_code||','||br_state_code||','||br_pin_code 
	into 	v_address 
	from 	bct 
	where	br_code = v_sol_id 
	and 	bank_code = '018';   
	exception when NO_DATA_FOUND then
	v_address := null;
end;
		
			out_rec :=
					v_cust_name		||'|'||   
					v_disc_rent_amt		||'|'||	    
					v_renewal_date		||'|'||
					v_due_date		||'|'||
					v_issue_date		||'|'||	 
					v_locker_num		||'|'||	    
					v_locker_type		||'|'||
					v_address;
			return;
end lornt_proc;
end lornt_pack;
/
drop public synonym lornt_pack
/
create public synonym lornt_pack for lornt_pack
/
grant execute on lornt_pack to tbacust,tbautil,tbagen,tbaadm
/

