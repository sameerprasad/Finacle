Rem     This file will create CUST_LOCKER_CLAIM_ADVICE_MOD Table
Rem     with the following characteristics.

Rem     Coded by : Ashwani Bhat (BBSSL)

Rem     Module  : LOCKER


Rem TABLE NAME: CUST_LOCKER_CLAIM_ADVICE_MOD

Rem SYNONYM:    CLCA_MOD

DROP TABLE icici.CUST_LOCKER_CLAIM_ADVICE_MOD CASCADE CONSTRAINTS  
/
DROP PUBLIC SYNONYM CLCA_MOD
/
CREATE TABLE icici.CUST_LOCKER_CLAIM_ADVICE_MOD
( 
  SOL_ID          VARCHAR2 (8), 
  LOCKER_NUM      VARCHAR2 (12),
  CUST_ID	  VARCHAR2 (9),
  CLAIM_CUST_ID	  VARCHAR2 (9),
  INFO_RECI_DATE  DATE, 
  INFO_RECI_TIME  VARCHAR2 (25), 
  EXPIRY_DATE     DATE, 
  INFO_BY         VARCHAR2 (20), 
  NOMINEE_NAME    VARCHAR2 (30), 
  COMMENTS_INFO   VARCHAR2 (30), 
  COMMENTS_NOMI   VARCHAR2 (30),
  DEL_FLG	  CHAR(1),
  ENTITY_CRE_FLG  CHAR(1),
  LCHG_USER_ID     VARCHAR2 (15), 
  LCHG_TIME        VARCHAR2 (25), 
  RCRE_USER_ID     VARCHAR2 (15), 
  RCRE_TIME        VARCHAR2 (25)
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */

/
create public synonym CLCA_MOD for icici.CUST_LOCKER_CLAIM_ADVICE_MOD
/
grant select, insert, update, delete on CLCA_MOD to tbagen
/
grant select on CLCA_MOD to tbacust
/
grant select on CLCA_MOD to tbautil
/
grant all on CLCA_MOD to tbaadm
/

