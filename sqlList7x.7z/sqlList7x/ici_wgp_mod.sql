set serveroutput on
spool test
declare

rmname VARCHAR2(50);
csmname VARCHAR2(50);

begin

select replace('&2','#',' '),replace('&5','#',' ') into rmname,csmname from dual;

DBMS_OUTPUT.PUT_LINE(rmname);
DBMS_OUTPUT.PUT_LINE(csmname);


delete from ici_wm_map where CUST_ID = lpad('&1',9);

commit;

insert into ici_wm_map (CUST_ID,RM_NAME,RM_EMAIL,RM_MOBILE,CSM_NAME,CSM_EMAIL,CSM_MOBILE,LCHG_USER_ID,LCHG_TIME,RCRE_USER_ID,RCRE_TIME)values(lpad('&1',9),replace(rmname,'dummy',null),replace('&3','dummy',null),replace('&4','dummy',null),replace(csmname,'dummy',null),replace('&6','dummy',null),replace('&7','dummy',null),'&8',sysdate,'&8',sysdate);

COMMIT;

end;
/
spool off
