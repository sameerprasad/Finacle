drop table icici.cust_locker_change_custid_mod
/
drop public synonym clcci_mod
/
create table  icici.cust_locker_change_custid_mod
(
sol_id 		varchar(8),
locker_num  	varchar(12),
old_cust_id 	varchar(9),
new_cust_id 	varchar(9),
hirer_type 	char(3),
entity_cre_flg  char(1),
LCHG_USER_ID    VARCHAR2(15),
LCHG_TIME       date,
RCRE_USER_ID    VARCHAR2(15),
RCRE_TIME       date,
del_flg 	char(1),
cust_id		varchar(9)
)
/
create public synonym clcci_mod for icici.cust_locker_change_custid_mod
/
grant select,insert,update,delete on clcci_mod to tbagen
/
grant all on clcci_mod to tbaadm
/
grant select on clcci_mod to tbacust
/
grant select on clcci_mod to tbautil
/
