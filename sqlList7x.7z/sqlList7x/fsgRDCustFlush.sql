-- Driver id changed to FRD for RD stmts
set head off
set trims on
set pages 0
set feedback off
set verify off
set termout off
spool Flush.log

SELECT 'Flushing the PSP_TMP table ...' FROM DUAL;

DELETE	PSP_TMP
WHERE	listid LIKE '&1'||'_%' ;

UPDATE	ICICI_LDTT
SET	remarks = 'F'
WHERE	dc_alias = (select dc_alias from gct)
AND	driver_id = 'FRD'
AND	sol_id = substr('&1', 4, 4)
AND	ser_num = substr('&1', 8, 1);

COMMIT;

spool off
