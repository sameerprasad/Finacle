--##############################################################################################
--#                     File Name       : LCKSIEXE.sql
--#                     Author : Chandrasekar.P (BBSSL)
--#                     Report : LOCKER SI EXECUTION REPORT
--#                     Date   :
--#                     Module  : LOCKER
--#                     Called Menu     : LOCKRPT
--#                     Called By       : LCKSIEXE.com
--##############################################################################################

CREATE OR REPLACE PACKAGE LCKSIEXE AS
        PROCEDURE LCKSIEXE(inp_str IN VARCHAR2,
                out_retCode OUT NUMBER,
                out_rec OUT VARCHAR2);
END LCKSIEXE;
/
CREATE OR REPLACE PACKAGE BODY LCKSIEXE AS
v_solid         sst.set_id%type;
v_date		date;

cursor c1 is
	SELECT  DISTINCT(sih.si_srl_num) ,
	tran_id,tran_date,tdtd.SI_ORG_EXEC_DATE,
	sih.cust_id,
	SUBSTR(SUBSTR(sih.RMKS_FREE_TEXT,INSTR(sih.RMKS_FREE_TEXT,'/LOC/'),LENGTH(sih.RMKS_FREE_TEXT)),6,1),
	SUBSTR(SUBSTR(sih.RMKS_FREE_TEXT,INSTR(sih.RMKS_FREE_TEXT,'/LOC/'),LENGTH(sih.RMKS_FREE_TEXT)),8,LENGTH(sih.RMKS_FREE_TEXT))
	FROM  TDTD, SST, SIH  
	WHERE  sih.si_srl_num >= '           1'  
	AND tdtd.si_srl_num(+) = sih.si_srl_num  
	AND sih.last_tried_date = TO_DATE(v_date, 'DD-MM-YYYY HH24:MI:SS')  
	AND (sih.sol_id = sst.sol_id AND sst.set_id = v_solid ) 
	AND (tdtd.si_org_exec_date(+) = TO_DATE(v_date , 'DD-MM-YYYY HH24:MI:SS')) 
	AND tdtd.dtd_pstd_flg!= 'N' 
	AND sih.RMKS_FREE_TEXT LIKE ('%/LOC/%')
	UNION 
	SELECT DISTINCT(sic.si_srl_num),
	tran_id,tran_date,tdtd.SI_ORG_EXEC_DATE,
	sih.cust_id,
	SUBSTR(SUBSTR(sih.RMKS_FREE_TEXT,INSTR(sih.RMKS_FREE_TEXT,'/LOC/'),LENGTH(sih.RMKS_FREE_TEXT)),6,1),
	SUBSTR(SUBSTR(sih.RMKS_FREE_TEXT,INSTR(sih.RMKS_FREE_TEXT,'/LOC/'),LENGTH(sih.RMKS_FREE_TEXT)),8,LENGTH(sih.RMKS_FREE_TEXT)) 
	FROM tdtd,sst,sic,sih 
	WHERE sih.si_srl_num >= '           1'  
	AND tdtd.si_srl_num(+) = sic.si_srl_num  
	AND (tdtd.si_org_exec_date(+) = sic.si_org_exec_date)  
	AND sih.si_srl_num = sic.si_srl_num  
	AND (SIC.last_tried_date = TO_DATE( v_date , 'DD-MM-YYYY HH24:MI:SS'))  
	AND ((sic.sol_id || NULL = sst.sol_id AND sst.set_id = v_solid )) 
	AND tdtd.dtd_pstd_flg!= 'N' 
	AND sih.RMKS_FREE_TEXT LIKE ('%/LOC/%');

PROCEDURE LCKSIEXE(inp_str IN VARCHAR2,
        out_retCode OUT NUMBER,
        out_rec OUT VARCHAR2) IS

outArr                  basp0099.ArrayType;
v_si_srl_num		sih.si_srl_num%type;
v_tran_id		tdtd.tran_id%type;
v_tran_date		tdtd.tran_date%type;
v_SI_ORG_EXEC_DATE	tdtd.SI_ORG_EXEC_DATE%type;
v_cust_id		sih.cust_id%type;
v_period		varchar2(5);
v_locker_number		varchar2(12);
v_cust_name		cmg.cust_name%type;
v_rent_amount		dtd.tran_amt%type;
v_oper_acc		gam.foracid%type;
v_oper_type		gam.schm_type%type;
v_status		varchar2(100) := 'SUCCESS';
v_acid			gam.acid%type;

Begin
        --{
        basp0099.formInputArr(inp_str,outArr);
	v_solid         := outArr(0);
	v_date          := outArr(1);
        out_retCode     :=  0;
        out_rec         := NULL;

------------------------------------------------------------
--Opening cursor
------------------------------------------------------------
        IF(NOT c1%ISOPEN) THEN
        --{
        out_retCode:= 0;
        open c1;
        --}
        END IF;
-------------------------------------------------------------
--Fetching Data
-------------------------------------------------------------
        IF(c1%ISOPEN)  THEN
        FETCH C1
        INTO v_si_srl_num,v_tran_id,v_tran_date,v_SI_ORG_EXEC_DATE,v_cust_id,v_period,v_locker_number;
        end if;
        if (c1%ISOPEN AND c1%NOTFOUND) THEN
        --{
            close c1;
            out_retcode := 1;
            return;
        --}
        end if;
------------------------------------------------------------
--Fetching Limits and Expiry Date
------------------------------------------------------------

begin
	SELECT cust_name INTO v_cust_name
	FROM cmg
	WHERE cust_id = v_cust_id;
	exception when no_data_found then
		v_cust_id := NULL;
end;

begin
        SELECT acid,tran_amt INTO v_acid,v_rent_amount
        FROM (SELECT acid,tran_amt FROM dtd
                WHERE tran_id = v_tran_id
                AND tran_date = v_tran_date
                AND part_tran_type = 'D'
                UNION
                SELECT acid,tran_amt FROM htd
                WHERE tran_id = v_tran_id
                AND tran_date = v_tran_date
                AND part_tran_type = 'D');
        exception when no_data_found then
                v_rent_amount := 0;
end;

begin
	SELECT foracid,schm_type INTO v_oper_acc,v_oper_type
	FROM gam 
	WHERE acid = v_acid;
	exception when no_data_found then
		v_oper_acc := NULL;
		v_oper_type := NULL;
end;

        out_rec := 	v_si_srl_num	||'|'||
			v_locker_number	||'|'||
			v_cust_id	||'|'||
			v_cust_name	||'|'||
			v_oper_acc	||'|'||
			v_oper_type	||'|'||
		v_SI_ORG_EXEC_DATE	||'|'||
			v_rent_amount	||'|'||
			v_period	||'|'||
			v_status;

END LCKSIEXE;
END LCKSIEXE;
/
DROP  PUBLIC SYNONYM LCKSIEXE
/
CREATE PUBLIC SYNONYM LCKSIEXE FOR LCKSIEXE
/
GRANT EXECUTE ON LCKSIEXE to  tbagen, tbautil, tbacust,tbaadm
/
