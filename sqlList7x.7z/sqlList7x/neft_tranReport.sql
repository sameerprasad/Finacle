set pages 0 feedback off echo off verify off trims on lines 2000
spool neft_tranReport_&1..txt
select BENF_IFSC||'|'||BENF_BR||'|'||SENDER_IFSC||'|'||TRAN_NO||'|'||VALUE_DATE||'|'||AMOUNT||'|'||SENDER_NAME||'|'||SENDER_ACT_TYPE||'|'||SENDER_ACCT_NO||'|'||BENF_NAME||'|'||BENF_ACT_TYPE||'|'||BENF_ACCT_NO||'|'||FRESH_RETURN_FLG||'|'||REJECT_CODE||'|'||REF_NUM||'|'||TRAN_DATE||'|'||TRAN_ID||'|'||PART_TRAN_SRL_NUM||'|'||NAM_MATCH_PER||'|'||NAM_MATCH_REMKS||'|'||FILE_NAM||'|'||ICORE_NAM||'|'||TRAN_STATUS||'|'||TRAN_USER||'|'||CMS_ACCOUNT_NO from ICICI_NEFT where FILE_NAM='&1' and TRAN_ID is not null and CMS_ACCOUNT_NO not like'HPCL%'
/
spool off
