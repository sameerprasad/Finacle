set head off
set verify off
set feedback off
set trimspool on
set pages 0
set termout off
spool gctvalue.lst
select dc_alias||'|'||to_char(db_stat_date,'dd-mm-yyyy') from gct
/
spool off
exit


