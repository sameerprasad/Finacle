Rem     This file will create LOCKER_BREAK_OPEN_HISTORY Table
Rem     with the following characteristics.

Rem     Coded by : Manav (BBSSL)

Rem     Module  : LOCKER


Rem TABLE NAME: LOCKER_BREAK_OPEN_HISTORY

Rem SYNONYM:    LCBRKOPH

DROP TABLE icici.LOCKER_BREAK_OPEN_HISTORY CASCADE CONSTRAINTS  
/
DROP PUBLIC SYNONYM LCBRKOPH
/
CREATE TABLE icici.LOCKER_BREAK_OPEN_HISTORY
( 
  SOL_ID           VARCHAR2 (8), 
  BREAK_OPEN_DATE  VARCHAR2 (25), 
  LOCKER_TYPE      VARCHAR2 (5), 
  LOCK_NO          VARCHAR2 (12), 
  KEY_NO           VARCHAR2 (8), 
  CUST_ID          VARCHAR2 (9), 
  CUST_NAME        VARCHAR2 (80), 
  ADDR1            VARCHAR2 (45), 
  ADDR2            VARCHAR2 (45), 
  CITY             VARCHAR2 (25), 
  STATE            VARCHAR2 (25), 
  COUNTRY          VARCHAR2 (25), 
  PIN              VARCHAR2 (6), 
  PHONE            VARCHAR2 (15), 
  TELEX            VARCHAR2 (15), 
  WITNESS1         VARCHAR2 (80), 
  WITNESS2         VARCHAR2 (80), 
  WITNESS3         VARCHAR2 (80), 
  WITNESS4         VARCHAR2 (80), 
  WITNESS5         VARCHAR2 (80), 
  AUTH_BANK_OFF    VARCHAR2 (80), 
  REASON           VARCHAR2 (80), 
  ADVISED_BY       VARCHAR2 (80), 
  LEAGEL_HIRER     VARCHAR2 (80), 
  ITEM_FOUND_1     VARCHAR2 (80), 
  ITEM_FOUND_2     VARCHAR2 (80), 
  ITEM_FOUND_3     VARCHAR2 (80), 
  ENTITY_CRE_FLG   CHAR (1), 
  LCHG_USER_ID     VARCHAR2 (15), 
  LCHG_TIME        VARCHAR2 (25), 
  RCRE_USER_ID     VARCHAR2 (15), 
 RCRE_TIME        VARCHAR2 (25),
 OPR_TYPE         VARCHAR2(2)
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
create public synonym LCBRKOPH for icici.LOCKER_BREAK_OPEN_HISTORY
/
grant select, insert, update, delete on LCBRKOPH to tbagen
/
grant select on LCBRKOPH to tbacust
/
grant select on LCBRKOPH to tbautil
/
grant all on LCBRKOPH to tbaadm
/
CREATE INDEX IDX_LCBRKOPH ON  icici.LOCKER_BREAK_OPEN_HISTORY(SOL_ID, LOCKER_TYPE, LOCK_NO, KEY_NO, CUST_ID) 
/

