set pages 0
set lines 098
set verify off
set termout off
set heading off
set echo off
set feedback off


spool &4 
select count(*) from tfht where to_date(substr(mesg_forward_time,1,10)) <  (to_date('&1' ,'DD-MM-YYYY')-5)
/
select count(*) from tfmt where to_date(substr(mesg_forward_time,1,10)) <  (to_date('&1' ,'DD-MM-YYYY')-5)
/
spool off



spool &2
select * from tfht where to_date(substr(mesg_forward_time,1,10)) <  (to_date('&1' ,'DD-MM-YYYY')-5)
order by substr(to_char(mesg_forward_time,'DD-MM-YYYY HH24:MI:SS'),1,10)  
/
delete from tfht where to_date(substr(mesg_forward_time,1,10)) <  (to_date('&1' ,'DD-MM-YYYY')-5) 
/
commit;
spool off

spool &3
select * from tfmt where substr(mesg_forward_time,1,10) < (to_date('&1','DD-MM-YYYY')-5)
order by substr(to_char(mesg_forward_time,'DD-MM-YYYY HH24:MI:SS'),1,10)
/
delete from tfmt where to_date(substr(mesg_forward_time,1,10)) <  (to_date('&1' ,'DD-MM-YYYY')-5) 
/
commit;
spool off


