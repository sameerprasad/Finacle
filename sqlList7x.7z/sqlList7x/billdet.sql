accept acct_num prompt "Enter the Account Number for which Bill data is required : "
accept start_date prompt"Enter the Start Date from which to search : "
set feedback off
set verify off
set pages 30
set lines 220
set echo off
alter session set nls_date_format='DD-MM-YYYY';
ttitle 'Report of Bills Lodged in different Branches pertaining to &acct_num from &start_date ' center
column solid heading 'Sol ID' format a4 
column soldesc heading 'Branch' format a30
column billid heading 'Bill Id' format a15
column regt heading 'Reg Type' format a8
column regst heading 'RegSubType' format a10
column bdate heading 'Bill Date' format a10
column instype heading 'Ins Typ' format a8
column instnum heading 'Ins Num' format a8
column billamt heading 'Bill Amt' format B99,99,99,99,999.99
column realamt heading 'Rlzd Amt' format B99,99,99,99,999.99
column lodgdt heading 'Ldg Date' format a10
column billstat heading 'Status' format a16
column clsflg heading 'ClsFlg' format a6
column clsdt heading 'Cls Dt' format a10
column lodgebr heading 'Ldg Br' format a6
column lbrnm heading 'Ldg Br Nm' format a25
spool rams
select blt.sol_id solid, rpad(sol_desc,30) soldesc, rpad(blt.bill_id,15) billid,  reg_type regt, reg_sub_type regst, blt.bill_date bdate, blt.instrmnt_type instype, blt.instrmnt_num instnum, to_char(bill_amt,'99,99,99,99,999.99') billamt,lodg_date lodgdt,decode(bill_stat,'G','LODGED','R','REALISED','N','DISHONOURED','T','TRANSFERRED') billstat, decode(cls_flg,'Y','CLOSED','OPEN') clsflg, cls_date clsdt, lodg_coll_br_code lodgebr, rpad(lodg_coll_br_name,25) lbrnm from blt,sol where blt.oper_acid = (Select acid from gam where foracid='&acct_num') and blt.del_flg!='Y' and blt.sol_id=sol.sol_id and blt.lodg_date > = to_date('&start_date','dd-mm-yyyy') order by blt.lodg_date;
