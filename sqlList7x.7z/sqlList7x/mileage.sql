set pages 0
set lines 450
set trimspool on
set verify off
set termout off
set feedback off
spool mileage

select dc_alias from GCT
/
select FORACID||'|'||dtd.TRAN_DATE||'|'||dtd.TRAN_TYPE||'|'|| dtd.TRAN_SUB_TYPE||'|'|| dtd.PART_TRAN_TYPE||'|'|| dtd.VALUE_DATE ||'|'|| dtd.TRAN_AMT||'|'|| dtd.TRAN_PARTICULAR||'|'||acct_cls_flg from dtd,gam
where gam.acid=dtd.acid
and schm_code = 'CAROD'
and dtd.del_flg != 'Y'
/
spool off

spool mileagebal

select FORACID||'|'||eab.TRAN_DATE_BAL
from gam,eab
where 
gam.acid = eab.acid
and eab.eod_date = (select max(eod_date) from eab where acid = gam.acid )
and schm_code = 'CAROD'

/
spool off
