rem ffdod.sql Modified by Soumen Dass to including period/autorenewal flag/formattting changes on 08-06-2001
rem Modified to include the SB account number and cust_id also - 18-07-2001
clear scr
accept solid prompt 'Enter Service Outlet (4-digit) OR %%% for ALL Service Outlets of this Database: '
set termout off
set feedback off
set echo off
set wrap on
set verify off
set linesize 130
set pagesize 60
set newpage 0
column solid heading 'Sol ID' format a6
column fo heading 'A/c No.' format a12
column acct_h heading 'A/c Holder Name' format a12
column md heading 'Maturity Date' format a13
column pf heading 'Print |Flag' format a6
column sc heading 'Safe Cust. |Flag' format a10
column arf heading 'Auto Renewal|Flag' format a13
column period heading 'Deposit Period' format a17
break on solid skip page on sol_id
define dashes = '---------------------------------------------------------------------------------------------------'
ttitle left dashes skip 1 center "Flexi Fixed Deposit Accounts in OD for Service Outlet &solid" skip 1 left dashes
btitle left dashes
spool ffdodrpc
select gam.sol_id solid, gam.cust_id "CUST ID",m.foracid,gam.foracid fo, gam.acct_name Acct_h, tam.maturity_date md, 
concat(concat(concat(DEPOSIT_PERIOD_MTHS, ' months '),DEPOSIT_PERIOD_DAYS),' days') period, 
decode(ltrim(tam.AUTO_RENEWAL_FLG),'N','No','U','Unlimited','Y','Yes for Limited Period','No') arf,
safe_custody_flg sc,printing_flg pf
from gam,ffl,tam,gam m
where tam.acid=gam.acid
and gam.acid=ffl.ffd_acid
and m.acid=ffl.acid
and gam.gl_sub_head_code in ('05060')
and gam.acct_cls_flg!='Y'
and gam.sol_id like lpad('&solid',4,0)
order by gam.sol_id,gam.cust_id
/
spool off
set termout on
clear scr
prompt The report is saved as ffdod&solid..lst
