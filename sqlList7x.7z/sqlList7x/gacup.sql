spool gacup.lst 

alter user tbaadm identified by tbaadm 
/

connect tbaadm/tbaadm
/

--select acid,int_cr_acid from gac where int_cr_acid is null and acid in ( select
--distinct (ffd_acid) from  ffl)
select acid,int_cr_acid from gac where int_cr_acid is null and acid in ( select
distinct (acid) from  tam where link_oper_account is not null)
/


UPDATE GAC  SET 
  INT_CR_ACID= ( SELECT 
ACID FROM tam WHERE GAC.ACID=tam.ACID) 
WHERE  GAC.ACID IN ( SELECT DISTINCT(ACID) FROM tam where link_oper_account is not null)
AND GAC.INT_CR_ACID IS NULL;
/

commit
/

select gac.acid,gac.int_cr_acid from gac where int_cr_acid is null and acid in 
(select distinct (acid) from  tam where link_oper_account is not null)
/
 spool off
/
exit 
/

