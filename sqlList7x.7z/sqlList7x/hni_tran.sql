set verify off
set feedback off
set termout off
set serveroutput on size 1000000
set pagesize 0
set linesize 150
set trims on
---set timing on
spool hnitran_&&1

DECLARE
output_var		varchar2(30000);
header_blk		varchar2(32000);

CURSOR trancur IS 
SELECT 	hth.tran_id,
		hth.tran_date
FROM hth 
WHERE hth.init_sol_id = '&&1'
AND hth.tran_date = '&&2'
AND hth.del_flg <>'Y'	;

CURSOR trancur2 (trid htd.tran_id%type,trdate htd.tran_date%type) IS
SELECT htd.tran_id,
		htd.part_tran_srl_num,
		htd.tran_amt, 
		htd.part_tran_type,
		htd.RPT_CODE,
		to_char(entry_date,'DD-MM-YYYY hh24:mi:ss') entry_time,
		to_char(vfd_date,'DD-MM-YYYY hh24:mi:ss') vfd_time,
		entry_user_id,
		vfd_user_id,
		htd.acid  
FROM HTD
where tran_id = trid
and tran_date = trdate
AND htd.del_flg <>'Y'   ; 

CURSOR gamcur(facid gam.acid%type) IS
SELECT 	foracid,
		schm_code,
		gl_sub_head_code,
		acid,
		cust_stat_code
FROM gam ,cmg
WHERE acid = facid
and (acct_cls_flg <>'Y' or acct_cls_date > '&2')
and acct_opn_date <= '&2'
and gam.cust_id = cmg.cust_id
and cust_stat_code in ('HNI', 'HNI00', 'HNI10', 'HNI1L', 'HNI25', 'HNI3L', 'HNI50', 'HNI5L', 'HNIC', 'HNICE', 'HNIDP', 'HNIE', 'HNIHH', 'HNIM', 'HNIME', 'HNIP', 'HNIPE', 'HNIR', 'HNIS', 'HNISE', 'HNISL', 'HNIST', 'PHNI');

---and cust_stat_code in ('HNI10','HNI00','HNI25','HNI50','HNI1L','HNI3L','HNI5L','HNI') ;


BEGIN
header_blk :='sol_id|tran_date|acct_no|schm_code|stat_code|tran_id|part_tran_srl_no|Dr/Cr|amt|rpt_code|maker_id|maker_time|verifier_id|verifier_time';
DBMS_OUTPUT.PUT_LINE(header_blk);
	FOR A IN trancur 
	LOOP
		FOR X IN trancur2(A.tran_id,A.tran_date)
		LOOP
		FOR B IN gamcur(X.acid)
		LOOP
	output_var := 
					'&&1'		||'|'||
					'&&2'		||'|'||
					B.foracid	||'|'||
					B.schm_code	||'|'||
					B.cust_stat_code	||'|'||
					X.tran_id	||'|'||
					X.part_tran_srl_num	||'|'||
					X.part_tran_type	||'|'||
					X.tran_amt	||'|'||
					X.RPT_CODE	||'|'||
					X.entry_user_id ||'|'||
                    X.entry_time        ||'|'||
                    X.vfd_user_id       ||'|'||
                    X.vfd_time
					;
		DBMS_OUTPUT.PUT_LINE(output_var);	
		END LOOP;
		END LOOP;
	END LOOP;
END;
/
spool off
