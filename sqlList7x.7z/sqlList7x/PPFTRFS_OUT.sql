REM###########################################################################################################
REM File Name   : PPFTRFS_OUT.sql
REM Description : Table creation for customer Provident fund Account Transfer OUT Maintenance(PPFTRFS_OUT)
Rem Module  	 : PPF
REM###########################################################################################################
drop table CUST_PPF_TRFSOUT_ACCT_DET
/
drop public synonym PPFTRFS_OUT
/
create table CUST_PPF_TRFSOUT_ACCT_DET
(
SOL_ID                                       VARCHAR2(8)  ,
FORACID                                      VARCHAR2(16) ,
LAST_PPF_STATUS                  			 CHAR(1)      ,
PPF_STATUS                                   CHAR(1)      ,
TRANSFER_OUT_DATE                            DATE         ,
TRANSFER_OUT_ACCT_BAL                 		 NUMBER(20,4) ,
DEATH_DATE									 DATE         ,
NATURE_OF_DEATH                              VARCHAR2(40) ,
BENEF_ACCT                                   VARCHAR2(16) ,
ENTITY_CRE_FLG                               CHAR(1)      ,
LCHG_USER_ID                                 VARCHAR2(15) ,
LCHG_TIME                                    DATE         ,
RCRE_USER_ID                                 VARCHAR2(15) ,
RCRE_TIME                                    DATE         ,
DEL_FLG                                      CHAR(1)	  ,	
TRF_REMARKS									 VARCHAR2(68) 
)
/
CREATE INDEX IDX_CUST_PPF_TRFSOUT_ACCT_DET ON 
CUST_PPF_TRFSOUT_ACCT_DET(FORACID) 
/
CREATE unique INDEX UIDX_CUST_PPF_TRFSOUT_ACCT_DET  ON
CUST_PPF_TRFSOUT_ACCT_DET(SOL_ID,FORACID)
/
create public synonym PPFTRFS_OUT for CUST_PPF_TRFSOUT_ACCT_DET
/
grant select,insert,update,delete on PPFTRFS_OUT to tbagen
/
grant select on PPFTRFS_OUT to tbacust
/
grant select on PPFTRFS_OUT to tbautil
/
grant all on PPFTRFS_OUT to tbaadm
/
