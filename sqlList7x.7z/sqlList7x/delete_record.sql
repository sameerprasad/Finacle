---Sql to delete the record for the given School Id
SET SERVEROUTPUT ON SIZE 1000000
set head off echo off verify off feedback off
	Declare
	recpresent	varchar2(5) := 'Y';
	gam_rec		varchar2(5) := 'Y';	
	schlid		varchar2(16) := '&1';
	loc_acctnum gam.foracid%type;
	loc_solid	gam.sol_id%type;

Begin
		Begin
		--{
			Select 'Y' into recpresent
			 from dual
			 where exists(select school_id 	
							from school_acct_mast
			               where school_id = schlid
				             and del_flg <> 'Y');
			Exception
			when no_data_found then
				recpresent := 'N';
		--}
		End;
		if recpresent = 'N' then
			dbms_output.put_line('School id does not exists in the database!');
		else
			dbms_output.put_line('Deleting the data from the school_acct_mast table');
			update school_acct_mast  set del_flg = 'Y' where  school_id = schlid;
			dbms_output.put_line('Record Deleted');
			commit;
		end if;
--}
End;
/
