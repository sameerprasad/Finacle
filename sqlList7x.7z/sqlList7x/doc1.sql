set heading off
set verify off
set feedback off
set line 300
set trims on
set serveroutput on SIZE 1000000
spool &1.fd_doc.lst
--spool fd_doc.lst

DECLARE

l_tenure       	number(6,2);
l_sys_date		date;
l_ins_amt		TAM.deposit_amount%TYPE:=0;
l_month			varchar(4);


CURSOR C1 is 
SELECT  CMG.cust_occp_code, GAM.foracid , GAM.acct_opn_date , maturity_date , CMG.cust_name,
            cust_comu_addr1,cust_comu_addr2,cust_comu_city_code,cust_comu_state_code,
            cust_comu_pin_code ,original_deposit_amount 
FROM GAM,TAM,CMG
WHERE GAM.acid = TAM.acid and GAM.cust_id = CMG.cust_id
AND GAM.schm_code IN ('CFDOC')
AND GAM.acct_opn_date LIKE '%-'||substr('&1',1,2)||'-%'
AND GAM.acct_opn_date <= (SELECT LAST_DAY('15-'||'&1') FROM DUAL) 
AND TAM.maturity_date >= (Select sysdate from DUAL)
--AND CMG.cust_stat_code IN ('GAADA','GAADB','GAADC','GAADD','HNIDA','HNIDB','HNIDC','HNIDD')
AND GAM.del_flg!='Y'
AND GAM.entity_cre_flg='Y'
AND GAM.acct_cls_flg='N';


BEGIN

	Select sysdate into l_sys_date from dual;

	For rec in C1
	LOOP --{

		SELECT trunc(to_date(rec.maturity_date)) - trunc(sysdate) INTO l_tenure FROM DUAL;

		SELECT Round(rec.original_deposit_amount/100000) * 100000 INTO l_ins_amt FROM DUAL;
		

		dbms_output.put_line(rec.cust_occp_code ||'|'||
                    rec.foracid        			||'|'||
                    rec.acct_opn_date     ||'|'||
                    rec.maturity_date  			||'|'||
					l_sys_date					||'|'||
                    rec.cust_name      			||'|'||
                    rec.CUST_COMU_ADDR1 		||'|'||
                    rec.CUST_COMU_ADDR2     	||'|'||
                    rec.CUST_COMU_CITY_CODE     ||'|'||
                    rec.CUST_COMU_STATE_CODE    ||'|'||
                    rec.CUST_COMU_PIN_CODE      ||'|'||
					l_tenure					||'|'||
                    rec.ORIGINAL_DEPOSIT_AMOUNT			||'|'||
					l_ins_amt
                    );
	END LOOP; --}

END;
/
spool off
