--------------------------------------------
--File Name   : Report_Norsurrrpt.sql 
--Description : Normal Surrender Report
--Author      : Priscilla & Vijay
--Date        : 01-06-2010
------------------------------------------

set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_Norsurrrpt.lst

DECLARE

lv_solid         gam.sol_id%type :='&1';
date1		 LCSM.SURRENDER_DATE%type := '&2';
date2            LCSM.SURRENDER_DATE%type := '&3';

CURSOR c1 IS
select lcsm.sol_id,
       LCSM.LOCKER_TYPE,
       WLCKM.RACK_ID,
       LCSM.LOCK_NO,
       LCSM.cust_id,
       substr(LCSM.cust_name,1,40) cust_name,
       CLMT.issue_date,
       CLMT.DUE_DATE,
       substr(LCSM.SURRENDER_DATE,1,10) SURRENDER_DATE
FROM LCSM,CLMT,WLCKM
WHERE LCSM.LOCK_NO  = CLMT.LOCKER_NUM
AND wlckm.LOCKER_NUM = LCSM.LOCK_NO
AND wlckm.LOCKER_NUM = CLMT.LOCKER_NUM
and lcsm.cust_id = clmt.cust_id
and wlckm.sol_id = lcsm.sol_id
and substr(LCSM.SURRENDER_DATE,1,10) between to_date(date1) and to_date(date2)
and wlckm.del_flg!='Y'
and clmt.del_flg!='N'
and LCSM.sol_id = lv_solid
ORDER by 9,4;

BEGIN

    for f1 in c1
    loop
			dbms_output.enable(buffer_size => NULL);
			dbms_output.put_line(
				f1.locker_type    	||'|'||
				f1.rack_id        	||'|'||
				f1.lock_no     		||'|'||
				f1.cust_id          ||'|'|| 
				f1.cust_name      	||'|'||
				f1.issue_date 		||'|'||
				f1.due_date 		||'|'||
				f1.SURRENDER_DATE); 
   end loop; 
END;
/
spool off
