host \rm -f FEETM*lst 2>/dev/null
set pagesize 80
set feedback off
column DC new_value dcalias
select dc_alias DC from gct;
column D new_value dt
define sep = :
select db_stat_date D from gct;
spool feetm1
set head off
set numformat 99,99,99,999.99
set linesize 500
set trims on
set verify off
break on report skip 1
select 'TRAN_ID:AMT:CR_OR_DR:INST_CODE:ROLL NO:CLASS:REF NO:STUDENT NAME:COURSE' from dual;
--compute SUM of AMT on report

select dtd.tran_id, '&sep',
		dtd.tran_amt AMT, '&sep',
		dtd.part_tran_type, '&sep',
		dtd.tran_particular, '&sep',
		' ', '&sep',
		dtd.tran_rmks 
from gam,dtd
where gam.acid=dtd.acid
and dtd.del_flg!='Y'
and gam.foracid in ('0036SLFEECOL','6235SLFEECOL')
and dtd.tran_date='&1'
and VFD_DATE is not null
and dtd.tran_type !='L'
and dtd.tran_id not like 'S%'
UNION
select ctd.tran_id, '&sep',
		ctd.tran_amt AMT, '&sep',
		ctd.part_tran_type, '&sep',
		ctd.tran_particular, '&sep',
		' ' , '&sep',
		ctd.tran_rmks 
from gam,ctd
where gam.acid=ctd.acid
and ctd.del_flg!='Y'
and gam.foracid in ('0036SLFEECOL','6235SLFEECOL')
and ctd.tran_date='&1'
and VFD_DATE is not null
and ctd.tran_type !='L'
and ctd.tran_id not like 'S%'
/
select 'SYSTEM GENERATED TRANSACTIONS' from dual;
select  sum(dtd.tran_amt)
from gam,dtd
where gam.acid=dtd.acid
and dtd.del_flg!='Y'
and gam.foracid in ('0036SLFEECOL','6235SLFEECOL')
and dtd.tran_date='&1'
and VFD_DATE is not null
and dtd.tran_type !='L'
and dtd.tran_id like 'S%'
UNION
select sum(ctd.tran_amt)
from gam,ctd
where gam.acid=ctd.acid
and ctd.del_flg!='Y'
and gam.foracid in ('0036SLFEECOL','6235SLFEECOL')
and ctd.tran_date='&1'
and VFD_DATE is not null
and ctd.tran_type !='L'
and ctd.tran_id like 'S%'
/
spool off
host chmod 777 feetm1.lst
--host sort -t ":" -k 4 feetm1.lst > feetm.lst
host cp feetm1.lst FEETM&dcalias&dt..lst 2>/dev/null
host cp feetm1.lst feetm.lst
host chmod 777 FEETM*.lst
host mailx -s "FEE COLL DETAILS FOR &dcalias &dt " ctu@icicibank.com < FEETM&dcalias&dt..lst 2>/dev/null
host mutt -a FEETM&dcalias&dt..lst -s "FEE COLL TM-DETAILS for &dcalias &dt" ctu@icicibank.com < FEETM&dcalias&dt..lst
