set heading off
set verify off
set feedback off
set line 300
set trims on
set term on
set numformat 99999999999999.99
set serveroutput on SIZE 1000000 format WRAPPED
spool TDS_50K_REP_&1

DECLARE

loc_wtax_flg	GAM.wtax_flg%type;
loc_cust_id		GAM.cust_id%type;
loc_sol_id		GAM.sol_id%type; 
loc_date		date;
loc_sol_desc	SOL.sol_desc%type;
loc_acct_cls_flg	GAM.acct_cls_flg%type;
iCnt			number := 0;
loc_sum_int		number := 0;

CURSOR  tmp_cur IS
SELECT	distinct(cust_id) cust_id
FROM	CUST_TDS50000
WHERE	update_flag = 'N'
AND		sol_id = loc_sol_id;

CURSOR	loc_cur IS
SELECT	tds_cust_id,
		tda_foracid,
		tda_acid,
		round(sum_int_amt + sum_flow_amt) loc_sum,
		acct_cls_flg
FROM	cust_tds50000 
WHERE	cust_id = loc_cust_id
AND		update_flag = 'N'
ORDER BY rcre_time desc;


BEGIN --{

	loc_sol_id := '&1';

	SELECT 	sysdate
	INTO	loc_date
	FROM	dual;

	SELECT	sol_desc
	INTO	loc_sol_desc
	FROM	SOL
	WHERE	sol_id = '&1';

	dbms_output.put_line(' ');
	dbms_output.put_line(lpad('ICICI BANK LIMITED', 40));
	dbms_output.put_line('  SOLID:'||loc_sol_id||'		  '||loc_sol_desc||'				Date:'||loc_date);
	dbms_output.put_line(' ');
	dbms_output.put_line('  List of accounts exceeding Rs 50000/- interest income and with exemption');
	dbms_output.put_line('  -------------------------------------------------------------------------');
	dbms_output.put_line(' ');
	dbms_output.put_line('Please note that in order to make the following accounts taxable you will have to');
	dbms_output.put_line('modify the TAX CATEGORY field in ACM, General Details from "E" to "T". ');
	dbms_output.put_line('-----------------------------------------------------------------------------------');
	dbms_output.put_line(' ');

	dbms_output.put_line('CUSTID    | '||' FORACID     | '||'TDS_CUST_ID | '||'    SUM INT AMT      | '||'CLS_FLG | '||'TAX_FLG');
	dbms_output.put_line('-----------------------------------------------------------------------------------');

	FOR rec in tmp_cur
	LOOP --{

		loc_cust_id := rec.cust_id;

		iCnt := 0;
		FOR	loc_rec in loc_cur
		LOOP --{

			SELECT	wtax_flg,
					acct_cls_flg
			INTO	loc_wtax_flg,
					loc_acct_cls_flg
			FROM	GAM
			WHERE	foracid = loc_rec.tda_foracid;

			if (loc_wtax_flg = 'T') then
				GOTO NEXTREC;
			end if;

			if iCnt = 0 then
			loc_sum_int := loc_rec.loc_sum;
			dbms_output.put_line(	lpad(loc_cust_id, 9)||' | '||
									lpad(loc_rec.tda_foracid, 12)||' | '||
									lpad(nvl(loc_rec.tds_cust_id, '           '), 11)||' | '||
								--	lpad(round((loc_rec.sum_int_amt + loc_rec.sum_flow_amt), 2), 17)||'|'||
									lpad(loc_sum_int, 20)||' | '||
									lpad(loc_acct_cls_flg, 7)||' | '||
									lpad(loc_wtax_flg, 7)
								);
			else
			dbms_output.put_line(	lpad('         ', 9)||' | '||
									lpad(loc_rec.tda_foracid, 12)||' | '||
									lpad(nvl(loc_rec.tds_cust_id, '           '), 11)||' | '||
								--	lpad(round((loc_rec.sum_int_amt + loc_rec.sum_flow_amt), 2), 17)||'|'||
									lpad('                    ', 20)||' | '||
									lpad(loc_acct_cls_flg, 7)||' | '||
									lpad(loc_wtax_flg, 7)
								);
			end if;

			iCnt := 1;

<<NEXTREC>>
			null;

		END LOOP; --}
	END LOOP; --}

	IF (iCnt = 0) THEN
		dbms_output.put_line(' ');
		dbms_output.put_line(lpad('*** No Data Found ***', 30));
		dbms_output.put_line(' ');
	END IF;
	dbms_output.put_line('-----------------------------------------------------------------------------------');
	dbms_output.put_line('');
	dbms_output.put_line('TIPS FOR PROPER TDS COLLECTION');
	dbms_output.put_line('------------------------------');
	dbms_output.put_line('a) Exemption at Customer Level : Use "TDS0" as the table code');
	dbms_output.put_line('b) Exemption at Account Level for "15H" : TDS flag to be set as "E"');
	dbms_output.put_line('c) Exemption at Account Level for "15AA" : TDS flag to be set as "N"');

END; --}
/

spool off;

quit;
