--#########################################################################
--#       File Name       : lcrntsys.sql
--#       Author          : Ashwani Bhat (BBSSL)
--#       Report          : RENT COLLECTED REPORT - System Collection
--#       Date            : 25-02-2010
--#       Module          : LOCKER
--#       Called Menu     : LOCKRPT
--#       Called Scripts  : lcrntsys.com
--#########################################################################

SET SERVEROUTPUT ON SIZE 1000000;
SET VERIFY OFF
SET TERMOUT OFF
SET TRIMSPOOL ON
SET ECHO OFF
SET FEEDBACK OFF
SET EMBEDDED ON
SET LINES 400
SET HEAD OFF
SET PAGES 0
clear columns
clear breaks
clear computes
set serveroutput on

spool lcrntsys.lst

declare

v_sol_id			CLMT.SOL_ID%type;
v_tran_date        	LCPD.TRAN_DATE%type;
v_reck_id        	WLCKM.RACK_ID%type;
v_locker_num        CLMT.LOCKER_NUM%type;
v_lock_type        	WLCKM.LOCKER_TYPE%type;
v_cust_id        	CLMT.CUST_ID%type;
v_tran_id        	LCPD.TRAN_ID%type;
v_paid_amt        	LCPD.PAID_AMOUNT%type;
v_frmperiod        	CLMT.RENEWAL_DATE%type;
v_toperiod        	CLMT.DUE_DATE%type;
v_over_amt        	LCPP.RENT_PAYABLE_AMOUNT%type;
v_cust_name			CMG.CUST_NAME%type;

v_lcknum			VARCHAR2(13);
v_solid				lcpd.sol_id%type;
v_date1				date;
v_date2				date;
v_renewal_date                  date;
v_overDuePrd                    number;

cursor C1 (v_lcknum  lcpd.locker_number%type, v_solid lcpd.sol_id%type, v_date1 date, v_date2 date)  is
SELECT  DISTINCT CLMT.SOL_ID,
        LCPD.TRAN_DATE,
        WLCKM.RACK_ID,
        CLMT.LOCKER_NUM,
        WLCKM.LOCKER_TYPE,
        CLMT.CUST_ID,
        LCPD.TRAN_ID,
        DTD.TRAN_AMT,
	floor(ABS((due_date - decode(renewal_date,'',(due_date+1),renewal_date))/365)) v_overDuePrd,
	(LCPP.RENT_PAYABLE_AMOUNT - LCPP.RENT_PAID_AMOUNT),
        CLMT.renewal_date
FROM    CLMT,LCPD,DTD,WLCKM,LCPP
WHERE   DTD.TRAN_DATE = LCPD.TRAN_DATE
AND     CLMT.LOCKER_NUM = LCPD.LOCKER_NUMBER
AND     LCPP.LOCKER_NUMBER = CLMT.LOCKER_NUM
AND     WLCKM.LOCKER_NUM = CLMT.LOCKER_NUM
AND     LCPD.cust_id = clmt.cust_id
AND     lcpp.cust_id = clmt.cust_id
AND     DTD.TRAN_ID = LPAD(LCPD.TRAN_ID,9,' ')
and clmt.sol_id = lcpd.sol_id
and lcpd.sol_id = DTD.sol_id
and DTD.sol_id = wlckm.sol_id
and wlckm.sol_id = lcpp.sol_id
AND     CLMT.SOL_ID = v_solid
AND     CLMT.LOCKER_NUM like v_lcknum
AND     LCPD.TRAN_DATE BETWEEN to_date(v_date1,'dd-mm-yyyy') AND to_date(v_date2,'dd-mm-yyyy')
AND     ((DTD.PSTD_USER_ID = 'SYSTEM') OR (DTD.VFD_USER_ID = 'SYSTEM'))
AND     CLMT.DEL_FLG != 'Y'
AND     LCPD.DEL_FLG != 'Y'
AND     WLCKM.DEL_FLG != 'Y'
AND     LCPP.DEL_FLG != 'Y'
AND     DTD.PART_TRAN_TYPE = 'D'
UNION all 
SELECT  DISTINCT CLMT.SOL_ID,
        LCPD.TRAN_DATE,
        WLCKM.RACK_ID,
        CLMT.LOCKER_NUM,
        WLCKM.LOCKER_TYPE,
        CLMT.CUST_ID,
        LCPD.TRAN_ID,
        HTD.TRAN_AMT,
	floor(ABS((due_date - decode(renewal_date,'',(due_date+1),renewal_date))/365)) v_overDuePrd,
	(LCPP.RENT_PAYABLE_AMOUNT - LCPP.RENT_PAID_AMOUNT),
        CLMT.renewal_date
FROM    CLMT,LCPD,HTD,WLCKM,LCPP
WHERE   HTD.TRAN_DATE = LCPD.TRAN_DATE
AND     CLMT.LOCKER_NUM = LCPD.LOCKER_NUMBER
AND     LCPP.LOCKER_NUMBER = CLMT.LOCKER_NUM
AND     WLCKM.LOCKER_NUM = CLMT.LOCKER_NUM
AND     LCPD.cust_id = clmt.cust_id
AND     lcpp.cust_id = clmt.cust_id
AND     HTD.TRAN_ID = LPAD(LCPD.TRAN_ID,9,' ')
and clmt.sol_id = lcpd.sol_id
and lcpd.sol_id = HTD.sol_id
and HTD.sol_id = wlckm.sol_id
and wlckm.sol_id = lcpp.sol_id
AND     CLMT.SOL_ID = v_solid
AND     CLMT.LOCKER_NUM like v_lcknum
AND     LCPD.TRAN_DATE BETWEEN to_date(v_date1,'dd-mm-yyyy') AND to_date(v_date2,'dd-mm-yyyy')
AND     ((HTD.PSTD_USER_ID = 'SYSTEM') OR (HTD.VFD_USER_ID = 'SYSTEM'))
AND     CLMT.DEL_FLG != 'Y'
AND     LCPD.DEL_FLG != 'Y'
AND     WLCKM.DEL_FLG != 'Y'
AND     LCPP.DEL_FLG != 'Y'
AND     HTD.PART_TRAN_TYPE = 'D'
ORDER   BY 4,7;

BEGIN
	v_lcknum := '&1';
    --dbms_output.put_line(v_lcknum);
	select nvl2(v_lcknum, '%'||v_lcknum, '%') into v_lcknum from dual;
	v_solid  := '&2';
	v_date1  := '&3';
	v_date2  := '&4';
        
	OPEN C1(v_lcknum,v_solid,v_date1,v_date2);
	loop
	--{
		if (C1%ISOPEN) then
		--{
		FETCH C1
		INTO
			v_sol_id,
			v_tran_date,
			v_reck_id,
			v_locker_num,
			v_lock_type,
			v_cust_id,
			v_tran_id,
			v_paid_amt,
			v_overDuePrd,
                        v_over_amt,
                        v_renewal_date;
			
			 IF (C1%NOTFOUND) THEN
				CLOSE C1;
				EXIT;
			END IF;
			BEGIN
                        --{
                                --To Arrive From Period
                                IF (v_overDuePrd > 0) THEN
                                --{
                                        BEGIN
                                        --{
                                                select add_months(v_renewal_date,(-12 * v_overDuePrd))
                                                INTO v_frmperiod
                                                FROM dual;
                                                Exception when no_data_found then
                                                        v_frmperiod := null;
                                        --}
                                        END;
                                --}
                                ELSIF(v_overDuePrd = 0) THEN
                                --{
                                        BEGIN
                                        --{
                                                select add_months(v_renewal_date,-12)
                                                INTO v_frmperiod
                                                FROM dual;
                                                Exception when no_data_found then
                                                        v_frmperiod := null;
                                        --}
                                        END;
                                --}
                                END IF;
                        --}
                        END;

	
                        BEGIN
                        --{
                                --To Arrive To Period
				IF (v_overDuePrd > 0) THEN
				--{
					BEGIN
					--{
						select (add_months(v_frmperiod,(12 * v_overDuePrd)) - 1)
						INTO v_toperiod
						FROM dual;
						Exception when no_data_found then
							v_toperiod := null;
					--}
					END;
				--}
				ELSIF(v_overDuePrd = 0) THEN
				--{
					BEGIN
					--{
						select (add_months(v_frmperiod,12) - 1)
						INTO v_toperiod
						FROM dual;
						Exception when no_data_found then
							v_toperiod := null;
					--}
					END;
				--}
				END IF;
                        --}
                        END;
			begin
                                select cust_name into v_cust_name from cmg where cust_id = lpad(v_cust_id,9,' ');
			Exception when no_data_found then
                                v_cust_name:=null;
                        end;

			IF(v_over_amt <= 0) THEN
			--{
				v_over_amt := 0;
			--}
			END IF;
		--}
		end if;

dbms_output.enable(buffer_size => NULL);
dbms_output.put_line(v_sol_id       	||'|'||
                        v_tran_date   	||'|'||
                        v_reck_id       ||'|'||
                        v_locker_num   	||'|'||
                        v_lock_type     ||'|'||
						v_cust_id		||'|'||
                        v_cust_name     ||'|'||
                        v_tran_id       ||'|'||	
                        v_paid_amt      ||'|'||
                        v_frmperiod     ||'|'||
                        v_toperiod      ||'|'||
                        v_over_amt);
end loop;
	--}
end;
/
spool off
