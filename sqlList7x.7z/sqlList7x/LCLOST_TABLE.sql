Rem     This file will create LOCKER_KEY_LOST_MAINTENENCE Table
Rem     with the following characteristics.

Rem     Coded by : Saravanan Sekar (BBSSL)

Rem     Module  : LOCKER


Rem TABLE NAME: LOCKER_KEY_LOST_MAINTENENCE

Rem SYNONYM:    LCLOST

drop table icici.LOCKER_KEY_LOST_MAINTENENCE
/
drop public synonym LCLOST
/
create table icici.LOCKER_KEY_LOST_MAINTENENCE
(
SOL_ID		VARCHAR2(8),
LOCKER_NUM	VARCHAR2(12),
KEY_NUM		VARCHAR2(8),
LOST_DATE	VARCHAR2(25),
LOST_TIME	VARCHAR2(25),
LOST_REASON	VARCHAR2(80),
INFORMED_BY	VARCHAR2(50),
OLD_STATUS	CHAR(1),
DEL_FLG		CHAR(1),
ENTITY_CRE_FLG  CHAR(1),
LCHG_USER_ID    VARCHAR2(15),
LCHG_TIME       DATE,
RCRE_USER_ID    VARCHAR2(15),
RCRE_TIME       DATE,
CUST_ID		VARCHAR2(9)
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
create public synonym LCLOST for icici.LOCKER_KEY_LOST_MAINTENENCE
/
grant select, insert, update, delete on LCLOST to tbagen,tbaadm
/
grant select on LCLOST to tbacust
/
grant select on LCLOST to tbautil
/
