set pagesize 80
set feedback on
set numformat 99,99,99,999.99
column DC new_value dcalias
select dc_alias DC from gct;
column D new_value dt
define sep = :
select db_stat_date D from gct;
set head off
set linesize 500
set trims on
set verify off
break on report skip 1
select 'ZONE_DATE:TRAN_DATE:ZONE_CODE:SOL_ID:TRAN_ID:AMT:DR_OR_CR:INST_CODE:ROLL:CLASS:REF_NUM:STUDENT NAME:COURSE' from dual;
spool feecl1
select 
ocp.clg_zone_date,'&sep',
ocp.tran_date,'&sep',
ocp.clg_zone_code,'&sep',
ocp.sol_id,'&sep',
ocp.tran_id, '&sep',
ocp.tran_amt AMT, '&sep',
oci.instrmnt_amt AMT, '&sep',
ocp.part_tran_type, '&sep',
ocp.partcls, '&sep',
' ', '&sep',
ocp.tran_rmks, '&sep',
oci.instrmnt_id, '&sep', 
oci.bank_code, '&sep',  
nvl(substr(bkc.bank_name,1,35),'     ')bank_name, '&sep',  
bct.br_name
from gam,ocp,ott, oci, bct,bkc
where gam.acid=ocp.acid
and ott.acid=ocp.acid
and ocp.del_flg!='Y'
and gam.foracid in ('0036SLFEECOL','6235SLFEECOL')
and ocp.clg_zone_date between '&1'  and '&2'
--and ocp.clg_zone_code in ('FM','FU')
and ocp.status_flg='G'
and shd_bal_rem_amt=0
and ocp.tran_id=ott.tran_id
and ocp.tran_date=ott.tran_date
and ocp.part_tran_srl_num=ott.part_tran_srl_num
and ott.del_flg!='Y'
and ott.org_tran_amt<>ott.total_offset_amt
and oci.sol_id = ocp.sol_id
and oci.clg_zone_date = ocp.clg_zone_date  
and oci.clg_zone_code = ocp.clg_zone_code
and oci.set_num = ocp.set_num
and oci.bank_code = bct.bank_code 
and oci.br_code = bct.br_code 
and trim(oci.bank_code) = bkc.bank_code(+) 
/
spool off
host chmod 777 feecl1.lst
--host sort -t ":" -k 4 feecl1.lst > feeclnew1.lst
--host chmod 777 feecl2.lst
--host sort -t ":" -k 4 feecl2.lst > feeclnew2.lst
--host cat feeclnew2.lst >> feeclnew1.lst
--host cat feecl2.lst >> feecl1.lst
--host cp feeclnew1.lst feecl.lst
host cp feecl1.lst feeclrange.lst
host cp feecl1.lst FEECLR&dcalias&dt..lst 2>/dev/null
host chmod 777 FEECL*.lst
host fsgMutt -a FEECLR&dcalias&dt..lst -s "Fee Coll CLG-Range for &dcalias " feecollection@icicibank.com < /dev/null
host mutt -a FEECLR&dcalias&dt..lst -s "Fee Coll CLG-Range for &dcalias " feecollection@icicibank.com < /dev/null
host fsgMutt -a FEECLR&dcalias&dt..lst -s "Fee Coll CLG-Range for &dcalias " ctu@icicibank.com < /dev/null
host mutt -a FEECLR&dcalias&dt..lst -s "Fee Coll CLG-Range for &dcalias " ctu@icicibank.com < /dev/null
