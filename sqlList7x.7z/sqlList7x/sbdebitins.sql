spool sbdebitins.log
insert into oat values ('SBDEBIT','GU','SYSTEM',sysdate,'SYSTEM',sysdate);
insert into mod values ('SBDEBIT','G','sbdr.com','','','C','76','000','','161','999','','FT','BT','FT','CO','','','','','','','','M','N','','','','','C','SYSTEM','SYSTEM',sysdate,sysdate);
insert into mod_txt values ('SBDEBIT','INFENG','SBDEBIT','SB DEBIT RUN  ','','SYSTEM','SYSTEM',sysdate,sysdate);
commit;
spool off
