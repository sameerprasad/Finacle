set numf 9999999999.99
set feedback off
set pagesize 500
ttitle " LIST OF FFD's OPEN WITH AUTO RENEWAL AND AUTO CLOSURE AS NO"

drop view tmp_ffd_tam
/

create view  tmp_ffd_tam as
select ffl.ffd_acid, gam.foracid , gam.acct_name ,
       ffl.acid,
       tam.maturity_amount
       from tam,ffl,gam  where
       tam.acid=ffl.ffd_acid and
       gam.acid=tam.acid and 
       gam.acct_cls_flg !='Y' and 
       tam.auto_renewal_flg='N' and 
       tam.close_on_maturity_flg='N' ;

clear buffer  
/
spool ffdopen.lst
/
select tmp_ffd_tam.foracid "TD ACCT ",
       gam.foracid    "OP ACCT",
       tmp_ffd_tam.maturity_amount " MAT AMT",
       tmp_ffd_tam.acct_name "ACCT NAME "
       from tmp_ffd_tam,gam 
       where gam.acid = tmp_ffd_tam.acid ;
spool off
/
drop view tmp_ffd_tam
/
exit
/

