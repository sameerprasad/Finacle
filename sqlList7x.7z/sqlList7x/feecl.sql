host \rm -f FEECL*lst 2>/dev/null
set pagesize 80
set feedback on
set numformat 99,99,99,999.99
column DC new_value dcalias
select dc_alias DC from gct;
column D new_value dt
define sep = :
select db_stat_date D from gct;
set head off
set linesize 500
set trims on
set verify off
break on report skip 1
--compute sum of AMT on report
select 'TRAN_ID:AMT:DR_OR_CR:INST_CODE:ROLL:CLASS:REF_NUM:STUDENT NAME:COURSE:CAPTURE MODE' from dual;
spool feecl1
select ocp.sol_id,'&sep',
ocp.tran_id, '&sep',
ocp.tran_amt AMT, '&sep',
ocp.part_tran_type, '&sep',
ocp.partcls, '&sep',
' ', '&sep',
ocp.tran_rmks, '&sep',
'MANUAL' from gam,ocp
where gam.acid=ocp.acid
and ocp.del_flg!='Y'
and gam.foracid in ('0036SLFEECOL','6235SLFEECOL')
and ocp.clg_zone_date='&1'
and ocp.clg_zone_code='FM'
and status_flg='G'
and shd_bal_rem_amt=0
/
spool off
host chmod 777 feecl1.lst
--host sort -t ":" -k 4 feecl1.lst > feeclnew1.lst
spool feecl2
select ocp.sol_id,'&sep',
ocp.tran_id, '&sep',
ocp.tran_amt AMT, '&sep',
ocp.part_tran_type, '&sep',
ocp.partcls, '&sep',
' ', '&sep',
ocp.tran_rmks, '&sep',
'UPLOAD' from gam,ocp
where gam.acid=ocp.acid
and ocp.del_flg!='Y'
and gam.foracid in ('0036SLFEECOL','6235SLFEECOL')
and ocp.clg_zone_date='&1'
and ocp.clg_zone_code='FU'
and status_flg='G'
and shd_bal_rem_amt=0
/
spool off
host chmod 777 feecl2.lst
--host sort -t ":" -k 4 feecl2.lst > feeclnew2.lst
--host cat feeclnew2.lst >> feeclnew1.lst
host cat feecl2.lst >> feecl1.lst
--host cp feeclnew1.lst feecl.lst
host cp feecl1.lst feecl.lst
host cp feecl.lst FEECL&dcalias&dt..lst 2>/dev/null
host chmod 777 FEECL*.lst
host mailx -s "FEE COLL DETAILS (CLG) FOR &dcalias &dt " ctu@icicibank.com < FEECL&dcalias&dt..lst 2>/dev/null
host mutt -a FEECL&dcalias&dt..lst -s "FEE COLL CLG-DETAILS for &dcalias run on &dt" ctu@icicibank.com < FEECL&dcalias&dt..lst
