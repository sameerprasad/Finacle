set serveroutput on size 1000000
set feedback off
set verify off
set linesize 500
set trims on
rem accept solid prompt "Enter Sol_id    "
rem accept frdate prompt "Enter From Date (DD-MM-YYYY)  "
rem accept todate prompt "Enter To date   (DD-MM-YYYY)  "
spool nom_cons
DECLARE
nom_reg_num                         icici_cndh.nom_reg_num%TYPE;
cust_id                             icici_cndh.cust_id%TYPE;
nom_name                            icici_cndh.nom_name%TYPE;
nom_reltn_code                      icici_cndh.nom_reltn_code%TYPE;
nom_date_of_birth                   icici_cndh.nom_date_of_birth%TYPE;
cust_name                           cmg.cust_name%TYPE;
cst_id                              icici_cift.cust_id%TYPE;
reltn_desc                          rct.ref_desc%TYPE;
rcre_time                           ICICI_CNDH.rcre_time%TYPE;
rcr_time                            ICICI_CNDT.rcre_time%TYPE;
lchg_time                           ICICI_CNDH.lchg_time%TYPE;
today                               varchar2(15);
flg									number(1);
error								varchar2(100);
sol_id                               icici_cift.home_sol_id%TYPE;
sol_nm                              sol.sol_desc%TYPE;
CURSOR nom_cndh IS SELECT 				cust_id,nom_reg_num,nom_name,
                                        nom_reltn_code,nom_date_of_birth,
                                        nom_minor_flg,lchg_time
					 FROM ICICI_CNDH 
                     where lchg_time between to_date('&2','dd-mm-yyyy') 
                      and to_date('&3','dd-mm-yyyy')+1 ;

BEGIN --{
--fmode := 'w';
        begin
           select sol_id,sol_desc into sol_id,sol_nm from sol where sol_id = '&1';
			EXCEPTION
				WHEN OTHERS THEN
                    flg:=1;
	                goto avr1;	
        end;
        begin
            select to_char(sysdate,'DD-MM-YYYY') into today from dual;
        end;
        dbms_output.put_line('00000'||'|'||sol_id||'|'||sol_nm||'|'||'C'||'|'||'&2'||'|'||'&3'||'|'||' '||'|'||' '||'|'||' ');
	FOR nom_cndh_rec in nom_cndh 
	LOOP --{
            flg:=0;
        BEGIN
			SELECT  ref_desc    
			INTO 	reltn_desc 
			FROM 	RCT 
            WHERE   ref_rec_type='04' 
            AND ref_code = nom_cndh_rec.nom_reltn_code;
			EXCEPTION
				WHEN OTHERS THEN
                    flg:=1;
                    error:='Relation ship Code not found';
	                goto avr;	
        END;
		BEGIN
			SELECT 	home_sol_id
            INTO    sol_id
			FROM    icici_cift
			WHERE cust_id  = nom_cndh_rec.cust_id;

			EXCEPTION
				WHEN OTHERS THEN
                    flg:=1;
                    error:='Customer Record not found in cift';
	                goto avr;	
		END;
        begin
			SELECT 	cust_name
            INTO    cust_name
			FROM    cmg
			WHERE cust_id  = nom_cndh_rec.cust_id;

			EXCEPTION
				WHEN OTHERS THEN
                    flg:=1;
                    error:='Customer record not found in cmg';
	                goto avr;	
         END;
         begin
            SELECT  rcre_time
            INTO    rcr_time
            FROM    icici_cndt
            WHERE cust_id  = nom_cndh_rec.cust_id;

            EXCEPTION
                WHEN OTHERS THEN
                    flg:=1;
                    error:='Customer record not found in cndt';
                    goto avr;
         END;
if(sol_id = '&1') then
   flg:=0;
else
   flg:=1;
end if;
<<avr>>
IF (flg <> 1) THEN
		dbms_output.put_line(to_char(nom_cndh_rec.lchg_time,'YYYYMMDD')||'|'||nom_cndh_rec.lchg_time||'|'||rpad(nom_cndh_rec.nom_reg_num,10,' ')||'|'||rpad(nom_cndh_rec.cust_id,10)||'|'||rpad(cust_name,40)||'|'||rpad(nom_cndh_rec.nom_name,40)||'|'||rpad(reltn_desc,15)||'|'||nom_cndh_rec.nom_date_of_birth||'|'||rcr_time);
END IF ;
flg:=0;
END LOOP; 
<<avr1>>
flg:=0;
END;  
/
spool off
quit
