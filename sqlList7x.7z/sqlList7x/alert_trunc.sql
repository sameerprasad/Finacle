-- truncates alert info table
--
set echo on
spool icici_alert_trunc
--
create table icici.icici_alert_info_temp TABLESPACE ICICI_CUST_SMALL
as (select * from icici.icici_alert_info_tbl where proc_flg = 'N')
/
--
truncate table ICICI.ICICI_ALERT_INFO_TBL
/
--
insert into ICICI.icici_alert_info_tbl (select * from icici.icici_alert_info_temp)
/
--
drop table icici.icici_alert_info_temp
/
--
spool off
