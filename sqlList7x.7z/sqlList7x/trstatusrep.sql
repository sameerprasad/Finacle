set serveroutput on size 1000000
set feedback off
set verify off
set linesize 500
set pages 0
set trims on
set termout off
set numformat 999D09
spool &3
select sol_id,decode(tax_type,'C','CBDT','CBEC'),DECODE(tax_tran_type,'C','Cash','T','Transfer','Clearing'),decode(tax_verify,'E','Pending','Verify'),count(*) from icici_gbm_trn_hdr where tax_tran_date='&1'  and sol_id ='&2' group by sol_id,tax_type,tax_tran_type,tax_verify
/
spool off
