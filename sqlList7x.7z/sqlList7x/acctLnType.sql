-- #############################################################
-- #	Source Name: acctLnType.sql				   		       #
-- #	Description: This script is used to get the required   #
-- #				 details for ROD accounts                  # 
-- #				 in ~ seperated format.                    #
-- #############################################################

Set ServerOutPut On Size 1000000
--Set Verify Off
--Set FeedBack off
--set line 80
set trims on

--Spool acctLnType.txt

DECLARE

inpDate				varchar2(25);

-- Temporary variables.
actype				UTL_FILE.FILE_TYPE;
lnclass				UTL_FILE.FILE_TYPE;
schmCode			GSP.schm_code%type;
schmDesc			GSP.schm_desc%type;
acCrncy				GAM.acct_crncy_code%type;
accttype			number := 999;
class				number := 0;
crncy				number(1) := 1;
cyclecode   		varchar2(2) := '00';
det_line1			varchar2(1000) := '';
det_line2			varchar2(1000) := '';

CURSOR 	RSP_CURSOR IS 
	SELECT 	schm_code,acct_crncy_code
	FROM 	gam,gac
	WHERE 	gam.acid = gac.acid
	AND		gam.schm_code in (	select 	distinct schm_code 
								from 	RSP 
								where 	entity_cre_flg = 'Y'
								and 	del_flg != 'Y')
	AND		gac.dpd_cntr >= 1
	AND		gam.entity_cre_flg = 'Y'
	AND		gam.del_flg != 'Y';


BEGIN
--{
	actype		:= UTL_FILE.FOPEN('/tmp','ex_accttype.csv','w');
	lnclass		:= UTL_FILE.FOPEN('/tmp','ex_lnclass.csv','w');

	OPEN RSP_CURSOR;

	LOOP
	--{
		schmCode := NULL;
		acCrncy := NULL;
		schmDesc := '-';
	
		FETCH RSP_CURSOR into schmCode,acCrncy;

		EXIT WHEN RSP_CURSOR%NOTFOUND;
		
		IF (schmCode is NOT NULL) THEN
		--{	
			BEGIN
			--{
				SELECT 	nvl(schm_desc,'-')
				INTO	schmDesc
				FROM 	GSP
				WHERE	schm_code = schmCode
				AND		del_flg != 'Y';

			EXCEPTION
				WHEN OTHERS THEN schmDesc := '-';
			--}
			END;

--	Schm code changed to HMOAD ... onsite 
			if (schmCode = 'HMOAD') then
				class := 1;
			elsif (schmCode = 'CAROD') then
				class := 2;
			elsif (schmCode = 'REVOD') then
				class := 3;
			elsif (schmCode = 'RVOD1') then
				class := 4;
			elsif (schmCode = 'REVEI') then 
				class := 5;
			else
				class := 6;
			end if;
			
			if (acCrncy = 'INR') then
				crncy := 1;
			elsif (acCrncy = 'USD') then
				crncy := 2;
			elsif (acCrncy = 'GBP') then
				crncy := 3;
			elsif (acCrncy = 'DEM') then
				crncy := 4;
			end if;
			
			det_line1 := accttype||'~'||'LN~OD~REVOLVING OD~1~0';
			UTL_FILE.PUT_LINE(actype,det_line1);

			det_line2 := accttype||'~'||class||'~'||schmDesc||'~'||crncy||'~5~1';
			UTL_FILE.PUT_LINE(lnclass,det_line2);
		--}
		END IF;
	--}
	END LOOP;

	UTL_FILE.FCLOSE(actype);
	UTL_FILE.FCLOSE(lnclass);
	CLOSE RSP_CURSOR;
--}
END;
/
--exit
--spool off
