-- ============================================================================================*
--  Source Name         :   modrpt_menu.sql
--  Title               :   Module for mod Reports Generation
--  Author              :   Sandeep
--  Date                :   25-May-2008
--  Description         :   sql file for Creating Menu option for MODRPT
--  Copyright           :   Copyright (C) 2006 ICICI BANK (DE) Ltd
--  <serial No>     <Date>          <Author Name>           <Description>
--  0.00a           26-May-2008    Sandeep Sharma     Original Code
-- ============================================================================================*
--Creating the Menu Option 'MODRPT'

--Login to Oracle as system user and run this sql file

delete from mod_txt where mop_id='MODRPT';
delete from oat where  mop_id='MODRPT';
delete from mod where  mop_id='MODRPT';

drop table tmp_mod;

create table tmp_mod as (select * from mod where mop_id = 'TM');

update tmp_mod set mop_id = 'MODRPT', input_filename = 'modrpt_mn001.scr',exe_name = ' ',mop_type='W';

delete from mod where MOP_ID='MODRPT';

insert into mod select * from tmp_mod;

drop table tmp_mod;

create table tmp_mod as (select * from mod_txt where mop_id = 'TM');
update tmp_mod set mop_id = 'MODRPT' , user_mop_id = 'MODRPT', mop_text = 'MOD Report Printing';

delete from mod_txt where MOP_ID='MODRPT';
insert into mod_txt select * from tmp_mod;

drop table tmp_mod;

delete from oat where MOP_ID='MODRPT';
insert into oat values('MODRPT','GU','TBAADM',sysdate,'TBAADM',sysdate,'0' );

commit;

