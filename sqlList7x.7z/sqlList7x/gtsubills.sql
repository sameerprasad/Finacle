---alter session set optimizer_goal = RULE;
set pages 0
set lines 98
set feedback on
set termout on
set verify off
spool &2
select sol_id||'|'||
       lodg_date||'|'||
       bill_id||'|'||
       reg_type||'|'||
       bill_stat||'|'||
       entity_cre_flg||'|'||
       VERIFN_IND||'|'
--       cls_flg||'|'||
--       del_flg
from   fbm
where  sol_id||NULL between '0001' and '7000'
and    lodg_date between  to_date('&1')-60 and '&1'
and    reg_type||NULL in ('FOBP','FOBC','ABLC','FDIC','FIBC','FSALE','FOCC','FBPF')
and    (VERIFN_IND in ('U',' ') or VERIFN_IND is NULL)
and    del_flg != 'Y'
/
select sol_id||'|'||
       lodg_date||'|'||
       bill_id||'|'||
       reg_type||'|'||
       bill_stat||'|'||
       entity_cre_flg||'|'||
       EFF_VERIFN_IND||'|'
--       cls_flg||'|'||
--       del_flg
from   blt 
where  sol_id||NULL between '0001' and '7000'
and    lodg_date between  to_date('&1')-60 and '&1'
and    reg_type in ('OBD','OBC','IBC','OBP')
and    (EFF_VERIFN_IND in ('U',' ') or EFF_VERIFN_IND is NULL)
and    del_flg !='Y'
/
spool off
