set serveroutput on size 1000000
set lines 2000
set feedback off
set trims on
set pages 0
set echo off
set verify off
set head off
spool subRptcashm.lst


declare
	
loc_soId CBRREP.sol_id%TYPE;
loc_tranDate CBRREP.TRAN_DATE%TYPE;
loc_procAmt CBRREP.PROC_AMT%TYPE;
loc_procForacid CBRREP.PROCFORACID%TYPE;
loc_unprocForacid CBRREP.UNPROCFORACID%TYPE;
samutcur_foracid CBRREP.UNPROCFORACID%TYPE;
loc_pcountRs1000 CBRREP.PCOUNTRS1000%TYPE;
loc_pcountRs500 CBRREP.PCOUNTRS500%TYPE;
loc_pcountRs100 CBRREP.PCOUNTRS100%TYPE;
loc_pcountRs50 CBRREP.PCOUNTRS50%TYPE;
loc_pcountRs20 CBRREP.PCOUNTRS20%TYPE;
loc_pcountRs10 CBRREP.PCOUNTRS10%TYPE;
loc_pcountRs5 CBRREP.PCOUNTRS5%TYPE;
loc_pcountRs2 CBRREP.PCOUNTRS2%TYPE;
loc_pcountRs1 CBRREP.PCOUNTRS1%TYPE;
loc_pcountcRs10 CBRREP.PCOUNTCRS10%TYPE;
loc_pcountcRs5 CBRREP.PCOUNTCRS5%TYPE;
loc_pcountcRs2 CBRREP.PCOUNTCRS2%TYPE;
loc_pcountcRs1 CBRREP.PCOUNTCRS1%TYPE;
loc_pcountcPs50 CBRREP.PCOUNT50PS%TYPE;
loc_pcountcPs25 CBRREP.PCOUNT25PS%TYPE;
loc_upcountRs1000 CBRREP.UCOUNTRS1000%TYPE;
loc_upcountRs500 CBRREP.UCOUNTRS500%TYPE;
loc_upcountRs100 CBRREP.UCOUNTRS100%TYPE;
loc_upcountRs50 CBRREP.UCOUNTRS50%TYPE;
loc_upcountRs20 CBRREP.UCOUNTRS20%TYPE;
loc_upcountRs10 CBRREP.UCOUNTRS10%TYPE;
loc_upcountRs5 CBRREP.UCOUNTRS5%TYPE;
loc_upcountRs2 CBRREP.UCOUNTRS2%TYPE;
loc_upcountRs1 CBRREP.UCOUNTRS1%TYPE;
loc_upcountcRs10 CBRREP.UCOUNTCRS10%TYPE;
loc_upcountcRs5 CBRREP.UCOUNTCRS5%TYPE;
loc_upcountcRs2 CBRREP.UCOUNTCRS2%TYPE;
loc_upcountcRs1 CBRREP.UCOUNTCRS1%TYPE;
loc_upcountcPs50 CBRREP.UCOUNT50PS%TYPE;
loc_upcountcPs25 CBRREP.UCOUNT25PS%TYPE;
loc_unprocAmt CBRREP.UNPROC_AMT%TYPE;
loc_lchgtime CBRREP.LCHG_TIME%TYPE;
loc_totAmt CBRREP.PROC_AMT%TYPE;
sum_cash_gl_acct CBRREP.PROC_AMT%TYPE;
phy_cash_in_branch CBRREP.PROC_AMT%TYPE;
bal_in_samutcur CBRREP.PROC_AMT%TYPE;
counter integer:=1;
shift integer:='&5';
loc_runBalRs1000 integer := 0;
loc_runBalRs500 integer := 0;
loc_runBalRs100 integer := 0;
loc_runBalRs50 integer := 0;
loc_runBalRs20 integer := 0;
loc_runBalRs10 integer := 0;
loc_runBalRs5 integer := 0;
loc_runBalRs2 integer := 0;
loc_runBalRs1 integer := 0;
loc_runBalC10 integer := 0;
loc_runBalC5 integer := 0;
loc_runBalC2 integer := 0;
loc_runBalC1 integer := 0;
loc_runBalC50 integer := 0;
loc_runBalC25 integer := 0;
	
loc_runProcNRs1000 integer := 0;
loc_runProcNRs500 integer := 0;
loc_runProcNRs100 integer := 0;
loc_runProcNRs50 integer := 0;
loc_runProcNRs20 integer := 0;
loc_runProcNRs10 integer := 0;
loc_runProcNRs5 integer := 0;
loc_runProcNRs2 integer := 0;
loc_runProcNRs1 integer := 0;
loc_runProcCRs10 integer := 0;
loc_runProcCRs5 integer := 0;
loc_runProcCRs2 integer := 0;
loc_runProcCRs1 integer := 0;
loc_runProcCPs50 integer := 0;
loc_runProcCPs25 integer := 0;
loc_runUnProcNRs1000 integer := 0;
loc_runUnProcNRs500 integer := 0;
loc_runUnProcNRs100 integer := 0;
loc_runUnProcNRs50 integer := 0;
loc_runUnProcNRs20 integer := 0;
loc_runUnProcNRs10 integer := 0;
loc_runUnProcNRs5 integer := 0;
loc_runUnProcNRs2 integer := 0;
loc_runUnProcNRs1 integer := 0;
loc_runUnProcCRs10 integer := 0;
loc_runUnProcCRs5 integer := 0;
loc_runUnProcCRs2 integer := 0;
loc_runUnProcCRs1 integer := 0;
loc_runUnProcCPs50 integer := 0;
loc_runUnProcCPs25 integer := 0;

cursor cursor1 is 
select
TRAN_IDENTIFIER,
SOL_ID,
TRAN_AMT,
TRAN_DATE,
FROM_FORACID,
TO_FORACID,
COUNTRS1000,
COUNTRS500,
COUNTRS100,
COUNTRS50,
COUNTRS20,
COUNTRS10,
COUNTRS5,
COUNTRS2,      
COUNTRS1,
COUNTCRS10,
COUNTCRS5,
COUNTCRS2,
COUNTCRS1,
COUNT50PS,
COUNT25PS,
LCHG_USER_ID,
LCHG_TIME,
RCRE_USER_ID,
RCRE_TIME,
TS_CNT
from ICI_DENOM
where SOL_ID in ( select sol_id from sst where sol_id = '&1')
and TRAN_DATE = '&2'  and (FROM_FORACID  IN ('&3','&4') OR TO_FORACID IN ('&3','&4'))
order by lchg_time;

cursor cursor2 is
select 
FORACID,
CLR_BAL_AMT,
ACCT_CRNCY_CODE 
from GAM 
where gl_sub_head_code ='51010' 
and sol_id='&1';


BEGIN
BEGIN

if(shift = 1) then
		select LCHG_TIME,SOL_ID,TRAN_DATE,PROC_AMT,PROCFORACID,UNPROCFORACID,PCOUNTRS1000,PCOUNTRS500,PCOUNTRS100,PCOUNTRS50,PCOUNTRS20,PCOUNTRS10,PCOUNTRS5,PCOUNTRS2,PCOUNTRS1,PCOUNTCRS10,PCOUNTCRS5,PCOUNTCRS2,PCOUNTCRS1,PCOUNT50PS,PCOUNT25PS,UCOUNTRS1000,UCOUNTRS500,UCOUNTRS100,UCOUNTRS50,UCOUNTRS20,UCOUNTRS10,UCOUNTRS5,UCOUNTRS2,UCOUNTRS1,UCOUNTCRS10,UCOUNTCRS5,UCOUNTCRS2,UCOUNTCRS1,UCOUNT50PS,UCOUNT25PS,UNPROC_AMT into  loc_lchgtime,loc_soId,loc_tranDate,loc_procAmt,loc_procForacid,loc_unprocForacid,loc_pcountRs1000,loc_pcountRs500,loc_pcountRs100,loc_pcountRs50,loc_pcountRs20,loc_pcountRs10,loc_pcountRs5,loc_pcountRs2,loc_pcountRs1,loc_pcountcRs10,loc_pcountcRs5,loc_pcountcRs2,loc_pcountcRs1,loc_pcountcPs50,loc_pcountcPs25,loc_upcountRs1000,loc_upcountRs500,loc_upcountRs100,loc_upcountRs50,loc_upcountRs20,loc_upcountRs10,loc_upcountRs5,loc_upcountRs2,loc_upcountRs1,loc_upcountcRs10,loc_upcountcRs5,loc_upcountcRs2,loc_upcountcRs1,loc_upcountcPs50,loc_upcountcPs25,loc_unprocAmt from CBRREP where SOL_ID in ( select sol_id from sst where sol_id = '&1') and TRAN_DATE = '&2' and shift = 1;

		
		dbms_output.put_line(to_char(loc_lchgtime,'DD-MM-YYYY:HH:MM:SS')||'|'||
			'AA'||'|'||
			'A'||'|'||
			loc_soId||'|'||
			loc_procAmt||'|'||
                        loc_tranDate||'|'||
                        loc_procForacid||'|'||
                        loc_unprocForacid||'|'||
                        loc_pcountRs1000||'|'||
                        loc_pcountRs500||'|'||
                        loc_pcountRs100||'|'||
                        loc_pcountRs50||'|'||
                        loc_pcountRs20||'|'||
                        loc_pcountRs10||'|'||
                        loc_pcountRs5||'|'||
                        loc_pcountRs2||'|'||
                        loc_pcountRs1||'|'||
                        loc_pcountcRs10||'|'||
                        loc_pcountcRs5||'|'||
                        loc_pcountcRs2||'|'||
                        loc_pcountcRs1||'|'||
                        loc_pcountcPs50||'|'||
                        loc_pcountcPs25);

                dbms_output.put_line(to_char(loc_lchgtime,'DD-MM-YYYY:HH:MM:SS')||'|'||'AB'||'|'||'A'||'|'||loc_soId||'|'||
			loc_unprocAmt||'|'||
                        loc_tranDate||'|'||
                        loc_procForacid||'|'||
                        loc_unprocForacid||'|'||
                        loc_upcountRs1000||'|'||
                        loc_upcountRs500||'|'||
                        loc_upcountRs100||'|'||
                        loc_upcountRs50||'|'||
                        loc_upcountRs20||'|'||
                        loc_upcountRs10||'|'||
                        loc_upcountRs5||'|'||
                        loc_upcountRs2||'|'||
                        loc_upcountRs1||'|'||
                        loc_upcountcRs10||'|'||
                        loc_upcountcRs5||'|'||
                        loc_upcountcRs2||'|'||
                        loc_upcountcRs1||'|'||
                        loc_upcountcPs50||'|'||
                        loc_upcountcPs25);

		loc_runProcNRs1000 := loc_pcountRs1000;
                loc_runProcNRs500 := loc_pcountRs500;
                loc_runProcNRs100 := loc_pcountRs100;
                loc_runProcNRs50  := loc_pcountRs50;
                loc_runProcNRs20 := loc_pcountRs20;
                loc_runProcNRs10 := loc_pcountRs10;
                loc_runProcNRs5 := loc_pcountRs5;
                loc_runProcNRs2 := loc_pcountRs2;
                loc_runProcNRs1 := loc_pcountRs1;
                loc_runProcCRs10 := loc_pcountcRs10;
                loc_runProcCRs5 := loc_pcountcRs5;
                loc_runProcCRs2 := loc_pcountcRs2;
                loc_runProcCRs1 := loc_pcountcRs1;
                loc_runProcCPs50 := loc_pcountcPs50;
                loc_runProcCPs25 := loc_pcountcPs25;
                loc_runUnProcNRs1000 := loc_upcountRs1000;
                loc_runUnProcNRs500 := loc_upcountRs500;
                loc_runUnProcNRs100 := loc_upcountRs100;
                loc_runUnProcNRs50  := loc_upcountRs50;
                loc_runUnProcNRs20 := loc_upcountRs20;
                loc_runUnProcNRs10 := loc_upcountRs10;
                loc_runUnProcNRs5 := loc_upcountRs5;
                loc_runUnProcNRs2 := loc_upcountRs2;
                loc_runUnProcNRs1 := loc_upcountRs1;
                loc_runUnProcCRs10 := loc_upcountcRs10;
                loc_runUnProcCRs5 := loc_upcountcRs5;
                loc_runUnProcCRs2 := loc_upcountcRs2;
                loc_runUnProcCRs1 := loc_upcountcRs1;
                loc_runUnProcCPs50 := loc_upcountcPs50;
                loc_runUnProcCPs25 := loc_upcountcPs25;

elsif(shift = 2) then
                select LCHG_TIME,SOL_ID,TRAN_DATE,PROC_AMT,PROCFORACID,UNPROCFORACID,PCOUNTRS1000,PCOUNTRS500,PCOUNTRS100,PCOUNTRS50,PCOUNTRS20,PCOUNTRS10,PCOUNTRS5,PCOUNTRS2,PCOUNTRS1,PCOUNTCRS10,PCOUNTCRS5,PCOUNTCRS2,PCOUNTCRS1,PCOUNT50PS,PCOUNT25PS,UCOUNTRS1000,UCOUNTRS500,UCOUNTRS100,UCOUNTRS50,UCOUNTRS20,UCOUNTRS10,UCOUNTRS5,UCOUNTRS2,UCOUNTRS1,UCOUNTCRS10,UCOUNTCRS5,UCOUNTCRS2,UCOUNTCRS1,UCOUNT50PS,UCOUNT25PS,UNPROC_AMT into  loc_lchgtime,loc_soId,loc_tranDate,loc_procAmt,loc_procForacid,loc_unprocForacid,loc_pcountRs1000,loc_pcountRs500,loc_pcountRs100,loc_pcountRs50,loc_pcountRs20,loc_pcountRs10,loc_pcountRs5,loc_pcountRs2,loc_pcountRs1,loc_pcountcRs10,loc_pcountcRs5,loc_pcountcRs2,loc_pcountcRs1,loc_pcountcPs50,loc_pcountcPs25,loc_upcountRs1000,loc_upcountRs500,loc_upcountRs100,loc_upcountRs50,loc_upcountRs20,loc_upcountRs10,loc_upcountRs5,loc_upcountRs2,loc_upcountRs1,loc_upcountcRs10,loc_upcountcRs5,loc_upcountcRs2,loc_upcountcRs1,loc_upcountcPs50,loc_upcountcPs25,loc_unprocAmt from CBRREP where SOL_ID in ( select sol_id from sst where sol_id = '&1') and TRAN_DATE = '&2' and shift =2;



                dbms_output.put_line(to_char(loc_lchgtime,'DD-MM-YYYY:HH:MM:SS')||'|'||
                        'AA'||'|'||
                        shift||'|'||
                        loc_soId||'|'||
                        loc_procAmt||'|'||
                        loc_tranDate||'|'||
                        loc_procForacid||'|'||
                        loc_unprocForacid||'|'||
                        loc_pcountRs1000||'|'||
                        loc_pcountRs500||'|'||
                        loc_pcountRs100||'|'||
                        loc_pcountRs50||'|'||
                        loc_pcountRs20||'|'||
                        loc_pcountRs10||'|'||
                        loc_pcountRs5||'|'||
                        loc_pcountRs2||'|'||
                        loc_pcountRs1||'|'||
                        loc_pcountcRs10||'|'||
                        loc_pcountcRs5||'|'||
                        loc_pcountcRs2||'|'||
                        loc_pcountcRs1||'|'||
                        loc_pcountcPs50||'|'||
                        loc_pcountcPs25);

                 dbms_output.put_line(to_char(loc_lchgtime,'DD-MM-YYYY:HH:MM:SS')||'|'||'AB'||'|'||shift||'|'||loc_soId||'|'||
                        loc_unprocAmt||'|'||
                        loc_tranDate||'|'||
                        loc_procForacid||'|'||
                        loc_unprocForacid||'|'||
                        loc_upcountRs1000||'|'||
                        loc_upcountRs500||'|'||
                        loc_upcountRs100||'|'||
                        loc_upcountRs50||'|'||
                        loc_upcountRs20||'|'||
                        loc_upcountRs10||'|'||
                        loc_upcountRs5||'|'||
                        loc_upcountRs2||'|'||
                        loc_upcountRs1||'|'||
                        loc_upcountcRs10||'|'||
                        loc_upcountcRs5||'|'||
                        loc_upcountcRs2||'|'||
	                loc_upcountcRs1||'|'||
                        loc_upcountcPs50||'|'||
                        loc_upcountcPs25);

                loc_runProcNRs1000 := loc_pcountRs1000;
                loc_runProcNRs500 := loc_pcountRs500;
                loc_runProcNRs100 := loc_pcountRs100;
                loc_runProcNRs50  := loc_pcountRs50;
                loc_runProcNRs20 := loc_pcountRs20;
                loc_runProcNRs10 := loc_pcountRs10;
                loc_runProcNRs5 := loc_pcountRs5;
                loc_runProcNRs2 := loc_pcountRs2;
                loc_runProcNRs1 := loc_pcountRs1;
                loc_runProcCRs10 := loc_pcountcRs10;
                loc_runProcCRs5 := loc_pcountcRs5;
                loc_runProcCRs2 := loc_pcountcRs2;
                loc_runProcCRs1 := loc_pcountcRs1;
                loc_runProcCPs50 := loc_pcountcPs50;
                loc_runProcCPs25 := loc_pcountcPs25;
                loc_runUnProcNRs1000 := loc_upcountRs1000;
                loc_runUnProcNRs500 := loc_upcountRs500;
                loc_runUnProcNRs100 := loc_upcountRs100;
                loc_runUnProcNRs50  := loc_upcountRs50;
                loc_runUnProcNRs20 := loc_upcountRs20;
                loc_runUnProcNRs10 := loc_upcountRs10;
                loc_runUnProcNRs5 := loc_upcountRs5;
                loc_runUnProcNRs2 := loc_upcountRs2;
                loc_runUnProcNRs1 := loc_upcountRs1;
                loc_runUnProcCRs10 := loc_upcountcRs10;
                loc_runUnProcCRs5 := loc_upcountcRs5;
                loc_runUnProcCRs2 := loc_upcountcRs2;
                loc_runUnProcCRs1 := loc_upcountcRs1;
                loc_runUnProcCPs50 := loc_upcountcPs50;
                loc_runUnProcCPs25 := loc_upcountcPs25;
        END IF;

		
		EXCEPTION
                        WHEN NO_DATA_FOUND THEN
			loc_soId := ' ';
			loc_tranDate := ' ';
			loc_procAmt := ' ';
			loc_procForacid := ' ';
			loc_unprocForacid := ' ';
			loc_pcountRs1000 := ' ';
			loc_pcountRs500 := ' ';
			loc_pcountRs100 := ' ';
			loc_pcountRs50 := ' ';
			loc_pcountRs20 := ' ';
			loc_pcountRs10 := ' ';
			loc_pcountRs5 := ' ';
			loc_pcountRs2 := ' ';
			loc_pcountRs1 := ' ';
			loc_pcountcRs10:= ' ';
			loc_pcountcRs5 := ' ';
			loc_pcountcRs2 := ' ';
			loc_pcountcRs1 := ' ';
			loc_pcountcPs50 := ' ';
			loc_pcountcPs25 := ' ';
			loc_upcountRs1000 := ' ';
			loc_upcountRs500 := ' ';
			loc_upcountRs100 := ' ';
			loc_upcountRs50 := ' ';
			loc_upcountRs20 := ' ';
			loc_upcountRs10 := ' ';
			loc_upcountRs5 := ' ';
			loc_upcountRs2 := ' ';
			loc_upcountRs1 := ' ';
			loc_upcountcRs10 := ' ';
			loc_upcountcRs5 := ' ';
			loc_upcountcRs2 := ' ';
			loc_upcountcRs1 := ' ';
			loc_upcountcPs50 := ' ';
			loc_upcountcPs25 := ' ';
			loc_unprocAmt := ' ';

		dbms_output.put_line(to_char(loc_lchgtime,'DD-MM-YYYY:HH:MM:SS')||'|'||'AA'||'|'||'A'||'|'||loc_soId||'|'||
			loc_procAmt||'|'||
			loc_tranDate||'|'||
			loc_procForacid||'|'||
			loc_unprocForacid||'|'||
			loc_pcountRs1000||'|'||
			loc_pcountRs500||'|'||
			loc_pcountRs100||'|'||
			loc_pcountRs50||'|'||
			loc_pcountRs20||'|'||
			loc_pcountRs10||'|'||
			loc_pcountRs5||'|'||
			loc_pcountRs2||'|'||
			loc_pcountRs1||'|'||
			loc_pcountcRs10||'|'||
			loc_pcountcRs5||'|'||
			loc_pcountcRs2||'|'||
			loc_pcountcRs1||'|'||
			loc_pcountcPs50||'|'||
			loc_pcountcPs25);
	
		dbms_output.put_line(to_char(loc_lchgtime,'DD-MM-YYYY:HH:MM:SS')||'|'||'AB'||'|'||'A'||'|'||loc_soId||'|'||
			loc_unprocAmt||'|'||
                        loc_tranDate||'|'||
                        loc_procForacid||'|'||
                        loc_unprocForacid||'|'||
                        loc_upcountRs1000||'|'||
                        loc_upcountRs500||'|'||
                        loc_upcountRs100||'|'||
                        loc_upcountRs50||'|'||
                        loc_upcountRs20||'|'||
                        loc_upcountRs10||'|'||
                        loc_upcountRs5||'|'||
                        loc_upcountRs2||'|'||
                        loc_upcountRs1||'|'||
                        loc_upcountcRs10||'|'||
                        loc_upcountcRs5||'|'||
                        loc_upcountcRs2||'|'||
                        loc_upcountcRs1||'|'||
                        loc_upcountcPs50||'|'||
                        loc_upcountcPs25);
			
END;
BEGIN
for fc1 in cursor1
loop
	if(fc1.TRAN_IDENTIFIER = 'A') then
		dbms_output.put_line(to_char(fc1.LCHG_TIME,'DD-MM-YYYY:HH:MM:SS')||'|'||'WA'||'|'||fc1.TRAN_IDENTIFIER||'|'||
                fc1.SOL_ID||'|'||
                fc1.TRAN_AMT||'|'||
                fc1.TRAN_DATE||'|'||
                fc1.FROM_FORACID||'|'||
                fc1.TO_FORACID||'|'||
                fc1.COUNTRS1000||'|'||
                fc1.COUNTRS500||'|'||
                fc1.COUNTRS100||'|'||
                fc1.COUNTRS50||'|'||
                fc1.COUNTRS20||'|'||
                fc1.COUNTRS10||'|'||
                fc1.COUNTRS5||'|'||
                fc1.COUNTRS2||'|'||
                fc1.COUNTRS1||'|'||
                fc1.COUNTCRS10||'|'||
                fc1.COUNTCRS5||'|'||
                fc1.COUNTCRS2||'|'||
                fc1.COUNTCRS1||'|'||
                fc1.COUNT50PS||'|'||
                fc1.COUNT25PS);

		loc_runProcNRs1000 := loc_runProcNRs1000 - fc1.COUNTRS1000;
                loc_runProcNRs500 := loc_runProcNRs500 - fc1.COUNTRS500;
                loc_runProcNRs100 := loc_runProcNRs100 - fc1.COUNTRS100;
                loc_runProcNRs50 := loc_runProcNRs50 - fc1.COUNTRS50;
                loc_runProcNRs20 := loc_runProcNRs20 - fc1.COUNTRS20;
                loc_runProcNRs10 := loc_runProcNRs10 - fc1.COUNTRS10;
                loc_runProcNRs5 := loc_runProcNRs5 - fc1.COUNTRS5;
                loc_runProcNRs2 := loc_runProcNRs2 - fc1.COUNTRS2;
                loc_runProcNRs1 := loc_runProcNRs1 - fc1.COUNTRS1;
                loc_runProcCRs10 := loc_runProcCRs10 - fc1.COUNTCRS10;
                loc_runProcCRs5 := loc_runProcCRs5 - fc1.COUNTCRS5;
                loc_runProcCRs2 := loc_runProcCRs2 - fc1.COUNTCRS2;
                loc_runProcCRs1 := loc_runProcCRs1 - fc1.COUNTCRS1;
                loc_runProcCPs50 := loc_runProcCPs50 - fc1.COUNT50PS;
                loc_runProcCPs25 := loc_runProcCPs25 - fc1.COUNT25PS;

		dbms_output.put_line(to_char(fc1.LCHG_TIME,'DD-MM-YYYY:HH:MM:SS')||'|'||'RA'||'|'||fc1.TRAN_IDENTIFIER||'|'||
		fc1.SOL_ID||'|'||
		fc1.TRAN_AMT||'|'||
		fc1.TRAN_DATE||'|'||
		fc1.FROM_FORACID||'|'||
                fc1.TO_FORACID||'|'||
		loc_runProcNRs1000||'|'||
		loc_runProcNRs500||'|'||
		loc_runProcNRs100||'|'||
		loc_runProcNRs50||'|'||
		loc_runProcNRs20||'|'||
		loc_runProcNRs10||'|'||
		loc_runProcNRs5||'|'||
		loc_runProcNRs2||'|'||
		loc_runProcNRs1||'|'||
		loc_runProcCRs10||'|'||
		loc_runProcCRs5||'|'||
		loc_runProcCRs2||'|'||
		loc_runProcCRs1||'|'||
		loc_runProcCPs50||'|'||
		loc_runProcCPs25);

			
				
	
	elsif(fc1.TRAN_IDENTIFIER = 'B') then
                dbms_output.put_line(to_char(fc1.LCHG_TIME,'DD-MM-YYYY:HH:MM:SS')||'|'||'DA'||'|'||fc1.TRAN_IDENTIFIER||'|'||
                fc1.SOL_ID||'|'||
                fc1.TRAN_AMT||'|'||
                fc1.TRAN_DATE||'|'||
                fc1.FROM_FORACID||'|'||
                fc1.TO_FORACID||'|'||
                fc1.COUNTRS1000||'|'||
                fc1.COUNTRS500||'|'||
                fc1.COUNTRS100||'|'||
                fc1.COUNTRS50||'|'||
                fc1.COUNTRS20||'|'||
                fc1.COUNTRS10||'|'||
                fc1.COUNTRS5||'|'||
                fc1.COUNTRS2||'|'||
                fc1.COUNTRS1||'|'||
                fc1.COUNTCRS10||'|'||
                fc1.COUNTCRS5||'|'||
                fc1.COUNTCRS2||'|'||
                fc1.COUNTCRS1||'|'||
                fc1.COUNT50PS||'|'||
                fc1.COUNT25PS);
		
		loc_runProcNRs1000 := loc_runProcNRs1000 + fc1.COUNTRS1000;
                loc_runProcNRs500 := loc_runProcNRs500 + fc1.COUNTRS500;
                loc_runProcNRs100 := loc_runProcNRs100 + fc1.COUNTRS100;
                loc_runProcNRs50 := loc_runProcNRs50 + fc1.COUNTRS50;
                loc_runProcNRs20 := loc_runProcNRs20 + fc1.COUNTRS20;
                loc_runProcNRs10 := loc_runProcNRs10 + fc1.COUNTRS10;
                loc_runProcNRs5 := loc_runProcNRs5 + fc1.COUNTRS5;
                loc_runProcNRs2 := loc_runProcNRs2 + fc1.COUNTRS2;
                loc_runProcNRs1 := loc_runProcNRs1 + fc1.COUNTRS1;
                loc_runProcCRs10 := loc_runProcCRs10 + fc1.COUNTCRS10;
                loc_runProcCRs5 := loc_runProcCRs5 + fc1.COUNTCRS5;
                loc_runProcCRs2 := loc_runProcCRs2 + fc1.COUNTCRS2;
                loc_runProcCRs1 := loc_runProcCRs1 + fc1.COUNTCRS1;
                loc_runProcCPs50 := loc_runProcCPs50 + fc1.COUNT50PS;
                loc_runProcCPs25 := loc_runProcCPs25 + fc1.COUNT25PS;

		dbms_output.put_line(to_char(fc1.LCHG_TIME,'DD-MM-YYYY:HH:MM:SS')||'|'||'RA'||'|'||fc1.TRAN_IDENTIFIER||'|'||
                fc1.SOL_ID||'|'||
                fc1.TRAN_AMT||'|'||
                fc1.TRAN_DATE||'|'||
                fc1.FROM_FORACID||'|'||
                fc1.TO_FORACID||'|'||
                loc_runProcNRs1000||'|'||
                loc_runProcNRs500||'|'||
                loc_runProcNRs100||'|'||
                loc_runProcNRs50||'|'||
                loc_runProcNRs20||'|'||
                loc_runProcNRs10||'|'||
                loc_runProcNRs5||'|'||
                loc_runProcNRs2||'|'||
                loc_runProcNRs1||'|'||
                loc_runProcCRs10||'|'||
                loc_runProcCRs5||'|'||
                loc_runProcCRs2||'|'||
                loc_runProcCRs1||'|'||
                loc_runProcCPs50||'|'||
                loc_runProcCPs25);
		
		

	elsif(fc1.TRAN_IDENTIFIER = 'C') then
                dbms_output.put_line(to_char(fc1.LCHG_TIME,'DD-MM-YYYY:HH:MM:SS')||'|'||'DB'||'|'||fc1.TRAN_IDENTIFIER||'|'||
                fc1.SOL_ID||'|'||
                fc1.TRAN_AMT||'|'||
                fc1.TRAN_DATE||'|'||
                fc1.FROM_FORACID||'|'||
                fc1.TO_FORACID||'|'||
                fc1.COUNTRS1000||'|'||
                fc1.COUNTRS500||'|'||
                fc1.COUNTRS100||'|'||
                fc1.COUNTRS50||'|'||
                fc1.COUNTRS20||'|'||
                fc1.COUNTRS10||'|'||
                fc1.COUNTRS5||'|'||
                fc1.COUNTRS2||'|'||
                fc1.COUNTRS1||'|'||
                fc1.COUNTCRS10||'|'||
                fc1.COUNTCRS5||'|'||
                fc1.COUNTCRS2||'|'||
                fc1.COUNTCRS1||'|'||
                fc1.COUNT50PS||'|'||
                fc1.COUNT25PS);

		loc_runUnProcNRs1000 := loc_runUnProcNRs1000 + fc1.COUNTRS1000;
                loc_runUnProcNRs500 := loc_runUnProcNRs500 + fc1.COUNTRS500;
                loc_runUnProcNRs100 := loc_runUnProcNRs100 + fc1.COUNTRS100;
                loc_runUnProcNRs50 := loc_runUnProcNRs50 + fc1.COUNTRS50;
                loc_runUnProcNRs20 := loc_runUnProcNRs20 + fc1.COUNTRS20;
                loc_runUnProcNRs10 := loc_runUnProcNRs10 + fc1.COUNTRS10;
                loc_runUnProcNRs5 := loc_runUnProcNRs5 + fc1.COUNTRS5;
                loc_runUnProcNRs2 := loc_runUnProcNRs2 + fc1.COUNTRS2;
                loc_runUnProcNRs1 := loc_runUnProcNRs1 + fc1.COUNTRS1;
                loc_runUnProcCRs10 := loc_runUnProcCRs10 + fc1.COUNTCRS10;
                loc_runUnProcCRs5 := loc_runUnProcCRs5 + fc1.COUNTCRS5;
                loc_runUnProcCRs2 := loc_runUnProcCRs2 + fc1.COUNTCRS2;
                loc_runUnProcCRs1 := loc_runUnProcCRs1 + fc1.COUNTCRS1;
                loc_runUnProcCPs50 := loc_runUnProcCPs50 + fc1.COUNT50PS;
                loc_runUnProcCPs25 := loc_runUnProcCPs25 + fc1.COUNT25PS;

		dbms_output.put_line(to_char(fc1.LCHG_TIME,'DD-MM-YYYY:HH:MM:SS')||'|'||'RB'||'|'||fc1.TRAN_IDENTIFIER||'|'||
		fc1.SOL_ID||'|'||
                fc1.TRAN_AMT||'|'||
                fc1.TRAN_DATE||'|'||
                fc1.FROM_FORACID||'|'||
                fc1.TO_FORACID||'|'||
		loc_runUnProcNRs1000||'|'||
		loc_runUnProcNRs500||'|'||
		loc_runUnProcNRs100||'|'||
		loc_runUnProcNRs50||'|'||
		loc_runUnProcNRs20||'|'||
		loc_runUnProcNRs10||'|'||
		loc_runUnProcNRs5||'|'||
		loc_runUnProcNRs2||'|'||
		loc_runUnProcNRs1||'|'||
		loc_runUnProcCRs10||'|'||
		loc_runUnProcCRs5||'|'||
		loc_runUnProcCRs2||'|'||
		loc_runUnProcCRs1||'|'||
		loc_runUnProcCPs50||'|'||
		loc_runUnProcCPs25);
		

	
	elsif(fc1.TRAN_IDENTIFIER = 'D')THEN

		dbms_output.put_line(to_char(fc1.LCHG_TIME,'DD-MM-YYYY:HH:MM:SS')||'|'||'WB'||'|'||fc1.TRAN_IDENTIFIER||'|'||
		fc1.SOL_ID||'|'||
		fc1.TRAN_AMT||'|'||
		fc1.TRAN_DATE||'|'||
		fc1.FROM_FORACID||'|'||
		fc1.TO_FORACID||'|'||
		fc1.COUNTRS1000||'|'||
		fc1.COUNTRS500||'|'||
		fc1.COUNTRS100||'|'||
		fc1.COUNTRS50||'|'||
		fc1.COUNTRS20||'|'||
		fc1.COUNTRS10||'|'||
		fc1.COUNTRS5||'|'||
		fc1.COUNTRS2||'|'||      
		fc1.COUNTRS1||'|'||
		fc1.COUNTCRS10||'|'||
		fc1.COUNTCRS5||'|'||
		fc1.COUNTCRS2||'|'||
		fc1.COUNTCRS1||'|'||
		fc1.COUNT50PS||'|'||
		fc1.COUNT25PS);

		loc_runUnProcNRs1000 := loc_runUnProcNRs1000 - fc1.COUNTRS1000;
                loc_runUnProcNRs500 := loc_runUnProcNRs500 - fc1.COUNTRS500;
                loc_runUnProcNRs100 := loc_runUnProcNRs100 - fc1.COUNTRS100;
                loc_runUnProcNRs50 := loc_runUnProcNRs50 - fc1.COUNTRS50;
                loc_runUnProcNRs20 := loc_runUnProcNRs20 - fc1.COUNTRS20;
                loc_runUnProcNRs10 := loc_runUnProcNRs10 - fc1.COUNTRS10;
                loc_runUnProcNRs5 := loc_runUnProcNRs5 - fc1.COUNTRS5;
                loc_runUnProcNRs2 := loc_runUnProcNRs2 - fc1.COUNTRS2;
                loc_runUnProcNRs1 := loc_runUnProcNRs1 - fc1.COUNTRS1;
                loc_runUnProcCRs10 := loc_runUnProcCRs10 - fc1.COUNTCRS10;
                loc_runUnProcCRs5 := loc_runUnProcCRs5 - fc1.COUNTCRS5;
                loc_runUnProcCRs2 := loc_runUnProcCRs2 - fc1.COUNTCRS2;
                loc_runUnProcCRs1 := loc_runUnProcCRs1 - fc1.COUNTCRS1;
                loc_runUnProcCPs50 := loc_runUnProcCPs50 - fc1.COUNT50PS;
                loc_runUnProcCPs25 := loc_runUnProcCPs25 - fc1.COUNT25PS;
		
		dbms_output.put_line(to_char(fc1.LCHG_TIME,'DD-MM-YYYY:HH:MM:SS')||'|'||'RB'||'|'||fc1.TRAN_IDENTIFIER||'|'||
                fc1.SOL_ID||'|'||
                fc1.TRAN_AMT||'|'||
                fc1.TRAN_DATE||'|'||
                fc1.FROM_FORACID||'|'||
                fc1.TO_FORACID||'|'||
                loc_runUnProcNRs1000||'|'||
                loc_runUnProcNRs500||'|'||
                loc_runUnProcNRs100||'|'||
                loc_runUnProcNRs50||'|'||
                loc_runUnProcNRs20||'|'||
                loc_runUnProcNRs10||'|'||
                loc_runUnProcNRs5||'|'||
                loc_runUnProcNRs2||'|'||
                loc_runUnProcNRs1||'|'||
                loc_runUnProcCRs10||'|'||
                loc_runUnProcCRs5||'|'||
                loc_runUnProcCRs2||'|'||
                loc_runUnProcCRs1||'|'||
                loc_runUnProcCPs50||'|'||
                loc_runUnProcCPs25);
		
		
	
		dbms_output.put_line(to_char(fc1.LCHG_TIME,'DD-MM-YYYY:HH:MM:SS')||'|'||'DA'||'|'||fc1.TRAN_IDENTIFIER||'|'||
                fc1.SOL_ID||'|'||
                fc1.TRAN_AMT||'|'||
                fc1.TRAN_DATE||'|'||
                fc1.FROM_FORACID||'|'||
                fc1.TO_FORACID||'|'||
                fc1.COUNTRS1000||'|'||
                fc1.COUNTRS500||'|'||
                fc1.COUNTRS100||'|'||
                fc1.COUNTRS50||'|'||
                fc1.COUNTRS20||'|'||
                fc1.COUNTRS10||'|'||
                fc1.COUNTRS5||'|'||
                fc1.COUNTRS2||'|'||
                fc1.COUNTRS1||'|'||
                fc1.COUNTCRS10||'|'||
                fc1.COUNTCRS5||'|'||
                fc1.COUNTCRS2||'|'||
                fc1.COUNTCRS1||'|'||
                fc1.COUNT50PS||'|'||
                fc1.COUNT25PS);
		
		loc_runProcNRs1000 := loc_runProcNRs1000 + fc1.COUNTRS1000;
                loc_runProcNRs500 := loc_runProcNRs500 + fc1.COUNTRS500;
                loc_runProcNRs100 := loc_runProcNRs100 + fc1.COUNTRS100;
                loc_runProcNRs50 := loc_runProcNRs50 + fc1.COUNTRS50;
                loc_runProcNRs20 := loc_runProcNRs20 + fc1.COUNTRS20;
                loc_runProcNRs10 := loc_runProcNRs10 + fc1.COUNTRS10;
                loc_runProcNRs5 := loc_runProcNRs5 + fc1.COUNTRS5;
                loc_runProcNRs2 := loc_runProcNRs2 + fc1.COUNTRS2;
                loc_runProcNRs1 := loc_runProcNRs1 + fc1.COUNTRS1;
                loc_runProcCRs10 := loc_runProcCRs10 + fc1.COUNTCRS10;
                loc_runProcCRs5 := loc_runProcCRs5 + fc1.COUNTCRS5;
                loc_runProcCRs2 := loc_runProcCRs2 + fc1.COUNTCRS2;
                loc_runProcCRs1 := loc_runProcCRs1 + fc1.COUNTCRS1;
                loc_runProcCPs50 := loc_runProcCPs50 + fc1.COUNT50PS;
                loc_runProcCPs25 := loc_runProcCPs25 + fc1.COUNT25PS;
		
		dbms_output.put_line(to_char(fc1.LCHG_TIME,'DD-MM-YYYY:HH:MM:SS')||'|'||'RA'||'|'||fc1.TRAN_IDENTIFIER||'|'||
                fc1.SOL_ID||'|'||
                fc1.TRAN_AMT||'|'||
                fc1.TRAN_DATE||'|'||
                fc1.FROM_FORACID||'|'||
                fc1.TO_FORACID||'|'||
                loc_runProcNRs1000||'|'||
                loc_runProcNRs500||'|'||
                loc_runProcNRs100||'|'||
                loc_runProcNRs50||'|'||
                loc_runProcNRs20||'|'||
                loc_runProcNRs10||'|'||
                loc_runProcNRs5||'|'||
                loc_runProcNRs2||'|'||
                loc_runProcNRs1||'|'||
                loc_runProcCRs10||'|'||
                loc_runProcCRs5||'|'||
                loc_runProcCRs2||'|'||
                loc_runProcCRs1||'|'||
                loc_runProcCPs50||'|'||
                loc_runProcCPs25);	
	
	elsif(fc1.TRAN_IDENTIFIER = 'E')THEN

                dbms_output.put_line(to_char(fc1.LCHG_TIME,'DD-MM-YYYY:HH:MM:SS')||'|'||'WA'||'|'||fc1.TRAN_IDENTIFIER||'|'||
                fc1.SOL_ID||'|'||
                fc1.TRAN_AMT||'|'||
                fc1.TRAN_DATE||'|'||
                fc1.FROM_FORACID||'|'||
                fc1.TO_FORACID||'|'||
                fc1.COUNTRS1000||'|'||
                fc1.COUNTRS500||'|'||
                fc1.COUNTRS100||'|'||
                fc1.COUNTRS50||'|'||
                fc1.COUNTRS20||'|'||
                fc1.COUNTRS10||'|'||
                fc1.COUNTRS5||'|'||
                fc1.COUNTRS2||'|'||
                fc1.COUNTRS1||'|'||
                fc1.COUNTCRS10||'|'||
                fc1.COUNTCRS5||'|'||
                fc1.COUNTCRS2||'|'||
                fc1.COUNTCRS1||'|'||
                fc1.COUNT50PS||'|'||
                fc1.COUNT25PS);

		loc_runProcNRs1000 := loc_runProcNRs1000 - fc1.COUNTRS1000;
                loc_runProcNRs500 := loc_runProcNRs500 - fc1.COUNTRS500;
                loc_runProcNRs100 := loc_runProcNRs100 - fc1.COUNTRS100;
                loc_runProcNRs50 := loc_runProcNRs50 - fc1.COUNTRS50;
                loc_runProcNRs20 := loc_runProcNRs20 - fc1.COUNTRS20;
                loc_runProcNRs10 := loc_runProcNRs10 - fc1.COUNTRS10;
                loc_runProcNRs5 := loc_runProcNRs5 - fc1.COUNTRS5;
                loc_runProcNRs2 := loc_runProcNRs2 - fc1.COUNTRS2;
                loc_runProcNRs1 := loc_runProcNRs1 - fc1.COUNTRS1;
                loc_runProcCRs10 := loc_runProcCRs10 - fc1.COUNTCRS10;
                loc_runProcCRs5 := loc_runProcCRs5 - fc1.COUNTCRS5;
                loc_runProcCRs2 := loc_runProcCRs2 - fc1.COUNTCRS2;
                loc_runProcCRs1 := loc_runProcCRs1 - fc1.COUNTCRS1;
                loc_runProcCPs50 := loc_runProcCPs50 - fc1.COUNT50PS;
                loc_runProcCPs25 := loc_runProcCPs25 - fc1.COUNT25PS;


		dbms_output.put_line(to_char(fc1.LCHG_TIME,'DD-MM-YYYY:HH:MM:SS')||'|'||'RA'||'|'||fc1.TRAN_IDENTIFIER||'|'||
                fc1.SOL_ID||'|'||
                fc1.TRAN_AMT||'|'||
                fc1.TRAN_DATE||'|'||
                fc1.FROM_FORACID||'|'||
                fc1.TO_FORACID||'|'||
                loc_runProcNRs1000||'|'||
                loc_runProcNRs500||'|'||
                loc_runProcNRs100||'|'||
                loc_runProcNRs50||'|'||
                loc_runProcNRs20||'|'||
                loc_runProcNRs10||'|'||
                loc_runProcNRs5||'|'||
                loc_runProcNRs2||'|'||
                loc_runProcNRs1||'|'||
                loc_runProcCRs10||'|'||
                loc_runProcCRs5||'|'||
                loc_runProcCRs2||'|'||
                loc_runProcCRs1||'|'||
                loc_runProcCPs50||'|'||
                loc_runProcCPs25);
		
		dbms_output.put_line(to_char(fc1.LCHG_TIME,'DD-MM-YYYY:HH:MM:SS')||'|'||'DB'||'|'||fc1.TRAN_IDENTIFIER||'|'||
                fc1.SOL_ID||'|'||
                fc1.TRAN_AMT||'|'||
                fc1.TRAN_DATE||'|'||
                fc1.FROM_FORACID||'|'||
                fc1.TO_FORACID||'|'||
                fc1.COUNTRS1000||'|'||
                fc1.COUNTRS500||'|'||
                fc1.COUNTRS100||'|'||
                fc1.COUNTRS50||'|'||
                fc1.COUNTRS20||'|'||
                fc1.COUNTRS10||'|'||
                fc1.COUNTRS5||'|'||
                fc1.COUNTRS2||'|'||
                fc1.COUNTRS1||'|'||
                fc1.COUNTCRS10||'|'||
                fc1.COUNTCRS5||'|'||
                fc1.COUNTCRS2||'|'||
                fc1.COUNTCRS1||'|'||
                fc1.COUNT50PS||'|'||
                fc1.COUNT25PS);

		loc_runUnProcNRs1000 := loc_runUnProcNRs1000 + fc1.COUNTRS1000;
                loc_runUnProcNRs500 := loc_runUnProcNRs500 + fc1.COUNTRS500;
                loc_runUnProcNRs100 := loc_runUnProcNRs100 + fc1.COUNTRS100;
                loc_runUnProcNRs50 := loc_runUnProcNRs50 + fc1.COUNTRS50;
                loc_runUnProcNRs20 := loc_runUnProcNRs20 + fc1.COUNTRS20;
                loc_runUnProcNRs10 := loc_runUnProcNRs10 + fc1.COUNTRS10;
                loc_runUnProcNRs5 := loc_runUnProcNRs5 + fc1.COUNTRS5;
                loc_runUnProcNRs2 := loc_runUnProcNRs2 + fc1.COUNTRS2;
                loc_runUnProcNRs1 := loc_runUnProcNRs1 + fc1.COUNTRS1;
                loc_runUnProcCRs10 := loc_runUnProcCRs10 + fc1.COUNTCRS10;
                loc_runUnProcCRs5 := loc_runUnProcCRs5 + fc1.COUNTCRS5;
                loc_runUnProcCRs2 := loc_runUnProcCRs2 + fc1.COUNTCRS2;
                loc_runUnProcCRs1 := loc_runUnProcCRs1 + fc1.COUNTCRS1;
                loc_runUnProcCPs50 := loc_runUnProcCPs50 + fc1.COUNT50PS;
                loc_runUnProcCPs25 := loc_runUnProcCPs25 + fc1.COUNT25PS;

		dbms_output.put_line(to_char(fc1.LCHG_TIME,'DD-MM-YYYY:HH:MM:SS')||'|'||'RB'||'|'||fc1.TRAN_IDENTIFIER||'|'||
                fc1.SOL_ID||'|'||
                fc1.TRAN_AMT||'|'||
                fc1.TRAN_DATE||'|'||
                fc1.FROM_FORACID||'|'||
                fc1.TO_FORACID||'|'||
                loc_runUnProcNRs1000||'|'||
                loc_runUnProcNRs500||'|'||
                loc_runUnProcNRs100||'|'||
                loc_runUnProcNRs50||'|'||
                loc_runUnProcNRs20||'|'||
                loc_runUnProcNRs10||'|'||
                loc_runUnProcNRs5||'|'||
                loc_runUnProcNRs2||'|'||
                loc_runUnProcNRs1||'|'||
                loc_runUnProcCRs10||'|'||
                loc_runUnProcCRs5||'|'||
                loc_runUnProcCRs2||'|'||
                loc_runUnProcCRs1||'|'||
                loc_runUnProcCPs50||'|'||
                loc_runUnProcCPs25);	
	
	ELSIF(fc1.TRAN_IDENTIFIER = 'F')THEN
		dbms_output.put_line(to_char(fc1.LCHG_TIME,'DD-MM-YYYY:HH:MM:SS')||'|'||'WB'||'|'||fc1.TRAN_IDENTIFIER||'|'||
                fc1.SOL_ID||'|'||
                fc1.TRAN_AMT||'|'||
                fc1.TRAN_DATE||'|'||
                fc1.FROM_FORACID||'|'||
                fc1.TO_FORACID||'|'||
                fc1.COUNTRS1000||'|'||
                fc1.COUNTRS500||'|'||
                fc1.COUNTRS100||'|'||
                fc1.COUNTRS50||'|'||
                fc1.COUNTRS20||'|'||
                fc1.COUNTRS10||'|'||
                fc1.COUNTRS5||'|'||
                fc1.COUNTRS2||'|'||
                fc1.COUNTRS1||'|'||
                fc1.COUNTCRS10||'|'||
                fc1.COUNTCRS5||'|'||
                fc1.COUNTCRS2||'|'||
                fc1.COUNTCRS1||'|'||
                fc1.COUNT50PS||'|'||
                fc1.COUNT25PS);

		loc_runUnProcNRs1000 := loc_runUnProcNRs1000 - fc1.COUNTRS1000;
                loc_runUnProcNRs500 := loc_runUnProcNRs500 - fc1.COUNTRS500;
                loc_runUnProcNRs100 := loc_runUnProcNRs100 - fc1.COUNTRS100;
                loc_runUnProcNRs50 := loc_runUnProcNRs50 - fc1.COUNTRS50;
                loc_runUnProcNRs20 := loc_runUnProcNRs20 - fc1.COUNTRS20;
                loc_runUnProcNRs10 := loc_runUnProcNRs10 - fc1.COUNTRS10;
                loc_runUnProcNRs5 := loc_runUnProcNRs5 - fc1.COUNTRS5;
                loc_runUnProcNRs2 := loc_runUnProcNRs2 - fc1.COUNTRS2;
                loc_runUnProcNRs1 := loc_runUnProcNRs1 - fc1.COUNTRS1;
                loc_runUnProcCRs10 := loc_runUnProcCRs10 - fc1.COUNTCRS10;
                loc_runUnProcCRs5 := loc_runUnProcCRs5 - fc1.COUNTCRS5;
                loc_runUnProcCRs2 := loc_runUnProcCRs2 - fc1.COUNTCRS2;
                loc_runUnProcCRs1 := loc_runUnProcCRs1 - fc1.COUNTCRS1;
                loc_runUnProcCPs50 := loc_runUnProcCPs50 - fc1.COUNT50PS;
                loc_runUnProcCPs25 := loc_runUnProcCPs25 - fc1.COUNT25PS;


		dbms_output.put_line(to_char(fc1.LCHG_TIME,'DD-MM-YYYY:HH:MM:SS')||'|'||'RB'||'|'||fc1.TRAN_IDENTIFIER||'|'||
                fc1.SOL_ID||'|'||
                fc1.TRAN_AMT||'|'||
                fc1.TRAN_DATE||'|'||
                fc1.FROM_FORACID||'|'||
                fc1.TO_FORACID||'|'||
                loc_runUnProcNRs1000||'|'||
                loc_runUnProcNRs500||'|'||
                loc_runUnProcNRs100||'|'||
                loc_runUnProcNRs50||'|'||
                loc_runUnProcNRs20||'|'||
                loc_runUnProcNRs10||'|'||
                loc_runUnProcNRs5||'|'||
                loc_runUnProcNRs2||'|'||
                loc_runUnProcNRs1||'|'||
                loc_runUnProcCRs10||'|'||
                loc_runUnProcCRs5||'|'||
                loc_runUnProcCRs2||'|'||
                loc_runUnProcCRs1||'|'||
                loc_runUnProcCPs50||'|'||
                loc_runUnProcCPs25);

	END IF;

end loop;
END;

BEGIN

        loc_unprocAmt := (1000 * loc_runUnProcNRs1000) + (500 * loc_runUnProcNRs500) + (100 * loc_runUnProcNRs100) + (50 * loc_runUnProcNRs50) + (20 * loc_runUnProcNRs20) + (10 * loc_runUnProcNRs10) + (5 * loc_runUnProcNRs5) + (2 * loc_runUnProcNRs2) + (1 * loc_runUnProcNRs1) + (10 * loc_runUnProcCRs10) + (5 * loc_runUnProcCRs5) + (2 * loc_runUnProcCRs2) + (1 * loc_runUnProcCRs1) + (0.5 * loc_runUnProcCPs50) + (0.25 * loc_runUnProcCPs25);

        loc_procAmt := (1000 * loc_runProcNRs1000) + (500 * loc_runProcNRs500) + (100 * loc_runProcNRs100) + (50 * loc_runProcNRs50) + (20 * loc_runProcNRs20) + (10 * loc_runProcNRs10) + (5 * loc_runProcNRs5) + (2 * loc_runProcNRs2) + (1 * loc_runProcNRs1) + (10 * loc_runProcCRs10) + (5 * loc_runProcCRs5) + (2 * loc_runProcCRs2) + (1 * loc_runProcCRs1) + (0.5 * loc_runProcCPs50) + (0.25 * loc_runProcCPs25);
	
	loc_totAmt := loc_unprocAmt + loc_procAmt;
	loc_runBalRs1000 := loc_runProcNRs1000 + loc_runUnProcNRs1000;
        loc_runBalRs500 := loc_runProcNRs500 + loc_runUnProcNRs500;
        loc_runBalRs100 := loc_runProcNRs100 + loc_runUnProcNRs100;
        loc_runBalRs50 := loc_runProcNRs50 + loc_runUnProcNRs50;
        loc_runBalRs20 := loc_runProcNRs20 + loc_runUnProcNRs20;
        loc_runBalRs10 := loc_runProcNRs10 + loc_runUnProcNRs10;
        loc_runBalRs5 := loc_runProcNRs5 + loc_runUnProcNRs5;
        loc_runBalRs2 := loc_runProcNRs2 + loc_runUnProcNRs2;
        loc_runBalRs1 := loc_runProcNRs1 + loc_runUnProcNRs1;
        loc_runBalC10 := loc_runProcCRs10 + loc_runUnProcCRs10;
        loc_runBalC5 := loc_runProcCRs5 + loc_runUnProcCRs5;
        loc_runBalC2 := loc_runProcCRs2 + loc_runUnProcCRs2;
        loc_runBalC1 := loc_runProcCRs1 + loc_runUnProcCRs1;
        loc_runBalC50 := loc_runProcCPs50 + loc_runUnProcCPs50;
        loc_runBalC25 := loc_runProcCPs25 + loc_runUnProcCPs25;

                dbms_output.put_line('00-00-0000:00:00:00'||'|'||'TD'||'|'||'T'||'|'||
                loc_soId||'|'||
                loc_totAmt||'|'||
                loc_tranDate||'|'||
                loc_procForacid||'|'||
                loc_procForacid||'|'||
                loc_runBalRs1000||'|'||
                loc_runBalRs500||'|'||
                loc_runBalRs100||'|'||
                loc_runBalRs50||'|'||
                loc_runBalRs20||'|'||
                loc_runBalRs10||'|'||
                loc_runBalRs5||'|'||
                loc_runBalRs2||'|'||
                loc_runBalRs1||'|'||
                loc_runBalC10||'|'||
                loc_runBalC5||'|'||
                loc_runBalC2||'|'||
                loc_runBalC1||'|'||
                loc_runBalC50||'|'||
                loc_runBalC25);
		
		dbms_output.put_line('00-00-0000:00:00:00'||'|'||'TA'||'|'||'T'||'|'||
                loc_soId||'|'||
                loc_totAmt||'|'||
                loc_tranDate||'|'||
                loc_procForacid||'|'||
                loc_procForacid||'|'||
                loc_runUnProcNRs1000||'|'||
                loc_runUnProcNRs500||'|'||
                loc_runUnProcNRs100||'|'||
                loc_runUnProcNRs50||'|'||
                loc_runUnProcNRs20||'|'||
                loc_runUnProcNRs10||'|'||
                loc_runUnProcNRs5||'|'||
                loc_runUnProcNRs2||'|'||
                loc_runUnProcNRs1||'|'||
                loc_runUnProcCRs10||'|'||
                loc_runUnProcCRs5||'|'||
                loc_runUnProcCRs2||'|'||
                loc_runUnProcCRs1||'|'||
                loc_runUnProcCPs50||'|'||
                loc_runUnProcCPs25);

	
END;
BEGIN
for fc2 in cursor2
loop

	dbms_output.put_line('00-00-0000:00:00:00'||'|'||'GL'||'|'||'G'||'|'||
                '&1'||'|'||
                fc2.CLR_BAL_AMT||'|'||
                '&2'||'|'||
                fc2.FORACID||'|'||
                fc2.ACCT_CRNCY_CODE||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0');
end loop;
END;

BEGIN
select clr_bal_amt,foracid into bal_in_samutcur,samutcur_foracid from GAm where sol_id='&1' and bacid='SAMUTCUR';

                dbms_output.put_line('00-00-0000:00:00:00'||'|'||'SA'||'|'||shift||'|'||
                '&1'||'|'||
                bal_in_samutcur||'|'||
                '&2'||'|'||
                samutcur_foracid||'|'||
                'INR'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0');

                 EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                        bal_in_samutcur := 0;
                        samutcur_foracid := 'NA';
                dbms_output.put_line('00-00-0000:00:00:00'||'|'||'SA'||'|'||shift||'|'||
                '&1'||'|'||
                bal_in_samutcur||'|'||
                '&2'||'|'||
                samutcur_foracid||'|'||
                'INR'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0');
END;

BEGIN

select sum(clr_bal_amt) into sum_cash_gl_acct from GAM where sol_id='&1' and gl_sub_head_code='51010' and acct_crncy_code='INR';

		dbms_output.put_line('00-00-0000:00:00:00'||'|'||'GT'||'|'||'G'||'|'||
                '&1'||'|'||
                sum_cash_gl_acct||'|'||
                '&2'||'|'||
                'AAAAAA'||'|'||
                'INR'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0');
END;
	
BEGIN

select sum(clr_bal_amt) into phy_cash_in_branch from GAm where sol_id='0017' and bacid in('CSQSDBCI','CSQG4SE2','CS00CASH','CS00TEL','CSATMBRN','CSCIBD','CSPROCES','CSQCSIXL','CSUNPROC','CSMAIN01','CSMAIN02');

		dbms_output.put_line('00-00-0000:00:00:00'||'|'||'PC'||'|'||'G'||'|'||
		'&1'||'|'||
                phy_cash_in_branch||'|'||
                '&2'||'|'||
                'AAAAAA'||'|'||
                'INR'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0'||'|'||
                '0');

END;
BEGIN

	loc_tranDate := loc_tranDate + 1;

	dbms_output.put_line('00-00-0000:00:00:00'||'|'||'PF'||'|'||'G'||'|'||
	'&1'||'|'||
	loc_unprocAmt||'|'||
	loc_tranDate||'|'||
	loc_procForacid||'|'||
	loc_unprocForacid||'|'||
	loc_runUnProcNRs1000||'|'||
	loc_runUnProcNRs500||'|'||
	loc_runUnProcNRs100||'|'||
	loc_runUnProcNRs50||'|'||
	loc_runUnProcNRs20||'|'||
	loc_runUnProcNRs10||'|'||
	loc_runUnProcNRs5||'|'||
	loc_runUnProcNRs2||'|'||
	loc_runUnProcNRs1||'|'||
	loc_runUnProcCRs10||'|'||
	loc_runUnProcCRs5||'|'||
	loc_runUnProcCRs2||'|'||
	loc_runUnProcCRs1||'|'||
	loc_runUnProcCPs50||'|'||
	loc_runUnProcCPs25);


	dbms_output.put_line('00-00-0000:00:00:00'||'|'||'UF'||'|'||'G'||'|'||
	'&1'||'|'||
        loc_procAmt||'|'||
        loc_tranDate||'|'||
        loc_procForacid||'|'||
        loc_unprocForacid||'|'||
        loc_runProcNRs1000||'|'||
        loc_runProcNRs500||'|'||
        loc_runProcNRs100||'|'||
        loc_runProcNRs50||'|'||
        loc_runProcNRs20||'|'||
        loc_runProcNRs10||'|'||
        loc_runProcNRs5||'|'||
        loc_runProcNRs2||'|'||
        loc_runProcNRs1||'|'||
        loc_runProcCRs10||'|'||
        loc_runProcCRs5||'|'||
        loc_runProcCRs2||'|'||
        loc_runProcCRs1||'|'||
        loc_runProcCPs50||'|'||
        loc_runProcCPs25);
	
		

END;


END;
/
spool off
