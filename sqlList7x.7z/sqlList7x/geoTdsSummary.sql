-- -----------------------------------------------------------------------------------#
-- Program Name    : fsgTdsSummary.sql                                                #
-- Author          : Mandar Raddi                                                     #
-- Date Written	   : 28-Feb-2001                                                      #
--                                                                                    #
-- -----------------------------------------------------------------------------------#
--                                 Version History                                    #
-- -----------------------------------------------------------------------------------#
--   Ver.No |     Date   |    Author    |           Reason For Change                 #
-- -----------------------------------------------------------------------------------#
--     1    | 28-02-2001 | Mandar Raddi | Initial Release                             #
-- -----------------------------------------------------------------------------------#

set serveroutput on size 1000000
set linesize 512
set trims    on
set feedback off
set verify   off
set head     off
set termout off
spool &1-&2-&3-&4

DECLARE
	pspListId				PSP_TMP.LISTID%Type;
	--pspIdType				PSP_TMP.ID_TYPE%Type;
	pspIdType				varchar2(2);
	tdsCustId				TDS.CUST_ID%Type;
	tdsIntAmt				VARCHAR(20);
	tdsTdsAmt				VARCHAR(20);
	tdsTranDate				TDS.TRAN_DATE%Type;
	custSolId				TDS.SOL_ID%Type;
	gamForacid				GAM.FORACID%Type;
	recordType				VARCHAR(3);
	subRecordType			VARCHAR(3);
	out_record				VARCHAR(300);
    endOfPspCursor          NUMBER;
	outputTdsRec			NUMBER;
	locFrDate				DATE;
	locToDate				DATE;
	locFinYr 				DATE;
	pspRunId				varchar2(10);

	
	CURSOR PSP_TMP_CURSOR IS
		SELECT
			ENTITY_ID
		FROM
			PSP_TMP
		WHERE
			LISTID      = pspListId
		AND HOME_SOL_ID = custSolId;
		--AND ID_TYPE     = pspIdType;


    PROCEDURE writeTdsRec( dummy NUMBER ) IS
    BEGIN
		out_record := custSolId||'|'||
                      tdsCustId||'|'||
                      recordType||'|'||
                      subRecordType||'|'||
                      tdsIntAmt||'|'||
                      tdsTdsAmt;

		DBMS_OUTPUT.PUT_LINE(out_record);
    END;


-- -----------------------------------------------------------------------------------#
--  Procedure to get the interesr amount sum and tds amount sum for the given   
--  customer id. The customer id is obtained from PSP_TMP table for the input
--  RUN ID and SOL ID
-- -----------------------------------------------------------------------------------#

	PROCEDURE getAmounts( dummy NUMBER ) IS
	BEGIN
		SELECT
			 NVL(LTRIM(TO_CHAR(SUM(INT_AMT))), '0.00')
			,NVL(LTRIM(TO_CHAR(SUM(tds_from_org_acct + tds_from_op_acct + tds_from_suspense_acct))), '0.00')
		INTO
			 tdsIntAmt
			,tdsTdsAmt
		FROM
			TDS
		WHERE
			CUST_ID = tdsCustId
		AND TRAN_DATE BETWEEN locFinYr AND locFrDate-1;

		EXCEPTION
		WHEN NO_DATA_FOUND THEN
				outputTdsRec := 0;
		WHEN OTHERS THEN
			DBMS_OUTPUT.PUT_LINE('<#ORA-ERROR#>');
			DBMS_OUTPUT.PUT_LINE('Cust Id '||tdsCustId);
			DBMS_OUTPUT.PUT_LINE('Check SQL error,  and try again');
			DBMS_OUTPUT.PUT_LINE('Sql Error Code is        : ' || SQLCODE );
			DBMS_OUTPUT.PUT_LINE('SQL Error Description is : '|| SQLERRM);
	END;

	PROCEDURE processPspCursor( dummy NUMBER ) IS
	BEGIN
		FETCH PSP_TMP_CURSOR INTO
			 tdsCustId;

		if( PSP_TMP_CURSOR%NOTFOUND ) then
			endOfPspCursor := 1;
			RETURN;
		end if; 

		outputTdsRec := 1;
		getAmounts(0);
		if( outputTdsRec = 1 ) then
			writeTdsRec(0);
		end if;
	END;
			

BEGIN
	pspRunId         := '&1';
	custSolId        := '&2';
	pspIdType        := '&4';
	locFrDate        := TO_DATE('&5', 'DD-MM-YYYY');
	locToDate        := TO_DATE('&6', 'DD-MM-YYYY');
	locFinYr         := TO_DATE('&7', 'DD-MM-YYYY');

	recordType       := '25';
	subRecordType    := '0';
	pspListId        := pspRunId||custSolId||pspIdType||'C';

	OPEN PSP_TMP_CURSOR;

    endOfPspCursor := 0;

    WHILE (endOfPspCursor = 0) LOOP
        processPspCursor(0);
    END LOOP;

    CLOSE PSP_TMP_CURSOR;

	EXCEPTION
	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('<#ORA-ERROR#>');
		DBMS_OUTPUT.PUT_LINE('Check SQL error,  and try again');
		DBMS_OUTPUT.PUT_LINE('Sql Error Code is        : ' || SQLCODE );
		DBMS_OUTPUT.PUT_LINE('SQL Error Description is : '|| SQLERRM);
END;
/
spool off
