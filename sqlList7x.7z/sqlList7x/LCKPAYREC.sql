--##############################################################################################
--#                     File Name       : LCKPAYREC.sql
--#                     Author : Arun Kumar (BBSSL)
--#                     Report :Locker Payment Received Report 
--#                     Date   :
--#                     Module  : LOCKER
--#                     Called Menu     : LOCKRPT
--#                     Called By       : LCKPAYREC.com
--##############################################################################################
CREATE OR REPLACE PACKAGE LCKPAYREC AS
        PROCEDURE LCKPAYREC(inp_str IN VARCHAR2,
                out_retCode OUT NUMBER,
                out_rec OUT VARCHAR2);
END LCKPAYREC;
/
CREATE OR REPLACE PACKAGE BODY LCKPAYREC AS
v_setid         sst.set_id%type;
f_date		date;
t_date		date;

cursor c1 is
	SELECT DISTINCT locker_number,tran_id,tran_date
	FROM LCPD
	WHERE sol_id IN (SELECT sol_id FROM sst WHERE set_id = NVL(v_setid,'ALL'))
	AND tran_date BETWEEN to_date(f_date,'dd-mm-yyyy') AND to_date(t_date,'dd-mm-yyyy')
	AND PAID_AMOUNT > 0;

PROCEDURE LCKPAYREC(inp_str IN VARCHAR2,
        out_retCode OUT NUMBER,
        out_rec OUT VARCHAR2) IS

outArr                  basp0099.ArrayType;
v_tran_id 		dtd.tran_id%type;
v_tran_date		dtd.tran_date%type;
v_lockno		lcpd.locker_number%type;
v_rentamt		lcpd.paid_amount%type;
v_taxamt		lcpd.paid_amount%type;
v_chrgamt		lcpd.paid_amount%type;
v_penalamt		lcpd.paid_amount%type;
v_breakamt		lcpd.paid_amount%type;
v_totalamt		lcpd.paid_amount%type;
v_mode			dtd.tran_type%type;

Begin
        --{
        basp0099.formInputArr(inp_str,outArr);
	v_setid         := outArr(0);
	f_date          := outArr(1);
	t_date          := outArr(2);
        out_retCode     :=  0;
        out_rec         := NULL;

------------------------------------------------------------
--Opening cursor
------------------------------------------------------------
        IF(NOT c1%ISOPEN) THEN
        --{
        out_retCode:= 0;
        open c1;
        --}
        END IF;
-------------------------------------------------------------
--Fetching Data
-------------------------------------------------------------
        IF(c1%ISOPEN)  THEN
        FETCH C1
        INTO v_lockno,v_tran_id,v_tran_date;
        end if;
        if (c1%ISOPEN AND c1%NOTFOUND) THEN
        --{
            close c1;
            out_retcode := 1;
            return;
        --}
        end if;
------------------------------------------------------------
--Fetching Limits and Expiry Date
------------------------------------------------------------

begin
	SELECT NVL(SUM(paid_amount),0)
	INTO v_rentamt
   	FROM lcpd
   	WHERE locker_number = v_lockno
   	AND remarks = 'LOCKER RENT'
   	AND tran_id = v_tran_id
   	AND tran_date = v_tran_date
	AND PAID_AMOUNT > 0;
	exception when no_data_found then
		v_rentamt := 0;
end;

begin
	SELECT NVL(SUM(paid_amount),0)
	INTO v_taxamt
	FROM lcpd
	WHERE locker_number = v_lockno
	AND remarks = 'LOCKER SERVICE TAX RECOVERED'
	AND tran_id = v_tran_id
	AND tran_date = v_tran_date;
	exception when no_data_found then
		v_taxamt := 0;
end;

begin
	SELECT NVL(SUM(paid_amount),0)
	INTO v_chrgamt
	FROM lcpd
	WHERE locker_number = v_lockno
	AND remarks NOT IN ('LOCKER RENT','LOCKER SERVICE TAX RECOVERED','LOCKER PENAL RENT',
			    'LOCKER BREAK OPEN CHARGE ADVN','LOCKER BREAK OPEN CHARGES')
	AND tran_id = v_tran_id
	AND tran_date = v_tran_date;
	exception when no_data_found then
                v_chrgamt := 0;
end;
begin
        SELECT NVL(SUM(paid_amount),0)
        INTO v_penalamt
	FROM lcpd
        WHERE locker_number = v_lockno
        AND remarks = 'LOCKER PENAL RENT'
	AND tran_id = v_tran_id
        AND tran_date = v_tran_date;
        exception when no_data_found then
                v_penalamt := 0;
end;

begin
        SELECT NVL(SUM(paid_amount),0)
        INTO v_breakamt
	FROM lcpd
        WHERE locker_number = v_lockno
        AND remarks IN ('LOCKER BREAK OPEN CHARGE ADVN','LOCKER BREAK OPEN CHARGES')
	AND tran_id = v_tran_id
        AND tran_date = v_tran_date;
        exception when no_data_found then
                v_breakamt := 0;
end;

begin
	SELECT DISTINCT(TRAN_TYPE)
	INTO v_mode
	FROM HTD
	WHERE trim(tran_id) = v_tran_id
        AND tran_date = v_tran_date;
	exception when no_data_found then
		begin
			SELECT DISTINCT(TRAN_TYPE)
			INTO v_mode
			FROM DTD
			WHERE trim(tran_id) = v_tran_id
			AND tran_date = v_tran_date;
			exception when no_data_found then
				v_mode := 'T';
		end;
end;

v_totalamt := v_rentamt + v_taxamt + v_chrgamt + v_penalamt + v_breakamt;

        out_rec := 	v_mode		||'|'||
			v_tran_date	||'|'||
			v_lockno	||'|'||
			v_rentamt	||'|'||
			v_taxamt	||'|'||
			v_chrgamt	||'|'||
			v_penalamt	||'|'||
			v_breakamt	||'|'||
			v_totalamt;

END LCKPAYREC;
END LCKPAYREC;
/
DROP  PUBLIC SYNONYM LCKPAYREC
/
CREATE PUBLIC SYNONYM LCKPAYREC FOR LCKPAYREC
/
GRANT EXECUTE ON LCKPAYREC to  tbagen, tbautil, tbacust,tbaadm
/
