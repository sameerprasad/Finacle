rem:  Ramaswamy  -  17-july-1998 
rem:  balances in Fc deposits   -  R-Return V para
alter session set nls_date_format='DD-MM-YYYY';
accept dt1 prompt  "ENTER DATE OF REPORT(DD-MM-YYYY):::"
accept solid prompt "PLEASE ENTER FOUR DIGIT SOL ID OF REPORT BRANCH : "
set head off
set termout off
set verify off
set echo off
set feedback off
set numformat b999,99,99,999.99
break on crncy_code skip 1
compute sum of sum(f.tot_cr_bal+tot_Dr_bal) on crncy_code
spool rrtnbal
select 'V.   Aggregate Balances as of &dt1' from dual;
select '________________________________________' from dual;
select '' from dual;
select 'A. EEFC ACCOUNTS' from dual;
select ' ' from dual;
select g.gl_sub_head_code,gl_sub_head_Desc,
f.crncy_code,sum(f.tot_cr_bal+tot_Dr_bal) 
from gst f, gsh g
where g.gl_sub_head_code = f.gl_sub_head_code
and f.tran_Date = '&dt1'
and g.gl_sub_head_code in ('05030','08030','20030')
and g.sol_id = f.sol_id
and g.sol_id = '&solid'
and f.sol_id = '&solid'
group by g.gl_sub_head_code,f.crncy_code,gl_sub_head_desc
order by 3
/
select 'B. EFC ACCOUNTS' from dual;
select ' ' from dual;
select 'C. RFC ACCOUNTS' from dual;
select ' ' from dual;
select g.gl_sub_head_code,gl_sub_head_Desc,f.crncy_code,
sum(f.tot_cr_bal+tot_Dr_bal) 
from gst f, gsh g
where g.gl_sub_head_code = f.gl_sub_head_code
and f.tran_Date = '&dt1'
and g.gl_sub_head_code in ('05040','08040','20040')
and g.sol_id = f.sol_id
and g.sol_id = '&solid'
and f.sol_id = '&solid'
group by g.gl_sub_head_code,f.crncy_code,gl_sub_head_desc
order by 3
/
select 'D. ESCROW F.C ACCOUNTS' from dual;
select ' ' from dual;
select ' ' from dual;
select 'E. FCNR(B) ACCOUNTS' from dual;
select ' ' from dual;
select g.gl_sub_head_code,gl_sub_head_desc,
f.crncy_code,sum(f.tot_cr_bal+tot_Dr_bal) 
from gst f, gsh g
where g.gl_sub_head_code = f.gl_sub_head_code
and f.tran_Date = '&dt1'
and g.gl_sub_head_code in ('20010')
and g.sol_id = f.sol_id
and g.sol_id = '&solid'
and f.sol_id = '&solid'
group by g. gl_sub_head_code,f.crncy_code,gl_sub_head_desc
order by 3
/
select 'F. OTHER F.C ACCOUNTS' from dual;
select g.gl_sub_head_code,gl_sub_head_desc,
f.crncy_code,sum(f.tot_cr_bal+tot_Dr_bal) 
from gst f, gsh g
where g.gl_sub_head_code = f.gl_sub_head_code
and f.tran_Date = '&dt1'
and g.gl_sub_head_code in ('05026','08026','20026')
and g.sol_id = f.sol_id
and g.sol_id = '&solid'
and f.sol_id = '&solid'
group by g.gl_sub_head_code,f.crncy_code,gl_sub_head_desc
order by 3
/
spool off
exit
