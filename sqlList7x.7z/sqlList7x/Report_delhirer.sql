--------------------------------------------
--File Name   : Report_delhirer.sql 
--Description : Deleted Hirer Report 
--Author      : Priscilla & Vijay
--Date        : 01-06-2010
------------------------------------------

set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_delhirer.lst

DECLARE

lv_solid         gam.sol_id%type :='&1';
date1	         cljh.LCHG_TIME%type:= '&2';
date2	         cljh.LCHG_TIME%type:= '&3';
MH_HIRER_NAME	 cmg.cust_name%type;

CURSOR c1 IS
select cljh.sol_id,
       wlckm.rack_id,
       wlckm.LOCKER_TYPE,
       cljh.locker_num,
	   cljh.CUST_JH_ID ,
       substr(cmg.CUST_NAME,'1','40') Hirer_name,
       cljh.LKR_JH_SRL_NO Hirer_Number,
	   cljh.CUST_MH_ID,
       cljh.LCHG_TIME Deletion_Date
from	cmg,wlckm,cljh,clmt
where	wlckm.LOCKER_NUM=cljh.LOCKER_NUM
and	clmt.LOCKER_NUM=cljh.LOCKER_NUM
and	clmt.LOCKER_NUM= wlckm.LOCKER_NUM
and	cljh.sol_id=clmt.sol_id
and clmt.sol_id = wlckm.sol_id
and	clmt.cust_id = cljh.cust_mh_id
and	cljh.sol_id = lv_solid
and	lpad(cljh.CUST_JH_ID,9,' ')=cmg.cust_id
and	cljh.del_flg = 'Y'
and	clmt.del_flg != 'Y'
and	wlckm.del_flg != 'Y'
and	wlckm.ENTITY_CRE_FLG != 'N'
and	to_date(cljh.LCHG_TIME,'DD-MM-YYYY') between to_date(date1,'DD-MM-YYYY') and to_date(date2,'DD-MM-YYYY')
order by 6,4;

BEGIN

    for f1 in c1
    loop
		BEGIN
			select substr(CUST_NAME,'1','40') into  MH_HIRER_NAME from cmg where cust_id=lpad(f1.CUST_MH_ID,9,' ');
		END;
dbms_output.enable(buffer_size => NULL);
dbms_output.put_line( f1.sol_id         ||'|'||
		      f1.rack_id        		||'|'||	
		      f1.LOCKER_TYPE    		||'|'||	
		      f1.locker_num     		||'|'||
			  f1.CUST_JH_ID				||'|'||
		      f1.Hirer_name     		||'|'|| 
			  f1.Hirer_Number 			||'|'||
			  f1.CUST_MH_ID				||'|'||
			  MH_HIRER_NAME          ||'|'||
		      f1.Deletion_Date	 
		      ); 
   end loop; 
END;
/
spool off
