REM####################################################################
REM File Name   : SPCTC1_MOD.sql
REM Description : Suppliers Credit Info for TC-1
REM Author      : Paresh Maru
REM Date        : 17-01-2011
REM Module  : Supplier Credit
REM####################################################################

REM TABLE NAME: SUP_CR_TC1_MOD

REM SYNONYM:    SPCTC1_MOD

drop table icici.SUP_CR_TC1_MOD
/
drop public synonym SPCTC1_MOD
/
create table icici.SUP_CR_TC1_MOD
(
suppliers_credit_ref_no		VARCHAR2(30),
dc_ref_no			VARCHAR2(16),
dc_sol_id			VARCHAR2(8),
Date_of_approval		DATE,
Name_of_lender			VARCHAR2(26),
Country_of_lender		VARCHAR2(16),
Amount				number(20,4),
Currency			VARCHAR2(4),
Rate_of_Interest		VARCHAR2(30),
Other_chrg_usd			number(20,4),
All_in_Cost			number(20,4),
Period_of_Credit		number(20,4),
Unit_of_time_period		VARCHAR2(4),
Type_of_Credit1			VARCHAR2(4),
Type_of_Credit2			VARCHAR2(4),
Description			VARCHAR2(16),
Category			VARCHAR2(16),
ENTITY_CRE_FLG			CHAR(1),
DEL_FLG				CHAR(1),
LCHG_USER_ID			VARCHAR2(15),
LCHG_TIME			DATE,
RCRE_USER_ID			VARCHAR2(15),
RCRE_TIME			DATE,
conv_rate			number(21,10),
equi_usd_amt		number(21,10),
bill_no				VARCHAR2(15)
)
/* STORE_START */
TABLESPACE ICICI_CUST_SMALL
/* STORE_END */
/
create public synonym SPCTC1_MOD for icici.SUP_CR_TC1_MOD
/
grant select, insert, update, delete on SPCTC1_MOD to tbagen
/
grant select on SPCTC1_MOD to tbacust
/
grant select on SPCTC1_MOD to tbautil
/
grant all on SPCTC1_MOD to tbaadm
/
create unique index IDX_SPCTC1_MOD on SPCTC1_MOD(suppliers_credit_ref_no,dc_ref_no,dc_sol_id)
/

