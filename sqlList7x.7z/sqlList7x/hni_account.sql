set verify off
set feedback off
set termout off
set serveroutput on size 1000000
set pagesize 0
set linesize 150
set trims on
spool hni_account.txt

declare
CURSOR acidcur is  select gam.cust_id cust_id, foracid,clr_bal_amt,acct_opn_date,acct_name ,cust_stat_code
    from gam,cmg where
	primary_sol_id='&1'
	and cust_stat_code in ('HNI10','HNI00','HNI25','HNI50','HNI1L','HNI3L','HNI5L','HNI')
	and acct_opn_date = '&2'
	and gam.cust_id=cmg.cust_id;
acidrec acidcur%rowtype;

begin

        open acidcur;
        loop
        fetch acidcur into acidrec;
        exit when acidcur%notfound;

DBMS_OUTPUT.PUT_LINE(acidrec.cust_id||'|'||acidrec.foracid||'|'||acidrec.clr_bal_amt||'|'||acidrec.acct_opn_date ||'|'||acidrec.acct_name||'|'||acidrec.cust_stat_code);

	end loop;
	close acidcur;

END;
/
spool off
