Rem     This file will create LOCKER_MIGRATION_FAILURE_TABLE
Rem     with the following characteristics.

Rem TABLE NAME: LOCKER_MIGRATION_FAILURE_TABLE

Rem SYNONYM:    LOCKER_MIGRATION_FAILURE_TABLE

drop table LOCKER_MIGRATION_FAILURE_TABLE
/
drop public synonym LCFAIL
/
create table tbaadm.LOCKER_MIGRATION_FAILURE_TABLE
( 
	sol_id varchar2(8),
	locker_num	varchar2(12),
	table_name varchar2(3)
)
/
create public synonym LCFAIL for tbaadm.LOCKER_MIGRATION_FAILURE_TABLE
/
grant select, insert, update, delete on LCFAIL to tbagen
/
grant select on LCFAIL to tbacust
/
grant select on LCFAIL to tbautil
/