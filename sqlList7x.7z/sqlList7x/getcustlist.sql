set head off
set feedback off
set pages 0
set trims on
set termout off
set verify off
spool custlist.lst
select ltrim(cust_id)
from gam 
where 
sol_id = '&1'
and substr(ltrim(cust_id),1,2) = '50'
and cust_id > lpad('&2',9)
and cust_id < lpad('&3',9)
/
spool off

