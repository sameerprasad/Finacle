-- Program Name    : fsgPspTmpDump.sql
-- Author          : Mandar Raddi
-- Date Written	   : 27-Feb-2001
--
-- -----------------------------------------------------------------------------------#   
-- Brief Description :                                                                #
-- -----------------------------------------------------------------------------------#
-- This PL/SQL program is responsible for creating Customer ID and Accout ID lists    #
-- in the PSP_TMP table for the given Sol ID. These two lists are required in the     #
-- Customer Statement generation process. This program creates the List id as         # 
-- Run ID (Input to the program) + 'C' for customer ids and Run ID + 'A' for accounts #
-- for the customers.                                                                 #
-- -----------------------------------------------------------------------------------# 
--                                 Version History                                    #
-- -----------------------------------------------------------------------------------#
--   Ver.No |     Date   |    Author    |           Reason For Change                 #
-- -----------------------------------------------------------------------------------#
--     1    | 27-02-2001 | Mandar Raddi | Initial Release                             #
-- -----------------------------------------------------------------------------------#

set serveroutput on size 1000000
set feedback off
set verify   off
set termout   off
set pages 0
set linesize 512
set trims on
spool &1-&2-&3-&4

variable maxIdType char(1);
-- -------------------------#
-- Start of DELCARE Section 
-- -------------------------#

DECLARE
matched				number;
cnt					number;
cmgKey				fsg_cfg.key_type%TYPE;
custNreFlag			varchar2(1);
wbgCust				char(1);
firstAcc			GAM.FORACID%Type;
beginCustId			ICICI_CIFT.CUST_ID%Type;
endCustId			ICICI_CIFT.CUST_ID%Type;
ciftCustId			ICICI_CIFT.CUST_ID%Type;
ciftEmailId			ICICI_CIFT.EMAIL_ID%Type;
ciftStmtReqd		ICICI_CIFT.STMT_REQD%Type;
stmtReqd			CHAR;
cmgCustStatCode		varchar2(10);
tmpCustStatCode     CMG.CUST_STAT_CODE%Type;
gamForacid			GAM.FORACID%Type;
gamAcid				GAM.ACID%Type;
custSolId			PSP_TMP.HOME_SOL_ID%Type;
custRecType			VARCHAR(3);
custSubRecType		VARCHAR(3);
pspCustListId		PSP_TMP.LISTID%Type;
pspAcctListId		PSP_TMP.LISTID%Type;
endOfCiftCursor     NUMBER;
endOfGamCursor      NUMBER;
acctFound			NUMBER;
gamTxn				NUMBER;
chooseThisCustId    CHAR;
custStatSelectFlag  CHAR;
-- Sri 3.7.02 begin
stmtFreq			char;
custSel				char;
custStat			CMG.CUST_STAT_CODE%Type;
accExist			number(1);
cfgKeyVal			varchar(5);
-- Sri 3.7.02 end
custStatArr 		iciArray.arrayType;
custStatCodes		VARCHAR2(100);
custStatCnt			NUMBER(5);
commitCnt			NUMBER(5);
step				NUMBER(5);
likeStr				varchar2(25);
likeStrAcc			varchar2(25);
likeStrCus			varchar2(25);
idType				CHAR(2);
idTypeOld           CHAR(1);
dispMode      		CHAR;
-- Changes for custnreflg
cmgCustNreFlag		cmg.cust_nre_flg%type;
	
cmgTitleName		varchar2(200);
cmgAddr1			CMG.cust_comu_addr1%TYPE;
cmgAddr2			CMG.cust_comu_addr2%TYPE;
cmgCityCode			CMG.cust_comu_city_code%TYPE;
cmgStateCode		CMG.cust_comu_state_code%TYPE;
cmgCntryCode		CMG.cust_comu_cntry_code%TYPE;
cmgPinCode			CMG.cust_comu_pin_code%TYPE;
cmgPhone1			CMG.cust_comu_phone_num_1%TYPE;
cmgPhone2			CMG.cust_comu_phone_num_2%TYPE;
cmgEmployer_id      CMG.employer_id%TYPE;
cityDesc			RCT.ref_desc%TYPE;
stateDesc			RCT.ref_desc%TYPE;
cntryDesc			RCT.ref_desc%TYPE;
nreCntryCode		NCT.nre_cntry_code%Type;


-- Sri 13-01-2003
cmgCustConst		CMG.cust_const%TYPE;
custConst			CMG.cust_const%TYPE;
cmgConstKey			CMG.cust_const%TYPE;
tmpConst			CMG.cust_const%TYPE;
-- Sri 13-01-2003

carRec				varchar2(500);
runId				varchar2(10);
cnt_negative        NUMBER(2);
lv_cust_id			CMG.cust_id%TYPE;

negFlg              varchar2(2);

-- VD Added for segregation of dump based on segements
custSegCode                      varchar2(10);
hcmgCustStatCode                 varchar2 (12);
cmgConstKey1                   CMG.cust_const%TYPE;
cmgKey1                        fsg_cfg.key_type%TYPE;

CURSOR ciftCur IS
SELECT	CUST_ID, lower(EMAIL_ID), stmt_reqd 
FROM ICICI_CIFT
WHERE	CUST_ID BETWEEN beginCustId AND endCustId
AND	HOME_SOL_ID = custSolId
AND	STMT_REQD != 'N'
AND	STMT_REQD != 'U'
ORDER BY cust_id;


CURSOR gamCur IS 
SELECT	acid,foracid
FROM	GAM
WHERE	CUST_ID = ciftCustId
AND	(SCHM_TYPE = 'SBA' OR ACCT_PREFIX = '05' OR ACCT_PREFIX = '51')
AND	((ACCT_CLS_FLG = 'N' AND ACCT_OPN_DATE <= '&8') OR
	 (ACCT_CLS_FLG = 'Y' AND ACCT_CLS_DATE > '&8'))
AND	ENTITY_CRE_FLG = 'Y'
and last_any_tran_date >= '&7' order by foracid;


-- santosh 25-05-2005

CURSOR stmtCur IS
SELECT  stmt_flag, stmt_freq, print, email
FROM ICICI_STMT_MODE
WHERE stmt_freq = stmtFreq;


-- --------------------------------------------------------------------------------#
-- PROCEDURE to Select customer details from CMG. The customer id is selected from #
-- ICICI_CIFT for the input SOL ID                                                 #
-- --------------------------------------------------------------------------------#

PROCEDURE getCmgData(dummy NUMBER) IS
BEGIN
	BEGIN
		step := 3;
		SELECT	cust_title_code || '.' || cust_name,
				cust_comu_addr1,
				cust_comu_addr2,
				cust_comu_city_code,
				cust_comu_state_code,
				cust_comu_cntry_code,
				cust_comu_pin_code,
				cust_comu_phone_num_1,
				cust_comu_phone_num_2,
				cust_stat_code,
				cust_const,
				cust_nre_flg
		INTO	cmgTitleName,
				cmgAddr1,
				cmgAddr2,
				cmgCityCode,
				cmgStateCode,
				cmgCntryCode,
				cmgPinCode,
				cmgPhone1,
				cmgPhone2,
				cmgCustStatCode,
				cmgCustConst,
				cmgCustNreFlag
		FROM	CMG
		WHERE	CUST_ID = ciftCustId;

		tmpCustStatCode := '';

		--if((cmgCustStatCode = '*') or (cmgCustStatCode = '**') or (cmgCustStatCode = '***') or (cmgCustStatCode = 'FAA05') or (cmgCustStatCode = 'GAA05')) then
        --   tmpCustStatCode := 'QAB';
        --end if;

		if(cmgCustNreFlag = 'Y') then
			cmgCustStatCode := 'NRI';
		end if;




-- VD added for Segregation of dump based on segments
 if((cmgCustStatCode = '1ICIC') or (cmgCustStatCode = '1STF') or (cmgCustStatCode = '1STFF')  or (cmgCustStatCode = '2ICIC')
 or (cmgCustStatCode = '2STF')  or (cmgCustStatCode = '2STFF')  or (cmgCustStatCode = 'PICIC')  or (cmgCustStatCode = 'PSTFF') or (cmgCustStatCode = 'XFSAF')) then
            cmgCustStatCode := 'STF';
        end if;


 -- JD added for sending GPC cover page for HNIPB, HNIPT,  HNIPS, HNIS and HNIM status codes.

  if((cmgCustStatCode != 'HNIPB') and (cmgCustStatCode != 'HNIPT') and (cmgCustStatCode != 'HNIPS') and (cmgCustStatCode != 'HNIS') and (cmgCustStatCode != 'HNIM')) then
                        if(substr(cmgCustStatCode,1,3) = 'HNI') then
                                cmgCustStatCode := 'HNI';
                        end if;
                else
                        if(cmgCustStatCode = 'HNIPB') then
                                cmgCustStatCode := 'HNB';
                        end if;
                        if(cmgCustStatCode = 'HNIPT') then
                                cmgCustStatCode := 'HNT';
                        end if;
                        if((cmgCustStatCode = 'HNIPS') or (cmgCustStatCode = 'HNIS')) then
                                cmgCustStatCode := 'HNS';
                        end if;
                        if(cmgCustStatCode = 'HNIM') then
                                cmgCustStatCode := 'HNM';
                        end if;
                end if;



hcmgCustStatCode := cmgCustStatCode;
        custSegCode := '';
    begin
--        select substr(SEGEMENT,4,2) into custSegCode from ICICI_CUST_SEG where CUST_ID = ciftCustId;
        select substr(SEGEMENT,instr(SEGEMENT,'|')+1)  into custSegCode from ICICI_CUST_SEG where CUST_ID = ciftCustId;
        exception
         when no_data_found THEN
                        custSegCode := 'NON';
    end;

         if ( custSegCode = 'Z' or custSegCode = 'z' or custSegCode = 'CE' or custSegCode = 'GPC' ) then
		    custSegCode := 'GB';
			end if;


     cmgKey1 := 0;
        begin
                     select key_type into cmgKey1 from fsg_cfg where prg_type = 'FSG'
                     and (key_type = 99 or key_type = 100) and key_value = cmgCustConst;
                     exception
                     when others then
                     cmgKey1 := 0;
            end;

   if (custSegCode = 'WS') then
                                if (substr(hcmgCustStatCode,1,3) = 'STF') then
                                   cmgCustStatCode :=  'STFWM';
                                end if;

if ( ( substr(hcmgCustStatCode,1,2) != 'HN')  and ( substr(hcmgCustStatCode,1,3) != 'STF') and  (substr(hcmgCustStatCode,1,3
) != 'NRI') and  ( cmgKey1 != '100') and ( cmgKey1 != '99') ) then
                                   cmgCustStatCode := 'ICIFSWM' ;
                              end if;

 --          if ( (cmgCustStatCode = 'HNIP') or (cmgCustStatCode = 'HNIC') or (cmgCustStatCode = 'HNIPW')) then
 --                               cmgCustStatCode := 'ICIFSWM' ;
 --                            end if;
                       
           end if;


     if (custSegCode = 'GS' or custSegCode = 'TS') then
                               if(substr(hcmgCustStatCode,1,3) = 'STF') then
                                        cmgCustStatCode := 'STFPB';
                                end if;
if (( substr(hcmgCustStatCode,1,2) != 'HN')  and ( substr(hcmgCustStatCode,1,3) != 'STF') and  (substr(hcmgCustStatCode,1,3)
!= 'NRI') and  ( cmgKey1 != '100') and  ( cmgKey1 != '99') ) then
                                  cmgCustStatCode := 'ICIFSPB' ;
                               end if;

 --           if ( (cmgCustStatCode = 'HNIP') or (cmgCustStatCode = 'HNIC') or (cmgCustStatCode = 'HNIPW')) then
 --                               cmgCustStatCode := 'ICIFSPB' ;
 --                           end if; 

                  end if;


 if (custSegCode = 'GB' or custSegCode = 'NON') then
                               if(substr(hcmgCustStatCode,1,3) = 'STF') then
                                        cmgCustStatCode := 'STFGB';
                                end if;

if ( ( substr(hcmgCustStatCode,1,2) != 'HN')  and (substr(hcmgCustStatCode,1,3) != 'STF') and (substr(hcmgCustStatCode,1,3)
!= 'NRI') and ( cmgKey1 != '100') and ( cmgKey1 != '99') ) then
                                    cmgCustStatCode := 'ICIFSGB' ;
                             end if;
 --              if ( (cmgCustStatCode = 'HNIP') or (cmgCustStatCode = 'HNIC') or (cmgCustStatCode = 'HNIPW')) then
 --                               cmgCustStatCode := 'ICIFSGB' ;
 --                           end if;

               end if;



		if (cmgCityCode is not null) then
			BEGIN
			SELECT	ref_desc
			INTO	cityDesc
			FROM	RCT
			WHERE	ref_rec_type = '01'
			AND		ref_code = cmgCityCode;
			EXCEPTION WHEN OTHERS THEN NULL;
			END;
		else
			cityDesc := '';
		end if;

		if (cmgStateCode is not null) then
			BEGIN
			SELECT	ref_desc
			INTO	stateDesc
			FROM	RCT
			WHERE	ref_rec_type = '02'
			AND		ref_code = cmgStateCode;
			EXCEPTION WHEN OTHERS THEN NULL;
			END;
		else
			stateDesc := '';
		end if;

		if (cmgCntryCode is not null) then
			BEGIN
			SELECT	ref_desc
			INTO	cntryDesc
			FROM	RCT
			WHERE	ref_rec_type = '03'
			AND		ref_code = cmgCntryCode;
			EXCEPTION WHEN OTHERS THEN NULL;
			END;
		else
			cntryDesc := '';
		end if;

		EXCEPTION
		WHEN NO_DATA_FOUND THEN 
			chooseThisCustId := 'N';
			RETURN;
	END;

	IF (custStatSelectFlag = 'O') THEN
		chooseThisCustId := 'N';
	ELSE
		chooseThisCustId := 'Y';
	END IF;

	FOR item IN 0..TO_NUMBER(custStatCnt - 1) LOOP
	BEGIN
		IF (custStatSelectFlag = 'E' AND cmgCustStatCode = custStatArr(item)) THEN
			chooseThisCustId := 'N';
			RETURN;
		END IF;
-- JD added for Annual statement to add R flag customers.		
		IF (custStatSelectFlag = 'O' AND cmgCustStatCode = custStatArr(item)) THEN
			chooseThisCustId := 'Y';
			RETURN;
		END IF;
	END;
	END LOOP;

END getCmgData;


PROCEDURE insertPspTmp( pspListId VARCHAR2,
	                pspEntityId VARCHAR2,
	                pspEntityType CHAR,
			pspHomeSolId VARCHAR2) IS
BEGIN
	step := 5;
	INSERT INTO
	PSP_TMP
		(LISTID
		,ENTITY_ID
		,ID_TYPE
		,HOME_SOL_ID)
	VALUES
		(pspListId
		,pspEntityId
		,pspEntityType
		,pspHomeSolId);
END insertPspTmp;


PROCEDURE processGamCursor( dummy NUMBER) IS
BEGIN
step := 4;
FOR gamCur_rec in gamCur
LOOP --{
    begin
	IF( gamCur%NOTFOUND ) then
		endOfGamCursor := 1;
		RETURN;
	END IF; 
	gamTxn := 0;
	begin
       	SELECT	1
		INTO	gamTxn
		FROM	DUAL
		WHERE	EXISTS(	SELECT	*
						FROM	CTD 
						WHERE	acid=gamCur_rec.acid
						AND		tran_date >= '&7'
						AND 	tran_date <= '&8');
		EXCEPTION
		WHEN NO_DATA_FOUND THEN
			gamTxn := 0;
	end;
	if(gamTxn > 0) then
		acctFound := 1;	
		if(substr(gamCur_rec.foracid,5,2) ='51') then
		if(stmtReqd='E') then
			insertPspTmp(pspAcctListId, gamCur_rec.foracid, idTypeOld, custSolId);
		end if;
		else
			insertPspTmp(pspAcctListId, gamCur_rec.foracid, idTypeOld, custSolId);
		end if;
	end if;
	if (cnt = 0) then
		firstAcc := gamCur_rec.foracid;
		cnt := 1;
	end if;
    end;
end loop;
END processGamCursor;
		

PROCEDURE processCiftCursor( dummy NUMBER ) IS
BEGIN
	step := 2;
	FETCH ciftCur 
	INTO ciftCustId,
		ciftEmailId,
		ciftStmtReqd;

	IF (ciftCur%NOTFOUND) then
		endOfCiftCursor := 1;
		RETURN;
	END IF;

	custSel := 'N';
	wbgCust := 'N';

	-- Sri 3.7.02 (begins here)

	if(stmtFreq = 'M') then

	--------------------santosh 25-05-2005

	FOR stmtRec in stmtCur
    LOOP

            EXIT WHEN stmtCur%NOTFOUND;
          -- Check for stmt_reqd. If M / E, select customer

            if(ciftStmtReqd = stmtRec.stmt_flag and (dispMode = 'A' or dispMode = stmtRec.print or dispMode = stmtRec.email)) then
                custSel := 'Y';
            end if;

            -- if(ciftStmtReqd = 'E' and (dispMode = 'A' or dispMode = 'E')) then
            --    custSel := 'Y';
            -- end if;

        END LOOP;
		
		--------------------------

		-- Check for customer status

		if((ciftStmtReqd = 'Y' or ciftStmtReqd = 'T') and (dispMode = 'A' or dispMode = 'Y')) then
			begin
				select nvl(cust_stat_code,'*'),nvl(employer_id,'*') into custStat,cmgEmployer_id
                from cmg where cust_id = ciftCustId;

				if(custStat != '*') then
					select key_value into cfgKeyVal from fsg_cfg where prg_type = 'FSG'
					and key_type = 1 and key_value in (custStat,cmgEmployer_id);

					if(cfgKeyVal = custStat or cmgEmployer_id = cfgKeyVal) then
						custSel := 'Y';
					end if;
				end if;

				exception 
				when others then
					null;
			end;	

			-- Check for customer const codes (for free stmts)
			
			begin
				select nvl(cust_const,'*') into custConst from cmg where cust_id = ciftCustId;

				if(custConst != '*') then
					select key_value into cfgKeyVal from fsg_cfg where prg_type = 'FSG'
					and key_type = 3 and key_value = custConst;

					if(cfgKeyVal = custConst) then
						custSel := 'Y';
					end if;
				end if;

				exception
				when others then
					null;

			end;

			-- Check for accounts in select schm_type / schm_code

			accExist := 0;

			begin
				select 1 into accExist from dual where exists
				(select acid from gam where cust_id = ciftCustId and acct_crncy_code = 'INR' and schm_type in
				(select key_value from fsg_cfg where prg_type = 'FSG' and key_type = 2)
				 and acct_cls_flg != 'Y');

				if(accExist = 1) then
					custSel := 'Y';
				end if;

				exception 
				when others then
					null;
			end;
		end if;

		cnt_negative := 0;
        if(custSel = 'Y' and ciftStmtReqd != 'E') then
            begin
                select count(*) into cnt_negative from ici_negative_bal where cust_id = ciftCustId and balance < 0;

            exception
                when others then
                    cnt_negative := 0;
            end;
            if( cnt_negative > 0) then
                custSel := 'N';
            end if;
        end if;

		if(custSel = 'N') then
			return;
		end if;

	end if;

	if(stmtFreq = 'Q') then

		-- By default select all customers


		 --------------------santosh 25-05-2005

        FOR stmtRec in stmtCur
        LOOP
                EXIT WHEN stmtCur%NOTFOUND;

                if (ciftStmtReqd = stmtRec.stmt_flag and (dispMode = 'A' or dispMode = stmtRec.email or dispMode = stmtRec.print)) then

                    if( ciftStmtReqd = 'S' or ciftStmtReqd = 'T' ) then
                        custSel := 'N';
                    else
                        custSel := 'Y';
                    end if;

                end if;

        END LOOP;

        --------------------------------


		-- Check for stmt_reqd. If Y / E, select customer

        --if(ciftStmtReqd = 'Y' or ciftStmtReqd = 'E') then
        --    custSel := 'Y';
        --end if;

		--
		-- 'De-select' customers with stmt_reqd as 'M' as they rcv monthly stmts
		--
		if(ciftStmtReqd = 'M') then
			custSel := 'N';
		end if;


		-- santosh 09-06-05
		-- No quarterly print stmt for NRI Customers who opted for Email

			
		if(ciftStmtReqd = 'E') then
            begin
                select nvl(cust_nre_flg,'*') into custStat from cmg where cust_id = ciftCustId;

				if(custStat = 'Y') then
               		custSel := 'N';
				end if;

			exception
                when others then
                    null;

			end;
				
		end if;


		-- For US based NRI customers, only annual stmts are given. No quarterly print

		if(ciftStmtReqd = 'Y') then
			begin
				select nvl(cust_nre_flg,'*') into custStat from cmg where cust_id = ciftCustId;
				if(custStat = 'Y') then
					begin
						select nvl(nre_cntry_code,'*') into nreCntryCode from nct where cust_id = ciftCustId;

						if(nreCntryCode = 'US') then
							custSel := 'N';
						end if;

						exception
						when others then
							null;
					end;
				end if;

				exception
				when others then
					null;
            end;
		end if;

		--
        -- Check for customer status. If cust is rcving monthly printed stmt, 'de-select'
		-- (if cust stmt_reqd is 'E', then cust will get print stmt every qrtr irrespective
		-- of cust_stat_code

		if(ciftStmtReqd = 'Y' or ciftStmtReqd = 'T') then
        	begin
            	select nvl(cust_stat_code,'*'),nvl(employer_id,'*') into custStat,cmgEmployer_id
				from cmg where cust_id = ciftCustId;

            	if(custStat != '*') then
                	select key_value into cfgKeyVal from fsg_cfg where prg_type = 'FSG'
                	and key_type = 1 and key_value in (custStat,cmgEmployer_id);

                	if(cfgKeyVal = custStat or cmgEmployer_id = cfgKeyVal) then
                    	custSel := 'N';
                	end if;
            	end if;

            	exception
            	when others then
                	null;
        	end;

            -- Check for customer const codes (for free stmts). If receiving free 
			-- monthly stmts, do not consider for quarterly statements

            begin
                select nvl(cust_const,'*') into custConst from cmg where cust_id = ciftCustId;

                if(custConst != '*') then
                    select key_value into cfgKeyVal from fsg_cfg where prg_type = 'FSG'
                    and key_type = 3 and key_value = custConst;

                	if(cfgKeyVal = custConst) then
                    	custSel := 'N';
                	end if;
				end if;

                exception
                when others then
                    null;

            end;

        	-- Check for accounts in select schm_type / schm_code

        	accExist := 0;

        	begin
            	select 1 into accExist from dual where exists
            	(select acid from gam where cust_id = ciftCustId and acct_crncy_code = 'INR' and schm_type in
                	(select key_value from fsg_cfg where prg_type = 'FSG' and key_type = 2) 
					and acct_cls_flg != 'Y');

            	if(accExist = 1) then
                	custSel := 'N';
            	end if;

            	exception
            	when others then
                	null;
        	end;
		end if;

		-- set ciftStmtReqd = 'Y' for all custs irrespective of stmt_reqd

		cnt_negative := 0;
        if(custSel = 'Y') then
            begin
                select count(*) into cnt_negative from ici_negative_bal where cust_id = ciftCustId and balance < 0;

            exception
                when others then
                    cnt_negative := 0;
            end;
            if( cnt_negative > 0) then
                custSel := 'N';
            end if;
        end if;

		ciftStmtReqd := 'Y';

		if(custSel = 'N') then
			return;
		end if;

	end if;

	if(stmtFreq = 'Y') then

		-- Check for stmt_reqd. If Y / M / E select customer

		 --------------------santosh 25-05-2005

--        FOR stmtRec in stmtCur
--        LOOP
--
--            EXIT WHEN stmtCur%NOTFOUND;
--
--            if (ciftStmtReqd = stmtRec.stmt_flag and (dispMode = 'A' or dispMode = stmtRec.email or dispMode = stmtRec.print)) then
--            if (ciftStmtReqd in ('R','A') and (dispMode = 'A' or dispMode = stmtRec.email or dispMode = stmtRec.print)) then
--                custSel := 'Y';
--            end if;
--
--        END LOOP;

          custSel := 'Y';

        -------------------------
		-- set ciftStmtReqd = 'Y' for all custs irrespective of stmt_reqd

		
		if((cmgCustStatCode != 'HNI') or (cmgCustStatCode != 'HNB') or (cmgCustStatCode != 'HNS') or (cmgCustStatCode != 'HNT') or (cmgCustStatCode != 'HNM') or (cmgCustStatCode != 'NRI') or (cmgCustStatCode != 'STF')) then

			cnt_negative := 0;
--			if(custSel = 'Y') then
			begin
				select count(*) into cnt_negative from ici_negative_bal where cust_id = ciftCustId and balance < 0;

			exception
				when others then
				cnt_negative := 0;
			end;

			if(negFlg = 'N') then
               custSel := 'N';
			   FOR stmtRec in stmtCur
        		LOOP

            		EXIT WHEN stmtCur%NOTFOUND;

            		if (ciftStmtReqd in ('R','A') and (dispMode = 'A' or dispMode = stmtRec.email or dispMode = stmtRec.print)) then
                		custSel := 'Y';
            		end if;

        		END LOOP;
				if( cnt_negative > 0) then
				  	 custSel := 'N';
				end if;

			elsif(negFlg = 'Y') then
               custSel := 'Y';
			   if(cnt_negative = 0) then 
					 custSel := 'N';
				end if;
			end if;

--			end if;

		end if;

		-- JD ends here

        -- For US based NRI customers, only annual stmts are given. No quarterly print

--        if(ciftStmtReqd = 'Y') then
--            begin
--                select nvl(cust_nre_flg,'*') into custStat from cmg where cust_id = ciftCustId;
--                if(custStat = 'Y') then
--                    begin
--                        select nvl(nre_cntry_code,'*') into nreCntryCode from nct where cust_id = ciftCustId;
--
--                        if(nreCntryCode = 'US') then
--                            custSel := 'N';
--                        end if;
--
--                        exception
--                        when others then
--                            null;
--                    end;
--                end if;
--
--                exception
--                when others then
--                    null;
--            end;
--        end if;


		if(custSel = 'N') then
			return;
		end if;

	end if;

	-- Sri 3.7.02 (ends here)

	getCmgData(0);

	IF (chooseThisCustId = 'N') THEN
		RETURN;
	END IF;

	endOfGamCursor := 0;
	acctFound := 0;
	cnt := 0;
	stmtReqd := ciftStmtReqd;
	firstAcc := '';
	processGamCursor(0);

	----------------------------------
	-- Sri 13-01-2003 for const. codes
	----------------------------------

	step := 9;
	tmpConst := '';
	cmgConstKey := '';
	begin
		select key_value,key_type into cmgConstKey, cmgKey from fsg_cfg where prg_type = 'FSG'
		and (key_type = 99 or key_type = 100) and key_value = cmgCustConst;

		if(cmgCustConst = cmgConstKey) then
			if(cmgKey = 99) then
				tmpConst := 'WBG';
			else
				tmpConst := 'SEG';
			end if;
			wbgCust := 'Y';
		end if;

		--if(tmpCustStatCode = 'QAB' and wbgCust != 'Y') then
        --    cmgCustStatCode := tmpCustStatCode;
        --end if;

		exception 
		when others then null;
	end;

	----------------------------------
	-- Sri 13-01-2003 for const. codes
	----------------------------------


	matched := 0;

	if (acctFound = 1 and cnt > 0) then --or ciftStmtReqd = 'E') and cnt > 0 ) then
		insertPspTmp(pspCustListId, ciftCustId, idTypeOld, custSolId);

		--if (ciftStmtReqd = 'E' ) then


		IF(wbgCust = 'N') THEN

			FOR stmtRec in stmtCur
         	LOOP

           		 EXIT WHEN stmtCur%NOTFOUND;


            		IF (ciftStmtReqd = stmtRec.stmt_flag) THEN

						matched := 1;

						IF (stmtRec.email = 'E' and (dispMode = 'A' or dispMode = 'E')) THEN

						dbms_output.put_line(custSolId              || '|' ||
                                ciftCustId              || '|01|0|' ||
                                ciftEmailId             || '|' ||
                                ltrim(rtrim(cmgTitleName))    || '|' ||
                                ltrim(rtrim(cmgAddr1))                || '|' ||
                                ltrim(rtrim(cmgAddr2))               || '|' ||
                                ltrim(rtrim(cityDesc))              || '|' ||
                                ltrim(rtrim(stateDesc)) || '|' ||
                                ltrim(rtrim(cntryDesc)) || ' - ' ||
                                ltrim(rtrim(cmgPinCode)) || '|' ||
                                cmgCustStatCode || '|' ||
                     			stmtRec.email ||'|'||firstAcc|| '|' ||'CustomerStateMent'||'|'||tmpConst);

						END IF;

						IF (stmtRec.print = 'Y' and (dispMode = 'A' or dispMode = 'Y')) THEN
					
								carRec := custSolId||'|'||ciftCustId||'|01|0|'||ltrim(rtrim(ciftEmailId))||'|'||
                ltrim(rtrim(cmgTitleName))||'|'||ltrim(rtrim(cmgAddr1))||'|'||
                ltrim(rtrim(cmgAddr2))||'|'||ltrim(rtrim(cityDesc))||'|'||
                ltrim(rtrim(stateDesc))||'|'||ltrim(rtrim(cntryDesc))||' - '||
                ltrim(rtrim(cmgPinCode))||'|'||cmgCustStatCode||'|'||'Y'||'|'||
                ltrim(rtrim(cmgPhone1))||' - '||ltrim(rtrim(cmgPhone2))||'|'||firstAcc||'|'||hcmgCustStatCode;
								
								if(length(carRec) > 255) then
									
										insert into ICICI_STMT_CUST_DETAIL values
                            			(
                       				          runId,custSolId,idType,carRec
           				                );
			                            COMMIT;

                				else
                    					dbms_output.put_line(carRec);
                				end if;
				
						END IF;
				END IF;

         	END LOOP;


			if (matched = 0 and stmtFreq = 'M') then

					carRec := custSolId||'|'||ciftCustId||'|01|0|'||ltrim(rtrim(ciftEmailId))||'|'||
                ltrim(rtrim(cmgTitleName))||'|'||ltrim(rtrim(cmgAddr1))||'|'||
                ltrim(rtrim(cmgAddr2))||'|'||ltrim(rtrim(cityDesc))||'|'||
                ltrim(rtrim(stateDesc))||'|'||ltrim(rtrim(cntryDesc))||' - '||
                ltrim(rtrim(cmgPinCode))||'|'||cmgCustStatCode||'|'||'Y'||'|'||
                ltrim(rtrim(cmgPhone1))||' - '||ltrim(rtrim(cmgPhone2))||'|'||firstAcc||'|'||hcmgCustStatCode;

                    if(length(carRec) > 255) then

							insert into ICICI_STMT_CUST_DETAIL values
                    		(
               			         runId,custSolId,idType,carRec
       			            );
		                    COMMIT;

                    else
                            dbms_output.put_line(carRec);
                    end if;	
			
			end if;

		END IF;

		--else
			if(wbgCust = 'Y') then

				if (dispMode = 'E') then
                    carRec := custSolId||'|'||ciftCustId||'|01|0|'||ltrim(rtrim(ciftEmailId))||'|'||
                    ltrim(rtrim(cmgTitleName))||'|'||ltrim(rtrim(cmgAddr1))||'|'||
                    ltrim(rtrim(cmgAddr2))||'|'||ltrim(rtrim(cityDesc))||'|'||
                    ltrim(rtrim(stateDesc))||'|'||ltrim(rtrim(cntryDesc))||' - '||
                    ltrim(rtrim(cmgPinCode))||'|'||cmgCustStatCode||'|'||'E'||'|'||
                    ltrim(rtrim(cmgPhone1))||' - '||ltrim(rtrim(cmgPhone2))||'|'||firstAcc||'|'||tmpConst;
                else
                    carRec := custSolId||'|'||ciftCustId||'|01|0|'||ltrim(rtrim(ciftEmailId))||'|'||
                    ltrim(rtrim(cmgTitleName))||'|'||ltrim(rtrim(cmgAddr1))||'|'||
                    ltrim(rtrim(cmgAddr2))||'|'||ltrim(rtrim(cityDesc))||'|'||
                    ltrim(rtrim(stateDesc))||'|'||ltrim(rtrim(cntryDesc))||' - '||
                    ltrim(rtrim(cmgPinCode))||'|'||cmgCustStatCode||'|'||'Y'||'|'||
                    ltrim(rtrim(cmgPhone1))||' - '||ltrim(rtrim(cmgPhone2))||'|'||firstAcc||'|'||tmpConst;
                end if;

				if(length(carRec) > 255) then
						
					insert into ICICI_STMT_CUST_DETAIL values
					(
						runId,custSolId,idType,carRec
					);
					COMMIT;

				else
					dbms_output.put_line(carRec);
				end if;
			end if;
	end if;
END processCiftCursor;


BEGIN
	cnt					:= 0;
	runId				:= '&1';
	custSolId			:= '&2';
	idType				:= substr('&4',1,2);
	idTypeOld           := substr('&4',1,1);	
	beginCustId			:= lpad('&5', 9);
	endCustId			:= lpad('&6', 9);
	custStatSelectFlag	:= '&9';
	custStatCodes 		:= '&10';
	dispMode 			:= '&11';
	-- Sri 3.7.02
	stmtFreq			:= '&12';
	negFlg              := '&13';

	pspCustListId		:= runId||custSolId||idType||'C';
	pspAcctListId		:= runId||custSolId||idType||'A';

	commitCnt := 0;

	custRecType			:= '01';
	custSubRecType		:= '0';

	likeStr		:= runId||custSolId||idType||'%';

	step := 1;
	iciArray.construct(custStatCodes, ',' , custStatCnt, custStatArr);

	--if(idType != '_') then
	--	DELETE FROM
	--		PSP_TMP
	--	WHERE
	--		LISTID LIKE likeStr 
	--		AND home_sol_id = custSolId;
	--else
		likeStrAcc := runId||custSolId||idType||'A';
		likeStrCus := runId||custSolId||idType||'C';
		DELETE FROM PSP_TMP WHERE LISTID = likeStrAcc and home_sol_id = custSolId;
		DELETE FROM PSP_TMP WHERE LISTID = likeStrCus and home_sol_id = custSolId;
		DELETE FROM ICICI_STMT_CUST_DETAIL WHERE runId = '&1' and custSolId = '&2' and idType = '&4';
	--end if;
	
	COMMIT;

	OPEN ciftCur;

	endOfCiftCursor := 0;

	WHILE (endOfCiftCursor = 0) LOOP
		processCiftCursor(0);
		commitCnt := commitCnt + 1;
		IF (commitCnt = 1000) THEN
			COMMIT;
			commitCnt := 0;
		END IF;
	END LOOP;

	CLOSE ciftCur;

	COMMIT;

	EXCEPTION
	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('<#ORA-ERROR#>');
		DBMS_OUTPUT.PUT_LINE('Cust Id/Account Id list creation failed at step...'||step);
		DBMS_OUTPUT.PUT_LINE('Cust Id '||ciftCustId);
		DBMS_OUTPUT.PUT_LINE('Check SQL error,  and try again');
		DBMS_OUTPUT.PUT_LINE('Sql Error Code is        : ' || SQLCODE );
		DBMS_OUTPUT.PUT_LINE('SQL Error Description is : '|| SQLERRM);
		ROLLBACK;
		DBMS_OUTPUT.PUT_LINE('Currenct Chunk rolled back.');
END;
/
spool &1-&2-&3-&4-Ex

    select CustRec from ICICI_STMT_CUST_DETAIL where runId = '&1' and custSolId = '&2' and idType = '&4';

spool off
