Rem     This file will create LOCKER_PAYABLE_DETAILS
Rem     with the following characteristics.

Rem     Coded by : Chandra Sekar (BBSSL)

Rem     Module  : LOCKER

Rem TABLE NAME: LOCKER_PAYABLE_DETAILS

Rem SYNONYM:    LCPY

drop table icici.LOCKER_PAYABLE_DETAILS
/
drop public synonym LCPY
/
create table icici.LOCKER_PAYABLE_DETAILS
( 
	sol_id varchar2(8),
	cust_id varchar2(9),
	locker_number varchar2(12),
	payable_amount number(20,4),
	remarks varchar2(50),
	entered_by varchar2(20),
	entered_time date,
	entity_cre_flg char(1),
	del_flg char(1)
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
create public synonym LCPY for icici.LOCKER_PAYABLE_DETAILS
/
create index IDX_LCPY on icici.LOCKER_PAYABLE_DETAILS(SOL_ID,CUST_ID,LOCKER_NUMBER)
/
grant select, insert, update, delete on LCPY to tbagen
/
grant select on LCPY to tbacust
/
grant select on LCPY to tbautil
/
grant all on LCPY to tbaadm
/
