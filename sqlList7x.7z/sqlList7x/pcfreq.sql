-- ###########################################################################################################
-- Package to be created by user ICICI
-- UPDATE HISTORY
-- ----------------------------------------------------------------------------------------------------------
-- Modified by          Date           Purpose of Modification
-- ----------------------------------------------------------------------------------------------------------
-- Arkaja Sachan        03-06-2008     STR: ICI6824 : To capture Mobile number in Chequebook download File
-- Sanjay K Jain        29-07-2008     STR: ICI6669 : For CIB migration 
-- Arkaja Sachan        20-10-2008     STR: ICI7118 : To create an additional field for multiple requests
-- Arkaja Sachan        31-12-2008     STR: ICI7204 : To change number of cheque leaves from 25 to 15 while
--                                     requesting for cheque book for Domestic Savings Accounts
-- ###########################################################################################################

set serveroutput on size 1000000
set head off
set pages 0
set linesize 300
set arraysize 1
set trims on
set trimspool on

spool pcfreq.txt

create or replace
PACKAGE icici.pcfreq AS
	PROCEDURE getDailyReq(  locRecLine          OUT     VARCHAR2,
				outEndOfFile        IN OUT  NUMBER
				);
	PROCEDURE getPrevReq(   inReqDate           IN      VARCHAR2,
				locRecLine          OUT     VARCHAR2,
				outEndOfFile        IN OUT  NUMBER
				);
end pcfreq;
/
CREATE OR REPLACE FUNCTION icici.NUM_CHARS(INSTRING VARCHAR2, INPATTERN VARCHAR2)
RETURN NUMBER
IS
COUNTER NUMBER;
NEXT_INDEX NUMBER;
STRING VARCHAR2(2000);
PATTERN VARCHAR2(2000);
BEGIN
COUNTER := 0;
NEXT_INDEX := 1;
STRING := LOWER(INSTRING);
PATTERN := LOWER(INPATTERN);
FOR I IN 1 .. LENGTH(STRING) LOOP
IF (LENGTH(PATTERN) <= LENGTH(STRING)-NEXT_INDEX+1)
AND (SUBSTR(STRING,NEXT_INDEX,LENGTH(PATTERN)) = PATTERN) THEN
COUNTER := COUNTER+1;
END IF;
NEXT_INDEX := NEXT_INDEX+1;
END LOOP;
RETURN COUNTER;
END;
/

create or replace
PACKAGE BODY icici.pcfreq AS
	glbPrevDate   varchar2(15);

	CURSOR 	pcfDailyCur IS
	SELECT	foracid,
		set_id,
		num_of_lvs,
		num_of_chq_bks,
		cb_type,
		rcre_user,
		rcre_time
	FROM	ICICI_CBRQ
	WHERE	status_flg = 'E'
	FOR	UPDATE;

	CURSOR 	pcfPrevCur IS
	SELECT	foracid,
		set_id,
		num_of_lvs,
		num_of_chq_bks,
		cb_type,
		rcre_user,
		rcre_time
	FROM	ICICI_CBRQ
	WHERE	status_flg = 'S'
	AND	to_char(status_date, 'DD-MM-YYYY') = glbPrevDate;

	PROCEDURE getDailyReq(	locRecLine	OUT	VARCHAR2,
				outEndOfFile	IN OUT	NUMBER
				) IS
		locPatternId		ICICI_CBPT.pattern_id%TYPE;
		locLine1		ICICI_CBPT.line1%TYPE;
		locLine2		ICICI_CBPT.line2%TYPE;
		locLine3		ICICI_CBPT.line3%TYPE;
		locBodDate		GCT.db_stat_date%TYPE;
		locDcAlias		GCT.dc_alias%TYPE;
		locSrlNum		ICICI_LDTT.ser_num%TYPE;
		locForacid		ICICI_CBRQ.foracid%TYPE;
		locSetId		ICICI_CBRQ.set_id%TYPE;
		locCbType		ICICI_CBRQ.cb_type%TYPE;
		locNumOfLvs		ICICI_CBRQ.num_of_lvs%TYPE;
		locNoOfBooks        	ICICI_CBRQ.num_of_chq_bks%TYPE;
		locUser        	    	ICICI_CBRQ.rcre_user%TYPE;
		locDate        	    	ICICI_CBRQ.rcre_time%TYPE;
		locStat			CHAR(1);
		locCardName1        	ICICI_CDTT.card_1_name%TYPE;
		locCardName2        	ICICI_CDTT.card_2_name%TYPE;
		locCardName3        	ICICI_CDTT.card_3_name%TYPE;
		locMothersName      	ICICI_CIFT.mothers_maiden_name%TYPE;
		locEmailId          	ICICI_CIFT.email_id%TYPE;
		locName1Flg         	CHAR(1);
		locName2Flg         	CHAR(1);
		locName3Flg         	CHAR(1);
		locDateOfBirth      	VARCHAR2(15);
		locDateOfBirthFlg   	CHAR(1);
		locNomAvlFlg        	CHAR(1);
		locNomNum           	ANT.nom_reg_num%TYPE;
		locNominee          	ANT.nom_name%TYPE;
		locCabmssign        	VARCHAR2(80);
		locCabmschq         	VARCHAR2(90);
		locGamForacid       	GAM.foracid%TYPE;
		locSchm             	GAM.schm_code%TYPE;
		locModeOfOper       	GAM.mode_of_oper_code%TYPE;
		locGamCustId        	GAM.cust_id%TYPE;
		locOpnDate          	GAM.acct_opn_date%TYPE;
		locTitle            	CMG.cust_title_code%TYPE;
		locAddr1            	CMG.cust_comu_addr1%TYPE;
		locAddr2            	CMG.Cust_comu_addr2%TYPE;
		locPhone1           	CMG.cust_comu_phone_num_1%TYPE;
		locPhone2           	CMG.cust_comu_phone_num_2%TYPE;
		locAcid             	GAM.acid%TYPE;
		locAcctCrncyCode    	GAM.acct_crncy_code%TYPE;
		locglsubheadcode    	GAM.gl_sub_head_code%TYPE;
		locCityCode         	CMG.cust_comu_city_code%TYPE;
		locStateCode        	CMG.cust_comu_state_code%TYPE;
		locCountryCode      	CMG.cust_comu_cntry_code%TYPE;
		locPin              	CMG.cust_comu_pin_code%TYPE;
		locStatus           	CMG.cust_stat_code%TYPE;
		locName             	CMG.cust_name%TYPE;
		locNre              	CMG.cust_nre_flg%TYPE;
		locCtype            	CMG.cust_type_code%TYPE;
		locCgroup           	CMG.cust_grp%TYPE;
		locConst            	CMG.cust_const%TYPE;
		locOccp             	CMG.cust_occp_code%TYPE;
		locIntstat          	CMG.cust_introd_stat_code%TYPE;
		locRating           	CMG.cust_rating_code%TYPE;
		locCity             	RCT.ref_desc%TYPE;
		locState            	RCT.ref_desc%TYPE;
		locCountry          	RCT.ref_desc%TYPE;
		locTypes            	varchar2(10);
		locMul              	varchar2(2);
		locNoOfLeaves       	number;
		locNoOfChqs         	number;
		locNomAvailableFlg  	GAM.nom_available_flg%TYPE;
		locDefNoLvs		number;
		locAcctClsFlg  		GAM.acct_cls_flg%TYPE;
		locChqAlwdFlg  		GAM.chq_alwd_flg%TYPE;
		loc_cnt       		number;
		locInfinityFlg      	CHAR(1);
		locPermAddr1        	CMG.cust_perm_addr1%TYPE;
        	locPermAddr2        	CMG.cust_perm_addr2%TYPE;
        	locPermCityCode     	CMG.cust_perm_city_code%TYPE;
        	locPermStateCode    	CMG.cust_perm_state_code%TYPE;
        	locPermPinCode      	CMG.cust_perm_pin_code%TYPE;
        	locPermCntryCode    	CMG.cust_perm_cntry_code%TYPE;
        	locPermPhoneNum     	CMG.cust_perm_phone_num%TYPE;
        	locPermTelexNum     	CMG.cust_perm_telex_num%TYPE;
		locPermCity         	RCT.ref_desc%TYPE;
		locPermState        	RCT.ref_desc%TYPE;
		locPermCountry      	RCT.ref_desc%TYPE;
		locCustPagerNo		CMG.cust_pager_no%TYPE;
		locLedgNum		GAM.ledg_num%TYPE;
		locMobileNum		ICICI_ALERT_REG.MODE_ID%TYPE;
		locRepeatFlg      	CHAR(1);
		locUnusedChq            number;
		locSolId		GAM.sol_id%TYPE;
		loc_Segment_NUM         ICICI_CUST_SEG.SEGEMENT%TYPE;
		--locbranchadd1           VARCHAR2(45);
		--locbranchadd2           VARCHAR2(45);
		locmicrcd               VARCHAR2(3);
                locifccode              VARCHAR2(12);
		lochomesolid            VARCHAR2(8);
		lochomebranchadd1       VARCHAR2(45); 
		lochomebranchadd2       VARCHAR2(45);



		BEGIN--{
			IF NOT pcfDailyCur%ISOPEN THEN
		   	 	OPEN pcfDailyCur;
	    		END IF;

			locCardName1 := '*';
			locCardName2 := '*';
			locCardName3 := '*';
			locMothersName := '*';
			locEmailId := '*';
			locName1Flg := 'N';
			locName2Flg := 'N';
			locName3Flg := 'N';
			locDateOfBirthFlg := 'N';
			locNomAvlFlg := 'N';
			locNomNum := '*';
			locNominee := '*';
			locCabmssign := '*';
			locCabmschq := '*';

			SELECT	dc_alias, 
				db_stat_date
			INTO	locDcAlias,
				locBodDate
			FROM	GCT;


			FETCH	pcfDailyCur
			INTO	locForacid,
				locSetId,
				locNumOfLvs,
				locNoOfBooks,
				locCbType,
				locUser,
				locDate;

			IF pcfDailyCur%NOTFOUND THEN
				CLOSE pcfDailyCur;

			SELECT	max(ser_num)+1
			INTO	locSrlNum
			FROM	ICICI_LDTT
			WHERE	dc_alias = locDcAlias
			AND	driver_id = 'PCF';

			INSERT	INTO	ICICI_LDTT
				VALUES (locDcAlias, 'PCF', '!', locSrlNum, sysdate, '');

			outEndOfFile := 1;
			RETURN;
			END IF;

			BEGIN --{

				SELECT  acid,
					foracid,
					schm_code,
					mode_of_oper_code,
					cust_id,
					acct_opn_date,
					nom_available_flg,
					acct_cls_flg,
					chq_alwd_flg,
					acct_crncy_code,
					gl_sub_head_code,
					ledg_num,
					sol_id 
				INTO    locAcid,
					locGamForacid,
					locSchm,
					locModeOfOper,
					locGamCustId,
					locOpnDate,
					locNomAvailableFlg,
					locAcctClsFlg,
					locChqAlwdFlg,
					locAcctCrncyCode,
					locglsubheadcode,
					locLedgNum,
					locSolId
				FROM    GAM
				WHERE   foracid = locForacid
				AND	entity_cre_flg = 'Y';


				EXCEPTION WHEN NO_DATA_FOUND THEN
						locGamCustId := '#';
			END; --}

	IF  (locGamCustId != '#') THEN
			BEGIN
			SELECT  decode(cust_title_code,NULL,' ',cust_title_code),
				cust_name,
				decode(cust_comu_addr1,NULL,' ',cust_comu_addr1),
				decode(cust_comu_addr2,NULL,' ',cust_comu_addr2),
				nvl(cust_comu_city_code,'*'),
				nvl(cust_comu_state_code,'*'),
				nvl(cust_comu_cntry_code,'*'),
				decode(cust_comu_pin_code,NULL,' ',cust_comu_pin_code),
				nvl(cust_comu_phone_num_1,'*'),
				nvl(cust_comu_phone_num_2,'*'),
				decode(cust_perm_addr1,NULL,' ',cust_perm_addr1),
				decode(cust_perm_addr2,NULL,' ',cust_perm_addr2),
				nvl(cust_perm_city_code,'*'),
				nvl(cust_perm_state_code,'*'),
				decode(cust_perm_pin_code,NULL,' ',cust_perm_pin_code),
				nvl(cust_perm_cntry_code,'*'),
				nvl(cust_perm_phone_num,'*'),
				nvl(cust_perm_telex_num,'*'),
				cust_stat_code,
				decode(rtrim(cust_stat_code), 'KIDE', 10, 'STUDT' ,10,'CABUS',50, 15),
				cust_name,
				decode(cmg.cust_nre_flg,NULL,'N',cmg.cust_nre_flg),
				cust_type_code,
				cust_grp,
				cust_const,
				cust_occp_code,
				cust_introd_stat_code,
				cust_rating_code,
				decode(ltrim(to_char(date_of_birth,'DD-MM-YYYY')),NULL,'00-00-0000',ltrim(to_char(date_of_birth,'DD-MM-YYYY'))),
				decode(ltrim(to_char(date_of_birth,'DD-MM-YYYY')),NULL,'N','Y'),
				cust_pager_no 
			INTO    locTitle,
				locName,
				locAddr1,
				locAddr2,
				locCityCode,
				locStateCode,
				locCountryCode,
				locPin,
				locPhone1,
				locPhone2,
				locPermAddr1,
				locPermAddr2,
				locPermCityCode,
				locPermStateCode,
				locPermPinCode,
				locPermCntryCode,
				locPermPhoneNum,
				locPermTelexNum,
				locStatus,
				locNoOfChqs,
				locName,
				locNre,
				locCtype,
				locCgroup,
				locConst,
				locOccp,
				locIntstat,
				locRating,
				locDateOfBirth,
				locDateOfBirthflg,
				locCustPagerNo
			FROM    CMG
			WHERE   cust_id = locGamCustId;
            END;

/* Added by Manoj Chopra(Infosys) for mandate holders cheque book request */

	if (locCbType = 'X') then
		begin --{
		SELECT  decode(cust_title_code,NULL,' ',cust_title_code),
			cust_name,
			decode(cust_comu_addr1,NULL,' ',cust_comu_addr1),
			decode(cust_comu_addr2,NULL,' ',cust_comu_addr2),
			nvl(cust_comu_city_code,'*'),
			nvl(cust_comu_state_code,'*'),
			nvl(cust_comu_cntry_code,'*'),
			decode(cust_comu_pin_code,NULL,' ',cust_comu_pin_code),
			nvl(CUST_COMU_PHONE_NUM_1,'*'),
			nvl(CUST_COMU_PHONE_NUM_2,'*')
		INTO    locTitle,
			locName,
			locAddr1,
			locAddr2,
			locCityCode,
			locStateCode,
			locCountryCode,
			locPin,
			locPhone1,
			locPhone2
		FROM 	CMG
		WHERE 	cust_id = (Select cust_id_mandate_holder from ICICI_MANDATE_HOLDER
			WHERE foracid_nri=locForacid and del_flg != 'Y');

		EXCEPTION WHEN NO_DATA_FOUND THEN
			locTitle := '#';
			locName := '#';
			locAddr1 := '#';
			locAddr2 := '#';
			locCityCode := '#';
			locStateCode := '#';
			locCountryCode := '#';
			locPin := '#';
			locPhone1 := '#';
			locPhone2 := '#';
		END; --}

	END IF;
/**************************************************************************/

			BEGIN--{
				SELECT  nvl(ltrim(card_1_name),'*'),
						decode(ltrim(card_1_name),NULL, 'N','Y'),
						nvl(ltrim(card_2_name),'*'),
						decode(ltrim(card_2_name),NULL,'N','Y'),
						nvl(ltrim(card_3_name),'*'),
						decode(ltrim(card_3_name),NULL,'N','Y')
				INTO    locCardName1,
						locName1Flg,
						locCardName2,
						locName2Flg,
						locCardName3,
						locName3Flg
				FROM    ICICI_CDTT
				WHERE   cust_id = locGamCustId;

				EXCEPTION WHEN NO_DATA_FOUND THEN
					locCardName1 := '*';
					locName1Flg := 'N';
					locCardName2 := '*';
					locName2Flg := 'N';
					locCardName3 := '*';
					locName3Flg := 'N';
			END;--}

			BEGIN --{
				SELECT	mothers_maiden_name,
					email_id
				INTO	locMothersName,
					locEmailId
				FROM	ICICI_CIFT
				WHERE	cust_id = locGamCustId;

				EXCEPTION WHEN NO_DATA_FOUND THEN
					locMothersName := '*';
                    			locEmailId := '*';
			END; --}
--***********************************************ADDED BY PRIYANKA************************************************************
			BEGIN --{ 
					Select BANK_IDENTIFIER 
					into locifccode
					from BRBIC
					where bank_code ='ICI'
					and branch_code = (select br_code from sol where sol_id = locSolId)
					and paysys_id ='GROSS' ;
					EXCEPTION WHEN NO_DATA_FOUND THEN
						locifccode := '*';
			END; --}	
				
			--- New code added for selection of Micr code - Sanjay Kamath - 26-11-2012
			BEGIN --{
					SELECT MICR_CENTRE_CODE||MICR_BANK_CODE||MICR_BRANCH_CODE
					INTO locmicrcd
					FROM BCT
					where bank_code = 'ICI'
				 	  and br_code= (select br_code from sol where sol_id = locSolId);
					EXCEPTION
					WHEN NO_DATA_FOUND THEN
						locmicrcd := '*';
			END; --}

			/*
			BEGIN --{
					SELECT MICR_BANK_CODE
					INTO locmicrcd
					FROM  SOL
					WHERE sol_id = locSolId; 

					EXCEPTION WHEN NO_DATA_FOUND THEN
						locmicrcd := '*';
			END; --}
			*/

			BEGIN --{
					SELECT HOME_SOL_ID 
					INTO lochomesolid
					FROM LGI
					WHERE CUST_ID = locGamCustId;

					EXCEPTION WHEN NO_DATA_FOUND THEN
						locGamCustId := '*';
			END; --}

                        BEGIN --{
                                        SELECT ADDR_1,ADDR_2
                                        INTO lochomebranchadd1,lochomebranchadd2
                                        FROM SOL
                                        WHERE sol_id = lochomesolid;

                                        EXCEPTION WHEN NO_DATA_FOUND THEN
                                                lochomebranchadd1 := '*';
                                                lochomebranchadd2 := '*';
                        END; --}

			BEGIN --{
				if (locNomAvailableFlg = 'Y') then
					SELECT  'Y',
						nom_reg_num,
						rtrim(nom_name)
				    	INTO    locNomAvlFlg,
   						locNomNum,
  						locNominee
					FROM    ANT 
					WHERE   acid = locAcid;
				else
					locNomAvlFlg := 'N';
					locNomNum := '*';
					locNominee := '*';
				end if;

				EXCEPTION WHEN NO_DATA_FOUND THEN
					locNomNum := '*';
					locNominee := '*';
			END; --}
 
			begin
				SELECT  decode(ref_desc,NULL,' ',ref_desc)
				INTO    locCity
				FROM    RCT
				WHERE   ref_rec_type = '01'
				AND     ref_code = locCityCode;
			exception
				when no_data_found then
					locCity := '*';
			end;

			begin
				SELECT 	decode(ref_desc,NULL,' ',ref_desc)
				INTO 	locState
				FROM 	rct
				WHERE 	ref_rec_type = '02'
				AND 	ref_code = locStateCode;
            		exception
            			when no_data_found then
					locState := '*';
			end;

            		begin
				SELECT  decode(ref_desc,NULL,' ',ref_desc)
				INTO    locCountry
				FROM    rct
				WHERE   ref_rec_type = '03'
				AND     ref_code = locCountryCode;
			exception
				when no_data_found then
					locCountry := '*';
			end;

			begin
				SELECT  decode(ref_desc,NULL,' ',ref_desc)
				INTO    locPermCity
				FROM    RCT
				WHERE   ref_rec_type = '01'
				AND     ref_code = locPermCityCode;
			exception
				when no_data_found then
					locPermCity := '*';
			end;

			begin
				SELECT 	decode(ref_desc,NULL,' ',ref_desc)
				INTO 	locPermState
				FROM 	rct
				WHERE 	ref_rec_type = '02'
				AND 	ref_code = locPermStateCode;
			exception
				when no_data_found then
					locPermState := '*';
			end;

			begin
				SELECT  decode(ref_desc,NULL,' ',ref_desc)
				INTO    locPermCountry
				FROM    rct
				WHERE   ref_rec_type = '03'
				AND     ref_code = locPermCntryCode;
			exception
				when no_data_found then
					locPermCountry := '*';
			end;
 
			BEGIN--{
				SELECT  substr(locGamForacid,5,2)
				INTO    locMul
				FROM    dual;

				EXCEPTION WHEN NO_DATA_FOUND THEN
				locMul := 'ERROR';
			END;--}

			BEGIN--{
				IF substr(locGamForacid,5,2) = '01' THEN
					locCabmschq:=locName;
				ELSE
					SELECT 'for '||locName
					INTO locCabmschq
					FROM dual;
				END IF;


				SELECT  decode(rtrim(locConst),'1', 'INDIVIDUAL', locCabmssign)
				INTO    locCabmssign
				FROM    dual;

				SELECT  decode(rtrim(locConst),'10','PROPRIETOR',locCabmssign)
				INTO    locCabmssign
				FROM    dual;

				SELECT  decode(rtrim(locConst),'2','PARTNER(S)',locCabmssign)
				INTO    locCabmssign
				FROM    dual;
 
				SELECT  decode(rtrim(locConst),'3','AUTHORIZED SIGNATORY(IES)',locCabmssign)
				INTO    locCabmssign
				FROM    dual;
 
				SELECT  decode(rtrim(locConst),'4','AUTHORIZED SIGNATORY(IES)',locCabmssign)
				INTO    locCabmssign
				FROM    dual;
 
				SELECT  decode(rtrim(locConst),'5','TRUSTEE(S)',locCabmssign)
				INTO    locCabmssign
				FROM    dual;

				SELECT  decode(rtrim(locConst),'6','AUTHORIZED SIGNATORY(IES)',locCabmssign)
				INTO    locCabmssign
				FROM    dual;

				SELECT  decode(rtrim(locConst),'7','AUTHORIZED SIGNATORY(IES)',locCabmssign)
				INTO    locCabmssign
				FROM    dual;

			END;--}

			BEGIN--{
				SELECT	pattern_id,
						line1,
						line2,
						line3
				INTO	locPatternId,
						locLine1,
						locLine2,
						locLine3
				FROM	ICICI_CBPT
				WHERE	foracid = locForacid
				AND	set_id = locSetId;

				EXCEPTION WHEN NO_DATA_FOUND THEN
					locPatternId := '#';
					locLine1 := '#';
					locLine2 := '#';
					locLine3 := '#';

			END;--}


-- ......................... Added by Arkaja on 03.06.2008 for STR:ICI6824 .........................

			BEGIN --{
				SELECT  MODE_ID
				INTO    locMobileNum
				FROM    ICICI_ALERT_REG
				WHERE   FORACID = locForacid
				AND 	MODE_OF_DELIVERY = '0'
				AND	RCRE_TIME = (	SELECT	MAX(RCRE_TIME)
							FROM	ICICI_ALERT_REG
							WHERE	FORACID = locForacid
							AND	MODE_OF_DELIVERY = '0'
							AND	DEL_FLG = 'N')
				AND	DEL_FLG = 'N'
				AND	ROWNUM < 2;

				EXCEPTION WHEN NO_DATA_FOUND THEN
					locMobileNum := '#';
			END; --}


 -- ............................. Added by Amitabh For segment field .............................
              BEGIN --{
                       SELECT SEGEMENT
                                     into   loc_Segment_NUM
                                       from   ICICI_CUST_SEG
                                      where   cust_id = locGamCustId;
                      EXCEPTION WHEN NO_DATA_FOUND THEN
                                       loc_Segment_NUM := '';
               END; --}
--..........................................................................................

-- ......................... Added by Arkaja on 20.10.2008 for STR:ICI7118 .........................

			BEGIN --{
				SELECT  decode(count(FORACID),0,'N','Y')
				INTO    locRepeatFlg
				FROM    ICICI_CBRQ
				WHERE   FORACID = locForacid
				AND 	STATUS_FLG = 'S'
				AND	locBodDate - RCRE_TIME <= 60;

				EXCEPTION WHEN NO_DATA_FOUND THEN
					locRepeatFlg := 'N';
			END; --}

-- .................................................................................................
---------------------- Added by Vijay to show unused leaves in pcfreq------------------------

                       BEGIN --{
                SELECT sum(NUM_CHARS(CHQ_LVS_STAT,'P')) into locUnusedChq
                        from cbt,gct
                        where acid = (select acid from gam where foracid = locForacid)
                        and chq_issu_date > add_months(db_stat_date,-6);
                        EXCEPTION WHEN NO_DATA_FOUND THEN
                                locUnusedChq := 0;
                        END;--}

---------------------- Added by Vijay to show unused leaves in pcfreq------------------------


			BEGIN --{
				locInfinityFlg := 'Y';
				select 'Y' into locInfinityFlg from dual where exists (select '1' from bdt where cust_id = locGamCustId);
				EXCEPTION WHEN NO_DATA_FOUND THEN
				locInfinityFlg := 'X';
            END;--}

			UPDATE	ICICI_CBRQ
			SET		status_flg = 'S',
					status_date = locBodDate
			WHERE	CURRENT OF pcfDailyCur;

			IF substr(locForacid,5,2) = '01' then

				IF (locStatus = 'KIDE' OR locStatus = 'STUDT') then
					locDefNoLvs := 10;
				ELSE
					locDefNoLvs := 15;
				END IF;
			ELSE
				IF (locStatus = 'KIDE' OR locStatus = 'STUDT') then
					locDefNoLvs := 10;
				ELSE
					locDefNoLvs := 50;
				END IF;
			END IF;


			IF (to_char(locDate, 'dd-mm-yyyy') = to_char(locOpndate, 'dd-mm-yyyy')) THEN
				locStat := 'N';
			ELSE
				locStat := 'R';
			END IF;

			IF (locUser = 'SYSTEM') THEN
				locStat := 'S';
			END IF;

			IF (locNoOfBooks = 0) THEN
				locNoOfBooks := 1;
			END IF;

			IF (locAcctClsFlg = 'Y' OR locChqAlwdFlg != 'Y') THEN
				locNoOfBooks := 0;
			END IF;

                        loc_Segment_NUM :='';

			locRecLine := 	locGamForacid||'|'||
					locTitle||'|'||
					locName||'|'||
					locAddr1||'|'||
 					locAddr2||'|'||
					locCity||'|'||
					locState||'|'||
					locCountry||'|'||
					locPin||'|'||
					locSchm ||'|'||
					locNoOfBooks||'|'||
					locDefNoLvs||'|'||
					locStatus||'|'||
					locNre||'|'||
					locModeOfOper||'|'||
					locGamCustId||'|'||
					--locCtype||'|'||
					--loccGroup||'|'||
					locConst||'|'||
					--locOccp||'|'||
					--locIntstat||'|'||
					--locRating||'|'||
					locOpndate||'|'||
					locCardname1 ||'|'||
					locName1Flg||'|'||
					locCardName2||'|'||
					locName2Flg||'|'||
					locCardName3||'|'||
					locName3Flg||'|'||
					--locMothersName||'|'||
					locEmailId||'|'||
					--locDateOfBirth||'|'||
					--locDateOfBirthFlg||'|'||
					locPhone1||'|'||
					locPhone2||'|'||
					locNomAvlFlg||'|'||
    	  				locNomNum||'|'||
					--locNominee||'|'||
					locCabmschq||'|'||
					locCabmssign||'|'||
					locStat||'|'||
					locLine1||'|'||
					locLine2||'|'||
					locLine3||'|'||
					--locPatternId||'|'||
					--locSetId||'|'||
					locNumOfLvs||'|'||
					locCbType||'|'||
					locAcctCrncyCode||'|'||
					locPermAddr1||'|'||
					locPermAddr2||'|'||
					locPermCity||'|'||
					locPermState||'|'||
					locPermPinCode||'|'||
					locPermCountry||'|'||
					locPermPhoneNum||'|'||
					locPermTelexNum||'|'||
					--locInfinityFlg||'|'||
					--locglsubheadcode||'|'||
					locLedgNum||'|'||
					locMobileNum||'|'||
					locRepeatFlg||'|'||
                                        locUnusedChq||'|'||
					locSolId||'|'||
					locifccode||'|'||
					locmicrcd||'|'||
					--locbranchadd1||'|'||
					--locbranchadd2||'|'||
					lochomesolid||'|'||
					lochomebranchadd1||'|'||
					lochomebranchadd2||'|'||
					loc_Segment_NUM;
			outEndOfFile := 0;

	ELSE
			UPDATE	ICICI_CBRQ
			SET		status_flg = 'S',
					status_date = locBodDate
			WHERE	CURRENT OF pcfDailyCur;

			locRecLine := 	locForacid||'|'||
					'#'||'|'||
					'#'||'|'||
					'#'||'|'||
					'#'||'|'||
					'#';
			outEndOfFile := 0;

	END IF;

		EXCEPTION
			WHEN OTHERS THEN raise_application_error(-20999,sqlerrm);
	END getDailyReq;

--  **********************************************************************
	PROCEDURE getPrevReq(	inReqDate	IN		VARCHAR2,
				locRecLine	OUT		VARCHAR2,
				outEndOfFile	IN OUT		NUMBER
						) IS

		locPatternId		ICICI_CBPT.pattern_id%TYPE;

		locLine1		ICICI_CBPT.line1%TYPE;
		locLine2		ICICI_CBPT.line2%TYPE;
		locLine3		ICICI_CBPT.line3%TYPE;
		locBodDate		GCT.db_stat_date%TYPE;
		locDcAlias		GCT.dc_alias%TYPE;
		locSrlNum		ICICI_LDTT.ser_num%TYPE;
		locForacid		ICICI_CBRQ.foracid%TYPE;
		locSetId		ICICI_CBRQ.set_id%TYPE;
		locCbType		ICICI_CBRQ.cb_type%TYPE;
		locNumOfLvs		ICICI_CBRQ.num_of_lvs%TYPE;
		locNoOfBooks            ICICI_CBRQ.num_of_chq_bks%TYPE;
		locUser        		ICICI_CBRQ.rcre_user%TYPE;
		locDate        		ICICI_CBRQ.rcre_time%TYPE;
		locStat			CHAR(1);
		locCardName1		ICICI_CDTT.card_1_name%TYPE;
		locCardName2		ICICI_CDTT.card_2_name%TYPE;
		locCardName3		ICICI_CDTT.card_3_name%TYPE;
		locMothersName		ICICI_CIFT.mothers_maiden_name%TYPE;
		locEmailId		ICICI_CIFT.email_id%TYPE;
		locName1Flg		CHAR(1);
		locName2Flg		CHAR(1);
		locName3Flg		CHAR(1);
		locDateOfBirth		VARCHAR2(15);
		locDateOfBirthFlg	CHAR(1);
		locNomAvlFlg		CHAR(1);
		locNomNum		ANT.nom_reg_num%TYPE;
		locNominee		ANT.nom_name%TYPE;
		locCabmssign		VARCHAR2(80);
		locCabmschq		VARCHAR2(90);
		locGamForacid		GAM.foracid%TYPE;
		locSchm			GAM.schm_code%TYPE;
		locModeOfOper		GAM.mode_of_oper_code%TYPE;
		locGamCustId		GAM.cust_id%TYPE;
		locOpnDate		GAM.acct_opn_date%TYPE;
		locTitle		CMG.cust_title_code%TYPE;
		locAddr1		CMG.cust_comu_addr1%TYPE;
		locAddr2		CMG.Cust_comu_addr2%TYPE;
		locPhone1		CMG.cust_comu_phone_num_1%TYPE;
		locPhone2		CMG.cust_comu_phone_num_2%TYPE;
		locAcid			GAM.acid%TYPE;
		locAcctCrncyCode	GAM.acct_crncy_code%TYPE;
		locglsubheadcode	GAM.gl_sub_head_code%TYPE;
		locCityCode		CMG.cust_comu_city_code%TYPE;
		locStateCode		CMG.cust_comu_state_code%TYPE;
		locCountryCode		CMG.cust_comu_cntry_code%TYPE;
		locPin			CMG.cust_comu_pin_code%TYPE;
		locStatus		CMG.cust_stat_code%TYPE;
		locName			CMG.cust_name%TYPE;
		locNre			CMG.cust_nre_flg%TYPE;
		locCtype		CMG.cust_type_code%TYPE;
		locCgroup		CMG.cust_grp%TYPE;
		locConst		CMG.cust_const%TYPE;
		locOccp			CMG.cust_occp_code%TYPE;
		locIntstat		CMG.cust_introd_stat_code%TYPE;
		locRating		CMG.cust_rating_code%TYPE;
		locCity			varchar2(25);
		locState		varchar2(25);
		locCountry		varchar2(25);
		locTypes		varchar2(10);
		locMul			varchar2(2);
		locNoOfLeaves		number;
		locNoOfChqs		number;
		locNomAvailableFlg	GAM.nom_available_flg%TYPE;
		locDefNoLvs		number;
		locAcctClsFlg		GAM.acct_cls_flg%TYPE;
		locChqAlwdFlg		GAM.chq_alwd_flg%TYPE;
		loc_cnt			number;
		locInfinityFlg		CHAR(1);
		locPermAddr1		CMG.cust_perm_addr1%TYPE;
		locPermAddr2		CMG.cust_perm_addr2%TYPE;
		locPermCityCode		CMG.cust_perm_city_code%TYPE;
		locPermStateCode	CMG.cust_perm_state_code%TYPE;
		locPermPinCode		CMG.cust_perm_pin_code%TYPE;
		locPermCntryCode	CMG.cust_perm_cntry_code%TYPE;
		locPermPhoneNum		CMG.cust_perm_phone_num%TYPE;
		locPermTelexNum		CMG.cust_perm_telex_num%TYPE;
		locPermCity             RCT.ref_desc%TYPE;
		locPermState            RCT.ref_desc%TYPE;
		locPermCountry          RCT.ref_desc%TYPE;
		locCustPagerNo		CMG.cust_pager_no%TYPE;
		locLedgNum		GAM.ledg_num%TYPE;
                locMobileNum            ICICI_ALERT_REG.MODE_ID%TYPE;
		locRepeatFlg		CHAR(1);
		locUnusedChq		number;
		locSolId		GAM.sol_id%TYPE;
		loc_Segment_NUM         ICICI_CUST_SEG.SEGEMENT%TYPE;

	BEGIN--{
		IF NOT pcfPrevCur%ISOPEN THEN
			glbPrevDate := inReqDate;
		     	OPEN pcfPrevCur;
	    	END IF;
 
		locCardName1 := '*';
		locCardName2 := '*';
		locCardName3 := '*';
		locMothersName := '*';
		locEmailId := '*';
		locName1Flg := 'N';
		locName2Flg := 'N';
		locName3Flg := 'N';
		locDateOfBirthFlg := 'N';
		locNomAvlFlg := 'N';
		locNomNum := '*';
		locNominee := '*';
		locCabmssign := '*';
		locCabmschq := '*';
 
		SELECT	dc_alias,
			db_stat_date
		INTO	locDcAlias,
			locBodDate
		FROM	GCT;
 
		FETCH	pcfPrevCur
		INTO	locForacid,
			locSetId,
			locNumOfLvs,
			locNoOfBooks,
			locCbType,
			locUser,
			locDate;
 
		IF pcfPrevCur%NOTFOUND THEN
			CLOSE pcfPrevCur;

			SELECT	max(ser_num)+1
			INTO	locSrlNum
			FROM	ICICI_LDTT
 
			WHERE	dc_alias = locDcAlias
			AND		driver_id = 'PCF';
 
			INSERT	INTO	ICICI_LDTT
			VALUES (locDcAlias, 'PCF', '!', locSrlNum, sysdate, '');
 
			outEndOfFile := 1;
			RETURN;
		END IF;
 
		BEGIN --{
			SELECT  acid,
					foracid,
					schm_code,
					mode_of_oper_code,
					cust_id,
					acct_opn_date,
					nom_available_flg,
					acct_cls_flg,
					chq_alwd_flg,
					acct_crncy_code,
					gl_sub_head_code,
					ledg_num,
					sol_id
			INTO    locAcid,
					locGamForacid,
					locSchm,
					locModeOfOper,
					locGamCustId,
					locOpnDate,
					locNomAvailableFlg,
					locAcctClsFlg,
					locChqAlwdFlg,
					locAcctCrncyCode,
					locglsubheadcode,
					locLedgNum,
					locSolId
			FROM	GAM
			WHERE   foracid = locForacid
			AND		entity_cre_flg = 'Y';
 
			EXCEPTION WHEN NO_DATA_FOUND THEN
					locGamCustId := '#';
		END; --}
 
 
	IF (locGamCustId != '#') THEN
 
		SELECT  decode(cust_title_code,NULL,' ',cust_title_code),
				cust_name,
				decode(cust_comu_addr1,NULL,' ',cust_comu_addr1),
				decode(cust_comu_addr2,NULL,' ',cust_comu_addr2),
				nvl(cust_comu_city_code,'*'),
				nvl(cust_comu_state_code,'*'),
				nvl(cust_comu_cntry_code,'*'),
				decode(cust_comu_pin_code,NULL,' ',cust_comu_pin_code),
				nvl(cust_comu_phone_num_1,'*'),
				nvl(cust_comu_phone_num_2,'*'),
				decode(cust_perm_addr1,NULL,' ',cust_perm_addr1),
				decode(cust_perm_addr2,NULL,' ',cust_perm_addr2),
				nvl(cust_perm_city_code,'*'),
				nvl(cust_perm_state_code,'*'),
				nvl(cust_perm_cntry_code,'*'),
				decode(cust_perm_pin_code,NULL,' ',cust_perm_pin_code),
				nvl(cust_perm_phone_num,'*'),
				nvl(cust_perm_telex_num,'*'),
				cust_stat_code,
				decode(rtrim(cust_stat_code), 'KIDE', 10, 'STUDT' ,10,'CABUS',50, 15),
				cust_name,
				decode(cmg.cust_nre_flg,NULL,'N',cmg.cust_nre_flg),
				cust_type_code,
				cust_grp,
				cust_const,
				cust_occp_code,
				cust_introd_stat_code,
				cust_rating_code,
				decode(ltrim(to_char(date_of_birth,'DD-MM-YYYY')),NULL,'00-00-0000',ltrim(to_char(date_of_birth,'DD-MM-YYYY'))),
				decode(ltrim(to_char(date_of_birth,'DD-MM-YYYY')),NULL,'N','Y'),
				cust_pager_no
		INTO    locTitle,
				locName,
				locAddr1,
				locAddr2,
				locCityCode,
				locStateCode,
				locCountryCode,
				locPin,
				locPhone1,
				locPhone2,
				locPermAddr1,
				locPermAddr2,
				locPermCityCode,
				locPermStateCode,
				locPermPinCode,
				locPermCntryCode,
				locPermPhoneNum,
				locPermTelexNum,
				locStatus,
				locNoOfChqs,
				locName,
				locNre,
				locCtype,
				locCgroup,
				locConst,
				locOccp,
				locIntstat,
				locRating,
				locDateOfBirth,
				locDateOfBirthflg,
				locCustPagerNo 
		FROM    CMG
 
		WHERE   cust_id = locGamCustId;
 
 
/* Added by Manoj Chopra(Infosys) for mandate holders cheque book request */
 
            if (locCbType = 'X') then
		begin --{
                SELECT  decode(cust_title_code,NULL,' ',cust_title_code),
			cust_name,
			decode(cust_comu_addr1,NULL,' ',cust_comu_addr1),
			decode(cust_comu_addr2,NULL,' ',cust_comu_addr2),
			nvl(cust_comu_city_code,'*'),
			nvl(cust_comu_state_code,'*'),
			nvl(cust_comu_cntry_code,'*'),
			decode(cust_comu_pin_code,NULL,' ',cust_comu_pin_code),
			nvl(CUST_COMU_PHONE_NUM_1,'*'),
			nvl(CUST_COMU_PHONE_NUM_2,'*')
                INTO    locTitle,
			locName,
			locAddr1,
			locAddr2,
			locCityCode,
			locStateCode,
			locCountryCode,
			locPin,
			locPhone1,
			locPhone2
                FROM 	CMG
                WHERE cust_id = (Select cust_id_mandate_holder from ICICI_MANDATE_HOLDER
                                WHERE foracid_nri=locForacid);
                exception
                    when no_data_found then
			locTitle := '#';
                        locName := '#';
                        locAddr1 := '#';
                        locAddr2 := '#';
                        locCityCode := '#';
                        locStateCode := '#';
                        locCountryCode := '#';
                        locPin := '#';
                        locPhone1 := '#';
                        locPhone2 := '#';
                end; --}

            end if;
/**************************************************************************/


		BEGIN--{
			SELECT  nvl(ltrim(card_1_name),'*'),
					decode(ltrim(card_1_name),NULL, 'N','Y'),
					nvl(ltrim(card_2_name),'*'),
					decode(ltrim(card_2_name),NULL,'N','Y'),
					nvl(ltrim(card_3_name),'*'),
					decode(ltrim(card_3_name),NULL,'N','Y')
			INTO    locCardName1,
					locName1Flg,
					locCardName2,
					locName2Flg,
					locCardName3,
					locName3Flg
			FROM    ICICI_CDTT
			WHERE   cust_id = locGamCustId;
 
			EXCEPTION WHEN NO_DATA_FOUND THEN
					locCardName1 := '*';
					locName1Flg := 'N';
					locCardName2 := '*';
					locName2Flg := 'N';
					locCardName3 := '*';
					locName3Flg := 'N';
		END;--}
 
 
		BEGIN --{
			SELECT	mothers_maiden_name,
				email_id
			INTO	locMothersName,
				locEmailId
			FROM	ICICI_CIFT
			WHERE	cust_id = locGamCustId;
 
			EXCEPTION WHEN NO_DATA_FOUND THEN
				locMothersName := '*';
				locEmailId := '*';
		END; --}
 
 
		BEGIN --{
			if (locNomAvailableFlg = 'Y') then
				SELECT  'Y',
						nom_reg_num,
						rtrim(nom_name)
				INTO    locNomAvlFlg,
						locNomNum,
						locNominee
				FROM    ANT
				WHERE   acid = locAcid;
			else
				locNomAvlFlg := 'N';
 
				locNomNum := '*';
				locNominee := '*';
			end if;
 
			EXCEPTION WHEN NO_DATA_FOUND THEN
				locNomNum := '*';
				locNominee := '*';
		END; --}
 
		begin 
			SELECT  decode(ref_desc,NULL,' ',ref_desc)
			INTO    locCity
			FROM    RCT
			WHERE   ref_rec_type = '01'
			AND     ref_code = locCityCode;
		exception
			when no_data_found then
				locCity := '*';
		end;
 
		begin
			SELECT 	decode(ref_desc,NULL,' ',ref_desc)
			INTO 	locState
			FROM 	rct
			WHERE 	ref_rec_type = '02'
			AND 	ref_code = locStateCode;
        	exception
        		when no_data_found then
				locState := '*';
		end;
 
		begin
			SELECT  decode(ref_desc,NULL,' ',ref_desc)
			INTO    locCountry
			FROM    rct
			WHERE   ref_rec_type = '03'
			AND     ref_code = locCountryCode;
        	exception
        		when no_data_found then
				locCountry := '*';
		end;
 
		begin
			SELECT  decode(ref_desc,NULL,' ',ref_desc)
			INTO    locPermCity
			FROM    RCT
			WHERE   ref_rec_type = '01'
			AND     ref_code = locPermCityCode;
		exception
        		when no_data_found then
				locPermCity := '*';
		end;
 
		begin
			SELECT 	decode(ref_desc,NULL,' ',ref_desc)
			INTO 	locPermState
			FROM 	rct
			WHERE 	ref_rec_type = '02'
			AND 	ref_code = locPermStateCode;
		exception
			when no_data_found then
				locPermState := '*';
		end;
 
		begin
			SELECT  decode(ref_desc,NULL,' ',ref_desc)
			INTO    locPermCountry
			FROM    rct
			WHERE   ref_rec_type = '03'
			AND     ref_code = locPermCntryCode;
		exception
			when no_data_found then
				locPermCountry := '*';
		end;
 
		BEGIN--{
			SELECT  substr(locGamForacid,5,2)
			INTO    locMul
			FROM    dual;
 
			EXCEPTION WHEN NO_DATA_FOUND THEN
 
				locMul := 'ERROR';
		END;--}
 
		BEGIN--{
			IF substr(locGamForacid,5,2) = '01' then
				locCabmschq:=locName;
			ELSE
				SELECT 'for '||locName
				INTO locCabmschq
				FROM dual;
				END IF;
 
				SELECT  decode(rtrim(locConst),'1', 'INDIVIDUAL', locCabmssign)
				INTO    locCabmssign
				FROM    dual;
 
				SELECT  decode(rtrim(locConst),'10','PROPRIETOR',locCabmssign)
				INTO    locCabmssign
				FROM    dual;
 
				SELECT  decode(rtrim(locConst),'2','PARTNER(S)',locCabmssign)
				INTO    locCabmssign
				FROM    dual;
 
				SELECT  decode(rtrim(locConst),'3','AUTHORIZED SIGNATORY(IES)',locCabmssign)
				INTO    locCabmssign
				FROM    dual;
 
				SELECT  decode(rtrim(locConst),'4','AUTHORIZED SIGNATORY(IES)',locCabmssign)
				INTO    locCabmssign
				FROM    dual;
 
				SELECT  decode(rtrim(locConst),'5','TRUSTEE(S)',locCabmssign)
				INTO    locCabmssign
				FROM    dual;
 
				SELECT  decode(rtrim(locConst),'6','AUTHORIZED SIGNATORY(IES)',locCabmssign)
				INTO    locCabmssign
				FROM    dual;
 
				SELECT  decode(rtrim(locConst),'7','AUTHORIZED SIGNATORY(IES)',locCabmssign)
				INTO    locCabmssign
				FROM    dual;
		END;--}
 
 
		BEGIN--{
			SELECT	pattern_id,
				line1,
				line2,
				line3
			INTO	locPatternId,
				locLine1,
				locLine2,
				locLine3
			FROM	ICICI_CBPT
			WHERE	foracid = locForacid
			AND	set_id = locSetId;
 
			EXCEPTION WHEN NO_DATA_FOUND THEN
				locPatternId := '#';
				locLine1 := '#';
				locLine2 := '#';
				locLine3 := '#';
			END;--}

-- ......................... Added by Arkaja on 03.06.2008 for STR:ICI6824 .........................

			BEGIN --{
				SELECT  MODE_ID
				INTO    locMobileNum
				FROM    ICICI_ALERT_REG
				WHERE   FORACID = locForacid
				AND     MODE_OF_DELIVERY = '0'
				AND     RCRE_TIME = (   SELECT  MAX(RCRE_TIME)
							FROM    ICICI_ALERT_REG
							WHERE   FORACID = locForacid
							AND     MODE_OF_DELIVERY = '0'
							AND     DEL_FLG = 'N')
				AND     DEL_FLG = 'N'
				AND     ROWNUM < 2;

				EXCEPTION WHEN NO_DATA_FOUND THEN
					locMobileNum := '#';
			END; --}

-- ............................. Added by Amitabh For segment field .............................
              BEGIN --{
                       SELECT SEGEMENT
                                     into   loc_Segment_NUM
                                       from   ICICI_CUST_SEG
                                      where   cust_id = locGamCustId;
                      EXCEPTION WHEN NO_DATA_FOUND THEN
                                       loc_Segment_NUM := '';
               END; --}
--..........................................................................................

-- ......................... Added by Arkaja on 20.10.2008 for STR:ICI7118 .........................

                        BEGIN --{
                                SELECT  decode(count(FORACID),0,'N','Y')
                                INTO    locRepeatFlg
                                FROM    ICICI_CBRQ
                                WHERE   FORACID = locForacid
                                AND     STATUS_FLG = 'S'
                                AND     locBodDate - RCRE_TIME <= 60;

                                EXCEPTION WHEN NO_DATA_FOUND THEN
                                        locRepeatFlg := 'N';
                        END; --}

-- .................................................................................................
---------------------- Added by Vijay to show unused leaves in pcfreq------------------------

                       BEGIN --{
                SELECT sum(NUM_CHARS(CHQ_LVS_STAT,'P')) into locUnusedChq
                        from cbt,gct
                        where acid = (select acid from gam where foracid = locForacid)
                        and chq_issu_date > add_months(db_stat_date,-6);
                        EXCEPTION WHEN NO_DATA_FOUND THEN
                                locUnusedChq := 0;
                        END;--}

---------------------- Added by Vijay to show unused leaves in pcfreq------------------------


		BEGIN --{
				locInfinityFlg := 'Y';
                select 'Y' into locInfinityFlg from dual where exists (select '1' from bdt where cust_id = locGamCustId);
                EXCEPTION WHEN NO_DATA_FOUND THEN
                locInfinityFlg := 'X';

		END;--}

		IF substr(locForacid,5,2) = '01' then
			IF (locStatus = 'KIDE' OR locStatus = 'STUDT') then
				locDefNoLvs := 10;
			ELSE
				locDefNoLvs := 15;
			END IF;
		ELSE
			IF (locStatus = 'KIDE' OR locStatus = 'STUDT') then
				locDefNoLvs := 10;
 
			ELSE
				locDefNoLvs := 50;
			END IF;
		END IF;
 
		IF (to_char(locDate, 'dd-mm-yyyy') = to_char(locOpndate, 'dd-mm-yyyy')) THEN
			locStat := 'N';
		ELSE
			locStat := 'R';
		END IF;
 
		IF (locUser = 'SYSTEM') THEN
			locStat := 'S';
		END IF;
 
		IF (locNoOfBooks = 0) THEN
			locNoOfBooks := 1;
		END IF;
 
		IF (locAcctClsFlg = 'Y' OR locChqAlwdFlg != 'Y') THEN
			locNoOfBooks := 0;
		END IF;
               
                loc_Segment_NUM :='';
 
		locRecLine := 	locGamForacid||'|'||
				locTitle||'|'||
				locName||'|'||
				locAddr1||'|'||
				locAddr2||'|'||
				locCity||'|'||
				locState||'|'||
				locCountry||'|'||
				locPin||'|'||
				locSchm ||'|'||
				locNoOfBooks||'|'||
				locDefNoLvs||'|'||
				locStatus||'|'||
				locNre||'|'||
				locModeOfOper||'|'||
				locGamCustId||'|'||
				--locCtype||'|'||
				--loccGroup||'|'||
				locConst||'|'||
				--locOccp||'|'||
				--locIntstat||'|'||
				--locRating||'|'||
				locOpndate||'|'||
				locCardname1 ||'|'||
				locName1Flg||'|'||
				locCardName2||'|'||
				locName2Flg||'|'||
				locCardName3||'|'||
				locName3Flg||'|'||
				--locMothersName||'|'||
				locEmailId||'|'||
				--locDateOfBirth||'|'||
				--locDateOfBirthFlg||'|'||
				locPhone1||'|'||
				locPhone2||'|'||
				locNomAvlFlg||'|'||
				locNomNum||'|'||
				--locNominee||'|'||
				locCabmschq||'|'||
				locCabmssign||'|'||
				locStat||'|'||
				locLine1||'|'||
				locLine2||'|'||
				locLine3||'|'||
				--locPatternId||'|'||
				--locSetId||'|'||
				locNumOfLvs||'|'||
				locCbType||'|'||
				locAcctCrncyCode||'|'||
				locPermAddr1||'|'||
				locPermAddr2||'|'||
				locPermCity||'|'||
				locPermState||'|'||
				locPermPinCode||'|'||
				locPermCountry||'|'||
				locPermPhoneNum||'|'||
				locPermTelexNum||'|'||
				--locInfinityFlg||'|'||
				--locglsubheadcode||'|'||
				locLedgNum||'|'||
				locMobileNum||'|'||
				locRepeatFlg||'|'||
				locUnusedChq||'|'||
				locSolId||'|'||
				locUser||'|'||
				locDate||'|'||
				loc_Segment_NUM;
		outEndOfFile := 0;
	ELSE
			locRecLine := 	locForacid||'|'||
					'#'||'|'||
					'#'||'|'||
					'#'||'|'||
					'#'||'|'||
					'#';

			outEndOfFile := 0;
	END IF;

		EXCEPTION WHEN OTHERS THEN
			raise_application_error(-20999,sqlerrm);
	END getPrevReq;--}
 
END	pcfreq;--}
/
GRANT EXECUTE ON pcfreq TO PUBLIC
/
GRANT EXECUTE ON icici.num_chars TO PUBLIC
/
show err
spool off
