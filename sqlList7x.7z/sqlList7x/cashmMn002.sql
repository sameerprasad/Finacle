set serveroutput on size 1000000
set lines 2000
set feedback off
set trims on
set pages 0
set echo off
set verify off
set head off
spool cashmMn002.lst


declare

v_tran_date_bal gam.clr_bal_amt%type := '0';
v_procash		gam.clr_bal_amt%type := '0';
v_unprocash		gam.clr_bal_amt%type := '0';
v_sol_id sol.sol_id%type :='&1';
v_tran_date eab.eod_date%type :='&2';

cursor cursor1 is 
select
gam.sol_id,foracid,acid , sol_desc , bacid, clr_bal_amt
from gam, sol
where  gam.sol_id = sol.sol_id
and sol.sol_id in ( select sol_id from sst where set_id = v_sol_id)
and bacid in ('CSPROCES','CSUNPROC');


BEGIN

for fc1 in cursor1
loop

BEGIN
select abs(tran_date_bal) into v_tran_date_bal
from eab 
where acid =fc1.acid
and eod_date <= v_tran_date
and end_eod_date >=  v_tran_date;
exception
when no_data_found then
v_tran_date_bal := '0';
when others then
v_tran_date_bal := '0';
END;


/*
if (fc1.bacid = 'PROCASH') then
	v_procash := v_tran_date_bal;
	v_unprocash := '0';
else
	v_procash := '0';
	v_unprocash := v_tran_date_bal;
end if;
*/

if (fc1.bacid = 'CSPROCES') then
	v_procash := fc1.clr_bal_amt;
	v_unprocash := '0';
else
	v_procash := '0';
	v_unprocash := fc1.clr_bal_amt;
end if;

dbms_output.put_line( fc1.sol_id||'|'||fc1.sol_desc||'|'||
fc1.FORACID||'|'|| v_procash||'|'||v_unprocash||'|'||v_tran_date||'|'||fc1.bacid||'|'||fc1.clr_bal_amt);

v_tran_date_bal := '0';
v_procash		:= '0';
v_unprocash		:= '0';


end loop;
END;
/
spool off
