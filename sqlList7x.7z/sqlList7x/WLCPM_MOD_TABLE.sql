Rem     This file will create WLOCKER_PARAMETER_MAINT_MOD Table
Rem     with the following characteristics.

Rem     Coded by : Chandra Sekar (BBSSL)

Rem     Module  : LOCKER

Rem TABLE NAME: WLOCKER_PARAMETER_MAINT_MOD

Rem SYNONYM:    WLCPM_MOD

drop table icici.WLOCKER_PARAMETER_MAINT_MOD
/
drop public synonym WLCPM_MOD
/
create table icici.WLOCKER_PARAMETER_MAINT_MOD
( 
	sol_id 			varchar2(8),
	location_code 		varchar2(10),
	locker_type 		varchar2(5),
	size_of_locker 		varchar2(11),
	allotment_charge 	number(20,4),
	discount_method 	char(1),
	discount_value 		number(20,4),
	penal_charges 		number(20,4),
	break_open_charges 	number(20,4),
	loss_key_charges 	number(20,4),
	minimum_deposit 	number(20,4),
	effective_from 		date,
	access_period 		number(3),
	access_time 		number(3),
	grace_days 		number(3),
	staff_discount_method 	char(1),
	staff_discount_value 	number(20,4),
	tax_percentage 		number(20,4),
	change_in_jholder 	number(20,4),
	change_in_nominee 	number(20,4),
	change_in_modeoper 	number(20,4),
        operational_charge 	number(20,4),
        authority_signatory 	number(20,4),
        change_in_power 	number(20,4),
	LCHG_USER_ID 		varchar2(15),
	LCHG_TIME 		date,
	RCRE_USER_ID 		varchar2(15),
	RCRE_TIME 		date,
	del_flg 		char(1),
	v_flg 			char(1),
	tax_effect_from 	date,
        access_gap 		number(20,4),
        penal_method 		char(1),
        adv_rent_days 		number(20,4),
	access_time_charges     number(20,4),
	MAX_DISCOUNT            VARCHAR2(10),
        ALLOT_ALLOW_NOD         VARCHAR2(10),
        ACCESS_GAP_HIGH         NUMBER(20,4),
        ACCESS_GAP_LOW          NUMBER(20,4),
        ACCESS_GAP_MED          NUMBER(20,4),
        PRE_DATED_ALLOT         NUMBER(5),
        BACK_DATED_ACCESS       NUMBER(5),
	MAX_DISC_PERIOD         NUMBER(5)
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
create public synonym WLCPM_MOD for icici.WLOCKER_PARAMETER_MAINT_MOD
/
grant select, insert, update, delete on WLCPM_MOD to tbagen
/
grant select on WLCPM_MOD to tbacust
/
grant select on WLCPM_MOD to tbautil
/
grant all on WLCPM_MOD to tbaadm
/
