--##############################################################################################
--#			File Name	: LC_operation.sql
--#			Author : Ashwani Bhat (BBSSL)
--#			Report : LOCKER OPERATIONS REPORT
--#			Date   : 
--#			Module	: LOCKER
--#			Called Menu	: LOCKCALL
--#                     Called By       : operation.com
--##############################################################################################

CREATE OR REPLACE PACKAGE Locop_pack AS

    PROCEDURE Locop_proc (
		inp_str IN varchar2,
		out_retcode OUT number,
		out_rec OUT varchar2
		);

	END Locop_pack;
/

CREATE OR REPLACE PACKAGE BODY Locop_pack AS   

v_new_locker_num	lcops.locker_no%type;       
v_locker_type		lcops.locker_type%type;
v_old_locker_num	lcops.locker_no%type;  
v_cust_name		lcops.cust_name%type;       
v_check_date		lcops.check_date%type;      
v_check_in_time		lcops.check_in_time%type;   
v_officer_id_in		lcops.authorised_by%type;   
v_check_out_time	lcops.check_out_time%type;  
v_officer_id_out	lcops.authorised_by%type;  
v_sol_id		lcops.sol_id%type;
  
CURSOR Locop (v_sol_id lcops.sol_id%type) IS
select		locker_no,
		locker_type,
		ltrim((substr(locker_no,-5)),0),
		cust_name,
		check_date,
		substr(check_in_time,11,9),
		authorised_by, 
		substr(check_out_time,11,9),
		authorised_by
from		lcops
where		sol_id = v_sol_id
order by	check_date,check_in_time;



OutArr	basp0099.ArrayType;

	PROCEDURE Locop_proc
	(
		inp_str IN varchar2,
		out_retcode  OUT number,
		out_rec  OUT varchar2
	) AS

BEGIN

	out_retcode := 0;

	IF (NOT Locop%ISOPEN) THEN
		basp0099.formInputArr(inp_str,outArr);
		v_sol_id := outArr(0);		
		


	OPEN Locop (v_sol_id);

	END IF;

			IF (Locop%ISOPEN) then

				FETCH Locop INTO
						v_new_locker_num,
						v_locker_type,	
						v_old_locker_num,
						v_cust_name,	
						v_check_date,	
						v_check_in_time,	
						v_officer_id_in,	
						v_check_out_time,
						v_officer_id_out;
			END IF;

			IF (Locop%NOTFOUND) THEN

				close Locop;
				out_retcode := 1;
				return;

			END IF;

		
			out_rec :=
					v_new_locker_num	||'|'||   
					v_locker_type		||'|'||	    
					v_old_locker_num	||'|'||   
					v_cust_name		||'|'||	    
					v_check_date		||'|'||	    
					v_check_in_time		||'|'||	
					v_officer_id_in		||'|'||	
					v_check_out_time	||'|'||   
					v_officer_id_out;   
			return;

end Locop_proc;
end Locop_pack;
/
drop public synonym Locop_pack
/
create public synonym Locop_pack for Locop_pack
/
grant execute on Locop_pack to tbacust,tbautil,tbagen,tbaadm
/

