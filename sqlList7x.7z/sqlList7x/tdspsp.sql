set head off
set pages 0
set linesize 200
set feedback off
set verify off
set termout off
spool tdspre.lst
select sum(recommended_tds_amt)||'|'||sum(int_amt)||'|'||cmg.cust_id||'|'||
cmg.cust_title_code||'|'||cmg.cust_name||'|'
from tds,cmg where
tran_date  > '&1' and tran_date <'&2'
and tds.cust_id between  lpad('&3',9) and lpad('&4',9)
and tds.sol_id='&6'
and cmg.cust_id=tds.cust_id
group by cmg.cust_id,cmg.cust_title_code,cmg.cust_name
/
spool off
spool tdsact.lst
select tds.cust_id||'|'||gam.foracid||'|'||int_amt||'|'||recommended_tds_amt||'|'||tran_date||'|'
from tds,gam
where
tds.cust_id between  lpad('&3',9) and lpad('&4',9)
and tran_date between '&2' and '&5'
and tds.sol_id='&6'
and gam.acid = tds.acid
order by tds.cust_id,tds.tran_date
/
spool off
