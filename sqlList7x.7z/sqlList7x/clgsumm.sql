break on bank skip page skip 3
compute sum of Amt on bank
compute sum of num  on bank
column amt format 999,99,99,99,999.99
----accept solid prompt "Enter solid - "
----accept clg_date prompt "Enter Zone Date(dd-mm-yyyy) - "
----accept clg_zone prompt "Enter Zone Code - "
set head off 
set feedback off
set verify off
set pages  25
set termout off
set trimspool on
spool clgsumm.lst
ttit center '================================================================================' skip center "OUTWARD CLEARING PUTTI -  " solid skip left '         Date : ' clg_date '                       Pages :  ' SQL.PNO  skip center '================================================================================'skip 2
btit skip 2 right "Manager" skip 5
select substr(bank_name,1,20) bank,
       substr(br_name,1,20) branch ,
       count(*) num ,
       sum(INSTRMNT_AMT) Amt 
from   oci,bkc,bct 
where  sol_id='&1'
and    CLG_ZONE_DATE='&2'
and    CLG_ZONE_CODE=upper('&3')
and    oci.del_flg!='Y' 
and    bct.br_code=oci.br_code 
and    oci.bank_code=bkc.bank_code
and    oci.bank_code=bkc.bank_code 
group  by bank_name,br_name
/
spool off
exit
