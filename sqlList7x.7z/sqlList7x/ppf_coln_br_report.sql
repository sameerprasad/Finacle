break on sol_id
compute sum of tran_amt on sol_id
column acct_name format A40
column tran_amt format 999999999999.99
spool br_report.txt
select htd.sol_id,tran_date,tran_id,gam.foracid, substr(acct_name,1,50) acct_name,part_tran_type,tran_amt from   gam,htd,pfam where  tran_date= '30-03-2009' and
gam.acid = htd.acid and pfam.foracid = gam.foracid  and htd.sol_id = gam.sol_id
and pfam.sol_id = gam.sol_id and PART_TRAN_TYPE ='C' and substr(REF_NUM,1,3) ='PPF'
and TRAN_SUB_TYPE <>'IP' and htd.pstd_flg='Y' and htd.del_flg <> 'Y' and gam.acct_cls_flg <>'Y'
and  gam.ENTITY_CRE_FLG = 'Y' and gam.del_flg <> 'Y'
/
spool off
clear breaks
