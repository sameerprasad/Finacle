-- set head off
-- set verify off
-- set feedback off
-- set pages 0
-- set term off
-- set echo off
-- set trims on
-- SET ARRAYSIZE 1
-- SET MAXDATA  60000
-- SET PAGESIZE 0
-- SET LINESIZE  5000
-- spool off
SET HEAD OFF
SET ARRAYSIZE 1
SET MAXDATA  60000
SET FEEDBACK OFF
SET VERIFY OFF
SET TERM OFF
SET PAGESIZE 0
SET TRIMS ON
SET LINESIZE  5000
spool  datediff.dat
select (to_date('&1','dd-mm-yyyy') - db_stat_date)||'|' from gct;
spool off
exit
