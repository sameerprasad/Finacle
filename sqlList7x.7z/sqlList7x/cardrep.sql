rem AUTHOR :: Gurnam S Saini, Manager (Systems)    DATE  :: 08 June 1998
rem Ver    :: 1

set echo off 
set termout off
set verify off
set feedback off
set linesize 80
set pagesize 60
set newpage 0

define all_dashes = '-----------------------------------------------------------------------------'
column today new_value today_date
select to_char(sysdate, 'dd/mm/yyyy') today
from   dual;
column rpt_date new_value dt1
column func heading 'Function' format a8
column remarks heading 'Card No.' format a16
column rmks heading 'Operation ' format a32 word_wrapped
column acct heading 'Account No.' format a12
column enterer_id heading 'Entry By' format a8
column branch new_value br 
select br_name branch from bct where br_code=(select br_code from sol ) and bank_code='ICI' ;
spool cardrep
compute sum of enterer_id on report
break on report skip 1
ttitle center 'ICICI BANK LIMITED' skip 1 -
center br -
right 'PAGE :   ' format 9999 sql.pno  skip 1 -
center 'REPORT OF ADDITION / MODIFICATION / DELETION OF CARD RECORDS IN OPTION CARM' skip 1 -
right 'DATE :   ' today_date skip 1 
select gam.foracid acct, substr(table_key,1,16) remarks,decode(func_code,'A','Added','M','Modified','D','Deleted') func, enterer_id, modified_fields_data rmks from adt ,gam
where adt.table_name='CAR' and
gam.acid = adt.acid and 
to_date(audit_date)=to_date(sysdate)
/
ttitle off
set heading off
set pagesize 0
whenever sqlerror continue
select '' from dual;
select 'No. of records for the day:  '||count(*) from adt where
table_name='CAR' and
to_date(audit_date)=to_date(sysdate)
/
spool out
set termout on
undefine all_dashes
set feedback on
set verify on
set heading on
set echo on
exit
