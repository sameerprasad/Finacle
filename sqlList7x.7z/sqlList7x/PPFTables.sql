
REM--- To Create PPF Custom Tables
set echo on
set pages 0
spool PPFTables.lst

@PFAM.sql
/
@PFAM_MOD.sql
/
@PFAH.sql
/
@CPTMSG.sql
/
@PFAM_ARR.sql
/
@PFAMTRFS_MOD.sql
/
@config_table.sql
/
@PPFTRFS_OUT.sql
/
spool off
