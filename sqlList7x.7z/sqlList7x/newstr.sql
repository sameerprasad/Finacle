spool newstr
delete from str where schm_code = 'CFDNR' and tran_rpt_code = 'CDFNR');
insert into str values ('CANRE','CANRE','999999999999.00','999999999999.00'); 
insert into str values ('CFDJY','LOCAL','999999999999.00','999999999999.00');
insert into str values ('EUSCA','EUSCA','999999999999.00','999999999999.00'); 
insert into str values ('EJYCA','EJYCA','999999999999.00','999999999999.00');
insert into str values ('EDKCA','EDKCA','999999999999.00','999999999999.00');
insert into str values ('EDMCA','EDMCA','999999999999.00','999999999999.00');
insert into str values ('EDMCA','ABROD','999999999999.00','999999999999.00');
insert into str values ('EDMCA','LOCAL','999999999999.00','999999999999.00');
insert into str values ('EDMCA','OTHER','999999999999.00','999999999999.00');
insert into str values ('SBNRE','SBNRE','999999999999.00','999999999999.00');
insert into str values ('CFDNR','CFDNR','999999999999.00','999999999999.00');
insert into str values ('EDKCA','RENEW','999999999999.00','999999999999.00');
insert into str values ('EFDMD','RENEW','999999999999.00','999999999999.00');
insert into str values ('EFUSD','RENEW','999999999999.00','999999999999.00');
insert into str values ('EFJYD','RENEW','999999999999.00','999999999999.00');
insert into str values ('EFGBD','RENEW','999999999999.00','999999999999.00');
insert into str values ('EDMSB','RENEW','999999999999.00','999999999999.00');
insert into str values ('EDMCA','RENEW','999999999999.00','999999999999.00');
insert into str values ('EGBCA','RENEW','999999999999.00','999999999999.00');
insert into str values ('EGBSB','RENEW','999999999999.00','999999999999.00');
insert into str values ('EJYCA','RENEW','999999999999.00','999999999999.00');
insert into str values ('EJYSB','RENEW','999999999999.00','999999999999.00');
insert into str values ('EUSCA','RENEW','999999999999.00','999999999999.00');
insert into str values ('EUSSB','RENEW','999999999999.00','999999999999.00');
insert into str values ('EFUSH','RENEW','999999999999.00','999999999999.00');
insert into str values ('EFGBH','RENEW','999999999999.00','999999999999.00');
insert into str values ('EFDMH','RENEW','999999999999.00','999999999999.00');
insert into str values ('EFJYH','RENEW','999999999999.00','999999999999.00');
spool off
exit
