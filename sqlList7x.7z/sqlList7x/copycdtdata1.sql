rem This sql is written to keep the data in icici-cdtt-daily before downloading

column suffix new_value suffix

set head off
set feedback off
set trims on
set linesize 1000
set pages 0
set arraysize 1000
set trimout on
set trimspool on

select to_char(sysdate,'ddmmyyyyHH24:MI:SS') suffix from dual;

spool $ICICI_CUST_REP/cif/cdttafterupdate&1&suffix

select	CUST_ID||'|'||
		CARD_1_NUMBER||'|'|| 
		CARD_1_NAME||'|'||
		CARD_1_UPDATED||'|'||
		CARD_2_NUMBER||'|'|| 
		CARD_2_NAME||'|'|| 
		CARD_2_UPDATED||'|'|| 
		CARD_3_NUMBER||'|'|| 
		CARD_3_NAME||'|'|| 
		CARD_3_UPDATED||'|'|| 
		CARD_4_NUMBER||'|'|| 
		CARD_4_NAME||'|'|| 
		CARD_4_UPDATED||'|'|| 
		CARD_5_NUMBER||'|'|| 
		CARD_5_NAME||'|'|| 
		CARD_5_UPDATED||'|'|| 
		PRIMARY_INDEX||'|'|| 
		CUST_NRE_FLG||'|'|| 
		CUST_STAT_CODE||'|'|| 
		CUST_OCCP_CODE||'|'|| 
		CUST_COMU_ADDR1||'|'|| 
		CUST_COMU_ADDR2||'|'|| 
		CUST_COMU_CITY_CODE||'|'|| 
		CUST_COMU_STATE_CODE||'|'|| 
		CUST_COMU_PIN_CODE||'|'|| 
		CUST_COMU_CNTRY_CODE||'|'|| 
		CUST_COMU_PHONE_NUM_1||'|'|| 
		CUST_PERM_ADDR1||'|'|| 
		CUST_PERM_ADDR2||'|'|| 
		CUST_PERM_CITY_CODE||'|'|| 
		CUST_PERM_PIN_CODE||'|'|| 
		CUST_PERM_CNTRY_CODE||'|'||
		SOL_ID||'|'||
		FORACID||'|'||
		SCHM_TYPE||'|'||
		SCHM_CODE||'|'||
		CUST_MINOR_FLG||'|'||
		CUST_CONST||'|'||
		MODE_OF_OPER_CODE||'|'||
		ACCT_STATUS	
from icici_cdtt_daily
/
spool off
