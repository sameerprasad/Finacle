Rem     This file will create CUST_LOCKER_EXCEPTION_DETAILS
Rem     with the following characteristics.
Rem     Coded by : Mariappan (BBSSL)

Rem     Module  : LOCKER


Rem TABLE NAME: CUST_LOCKER_EXCEPTION_DETAILS

Rem SYNONYM:    CUST_LOCKER_EXCEPTION_DETAILS

drop table icici.CUST_LOCKER_EXCEPTION_DETAILS
/
drop public synonym CLCET
/
create table icici.CUST_LOCKER_EXCEPTION_DETAILS
( 
	sol_id varchar2(8),
	cust_id varchar2(9),
	locker_number varchar2(12),
	excp_code varchar2(3),
	excp_date date,
	approve_user_id varchar2(15),
	approve_date date,
	del_flg char(1)
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
create public synonym CLCET for icici.CUST_LOCKER_EXCEPTION_DETAILS
/
create index IDX_CLCET on icici.CUST_LOCKER_EXCEPTION_DETAILS( SOL_ID,CUST_ID,LOCKER_NUMBER,EXCP_CODE,EXCP_DATE )
/
grant select, insert, update, delete on CLCET to tbagen
/
grant select on CLCET to tbacust
/
grant select on CLCET to tbautil
/
grant all on CLCET to tbaadm
/
