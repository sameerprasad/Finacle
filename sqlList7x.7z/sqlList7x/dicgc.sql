rem DICGC Return 
rem PREPARED BY : G.S.Saini , I.T. Deptt.
set feedback off
set verify off
set heading off
column br new_value bran
select br_code br from sol; 
column rpt_date new_value dt1
select to_char(db_stat_date, 'yymmdd') rpt_date from gct; 
set pagesize 0
set linesize 100
set numformat b99999999999990.99
spool &bran.&dt1..dic
select s.br_code||'|'||'1.Upto Rs.100000'||'|'||
	count(g.foracid)||'|'||sum(e.tran_date_bal) 
        from eab e, gam g,sol s 
        where g.acct_ownership='C'
	and g.acct_opn_date <= '&&1'
	and (g.acct_cls_flg!='Y' or acct_cls_date > '&&1')
	and g.gl_sub_head_code not in ('05010','12010','15010','28010')
	and e.acid=g.acid
	and g.sol_id=s.sol_id
	and e.tran_date_bal > 0
	and e.tran_date_bal <= 100000
	and e.eod_date = (select max(e1.eod_date) from eab e1
                            where e1.acid=g.acid
                            and e1.eod_date <=  '&&1')
	group by s.br_code,'1.Upto Rs.100000'
	union
select s.br_code||'|'||'2.More than Rs.100000 and upto Rs.150000'||'|'||
	count(g.foracid)||'|'||sum(e.tran_date_bal) 
from eab e, gam g,sol s
        where g.acct_ownership='C'
	and g.acct_opn_date <= '&&1'
	and (g.acct_cls_flg!='Y' or acct_cls_date > '&&1')
	and g.gl_sub_head_code not in ('05010','12010','15010','28010')
	and e.acid=g.acid
	and g.sol_id=s.sol_id
	and e.tran_date_bal > 100000
	and e.tran_date_bal <= 150000
	and e.eod_date = (select max(e1.eod_date) from eab e1
                            where e1.acid=g.acid
                            and e1.eod_date <=  '&&1')
	group by s.br_code,'2.More than Rs.100000 and upto Rs.150000'
	union
select s.br_code||'|'||'3.More than Rs.150000 and upto Rs.200000'||'|'||
	count(g.foracid)||'|'||sum(e.tran_date_bal) 
from eab e, gam g,sol s 
	where g.acct_ownership='C'
	and g.acct_opn_date <= '&&1'
	and (g.acct_cls_flg!='Y' or acct_cls_date > '&&1')
	and g.gl_sub_head_code not in ('05010','12010','15010','28010')
	and e.acid=g.acid
	and g.sol_id=s.sol_id
	and e.tran_date_bal > 150000
	and e.tran_date_bal <= 200000
	and e.eod_date = (select max(e1.eod_date) from eab e1
                            where e1.acid=g.acid
                            and e1.acid=g.acid
                            and e1.eod_date <=  '&&1')
	group by s.br_code,'3.More than Rs.150000 and upto Rs.200000'
union
select s.br_code||'|'||'4.More than Rs.200000'||'|'||
	count(g.foracid)||'|'||sum(e.tran_date_bal) 
from eab e, gam g,sol s
	where g.acct_ownership='C'
	and g.acct_opn_date <= '&&1'
	and (g.acct_cls_flg!='Y' or acct_cls_date > '&&1')
	and g.gl_sub_head_code not in ('05010','12010','15010','28010')
	and e.acid=g.acid
	and g.sol_id=s.sol_id
	and e.tran_date_bal > 200000
	and e.eod_date = (select max(e1.eod_date) from eab e1
                            where e1.acid=g.acid
                            and e1.eod_date <=  '&1')
	group by s.br_code,'4.More than Rs.200000'
	order by 1
/
spool off
set heading off
set termout on
set verify on
set feedback on
