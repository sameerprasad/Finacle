REM CLRT Table
REM ------------------

drop index IDX_cust_locker_reversal_tran
/
drop index IDX_cust_locker_rev_tranid
/
drop index UIDX_cust_locker_reversal_tran
/
CREATE INDEX IDX_cust_locker_reversal_tran ON ICICI.cust_locker_reversal_tran(SOL_ID,locker_num,cust_id)
/
CREATE INDEX IDX_cust_locker_rev_tranid ON ICICI.cust_locker_reversal_tran(locker_num,org_tran_id,org_tran_date)
/
CREATE unique INDEX UIDX_cust_locker_reversal_tran ON ICICI.cust_locker_reversal_tran(SOL_ID,locker_num,cust_id,org_tran_id,org_tran_date)
/
REM WLSM Table
REM ------------------

drop index IDX_SCHM_MASTER_TABLE
/
CREATE  INDEX IDX_SCHM_MASTER_TABLE ON icici.LOC_SCHM_MASTER_TABLE(SOL_ID,Scheme_name,Disc_Based_On)
/
REM WLCRMT Table
REM ------------------

drop index idx_WLCRMT_main
/
CREATE  UNIQUE INDEX  idx_WLCRMT_main ON icici.RACK_ID_TRAN_MAIN(SOL_ID1,RACK_ID,del_flg)
/
REM WLPM Table
REM ------------------

drop index idx_WLPM_TABLE
/
CREATE  INDEX IDX_WLPM_TABLE ON icici.LOC_PREMIUM_MODTABLE(SOL_ID,LOCKER_NUM,CUST_ID,TYPE)
/
REM WLPM Table
REM ------------------

drop index IDX_cust_locker_tran_ledger
/
drop index IDX_cust_locker_tran_date
/
CREATE INDEX IDX_cust_locker_tran_ledger ON ICICI.cust_locker_tran_ledger(SOL_ID,locker_num,cust_id)
/
CREATE INDEX IDX_cust_locker_tran_date ON ICICI.cust_locker_tran_ledger(locker_num,APPLICABLE_DATE)
/
REM LCBRKOP Table
REM ------------------

drop index IDX_LCBRKOP
/
create unique index IDX_LCBRKOP on ICICI.LOCKER_BREAK_OPEN(SOL_ID,LOCKER_TYPE,LOCK_NO,KEY_NO,CUST_ID)
/

REM LCBRKOPH Table
REM -----------------

drop index IDX_LCBRKOPH
/
CREATE INDEX IDX_LCBRKOPH ON  ICICI.LOCKER_BREAK_OPEN_HISTORY(SOL_ID, LOCKER_TYPE, LOCK_NO, KEY_NO, CUST_ID)
/
REM CLCLA Table
REM ----------------

drop index IDX_CLCLA
/
create index IDX_CLCLA on ICICI.CLOCKER_LETTER_OF_AUTHORITY( SOL_ID,LOCKER_NUMBER,KEY_NUMBER,CUST_MH_ID,CLCLA_SRL_NUM )
/

REM CLCLAH Table
REM -------------

drop index  IDX_CLCLAH
/
create index IDX_CLCLAH on ICICI.CLOCKER_LETTER_OF_AUTHORITYH( SOL_ID,LOCKER_NUMBER,KEY_NUMBER,CUST_MH_ID,CLCLA_SRL_NUM )
/
REM WLCRM Table
REM -----------------

drop index idx_wlcrm_main
/
create unique index idx_wlcrm_main on ICICI.RACK_ID_MAINTENENCE(SOL_ID,RACK_ID,DEL_FLG)
/

Alter index IDX_WLCPM rebuild
/
Alter index IDX_WLCPMH rebuild
/
Alter index idx_wlcrm_main rebuild
/
Alter index IDX_CLND rebuild
/
Alter index IDX_CLND rebuild
/
Alter index IDX_LCOPS rebuild
/
drop index idx_wlckm_locknum
/
drop index idx_wlckm_locknum2
/
create index idx_wlckm_locknum on ICICI.LOCKER_KEY_MAINTENENCE(SOL_ID,LOCKER_NUM)
/
create index idx_wlckm_locknum2 on ICICI.LOCKER_KEY_MAINTENENCE(SOL_ID,LOCKER_NUM,del_flg)
/

--------------------------------------------
drop index IDX_clmt_locknum
/
drop index IDX_clmt_lockcustid
/
drop index IDX_clmt_locknumdel
/
CREATE INDEX IDX_clmt_locknum ON ICICI.cust_locker_master_table(SOL_ID,locker_num)
/
CREATE INDEX IDX_clmt_lockcustid ON ICICI.cust_locker_master_table(SOL_ID,locker_num,cust_id)
/
CREATE INDEX IDX_clmt_locknumdel ON ICICI.cust_locker_master_table(SOL_ID,locker_num,del_flg)
/

REM CLONUM Table
REM ------------------

drop index IDX_cust_locker_oldnum_table
/
CREATE INDEX IDX_cust_locker_oldnum_table ON ICICI.cust_locker_oldnum_table(old_sol_id,old_locker_num)
/

REM LCLOST Table
REM ------------------

drop index IDX_LCLOST
/
CREATE INDEX IDX_LCLOST ON icici.LOCKER_KEY_LOST_MAINTENENCE(SOL_ID,LOCKER_NUM,CUST_ID)
/
