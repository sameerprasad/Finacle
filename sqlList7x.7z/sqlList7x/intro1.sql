set echo off 
set pause off
set pagesize 1000

rem Script For Generating List Of Customers who have introduced other
rem customers today.
rem
rem This will be used to generate a letter of thanks for introducing
rem the new customers to ICICI. The letter template is intro.let
rem
rem Note that this has to be run every day. Else, the data is lost.
rem
rem Input parameters in command line -
rem	None
rem
rem Tables accessed -
rem       CMG, RCT.
rem
rem The table RCT is used to pick up the address of the customer
rem from the codes given in CMG. CMG is joined with itself to obtain
rem the details of the customer who has introduced another customer.
rem Note that if an employee or any other known person introduces a
rem new customer, then this advice will not be generated.
rem
rem This script can be run at any time During the Day.

set verify off
set wrap on
set feedback off
set linesize 291
set space 1
set termout off
set heading off

spool &1 

select	decode(y.cust_title_code,NULL,' ',y.cust_title_code)||'|'||
	decode(y.cust_name,NULL,' ',y.cust_name)||'|'||
	decode(y.cust_comu_addr1,NULL,' ',y.cust_comu_addr1)||'|'||
	decode(y.cust_comu_addr2,NULL,' ',y.cust_comu_addr2)||'|'||
	decode(b.ref_desc,NULL,' ',b.ref_desc)||'|'||
	decode(c.ref_desc,NULL,' ',c.ref_desc)||'|'||
	decode(d.ref_desc,NULL,' ',d.ref_desc)||'|'||
	decode(y.cust_comu_pin_code,NULL,' ',y.cust_comu_pin_code)||'|'||
	decode(br_name,NULL,' ',br_name)||'|'||
	decode(x.cust_title_code,NULL,' ',x.cust_title_code)||'|'||
	decode(x.cust_name,NULL,' ',x.cust_name)||'|'||
	decode(y.cust_title_code, 'M/S', 'Sirs',y.cust_title_code)||'|'||
	decode(y.cust_title_code, 'M/S', ' ',y.cust_name)||'|'
from	cmg x, cmg y, rct b, rct c, rct d, bct, sol
where	y.entity_cre_flg = 'Y'
and	y.del_flg != 'Y'
and	to_char ( x.rcre_time, 'DD-MON-YYYY' ) = to_char ( to_date('&2'), 'DD-MON-YYYY' )
and	x.cust_introd_cust_id = y.cust_id
and	x.entity_cre_flg = 'Y' 
and	x.del_flg != 'Y'
and	b.ref_rec_type = '01'
and	b.ref_code = y.cust_comu_city_code
and	b.del_flg != 'Y'
and	c.ref_rec_type = '02'
and	c.ref_code = y.cust_comu_state_code
and	c.del_flg != 'Y'
and	d.ref_rec_type = '03'
and	d.ref_code = y.cust_comu_cntry_code
and	d.del_flg != 'Y' 
and	sol.br_code = bct.br_code  
/
spool off
exit
