set head off
set verify off
set feedback off
set trimspool on
set pages 0
set termout off
spool bod_date.lst
select to_char(db_stat_date,'ddmmyyyy') from gct
/
spool off
