Rem     This file will create LOCKER_KEY_SWAPPING_MOD Table
Rem     with the following characteristics.

Rem     Coded by : Saravanan (BBSSL)

Rem     Module  : LOCKER


Rem TABLE NAME: LOCKER_KEY_SWAPPING_MOD

Rem SYNONYM:    LCKS_MOD

drop table icici.LOCKER_KEY_SWAPPING_MOD
/
drop public synonym LCKS_MOD
/
create table icici.LOCKER_KEY_SWAPPING_MOD
(
SOL_ID		VARCHAR2(8),
LOCKER_NUM1	VARCHAR2(12),
KEY_NUM1	VARCHAR2(8),
STATUS1		CHAR(1),
LOCKER_NUM2	VARCHAR2(12),
KEY_NUM2	VARCHAR2(8),
STATUS2		CHAR(1),
DEL_FLG		CHAR(1),
ENTITY_CRE_FLG  CHAR(1),
LCHG_USER_ID    VARCHAR2(15),
LCHG_TIME       DATE,
RCRE_USER_ID    VARCHAR2(15),
RCRE_TIME       DATE
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
create public synonym LCKS_MOD for icici.LOCKER_KEY_SWAPPING_MOD
/
grant select, insert, update, delete on LCKS_MOD to tbagen
/
grant select on LCKS_MOD to tbacust
/
grant select on LCKS_MOD to tbautil
/
grant all on LCKS_MOD to tbaadm
/


