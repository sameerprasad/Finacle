accept solid prompt 'PLEASE ENTER FOUR DIGIT SOL ID OF REPORT BRANCH : '
set heading on
set pagesize 60
set linesize 132
set echo off
set feedback off
set termout off
set verify off
#col subgl format a5
set newpage 0
define all_dashes = '_____________________________________________________________________________________________________________________'
spool nom_daily_&solid
column today new_value today_date

select to_char(sysdate,'dd/mm/yyyy:hh24:mi:ss') today
from dual;
ttitle center  'ICICI BANK LTD.' skip 1 -
#center br skip 1 -
center ' REPORT of of Nominations entered today "/' today_date skip 1 - 
left all_dashes skip 2
#break on home_sol_id skip 2 on report

column a.nom_reg_num heading "Nomination Number" format a10 trun
column b.cust_id heading "Customer Id." format a13 
column c.cust_name heading "Customer Name." format a30 trun
column a.nom_name heading "Name of Nominee" format a30 trun
column a.nom_reltn_code heading "Nominee Relation Code" format a8 trun
column a.nom_date_of_birth heading "Date of Birth (In Minor)" format a20 trun
select a.rcre_time,a.nom_reg_num,a.cust_id,c.cust_name,a.nom_name,a.nom_reltn_code,b.cust_id,b.home_sol_id,c.cust_name from icici_cndt_cndh a,icici_cift b,cmg c where (b.cust_id=a.cust_id and b.home_sol_id = '&solid') and a.cust_id = c.cust_id
/
set feedback on
set verify on
set termout on
set heading on
set echo on
clear breaks
clear computes
spool off
/
