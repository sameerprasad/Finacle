rem accept solid prompt "ENTER SOL ID::::"
set echo off
set verify off
set termout off
set feedback off
set pages 66
set lines 132

column BOD new_value Statusdate
column br new_value bname
column brc new_value code

select br_code brc from sol where sol_id = '&1';

select br_name br from bct where br_code = (select br_code from sol where 
				sol_id = '&1');
select to_Date(db_stat_date,'DD-MM-YYYY') BOD from gct; 

break on CUST_ID 
compute sum of balance on CUST_ID
column name format a25 trunc
column days format a5
column scheme format a5
column BALANCE format 99,99,99,999.99
column AGE format 999


ttitle center ' ICICI BANK LTD ' &bname skip 2-
center ' List of overdue deposits in the branch as on &Statusdate' skip 2-

spool overdue1.&1

select gam.cust_id CUST_ID,gam.schm_code scheme,gam.foracid,gam.acct_name name,
to_char(tam.maturity_date,'DD-MM-YYYY') MATURITY,
deposit_period_mths||'\'||deposit_period_days DAYS,
(clr_bal_amt + un_clr_bal_amt) BALANCE,
(sysdate - maturity_Date) AGE  from gam,tam,dual
where gam.sol_id = '&1'
and gam.acid = tam.acid
and gam.gl_sub_head_code = '05060'
and gam.acct_cls_flg != 'Y'
and tam.maturity_date < '&Statusdate'
order by gam.cust_id,tam.maturity_date
/
spool off
exit
