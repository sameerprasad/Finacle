set numformat 9999999999.99
set serveroutput on size 1000000
set pages 0
set lines 5000
set trims on
set verify off
set feedback off
set termout on 

var datecomp varchar2(15);
var fromdate varchar2(10);
var todate   varchar2(10);

create table TBAUTIL.TMP_ICI_SCHOOL_CLG
(
inst_code varchar(60),
off_acc   varchar(20),
init_sol_id varchar(5),
tran_amt  number(16,2),
tran_id varchar(20),
tran_date date,
roll_no varchar(100),
class varchar(100)
)
/

Begin
        :datecomp := '&3';
        :fromdate := '&1';
        :todate := '&2';
End;
/

DECLARE

inst_code varchar2(60);
loc_school_id varchar2(60);
temp      varchar2(60);
roll_no   varchar2(100);
class     varchar2(100);
cr_amt    number(16,2);
solid     GAM.sol_id%type;
first_pos number; 
second_pos number; 
third_pos number; 
fourth_pos number;
file_ind number := 1;
v_count number := 0;
recexists	varchar2(5) := 'N';
off_acct	gam.foracid%type;
off_sol		gam.sol_id%type;
cnt_temp	number;
fai_file        utl_file.file_type;
fai_filename    varchar2(100);
fai_filepath    varchar2(10);
fai_filemode    varchar2(2);
out_file        utl_file.file_type;
out_filename    varchar2(100);
out_filepath    varchar2(10);
out_filemode    varchar2(2);
outstr			varchar2(1000);
failstr			varchar2(1000);



CURSOR tran_details IS
select
	ocp.clg_zone_date,
	ocp.tran_date as trandate,
	ocp.clg_zone_code,
	ocp.sol_id initsolid,
	ocp.tran_id tranid,
	ocp.tran_amt tranamt,
	ocp.part_tran_type,
	ocp.partcls tranparticular,
	ocp.tran_rmks,
	gam.foracid as offacc
 from gam,ocp,ott
 where gam.acid=ocp.acid
 and ott.acid=ocp.acid
 and ocp.del_flg!='Y'
 and gam.bacid ='SLFEECOL'
 and ocp.clg_zone_date between :fromdate and :todate
 and ocp.status_flg='G'
 and shd_bal_rem_amt=0
 and ocp.tran_id=ott.tran_id
 and ocp.tran_date=ott.tran_date
 and ocp.part_tran_srl_num=ott.part_tran_srl_num
 and ott.org_tran_amt<>ott.total_offset_amt
 and ott.del_flg!='Y';

CURSOR school_det IS 
select * from tbautil.tmp_ici_school_clg order by inst_code;

BEGIN
			out_filepath := '/tmp';
			out_filename := 'schlupld_clg_'||:datecomp||'.SUC'||lpad(file_ind,4,'0');
			out_filemode := 'w';
			out_file := utl_file.fopen(out_filepath,out_filename,out_filemode);
			fai_filepath := '/tmp';
			fai_filename := 'schlupld_clg_'||:datecomp||'.FAI';
			fai_filemode := 'w';
			fai_file := utl_file.fopen(fai_filepath,fai_filename,fai_filemode);

for trandetails in tran_details
loop
    first_pos := instr(trandetails.tranparticular,':',1,1);
    second_pos := instr(trandetails.tranparticular,':',1,2);

	temp := substr(trandetails.tranparticular,1,4);

	if (temp = 'TRFR') then 
	
		third_pos := instr(trandetails.tranparticular,':',1,3);
		fourth_pos := length(trandetails.tranparticular);

		inst_code := substr(trandetails.tranparticular,first_pos+1,second_pos-first_pos-1);
		roll_no   := substr(trandetails.tranparticular,second_pos+1,third_pos-second_pos-1);
		class     := substr(trandetails.tranparticular,third_pos+1,fourth_pos-third_pos);

	else
    	third_pos := length(trandetails.tranparticular);

    	inst_code := substr(trandetails.tranparticular,1,first_pos-1);
    	roll_no   := substr(trandetails.tranparticular,first_pos+1,second_pos-first_pos-1);
    	class     := substr(trandetails.tranparticular,second_pos+1,third_pos-second_pos);
	end if;

if (inst_code IS NULL) then
	failstr := (trandetails.offacc||'|'||trandetails.initsolid||'|'||'X'||'|'||trandetails.tranamt||'|'||trandetails.tranparticular);
	utl_file.put_line(fai_file,failstr);
else
	Begin
	Select 'Y' into recexists from dual
	 where exists(select foracid from school_acct_mast where school_id = inst_code and del_flg <> 'Y');
	Exception
	When no_data_found then
		recexists := 'N';
	End;
	if recexists = 'N' then
		failstr := (trandetails.offacc||'|'||trandetails.initsolid||'|'||'X'||'|'||trandetails.tranamt||'|'||inst_code||' :School Id does not exist');
		utl_file.put_line(fai_file,failstr);
	else if recexists = 'Y' then
	insert into TBAUTIL.TMP_ICI_SCHOOL_CLG values(inst_code,trandetails.offacc,trandetails.initsolid,trandetails.tranamt,trandetails.tranid,trandetails.trandate,roll_no,class);
	end if;
	end if;
end if;

end loop;															
file_ind :=1;

loc_school_id := 'X';
cr_amt := '0';

for schdet in school_det
loop

	if ( (loc_school_id = schdet.inst_code)  or (loc_school_id = 'X'))
	then

		if ( v_count = 498 )
		---{
		then
			Begin
			Select foracid,sol_id
			  into off_acct,off_sol
			  from school_acct_mast
		 	 where school_id =loc_school_id;
			Exception
			When others then
				dbms_output.put_line(loc_school_id);
			End;

			outstr := (rpad(schdet.off_acc,16,' ')||'INR'||rpad(off_sol,8,' ')||'C'||to_char(cr_amt,'99999999990.00')||rpad(('REF MIS DTD : '||sysdate),80,' '));
			utl_file.put_line(out_file,outstr);

			file_ind := file_ind + 1;
			utl_file.fclose(out_file);
			out_filename := 'schlupld_clg_&3..SUC'||lpad(file_ind,4,'0');
			out_file := utl_file.fopen(out_filepath,out_filename,out_filemode);

			outstr := (rpad(schdet.off_acc,16,' ')||'INR'||rpad(off_sol,8,' ')||'D'||to_char(cr_amt,'99999999990.00')||rpad(('REF MIS DTD : '||sysdate),80,' '));
			utl_file.put_line(out_file,outstr);

			v_count := 1;
			cr_amt := cr_amt;
		---}
		end if;

		loc_school_id := schdet.inst_code;			
		outstr := (rpad(schdet.off_acc,16,' ')||'INR'||rpad(schdet.init_sol_id,8,' ')||'D'||to_char(schdet.tran_amt,'99999999990.00')||rpad(((trim(schdet.tran_id))||'-'||substr(schdet.roll_no,1,9)||'-'||schdet.tran_date),80,' '));

		utl_file.put_line(out_file,outstr);
		v_count := v_count + 1;
		cr_amt := cr_amt + schdet.tran_amt;
	else
		Begin
		Select foracid,sol_id
		  into off_acct,off_sol
		  from school_acct_mast
	 	 where school_id = loc_school_id;
		EXCEPTION
                WHEN others then
                	dbms_output.put_line(loc_school_id);
		End;

		outstr := (rpad(off_acct,16,' ')||'INR'||rpad(off_sol,8,' ')||'C'||to_char(cr_amt,'99999999990.00')||rpad(('REF MIS DTD : '||sysdate),80,' '));
		utl_file.put_line(out_file,outstr);

		v_count := v_count + 1;	
		cr_amt := 0;
		loc_school_id := schdet.inst_code;
	
		if( v_count >= 498 )
		then
			v_count := 0;
			file_ind := file_ind + 1;
			utl_file.fclose(out_file);
			out_filename := 'schlupld_clg_&3..SUC'||lpad(file_ind,4,'0');
			out_file := utl_file.fopen(out_filepath,out_filename,out_filemode);
		end if;

		outstr := (rpad(schdet.off_acc,16,' ')||'INR'||rpad(schdet.init_sol_id,8,' ')||'D'||to_char(schdet.tran_amt,'99999999990.00')||rpad(((trim(schdet.tran_id))||'-'||substr(schdet.roll_no,1,9)||'-'||schdet.tran_date),80,' '));

		utl_file.put_line(out_file,outstr);

		v_count := v_count + 1;
		cr_amt := cr_amt + schdet.tran_amt;
	
	end if;
---		loc_school_id := schdet.inst_code;
end loop;
			Begin
			Select foracid,sol_id
			  into off_acct,off_sol
			  from school_acct_mast
		 	 where school_id = loc_school_id;
			EXCEPTION 
			WHEN others then
				dbms_output.put_line(loc_school_id);
			End;

			outstr := (rpad(off_acct,16,' ')||'INR'||rpad(off_sol,8,' ')||'C'||to_char(cr_amt,'99999999990.00')||rpad(('REF MIS DTD: '||sysdate),80,' '));
			utl_file.put_line(out_file,outstr);

utl_file.fclose(out_file);
utl_file.fclose(fai_file);
end;
/
drop table TBAUTIL.TMP_ICI_SCHOOL_CLG
/
