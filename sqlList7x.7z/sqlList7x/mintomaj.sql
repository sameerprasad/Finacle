set echo off
set termout off
set pause off
set feedback off
set verify off
whenever sqlerror exit sql.sqlcode
set pagesize 0
set linesize 500
set trims on
set heading off
set space 0

spool  &1
select  a.cust_id||'|'||
   a.cust_title_code||'|'||
   a.cust_name||'|'||
   a.cust_comu_addr1||'|'|| 
   a.cust_comu_addr2||'|'||
   a.cust_comu_city_code||'|'||
   a.cust_comu_state_code||'|'||
   a.cust_comu_pin_code||'|'||
   substr(a.cust_name,1,40)||'|'||
   foracid||'|'
from cmg a, cmt c,gam d where 
a.cust_id=c.cust_id
and a.cust_id=d.cust_id
and d.acct_cls_flg!='Y'
and minor_attain_major_date between '&2' and '&3'
and primary_sol_id='&4'
order by 1
/
spool off
ttitle off
btitle off
whenever sqlerror continue
set termout on
set feedback on
set verify on
set heading on
clear breaks 
set echo on
exit
