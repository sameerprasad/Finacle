--##############################################################################################
--#                     File Name       : LCKAVAIL.sql
--#                     Author : Mariappan.V (BBSSL)
--#                     Report : LOCKER AVAILABILITY REPORT
--#                     Date   :
--#                     Module  : LOCKER
--#                     Called Menu     : LOCKRPT
--#                     Called By       : LCKAVAIL.com
--##############################################################################################

SET HEAD OFF ECHO OFF TRIMS ON VERIFY OFF FEEDBACK OFF
SET TIMING OFF LINESIZE 1000 EMBEDDED OFF PAGES 0 TERMOUT OFF
SET NUMF 999999999999999.99
SET SERVEROUTPUT ON SIZE 1000000


spool LCKAVAIL.lst

DECLARE
v_sol_id	wlckm.sol_id%type:='&1';
avail		number;
total		number;
grandavail	number;
grandtotal	number;
i               number(5) :=0;
status		c_svrsetvar.VARIABLE_VALUE%type;
cursor cur1(v_locker_type wlckm.locker_type%type) is
	SELECT locker_type,LOCKER_NUM,KEY_NUM,SURRENDER_DATE,VARIABLE_VALUE
		FROM wlckm,c_svrsetvar
		WHERE status in ('S','A')
		AND sol_id = v_sol_id
		and locker_type = v_locker_type
		and MODULE_NAME = 'LOCKER'
		and SUB_MODULE_NAME = 'LCKM'
		and VARIABLE_NAME = status;

cursor cur2 is
	select distinct locker_type v_locker_type from wlckm
		where sol_id = v_sol_id;

BEGIN

	BEGIN
		SELECT count(a),count(b)
		into grandavail,grandtotal
		FROM
			(
			SELECT locker_type, 
			CASE WHEN status in ('A','S') THEN
			locker_num
			END a,
			CASE WHEN status IS NOT NULL THEN
			locker_num
			END b
			FROM wlckm
			WHERE sol_id = v_sol_id
			);
	END;

for f2 in cur2
loop
--(	
	i := 0;
	BEGIN
		SELECT count(a),count(b)
		into avail,total
		FROM
			(
			SELECT locker_type, 
			CASE WHEN status in ('A','S') THEN
			locker_num
			END a,
			CASE WHEN status IS NOT NULL THEN
			locker_num
			END b
			FROM wlckm
			WHERE sol_id = v_sol_id
			)
			having locker_type = f2.v_locker_type
			GROUP BY locker_type;
	END;

	


	for f1 in cur1(f2.v_locker_type)
	loop
	--(	
		BEGIN
		
		i := i+1;
		dbms_output.put_line	(	f2.v_locker_type	||'|'||
						f1.LOCKER_NUM		||'|'||
						f1.KEY_NUM		||'|'||
						f1.SURRENDER_DATE	||'|'||
						f1.VARIABLE_VALUE	||'|'||
						avail			||'|'||
						total			||'|'||
						grandavail		||'|'||
						grandtotal
					);
		END;
	--)
	end loop;
		
		if (i < 1) then
		dbms_output.put_line	(	f2.v_locker_type	||'|'||
						' '			||'|'||
						' '			||'|'||
						' '			||'|'||
						' '			||'|'||
						avail			||'|'||
						total			||'|'||
						grandavail		||'|'||
						grandtotal
					);
		END IF;

				
	--)
end loop;
END;
/
SPOOL OFF;
