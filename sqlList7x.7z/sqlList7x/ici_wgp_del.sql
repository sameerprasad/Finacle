delete from ici_wm_map where CUST_ID =lpad('&1',9)
/
commit
/
