-- Default status codes, scheme codes populated in
-- fsg_cfg table for monthly stmt gen
--
insert into fsg_cfg values('FSG',1,'TRUST',50.00,'');
insert into fsg_cfg values('FSG',1,'CLUB',50.00,'');
insert into fsg_cfg values('FSG',1,'ASSCN',50.00,'');
insert into fsg_cfg values('FSG',1,'ASSON',50.00,'');
insert into fsg_cfg values('FSG',1,'SOCTY',50.00,'');
--
