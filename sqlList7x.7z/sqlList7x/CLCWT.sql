Rem     This file will create LOCKER_WAIVE_TABLE
Rem     with the following characteristics.

Rem     Coded by : Mariappan (BBSSL)

Rem     Module  : LOCKER


Rem TABLE NAME: LOCKER_WAIVE_TABLE

Rem SYNONYM:    LOCKER_WAIVE_TABLE

drop table icici.LOCKER_WAIVE_TABLE
/
drop public synonym CLCWT
/
create table icici.LOCKER_WAIVE_TABLE
( 
	sol_id varchar2(8),
	cust_id varchar2(9),
	locker_number varchar2(12),
	rent_waived number(20,4) default 0,
	charges_waived number(20,4) default 0,
	waive_remarks varchar2(50),
	file_no varchar2(50),
	waive_date date,
	lchg_user_id varchar2(15),
	lchg_time date,
	rcre_user_id varchar2(15),
	rcre_time date,
	del_flg char(1)
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
create public synonym CLCWT  for icici.LOCKER_WAIVE_TABLE
/
create index IDX_CLCWT on icici.LOCKER_WAIVE_TABLE( SOL_ID,CUST_ID,LOCKER_NUMBER )
/
grant select, insert, update, delete on CLCWT  to tbagen
/
grant select on CLCWT  to tbacust
/
grant select on CLCWT  to tbautil
/
grant all on CLCWT to tbaadm
/
