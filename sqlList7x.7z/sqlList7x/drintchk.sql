rem accept solid prompt 'ENTER 4 DIGITS OF THE SOL_ID OF YOUR BRANCH :: '

set feedback off
set termout off
set echo off
set wrap off
set pause off
set verify off
set pagesize 60 
set lines 80
set numformat 999,999,99,999.99

ttitle "LIST OF ACCOUNTS WHERE DEBIT INTEREST IS NOT COMPLETED AS ON 30/09/2002"

spool &1.drintchk

select b.foracid,
       a.last_interest_run_date_dr rundate,
       a.last_int_dr_tran_date pstddt,
       b.clr_bal_amt
from eit a, gam b
where b.sol_id='&1'
and  a.entity_id=b.acid
and b.clr_bal_amt+b.un_clr_bal_amt < 0
and b.acct_cls_flg = 'N'
and b.del_flg = 'N'
-- and a.last_int_dr_tran_date between '01-12-2001' and '31-12-2001'
and a.last_int_dr_tran_date <'&2'
and b.acct_prefix in ('05','51', '52', '53', '54', '55', '60') 
and clr_Bal_amt <0
order by 1, 2
/
spool off
exit   
