set verify off
set pages 0
set trims on
spool altertbl
SELECT 'Adding fields home_sol_id and stmt_reqd to ICICI_CIFT table...' FROM DUAL;
ALTER TABLE ICICI_CUST_INFO_FILE_TBL ADD ( home_sol_id   VARCHAR2(8), stmt_reqd  CHAR(1));
ALTER TABLE ICICI_CUST_INFO_MOD_TBL ADD ( home_sol_id   VARCHAR2(8), stmt_reqd  CHAR(1));
spool off
set termout off
set feedback off
spool custpfx
SELECT SUBSTR(sol_id, 3, 4) 
FROM sol;
SELECT '50' FROM DUAL;
spool off
QUIT
