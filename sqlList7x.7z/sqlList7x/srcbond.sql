set lines 132
set pages 0
set heading off
set verify off
set feedback off
set echo off
set trims on
set serveroutput on SIZE 1000000
spool srcbond-&1
select tran_id || '|' || tran_amt || '|' || part_tran_type || '|' || 
	substr(tran_particular, instr(tran_particular,',',1,1)-4, length(tran_particular) )
	 || '|' || 
	htd.entry_user_id || '|' || htd.vfd_user_id || '|' || htd.tran_date || '|' ||
	htd.value_date
from htd, gam
where 
gam.foracid = (select decode(dc_alias,'D6', '0017SLSRCBND', 'Q4', '6044SL9SCSSC', '0018SL9SCSSC') from gct)
and htd.acid = gam.acid
and htd.value_date = '&1'
and htd.del_flg != 'Y'
union
select tran_id || '|' || tran_amt || '|' || part_tran_type || '|' ||  
	substr(tran_particular, instr(tran_particular,',',1,1)-4, length(tran_particular) )
	 || '|' || 
	dtd.entry_user_id || '|' || dtd.vfd_user_id || '|' || dtd.tran_date || '|' ||
	dtd.value_date
from dtd, gam
where 
gam.foracid = (select decode(dc_alias,'D6', '0017SLSRCBND', 'Q4', '6044SL9SCSSC', '0018SL9SCSSC') from gct)
and dtd.acid = gam.acid
and dtd.value_date = '&1'
and dtd.del_flg != 'Y'
/
spool off
