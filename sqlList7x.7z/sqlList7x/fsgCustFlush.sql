set head off
set trims on
set pages 0
set feedback off
set verify off
set termout off
spool Flush.log

SELECT 'Flushing the PSP_TMP table ...' FROM DUAL;

DELETE	PSP_TMP
WHERE	listid LIKE '&1'||'%' ;

UPDATE	ICICI_LDTT
SET	remarks = 'F'
WHERE	dc_alias = (select dc_alias from gct)
AND	driver_id = 'FSG'
AND	sol_id = substr('&1', 4, 4)
AND	ser_num = substr('&1', 9, 1);

INSERT INTO ICI_STMT_LOG values (lpad('&2',9),'&3','&4','&5','&6',sysdate);

COMMIT;

spool off
