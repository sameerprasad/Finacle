--##############################################################################################
--#                     File Name       : LCLOSTRPT.sql
--#                     Author : Ashwani Bhat (BBSSL)
--#                     Report : Key Lost Report
--#                     Date   :
--#                     Module  : LOCKER
--#                     Called Menu     : LOCKRPT
--#                     Called By       : LCLOSTRPT.com
--##############################################################################################


SET SERVEROUTPUT ON SIZE 1000000;
SET VERIFY OFF
SET TERMOUT OFF
SET TRIMSPOOL ON
SET ECHO OFF
SET FEEDBACK OFF
SET EMBEDDED ON
SET LINES 400
SET HEAD OFF
SET PAGES 0
clear columns
clear breaks
clear computes
--SET NUMF 999999999999999.99
spool LCLOSTRPT.lst

declare

v_sol_id		gam.sol_id%type := '&1';
v_date			date := '&2';
v_cust_name		cmg.cust_name%type;

CURSOR c1 is
	SELECT lclost.locker_num,
     		clmt.locker_type,
     		lclost.key_num,
     		clmt.cust_id,
     		lclost.LOST_DATE,
     		lclost.lost_time,
     		lclost.INFORMED_BY
 	FROM
 		lclost,clmt
 	WHERE  	lclost.sol_id = v_sol_id
 	and	lclost.locker_num = clmt.locker_num
 	and	lclost.lost_date <= to_date(v_date,'dd-mm-yyyy')
	 order by 1,2;	
 BEGIN
 
     DBMS_OUTPUT.ENABLE (buffer_size => NULL);
     
 FOR f1 in c1
 LOOP
 	BEGIN
 		SELECT
 			SUBSTR(cust_name,1,45)
 		INTO
 			v_cust_name
 		FROM	cmg
 		WHERE   cust_id = f1.cust_id
 		and	DEL_FLG != 'Y';
 		EXCEPTION WHEN NO_DATA_FOUND THEN
 			v_cust_name := NULL;
 	END;
 
 		DBMS_OUTPUT.PUT_LINE( f1.locker_num		||'|'||
 					f1.locker_type		||'|'||
 					f1.key_num		||'|'||
 					f1.cust_id		||'|'||
 					f1.lost_date		||'|'||
 					f1.lost_time		||'|'||
 					f1.INFORMED_BY		||'|'||
					v_cust_name		
				   );
END LOOP; 				   
END;
/
spool off
 				    
