Rem     This file will create ICICI_CUST_DNC_TABLE
Rem     with the following characteristics.

Rem TABLE NAME: ICICI.ICICI_CUST_DNC_TABLE

Rem SYNONYM:    ICICI.ICICI_CUST_DNC

drop table ICICI.ICICI_CUST_DNC_TABLE
/
drop public synonym ICICI_CUST_DNC
/
drop public synonym DNC
/
create table ICICI.ICICI_CUST_DNC_TABLE
( 
 CUST_ID			VARCHAR2(9),
 DNC_FLG			CHAR(1),
 ELEC_MAT			CHAR(1),
 PHYS_MAT			CHAR(1),
 ENTITY_CRE_FLG			CHAR(1),
 DEL_FLG			CHAR(1),
 LCHG_USER_ID			VARCHAR2(15),
 LCHG_TIME			DATE,
 RCRE_USER_ID			VARCHAR2(15),
 RCRE_TIME			DATE
)
/

create public synonym ICICI_CUST_DNC
    for ICICI.ICICI_CUST_DNC_TABLE
/
create public synonym DNC
    for ICICI.ICICI_CUST_DNC_TABLE
/
create unique index ICICI.IDX_ICICI_CUST_DNC_TABLE
	on ICICI.ICICI_CUST_DNC_TABLE ( CUST_ID )
/
grant select, insert, update, delete on ICICI.ICICI_CUST_DNC_TABLE to tbagen,tbacust
/
grant select on ICICI.ICICI_CUST_DNC_TABLE to tbautil
/
