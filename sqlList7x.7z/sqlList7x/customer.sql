-- #############################################################
-- #	Source Name: customer.sql				   		       #
-- #	Description: This script is used to get the required   #
-- #				 details for customer                      # 
-- #				 in ~ seperated format.                    #
-- #############################################################

Set ServerOutPut On Size 1000000
--Set Verify Off
--Set FeedBack off
--set line 80
set trims on

--Spool customer.txt

DECLARE

inpDate				varchar2(25);

-- Temporary variables.
phone				UTL_FILE.FILE_TYPE;
address				UTL_FILE.FILE_TYPE;
relation			UTL_FILE.FILE_TYPE;
personal			UTL_FILE.FILE_TYPE;
portrait			UTL_FILE.FILE_TYPE;
business			UTL_FILE.FILE_TYPE;
portfolio			UTL_FILE.FILE_TYPE;
tmpAcid				GAM.acid%type;
tmpFora				GAM.foracid%type;
tmpCustId			CMG.cust_id%type;
solId				GAM.sol_id%type;
city				RCT.ref_desc%type;
country				RCT.ref_desc%type;
country_flg			number(1) := 0;
cimnumb				CMG.cust_id%type;
frstname			CMG.cust_name%type;
busname				CMG.cust_name%type;
cphone1				CMG.cust_comu_phone_num_1%type;
cphone2				CMG.cust_comu_phone_num_2%type; 
pphone1				CMG.cust_perm_phone_num%type; 
pphone2				CMG.cust_perm_phone_num_2%type; 
ephone1				CMG.cust_emp_phone_num_1%type; 	
ephone2				CMG.cust_emp_phone_num_2%type; 
pager				CMG.cust_pager_no%type; 
cfax				CMG.cust_fax_no%type; 
pfax				CMG.cust_perm_fax_num%type; 
efax				CMG.cust_emp_fax_num%type; 
ptelex				CMG.cust_perm_telex_num%type; 
ctelex				CMG.cust_comu_telex_num%type; 
etelex				CMG.cust_emp_telex_num%type; 
paddr				varchar(100); 
caddr				varchar(100); 
eaddr				varchar(100);
addr1				varchar(40);
addr2				varchar(40);
addr3				varchar(40);
begdate				CMG.cust_opn_date%type; 
pcity				CMG.cust_perm_city_code%type; 
ccity				CMG.cust_comu_city_code%type; 
ecity				CMG.cust_emp_city_code%type; 
pcountry			CMG.cust_perm_cntry_code%type; 
ccountry			CMG.cust_comu_cntry_code%type; 
ecountry			CMG.cust_emp_cntry_code%type; 
ppin				CMG.cust_perm_pin_code%type; 
cpin				CMG.cust_comu_pin_code%type; 
epin				CMG.cust_emp_pin_code%type; 
pstate				CMG.cust_perm_state_code%type; 
cstate				CMG.cust_comu_state_code%type; 
estate				CMG.cust_emp_state_code%type; 
const				CMG.cust_const%type; 
dob					CMG.date_of_birth%type; 
marital				CMG.cust_marital_status%type; 
prefix				CMG.cust_title_code%type; 
salary				CMG.cust_salary%type; 
sex					CMG.cust_sex%type; 
email				CMG.email_id%type; 
shortname			CMG.cust_short_name%type; 
typ					CMG.cust_type_code%type; 
occuCatg			CMG.cust_occp_code%type;
seqnum1				number := 1;
seqnum2				number := 1;
jointNum			number := 0;
stopCnt				number := 0; 
acctrel				number := 1;
yearsEmp			number(2) := 0;
occup				number(4) := 0;
sal					number(1) := 0;
bustype				number(4) := 6;
employer			varchar2(30) := '';
motherMaiden		varchar2(50) := '';
maritalCd			char(1);
abbr 				varchar2(5) := 'SOLEO';
descript			varchar2(100) := 'Sole Owner';
bOrp				varchar2(1) := 'P';
branch				varchar2(6);
begChar				varchar2(10);
dobChar				varchar2(10);
det_line1			varchar2(1000) := '';
det_line2			varchar2(1000) := '';
det_line3			varchar2(1000) := '';
det_line4			varchar2(1000) := '';
det_line5			varchar2(1000) := '';
det_line6			varchar2(1000) := '';
det_line7			varchar2(1000) := '';

CURSOR 	RSP_CURSOR IS 
	SELECT 	cust_id,gam.acid,foracid,sol_id
	FROM 	gam,gac
	WHERE 	gam.acid = gac.acid
	AND		gam.schm_code in (	select 	distinct schm_code 
								from 	RSP 
								where 	entity_cre_flg = 'Y'
								and 	del_flg != 'Y')
	AND		gac.dpd_cntr >= 1
	AND		gam.acct_cls_flg != 'Y'
	AND		gam.entity_cre_flg = 'Y'
	AND		gam.del_flg != 'Y'
	ORDER BY cust_id;

CURSOR 	AAS_CURSOR IS 
	SELECT 	cust_id
	FROM 	aas
	WHERE	acid = tmpAcid
	AND		acct_poa_as_srl_num > '000'
	AND		acct_poa_as_rec_type = 'J'
	AND		lchg_time >= to_date(inpDate,'DD-MM-YYYY HH24:MI:SS');


BEGIN
--{
	inpDate := '&1';

	phone		:= UTL_FILE.FOPEN('/tmp','ex_phone.csv','w');
	address		:= UTL_FILE.FOPEN('/tmp','ex_address.csv','w');
	relation	:= UTL_FILE.FOPEN('/tmp','ex_relation.csv','w');
	personal	:= UTL_FILE.FOPEN('/tmp','ex_personal.csv','w');
	portrait	:= UTL_FILE.FOPEN('/tmp','ex_portrait.csv','w');
	business	:= UTL_FILE.FOPEN('/tmp','ex_business.csv','w');
	portfolio	:= UTL_FILE.FOPEN('/tmp','ex_portfoli.csv','w');

	OPEN RSP_CURSOR;

	LOOP
	--{
		FETCH RSP_CURSOR into tmpCustId,tmpAcid,tmpFora,solId;

		EXIT WHEN RSP_CURSOR%NOTFOUND;
		
		IF (tmpCustId is NOT NULL) THEN
		--{
			BEGIN
			--{
				SELECT	1
				INTO	jointNum
				FROM	DUAL
				WHERE	EXISTS (SELECT	cust_id
								FROM 	AAS
								WHERE	acid = tmpAcid
								AND		acct_poa_as_srl_num > '000'
								AND		acct_poa_as_rec_type = 'J');
			EXCEPTION WHEN OTHERS THEN
				jointNum := 0;
			--}
			END;
		--}
		END IF;
		
		stopCnt := 1;
		acctrel := 1;
		abbr 	:= 'SOLEO';
		descript:= 'Sole Owner';

		IF (jointNum != 0) THEN
			OPEN AAS_CURSOR;
			acctrel := 5;
			abbr	:= 'JOINT';
			descript:= 'Joint or Other';
		END IF;
		
		LOOP
		--{
			addr1 := '-';
			addr2 := '-';
			addr3 := '-';

			IF (AAS_CURSOR%ISOPEN) THEN
				FETCH AAS_CURSOR into tmpCustId;
				IF (AAS_CURSOR%NOTFOUND) THEN
					CLOSE AAS_CURSOR;
					EXIT;
				END IF;
			END IF; 

			cimnumb := NULL;
			paddr := NULL;
			caddr := NULL;
			eaddr := NULL;
			
			BEGIN
			--{
				SELECT	cust_id,substr(cust_name,1,40),substr(cust_name,1,15),
						nvl(trim(substr(lpad(cust_comu_phone_num_1,15),6)),'0'),
						trim(substr(lpad(cust_comu_phone_num_2,15),6)),
						trim(substr(lpad(cust_perm_phone_num,15),6)),trim(substr(lpad(cust_perm_phone_num_2,15),6)),
						trim(substr(lpad(cust_emp_phone_num_1,15),6)),trim(substr(lpad(cust_emp_phone_num_2,15),6)),
						trim(substr(lpad(cust_pager_no,15),6)),trim(substr(lpad(cust_fax_no,15),6)),
						trim(substr(lpad(cust_perm_fax_num,15),6)),trim(substr(lpad(cust_emp_fax_num,15),6)),
						trim(substr(lpad(cust_perm_telex_num,15),6)),trim(substr(lpad(cust_comu_telex_num,15),6)),
						trim(substr(lpad(cust_emp_telex_num,15),6)),cust_perm_addr1||' '||cust_perm_addr2,
						cust_comu_addr1||' '||cust_comu_addr2,
						cust_emp_addr1||' '||cust_emp_addr2,
						nvl(cust_opn_date,'01-01-1900'),cust_perm_city_code,
						cust_comu_city_code,cust_emp_city_code,
						cust_perm_cntry_code,cust_comu_cntry_code,
						cust_emp_cntry_code,cust_perm_pin_code,
						cust_comu_pin_code,cust_emp_pin_code,
						substr(cust_perm_state_code,1,2),substr(cust_comu_state_code,1,2),
						substr(cust_emp_state_code,1,2),cust_const,
						date_of_birth,cust_marital_status,
						cust_title_code,cust_salary,
						cust_sex,email_id,cust_short_name,
						cust_type_code,cust_occp_code
				INTO	cimnumb,busname,frstname,cphone1,cphone2,pphone1,pphone2,
						ephone1,ephone2,pager,cfax,pfax,efax,ptelex,ctelex,
						etelex,paddr,caddr,eaddr,begdate,pcity,ccity,ecity,
						pcountry,ccountry,ecountry,ppin,cpin,epin,pstate,
						cstate,estate,const,dob,marital,prefix,salary,sex,
						email,shortname,typ,occuCatg
				FROM 	CMG
				WHERE 	cust_id = lpad(tmpCustId,9)
				AND		lchg_time >= to_date(inpDate,'DD-MM-YYYY HH24:MI:SS')
				AND		entity_cre_flg = 'Y'
				AND		del_flg != 'Y';
	
			EXCEPTION
				WHEN OTHERS THEN NULL;
			--}
			END;

			if (cimnumb is NOT NULL) then
			--{
				seqnum1 := 1;
		
				begin
				--{
					select	to_char(begdate,'mm-dd-yyyy'),to_char(dob,'mm-dd-yyyy')
					into	begChar,dobChar
					from	DUAL;
				exception
					WHEN OTHERS THEN NULL;
				--}
				end;

				while seqnum1 <= 13 
				loop
				--{
					if (seqnum1 = 1) then
						det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||cphone1||'~'||'P'||'~'||seqnum1;
						UTL_FILE.PUT_LINE(phone,det_line1);
					elsif (seqnum1 = 2 and cphone2 is NOT NULL) then
						det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||cphone2||'~'||'P'||'~'||seqnum1;
						UTL_FILE.PUT_LINE(phone,det_line1);
					elsif (seqnum1 = 3 and pphone1 is NOT NULL) then
						det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||pphone1||'~'||'O'||'~'||seqnum1;
						UTL_FILE.PUT_LINE(phone,det_line1);
					elsif (seqnum1 = 4 and pphone2 is NOT NULL) then
						det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||pphone2||'~'||'O'||'~'||seqnum1;
						UTL_FILE.PUT_LINE(phone,det_line1);
					elsif (seqnum1 = 5 and ephone1 is NOT NULL) then
						det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||ephone1||'~'||'B'||'~'||seqnum1;
						UTL_FILE.PUT_LINE(phone,det_line1);
					elsif (seqnum1 = 6 and ephone2 is NOT NULL) then
						det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||ephone2||'~'||'B'||'~'||seqnum1;
						UTL_FILE.PUT_LINE(phone,det_line1);
					elsif (seqnum1 = 7 and pager is NOT NULL) then
						det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||pager||'~'||'M'||'~'||seqnum1;
						UTL_FILE.PUT_LINE(phone,det_line1);
					elsif (seqnum1 = 8  and cfax is NOT NULL) then
						det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||cfax||'~'||'F'||'~'||seqnum1;   
						UTL_FILE.PUT_LINE(phone,det_line1);
					elsif (seqnum1 = 9  and pfax is NOT NULL) then
						det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||pfax||'~'||'F'||'~'||seqnum1;   
						UTL_FILE.PUT_LINE(phone,det_line1);
					elsif (seqnum1 = 10  and efax is NOT NULL) then
						det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||efax||'~'||'F'||'~'||seqnum1;   
						UTL_FILE.PUT_LINE(phone,det_line1);
					elsif (seqnum1 = 11  and ctelex is NOT NULL) then
						det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||ctelex||'~'||'O'||'~'||seqnum1;   
						UTL_FILE.PUT_LINE(phone,det_line1);
					elsif (seqnum1 = 12  and ptelex is NOT NULL) then
						det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||ptelex||'~'||'O'||'~'||seqnum1;   
						UTL_FILE.PUT_LINE(phone,det_line1);
					elsif (seqnum1 = 13  and etelex is NOT NULL) then
						det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||etelex||'~'||'O'||'~'||seqnum1;   
						UTL_FILE.PUT_LINE(phone,det_line1);
					end if;

					seqnum1 := seqnum1 + 1;
				--}
				end loop;

				seqnum2 := 1;

				while seqnum2 <= 3 
				loop
				--{
					city := NULL;
					if (seqnum2 = 1 and (trim(paddr) is NOT NULL)) then
						addr1 := substr(paddr,1,30);
						addr2 := substr(paddr,31,30);
						addr3 := substr(paddr,61,30); 

						BEGIN
						--{
							SELECT 	substr(ref_desc,1,26)
							INTO	city
							FROM 	RCT
							WHERE 	ref_rec_type ='01'
							AND		ref_code = pcity
							AND		del_flg != 'Y';

						EXCEPTION
							WHEN OTHERS THEN NULL;
						--}
						END;

						BEGIN
						--{
							SELECT 	substr(ref_desc,1,26)
							INTO	country
							FROM 	RCT
							WHERE 	ref_rec_type ='03'
							AND		ref_code = pcountry
							AND		del_flg != 'Y';

						EXCEPTION
							WHEN OTHERS THEN NULL;
						--}
						END;
						
						if(country = 'INDIA') then
							country_flg := 0;
						else
							country_flg := 1;
						end if;
						det_line2 := addr1||'~'||addr2||'~'||addr3||'~'||cimnumb||'~'||begChar||'~'||city||'~'||country||'~'||country_flg||'~~~'||ppin||'~'||pstate||'~~'||'0'||'~'||cimnumb||'~1~';
						UTL_FILE.PUT_LINE(address,det_line2);
						paddr := NULL;
					elsif (seqnum2 = 2 and (trim(caddr) is NOT NULL))then
						addr1 := substr(caddr,1,30);
						addr2 := substr(caddr,31,30);
						addr3 := substr(caddr,61,30); 

						BEGIN
						--{
							SELECT 	substr(ref_desc,1,26)
							INTO	city
							FROM 	RCT
							WHERE 	ref_rec_type ='01'
							AND		ref_code = ccity
							AND		del_flg != 'Y';

						EXCEPTION
							WHEN OTHERS THEN NULL;
						--}
						END;

						BEGIN
						--{
							SELECT 	substr(ref_desc,1,26)
							INTO	country
							FROM 	RCT
							WHERE 	ref_rec_type ='03'
							AND		ref_code = ccountry
							AND		del_flg != 'Y';

						EXCEPTION
							WHEN OTHERS THEN NULL;
						--}
						END;
						
						if(country = 'INDIA') then
							country_flg := 0;
						else
							country_flg := 1;
						end if;

						det_line2 := addr1||'~'||addr2||'~'||addr3||'~'||cimnumb||'~'||begChar||'~'||city||'~'||country||'~'||country_flg||'~~~'||cpin||'~'||cstate||'~~'||'0'||'~'||cimnumb||'~2~';
						UTL_FILE.PUT_LINE(address,det_line2);
						caddr := NULL;  
					elsif (seqnum2 = 3 and (trim(eaddr) is NOT NULL)) then
						addr1 := substr(eaddr,1,30);
						addr2 := substr(eaddr,31,30);
						addr3 := substr(eaddr,61,30); 

						BEGIN
						--{
							SELECT 	substr(ref_desc,1,26)
							INTO	city
							FROM 	RCT
							WHERE 	ref_rec_type ='01'
							AND		ref_code = ecity
							AND		del_flg != 'Y';

						EXCEPTION
							WHEN OTHERS THEN NULL;
						--}
						END;

						BEGIN
						--{
							SELECT 	substr(ref_desc,1,26)
							INTO	country
							FROM 	RCT
							WHERE 	ref_rec_type ='03'
							AND		ref_code = ecountry
							AND		del_flg != 'Y';

						EXCEPTION
							WHEN OTHERS THEN NULL;
						--}
						END;
						
						if(country = 'INDIA') then
							country_flg := 0;
						else
							country_flg := 1;
						end if;

						det_line2 := addr1||'~'||addr2||'~'||addr3||'~'||cimnumb||'~'||begChar||'~'||city||'~'||country||'~'||country_flg||'~~~'||epin||'~'||estate||'~~'||'0'||'~'||cimnumb||'~3~';
						UTL_FILE.PUT_LINE(address,det_line2);
						eaddr := NULL; 
					end if;

					seqnum2 := seqnum2 + 1;
				--}
				end loop;

				det_line3 := abbr||'~'||acctrel||'~'||descript||'~~';
				UTL_FILE.PUT_LINE(relation,det_line3);

--***		Modified to actual typ values at client site
				if (typ = '40' or typ = '41' or typ = '42') then
					bOrp := 'P';
				else
					bOrp := 'B';
				end if;

				det_line5 := solId||'~'||cimnumb||'~0~'||email||'~~~~'||begChar||'~'||shortname||'~'||bOrp;
				UTL_FILE.PUT_LINE(portrait,det_line5);

				begin
				--{
					select	employed_company, mothers_maiden_name,
							employed_years_of_service
					into	employer,motherMaiden,yearsEmp
					from	ICICI_CIFT
					where	cust_id = lpad(tmpCustId,9);
				exception
					when others then NULL;
				--}
				end;

--***		Occup changed based on values in icici_cift
                if (occuCatg = '003') then
                    occup := 2;
                elsif (occuCatg = '002') then
                    occup := 3;
                elsif (occuCatg = '500') then
                    occup := 9;
                elsif (occuCatg = 'DOCA') then
                    occup := 11;
                elsif (occuCatg = 'DOCB') then
                    occup := 11;
                elsif (occuCatg = 'DOCC') then
                    occup := 11;
                elsif (occuCatg = 'DOCD') then
                    occup := 11;
                elsif (occuCatg = '363') then
                    occup := 12;
                elsif (occuCatg = '004') then
                    occup := 14;
                elsif (occuCatg = '898') then
                    occup := 15;
                elsif (occuCatg = '008') then
                    occup := 22;
                elsif (occuCatg = '940') then
                    occup := 23;
                elsif (occuCatg = '007') then
                    occup := 26;
                elsif (occuCatg = '006') then
                    occup := 28;
                elsif (occuCatg = '963') then
                    occup := 32;
                else
                    occup := 0;
                end if;

				if (salary >= 10000 and salary <= 25000) then
					sal := 1;
				elsif (salary >= 25001 and salary <= 50000) then 
					sal := 2;
				elsif (salary >= 50001 and salary <= 100000) then 
					sal := 3;
				elsif (salary >= 100001 and salary <= 500000) then 
					sal := 4;
				elsif (salary >= 500001 and salary <= 1000000) then 
					sal := 5;
				elsif (salary >= 1000001 and salary <= 2500000) then 
					sal := 6;
				else
					sal := 7;
				end if;

				if (marital = 'MARID') then
					maritalCd := 'M';
				elsif (marital = 'SINGL') then
					maritalCd := 'S';
				else
					maritalCd := NULL;
				end if;
				
				if( bOrp = 'P') then
					det_line4 := cimnumb||'~'||dobChar||'~~~~'||employer||'~~'||frstname||'~-~'||maritalCd||'~~'||motherMaiden||'~'||occup||'~'||prefix||'~'||sal||'~'||sex||'~~~'||yearsEmp;
					UTL_FILE.PUT_LINE(personal,det_line4);
				end if;

--***		Modified to actual bustype value at client site
				if (typ = 'ASSON') then
					bustype := 1;
				elsif (typ = '33') then
					bustype := 3;
--***			elsif (typ = '40') then
--***				bustype := 6;
				elsif (typ = '63' or typ = '70' or typ = 'TRUST') then
					bustype := 7;
				elsif (typ = '15') then
					bustype := 10;
				elsif (typ = '32') then
					bustype := 14;
				elsif (typ = '31') then
					bustype := 15;
				elsif (typ = '20') then
					bustype := 16;
				else
					bustype := 99;
				end if;

				if( bOrp = 'B') then
					det_line6 := busname||'~'||bustype||'~'||cimnumb||'~0';
					UTL_FILE.PUT_LINE(business,det_line6);
				end if;

				det_line7 := 'LN~'||tmpFora||'~'||acctrel||'~999~'||cimnumb||'~'||cimnumb||'~0';
				UTL_FILE.PUT_LINE(portfolio,det_line7);
			--}
			end if;

			if(jointNum = 0)then
				EXIT;
			end if;
		--}
		END LOOP;
	--}
	END LOOP;

	UTL_FILE.FCLOSE(phone);
	UTL_FILE.FCLOSE(address);
	UTL_FILE.FCLOSE(relation);
	UTL_FILE.FCLOSE(personal);
	UTL_FILE.FCLOSE(portrait);
	UTL_FILE.FCLOSE(business);
	UTL_FILE.FCLOSE(portfolio);
	CLOSE RSP_CURSOR;
--}
END;
/
exit
--spool off
