set serveroutput on size 1000000 
set feedback off
set verify   off
set termout   off
set head off
set pages 0
set linesize 512
set trims on
spool &1-&2-&3-&4

DECLARE
cnt			number;
firstAcc		GAM.FORACID%Type;
runId			varchar2(20);
custId			ICICI_CIFT.CUST_ID%Type;
solId			ICICI_CIFT.HOME_SOL_ID%Type;
ciftCustId		ICICI_CIFT.CUST_ID%Type;
ciftStmtReqd            ICICI_CIFT.stmt_reqd%TYPE;
dispMode            ICICI_CIFT.stmt_reqd%TYPE;
gamForacid		GAM.FORACID%Type;
custRecType		VARCHAR(3);
custSubRecType	VARCHAR(3);
pspCustListId	PSP_TMP.LISTID%Type;
pspAcctListId	PSP_TMP.LISTID%Type;
endOfGamCursor	NUMBER;
step			NUMBER(5);
likeStr			varchar2(25);
ciftEmailId		ICICI_CIFT.EMAIL_ID%Type;
cmgTitleName	varchar2(100);
cmgAddr1		CMG.cust_comu_addr1%TYPE;
cmgAddr2		CMG.cust_comu_addr2%TYPE;
cmgCityCode		CMG.cust_comu_city_code%TYPE;
cmgStateCode	CMG.cust_comu_state_code%TYPE;
cmgCntryCode	CMG.cust_comu_cntry_code%TYPE;
cmgCustStatCode CMG.cust_stat_code%TYPE;
cmgPinCode		CMG.cust_comu_pin_code%TYPE;
cmgPhone1		CMG.cust_comu_phone_num_1%TYPE;
cmgPhone2		CMG.cust_comu_phone_num_2%TYPE;
idType			char(2);
idTypeOld			char(1);
-- Changes for custnreflg
cmgCustNreFlag	cmg.cust_nre_flg%type;
cmgConst		cmg.cust_const%type;
tmpConst		cmg.cust_const%type;
wbgCust			char(1);

cityDesc		RCT.ref_desc%TYPE;
stateDesc		RCT.ref_desc%TYPE;
cntryDesc		RCT.ref_desc%TYPE;

carRec          varchar2(500);
	
CURSOR gamCur IS 
SELECT	
	FORACID
FROM	
	GAM
WHERE	
	CUST_ID = custId
AND	(SCHM_TYPE = 'SBA' OR ACCT_PREFIX = '05' or ACCT_PREFIX = '51')
AND	((ACCT_CLS_FLG = 'N' AND ACCT_OPN_DATE <= '&7') OR
	 (ACCT_CLS_FLG = 'Y' AND ACCT_CLS_DATE > '&7'))
AND	ENTITY_CRE_FLG = 'Y' order by foracid ;


PROCEDURE insertPspTmp( pspListId VARCHAR2,
		                pspEntityId VARCHAR2,
		                pspEntityType CHAR,
						pspHomeSolId VARCHAR2) IS
BEGIN
	step := 5;
	INSERT INTO
	PSP_TMP
		(LISTID
		,ENTITY_ID
		,ID_TYPE
		,HOME_SOL_ID)
	VALUES
		(pspListId
		,pspEntityId
		,pspEntityType
		,pspHomeSolId);
END insertPspTmp;


PROCEDURE processGamCursor( dummy NUMBER) IS
BEGIN
	step := 4;
	FETCH gamCur
	INTO gamForacid;

	IF( gamCur%NOTFOUND ) then 
		endOfGamCursor := 1; 
		RETURN; 
	END IF; 

	if(cnt = 0) then
		firstAcc := gamForacid;
		cnt := 1;
	end if;

        if (substr(gamForacid,5,2) != '51') then
                insertPspTmp(pspAcctListId, gamForacid, idTypeOld, solId);
        else
           if (dispMode = 'E') then
                insertPspTmp(pspAcctListId, gamForacid, idTypeOld, solId);
           end if;
        end if;

END processGamCursor;
		

BEGIN
	custRecType		:= '01';
	custSubRecType	:= '0';
	cnt		:= 0;
	runId			:= '&1';
	solId			:= '&2';
	idType			:= substr('&4',1,2);
	idTypeOld		:= substr('&4',1,1);
	custId			:= lpad('&5', 9);
	dispMode                := '&8';
	pspCustListId	:= runId||solId||idType||'C';
	pspAcctListId	:= runId||solId||idType||'A';

	OPEN gamCur;
	endOfGamCursor := 0;

	firstAcc := '';
	WHILE (endOfGamCursor = 0) LOOP
		processGamCursor(0);
	END LOOP;

	CLOSE gamCur;

	SELECT	cust_title_code || '.' || cust_name,
			cust_comu_addr1,
			cust_comu_addr2,
			cust_comu_city_code,
			cust_comu_state_code,
			cust_comu_cntry_code,
			cust_comu_pin_code,
			cust_comu_phone_num_1,
			cust_comu_phone_num_2,
			cust_stat_code,
			cust_nre_flg,
			cust_const
	INTO	cmgTitleName,
			cmgAddr1,
			cmgAddr2,
			cmgCityCode,
			cmgStateCode,
			cmgCntryCode,
			cmgPinCode,
			cmgPhone1,
			cmgPhone2,
			cmgCustStatCode,
			cmgCustNreFlag,
			cmgConst
	FROM	CMG
	WHERE	CUST_ID = custId;

	if(cmgCustNreFlag = 'Y') then
		cmgCustStatCode := 'NRI';
	end if;

	if(substr(cmgCustStatCode,1,3) = 'HNI') then
		cmgCustStatCode := 'HNI';
	end if;

	SELECT  cust_id,
		email_id,
		stmt_reqd
	INTO
		ciftCustId,
		ciftEmailId,
		ciftStmtReqd
	FROM ICICI_CIFT
 	WHERE   CUST_ID = custId;

	if (cmgCityCode is not null) then
		BEGIN
		SELECT	ref_desc
		INTO	cityDesc
		FROM	RCT
		WHERE	ref_rec_type = '01'
		AND		ref_code = cmgCityCode;
		EXCEPTION WHEN OTHERS THEN NULL;
		END;
	else
		cityDesc := '';
	end if;

	if (cmgStateCode is not null) then
		BEGIN
		SELECT	ref_desc
		INTO	stateDesc
		FROM	RCT
		WHERE	ref_rec_type = '02'
		AND		ref_code = cmgStateCode;
		EXCEPTION WHEN OTHERS THEN NULL;
		END;
	else
		stateDesc := '';
	end if;

	if (cmgCntryCode is not null) then
		BEGIN
		SELECT	ref_desc
		INTO	cntryDesc
		FROM	RCT
		WHERE	ref_rec_type = '03'
		AND		ref_code = cmgCntryCode;
		EXCEPTION WHEN OTHERS THEN NULL;
		END;
	else
		cntryDesc := '';
	end if;

	-- Check if cust const is one of WBG const codes

	wbgCust := 'N';
	tmpConst := '';

	BEGIN
		select key_value into tmpConst from fsg_cfg where key_type = 99 and
		key_value = cmgConst;	

		if(tmpConst = cmgConst) then
			wbgCust := 'Y';
		end if;

		exception
			when others then null;
	END;

	if(wbgCust = 'N') then
		tmpConst := '';
	end if;

	if ( cnt > 0 ) then
		insertPspTmp(pspCustListId, custId, idTypeOld, solId);

	if ( dispMode = 'E' ) then
               dbms_output.put_line(    solId               || '|' ||
                                ciftCustId              || '|01|0|' ||
                                ciftEmailId             || '|' ||
                                ltrim(rtrim(cmgTitleName))    || '|' ||
                                ltrim(rtrim(cmgAddr1))                || '|' ||
                                ciftCustId               || '|' ||
                                ltrim(rtrim(cityDesc))              || '|' ||
                                ltrim(rtrim(stateDesc)) || '|' ||
                                ltrim(rtrim(cntryDesc)) || ' - ' ||
                                ltrim(rtrim(cmgPinCode)) || '|' ||
 				cmgCustStatCode || '|' ||
                                dispMode ||'|'||firstAcc||'||'||tmpConst);
			else
				if(wbgCust = 'Y') then
					carRec:= solId||'|'||ciftCustId||'|01|0|'||ltrim(rtrim(ciftEmailId))||'|'||
					ltrim(rtrim(cmgTitleName))||'|'||ltrim(rtrim(cmgAddr1))||'|'||
					ltrim(rtrim(cmgAddr2))||'|'||ltrim(rtrim(cityDesc))||'|'||
					ltrim(rtrim(stateDesc))||'|'||ltrim(rtrim(cntryDesc))||' - '||
					ltrim(rtrim(cmgPinCode))||'|'||cmgCustStatCode||'|'||'Y'||'|'||
					firstAcc||'||'||tmpConst;
					dbms_output.put_line(carRec);
				else
					carRec:= solId||'|'||ciftCustId||'|01|0|'||ltrim(rtrim(ciftEmailId))||'|'||
					ltrim(rtrim(cmgTitleName))||'|'||ltrim(rtrim(cmgAddr1))||'|'||
					ltrim(rtrim(cmgAddr2))|| '|' ||ltrim(rtrim(cityDesc))||'|'||
					ltrim(rtrim(stateDesc))||'|'||ltrim(rtrim(cntryDesc))||' - '||
					ltrim(rtrim(cmgPinCode))||'|'||cmgCustStatCode||'|'||'Y'||'|'||
					ltrim(rtrim(cmgPhone1))||' - '||ltrim(rtrim(cmgPhone2)) || '||'||tmpConst;

					if(length(carRec) > 255) then
						carRec :=  solId||'|'||ciftCustId||'|01|0|'||'|'||
						ltrim(rtrim(cmgTitleName))||'|'||ltrim(rtrim(cmgAddr1))||'|'||
						ltrim(rtrim(cmgAddr2))|| '|' ||ltrim(rtrim(cityDesc))||'|'||
						ltrim(rtrim(stateDesc))||'|'||ltrim(rtrim(cntryDesc))||' - '||
						ltrim(rtrim(cmgPinCode))||'|'||cmgCustStatCode||'|'||'Y'||'|'||
						ltrim(rtrim(cmgPhone1))||' - '||ltrim(rtrim(cmgPhone2)) || '||'||tmpConst;

						if(length(carRec) > 255) then
							carRec :=  solId||'|'||ciftCustId||'|01|0|'||'|'||
							ltrim(rtrim(cmgTitleName))||'|'||ltrim(rtrim(cmgAddr1))||'|'||
							ltrim(rtrim(cmgAddr2))|| '|' ||ltrim(rtrim(cityDesc))||'|'||
							ltrim(rtrim(stateDesc))||'|'||ltrim(rtrim(cntryDesc))||' - '||
							ltrim(rtrim(cmgPinCode))||'|'||cmgCustStatCode||'|'||'Y'||'|'||
							'||'||tmpConst;
							dbms_output.put_line(carRec);
						else
							dbms_output.put_line(carRec);
						end if;
					else
						dbms_output.put_line(carRec);
					end if;
			 	end if; -- (if WBGCust = Y)
			end if; -- (If dispMode = E)
	end if; -- (If cnt > 0)
	EXCEPTION
	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('<#ORA-ERROR#>');
		DBMS_OUTPUT.PUT_LINE('Cust Id/Account Id list creation failed at step...'||step);
		DBMS_OUTPUT.PUT_LINE('Cust Id '||custId);
		DBMS_OUTPUT.PUT_LINE('Check SQL error,  and try again');
		DBMS_OUTPUT.PUT_LINE('Sql Error Code is        : ' || SQLCODE );
		DBMS_OUTPUT.PUT_LINE('SQL Error Description is : '|| SQLERRM);
		ROLLBACK;
		DBMS_OUTPUT.PUT_LINE('Currenct Chunk rolled back.');
END;
/
spool off
