set serveroutput on size 1000000
set feedback off
set verify off
set head off
set colsep |
set pages 0
set linesize 500
set trims on
set termout off
set echo off

spool mail_for_dp.lst


DECLARE
gam_solid		gam.sol_id%type;
acctnum			gam.foracid%type;
lim_sanct_date		lht.lim_sanct_date%type;
lim_exp_date		lht.lim_exp_date%type;
limit_b2kid		gam.limit_b2kid%type;
acct_name		gam.acct_name%type;
sanct_lim		lht.sanct_lim%type;
vstr_CUST_COMU_ADDR1		varchar2(100);
vstr_CUST_COMU_ADDR2		varchar2(100);
vstr_CUST_COMU_PIN_CODE		varchar2(100);
vstr_CUST_COMU_PHONE_NUM_1	varchar2(100);
vstr_CUST_COMU_PHONE_NUM_2	varchar2(100);
vstr_CUST_COMU_TELEX_NUM	varchar2(100);
vstr_CUST_COMU_STATE_CODE	varchar2(100);
vstr_CUST_COMU_CNTRY_CODE	varchar2(100);
vstr_sol_CITY_CODE		varchar2(100);
vstr_CUST_COMU_CITY_CODE	varchar2(100);
vstr_CUST_COMU_CITY		varchar2(100);
vstr_CUST_COMU_STATE		varchar2(100);
vstr_CUST_COMU_CNTRY		varchar2(100);
vstr_sysdate			varchar2(100);

CURSOR dp_modify IS
select	g.foracid,
	g.acct_name,
	g.cust_id,
	l.sanct_lim,
	l.LIM_EXP_DATE,
	s.sol_desc,
	s.CITY_CODE
from dht d,lht l,gam g,sol s
where d.serial_num like '%00002'
and trunc(d.rcre_time)= (
	select db_stat_date-1
	from gct)
and g.acid = d.acid
and g.acid = l.acid
and g.schm_code = 'SBLOD'
and s.sol_id = g.sol_id
and l.serial_num = (select max(serial_num) from lht where acid = l.acid and status = 'A' and entity_cre_flg = 'Y')
;

BEGIN
	FOR A in dp_modify
	LOOP
	begin
		select	c.CUST_COMU_ADDR1,
			c.CUST_COMU_ADDR2,
			c.CUST_COMU_PIN_CODE,
			c.CUST_COMU_PHONE_NUM_1,
			c.CUST_COMU_STATE_CODE,
			c.CUST_COMU_CNTRY_CODE,
			c.CUST_COMU_CITY_CODE,
			c.CUST_COMU_PHONE_NUM_2,
			c.CUST_COMU_TELEX_NUM
		into
			vstr_CUST_COMU_ADDR1,
			vstr_CUST_COMU_ADDR2,
			vstr_CUST_COMU_PIN_CODE,
			vstr_CUST_COMU_PHONE_NUM_1,
			vstr_CUST_COMU_STATE_CODE,
			vstr_CUST_COMU_CNTRY_CODE,
			vstr_CUST_COMU_CITY_CODE,
			vstr_CUST_COMU_PHONE_NUM_2,
			vstr_CUST_COMU_TELEX_NUM
		from	cmg c
		where	c.cust_id = A.cust_id;

		EXCEPTION
		when no_data_found then
		    vstr_CUST_COMU_ADDR1:=null;
			vstr_CUST_COMU_ADDR2:=null;
			vstr_CUST_COMU_PIN_CODE:=null;
			vstr_CUST_COMU_PHONE_NUM_1:=null;
			vstr_CUST_COMU_STATE_CODE:=null;
			vstr_CUST_COMU_CNTRY_CODE:=null;
			vstr_CUST_COMU_CITY_CODE:=null;
			vstr_CUST_COMU_PHONE_NUM_2:=null;
			vstr_CUST_COMU_TELEX_NUM:=null;

		end;

		BEGIN
		--{
			SELECT REF_DESC 
			INTO vstr_CUST_COMU_CITY
			FROM RCT
			WHERE REF_CODE = vstr_CUST_COMU_CITY_CODE
			AND ref_rec_type = '01';

			EXCEPTION
			WHEN NO_DATA_FOUND THEN
			vstr_CUST_COMU_CITY := '';
		--}	
		END;
		BEGIN
		--{
			SELECT REF_DESC 
			INTO vstr_sol_CITY_CODE
			FROM RCT
			WHERE REF_CODE = A.CITY_CODE
			AND ref_rec_type = '01';

			EXCEPTION
			WHEN NO_DATA_FOUND THEN
			vstr_CUST_COMU_CITY := '';
		--}	
		END;

		BEGIN
		--{
			SELECT REF_DESC 
			INTO vstr_CUST_COMU_STATE
			FROM RCT
			WHERE REF_CODE = vstr_CUST_COMU_STATE_CODE
			AND ref_rec_type = '02';

			EXCEPTION
			WHEN NO_DATA_FOUND THEN
			vstr_CUST_COMU_STATE := '';
		--}	
		END;

		BEGIN
		--{
			SELECT to_char(sysdate,'dd Month yyyy') 
			INTO vstr_sysdate
			FROM dual;
			
			EXCEPTION
			WHEN NO_DATA_FOUND THEN
			vstr_sysdate := '';
		--}
		END;

		BEGIN
		--{
			SELECT REF_DESC 
			INTO vstr_CUST_COMU_CNTRY
			FROM RCT
			WHERE REF_CODE = vstr_CUST_COMU_CNTRY_CODE
			AND ref_rec_type = '03';

			EXCEPTION
			WHEN NO_DATA_FOUND THEN
			vstr_CUST_COMU_CNTRY := '';
		--}	
		END;

		
	dbms_output.put_line(vstr_sysdate||'|'||A.foracid||'|'||A.acct_name||'|'||vstr_CUST_COMU_ADDR1||'|'||vstr_CUST_COMU_ADDR2||'|'||vstr_CUST_COMU_CITY||'|'||vstr_CUST_COMU_PIN_CODE||'|'||vstr_CUST_COMU_PHONE_NUM_1||'|'||A.sanct_lim||'|'||A.LIM_EXP_DATE||'|'||A.sol_desc||'|'||vstr_CUST_COMU_STATE||'|'||vstr_CUST_COMU_CNTRY||'|'||vstr_CUST_COMU_PHONE_NUM_2||'|'||vstr_CUST_COMU_TELEX_NUM||'|'||vstr_sol_CITY_CODE);

	END LOOP;
END;
/
SPOOL OFF


