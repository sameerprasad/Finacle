Rem     This file will create LOCKER_KEY_MAINTENENCE_HISTORY Table
Rem     with the following characteristics.

Rem     Coded by : Saravanan (BBSSL)

Rem     Module  : LOCKER


Rem TABLE NAME: LOCKER_KEY_MAINTENENCE_HISTORY

Rem SYNONYM:    WLCKMH


drop table icici.LOCKER_KEY_MAINTENENCE_HISTORY
/
drop public synonym WLCKMH
/
create table icici.LOCKER_KEY_MAINTENENCE_HISTORY
(
SOL_ID		VARCHAR2(8),
LOCKER_TYPE	VARCHAR2(5),
SIZE_OF_LOCKER	VARCHAR2(11),
RACK_ID		VARCHAR2(3),
LOCKER_NUM	VARCHAR2(12),
KEY_NUM		VARCHAR2(10),
STATUS		CHAR(1),
REMARKS		VARCHAR2(40),
DEL_FLG		CHAR(1),
ENTITY_CRE_FLG  CHAR(1),
LCHG_USER_ID    VARCHAR2(15),
LCHG_TIME       DATE,
RCRE_USER_ID    VARCHAR2(15),
RCRE_TIME       DATE,
SURRENDER_DATE	DATE
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
create public synonym WLCKMH for icici.LOCKER_KEY_MAINTENENCE_HISTORY
/
grant select, insert, update, delete on WLCKMH to tbagen
/
grant select on WLCKMH to tbacust
/
grant select on WLCKMH to tbautil
/
grant all on WLCKMH to tbaadm
/
create index idx_wlckmh_main on WLCKMH(SOL_ID,LOCKER_NUM,KEY_NUM,STATUS)
/
create index idx_wlckmh_key_main on WLCKMH(SOL_ID,KEY_NUM)
/
create index idx_wlckmh_lock_main on WLCKMH(SOL_ID,LOCKER_NUM)
/
