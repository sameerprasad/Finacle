rem Author : Rahul Nimkar
rem SQL script to generate list of mandates for specified Account Number and User Institution

rem accept acct_no prompt "Enter the account number : "
rem accept ui_code prompt "Enter the User Institution Number : "

set verify off
set feedback off
set trims on
set pages 60
set linesize 200

col mandate_srl_num heading 'Mandate No.' format A12
col foracid heading 'Account No.' format A16
col membership_id heading 'User Inst. No.' format A14
col reference_id heading 'Description' format A60
col suspend_mandate_from heading 'Suspend From' format A12
col suspend_mandate_to heading 'Suspend To' format A12
col START_DATE heading 'Start Date ' format A12
col END_DATE heading 'End Date ' format A12
col Amount heading 'Amount ' format A12
col Del_flg heading 'Deleted ' format A7

spool mandates_list.lst
SELECT mandate_srl_num,
        gam.foracid,
        membership_id,
        reference_id_1||'|'||reference_id_2 reference_id,
        suspend_mandate_from,
        suspend_mandate_to,
        START_DATE,
        END_DATE,
        MANDATE_AMOUNT_TYPE||'|'||AMOUNT Amount,
	EMD.del_flg del_flg
FROM EMD, GAM
WHERE GAM.foracid = '&1'
AND EMD.b2k_type = 'ACCNT'
AND GAM.acid = EMD.b2k_id
ORDER BY mandate_srl_num
/
spool off
set verify on feedback on
exit
