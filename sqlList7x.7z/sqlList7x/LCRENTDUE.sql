--##############################################################################################
--#                     File Name       : LCRENTDUE.sql
--#                     Author : Mariappan.V (BBSSL)
--#                     Report : LOCKER DUE RENT REPORT
--#                     Date   :
--#                     Module  : LOCKER
--#                     Called Menu     : LOCKRPT
--#                     Called By       : LCRENTDUE.com
--##############################################################################################



CREATE OR REPLACE PACKAGE LCRENTDUE AS
        PROCEDURE LCRENTDUE(inp_str IN VARCHAR2,
                out_retCode OUT NUMBER,
                out_rec OUT VARCHAR2);
END LCRENTDUE;
/
CREATE OR REPLACE PACKAGE BODY LCRENTDUE AS
--{
	v_sol_id        wlckm.sol_id%type;
	v_date		date;
	v_locker_type	wlckm.locker_type%type;
	v_locker_num	wlckm.LOCKER_NUM%type;
	v_cust_name	cmg.CUST_NAME%type;
	v_oper_accnt	clmt.OPER_ACNT%type;
	v_hire_date	clmt.ISSUE_DATE%type;
	v_due_date	clmt.DUE_DATE%type;
	v_year		number;
	v_mon		number;
	v_days		number;
	v_loc_code	clrm.LOCATION_CODE%type;
	v_rent_amt1	clrm.RENT_AMT%type;
	v_rent_amt	clrm.RENT_AMT%type;

	CURSOR CUR IS
		SELECT 	A.locker_type,
        		A.LOCKER_NUM,
        		B.CUST_NAME,
        		A.OPER_ACNT,
        		NVL(A.RENEWAL_DATE,A.ISSUE_DATE),
        		A.DUE_DATE,
        		TRUNC(MONTHS_BETWEEN(v_date,TO_DATE(DUE_DATE))/12),
			trunc((MONTHS_BETWEEN(v_date,TO_DATE(DUE_DATE))/12 - TRUNC(MONTHS_BETWEEN(v_date,TO_DATE(DUE_DATE))/12))*12),
			TRUNC((((MONTHS_BETWEEN(v_date,TO_DATE(DUE_DATE))/12 - TRUNC(MONTHS_BETWEEN(v_date,TO_DATE(DUE_DATE))/12))*12) - trunc((MONTHS_BETWEEN(v_date,TO_DATE(DUE_DATE))/12 - TRUNC(MONTHS_BETWEEN(v_date,TO_DATE(DUE_DATE))/12))*12))*30) + 1
        		FROM clmt A,cmg B
        			WHERE A.CUST_ID = B.CUST_ID
        			AND A.sol_id = v_sol_id
        			AND A.due_date < to_date(v_date,'dd-mm-yyyy')
        			AND a.DEL_FLG <> 'Y'
        			ORDER BY A.locker_type,DUE_DATE DESC,A.locker_num;
        			


PROCEDURE LCRENTDUE(inp_str IN VARCHAR2,
        out_retCode OUT NUMBER,
        out_rec OUT VARCHAR2) IS

outArr                  basp0099.ArrayType;


BEGIN
        --{
        basp0099.formInputArr(inp_str,outArr);
        v_sol_id	:= outArr(0);
	v_date		:= outArr(1);
	out_retCode     :=  0;
        out_rec         := NULL;


------------------------------------------------------------
--Opening cursor
------------------------------------------------------------
        IF(NOT CUR%ISOPEN) THEN
        --{
		out_retCode:= 0;
		open CUR;
        --}
        END IF;


-------------------------------------------------------------
--Fetching Data
-------------------------------------------------------------
        IF (CUR%ISOPEN)   THEN
                FETCH CUR
               	into v_locker_type,v_locker_num,v_cust_name,v_oper_accnt,v_hire_date,v_due_date,v_year,v_mon,v_days;
                if (CUR%NOTFOUND) THEN
                --{
                    out_retcode := 1;
                    close CUR;
                --}
                end if;
                
        end if;


			
	BEGIN
		select	set_id
			into v_loc_code
			from sst
				where sol_id = v_sol_id
				and set_id like 'LOC%';
	END;


	BEGIN
		
		select a.rent_amt
			into v_rent_amt1	
			from clrm a
				WHERE a.sol_id= v_sol_id
				and a.location_code=v_loc_code
				and a.locker_type = v_locker_type 
				and a.Rent_period= '1'
				and a.Rent_Version_Code = (select max(b.Rent_Version_Code) 
								from clrm b
								where a.location_code = b.location_code 
								and a.locker_type = b.locker_type
								and a.sol_id = b.sol_id
								and a.Rent_period = b.Rent_period 
								and b.rent_effective_date <= v_due_date)
				and a.del_flg != 'Y'
				and a.entity_cre_flg != 'N';
		EXCEPTION WHEN NO_DATA_FOUND THEN
		BEGIN
				select a.rent_amt
				into v_rent_amt1	
				from clrm a
				WHERE a.sol_id= '0000'
				and a.location_code=v_loc_code
				and a.locker_type = v_locker_type 
				and a.Rent_period= '1'
				and a.Rent_Version_Code = (select max(b.Rent_Version_Code) 
								from clrm b
								where a.location_code = b.location_code 
								and a.locker_type = b.locker_type
								and a.sol_id = b.sol_id
								and a.Rent_period = b.Rent_period 
								and b.rent_effective_date <= v_due_date)
				and a.del_flg != 'Y'
				and a.entity_cre_flg != 'N';
				EXCEPTION WHEN NO_DATA_FOUND THEN
					v_rent_amt1 := '0';
		END;
			
	END;
        	
		if (v_year < 1) then
			v_rent_amt :=  v_rent_amt1;
		elsif (v_year >= 1) and (v_year <2) then
			v_rent_amt := v_rent_amt1 * 2;
		else
			v_rent_amt := v_rent_amt1 * 3;
		end if;
        	
		
		
	out_rec	:=	v_locker_type	||'|'||
			v_locker_num	||'|'||
			v_cust_name	||'|'||
			v_oper_accnt	||'|'||
			v_hire_date	||'|'||
			v_due_date	||'|'||
			v_year		||'|'||
			v_mon		||'|'||
			v_days		||'|'||
			v_rent_amt	||'|'||
			v_sol_id	||'|'||
			v_date;
	
					
--} 
END LCRENTDUE; 
--} 
END LCRENTDUE;
/
DROP  PUBLIC SYNONYM LCRENTDUE
/
CREATE PUBLIC SYNONYM LCRENTDUE FOR LCRENTDUE
/
GRANT EXECUTE ON LCRENTDUE to  tbagen, tbautil, tbacust,tbaadm
/
