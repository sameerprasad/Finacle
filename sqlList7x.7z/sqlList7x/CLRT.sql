REM####################################################################
REM File Name   : CLRT.sql
REM Description : Table creation for custom locker Reversal Transaction table
REM Author      : Prabhu.B (BBSSL)
REM Date        : 11-05-2010
Rem     Module  : LOCKER
REM####################################################################
drop table icici.cust_locker_reversal_tran
/
drop public synonym CLRT
/
create table icici.cust_locker_reversal_tran
(
	sol_id 		varchar(8),
	cust_id		varchar(9),
	locker_num	varchar(12),
	org_tran_id	VARCHAR2(9),
	org_tran_date   DATE,
	rev_tran_id     VARCHAR2(9),
	rev_tran_date   DATE,
	entity_cre_flg  char(1),
	LCHG_USER_ID    VARCHAR2(15),
	LCHG_TIME       date,
	RCRE_USER_ID    VARCHAR2(15),
	RCRE_TIME       date,
	del_flg         char(1)
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
CREATE INDEX IDX_cust_locker_reversal_tran ON ICICI.cust_locker_reversal_tran(SOL_ID,locker_num,cust_id)
/
CREATE INDEX IDX_cust_locker_rev_tranid ON ICICI.cust_locker_reversal_tran(locker_num,org_tran_id,org_tran_date)
/
CREATE unique INDEX UIDX_cust_locker_reversal_tran ON ICICI.cust_locker_reversal_tran(SOL_ID,locker_num,cust_id,org_tran_id,org_tran_date)
/
create public synonym CLRT for icici.cust_locker_reversal_tran
/
grant select,insert,update,delete on CLRT to tbagen
/
grant select on CLRT to tbacust
/
grant all on CLRT to tbaadm
/
grant select on CLRT to tbautil
/
