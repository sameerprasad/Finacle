rem this sql is written to create a temporary table out of cdtt daily table before 
rem truncating the same

spool createcdt

drop table temp_cdtt_daily
/

create table temp_cdtt_daily
as (select * from icici_cdtt_daily)
/

truncate table icici_cdtt_daily
/

spool off


