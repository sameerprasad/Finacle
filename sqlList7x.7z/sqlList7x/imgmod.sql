rem accept solid prompt "ENTER SOL ID ::"
rem THIS QUERY GENERATES A REPORT OF ALL TEXT MODIFICATIONS DONE TO A SIGNATURE 
rem RECORD DURING THE DAY, THRU OPTION ' IMGMNT '. NEW RECORDS ADDED DURING THE 
rem DAY ARE NOT CONSIDERED.
rem Author : V.V.Sundar 	Date : 21-May-1996
rem Verified By :G.S.Saini 	Date : 21-May-1996 
set heading on
set termout off
set verify off
set linesi 132
set pagesi 60
break on report skip 3 on a
col a heading ACC_NUM 
col MODIFIED_TEXT format  a80 word_wrapped
col e heading 'MODIFIED_BY' format a10
col f heading 'ON_DATE' format date
col today new_value today_date
col branch new_value br
select to_char(sysdate,'DD-MON-YYYY') today from dual;
select br_name branch from bct where br_code =(select br_code from sol 
where sol_id='&1');
ttitle center 'LIST OF ACCOUNTS WHERE IMAGE TEXT IS MODIFIED AS ON ' today_date skip 2-
center 'Branch : ' br skip 1-
left ' Date  : ' today_date skip 4 
spool imgmod.&1
select foracid a, 
text_line_1||text_line_2||
text_line_3 MODIFIED_TEXT ,imt.lchg_user_id MOD_BY 
from imt ,gam
where imt.sol_id='&1'
and imt.sol_id = gam.sol_id 
and imt.acid = gam.acid
and to_char(imt.lchg_time,'DD-MON-YYYY')  = (select to_char(sysdate,'DD-MON-YYYY') today from dual)
and imt.tot_mod_times >0
/
spool off
exit
