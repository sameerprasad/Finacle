rem this sql has been given for changes in 1.6.36.18  version
rem this will take care of forex sql update required for the 
rem new version
rem this contains several parts and each part is explained separately
rem GMM part this will update all guarantees marked as expired by b2k
rem after migration as abh.com was not hashed out for this process
rem branches are asking for updation regularly
rem this will ensure that the all BGs with claim expiry > today
rem will be updated as A or E
rem this is for updating GPLG display of dates in DD-MM-YYYY (y2k)
rem format for BEF letter GEneration
rem updcsproundoff part - this sql has been given to update csp
rem to update the interest round off parameter
rem and interest round off amount
rem parameter set to nearest and amt set to
rem (for other than JPY and INR ) 0.01
rem for JPY = 1.00
rem Update DCMM 
rem this will set the outside country charges in Dcs
rem opened in 1.5.94.02 version as this is a new and mandatory
rem field and cursor does not go there.
rem we are adding another let file for GPLG in 'LCPAY'
rem this will give the reminders to LC opening bank for payamnet
rem we are adding yet another let and sql files for GPLG in 'BGEXP'
rem this will send expiry notice to beneficiaries for expired BG

spool fxupd163618.lst

update  bgm
set bg_status = 'A'
where bg_status = 'O'
and claim_expiry_date > sysdate
and num_of_amends  = 0
/
commit
/
update  bgm
set bg_status = 'E'
where bg_status = 'O'
and claim_expiry_date > sysdate
and num_of_amends >= 1
/ 
commit
/
update let
set sql_parameter_format = 'FROM (DD-MM-YYYY) TO (BOD) (DD-MM-YYYY)'
where letter_id in ('ABDUE','BIDUE')
/
commit
/
select schm_code,crncy_code,cr_int_amt_rnd_stat,cr_int_amt_rnd_amt,dr_int_amt_rnd_stat,dr_int_amt_rnd_amt from csp
where crncy_code not in ('INR' , 'JPY')
and del_flg != 'Y'
/
select schm_code,crncy_code,cr_int_amt_rnd_stat,cr_int_amt_rnd_amt,dr_int_amt_rnd_stat,dr_int_amt_rnd_amt from csp
where crncy_code = 'JPY'
and del_flg != 'Y'
/
update csp
set cr_int_amt_rnd_stat = 'N',cr_int_amt_rnd_amt = 0.01,
    dr_int_amt_rnd_stat = 'N',dr_int_amt_rnd_amt = 0.01
where crncy_code not in ('INR' , 'JPY')
and del_flg != 'Y'
/
commit
/
update csp
set cr_int_amt_rnd_stat = 'N',cr_int_amt_rnd_amt = 1.00,
    dr_int_amt_rnd_stat = 'N',dr_int_amt_rnd_amt = 1.00
where crncy_code = 'JPY' 
and del_flg != 'Y'
/
commit
/
select schm_code,crncy_code,cr_int_amt_rnd_stat,cr_int_amt_rnd_amt,dr_int_amt_rnd_stat,dr_int_amt_rnd_amt from csp
where crncy_code not in ('INR' , 'JPY')
and del_flg != 'Y'
/
select schm_code,crncy_code,cr_int_amt_rnd_stat,cr_int_amt_rnd_amt,dr_int_amt_rnd_stat,dr_int_amt_rnd_amt from csp
where crncy_code = 'JPY'
and del_flg != 'Y'
/
select schm_code,fx_tran_flg from gsp
where fx_tran_flg = 'Y'
/
update gsp
set fx_tran_flg = 'Y'
where schm_code in ('OABAS','OABLA','OAXDR','OCASH','FBP','PCUSD','HOFXP','HOFXS','HOMOD','OEFBP','OIFBP')
/
commit
/
select schm_code,fx_tran_flg from gsp
where fx_tran_flg = 'Y'
/
select dc_ref_num,outside_charg_ind from dcmm
where outside_charg_ind not in ('B','O')
and date_clsd is  NULL
/
update dcmm
set outside_charg_ind = 'O'
where outside_charg_ind not in ('O','B')
and date_clsd is  NULL
/
commit
/
select dc_ref_num,outside_charg_ind from dcmm
where outside_charg_ind not in ('B','O')
and date_clsd is  NULL
/
insert into let values ('LCPAY','N','LETTER TO LC OPENING BANK FOR PAYMENT','lcpaymt.let','lcpaymt.sql','(START DATE) DD-MM-YYYY  (END DATE) DD-MM-YYYY','UPDATE',sysdate, 'UPDATE',sysdate)
/
commit
/
insert into let values ('BGEXP','N','LETTER TO BENEFICIARY FOR BG EXPIRY','bgexp.let','bgexp.sql','(START DATE) DD-MM-YYYY  (END DATE) DD-MM-YYYY','UPDATE',sysdate, 'UPDATE',sysdate)
/
commit
/
spool off
exit
