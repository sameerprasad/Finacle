set verifed off
set verify off
set head off
set trims on
set pages 0
spool HGCPM

prompt 'Creation of Menu option LCRNT :'

select 'Adding the new menu option LCRNT...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCRNT';
end;
/

delete mod where mop_id = 'LCRNT';
set escape \
insert into mod values ('LCRNT','Y','N','U','http://$W/finbranch/','custom/LockRntMain01.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCRNT';
insert into oat values ('LCRNT', 'DB', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCRNT';
insert into mod_txt values ('LCRNT', 'INFENG', 'LCRNT', 'Locker Rent Maintenance', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCRNT';
begin
insert into mno values ('LCRNT', :mopNum, 'LCRNT', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCRNTV :'

select 'Adding the new menu option LCRNTV...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCRNTV';
end;
/

delete mod where mop_id = 'LCRNTV';

insert into mod values ('LCRNTV','Y','N','U','http://$W/finbranch/','custom/LockRntVer01.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCRNTV';
insert into oat values ('LCRNTV', 'DB', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCRNTV';
insert into mod_txt values ('LCRNTV', 'INFENG', 'LCRNTV', 'Locker Rent Maintenance-Verification', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCRNTV';
begin
insert into mno values ('LCRNTV', :mopNum, 'LCRNTV', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCRI :'

select 'Adding the new menu option LCRI...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCRI';
end;
/

delete mod where mop_id = 'LCRI';

insert into mod values ('LCRI','Y','N','U','http://$W/finbranch/','custom/LockRntInq01.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCRI';
insert into oat values ('LCRI', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCRI';
insert into mod_txt values ('LCRI', 'INFENG', 'LCRI', 'Locker Rent Inquiry', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCRI';
begin
insert into mno values ('LCRI', :mopNum, 'LCRI', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCPM :'

select 'Adding the new menu option LCPM...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCPM';
end;
/

delete mod where mop_id = 'LCPM';

insert into mod values ('LCPM','Y','N','U','http://$W/finbranch/','custom/lcpm.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCPM';
insert into oat values ('LCPM', 'DB', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCPM';
insert into mod_txt values ('LCPM', 'INFENG', 'LCPM', 'Locker Parameter Maintenance', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCPM';
begin
insert into mno values ('LCPM', :mopNum, 'LCPM', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCPMV :'

select 'Adding the new menu option LCPMV...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCPMV';
end;
/

delete mod where mop_id = 'LCPMV';

insert into mod values ('LCPMV','Y','N','U','http://$W/finbranch/','custom/lcpmv.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCPMV';
insert into oat values ('LCPMV', 'DB', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCPMV';
insert into mod_txt values ('LCPMV', 'INFENG', 'LCPMV', 'Locker Parameter Maint-Verification', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCPMV';
begin
insert into mno values ('LCPMV', :mopNum, 'LCPMV', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCPI :'

select 'Adding the new menu option LCPI...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCPI';
end;
/

delete mod where mop_id = 'LCPI';

insert into mod values ('LCPI','Y','N','U','http://$W/finbranch/','custom/lcpi.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCPI';
insert into oat values ('LCPI', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCPI';
insert into mod_txt values ('LCPI', 'INFENG', 'LCPI', 'Locker Parameter Inquiry', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCPI';
begin
insert into mno values ('LCPI', :mopNum, 'LCPI', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCRM :'

select 'Adding the new menu option LCRM...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCRM';
end;
/

delete mod where mop_id = 'LCRM';

insert into mod values ('LCRM','Y','N','U','http://$W/finbranch/','custom/lcrm.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCRM';
insert into oat values ('LCRM', 'DB', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCRM';
insert into mod_txt values ('LCRM', 'INFENG', 'LCRM', 'Locker Rack Id Maintenance', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCRM';
begin
insert into mno values ('LCRM', :mopNum, 'LCRM', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCRMV :'

select 'Adding the new menu option LCRMV...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCRMV';
end;
/

delete mod where mop_id = 'LCRMV';

insert into mod values ('LCRMV','Y','N','U','http://$W/finbranch/','custom/lcrmv.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCRMV';
insert into oat values ('LCRMV', 'DB', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCRMV';
insert into mod_txt values ('LCRMV', 'INFENG', 'LCRMV', 'Locker Rack Id Maintenance Verification', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCRMV';
begin
insert into mno values ('LCRMV', :mopNum, 'LCRMV', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCKMA :'

select 'Adding the new menu option LCKMA...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCKMA';
end;
/

delete mod where mop_id = 'LCKMA';

insert into mod values ('LCKMA','Y','N','U','http://$W/finbranch/','custom/lckma.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCKMA';
insert into oat values ('LCKMA', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCKMA';
insert into mod_txt values ('LCKMA', 'INFENG', 'LCKMA', 'Locker Key Maintenance-Add', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCKMA';
begin
insert into mno values ('LCKMA', :mopNum, 'LCKMA', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCKM :'

select 'Adding the new menu option LCKM...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCKM';
end;
/

delete mod where mop_id = 'LCKM';

insert into mod values ('LCKM','Y','N','U','http://$W/finbranch/','custom/lckm.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCKM';
insert into oat values ('LCKM', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCKM';
insert into mod_txt values ('LCKM', 'INFENG', 'LCKM', 'Locker Key Change Maintenance', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCKM';
begin
insert into mno values ('LCKM', :mopNum, 'LCKM', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCKMV :'

select 'Adding the new menu option LCKMV...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCKMV';
end;
/

delete mod where mop_id = 'LCKMV';

insert into mod values ('LCKMV','Y','N','U','http://$W/finbranch/','custom/lckmv.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCKMV';
insert into oat values ('LCKMV', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCKMV';
insert into mod_txt values ('LCKMV', 'INFENG', 'LCKMV', 'Locker Key Change Maint-Verification', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCKMV';
begin
insert into mno values ('LCKMV', :mopNum, 'LCKMV', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCLOST :'

select 'Adding the new menu option LCLOST...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCLOST';
end;
/

delete mod where mop_id = 'LCLOST';

insert into mod values ('LCLOST','Y','N','U','http://$W/finbranch/','custom/lclost.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCLOST';
insert into oat values ('LCLOST', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCLOST';
insert into mod_txt values ('LCLOST', 'INFENG', 'LCLOST', 'Locker Key Lost Maintenance', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCLOST';
begin
insert into mno values ('LCLOST', :mopNum, 'LCLOST', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCLOSTV :'

select 'Adding the new menu option LCLOSTV...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCLOSTV';
end;
/

delete mod where mop_id = 'LCLOSTV';

insert into mod values ('LCLOSTV','Y','N','U','http://$W/finbranch/','custom/lclostv.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCLOSTV';
insert into oat values ('LCLOSTV', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCLOSTV';
insert into mod_txt values ('LCLOSTV', 'INFENG', 'LCLOSTV', 'Locker Key Lost Maint-Verification', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCLOSTV';
begin
insert into mno values ('LCLOSTV', :mopNum, 'LCLOSTV', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCKS :'

select 'Adding the new menu option LCKS...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCKS';
end;
/

delete mod where mop_id = 'LCKS';

insert into mod values ('LCKS','Y','N','U','http://$W/finbranch/','custom/lcks.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCKS';
insert into oat values ('LCKS', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCKS';
insert into mod_txt values ('LCKS', 'INFENG', 'LCKS', 'Locker Key Number Swapping Maintenance', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCKS';
begin
insert into mno values ('LCKS', :mopNum, 'LCKS', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCKSV :'

select 'Adding the new menu option LCKSV...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCKSV';
end;
/

delete mod where mop_id = 'LCKSV';

insert into mod values ('LCKSV','Y','N','U','http://$W/finbranch/','custom/lcksv.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCKSV';
insert into oat values ('LCKSV', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCKSV';
insert into mod_txt values ('LCKSV', 'INFENG', 'LCKSV', 'Locker Key Swapping Maint-Verification', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCKSV';
begin
insert into mno values ('LCKSV', :mopNum, 'LCKSV', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCLCK :'

select 'Adding the new menu option LCLCK...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCLCK';
end;
/

delete mod where mop_id = 'LCLCK';

insert into mod values ('LCLCK','Y','N','U','http://$W/finbranch/','custom/lclck.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCLCK';
insert into oat values ('LCLCK', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCLCK';
insert into mod_txt values ('LCLCK', 'INFENG', 'LCLCK', 'Locker Lock Maintenance', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCLCK';
begin
insert into mno values ('LCLCK', :mopNum, 'LCLCK', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCLCKV :'

select 'Adding the new menu option LCLCKV...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCLCKV';
end;
/

delete mod where mop_id = 'LCLCKV';

insert into mod values ('LCLCKV','Y','N','U','http://$W/finbranch/','custom/lclckv.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCLCKV';
insert into oat values ('LCLCKV', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCLCKV';
insert into mod_txt values ('LCLCKV', 'INFENG', 'LCLCKV', 'Locker Lock Maintenance-Verification', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCLCKV';
begin
insert into mno values ('LCLCKV', :mopNum, 'LCLCKV', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCCM :'

select 'Adding the new menu option LCCM...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCCM';
end;
/

delete mod where mop_id = 'LCCM';

insert into mod values ('LCCM','Y','N','U','http://$W/finbranch/','custom/LockCustMain01.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCCM';
insert into oat values ('LCCM', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCCM';
insert into mod_txt values ('LCCM', 'INFENG', 'LCCM', 'Locker Customer Maintenance', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCCM';
begin
insert into mno values ('LCCM', :mopNum, 'LCCM', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCCMV :'

select 'Adding the new menu option LCCMV...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCCMV';
end;
/

delete mod where mop_id = 'LCCMV';

insert into mod values ('LCCMV','Y','N','U','http://$W/finbranch/','custom/LockCustMainV01.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCCMV';
insert into oat values ('LCCMV', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCCMV';
insert into mod_txt values ('LCCMV', 'INFENG', 'LCCMV', 'Locker Customer Maint-Verification', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCCMV';
begin
insert into mno values ('LCCMV', :mopNum, 'LCCMV', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCREN :'

select 'Adding the new menu option LCREN...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCREN';
end;
/

delete mod where mop_id = 'LCREN';

insert into mod values ('LCREN','Y','N','U','http://$W/finbranch/','custom/LockRenMain01.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCREN';
insert into oat values ('LCREN', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCREN';
insert into mod_txt values ('LCREN', 'INFENG', 'LCREN', 'Locker Renewal Maintenance', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCREN';
begin
insert into mno values ('LCREN', :mopNum, 'LCREN', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCBRKOP :'

select 'Adding the new menu option LCBRKOP...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCBRKOP';
end;
/

delete mod where mop_id = 'LCBRKOP';

insert into mod values ('LCBRKOP','Y','N','U','http://$W/finbranch/','custom/LockBrkopMain01.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCBRKOP';
insert into oat values ('LCBRKOP', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCBRKOP';
insert into mod_txt values ('LCBRKOP', 'INFENG', 'LCBRKOP', 'Locker Break Open Maintenance', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCBRKOP';
begin
insert into mno values ('LCBRKOP', :mopNum, 'LCBRKOP', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCBRKOPV :'

select 'Adding the new menu option LCBRKOPV...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCBRKOPV';
end;
/

delete mod where mop_id = 'LCBRKOPV';

insert into mod values ('LCBRKOPV','Y','N','U','http://$W/finbranch/','custom/LockBrkopvMain01.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCBRKOPV';
insert into oat values ('LCBRKOPV', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCBRKOPV';
insert into mod_txt values ('LCBRKOPV', 'INFENG', 'LCBRKOPV', 'Locker Break Open Maint-Verification', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCBRKOPV';
begin
insert into mno values ('LCBRKOPV', :mopNum, 'LCBRKOPV', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCSM :'

select 'Adding the new menu option LCSM...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCSM';
end;
/

delete mod where mop_id = 'LCSM';

insert into mod values ('LCSM','Y','N','U','http://$W/finbranch/','custom/LockSurMain01.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCSM';
insert into oat values ('LCSM', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCSM';
insert into mod_txt values ('LCSM', 'INFENG', 'LCSM', 'Locker Surrender Maintenance', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCSM';
begin
insert into mno values ('LCSM', :mopNum, 'LCSM', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCSMV :'

select 'Adding the new menu option LCSMV...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCSMV';
end;
/

delete mod where mop_id = 'LCSMV';

insert into mod values ('LCSMV','Y','N','U','http://$W/finbranch/','custom/LockSurMain01v.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCSMV';
insert into oat values ('LCSMV', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCSMV';
insert into mod_txt values ('LCSMV', 'INFENG', 'LCSMV', 'Locker Surrender Maint-Verification', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCSMV';
begin
insert into mno values ('LCSMV', :mopNum, 'LCSMV', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCOPS :'

select 'Adding the new menu option LCOPS...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCOPS';
end;
/

delete mod where mop_id = 'LCOPS';

insert into mod values ('LCOPS','Y','N','U','http://$W/finbranch/','custom/LockOperMain01.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCOPS';
insert into oat values ('LCOPS', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCOPS';
insert into mod_txt values ('LCOPS', 'INFENG', 'LCOPS', 'Locker Operation Maintenance', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCOPS';
begin
insert into mno values ('LCOPS', :mopNum, 'LCOPS', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCINQ :'

select 'Adding the new menu option LCINQ...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCINQ';
end;
/

delete mod where mop_id = 'LCINQ';

insert into mod values ('LCINQ','Y','N','U','http://$W/finbranch/','custom/lcinq.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCINQ';
insert into oat values ('LCINQ', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCINQ';
insert into mod_txt values ('LCINQ', 'INFENG', 'LCINQ', 'Locker Inquiry', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCINQ';
begin
insert into mno values ('LCINQ', :mopNum, 'LCINQ', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCPAY :'

select 'Adding the new menu option LCPAY...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCPAY';
end;
/

delete mod where mop_id = 'LCPAY';

insert into mod values ('LCPAY','Y','N','U','http://$W/finbranch/','custom/lcpay.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCPAY';
insert into oat values ('LCPAY', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCPAY';
insert into mod_txt values ('LCPAY', 'INFENG', 'LCPAY', 'Locker Payments', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCPAY';
begin
insert into mno values ('LCPAY', :mopNum, 'LCPAY', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCWAIT :'

select 'Adding the new menu option LCWAIT...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCWAIT';
end;
/

delete mod where mop_id = 'LCWAIT';

insert into mod values ('LCWAIT','Y','N','U','http://$W/finbranch/','custom/lcwait.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCWAIT';
insert into oat values ('LCWAIT', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCWAIT';
insert into mod_txt values ('LCWAIT', 'INFENG', 'LCWAIT', 'Locker WaitList', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCWAIT';
begin
insert into mno values ('LCWAIT', :mopNum, 'LCWAIT', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCCLM :'

select 'Adding the new menu option LCCLM...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCCLM';
end;
/

delete mod where mop_id = 'LCCLM';

insert into mod values ('LCCLM','Y','N','U','http://$W/finbranch/','custom/lcclm.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCCLM';
insert into oat values ('LCCLM', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCCLM';
insert into mod_txt values ('LCCLM', 'INFENG', 'LCCLM', 'Locker Claim Advice', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCCLM';
begin
insert into mno values ('LCCLM', :mopNum, 'LCCLM', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCCLMV :'

select 'Adding the new menu option LCCLMV...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCCLMV';
end;
/

delete mod where mop_id = 'LCCLMV';

insert into mod values ('LCCLMV','Y','N','U','http://$W/finbranch/','custom/lcclmv.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCCLMV';
insert into oat values ('LCCLMV', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCCLMV';
insert into mod_txt values ('LCCLMV', 'INFENG', 'LCCLMV', 'Locker Claim Advice-Verification', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCCLMV';
begin
insert into mno values ('LCCLMV', :mopNum, 'LCCLMV', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCPWD :'

select 'Adding the new menu option LCPWD...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCPWD';
end;
/

delete mod where mop_id = 'LCPWD';

insert into mod values ('LCPWD','Y','N','U','http://$W/finbranch/','custom/lcpwd.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCPWD';
insert into oat values ('LCPWD', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCPWD';
insert into mod_txt values ('LCPWD', 'INFENG', 'LCPWD', 'Locker Password Maintenance', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCPWD';
begin
insert into mno values ('LCPWD', :mopNum, 'LCPWD', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCWAIVE :'

select 'Adding the new menu option LCWAIVE...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCWAIVE';
end;
/

delete mod where mop_id = 'LCWAIVE';

insert into mod values ('LCWAIVE','Y','N','U','http://$W/finbranch/','custom/LockWaiveMain.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCWAIVE';
insert into oat values ('LCWAIVE', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCWAIVE';
insert into mod_txt values ('LCWAIVE', 'INFENG', 'LCWAIVE', 'Locker Waive Maintenance', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCWAIVE';
begin
insert into mno values ('LCWAIVE', :mopNum, 'LCWAIVE', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCWAIVEV :'

select 'Adding the new menu option LCWAIVEV...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCWAIVEV';
end;
/

delete mod where mop_id = 'LCWAIVEV';

insert into mod values ('LCWAIVEV','Y','N','U','http://$W/finbranch/','custom/LockWaiveMainV.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCWAIVEV';
insert into oat values ('LCWAIVEV', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCWAIVEV';
insert into mod_txt values ('LCWAIVEV', 'INFENG', 'LCWAIVEV', 'Locker Waive Maintenance-Verification', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCWAIVEV';
begin
insert into mno values ('LCWAIVEV', :mopNum, 'LCWAIVEV', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCLAH :'

select 'Adding the new menu option LCLAH...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCLAH';
end;
/

delete mod where mop_id = 'LCLAH';

insert into mod values ('LCLAH','Y','N','U','http://$W/finbranch/','custom/lclah.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCLAH';
insert into oat values ('LCLAH', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCLAH';
insert into mod_txt values ('LCLAH', 'INFENG', 'LCLAH', 'Locker Letter Of Auth/Pow Of Attorney', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCLAH';
begin
insert into mno values ('LCLAH', :mopNum, 'LCLAH', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCLAHV :'

select 'Adding the new menu option LCLAHV...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCLAHV';
end;
/

delete mod where mop_id = 'LCLAHV';

insert into mod values ('LCLAHV','Y','N','U','http://$W/finbranch/','custom/lclahv.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCLAHV';
insert into oat values ('LCLAHV', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCLAHV';
insert into mod_txt values ('LCLAHV', 'INFENG', 'LCLAHV', 'Locker Let Of Auth/Pow Of Attrney-Verifn', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCLAHV';
begin
insert into mno values ('LCLAHV', :mopNum, 'LCLAHV', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCEXCDM :'

select 'Adding the new menu option LCEXCDM...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCEXCDM';
end;
/

delete mod where mop_id = 'LCEXCDM';

insert into mod values ('LCEXCDM','Y','N','U','http://$W/finbranch/','custom/LockerEXCDM.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCEXCDM';
insert into oat values ('LCEXCDM', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCEXCDM';
insert into mod_txt values ('LCEXCDM', 'INFENG', 'LCEXCDM', 'Locker Exception Maintenance', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCEXCDM';
begin
insert into mno values ('LCEXCDM', :mopNum, 'LCEXCDM', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCRRM :'

select 'Adding the new menu option LCRRM...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCRRM';
end;
/

delete mod where mop_id = 'LCRRM';

insert into mod values ('LCRRM','Y','N','U','http://$W/finbranch/','custom/lcrrm.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCRRM';
insert into oat values ('LCRRM', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCRRM';
insert into mod_txt values ('LCRRM', 'INFENG', 'LCRRM', 'Locker Rent Remainder Maintenance', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCRRM';
begin
insert into mno values ('LCRRM', :mopNum, 'LCRRM', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCCTM :'

select 'Adding the new menu option LCCTM...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCCTM';
end;
/

delete mod where mop_id = 'LCCTM';

insert into mod values ('LCCTM','Y','N','U','http://$W/finbranch/','custom/LockCustTypeMain.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCCTM';
insert into oat values ('LCCTM', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCCTM';
insert into mod_txt values ('LCCTM', 'INFENG', 'LCCTM', 'Locker Customer Type Maintenance', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCCTM';
begin
insert into mno values ('LCCTM', :mopNum, 'LCCTM', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option LCKVAL :'

select 'Adding the new menu option LCKVAL...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCKVAL';
end;
/

delete mod where mop_id = 'LCKVAL';

insert into mod values ('LCKVAL','Y','N','U','http://$W/finbranch/','custom/LockVal.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'LCKVAL';
insert into oat values ('LCKVAL', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'LCKVAL';
insert into mod_txt values ('LCKVAL', 'INFENG', 'LCKVAL', 'Locker Validation Run', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'LCKVAL';
begin
insert into mno values ('LCKVAL', :mopNum, 'LCKVAL', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/

prompt 'Creation of Menu option CLCI :'

select 'Adding the new menu option CLCI...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'CLCI';
end;
/

delete mod where mop_id = 'CLCI';

insert into mod values ('CLCI','Y','N','U','http://$W/finbranch/','custom/CLCI.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','025','','','999','','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'CLCI';
insert into oat values ('CLCI', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);

delete mod_txt where mop_id = 'CLCI';
insert into mod_txt values ('CLCI', 'INFENG', 'CLCI', 'Change Locker Customer Id', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

delete mno where mop_id = 'CLCI';
begin
insert into mno values ('CLCI', :mopNum, 'CLCI', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
end;
/
commit
/
