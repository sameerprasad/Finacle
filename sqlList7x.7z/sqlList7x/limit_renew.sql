set echo off 
set pause off
set pagesize 66

rem Script For Determining accounts due for renewal within 15 days.
rem   Input parameters in command line -
rem		None
rem   Tables accessed -
rem       GAM, CAM, SOL.
rem	This script can be run at any time. It will give a list of all
rem	accounts every time it is run.

set verify off
set wrap on
set feedback off
set linesize 80
set newpage 0
set space 1
set termout off

column today new_value today_date
select to_char(db_stat_date, 'dd-mm-yyyy') today
from   gct; 

define all_dashes = '-------------------------------------------------------------------------------'
ttitle center 'List of Accounts due for renewal within 15 days as on ' -
right today_date skip 0 -
left all_dashes
btitle left all_dashes

set numformat 999999999999.99

column schm_code format a6 heading 'Scheme'
column b.foracid heading 'A/c Number' format a11
column acct_name format a40 heading 'Account Name'
column max_alwd_advn_lim heading 'Limit Allowed' format 9,99,99,99,99,999.99
column clear_bal heading 'Clear Balance' format 9,99,99,99,99,999.99
column unclear_bal heading 'Shadow Balance' format 9,99,99,99,99,999.99
column baltype format a2 heading '  '
column lim_exp_date format a9 heading 'Expiry Dt'

whenever sqlerror exit sql.sqlcode 
break on schm_code skip 1 on cust_id skip 1
compute sum of max_alwd_advn_lim on cust_id
compute sum of clr_bal_amt on cust_id
compute sum of un_clr_bal_amt on cust_id

spool limit_renew

select	b.schm_code, b.cust_id, b.foracid, b.acct_name,
	a.max_alwd_advn_lim,
	abs(clr_bal_amt) clear_bal,
	decode(clr_bal_amt, abs(clr_bal_amt), 'Cr', 'Dr') baltype,
	abs(un_clr_bal_amt) unclear_bal,
	decode(un_clr_bal_amt, abs(un_clr_bal_amt), 'Cr', 'Dr') baltype,
	d.lim_exp_date
from cam a, gam b, sol c,gct, llt d
where b.sol_id = c.sol_id
and a.acid = b.acid
and d.limit_b2kid=b.acid
and months_between ( gct.db_stat_date, d.lim_exp_date ) <= 0.5
and b.acct_cls_flg != 'Y'
and b.del_flg != 'Y'
order by b.schm_code, b.cust_id,b.foracid 
/

ttitle off
btitle off
undefine all_dashes

whenever sqlerror continue 
spool off
set pause off
set feedback on
set verify on
set heading on
clear breaks
set echo on
exit
