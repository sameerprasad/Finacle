accept start_date prompt " PLEASE ENTER THE START DATE OF THE REPORT "
accept end_date prompt " PLEASE ENTER THE END DATE OF THE REPORT "
-- accept card prompt " PLEASE ENTER THE TYPE OF ACCOUNT like SLCARDCL "
set head off
set pages 64
set echo off
set lines 132
set wrap off
set newpage 0
set space 0
set feedback off
set verify off
set pause off
set termout off
alter session set nls_date_format='dd-mm-yyyy';
set termout on
select 'Working..Please Wait..' from dual;
select '                                    ' from dual;
spool CROLD.lst
select ctd.sol_id ||'|'||tran_date||'|'||foracid||'|'||TRAN_ID||'|'||
decode(part_tran_type,'C',1*tran_amt,-1*tran_amt)||'|'||
TRAN_PARTICULAR||'|'||
tran_rmks||'|'
FROM CTD,GAM
where gam.acid=ctd.acid
and ctd.tran_date between '&start_date' and '&end_date'
and ctd.tran_crncy_code='INR'
and ctd.del_flg!='Y'
and ctd.tran_id in (select distinct tran_id from ctd where acid in (select distinct acid from gam 
								where foracid like '00%SLCARDCL')
		    and tran_date between '&&start_date' and '&&end_date'
		    and tran_crncy_code='INR')
and gam.foracid like '00%SLCARDCL'
order by ctd.sol_id,tran_date
/
spool off
host mail vidyak@ibank.icicibank.com < CROLD.lst
host mailx -s "SLCARDCL REPO" gururajr@icicibank.com < CROLD.lst
host mailx -s "SLCRADCL REPO" guptah@icicibank.com < CROLD.lst
exit
