------------------------------------------------------------------------------
--Date      ver     Author          Rmks
--28-02-2007    1.0     Sanjay K jain       FWC advice
--@fwcadvp.sql 0017 01-01-2000 31-12-2099 ALL B 1 2 ALL
------------------------------------------------------------------------------
set pages 0 line 300 feed off term off veri off echo off
set colsep |
spo fwcadvp.lst
select
    m.sol_id||'|'||
    m.frwrd_cntrct_num||'|'||
    h.CHARGE_TRAN_ID||'|'||
    (select trim(cust_id)||'|'||EMAIL_ID||'|'||CUST_NAME||'|'||CUST_COMU_ADDR1||'|'||
        CUST_COMU_ADDR2||'|'||
    CUST_COMU_CITY_CODE||'|'||CUST_COMU_STATE_CODE||'|'||CUST_COMU_PIN_CODE||'|'||
    CUST_COMU_CNTRY_CODE
    from cmg where cust_id = m.PARTY_CODE)||'|'||
    (select foracid from gam where acid=m.acid)||'|'||
        m.REG_TYPE||'|'||
    m.VALID_TO_DATE||'|'||
    m.FROM_CRNCY_CODE||'|'||
    m.TO_CRNCY_CODE||'|'||
    decode(h.action_code,'A',m.RATE,'L',h.CNCL_TR_SETTLEMENT_RATE)||'|'||
    m.RATECODE||'|'||
    h.action_date||'|'||
    h.action_code||'|'||
    h.AMT_CNCLD||'|'||
    (ACTUAL_AMT_COLL)||'|'||TRAN_RMKS
from    fcm m, fch h, cxl x
where   h.sol_id = m.sol_id
and h.frwrd_cntrct_num = m.frwrd_cntrct_num
and chrg_tran_date = h.action_date and chrg_tran_id = h.CHARGE_TRAN_ID
and PART_TRAN_TYPE ='C' and event_id=h.CHARGE_CODE
and     (m.sol_id = '&1')
and     ((h.ACTION_DATE between '&2' and '&3') or (m.frwrd_cntrct_num between '&6' and '&7'))
and     (m.REG_TYPE = '&4' or '&4' ='ALL')
and     (h.action_code = '&5' or '&5' = 'B')
and     (m.PARTY_CODE = lpad('&8',9) or '&8' = 'ALL')
/
spo off;
