REM####################################################################
REM File Name   : SPCTC2_INT_MOD.sql
REM Description : Suppliers Credit interest Info for TC-2
REM Author      : Paresh Maru
REM Date        : 19-05-2011
REM Module	: Trade Credit
REM####################################################################

REM TABLE NAME: SUP_CR_TC2_INT_MOD

REM SYNONYM:    SPCTC2_INT_MOD

drop table icici.SUP_CR_TC2_INT_MOD
/
drop public synonym SPCTC2_INT_MOD
/
create table icici.SUP_CR_TC2_INT_MOD
(
Int_Bill_no         VARCHAR2(16),
crncy               VARCHAR2(3),
Int_Amt             VARCHAR2(30),
Int_Rate			VARCHAR2(15),
Int_Date            DATE,
Int_Bill_ref_no     VARCHAR2(16),
Int_Bill_ref_amt	VARCHAR2(30),
ENTITY_CRE_FLG      CHAR(1),
DEL_FLG             CHAR(1),
LCHG_USER_ID        VARCHAR2(15),
LCHG_TIME           DATE,
RCRE_USER_ID        VARCHAR2(15),
RCRE_TIME           DATE
)
/* STORE_START */
TABLESPACE ICICI_CUST_SMALL
/* STORE_END */
/
create public synonym SPCTC2_INT_MOD for icici.SUP_CR_TC2_INT_MOD
/
grant select, insert, update, delete on SPCTC2_INT_MOD to tbagen
/
grant select on SPCTC2_INT_MOD to tbacust
/
grant select on SPCTC2_INT_MOD to tbautil
/
grant all on SPCTC2_INT_MOD to tbaadm
/
