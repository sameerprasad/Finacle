

rem This script has been provided for updation after migration to version1.63618
rem The default migration is putting ffp table values as blank for autorenewal
rem gl sub head code. This update would put the correct gl subhead code in ffp 
rem table. 
rem created by Murali verified by V.V.sundar 17/11/1999
spool updffpglsubhead 
set echo on
select gam.foracid, ffp.schm_code, ffp.auto_renewal_flg, ffp.auto_renewal_schm_code,
ffp.auto_renwl_gl_subhead_code from ffp, gam
where gam.acid=ffp.acid 
and ffp.auto_renewal_flg in ('U','L')
and ffp.schm_code in ('FDRBL','FDRPI','CFDEP')
and auto_renwl_gl_subhead_code is null
/
select ffp.schm_code,count(*) from ffp,gam
where gam.acid=ffp.acid 
and ffp.auto_renewal_flg in ('U','L')
and ffp.schm_code in ('FDRBL','FDRPI','CFDEP')
and auto_renwl_gl_subhead_code is null
group by ffp.schm_code
/
update ffp 
set auto_renwl_gl_subhead_code='15050'
where auto_renewal_schm_code='CFDEP'
and ffp.auto_renewal_flg in ('U','L')
and auto_renwl_gl_subhead_code is null
/
update ffp
set auto_renwl_gl_subhead_code='12050'
where auto_renewal_schm_code in ('FDRBL','FDRPI')
and ffp.auto_renewal_flg in ('U','L')
and auto_renwl_gl_subhead_code is null
/
select gam.foracid, ffp.schm_code, ffp.auto_renewal_flg,
ffp.auto_renewal_schm_code,ffp.auto_renwl_gl_subhead_code from ffp, gam
where gam.acid=ffp.acid
and ffp.auto_renewal_flg in ('U','L')
and ffp.schm_code in ('FDBRL','FDRPI','CFDEP')
and auto_renwl_gl_subhead_code is null
/
spool off
host mail murali@icici-bank1<updffpglsubhead.lst
host mail madhavi@icici-bank1<updffpglsubhead.lst 
