rem Script to generate acknowledgement letter for Bill of entry
rem Author : Naresh Kumar
set verify off
set wrap on
set feedback off
set numformat 99,99,99,99,99,999.99
set termout off
set linesize 500
set space 2
set heading off
alter session set nls_date_format = 'DD-MM-YYYY';
spool &1
select 	distinct fbm.party_name||'|'||
	nvl(fbm.party_addr1,' ')||'|'||
	nvl(fbm.party_addr2,' ')||'|'||
	nvl(fbm.party_addr3,' ')||'|'|| 
	nvl(fpc.jcci_code,' ')||'|'|| 
nvl(fbi.bill_of_entry,'--') ||'|'||
nvl(to_char(fbi.bill_of_entry_submit_date),'--')||'|'||
nvl(fbi.licence_det,'--')||'|'||
nvl(fbi.bill_id,'--')||'|'||
nvl(fei.invoice_crncy,'0')||'|'||
nvl(fei.total_invoice_amt,'0')||'|'||
nvl(fei.cmmdty_det,'--')||'|'||
nvl(a.MSG1,'')||'|'||
nvl(b.MSG2,'')||'|'||
nvl(c.MSG3,'')||'|'||
nvl(d.MSG4,'')||'|'||
nvl(e.MSG5,'')
from	fbm, fei, fbi,fpc,
(select msg MSG1 ,sol_id ,bill_id from fxm where msg_class='DB' and msg_srl_num='0001' and sol_id=('&2'))a,
(select msg MSG2 ,sol_id ,bill_id from fxm where msg_class='DB' and msg_srl_num='0002'  and sol_id=('&2'))b,
(select msg MSG3 ,sol_id ,bill_id from fxm where msg_class='DB' and msg_srl_num='0003'  and sol_id=('&2'))c,
(select msg MSG4 ,sol_id ,bill_id from fxm where msg_class='DB' and msg_srl_num='0004'  and sol_id=('&2'))d,
(select msg MSG5 ,sol_id ,bill_id from fxm where msg_class='DB' and msg_srl_num='0005'  and sol_id=('&2'))e
where  fbm.sol_id=('&2')
and     fbm.sol_id=fei.sol_id 
and     fbm.sol_id=fbi.sol_id 
and     fei.sol_id= fbi.sol_id
and     fbm.del_flg !='Y'
and     fbm.bill_id =fei.bill_id
and     fbm.bill_id =fbi.bill_id
and     fei.bill_id =fbi.bill_id
and     fbm.party_code(+)=fpc.party_code
and     fbm.bill_id =a.bill_id (+)
and     fbm.bill_id =b.bill_id (+)
and     fbm.bill_id =c.bill_id (+)
and     fbm.bill_id =d.bill_id (+)
and     fbm.bill_id =e.bill_id (+)
and     fbm.sol_id=a.sol_id (+)
and     fbm.sol_id=b.sol_id (+)
and     fbm.sol_id=c.sol_id (+)
and     fbm.sol_id=d.sol_id (+)
and     fbm.sol_id=e.sol_id (+)
and     fbi.bill_of_entry_submit_date between '&3' and '&4'
/
spool off
exit
