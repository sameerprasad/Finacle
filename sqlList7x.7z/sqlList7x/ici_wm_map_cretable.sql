  
drop table icici.ici_wm_map_tbl 
/
drop public synonym ici_wm_map
/

create table icici.ici_wm_map_tbl
  (CUST_ID        VARCHAR2(9) , 
  RM_NAME         VARCHAR2(50), 
  RM_EMAIL	  VARCHAR2(70),
  RM_MOBILE       VARCHAR2(12), 
  CSM_NAME        VARCHAR2(50), 
  CSM_EMAIL       VARCHAR2(70), 
  CSM_MOBILE      VARCHAR2(12), 
  ENTITY_CRE_FLG  CHAR(1), 
  DEL_FLG         CHAR(1), 
  LCHG_USER_ID    VARCHAR2(15), 
  LCHG_TIME       DATE, 
  RCRE_USER_ID    VARCHAR2(15), 
  RCRE_TIME       DATE)
  /

create public synonym ici_wm_map 
        for icici.ici_wm_map_tbl 
/
grant select, insert, update, delete on ici_wm_map to icici
/
grant select, insert, update, delete on ici_wm_map to tbagen
/
grant select, delete on ici_wm_map to tbacust
/
grant select, insert, update, delete on ici_wm_map to tbautil
/
commit
/
~
