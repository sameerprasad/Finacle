set serveroutput on size 1000000
set feedback off
set verify off
set linesize 500
set pages 0
set trims on
set termout off
set numformat 999D09
spool &3
select distinct '52^639'||'^'||substr(BSR_CODE,length(bsr_code)-3,4)||'^'||''||'^'||lpad('',6)||'^'||lpad('',6)||'^'||lpad('',14)||'^'||to_char(to_date('&2'),'ddmmyyyy')||'^'||lpad('',5)||'^'||lpad('',8)||'^'||lpad('',6)||'^'||lpad('',7)||'^'||lpad('',5)||'^'||lpad('',8)
from ici_gbm_bsrcode 
where sol_id not in (select distinct a.sol_id from ici_gbm_challan_master a,icici_gbm_trn_hdr b where a.tax_tran_id = b.tax_tran_id and a.tax_tran_Date = b.tax_tran_date and a.PAYOUT_DT='&1' and a.del_flg='N' and a.major_tax_head in (select tax_head from ICI_GBM_MAJOR_HEAD where TAX_SCHEME='0005')) and sol_id in (select sol_id from ici_gbm_terminal_master where SCHEME_CODE='0005') and BSR_CODE != '6390005'
/
spool off
