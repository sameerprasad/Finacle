-------------------------------------------------------------------------
--Author    :    Manjunath(BBSSL)
--Date      :    10-11-2011
--Desc      :    Report Of Masters
--File Name :    Report_LocMaster2.sql
------------------------------------------------------------------------



set serveroutput on size 1000000
set lines 2000 
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_LocMaster2.lst
Declare
v_sol_id    wlckm.sol_id%type:='&1';
v_rack_id   wlckm.rack_id%type;
v_locker_type   wlckm.locker_type%type;
v_locker_num    varchar2(10000);
v_locker_num1	varchar2(101);
v_locker_num2	varchar2(101);
v_locker_num3	varchar2(101);
v_locker_num4	varchar2(101);
v_locker_num5	varchar2(101);
v_locker_num6	varchar2(101);
v_locker_num7	varchar2(101);
v_locker_num8	varchar2(101);
v_locker_num9	varchar2(101);
v_locker_num10	varchar2(101);

cursor t1 is select distinct sol_id,locker_type  from wlckm where del_flg ='N' and sol_id = v_sol_id;

cursor t2(v_sol_id varchar2,v_locker_type varchar2) is
    SELECT     sol_id,rack_id,locker_type, LTRIM (MAX (SYS_CONNECT_BY_PATH (locker_num, ',')), ',')
    locker_number
    FROM (SELECT sol_id,rack_id,locker_type, ltrim(substr(locker_num,-5),0) as locker_num,
    ROW_NUMBER () OVER (PARTITION BY rack_id ORDER BY ROWNUM) rn
    FROM wlckm where sol_id = v_sol_id and locker_type = v_locker_type and del_flg ='N')
    CONNECT BY rack_id = PRIOR rack_id AND rn = PRIOR rn + 1
    START WITH rn = 1
    GROUP BY rack_id,sol_id,locker_type
    ORDER BY rack_id;

begin
for i in t1
loop
--{
open t2(i.sol_id,i.locker_type);

loop
--{
    fetch t2 into v_sol_id,v_rack_id,v_locker_type,v_locker_num;

if t2%NOTFOUND then
--{
    close t2;
    exit;
--}
end if;

		v_locker_num1 := substr(v_locker_num,1,100);
		v_locker_num2 := substr(v_locker_num,101,100);
		v_locker_num3 := substr(v_locker_num,201,100);
		v_locker_num4 := substr(v_locker_num,301,100);
		v_locker_num5 := substr(v_locker_num,401,100);
		v_locker_num6 := substr(v_locker_num,501,100);
		v_locker_num7 := substr(v_locker_num,601,100);
 		v_locker_num8 := substr(v_locker_num,701,100);
		v_locker_num9 := substr(v_locker_num,801,100);
		v_locker_num10:= substr(v_locker_num,901,100);

			dbms_output.enable(buffer_size => NULL);

			if(v_locker_num1 is not NULL)then
			dbms_output.put_line(i.sol_id       ||'|'||
                     		 v_rack_id      ||'|'||
                     		 v_locker_type  ||'|'||
                             v_locker_num1);
			end if;

			if(v_locker_num2 is not NULL)then
			dbms_output.put_line(i.sol_id       ||'|'||
                     		 v_rack_id      ||'|'||
                     		 v_locker_type  ||'|'||
                             v_locker_num2);
			end if;
			
			if(v_locker_num3 is not NULL)then
			dbms_output.put_line(i.sol_id       ||'|'||
                     		 v_rack_id      ||'|'||
                     		 v_locker_type  ||'|'||
                             v_locker_num3);
			end if;
			
			if(v_locker_num4 is not NULL)then
			dbms_output.put_line(i.sol_id       ||'|'||
                     		 v_rack_id      ||'|'||
                     		 v_locker_type  ||'|'||
                             v_locker_num4);
			end if;
			
			if(v_locker_num5 is not NULL)then
			dbms_output.put_line(i.sol_id       ||'|'||
                     		 v_rack_id      ||'|'||
                     		 v_locker_type  ||'|'||
                             v_locker_num5);
			end if;
		
			if(v_locker_num6 is not NULL)then
			dbms_output.put_line(i.sol_id       ||'|'||
                     		 v_rack_id      ||'|'||
                     		 v_locker_type  ||'|'||
                             v_locker_num6);
			end if;

			if(v_locker_num7 is not NULL)then
			dbms_output.put_line(i.sol_id       ||'|'||
                     		 v_rack_id      ||'|'||
                     		 v_locker_type  ||'|'||
                             v_locker_num7);
			end if;
			if(v_locker_num8 is not NULL)then
			dbms_output.put_line(i.sol_id       ||'|'||
                     		 v_rack_id      ||'|'||
                     		 v_locker_type  ||'|'||
                             v_locker_num8);
			end if;
			if(v_locker_num9 is not NULL)then
			dbms_output.put_line(i.sol_id       ||'|'||
                     		 v_rack_id      ||'|'||
                     		 v_locker_type  ||'|'||
                             v_locker_num9);
			end if;
			if(v_locker_num10 is not NULL)then
			dbms_output.put_line(i.sol_id       ||'|'||
                     		 v_rack_id      ||'|'||
                     		 v_locker_type  ||'|'||
                             v_locker_num10);
			end if;
			
			
--}
end loop;
--}
end loop;
end;
/
spool off

