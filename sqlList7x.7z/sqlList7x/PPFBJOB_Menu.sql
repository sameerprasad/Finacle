create table tmp_mod32 as (select * from mod where mop_id = 'UPM')
/
update tmp_mod32 set mop_id = 'PPFBJOB', input_filename = 'PPFBJOB.scr', mop_type='W',exe_name='' ,db_status='C'
/
commit;

insert into mod select * from tmp_mod32;

commit;

drop table tmp_mod32;

create table tmp_mod32 as (select * from mod_txt where mop_id = 'UPM');
update tmp_mod32 set mop_id = 'PPFBJOB' , user_mop_id = 'PPFBJOB',mop_text = 'PPF Account Financial Year End Batch Job';
commit;
insert into mod_txt select * from tmp_mod32;
commit;

drop table tmp_mod32;

insert into oat values ('PPFBJOB','DB','TBAADM',sysdate,'TBAADM',sysdate,0)
/
commit
/
insert into mno values ('WFMU','OZ','PPFBJOB','TBAADM',sysdate,'TBAADM',sysdate,0 )
/
commit;

