-- ************************************************************
-- * File Name      :- BKC_Trigger.sql
-- * Trigger Name   :- FIN_BKC_TRIG_AFTER
-- * Description    :- On any manual DB operations on BKC table
-- *                   SOD table will be updated accordingly.
-- * Author         :- Manjunath DV
-- * Date           :- 04-01-2003
-- ************************************************************
create or replace trigger FIN_BKC_TRIG_AFTER
AFTER UPDATE OR INSERT OR DELETE ON TBAADM.BANK_CODE_TABLE FOR EACH ROW
	DECLARE
		old_ts_cnt    NUMBER;
		new_ts_cnt    NUMBER;
		new_table_key TBAADM.SOL_DATA_DISTRBTN_TABLE.TABLE_KEY%TYPE;
		old_table_key TBAADM.SOL_DATA_DISTRBTN_TABLE.TABLE_KEY%TYPE;
		num_of_recs   NUMBER;
		loc_func_code CHAR(1);
		sod_func_code CHAR(1);
		loc_sol_id	  TBAADM.SOL_DATA_DISTRBTN_TABLE.CONTEXT_SOLID%TYPE;
BEGIN --{

	loc_sol_id     := 'ALL';
	new_ts_cnt     := :new.ts_cnt;
	old_ts_cnt     := :old.ts_cnt;
	loc_func_code  := 'A';

	SELECT :old.bank_code into old_table_key from dual;
	SELECT :new.bank_code into new_table_key from dual;

	IF INSERTING THEN --{
		old_ts_cnt    := :new.ts_cnt;
		old_table_key := new_table_key;
	ELSIF DELETING THEN
		new_ts_cnt    := :old.ts_cnt;
		new_table_key := old_table_key;
		loc_func_code := 'D';
	END IF; --}


	-- *********************************************
	-- * Do the DB Operations only if there is no
	-- * change in ts_cnt. This check is required
	-- * to ensure that the updations on the table
	-- * are happening manually and not through the
	-- * Finacle application.
	-- *********************************************

	IF (old_ts_cnt = new_ts_cnt) THEN --{
	BEGIN --{
		BEGIN  --{
			SELECT TABLE_FUNC,1 INTO sod_func_code,num_of_recs FROM TBAADM.SOL_DATA_DISTRBTN_TABLE
					WHERE CONTEXT_SOLID = loc_sol_id
					AND TABLE_KEY=old_table_key AND TABLE_ABBR='BKC';
		EXCEPTION
			WHEN NO_DATA_FOUND THEN
				num_of_recs := 0;
				sod_func_code := 'A';
			WHEN OTHERS THEN
				num_of_recs := 0;
				sod_func_code := 'A';
		END; --}

		IF num_of_recs = 1 THEN --{
			IF (new_table_key <> old_table_key)  THEN  --{
				-- *********************************************
				-- * 1. If Key fields are got modified then
				-- *    Update existing record with table_func = 'D'
				-- *    So as to delete the record from CSIS DB.
				-- * 2. Insert a record with new values.
				-- *********************************************

				UPDATE TBAADM.SOL_DATA_DISTRBTN_TABLE SET TABLE_FUNC = 'D' 
						WHERE CONTEXT_SOLID = loc_sol_id
						AND TABLE_KEY=old_table_key AND TABLE_ABBR='BKC';
				INSERT INTO TBAADM.SOL_DATA_DISTRBTN_TABLE VALUES (loc_sol_id,'BKC',new_table_key,loc_func_code,0);

			ELSIF (loc_func_code <> sod_func_code) THEN 
				-- **********************************************
				-- * 1. If there is a difference in func_codes
				-- *    then udpate the existing record.
				-- **********************************************

				UPDATE TBAADM.SOL_DATA_DISTRBTN_TABLE SET 
						CONTEXT_SOLID = loc_sol_id,TABLE_KEY=new_table_key,
						TABLE_ABBR='BKC',TABLE_FUNC=loc_func_code
					WHERE CONTEXT_SOLID = loc_sol_id
					AND TABLE_KEY = old_table_key AND TABLE_ABBR='BKC';
			END IF; --}
		ELSE 
			-- *********************************************
			-- * 1. Insert a record with new values.
			-- * 2. If Key fields are got modified then
			-- *    Insert a record with table_func = 'D'
			-- *    So as to delete the record from CSIS DB.
			-- *********************************************

			INSERT INTO TBAADM.SOL_DATA_DISTRBTN_TABLE VALUES 
				(loc_sol_id,'BKC',new_table_key,loc_func_code,0);

			IF (new_table_key <> old_table_key)  THEN  --{
				INSERT INTO TBAADM.SOL_DATA_DISTRBTN_TABLE VALUES
					(loc_sol_id,'BKC',old_table_key,'D',0);
			END IF; --}

		END IF; --}

	END; --}
	END IF; --}

END; --}
/
