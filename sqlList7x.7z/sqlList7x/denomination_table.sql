Rem     This file will create TEMP_PIADV
Rem     with the following characteristics.

Rem TABLE NAME: ICI_DENOM_TABLE 

Rem SYNONYM:    ICI_DENOM 

--drop index ICICI.IDX_UNIQ_TEMP_PIADV
--/
drop table ICICI.ICI_DENOM_TABLE
/
drop public synonym ICI_DENOM
/

create table ICICI.ICI_DENOM_TABLE
(
	TRAN_IDENTIFIER								VARCHAR2(16 CHAR),
	SOL_ID										VARCHAR(8),
	TRAN_AMT									NUMBER(20, 4),
	TRAN_DATE									DATE,
 	FROM_FORACID                                VARCHAR2(16 CHAR),
 	TO_FORACID                                  VARCHAR2(16 CHAR),
	COUNTRS1000									NUMBER,
	COUNTRS500									NUMBER,
	COUNTRS100									NUMBER,
	COUNTRS50									NUMBER,
	COUNTRS20									NUMBER,
	COUNTRS10									NUMBER,
	COUNTRS5									NUMBER,
	COUNTRS2									NUMBER,
	COUNTRS1									NUMBER,
	COUNTCRS10                                  NUMBER,
    COUNTCRS5                                   NUMBER,
    COUNTCRS2                                   NUMBER,
    COUNTCRS1                                   NUMBER,
	COUNT50PS									NUMBER,
	COUNT25PS									NUMBER,
    LCHG_USER_ID 								VARCHAR(15),
    LCHG_TIME 									DATE,
    RCRE_USER_ID 								VARCHAR(15),
    RCRE_TIME 									DATE,
	TS_CNT 										NUMBER(5)
)
/

--create unique index ICICI.IDX_UNIQ_TEMP_PIADV   on ICICI.TEMP_PIADV(FORACID)
--/

create public synonym ICI_DENOM for ICICI.ICI_DENOM_TABLE	
/

grant select, insert, update, delete on ICI_DENOM to tbagen
/
grant select, insert, update, delete on ICI_DENOM to tbaadm
/
grant select on ICI_DENOM to tbacust
/
grant select on ICI_DENOM to tbautil
/
