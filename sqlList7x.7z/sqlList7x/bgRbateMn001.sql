set serveroutput on size unlimited
set lines 2000
set feedback off
set trims on
set pages 0
set echo off
set verify off
set head off
spool bgRbateMn001.lst


declare

max_dueDt date := '';
min_dueDt date := '';
next_dueDt date := '';
tot_days number := '0';
v_days number := '0';
accr_amt number(20,4) := '0';
v_tran_amt number(20,4) := '0';
v_srlnum VARCHAR2(5):= '0';
v_rbt_amt number(20,4) := '0';
v_nxtduedate date := '';
v_dsrlnum VARCHAR2(5):= '0';

cursor cursor1 is 
select
cht.B2K_ID,
cht.B2KID_TYPE,
cht.PTRAN_BUS_TYPE,
cht.ECT_SRL_NUM,
cht.CHT_KEY_SRL_NUM,
cht.EVENT_ID,
cht.EVENT_TYPE,
cht.UPFRONT_DEF_FLG,
cht.CR_DR_IND,
cht.CHRG_CRNCY_CODE,
cht.TTL_SYS_CALC_CHRG_AMT,
cht.TTL_CHRG_TOBE_COLL_AMT,
cht.TRAN_ID,
cht.TRAN_DATE,
cht.TRAN_RMKS,
cht.OPER_ACID,
cht.OPER_CRNCY_CODE,
cht.CHRG_ACID,
cht.RATE_CODE,
cht.RATE,
cht.REFUND_FLG,
cht.DR_CONS_FLG,
cht.SUPERSEDE_FLG,         
cht.TTL_CHRG_DUE_AMT,
cht.TTL_CHRG_COLL_AMT,
bgm.bg_srl_num,
bgm.effective_date,
bgm.claim_expiry_date,
bgm.sol_id,
bgm.bg_expiry_date,(select foracid from gam where acid =cht.chrg_acid ) chrg_ac
from bgm, cht, gam 
where bgm.BG_B2KID = cht.B2K_ID
and gam.acid = cht.chrg_acid
--and bgm.bg_srl_num in('017BG64008')
--and bgm.effective_date <= (select db_stat_date from gct)
--and bgm.bg_expiry_date >= (select db_stat_date from gct)
and bgm.effective_date <= '&1'
and bgm.bg_expiry_date >= '&1'
--and cht.TTL_SYS_CALC_CHRG_AMT != 0
and (cht.PTRAN_BUS_TYPE = '!' OR cht.PTRAN_BUS_TYPE = 'COMM')
and bgm.claim_expiry_date > '&1'
and bgm.bg_status not in ('Z','R','K')
and gam.bacid ='CNGTE-ISSUE'
and gam.entity_cre_flg = 'Y'
and gam.del_flg != 'Y'
and gam.acct_cls_date is null
order by bgm.sol_id;

BEGIN

for fc1 in cursor1
loop

--dbms_output.put_line(fc1.bg_srl_num||'|'||'00');
BEGIN
	select max(due_date) 
	into max_dueDt 	
	from dcc 	
	where  B2K_ID = fc1.B2K_ID 
	and (dcc.PTRAN_BUS_TYPE = '!' OR dcc.PTRAN_BUS_TYPE = 'COMM') ;
	EXCEPTION
	when no_data_found then
	max_dueDt := '';
	when others then
	max_dueDt := '';
END;

BEGIN
	select min(due_date) 
	into min_dueDt 
	from dcc 	
	where  B2K_ID = fc1.B2K_ID 
	and (dcc.PTRAN_BUS_TYPE = '!' OR dcc.PTRAN_BUS_TYPE = 'COMM');
	EXCEPTION
	when no_data_found then
	min_dueDt := '';
	when others then
	min_dueDt := '';
END;

--dbms_output.put_line(fc1.bg_srl_num||'|'||'11');
BEGIN
	select TRAN_AMT 
	into v_tran_amt 
	from dcc 
	where  B2K_ID = fc1.B2K_ID 
	and (dcc.PTRAN_BUS_TYPE = '!' OR dcc.PTRAN_BUS_TYPE = 'COMM')
	and TRAN_ID is not null
	and TRAN_ID = fc1.TRAN_ID;
	EXCEPTION
	when no_data_found then
	v_tran_amt := '';
	when others then
	v_tran_amt := '';
END;

BEGIN
    select  max(DCC_KEY_SRL_NUM)+1
    into v_srlnum
    from dcc
    where  B2K_ID = fc1.B2K_ID
    and (dcc.PTRAN_BUS_TYPE = '!' OR dcc.PTRAN_BUS_TYPE = 'COMM')
    and TRAN_ID is not null;
    EXCEPTION
    when no_data_found then
    v_srlnum    :='';
    when others then
    v_srlnum    :='';
END;

--dbms_output.put_line(fc1.bg_srl_num||'|'||'22'||'|'||v_tran_amt||'|'||v_srlnum );
BEGIN
	select due_date  
	into next_dueDt 
	from dcc 
	where  B2K_ID = fc1.B2K_ID 
	and (dcc.PTRAN_BUS_TYPE = '!' OR dcc.PTRAN_BUS_TYPE = 'COMM')
	and to_number(DCC_KEY_SRL_NUM) = v_srlnum
	and rownum < 2;
	EXCEPTION
	when no_data_found then
	next_dueDt := '';
	when others then
	next_dueDt := '';
END;

--dbms_output.put_line(fc1.UPFRONT_DEF_FLG||'|'||max_dueDt||'|'||min_dueDt||'|'||v_srlnum||'|'||next_dueDt||'|'||fc1.claim_expiry_date ||'|'|| fc1.effective_date);

--dbms_output.put_line('--bf'||'|'||fc1.TTL_CHRG_TOBE_COLL_AMT||'|'||v_days||'|'||tot_days||'|'||v_tran_amt||'|'||accr_amt);

if ( fc1.UPFRONT_DEF_FLG = 'U') then
	BEGIN
		--dbms_output.put_line('IF');
		select (fc1.claim_expiry_date - fc1.effective_date) + 1, (to_date('&1') - fc1.effective_date) + 1 
		into tot_days,v_days 
		from dual;
		EXCEPTION
		when no_data_found then
		tot_days := '1';
		v_days := '1';
	END;

	accr_amt := (fc1.TTL_CHRG_TOBE_COLL_AMT * v_days)/tot_days;
	v_rbt_amt := fc1.TTL_CHRG_TOBE_COLL_AMT-accr_amt;
else
	BEGIN
   		select  max(DCC_KEY_SRL_NUM)
    	into v_dsrlnum
    	from dcc
    	where  B2K_ID = fc1.B2K_ID
    	and (dcc.PTRAN_BUS_TYPE = '!' OR dcc.PTRAN_BUS_TYPE = 'COMM')
    	and TRAN_ID is not null;
    	EXCEPTION
    	when no_data_found then
    	v_dsrlnum    :='';
    	when others then
    	v_dsrlnum    :='';
	END;

	BEGIN
		select due_date 
		into v_nxtduedate
		from dcc
		where  B2K_ID = fc1.B2K_ID
        and (dcc.PTRAN_BUS_TYPE = '!' OR dcc.PTRAN_BUS_TYPE = 'COMM')
		and to_number(DCC_KEY_SRL_NUM) = v_dsrlnum
        and TRAN_ID is null;
        EXCEPTION
        when no_data_found then
		v_nxtduedate :='';
		when others then
        v_nxtduedate :='';
	END;

	if v_nxtduedate is not null then
		next_dueDt := v_nxtduedate;
	end if;	

	if (next_dueDt = min_dueDt) then
	BEGIN
        --dbms_output.put_line('else'||'|'||next_dueDt||'|'||min_dueDt||'|'||'31-03-2013');
        select fc1.claim_expiry_date - min_dueDt, (to_date('&1') - min_dueDt) +1
        into tot_days,v_days
        from dual;
        EXCEPTION
        when no_data_found then
        tot_days := '1';
        v_days := '1';
    END;
	else
	BEGIN
		--dbms_output.put_line('else'||'|'||next_dueDt||'|'||min_dueDt||'|'||'31-03-2013');
		select next_dueDt - min_dueDt, (to_date('&1') - min_dueDt) +1 
		into tot_days,v_days 
		from dual;
		EXCEPTION
		when no_data_found then
		tot_days := '1';
		v_days := '1';
	END;
	end if;

	if(tot_days = 0) then
		tot_days := '1';
	end if;

	accr_amt := (v_tran_amt * v_days)/tot_days;
	v_rbt_amt := v_tran_amt-accr_amt;

	if (v_rbt_amt < 0 ) then
		v_rbt_amt := 0;
	end if;

end if;

--dbms_output.put_line('--af'||'|'||fc1.TTL_CHRG_TOBE_COLL_AMT||'|'||v_days||'|'||tot_days||'|'||v_tran_amt||'|'||accr_amt||'|'||fc1.claim_expiry_date ||'|'|| fc1.effective_date);


dbms_output.put_line(fc1.bg_srl_num||'|'||
					fc1.chrg_ac||'|'||
					fc1.oper_crncy_code||'|'||
					fc1.sol_id||'|'||
					fc1.CR_DR_IND||'|'||
					fc1.TRAN_RMKS||'|'||
					v_rbt_amt||'|'||
					fc1.TTL_CHRG_COLL_AMT||'|'||
					fc1.TTL_CHRG_DUE_AMT||'|'||
					fc1.SUPERSEDE_FLG||'|'||
					max_dueDt||'|'||
					min_dueDt||'|'||
					tot_days||'|'||
					v_days);
--dbms_output.put_line(fc1.bg_srl_num||'|'||'99');
v_rbt_amt := '0';
accr_amt := '0';
tot_days := '1';
v_days := '1';
next_dueDt := '';
max_dueDt	 := '';
min_dueDt  := '';
v_tran_amt := '0';
v_srlnum := '0';


end loop;
END;
/
spool off
