set heading off
set term off
set linesize 500
set pages 0
set echo off
set feedback off
set verify off
alter session set nls_date_format = 'DD-MM-YYYY';
coulmn bill_amt format b999,99,99,99,99,999.99
spool &1
select c.bill_id||'|'||c.lodg_date||'|'||
       ltrim(to_char(abs(c.bill_amt),'b99,99,99,99,999.99'))||'|'||
       c.due_date||'|'||
		c.drawee_name||'|'||
		NVL(c.drawee_addr1,' ')||'|'||
		NVL(c.drawee_addr2,' ')||'|'||
		NVL(c.drawee_addr3,' ')||'|'||
		c.lodg_coll_br_name||'|'||
		NVL(c.lodg_coll_br_addr1,' ')||'|'||
		NVL(c.lodg_coll_br_addr2,' ')||'|'||
		NVL(c.lodg_coll_br_addr3,' ')||'|'||
		NVL(c.lodgr_ref_num,' ')||'|'||
        NVL(c.ref_bill_id,'T')||'|'
from blt c 
where c.reg_type in ('OBC' , 'OBD' , 'OBP')
and   c.cls_flg != 'Y'
and   c.due_date between '&2' and '&3'
and   c.bill_stat = 'G'
and c.sol_id = '&4'
/
spool off
exit
