rem This script is to find out those FFD deposit accounts where the 
rem auto_renewal_flg at account level is NO and Lien_flg is Yes
rem Such accounts should be modified in ACM to make the auto_renewal_flg as 'Y'
rem and Lien_flg  as 'N'. This is done to ensure that any penalty which 
rem is there on account of II flow is adjusted on Auto-renewal.
rem V.V.Sundar	29th April 1997
rem To include reserved_amt also on 14-May-97
set pause off
set newpage 0
set pages 60
set linesi 132
set numformat B9999,99,99,99,999.00
set heading on
set feedback off
set echo off
set verify off
break on cust_id on Oper_acct skip 2 on oper_reserved_amt on Name on report
compute sum of Deposit Balance on Oper_acct skip 1 
compute sum of Deposit Balance  on report
column auto_renewal_flg format a14
column today new_value todate
column branch new_value br
column auto_renewal_flg heading AUTO_RENEW_FLG format a15
column lien_flg format a8
select to_char(sysdate,'DD-MON-YYYY') today from dual;
select br_name branch from bct where br_code =(select br_code from sol 
						where sol_id='&1');
spool ffdflags.lst
ttitle center ' ICICI BANK LIMITED ' skip 1-
center br ' BRANCH ' skip 2-
center ' LIST OF QUANTUM DEPOSIT ACCOUNTS WHERE AUTO-RENEWAL FLG IS NO 'skip 1-
center '       OR  LIEN-FLG IS YES OR RESERVED AMOUNT IS ENTERED' skip 1-
left  ' Date : ' todate  skip 1
btitle 'THE ABOVE ACCOUNTS SHOULD HAVE THE FOLLOWING : ' skip 2 - 
left ' AUTO-RENEWAL-FLG=Y ' skip 1-
left ' LIEN-FLG=N ' skip 1-
left ' RESERVED AMOUNT IN OPERATIVE ACCOUNT SHOULD BE BLANK ' skip 2-
left ' PLEASE CHECK THE ABOVE ACCOUNTS AND MAKE NECESSARY MODIFICATIONS '
select m.cust_id, substr(m.acct_name,1,15) Name, 
g.foracid ACCOUNT,
deposit_amount Deposit,auto_renewal_flg ,
lien_flg lien,g.lien_amt Oper_reserved_amt
from gam g,gam m,tam,ffl
where g.sol_id='&1'
and m.sol_id='&1'
and ffl.acid=g.acid
and ffl.ffd_acid=tam.acid
and ffl.ffd_acid=m.acid
and ffl.del_flg!='Y'
and (tam.auto_renewal_flg not in ('Y','U','L')
or tam.lien_flg='Y'
or g.reserved_amt >0)
and g.acct_cls_flg!='Y'
order by g.cust_id,g.foracid
/
spool off
rem This script is to find out those Quantum Deposits where there is a 
rem difference between the Deposit amount and Balance amount.
rem Branch should check this report and find out the reasons for the difference
rem This difference could be because of TM debit or crediting wrong amount
rem at the time of opening the account.
set newpage 0
set feedback off
set termout off
set pages 60
set linesi 80
set numformat B9999,99,99,99,999.00
set heading on
set feedback off
set echo off
set verify off
break on cust_id on Oper_acct skip 2 on reserved on Name on report
compute sum of Deposit Balance on Oper_acct skip 1 
compute sum of Deposit Balance  on report
column DEP_Balance format B9999,99,99,999.00
column today new_value todate
column branch new_value br
select to_char(sysdate,'DD-MON-YYYY') today from dual;
select br_name branch from bct where br_code =(select br_code from sol 
						where sol_id='&1');
spool ffdbaldiff.lst
ttitle center ' ICICI BANK LIMITED ' skip 1-
center br ' BRANCH ' skip 2-
center  '     LIST OF QUANTUM DEPOSIT ACCOUNTS 'skip 1-
center  ' WHERE THE DEPOSIT AMOUNT AND BALANCE DIFFER ' skip 1 -
left  ' Date : ' todate skip 2
btitle left ' THE ABOVE IS THE LIST WHERE THE DEPOSIT AMOUNT is GREATER THAN BALANCE' skip 2 -
left 'PLEASE CHECK THE REASONS FOR THE DIFFERENCE IN THE DEPOSIT AMOUNT ' skip 2 -
left 'AND BALANCE AND  RECTIFY THE SAME '
select m.cust_id,g.foracid Oper_acct,
substr(m.acct_name,1,15) Name,ffd_acid FFD_ACS, 
deposit_amount Deposit,
decode(m.clr_bal_amt,'','NIL',m.clr_bal_amt) DEP_Balance,
g.reserved_amt OPER_reserved 
from gam g,gam m,tam,ffl
where g.acid= m.acid
and ffl.acid=g.acid
and ffl.ffd_acid=tam.acid
and ffl.ffd_acid=m.acid
and ffl.del_flg!='Y'
and tam.deposit_amount >m.clr_bal_amt
order by g.cust_id,g.foracid
/
spool off
rem This sql is to find out if any Customer Instructions are issued in the
rem Quantum Deposit Accounts.
rem This should not be entered by the users
rem This will generate a report and print it on Line 
rem Printer as part of Pre-Eod. The report should be perused and necessary 
rem Modifications should be made
set newpage 0
set feedback off
set echo off
set verify off
set pages 60
set linesi 80
set numformat B9999,99,99,99,999.00
set heading on
column today new_value todate
column branch new_value br
select to_char(sysdate,'DD-MON-YYYY') today from dual;
select br_name branch from bct where br_code =(select br_code from sol 
						where sol_id='00');
spool ffdins
ttitle center ' ICICI BANK LIMITED ' skip 1-
center br ' BRANCH ' skip 2-
center ' LIST OF QUANTUM DEPOSIT ACCOUNTS FOR WHICH CUSTOMER-INSTRUCTIONS ARE GIVEN ' skip 1 -
left  ' Date : ' todate  skip 2
btitle 'THE ABOVE ACCOUNTS SHOULD NOT HAVE ANY CUSTOMER INSTRUCTIONS DEFINED ' skip 1 -
left ' PLEASE MAKE NECESSARY MODIFICATIONS IN ACM - OPTION C OF THE DEPOSIT ACCOUNT ' 
select foracid FFD_ACCOUNT
from ffl,cit,gam
where ffl.ffd_acid=cit.acid
and ffl.ffd_acid = gam.acid
and ffl.del_flg!='Y'
/
spool off
host echo "  "
host echo "  "
host echo "  "
host echo "  "
host echo " GENERATING REPORT ON STAFF DEPOSITS WITH WRONG INTEREST CODE "
host echo "  "
host echo "  "
set head on
set numformat B9999,99,99,999.00
set termout off
set pagesi 60
set linesi 132
set feedback on
break on cust_id skip 1 on report
column bran new_value br
select br_name bran from bct where br_code=(select br_code from sol);
column today new_value todate
column to_day new_value to_date
column int_tbl_code format  a8 heading "INT_CODE"
select to_char(sysdate,'DD-MM-YYYY') to_day from dual;
select db_stat_date today from gct;
ttitle center ' ICICI BANK LIMITED 'skip 1 -
center br  ' BRANCH ' skip 1 -
left ' Date :' to_date skip 2 -
center ' LIST OF STAFF TERM DEPOSIT ACCOUNTS AS ON ' todate skip 1 -
center ' WITH INTEREST CODE OTHER THAN TDSTF ' skip 3
btitle left ' PLEASE CHECK FOR THE DISCREPANCIES AND MAKE THE NECESSARY CORRECTIONS' skip 1 -
left ' in option INTTM '
spool tdstf
select gam.cust_id,substr(gam.acct_name,1,15) NAME,gam.foracid ACCOUNT,
int_tbl_code , cmg.cust_stat_code STATUS,t.deposit_amount DEPOSIT,gam.clr_bal_amt BALANCE
from cmg,gam,tam t,itc
where gam.sol_id = '&1'
and itc.entity_id=gam.acid
and substr(gam.foracid,3,2) in ('10','15','25')
and itc.acid=t.acid
and gam.cust_id=cmg.cust_id
and gam.acct_cls_flg!='Y'
and ltrim(cmg.cust_stat_code)='STF'
and int_tbl_code !='TDSTF'
and int_tbl_code_srl_num =(select max(int_tbl_code_srl_num) from itc t
				where t.acid=itc.acid
				and del_flg!='Y')
order by 1,3,5
/
spool off
rem host lp ffdflags.lst ffdins.lst ffdbaldiff.lst tdstf.lst
exit
