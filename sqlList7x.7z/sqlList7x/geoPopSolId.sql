set verify off
set feedback off
set pages 0
set trims on
set linesize 512
spool fsgPopSolId-&1

SELECT 'Updating home_sol_id for Cust Prefix &1 ....' FROM DUAL;
DECLARE

userId		cmg.rcre_user_id%TYPE;
solId		gam.sol_id%TYPE;	
rcreTime	DATE;
custPfx		VARCHAR2(2);
stmtReqd	icici_cift.stmt_reqd%type;
homeSolId	icici_cift.home_sol_id%TYPE;

CURSOR 	cifCur IS
SELECT	cust_id, stmt_reqd
FROM	icici_cift
WHERE	cust_id LIKE '&1%'
OR		cust_id LIKE ' &1%'
OR		cust_id LIKE '  &1%'
OR		cust_id LIKE '   &1%'
OR		cust_id LIKE '    &1%'
OR		cust_id LIKE '     &1%'
OR		cust_id LIKE '      &1%'
FOR	UPDATE;
	
	
BEGIN
	custPfx := '&1';
	FOR cifRec IN cifCur LOOP
	BEGIN
		IF (custPfx != '50') THEN
			homeSolId := '00' || custPfx;
		ELSE
		BEGIN
			SELECT  MIN(rcre_time)
			INTO	rcreTime
			FROM    gam
			WHERE   cust_id = cifRec.cust_id 
			AND 	acct_cls_flg != 'Y'
			AND     del_flg != 'Y'
			AND     entity_cre_flg = 'Y'
			AND     acct_ownership != 'O'
			AND     schm_type IN ('SBA', 'CAA', 'ODA');
		
		 	SELECT	sol_id
			INTO	homeSolId
			FROM	gam
			WHERE	cust_id = cifRec.cust_id
			AND 	acct_cls_flg != 'Y'
			AND     del_flg != 'Y'
			AND     entity_cre_flg = 'Y'
			AND     acct_ownership != 'O'
			AND     schm_type IN ('SBA', 'CAA', 'ODA')
			AND		rcre_time = rcreTime
			AND		rownum < 2;
		
			EXCEPTION WHEN NO_DATA_FOUND THEN
			BEGIN
				SELECT	rcre_user_id
				INTO	userId
				FROM	cmg
				WHERE	cust_id = cifRec.cust_id;
			
				SELECT	sol_id
				INTO	homeSolId
				FROM	upr
				WHERE	user_id = userId;
			END;
		END;
		END IF;
	
		if(cifRec.stmt_reqd is null) then
			UPDATE	ICICI_CIFT
			SET		home_sol_id = homeSolId, stmt_reqd = 'Y'
			WHERE	CURRENT OF cifCur;
		else
			UPDATE  ICICI_CIFT
			SET     home_sol_id = homeSolId
			WHERE   CURRENT OF cifCur;
		end if;
	END;
	END LOOP;

	COMMIT;
END;
/
SELECT 'Successfully Updated home_sol_id for Cust Prefix &1 ....' FROM DUAL;
spool off
QUIT
