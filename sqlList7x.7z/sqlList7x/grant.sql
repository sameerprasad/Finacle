grant select,update,insert,delete on icici_ldtt to tbautil;
