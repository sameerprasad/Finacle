--- CAF data for AGRI
--- Accepts input parameter as timestamp

--set serveroutput on size 100000


declare

fp				utl_file.file_type;
fe				utl_file.file_type;
rec_cnt			number :=0;
bin_num			varchar2(10);
card_type		varchar2(5);
fiid			varchar2(5);
cust_catg		varchar2(5);
name_1			varchar2(30);
name_2			varchar2(30);
addr_1			varchar2(34);
addr_2			varchar2(34);
city_name		varchar2(22);
state_name		varchar2(10);
pin				varchar2(10);
cntry_code		varchar2(5);
telephone		varchar2(40);
ac_type			varchar2(3);
ac_num			varchar2(19);
act_stat		varchar2(1);
ikit_flg		varchar2(1);
ac_crncy		varchar2(5);
mobile_num		varchar2(15);
email			varchar2(40);
dob				varchar2(10);
corp_name		varchar2(40);
cust_seg		varchar2(7);
customer_id		varchar2(9);
nat_id			varchar2(16);

file_hdr		varchar2(20);
file_trlr		varchar2(15);


cursor cdtt_cur is
select 	cust_id,
		card_1_number,
		decode(card_1_number,'97','508534','98','940149',' ') bin_num,
		decode(card_1_number,'97','VD','98','P ',' ') card_type
  from icici_cdtt_daily ;

cursor cmg_cur(cid cmg.cust_id%type) is 
select 	cmg.cust_id,
		cust_stat_code,
		cust_const,
		decode(cust_title_code,'MR','1','MRS','2','MISS','3','MS','4','DR','5','0') title,
		cust_name,
		cust_comu_addr1,
		cust_comu_addr2,
		cust_comu_city_code,
		cust_comu_state_code,
		cust_comu_pin_code,
		decode(cust_comu_cntry_code,'IN','356',cust_comu_cntry_code) cntry,
		nvl(cust_comu_phone_num_1,' ') cust_comu_phone_num_1,
		nvl(nat_id_card_num,' ') nat_id_card_num,
		to_char(date_of_birth,'DDMMYYYY') dob,
		nvl(cust_pager_no,' ') cust_pager_no,
		decode(schm_type,'SBA','11','LAA','31','CAA','01') acct_type,
		foracid,
		decode(acct_crncy_code,'INR','356',acct_crncy_code) acct_crncy_code,
		gam.sol_id,
		nvl(email_id,' ') email_id
  from  CMG,GAM
 where  CMG.cust_id = cid
   and  schm_code = 'SBGON'
   and  GAM.cust_id = CMG.cust_id
   and  GAM.entity_cre_flg ='Y'
   and  GAM.del_flg = 'N'
   and  GAM.pbf_download_flg = 'Y'
   and  CMG.cust_minor_flg != 'Y'
   and  GAM.acct_cls_flg = 'N';



Begin
fe := utl_file.fopen('/tmp','caf_agri_&1..err','w');
fp := utl_file.fopen('/tmp','caf_agri_&1..txt','w');

		----file_hdr := 'FH20120508101223'; 
		file_hdr := 'FH'||'&1';

		utl_file.put_line(fp,file_hdr);
for a in cdtt_cur
loop

For c in cmg_cur(a.cust_id)
Loop
		rec_cnt := rec_cnt + 1;


		bin_num := lpad(a.bin_num,6);
		fiid      := c.sol_id ;
		cust_catg := lpad(c.cust_stat_code,5);
		name_1    := rpad(c.cust_name,30);
		name_2    := rpad(' ',30);
		addr_1    := rpad(nvl(c.cust_comu_addr1,' '),34);
		addr_2    := rpad(nvl(c.cust_comu_addr2,' '),34);
		
		Begin
		Select ref_desc into city_name from rct where ref_rec_type='01' and ref_code = c.cust_comu_city_code;
		exception
		when no_data_found then
			city_name := c.cust_comu_city_code;
		End;

		city_name := rpad(city_name,22);
		state_name:= rpad(c.cust_comu_state_code,3);
		pin		  := rpad(c.cust_comu_pin_code,9);
		cntry_code := c.cntry;

		telephone := rpad(c.cust_comu_phone_num_1,40);
		ac_type   := c.acct_type ;
		ac_num    := rpad(c.foracid,19);
		act_stat  := '3';
		ikit_flg  := 'I';
		ac_crncy  := c.acct_crncy_code;
		mobile_num := rpad(c.cust_pager_no,15);
		email      := rpad(c.email_id,40);
		dob        := c.dob;
		corp_name := rpad(' ',40);
		cust_seg  := rpad(' ',7);
		customer_id := c.cust_id;

		if (a.card_1_number = '98') then
			Begin
			Select rpad(urn_no,16) into nat_id from ICI_MAP_AADHAR_ACCT
          	where foracid = c.foracid ;
			Exception
			when no_data_found then
				nat_id := NULL;
			End;
		else
			nat_id  := rpad(c.nat_id_card_num,16);
		end if ;
		
		utl_file.put_line(fp,
								bin_num||a.card_type||fiid||cust_catg||c.title||name_1||name_2||addr_1||addr_2||city_name||state_name||pin||
								cntry_code||telephone||ac_type||ac_num||act_stat||ikit_flg||ac_crncy||mobile_num||email||dob||corp_name||
								cust_seg||customer_id||nat_id
						);
		---For deletion of the ICICI_CDTT_DAILY RECORD
			--Begin
		---	Delete icici_cdtt_daily where cust_id = c.cust_id ;
		---	Exception
		---	When others then
		---		errstr := 'Error in deletion ICICI_CDTT_DAILY record'||'|'||c.cust_id ;
		---		utl_file.put_line(fe,errstr);
		---	End;
		---ICICI_CDTT_DAILY DELETION TILL HERE 
End loop;
End loop;
		file_trlr:= 'FT'||lpad(rec_cnt,10,'0');
		utl_file.put_line(fp,file_trlr);
utl_file.fclose(fp);
utl_file.fclose(fe);
End;
/
