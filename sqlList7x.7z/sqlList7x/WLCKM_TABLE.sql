Rem     This file will create LOCKER_KEY_MAINTENENCE Table
Rem     with the following characteristics.

Rem     Coded by : Saravanan (BBSSL)

Rem     Module  : LOCKER

Rem TABLE NAME: LOCKER_KEY_MAINTENENCE

Rem SYNONYM:    WLCKM

drop table icici.LOCKER_KEY_MAINTENENCE
/
drop public synonym WLCKM
/
create table icici.LOCKER_KEY_MAINTENENCE
(
SOL_ID		VARCHAR2(8),
LOCKER_TYPE	VARCHAR2(5),
SIZE_OF_LOCKER	VARCHAR2(11),
RACK_ID		VARCHAR2(3),
LOCKER_NUM	VARCHAR2(12),
KEY_NUM		VARCHAR2(8),
STATUS		CHAR(1),
REMARKS		VARCHAR2(40),
DEL_FLG		CHAR(1),
ENTITY_CRE_FLG  CHAR(1),
LCHG_USER_ID    VARCHAR2(15),
LCHG_TIME       DATE,
RCRE_USER_ID    VARCHAR2(15),
RCRE_TIME       DATE,
SURRENDER_DATE	DATE
)
/* STORE_START */                          
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */               
/
create public synonym WLCKM for icici.LOCKER_KEY_MAINTENENCE
/
grant select, insert, update, delete on WLCKM to tbagen
/
grant select on WLCKM to tbacust
/
grant select on WLCKM to tbautil
/
create unique index idx_wlckm on WLCKM(SOL_ID,LOCKER_TYPE,LOCKER_NUM,KEY_NUM,STATUS)
/
grant all on WLCKM to tbaadm
/
