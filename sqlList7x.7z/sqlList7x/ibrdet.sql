set lines 1000 pages 1000 colsep | trims on
set echo off
set verify off feedback off headsep !
set serveroutput on size 1000000
select b.bar_or_advc_num IBR_NO, b.bar_or_advc_date ORIG_DATE, b.tran_id TRAN_ID, 
       h.entry_user_id ENTRY_USER_ID, e.user_emp_id ENTRY_EMP, h.vfd_user_id VRFD_USER_ID, v.user_emp_id VRFD_EMP
from bat b, htd h, upr e, upr v
where bar_or_advc_date = '&1'
and bar_or_advc_num = lpad('&2',12,' ')
and nft_type = 'OAD'
and b.tran_date = h.tran_date
and b.tran_id = h.tran_id
and b.part_tran_srl_num = h.part_tran_srl_num
and h.entry_user_id = e.user_id
and h.vfd_user_id = v.user_id
and b.del_flg != 'Y'
/
