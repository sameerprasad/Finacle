REM################################################################################
REM File Name   : PFAMTRFS_MOD.sql
REM Description : Table creation for storing
REM              unverified Provident fund Account details(PFAM)
Rem Module      : PPF
REM################################################################################
drop table CUST_PPF_ACCOUNT_TRFS_MOD
/
drop public synonym PFAMTRFS_MOD
/
create table CUST_PPF_ACCOUNT_TRFS_MOD
(
	SOL_ID 								varchar(8),
	FORACID								varchar(16),
	ACCT_OPEN_DATE						DATE,
	MATURITY_DATE						DATE,
	ACCT_TRANSFER_DATE            DATE,
	FINANCIAL_YEAR_END            DATE,
	CURRENT_FY_SUM_DEPOSIT 			number (20,4),
	TOT_PRINCIPAL_CREDIT          number (20,4),
	TOT_INTEREST_CREDIT           number (20,4),
	MIN_BAL				number (20,4),
	TRANSFER_REMARKS					varchar(250),
	TRFS_MODE_FLG            	   CHAR(1),
	FY_TOT_PRICIPAL_CREDIT			number (20,4),
	FY_TOT_INTEREST_CREDIT			number (20,4),
	FY_TOT_CREDIT_AMT					number (20,4),
	TOT_INTEREST_ACCRUED				number (20,4),
	CREDIT_TRAN_COUNT					number (20),
	DEBIT_TRAN_COUNT				   number (20),
	CURRENT_FY_WITHDRAW_AMT			number (20,4),
	LAST_PPF_STATUS_CHANGE_DATE 	DATE,
	PPF_STATUS							char(1),
	TOTAL_FINE_DUE 					number (20,4),
	TOTAL_ARREARS 						number (20,4),
	entity_cre_flg  					char(1),
	LCHG_USER_ID    					VARCHAR2(15),
	LCHG_TIME       					date,
	RCRE_USER_ID    					VARCHAR2(15),
	RCRE_TIME       					date,
   DEL_FLG         					CHAR(1)
)
/
create public synonym PFAMTRFS_MOD for CUST_PPF_ACCOUNT_TRFS_MOD
/
grant select,insert,update,delete on PFAMTRFS_MOD to tbagen
/
grant select on PFAMTRFS_MOD to tbacust
/
grant select on PFAMTRFS_MOD to tbautil
/
