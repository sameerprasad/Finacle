host \rm -f FEECL*lst 2>/dev/null
set pagesize 80
set numformat 99,99,99,99,999.99
set feedback off
column DC new_value dcalias
select dc_alias DC from gct;
column D new_value dt
select db_stat_date D from gct;
spool fee1week1
set head off
set linesize 500
set trims on
set verify off
select 'SUM OF TRAN_AMT FOR FM AND FU ZONES FOR LAST FEW DAYS' from dual;
select sol_id,clg_zone_date,clg_zone_code, sum(tran_amt) 
from ocp,gam
where gam.acid=ocp.acid
and ocp.del_flg!='Y'
and gam.foracid in ('0036SLFEECOL','6235SLFEECOL')
and ocp.clg_zone_date between sysdate - 10 and sysdate
and ocp.clg_zone_code='FM'
and status_flg='G'
and shd_bal_rem_amt=0
group by sol_id,clg_zone_date,clg_zone_code
/
select sol_id,clg_zone_date,clg_zone_code, sum(tran_amt) 
from ocp,gam
where gam.acid=ocp.acid
and ocp.del_flg!='Y'
and gam.foracid in ('0036SLFEECOL','6235SLFEECOL')
and ocp.clg_zone_date between sysdate - 10 and sysdate
and ocp.clg_zone_code='FU'
and status_flg='G'
and shd_bal_rem_amt=0
group by sol_id,clg_zone_date,clg_zone_code
/
spool off
host chmod 777 fee1week1.lst
host sort -t ":" -k 4 fee1week1.lst > fee1week.lst
host cp fee1week.lst FEE1WEEK&dcalias&dt..lst 2>/dev/null
host chmod 777 FEE1WEEK*.lst
host mutt -a FEE1WEEK&dcalias&dt..lst -s "FEE COLL CLG-HISTORY" ctu@icicibank.com < FEE1WEEK&dcalias&dt..lst
