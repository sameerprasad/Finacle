set serveroutput on size &900000
set feedback off
set verify off
set linesize 500
set pages 0
set trims on
set termout off
set numformat &8&8&8D0&8
spool &3
select Rownum||','||a.CHEQUE_DEP_DATE||','||a.realisation_date||','||a.sol_id||','||decode(b.tax_type,'C','0004','0005')||','||a.zone_code||','||a.zone_date||','||a.set_num||','||c.INSTRMNT_ID||','||c.STATUS_FLG||','||a.challan_amount||','||a.tax_tran_id||','||a.major_tax_head
from ici_gbm_challan_master a,icici_gbm_trn_hdr b,ocp c
where c.sol_id = a.sol_id and c.CLG_ZONE_DATE = a.ZONE_DATE and c.CLG_ZONE_CODE = a.ZONE_CODE and c.SET_NUM = a.SET_NUM and c.PART_TRAN_SRL_NUM = a.PART_TRAN_SRL_NUM and b.tax_tran_id = a.tax_tran_id and b.tax_tran_date = a.tax_tran_date and b.tax_tran_type='L' and a.DEL_FLG = 'N' 
and c.CLG_ZONE_DATE between '&4' and '&5'
and a.realisation_date between '&1' and '&6'
and a.tran_date between '&7' and '&8'
and c.CLG_ZONE_CODE = '&9'
and b.tax_type='&10' 
and a.sol_id in (select distinct sol_id from ici_gbm_terminal_master where parent_sol_id='&2')
/
spool off
