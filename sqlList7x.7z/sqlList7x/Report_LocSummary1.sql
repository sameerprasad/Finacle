-------------------------------------------------------------------------
--Author    :    BBSSL
--Date      :    08-Aug-2012
--Desc      :  	 Locker Status Report  
--File Name :    Report_LocSummary1..sql
--------------------------------------------------------------------------
set serveroutput on size 1000000
set lines 2000 
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_LocSummary1.lst 

Declare
v_sol_id    	wlckm.sol_id%type:='&1';
v_rack_id       varchar2(15);	
v_locker_type   wlckm.locker_type%type;
v_locker_count  number;



cursor t2 is
			select a.rack_id,a.locker_type,count(1)
			from wlckm a
			where a.sol_id = v_sol_id
			and a.del_flg = 'N'
			group by a.sol_id,a.rack_id,a.locker_type order by a.sol_id,a.rack_id,a.locker_type;
begin
open t2;
loop
--{
    fetch t2 into v_rack_id,v_locker_type,v_locker_count;

	if t2%NOTFOUND then
	--{
    	close t2;
    	exit;
	--}
	end if;


			dbms_output.enable(buffer_size => NULL);
			dbms_output.put_line(v_rack_id      ||'|'||
                     		 v_locker_type      ||'|'||
                     		 v_locker_count);    

--}
end loop;
end;
/
spool off

