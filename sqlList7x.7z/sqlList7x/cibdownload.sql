set head off
set verify off
set feedback off
set trimspool on
set pages 0
set termout off
spool cib&1..lst
select
	'|'||
	trim(cust_id)||
	'|'||
	'|'||
	'<GRP>'||
	'|'||
	trim(cust_id)||
	'|'||
	trim(cust_id)||
	'|'||
	'<CUST>'||
	'|'||
	'&3/'||
	trim(cust_id)||
	'|'||
	'<USR>'||
	'|'||
	'USER1'||
	'|'||
	'USER1'||
	'|'||
	'|'||
	'.'||
	'|'
from gam where sol_id= '&1'
and schm_code = 'CAKIT'
and acct_opn_date = '&2'
and acct_name = '* * *'
and del_flg!='Y'
and entity_cre_flg='Y'
/
spool off
exit
