accept dt prompt "Enter the value of date in DD-MM-YYYY format:"

set verify off head off feedback off trims on pages 0
set numformat 99,99,99,99,99,99,999.99
set colsep '|'
column sol_schm format A9

spool /temp/ibr_reconciliation/eab.bby.lst

select concat(sol_id,rpad(decode(schm_code,'ANWCD','!','ANWFT','!','ANWCW','!',schm_code),5)) sol_schm ,sum(tran_date_tot_tran) TOT_TRAN
from gam,eab
where gam.acid=eab.acid 
and acct_cls_flg!='Y'
and (gam.schm_type = 'HOC' or schm_code in ('ANWFT','ANWCD', 'ANWCW','DDGEN'))
and trunc(eod_date)=trunc(to_date('&dt'))
group by sol_id,decode(schm_code,'ANWCD','!','ANWFT','!','ANWCW','!',schm_code)
/
spool off

