alter session set nls_date_format='ddmmyyyy';
accept dt prompt "ENTER DATE FOR WHICH REPORT REQUIRED (DDMMYYYY)::"
set echo off
set pages 0
set verify off
set feedback off
set trimspool on
set head off
set termout off
spool fpfdexad
select sol_id||'/'||tran_Date||'/'||org_Tran_amt||'/'||tran_particular
from ott
where acid in  (select acid from gam where foracid like '%FPFDEXAD')
and total_offset_amt != org_tran_amt
and del_flg !='Y'
and tran_date='&dt'
/
spool off
exit
