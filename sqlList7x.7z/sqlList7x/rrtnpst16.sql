rem:  S. Gopalan  Date:  17-july-1998
rem:  To enable branches to build ib/mirror acct in EXCEL 
alter session set nls_date_format='dd-mon-yyyy';
accept dt1 prompt  "ENTER  START DATE OF REPORT (dd-mon-yyyy):::"
accept dt2 prompt  "ENTER END DATE OF REPORT (dd-mon-yyyy):::"
set head off
set termout off
set verify off
set echo off
set feedback off
set numformat b999,99,99,999.99
set pagesize 500
set linesize 200
spool rrtnpst16.lst
select 'date|bill_num|crncy purchased|amt_purchsd|crncy_sold|amt_sold|remarks|INR equivalent| LC_num|Other Reference|Cust Rate|Base Rate|'  from dual;  

select pst_date||'|'||bill_ref_num||'|'||crncy_purchsd||'|'||amt_purchsd||'|'||crncy_sold||'|'||amt_sold||'|'||remarks||'|'||amt_home_crncy||'|'||lc_ref_num||'|'||ref_num||'|'||rate||'|'cust_rate
from pst
where pst_date between '&dt1' and '&dt2' 
/
spool off
exit
