set head off
set feedback off
set verify off
set linesize 5
set pagesi 0
spool solALL.txt
select sol_id from sol
order by sol_id
/
spool off
exit

