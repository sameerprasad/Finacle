set feedback off
set verify off
set linesize 80
spool icisystr.list
column tran_id heading 'TRAN_ID' 
column tran_date heading 'TRAN_DATE' 
column rcre_user_id heading 'USER_ID' 
select tran_id, tran_date,rcre_user_id from dtd where
dtd.tran_date = '&1'and dtd.del_flg <> 'Y' and
dtd.entry_user_id = 'SYSTEM' and
dtd.pstd_flg = 'N' and tran_id like '%'||(select dc_alias from gct)||'%' and
sol_id in (select sol_id from sst where set_id = '&2')
/
spool off
exit
