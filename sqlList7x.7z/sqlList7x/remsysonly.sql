set head off
set pages 0
spool systemonly
select foracid, system_only_acct_flg from gam where bacid in ('CHCOURFEX','CHP'||'&'||'TFEX','ICFBEXP','ICFBIMP','CNFBEXP','CNFBIMP','CNFWC','CNFX-OTHER');
update gam set system_only_acct_flg='' where bacid in ('CHCOURFEX','CHP'||'&'||'TFEX','ICFBEXP','ICFBIMP','CNFBEXP','CNFBIMP','CNFWC','CNFX-OTHER');
spool off
exit
