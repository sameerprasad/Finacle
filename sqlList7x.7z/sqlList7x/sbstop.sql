set echo off
set verify off
whenever sqlerror exit sql.sqlcode
set feedback off
set termout off
set linesize 132
set newpage 0
set pagesize 60

define all_dashes = '---------------------------------------------------------------------------------------------------------------------------------------------------'
column today new_value today_date
column solid new_value sol
select to_char(sysdate, 'dd/mm/yyyy') today
from   dual;

select br_name solid from bct where br_code=(select br_code from sol where sol_id='&1') and bank_code='ICI';
spool $ICICI_CUST_REP/sbstop.&1

ttitle center '  SB STOP PAYMENTS AS ON'   '  '  today_date -
right 'Page :       ' format 999 sql.pno skip 1 -
center      '----------------------------------------------' SKIP 1 -
center sol skip 1 -
right 'Date : ' today_date skip 2 -
left all_dashes
column foracid heading "Account No." format a16
column payee_name heading "Payee Name" format a12
column begin_chq_num heading "Begin No." format a8
column end_chq_num heading "End  No." format a8
column chq_date heading "Chq Dt." format a8
column chq_amt heading "Chq Amt." format 99,99,99,999.99
column Status format a6
break on rec_type skip page on report
COMPUTE SUM OF chq_amt ON rec_type report
 
select  gam.foracid 
		payee_name, 
		begin_chq_num, 
		end_chq_num, 
		to_char(chq_date,'DD-MM-YY') chq_date, 
		chq_amt, decode(rec_type, 'S', 'STOP', 'R','REVOKE', ' ') Status 
from gam, spt
where gam.schm_code in (select schm_code from gsp where schm_type = 'SBA')  
and spt.acid = gam.acid
and spt.entity_cre_flg = 'Y'
and spt.del_flg = 'N'
and gam.acct_cls_flg !='Y'
and gam.sol_id='&1'
order by rec_type, 1 ;

spool off
undefine all_dashes

whenever sqlerror continue 
set termout on
set feedback on
set verify on
set heading off
set echo on
exit
