rem this sql has been given to generate reminders to the customers
rem for expiring BGs
rem based on expiry date
rem written by shashi on 08-11-1999
rem written at bangalore branch
rem this can be taken at any time
rem the let file name is bgexp.let

set pause off
set wrap on
set head off
set verify off
set echo off
set termout off
set feedback off
set pagesize 1000
set linesize 500
set space 0
set heading off
alter session set nls_date_format = 'DD-MM-YYYY';

spool &1

select 	a.beneficiary_name||'|'||
	a.beneficiary_addr_1||'|'|| 
	NVL(a.beneficiary_addr_2,' ')||'|'|| 
        NVL(d.ref_desc, ' ')||'|'||
	NVL(a.pin_code, ' ')||'|'||
	a.crncy_code||'|'||
	ltrim(to_char(abs(a.bg_amt),'b99,99,99,999.99'))||'|'||
	a.claim_expiry_date||'|'||
	ltrim(a.bg_srl_num)||'|'||
	a.issue_date||'|'||
	b.cust_name||'|'||
	b.cust_comu_addr1||'|'||
	NVL(b.cust_comu_addr2,' ')||'|'||
	NVL(b.cust_comu_pin_code,' ') ||'|'||
	c.ref_desc||'|'
from 	bgm a, cmg b , rct c,rct d
where bg_status in ('A','E','O','D')
and claim_expiry_date between '&2' and '&3'
and b.cust_id = a.cust_id
and c.ref_rec_type||null = '01'
and c.ref_code||null = NVL(b.cust_comu_city_code,'*')
and d.ref_rec_type||null = '01'
and d.ref_code||null = NVL(a.city_code,'*')
and a.sol_id = '&4'
/
spool off
exit
