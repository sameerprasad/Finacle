---Sql to view the record for the given School Id
SET SERVEROUTPUT ON SIZE 1000000
set head off echo off verify off feedback off trims on 
	Declare
	failFlg		varchar2(5) := 'Y';	
	schlid		varchar2(16) := '&1';
	loc_school_id	school_acct_mast.school_id%type;
	loc_school_name	school_acct_mast.school_name%type;
	loc_sol_id		school_acct_mast.sol_id%type;
	loc_foracid		school_acct_mast.foracid%type;

Begin
		Begin
		--{
			Select school_id,
					school_name,
					sol_id,
					foracid,
					'N'
			  into loc_school_id,loc_school_name,loc_sol_id,loc_foracid,failFlg
   			  from school_acct_mast
			  where school_id = schlid
				and del_flg <> 'Y';
			Exception
			when no_data_found then
				failFlg := 'Y';
				loc_school_id := NULL;
				loc_school_name := NULL;
				loc_sol_id := NULL;
				loc_foracid := NULL;
		--}
		End;
		if failFlg = 'N' then
			dbms_output.put_line('School Id.   :    '|| loc_school_id);
			dbms_output.put_line('School Name. :    '|| loc_school_name);
			dbms_output.put_line('Sol Id.      :    '|| loc_sol_id);
			dbms_output.put_line('Account No   :    '|| loc_foracid);
		else
			dbms_output.put_line('No records found for '||schlid);
		end if;
--}
End;
/
