set serveroutput on size 1000000
set head off
set linesize 512
set trims on
set pages 0
set feedback off
set verify off
set termout off
spool &1-SAR

variable printIdType char(1);
variable printListId varchar2(20);

DECLARE
runId		varchar2(10);
solId		sol.sol_id%TYPE;
bankCode	sol.bank_code%TYPE;
brCode		sol.bank_code%TYPE;
brPrtcls	varchar2(200);

idTypeStr   VARCHAR2(200);
--idTypeArr   iciLongArray.arrayType;
idTypeArr   iciArray.arrayType;
idTypeCnt   NUMBER(5);
numCnt      NUMBER(5);
dcAlias     GCT.dc_alias%TYPE;
idType		char(1);
idTypeNew		char(2);

RESOURCE_BUSY   EXCEPTION;
PRAGMA EXCEPTION_INIT(RESOURCE_BUSY, -0054);

BEGIN
	runId := '&1';
	SELECT	home_sol_id
	INTO	solId
	FROM	ICICI_CIFT
	WHERE	cust_id = lpad('&2', 9);

	SELECT	bank_code,
			br_code
	INTO	bankCode,
			brCode
	FROM	SOL
	WHERE	sol_id = solId
	AND		del_flg !='Y';

	SELECT	br_name || '|' ||
			br_addr_1 || '|' ||
			br_addr_2 || '|' ||
			br_pin_code || '|' ||
			'CustomerStateMent'
	INTO	brPrtcls
	FROM	BCT  
	WHERE	bct.bank_code = bankCode  
	AND		bct.br_code= brCode;

	DBMS_OUTPUT.PUT_LINE(solId || '|         |00|0|' || brPrtcls);

	numCnt := 0;
	SELECT	dc_alias INTO dcAlias FROM GCT;

	BEGIN
		SELECT	1
		INTO	numCnt
		FROM	DUAL
		WHERE	EXISTS(	SELECT	*
						FROM	ICICI_LDTT
						WHERE	dc_alias = dcAlias
						AND		driver_id = 'FSG'
						AND		sol_id = solId);	
		EXCEPTION
		WHEN NO_DATA_FOUND THEN
			idTypeStr := '0|1|2|3|4|5|6|7|8|9';
	
			--iciLongArray.construct(idTypeCnt,  idTypeArr);
			iciArray.construct(idTypeStr, '|' , idTypeCnt,  idTypeArr);
			FOR item IN 0..TO_NUMBER(idTypeCnt - 1) LOOP
				INSERT
				INTO	ICICI_LDTT
				VALUES	(dcAlias, 'FSG', solId, item, '', 'F');
			END LOOP;
	END;

	BEGIN
		SELECT	ser_num
		INTO	idType
		FROM	ICICI_LDTT
		WHERE	dc_alias = dcAlias
		AND		driver_id = 'FSG'
		AND		sol_id = solId
		AND		remarks = 'F'
		AND		rownum = 1
		FOR	UPDATE NOWAIT;
	
		EXCEPTION
		WHEN NO_DATA_FOUND THEN
			DBMS_OUTPUT.PUT_LINE ('GFEM:Statement Generator is Busy. Try after some time.....');
		WHEN RESOURCE_BUSY THEN
			DBMS_OUTPUT.PUT_LINE ('GFEM:Statement Generator was Busy. Try once again.....');
		return;
	END;

	UPDATE	ICICI_LDTT
	SET		remarks = 'U'
	WHERE	dc_alias = dcAlias
	AND		driver_id = 'FSG'
	AND		sol_id = solId
	AND		ser_num	= idType;

	:printIdType := idType;
	idTypeNew := '0'||idType;
	:printListId := runId||solId||idTypeNew;

END;
/
spool off
spool fsgIdType.dat
set head off
set trims on
set termout off
print printIdType
spool off
spool listid.lst
set head off
set trims on
set termout off
print printListId
spool off
