Rem     This file will create CUSTOM_LOCKER_AUDIT_TABLE
Rem     with the following characteristics.

Rem     Coded by : Chandra Sekar (BBSSL)

Rem     Module  : LOCKER


Rem TABLE NAME: CUSTOM_LOCKER_AUDIT_TABLE

Rem SYNONYM:    CUSTOM_LOCKER_AUDIT_TABLE

drop table icici.CUSTOM_LOCKER_AUDIT_TABLE
/
drop public synonym C_LADT
/
create table icici.CUSTOM_LOCKER_AUDIT_TABLE
( 
	TABLE_NAME VARCHAR2(7),
	AUDIT_SOL_ID VARCHAR2(8),
	LOCKER_NUMBER VARCHAR2(12),
	ENTERER_ID VARCHAR2(15),
	AUTH_ID VARCHAR2(15),
	RMKS VARCHAR2(100),
	AUDIT_DATE DATE,
	MODIFIED_FIELDS_DATA VARCHAR2(2000),
	FUNC_CODE CHAR(1),
	INIT_SOL_ID VARCHAR2(8),
	AUDIT_BOD_DATE DATE
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
create public synonym C_LADT for icici.CUSTOM_LOCKER_AUDIT_TABLE
/
grant select, insert, update, delete on C_LADT to tbagen
/
grant select on C_LADT to tbacust
/
grant select on C_LADT to tbautil
/
grant all on C_LADT to tbaadm
/
