set echo off verify off feedback off pagesi 0 linesi 120 term off
set numformat 9999999999999.999
set serveroutput on size 1000000
spool &3.brexp2.dat

declare

cursor gamsel is
select acid,foracid,acct_name,gl_sub_head_code,acct_crncy_code,(clr_bal_amt + un_clr_bal_amt) acct_cls_bal from gam
where sol_id = '&1'
and   (gl_sub_head_code > '95000')
--and 	foracid = '0004IPFCTDUSD'
and substr(foracid,7,3) in ('&2')
and   acct_cls_flg = 'N'
and   del_flg = 'N';

acct_cls_bal eab.value_date_bal%type;
drbal eab.value_date_bal%type;
crbal eab.value_date_bal%type;
rdate gam.rcre_time%type;
expense eab.value_date_bal%type := 0;
income eab.value_date_bal%type := 0;

FUNCTION rate_code (crcd in gam.acct_crncy_code%type,frdt gam.rcre_time%type) return number
is

fx_rate rth.var_crncy_units%type := 0;
rdt rth.rtlist_date%type;
rsl rth.rtlist_num%type;

begin

	select max(rtlist_date) into rdt from rth where fxd_crncy_code = crcd and
	var_crncy_code = 'INR' and ratecode = 'NOR' and rtlist_date <= frdt;

	select max(rtlist_num) into rsl from rth where fxd_crncy_code = crcd and
	rtlist_date = rdt and var_crncy_code = 'INR' and ratecode = 'NOR';

	select nvl(var_crncy_units/fxd_crncy_units,1) into fx_rate from rth where
	fxd_crncy_code = crcd and var_crncy_code = 'INR' and ratecode = 'NOR' and
	rtlist_date = rdt and rtlist_num = rsl;

	return fx_rate;

exception

	when no_data_found then fx_rate := 1;
	return fx_rate;

END rate_code;

begin

select to_char(db_stat_date,'dd-mm-yyyy') into rdate from gct;

for i in gamsel
loop

	drbal := 0;
	crbal := 0;

	if ( i.acct_crncy_code != 'INR')
	then
--		dbms_output.put_line(i.acct_crncy_code||'|'||i.foracid||'|'||rate_code(i.acct_crncy_code,rdate));
		i.acct_cls_bal := i.acct_cls_bal * rate_code(i.acct_crncy_code,rdate);
	end if;
	
	if ( i.acct_cls_bal < 0 )
	then
		drbal := i.acct_cls_bal;
	else
		crbal := i.acct_cls_bal; 
	end if;

	if (substr(i.gl_sub_head_code,1,1) = '4')
	then
			income := income + i.acct_cls_bal;
        else
            expense := expense + i.acct_cls_bal;
    end if;


	dbms_output.put_line('&1'													||'|'||
						 rdate 														||'|'|| 
						 i.gl_sub_head_code										||'|'||
						 rpad(i.foracid,16)										||'|'|| 
						 rpad(i.acct_name,30)									||'|'||
						 to_char(drbal,99999999999.99)						||'|'||
						 to_char(crbal,99999999999.99));
						
end loop;
   dbms_output.put_line('&1'                     					  	||'|'||
                         rdate  					                    	||'|'||
                         '49999'											  	||'|'||
                         rpad('INCOME',16)							 	||'|'||
                         rpad('INCOME',30)        						||'|'||
                         lpad('0.00',15)          						||'|'||
                         to_char(income,99999999999.99));

   dbms_output.put_line('&1'                       					||'|'||
                         rdate                      					||'|'||
                         '95999'         									||'|'||
                         rpad('EXPENSE',16)          					||'|'||
                         rpad('EXPENSE',30)       						||'|'||
                         lpad('0.00',15)          						||'|'||
                         to_char(expense,99999999999.99));


end;
/
