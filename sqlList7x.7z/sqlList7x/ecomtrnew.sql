set serveroutput on size 1000000 
set feedback off 
set verify off
set linesize 500
set trims on
spool dtd_tran2_&1..lst
DECLARE
tranRmks                           dtd.tran_rmks%TYPE;
part_tran_type                      dtd.part_tran_type%TYPE;
partTranType                      dtd.part_tran_type%TYPE;
tranDate                          dtd.tran_date%TYPE;
tran_date                          dtd.tran_date%TYPE;
value_date                          dtd.value_date%TYPE;
valueDate                          dtd.value_date%TYPE;
tran_id                             dtd.tran_id%TYPE;
tranId                             dtd.tran_id%TYPE;
tranParticular                     dtd.tran_particular%TYPE;
tran_particular                     dtd.tran_particular%TYPE;
tran_amt                            dtd.tran_amt%TYPE;
tranAmt                            dtd.tran_amt%TYPE;
gamAcid                                dtd.acid%TYPE;
del_flg                             dtd.del_flg%TYPE;
refNum                              dtd.ref_num%TYPE;
vfdUserId                         dtd.vfd_user_id%TYPE;
code                                varchar2(20);
foracd                              gam.foracid%type;
acctType                            varchar2(20);
cnt				number:=0;

CURSOR	tst_dtd IS 
SELECT  tran_id,
		part_tran_type,
        tran_amt
FROM	DTD 
WHERE   acid in (SELECT acid FROM gam WHERE foracid like '&1'||'SLECMTR%');

BEGIN --{

	FOR tst_dtd_rec in tst_dtd 
	LOOP --{
	begin
        -- select '&1'||'SLECOMTR'
		-- into acctType
        -- from dual;
        select acid,
			tran_date,
			value_date,
			tran_id,
			tran_amt,
			part_tran_type,
			tran_particular,
			ref_num,
			vfd_user_id
        into gamAcid,
			tranDate,
			valueDate,
			tranId,
			tranAmt,
			partTranType,
			tranParticular,
			refNum,
			vfdUserId
  		from dtd
        where tran_date = (select db_stat_date from gct) 
		and tran_id = tst_dtd_rec.tran_id 
		and part_tran_type != tst_dtd_rec.part_tran_type
		and del_flg != 'Y';

	--select foracid into foracd from gam where acid = gamAcid;
        --if(foracd = acctType) then
        --     exit;
        --end if;

	select count(*) into cnt from gam where acid = gamAcid 
           and foracid in ('0018SLECMTR0', '0018SLECMTR1', '0018SLECMTR2', '0018SLECMTR3',
		               '0018SLECMTR4', '0018SLECMTR5', '0018SLECMTR6', '0018SLECMTR7',
                               '0018SLECMTR8', '0018SLECMTR9')
	if (cnt > 0) Then
            exit;
        end if;

		dbms_output.put_line('&1'||'|'||tranDate||'|'||valueDate||'|'||tranId||'|'||tranAmt||'|'||partTranType||'|'||substr(tranParticular,1,26)||'|'||substr(refNum,1,15)||'|'||vfdUserId||'|'||foracd);
		exception when OTHERS then NULL;
---			dbms_output.put_line ('sqlcode' || sqlcode);
	END;
	END LOOP; 
END;  
/
spool off
quit
