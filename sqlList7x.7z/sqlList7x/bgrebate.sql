ACCEPT dt PROMPT 'ENTER REPORT DATE IN DD-MM-YYYY FORMAT  : '
rem AUTHOR :: G.S.Saini, I.T. Deptt.            DATE  ::22-Mar-96
rem This sql gives the rebate on Banj Guarantees Calculated for
rem the remaining period.
rem This has been modified for the new version (1.6.36.10)
rem by shashi on 26-5-1999
accept solid prompt 'ENTER THE SOL_ID OF YOUR BRANCH : '

set echo off 
set termout off
set pause off
set verify off
whenever sqlerror exit sql.sqlcode
set feedback off
set linesize 132
set pagesize 66
set wrap off
set space 1
alter session set nls_date_format='DD-MM-YYYY';


define all_dashes = '-----------------------------------------------------------------------------'
column today new_value today_date
select to_char(sysdate, 'dd/mm/yyyy') today
from   dual;
column br_name new_value br
select ltrim(rtrim(sol_desc)) br_name from sol where extn_cntr_code='00'
/
column a heading 'Gtee No.' format a12
column b heading 'Effective|Date' format a12
column c heading 'Claim Exp|Date' format a12
column d heading 'Total No.|Of Months' format 99,99,999
column e heading 'Remaining|Months' format 99,99,990
column f heading 'Commission|Collected' format 9,99,99,990
column g heading 'Commission For|Remaining Perd' format 9,99,99,990
column h heading 'BG Amount' format 9,99,99,99,999.99
break on report
compute sum of f on report
compute sum of g on report
compute sum of h on report
spool bgrebate

ttitle center 'ICICI BANK LIMITED' skip 1 -
center br  skip 1 -
center 'REPORT OF PROPORTIONATE COMMISSION FOR THE PERIOD BEYOND ' &dt SKIP 1 -
center 'FOR GUARANTEES EXCEEDING 18 MONTHS' -
right 'PAGE :   ' format 9999 sql.pno  skip 1 -
right 'DATE :   ' today_date skip 2 -

select bg_srl_num a, effective_date b, claim_expiry_date c, 
ceil(months_between((to_date(claim_expiry_date,'DD-MM-YYYY')+1),to_date(effective_date))) d,
floor(months_between((to_date(claim_expiry_date,'DD-MM-YYYY')+1),to_date('&dt'))) e, commn_amt f, 
commn_amt*ceil(months_between((to_date(claim_expiry_date,'DD-MM-YYYY')+1),to_date('&dt')))/floor(months_between((to_date(claim_expiry_date,'DD-MM-YYYY')+1),to_date(effective_date))) g, bg_amt h  from bgm
where
bg_status in ('A','E','G','O') and 
ceil(months_between((claim_expiry_date+1),effective_date))>18 and
claim_expiry_date>'&dt' and
effective_date<='&dt'
and crncy_code = 'INR'
union
select bg_srl_num a, effective_date b, claim_expiry_date c, 
ceil(months_between((to_date(claim_expiry_date,'DD-MM-YYYY')+1),to_date(effective_date))) d,
floor(months_between((to_date(claim_expiry_date,'DD-MM-YYYY')+1),to_date('&dt'))) e, commn_amt f, 
commn_amt*ceil(months_between((to_date(claim_expiry_date,'DD-MM-YYYY')+1),to_date('&dt')))/floor(months_between((to_date(claim_expiry_date,'DD-MM-YYYY')+1),to_date(effective_date))) g, (round(bg_amt*rate,2)) h  from bgm
where
bg_status in ('A','E','G','O') and 
ceil(months_between((claim_expiry_date+1),effective_date))>18 and
claim_expiry_date>'&dt' and
effective_date<='&dt'
and crncy_code != 'INR'
order by 2
/
ttitle off
ttitle center 'REPORT OF PROPORTIONATE COMMISSION FOR THE PERIOD BEYOND ' &dt SKIP 1 -
center 'FOR GUARANTEES UPTO 18 MONTHS' 
select bg_srl_num a, effective_date b, claim_expiry_date c, 
ceil(months_between((to_date(claim_expiry_date,'DD-MM-YYYY')+1),to_date(effective_date))) d,
floor(months_between((to_date(claim_expiry_date,'DD-MM-YYYY')+1),to_date('&dt'))) e, commn_amt f, 
commn_amt*ceil(months_between((to_date(claim_expiry_date,'DD-MM-YYYY')+1),to_date('&dt')))/floor(months_between((to_date(claim_expiry_date,'DD-MM-YYYY')+1),to_date(effective_date))) g,bg_amt h from bgm
where
bg_status in ('A','E','G','O') and 
ceil(months_between((claim_expiry_date+1),effective_date))<=18 and
claim_expiry_date>'&dt' and
effective_date<='&dt'
and crncy_code = 'INR'
union
select bg_srl_num a, effective_date b, claim_expiry_date c, 
ceil(months_between((to_date(claim_expiry_date,'DD-MM-YYYY')+1),to_date(effective_date))) d,
floor(months_between((to_date(claim_expiry_date,'DD-MM-YYYY')+1),to_date('&dt'))) e, commn_amt f, 
commn_amt*ceil(months_between((to_date(claim_expiry_date,'DD-MM-YYYY')+1),to_date('&dt')))/floor(months_between((to_date(claim_expiry_date,'DD-MM-YYYY')+1),to_date(effective_date))) g, (round(bg_amt*rate,2)) h  from bgm
where
bg_status in ('A','E','G','O') and 
ceil(months_between((claim_expiry_date+1),effective_date))<=18 and
claim_expiry_date>'&dt' and
effective_date<='&dt'
and crncy_code != 'INR'
order by 2
/
spool off
whenever sqlerror continue 
set termout on
undefine all_dashes
set feedback on
set verify on
set heading on
clear breaks
set echo on
exit
