set echo off 
set pause off
set pagesize 1000
rem Script For Generating Letters to Customers for whom there are bills
rem lodged in the ABLC register for intimating and asking payment.
rem  author::  GOPAL, IT dept., Bombay
rem modified by shashi for 1.6.36 vesion
rem This script can be run at any time During the Day.
set verify off
set wrap on
set feedback off
set linesize 500
set space 0
set termout off
set heading off
alter session set nls_date_format = 'DD-MM-YYYY';
column bill_amt justify right format  b9999,99,99,999.99 
column other_bank_chrg justify right format b9999,99,99,999.99 
spool &1
select	y.cust_title_code,'|',
	y.cust_name,'|',
	y.cust_comu_addr1,'|',
	y.cust_comu_addr2,'|',
	b.ref_desc,'|',
	c.ref_desc,'|',
	d.ref_desc,'|',
	y.cust_comu_pin_code,'|',
        fbm.sol_id,'|',
	decode(y.cust_title_code, 'M/S', 'Sirs','Sirs'),'|',
        fbm.bill_id,'|',
        bill_crncy_code,'|',
        ltrim(bill_amt),'|',
        lodg_date,'|',
        fbm.due_date,'|',
        ltrim(fbm.other_bank_chrg), '|', 
        fei.lc_number,'|'  
from	cmg y, rct b, rct c, rct d, fpc, fbm, fei
where	y.entity_cre_flg = 'Y'
and	y.del_flg != 'Y'
and	b.ref_rec_type = '01'
and	b.ref_code = y.cust_comu_city_code
and	b.del_flg != 'Y'
and	c.ref_rec_type = '02'
and	c.ref_code = y.cust_comu_state_code
and	c.del_flg != 'Y'
and	d.ref_rec_type = '03'
and	d.ref_code = y.cust_comu_cntry_code
and	d.del_flg != 'Y'
and     y.cust_id  = fpc.party_code
and     fpc.party_code = fbm.party_code
and     fbm.del_flg !='Y'
and     fbm.reg_type ='ABLC'
and     fbm.bill_stat in ('G','P') 
and     fbm.due_date >= '&2'
and     fbm.due_date <= '&3'
and     fbm.bill_id =fei.bill_id
and 	fbm.sol_id = '&4'
and     fei.sol_id = '&4'
and     fbm.sol_id = fei.sol_id
/
spool off
exit
