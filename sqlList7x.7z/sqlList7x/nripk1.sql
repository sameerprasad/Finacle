rem   Script for creating data file FOR  cover page for NRI packs
rem   for a given account number
rem        Input parameters in command line
rem     
rem        Tables accessed: CMG, GAM, RCT
rem        Author P Srinivas Rao
rem
rem        This is the version for GPLG 
rem 
rem     Parameters :-
rem     1 - spool file name (populated by GPLG)
rem     2 - account number
rem
rem	*******************************************************
rem !getNRIPackFile.com
set echo off
set termout off
set pause off
set feedback off
set verify off
whenever sqlerror exit sql.sqlcode
set linesize 500
set trims on
set pagesize 0
set heading off
set space 0
--
spool tmpNri.com
select 'getNRIPackFile.com &2' from dual;
spool off
--
!ksh tmpNri.com
--
SPOOL  &1
--
start nritemp.sql
--
spool off
ttitle off
btitle off
whenever sqlerror continue
set termout on
set feedback on
set verify on
set heading on
clear breaks 
set echo on
! rm nritemp.sql
exit
