SET HEAD OFF
SET VERIFY OFF
SET FEEDBACK OFf
DECLARE

gctdate gct.db_stat_date%type;
gctday VARCHAR2(3) ;
stlim NUMBER := 20 ;
enlim NUMBER ;
tacid tam.acid%type;
depprdmths tam.deposit_period_mths%type;
depprddays tam.deposit_period_days%type;
valuedate tam.open_Effective_date%type;
matdate tam.maturity_Date%type;
principal tam.deposit_amount%type;
matamt tam.maturity_amount%type;
safecust tam.safe_custody_flg%type;
autoren tam.auto_renewal_flg%type;
autoclose tam.close_on_maturity_flg%type;
acctnum gam.foracid%type;
acctclsflg gam.acct_cls_flg%type;
gcustid gam.cust_id%type;
opndate gam.acct_opn_date%type;
clrbal gam.clr_bal_amt%type;
schm gam.schm_code%type;
crncy gam.acct_crncy_code%type;
solid gam.sol_id%type;
title cmg.cust_title_code%type;
name cmg.cust_name%type;
addr1 cmg.cust_comu_addr1%type;
addr2 cmg.cust_comu_addr2%type;
citycode cmg.cust_comu_city_code%type;
statecode cmg.cust_comu_state_code%type;
pin cmg.cust_comu_pin_code%type;
cntrycode cmg.cust_comu_cntry_code%type;
city rct.ref_desc%TYPE;
state rct.ref_desc%TYPE;
country rct.ref_desc%TYPE;
soldesc sol.sol_Desc%type;
soladdr1 sol.addr_1%type;
soladdr2 sol.addr_2%type;
solstate sol.state_code%type;
solcity sol.city_code%type;
solpin sol.pin_code%type;
solstatedesc rct.ref_desc%TYPE;
solcitydesc rct.ref_desc%TYPE;
mob_num         ICICI_ALERT_REG.MODE_ID%TYPE;
e_mail          CMG.EMAIL_ID%TYPE;
cust_const      CMG.cust_const%type;
prn_flg	varchar2(1);

loc_fp utl_file.file_type;
loc_filename                    varchar2(200);
loc_filepath                    varchar2(100);
loc_filemode                    varchar(10);

cursor gctcur is
select db_stat_date, TO_CHAR(db_stat_date,'DY') from gct;

cursor tamcur is
select acid, DEPOSIT_PERIOD_MTHS,DEPOSIT_PERIOD_DAYS, OPEN_EFFECTIVE_DATE, MATURITY_DATE, DEPOSIT_AMOUNT,  MATURITY_AMOUNT, SAFE_CUSTODY_FLG,  AUTO_RENEWAL_FLG, CLOSE_ON_MATURITY_FLG from tam
where (maturity_date >= (gctdate + stlim) and maturity_date <= (gctdate + enlim))
and safe_custody_flg='N' and printing_flg='Y' and auto_renewal_flg='N' 
order by maturity_date;

cursor gamcur is
select sol_id,foracid , cust_id,clr_bal_amt, acct_opn_date, acct_cls_flg,schm_code, acct_crncy_code from gam where gam.acid=tacid ;
cursor solcur is
select sol_desc,addr_1, addr_2,city_code, state_code, pin_code from sol where sol.sol_id=solid;

cursor cmgcur is
select cust_title_code,cust_name,CUST_COMU_ADDR1,CUST_COMU_ADDR2,CUST_COMU_CITY_CODE,CUST_COMU_STATE_CODE,CUST_COMU_PIN_CODE,CUST_COMU_CNTRY_CODE,EMAIL_ID,cust_const from cmg where cmg.cust_id=gcustid;

cursor  icialert is
select MODE_ID  FROM ICICI_ALERT_REG where FORACID = acctnum AND  MODE_OF_DELIVERY = '0';

BEGIN

begin
open gctcur;
fetch gctcur into gctdate, gctday;
close gctcur;
end;

IF gctday = 'SAT' THEN
	enlim := 21 ;
ELSE
	enlim := 20 ;
END IF ;

		loc_filepath := '/tmp';
        loc_filename := 'duenew.lst';
        loc_filemode := 'w';
        loc_fp := utl_file.fopen(loc_filepath, loc_filename, loc_filemode);


open tamcur;
begin
loop
fetch tamcur into tacid,depprdmths, depprddays, valuedate, matdate, principal, matamt,safecust, autoren, autoclose;
exit when tamcur%notfound;

begin
open gamcur;
fetch gamcur into solid,acctnum, gcustid, clrbal,opndate,acctclsflg,schm, crncy;
close gamcur;
end;
begin
open solcur;
fetch solcur into soldesc, soladdr1,soladdr2, solcity, solstate, solpin;
close solcur;
end;
begin
open cmgcur;
fetch cmgcur into title, name, addr1, addr2,citycode, statecode, pin, cntrycode, e_mail,cust_const;
close cmgcur;
end;
open icialert;
fetch icialert into mob_num;
close icialert;

BEGIN
select decode(ref_desc,NULL,' ',ref_desc) into city
from rct
    where ref_rec_type = '01'
    and ref_code = citycode;
EXCEPTION
WHEN no_data_found then
city := 'city ERROR';
END;

BEGIN
select decode(ref_desc,NULL,' ',ref_desc) into state
from rct
where ref_rec_type = '02'
and ref_code = statecode;
EXCEPTION
WHEN no_data_found then
    state := 'state ERROR';
END;

BEGIN
select decode(ref_desc,NULL,' ',ref_desc) into solcitydesc
from rct
    where ref_rec_type = '01'
    and ref_code = solcity;
EXCEPTION
WHEN no_data_found then
solcitydesc := 'city ERROR';
END;

BEGIN
select decode(ref_desc,NULL,' ',ref_desc) into solstatedesc
from rct
where ref_rec_type = '02'
and ref_code = solstate;
EXCEPTION
WHEN no_data_found then
solstatedesc:= 'state ERROR';
END;
BEGIN
select decode(ref_desc,NULL,' ',ref_desc) into country
from rct  where ref_rec_type = '03' and ref_code = cntrycode;
EXCEPTION
WHEN no_data_found then
state := 'country ERROR';
END;

if ( acctclsflg !='Y') then prn_flg :='Y'; else prn_flg :='N'; end if;

if ((prn_flg ='Y' ) and (mob_num is null)) then prn_flg :='Y'; else prn_flg :='N'; end if;

#if ((prn_flg ='Y' ) and (e_mail is  null)) then prn_flg :='Y'; else prn_flg :='N'; end if;

if ((prn_flg ='Y' ) and (cust_const !='R1') and (mob_num is not null)) then prn_flg :='Y'; else prn_flg :='N'; end if;

if ((prn_flg ='Y' ) ) then

UTL_FILE.PUT_LINE(loc_fp,solid||'|'||acctnum||'|'||gcustid||'|'||name||'|'||depprdmths||'/'||depprddays||'|'||valuedate||'|'||matdate||'|'||opndate||'|'||principal||'|'||matamt||'|'||safecust||'|'||autoren||'|'||autoclose||'|'||clrbal||'|'||schm||'|'||crncy||'|'||title||'|'||addr1||'|'||addr2||'|'||city||'|'||pin||'|'||state||'|'||country||'|'||gctdate||'|'||soldesc||'|'||soladdr1||'|'||soladdr2||'|'||solcitydesc||'|'||solstatedesc||'|'||solpin);

end if;

end loop;
end;
close tamcur;
END;
/
exit

