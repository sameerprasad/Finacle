drop table NOM_NAME_PRNT_ADT
/
drop public synonym NOM_NAME_PRNT_ADT
/
commit
/
create table TBAPSG.NOM_NAME_PRNT_ADT
(
    FORACID               VARCHAR2(16 BYTE),
    SOL_ID                VARCHAR2(8 BYTE),
	NOM_PRINT_FLAG		VARCHAR2(1 BYTE),
	MODIFIED_FIELDS_DATA	VARCHAR2(200 BYTE),
	AUTH_ID			VARCHAR2(15 BYTE),
    RCRE_TIME             DATE,
    RCRE_USER_ID          VARCHAR2(15 BYTE),
    LCHG_TIME             DATE,
    LCHG_USER_ID          VARCHAR2(15 BYTE)
)
/
create public synonym NOM_NAME_PRNT_ADT for TBAPSG.NOM_NAME_PRNT_ADT
/
commit
/
drop index IDX_NMNE_NAME_ADT_FORACID
/
create index IDX_NMNE_NAME_ADT_FORACID on NOM_NAME_PRNT_ADT(FORACID)

/
drop index IDX_NMNE_NAME_ADT_SOL
/
create index IDX_NMNE_NAME_ADT_SOL 
on NOM_NAME_PRNT_ADT(SOL_ID)

/
drop index IDX_NMNE_NAME_ADT_COMBINED
/
create index IDX_NMNE_NAME_ADT_COMBINED  on NOM_NAME_PRNT_ADT( FORACID,SOL_ID,NOM_NAME)

/
grant select, insert, update, delete on NOM_NAME_PRNT_ADT to tbagen,tbacust,custom,tbautil,tbaadm
/
grant select on TBAPSG.NOM_NAME_PRNT_ADT to tbacust,tbautil,custom
/
grant select on TBAPSG.NOM_NAME_PRNT_ADT to tbagen
/
commit;
/
