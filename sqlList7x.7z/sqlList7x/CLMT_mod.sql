REM####################################################################
REM File Name   : CLMT_MOD.sql
REM Description : Table creation for custom locker master Mod table
REM Author      : Prabhu.B (BBSSL)
REM Date        : 22-09-2008
REM Module	: LOCKER
REM####################################################################
drop table icici.cust_locker_master_mod_table
/
drop public synonym CLMT_MOD
/
create table icici.cust_locker_master_mod_table
(
	sol_id 		varchar(8),
	cust_id		varchar(9),
	locker_type	varchar(5),
	locker_num	varchar(12),
	locker_size	varchar2(11),
	oper_acnt	varchar(16),
	dep_acnt	varchar(16),
	staff_flg	char(1),
	issue_date	date,
	rent_amt	number (20,4),
	locker_key_num	varchar(8),
	operation_mode	varchar(5),
	locker_period	number(3),
	intr_acnt_id	varchar(16),
	due_date	date,
	discount_flg    char(1),
	disc_rent_amt   number (20,4),
	del_flg         char(1),
	entity_cre_flg  char(1),
	LCHG_USER_ID    VARCHAR2(15),
	LCHG_TIME       date,
	RCRE_USER_ID    VARCHAR2(15),
	RCRE_TIME       date,
	remarks         VARCHAR2(40),
	contract_no     VARCHAR2(20),
	staff_discount_flg char(1),
	renewal_date	date,
	NO_HIRER        number(3)
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE ACCT_DETAILS_2_SMALL
/* STORE_END */
/
create public synonym CLMT_MOD for icici.cust_locker_master_mod_table
/
grant select,insert,update,delete on CLMT_MOD to tbagen
/
grant all on CLMT_MOD to tbaadm
/
grant select on CLMT_MOD to tbacust
/
grant select on CLMT_MOD to tbautil
/
