set pages 0 feedback off echo off verify off trimspool on lin 1000
spool nameMatchInput_&1
select BENF_ACCT_NO||'|'||AMOUNT||'|'||BENF_NAME||'|'||ICORE_NAM||'|'||c.CUST_TITLE_CODE||'|'||
decode(g.schm_type,'SBA','Saving','CAA','Current','TDA','Deposit','ODA','Advance') ||'|'||'111'
from icici_neft i, gam g, cmg c where FILE_NAM ='&1' 
and FRESH_RETURN_FLG ='Fresh' and g.cust_id=c.cust_id and i.BENF_ACCT_NO=g.foracid and TRAN_STATUS is null
and AMOUNT>=5001
/
spool off
