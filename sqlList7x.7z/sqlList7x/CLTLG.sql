REM####################################################################
REM File Name   : CLTLG.sql
REM Description : Table creation for custom Locker Transaction Legder table
REM Author      : Prabhu.B (BBSSL)
REM Date        : 11-05-2010
Rem     Module  : LOCKER
REM####################################################################
drop table icici.cust_locker_tran_ledger
/
drop public synonym CLTLG
/
create table icici.cust_locker_tran_ledger
(
	sol_id 		varchar(8),
	cust_id		varchar(9),
	locker_num	varchar(12),
	PARTICULARS	varchar2(500),
	APPLICABLE_DATE	DATE,
	AMOUNT		NUMBER(20,4),
	RCRE_USER_ID    VARCHAR2(15),
	RCRE_TIME       date,
	del_flg         char(1),
	part_tran_type	char(1)
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
CREATE INDEX IDX_cust_locker_tran_ledger ON ICICI.cust_locker_tran_ledger(SOL_ID,locker_num,cust_id)
/
CREATE INDEX IDX_cust_locker_tran_date ON ICICI.cust_locker_tran_ledger(locker_num,APPLICABLE_DATE)
/
create public synonym CLTLG for icici.cust_locker_tran_ledger
/
grant select,insert,update,delete on CLTLG to tbagen
/
grant select on CLTLG to tbacust
/
grant all on CLTLG to tbaadm
/
grant select on CLTLG to tbautil
/
