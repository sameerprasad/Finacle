Rem ScriptName: mandatedtls.sql
Rem SQL called from ICIRSQLS to display details of mandate details for particular date
Rem Author : Soundaram - ICI6150

set serveroutput on size 1000000
set feedback off
set verify off
set linesize 500
set trims on
set termout off

spool mandatedtls

declare

   date1 icici_mandate_holder.lchg_time%type;

   cursor mandate is
          select a.FORACID_NRI,
                 b.CUST_ID,
                 b.ACCT_NAME,
                 a.CUST_ID_MANDATE_HOLDER,
                 c.CUST_NAME,
                 a.RCRE_USER,
                 a.RCRE_TIME,
                 a.MANDATE_TYPE,
                 d.EMAIL_ID
          from  icici_mandate_holder a,gam b,cmg c,icici_cift d 
          where to_char(a.lchg_time)='&1' and
                a.foracid_nri=b.foracid and
                a.cust_id_mandate_holder=c.cust_id and
                b.cust_id=d.cust_id;
      
begin

     date1:='&1';

     for i in mandate 
     loop
     
     
       dbms_output.put_line(i.FORACID_NRI||'|'||i.CUST_ID||'|'||i.ACCT_NAME||'|'||i.CUST_ID_MANDATE_HOLDER||'|'||
                            i.CUST_NAME||'|'||i.RCRE_USER||'|'||i.RCRE_TIME||'|'||i.MANDATE_TYPE||'|'||
                            i.EMAIL_ID);
     end loop;
end;
/
spool off
set feedback on
set verify on
