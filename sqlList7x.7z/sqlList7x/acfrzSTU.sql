-- ICI STR 6456    27-12-2007    Sanjay Jain  Bankcampus account freezing
set head off
set verify off
set feedback off
set trimspool on
set pages 0
set termout off
spo actfrzstd.lst

select 	foracid||'|'||'T'||'|'||'ADV'
from 	cmg ,gam
where 	gam.cust_id = cmg.cust_id
and		trunc(date_of_birth) = trunc(add_months((select db_stat_date from gct),-12*27))
and		(CUST_STAT_CODE='STUDT' or CUST_STAT_CODE='STUDN')
and		gam.acct_cls_flg!='Y'
/
spo off
exit 
