set head off echo off trims on feed off verify off pages 0
spool cmd_ncdex_bal_file_dt.lst
select to_char(to_date('&1','DD-MM-YYYY'),'YYYYMMDD') from dual;
spool off
