drop table DISB_REF_DET
/
drop public synonym DISB_REF_DET
/

create table TBAADM.DISB_REF_DET
(
    DISB_ID                 VARCHAR2(12 BYTE),
    FORACID                 VARCHAR2(16 BYTE),
    REFINANCE_FLG           CHAR(1 BYTE),
    REFINANCE_AMT           NUMBER(20,4),
    FUNC_CODE	    	    VARCHAR2 (1 Byte),	
    LCHG_USER_ID            VARCHAR2(15 BYTE),
    LCHG_TIME               DATE,
    RCRE_USER_ID            VARCHAR2(15 BYTE),
    RCRE_TIME               DATE
)
/* STORE_START
TABLESPACE ACCT_DETAILS_3
/* STORE_END */
/

create public synonym DISB_REF_DET for TBAADM.DISB_REF_DET
/

drop index TBAADM.IDX_DISB_REF_DET_DISBID
/
create index TBAADM.IDX_DISB_REF_ADT_DISBID
on DISB_REF_DET(DISB_ID)
/* STORE_START */
storage ( PCTINCREASE 0 )
TABLESPACE IDX_ACCT_DETAILS_3
/* STORE_END */
/

drop index TBAADM.IDX_DISB_REF_DET_FORACID
/
create index TBAADM.IDX_DISB_REF_DET_FORACID
on DISB_REF_DET(FORACID)
/* STORE_START */
storage ( PCTINCREASE 0 )
TABLESPACE IDX_ACCT_DETAILS_3
/* STORE_END */
/

grant select, insert, update, delete on DISB_REF_DET to tbagen
/
grant select on DISB_REF_DET to tbacust
/
grant select on DISB_REF_DET to tbautil
/
