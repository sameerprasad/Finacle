set serveroutput on size 1000000
set feedback off
set verify off
set linesize 500
set pages 0
set trims on
set termout off
set numformat 999D09
spool &3
declare
	SOLID varchar2(5);
	TR_DT varchar2(10);
	outline1 varchar(1500);
	var_out char(20);
	cnt number(10);
begin
SOLID := '&2';
TR_DT := '&1';
var_out := '';
outline1 := '';
select DO_code into var_out from ici_gbm_terminal_master where sol_id = SOLID and scheme_code='0004';
outline1 := var_out;
select SOL_DESC into var_out from sol where sol_id=SOLID;
outline1 := replace(outline1||','||var_out,' ','');
select BSR_code into var_out from ici_gbm_bsrcode where sol_id=SOLID;
outline1 := replace(outline1||','||var_out,' ','');
select to_char(sysdate,'mm') into var_out from dual;
outline1 := replace(outline1||','||var_out,' ','');
select to_char(sysdate,'yyyy') into var_out from dual;
outline1 := replace(outline1||','||var_out,' ','');
select to_char(sysdate,'dd/mm/yyyy') into var_out from dual;
outline1 := replace(outline1||','||var_out,' ','');
select sum(challan_amount)||','||count(*) into var_out from ici_gbm_challan_master where sol_id=SOLID and major_tax_head='0020' and realisation_date=TR_DT and tran_id is not null;
outline1 := replace(outline1||','||var_out,' ','');
select sum(challan_amount)||','||count(*) into var_out from ici_gbm_challan_master where sol_id=SOLID and major_tax_head='0021' and realisation_date=TR_DT and tran_id is not null;
outline1 := replace(outline1||','||var_out,' ','');
select sum(challan_amount)||','||count(*) into var_out from ici_gbm_challan_master where sol_id=SOLID and major_tax_head='0023' and realisation_date=TR_DT and tran_id is not null;
outline1 := replace(outline1||','||var_out,' ','');
select sum(challan_amount)||','||count(*) into var_out from ici_gbm_challan_master where sol_id=SOLID and major_tax_head='0024' and realisation_date=TR_DT and tran_id is not null;
outline1 := replace(outline1||','||var_out,' ','');
select sum(challan_amount)||','||count(*) into var_out from ici_gbm_challan_master where sol_id=SOLID and major_tax_head='0026' and realisation_date=TR_DT and tran_id is not null;
outline1 := replace(outline1||','||var_out,' ','');
select sum(challan_amount)||','||count(*) into var_out from ici_gbm_challan_master where sol_id=SOLID and major_tax_head='0028' and realisation_date=TR_DT and tran_id is not null;
outline1 := replace(outline1||','||var_out,' ','');
select sum(challan_amount)||','||count(*) into var_out from ici_gbm_challan_master where sol_id=SOLID and major_tax_head='0031' and realisation_date=TR_DT and tran_id is not null;
outline1 := replace(outline1||','||var_out,' ','');
select sum(challan_amount)||','||count(*) into var_out from ici_gbm_challan_master where sol_id=SOLID and major_tax_head='0032' and realisation_date=TR_DT and tran_id is not null;
outline1 := replace(outline1||','||var_out,' ','');
select sum(challan_amount)||','||count(*) into var_out from ici_gbm_challan_master where sol_id=SOLID and major_tax_head='0033' and realisation_date=TR_DT and tran_id is not null;
outline1 := replace(outline1||','||var_out,' ','');
select sum(challan_amount)||','||count(*) into var_out from ici_gbm_challan_master where sol_id=SOLID and major_tax_head='0034' and realisation_date=TR_DT and tran_id is not null;
outline1 := replace(outline1||','||var_out,' ','');
select sum(challan_amount)||','||count(*) into var_out from ici_gbm_challan_master where sol_id=SOLID and major_tax_head='0036' and realisation_date=TR_DT and tran_id is not null;
outline1 := replace(outline1||','||var_out,' ','');
select sum(challan_amount)||','||count(*) into var_out from ici_gbm_challan_master where sol_id=SOLID and realisation_date=TR_DT and tran_id is not null and major_tax_head in ('0020','0021','0023','0024','0026','0028','0031','0032','0033','0034','0036');
outline1 := replace(outline1||','||var_out,' ','');
select to_char(sysdate,'dd/mm/yyyy') into var_out from dual;
outline1 := replace(outline1||','||var_out,' ','');
cnt := 0;
dbms_output.put_line(length(outline1));
	WHILE cnt <= length(outline1)  LOOP
		dbms_output.put_line('"'||substr(outline1,cnt,200)||'"');
		cnt := cnt + 200;
	END LOOP;
end;
/
spool off
