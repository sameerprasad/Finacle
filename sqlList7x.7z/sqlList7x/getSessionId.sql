set head off
set pages 0
set linesize 100
set feedback off
set verify off
set termout off
set trims on
spool sessionId

select 'STDWFS.GLBDATA.wfsFlag="'||wfs_in_operation_flg||'"' from lgi where session_id = '&1'
/
spool off
