set pages 0 feedback off echo off verify off trims on lines 2000
spool neft_N10Report.txt
select '{4:'||chr(10)||':2020:'||to_char(rownum,'0000')||to_char(sysdate,'HH24')||'00'||to_char(sysdate,'yyyymmdd')||chr(10)||
':2020:'||tran_id||to_char(tran_date,'yyyymmdd')||chr(10)||
':5518:'||SENDER_IFSC||chr(10)||
':2006:'||TRAN_NO||chr(10)||
':3501:'||to_char(sysdate,'yyyymmdd')||chr(10)||
to_char(sysdate,'HH24MISS')||chr(10)||'-}'
from icici_neft where FILE_NAM='&1' and tran_status='Y'
/
spool off
