set head off
set verify off
set feedback off

spool tmp.lst

select 'PSPREP.TEMP.appId="' || USER_APPL_NAME || '"' from UPR where USER_ID = '&1'
/
spool off

