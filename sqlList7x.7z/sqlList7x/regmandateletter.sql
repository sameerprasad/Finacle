Set ServerOutPut On Size 1000000
set pagesize 0  linesize 500  trims on echo off termout off pause off feedback off verify off heading off space 0
spool  amitabh.lst

declare
fp              utl_file.file_type;
out_rec         varchar2(1000);
repdt                   date;
foracid_nri		varchar2(15);
schm_code		VARCHAR2(5);
MANDATE_HOLDER		varchar2(15);
mandate_cust_id1		 varchar2(15);
mandate_CUST_NAME	 VARCHAR2(80);
mandate_CUST_PERM_ADDR1  varchar2(45);
mandate_CUST_PERM_ADDR2		varchar2(45);
mandate_CUST_PERM_CITY_CODE	varchar2(5);
mandate_CUST_PERM_STATE_CODE	varchar2(5);
mandate_CUST_PERM_PIN_CODE	varchar2(6);
mandate_CUST_PERM_CNTRY_CODE	varchar2(5);
mandate_CUST_PERM_PHONE_NUM	varchar2(15);
CUST_Email			VARCHAR2(50);
CUST_PERM_CITY_CODE1		varchar2(50);
CUST_PERM_STATE_CODE1        varchar2(50);
CUST_PERM_CNTRY_CODE1		varchar2(50);
mandate_CUST_PERM_CITY_CODE1	varchar2(50);
mandate_CUST_PERM_STATE_CODE1    varchar2(50);
mandate_CUST_PERM_CNTRY_CODE1	varchar2(50);

cursor	mandate(date varchar) is
--{
select
                I.FORACID_NRI                   foracid_nri,
                I.CUST_ID_MANDATE_HOLDER        MANDATE_HOLDER,
                G.CUST_ID                       cust,
                CF.CUST_ID                      cf_cust,
				nvl(CF.EMAIL_ID,' ')			mail
from      ICICI_MANDATE_HOLDER I,ICICI_CIFT CF,GAM G
where   G.foracid       =  I.FORACID_NRI
and     G.CUST_ID       =  CF.CUST_ID
and       G.CUST_ID       =  CF.CUST_ID
and	nvl(CF.EMAIL_ID,' ') = ' '
--and       to_date(I.LCHG_TIME) = '04-01-2010';
and       to_date(I.LCHG_TIME,'dd-mm-yyyy') = repdt;
--};

cursor	main_details(foracidnri varchar) is
select 
	G.foracid			foracid_nre,
	G.SCHM_CODE			schm_code,
	C.cust_id 			cust_id,
	C.CUST_NAME			CUST_NAME,
	C.CUST_comu_ADDR1		CUST_PERM_ADDR1,
	C.CUST_comu_ADDR2		CUST_PERM_ADDR2,
	C.CUST_comu_CITY_CODE		CUST_PERM_CITY_CODE,
	C.CUST_comu_PIN_CODE		CUST_PERM_PIN_CODE,
	C.CUST_comu_CNTRY_CODE		CUST_PERM_CNTRY_CODE,
	C.CUST_COMU_STATE_CODE		CUST_PERM_STATE_CODE,
	C.CUST_comu_PHONE_NUM_1		CUST_PERM_PHONE_NUM,
	nvl(C.EMAIL_ID,' ')			CUST_Email
from	cmg C,gam G
where    G.foracid 	=  foracidnri
and nvl(C.EMAIL_ID,' ') = ' '
and 	C.cust_id	= lpad(G.cust_id,9);
begin
--{
	fp :=  utl_file.fopen('/tmp','Mandate.lst','w');
	select db_stat_date into repdt from gct;
	for rec in mandate(repdt)
	loop
	--{
		for main in main_details(rec.foracid_nri)
		loop
		--{
			BEGIN
				--{
				select distinct  REF_DESC into CUST_PERM_CITY_CODE1 from rct 
				where REF_CODE = main.CUST_PERM_CITY_CODE AND ref_rec_type = '01';
				EXCEPTION
				WHEN NO_DATA_FOUND THEN
				CUST_PERM_CITY_CODE1 := '';
				--}
			END;
			BEGIN
				--{
				select distinct  REF_DESC into CUST_PERM_STATE_CODE1 from rct
				where REF_CODE = main.CUST_PERM_STATE_CODE AND ref_rec_type = '02';
				EXCEPTION
				WHEN NO_DATA_FOUND THEN
				CUST_PERM_STATE_CODE1 := '';
				--}
				END;
			BEGIN
				--{
				select distinct  REF_DESC into CUST_PERM_CNTRY_CODE1 from rct
				where REF_CODE = main.CUST_PERM_CNTRY_CODE AND ref_rec_type = '03';
				EXCEPTION 
				 WHEN NO_DATA_FOUND THEN
				 CUST_PERM_CNTRY_CODE1 := '';
				  --}
			  END;

			 select	  C.cust_id,            
					  C.CUST_NAME,	
					  C.CUST_COMU_ADDR1,
					  C.CUST_COMU_ADDR2,
					  C.CUST_COMU_CITY_CODE,
					  C.CUST_COMU_STATE_CODE,
					  C.CUST_COMU_PIN_CODE,	
					  C.CUST_COMU_CNTRY_CODE,
					  C.CUST_COMU_PHONE_NUM_1        
				into
					 mandate_cust_id1,
					 mandate_CUST_NAME,
					 mandate_CUST_PERM_ADDR1,
					 mandate_CUST_PERM_ADDR2,
					 mandate_CUST_PERM_CITY_CODE,
					mandate_CUST_PERM_STATE_CODE,
					mandate_CUST_PERM_PIN_CODE,
					mandate_CUST_PERM_CNTRY_CODE,
					mandate_CUST_PERM_PHONE_NUM
				from    cmg C where    
					C.cust_id  = lpad(rec.MANDATE_HOLDER,9);
			 BEGIN
				--{ CITY CODE
		 		select distinct  REF_DESC into mandate_CUST_PERM_CITY_CODE1 from rct
				 where REF_CODE = mandate_CUST_PERM_CITY_CODE AND ref_rec_type = '01';
			 	EXCEPTION
				 WHEN NO_DATA_FOUND THEN
				 mandate_CUST_PERM_CITY_CODE1 := '';
				 --}
			 END;
			   BEGIN
			   --{ STATE CODE
			   select distinct  REF_DESC into mandate_CUST_PERM_STATE_CODE1 from rct
				where REF_CODE = mandate_CUST_PERM_STATE_CODE AND ref_rec_type = '02';
				EXCEPTION
				 WHEN NO_DATA_FOUND THEN
		  		mandate_CUST_PERM_STATE_CODE1 := '';
			   --}
				END;
			 BEGIN
		 		--{
				select distinct  REF_DESC into mandate_CUST_PERM_CNTRY_CODE1 from rct
			 	where REF_CODE = mandate_CUST_PERM_CNTRY_CODE AND ref_rec_type = '03';
				 EXCEPTION
			  WHEN NO_DATA_FOUND THEN
				   mandate_CUST_PERM_CNTRY_CODE1 := '';
				 --}
			   END;



				out_rec:= 
					 -- rpad(repdt,12)            ||'|'||
					rec.foracid_nri			   	||'|'||
					main.schm_code                ||'|'||
					main.cust_id		||'|'||
					main.CUST_NAME        	||'|'||
					main.CUST_PERM_ADDR1        	||'|'||
					main.CUST_PERM_ADDR2        	||'|'||
					--rpad(main.CUST_PERM_CITY_CODE        	||'|'||
					CUST_PERM_CITY_CODE1          ||'|'||
					CUST_PERM_STATE_CODE1          ||'|'||
					main.CUST_PERM_PIN_CODE		||'|'||
					--rpad(main.CUST_PERM_CNTRY_CODE		||'|'||
					CUST_PERM_CNTRY_CODE1		||'|'||
					main.CUST_PERM_PHONE_NUM		||'|'||

					mandate_cust_id1		||'|'||      
					mandate_CUST_NAME		||'|'||
					mandate_CUST_PERM_ADDR1		||'|'||      
					mandate_CUST_PERM_ADDR2		||'|'||      
					--rpad(mandate_CUST_PERM_CITY_CODE		||'|'||      
					mandate_CUST_PERM_CITY_CODE1       ||'|'||
					 mandate_CUST_PERM_STATE_CODE1       ||'|'||
					mandate_CUST_PERM_PIN_CODE			||'|'||      
					--rpad(mandate_CUST_PERM_CNTRY_CODE		||'|'||      
					mandate_CUST_PERM_CNTRY_CODE1      ||'|'||
					mandate_CUST_PERM_PHONE_NUM;
			if (CUST_Email is  null) then 
				utl_file.put_line(fp,out_rec);
			 end if;

			 CUST_PERM_CITY_CODE1 := '';
			 CUST_PERM_STATE_CODE1 := '';
			 CUST_PERM_CNTRY_CODE1   := '';

			 mandate_CUST_PERM_CITY_CODE1 := '';
			 mandate_CUST_PERM_STATE_CODE1   := '';
			 mandate_CUST_PERM_CNTRY_CODE1  := '';


		--}
		end loop;
	--}
	end loop;
	utl_file.fclose(fp);
--}
end;
/
spo off
exit

