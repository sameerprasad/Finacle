prompt 'Creation of Menu option LCUPL for Locker Master Upload:'

select 'Adding the new menu option LCUPL...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'LCUPL';
end;
/
create table tmp_mod32 as (select * from mod where mop_id = 'UPM')
/
update tmp_mod32 set mop_id = 'LCUPL', input_filename = '', mop_type='G',exe_name='LockMigUpl.com',db_status='C'
/
commit;

insert into mod select * from tmp_mod32;

commit;

drop table tmp_mod32;

create table tmp_mod32 as (select * from mod_txt where mop_id = 'UPM');
update tmp_mod32 set mop_id = 'LCUPL' , user_mop_id = 'LCUPL',mop_text = 'LOCKER MIGRATION MASTER UPLOAD';
commit;
insert into mod_txt select * from tmp_mod32;
commit;

drop table tmp_mod32;

insert into oat values ('LCUPL','GU','SYSTEM',sysdate,'SYSTEM',sysdate,0)
/
insert into oat values ('LCUPL','DB','SYSTEM',sysdate,'SYSTEM',sysdate,0)
/
commit
/
insert into mno values ('WFMU',:mopNum,'LCUPL','SYSTEM',sysdate,'SYSTEM',sysdate,0 )
/
commit;
