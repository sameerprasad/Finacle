set head off
set pages 0
set feedback off
spool dbdate
select (db_stat_date ) from gct;
spool off
exit
