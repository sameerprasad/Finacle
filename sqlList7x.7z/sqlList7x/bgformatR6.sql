accept solid prompt 'ENTER FOUR DIGIT SOL ID OF REPORT BRANCH : '
accept dt1 prompt 'ENTER DATE FOR REPORT (DD-MM-YYYY) : '
set termout off
author :: Gurnam S Saini, I.T. Deptt.,Corporate Office,Bombay
set verify off
set echo off
set feedback off
set pages 60
set linesize 132
set newpage 0

column today new_value today_date
select to_char(sysdate,'dd/mm/yyyy') today from dual;

column bran new_value br
select br_name bran from bct where br_code=(select br_code from sol); 

set numformat b999,99,99,999.99
col cust_id  heading 'CUST_ID' format a11
col name heading 'NAME' format a35 word_wrap
col type heading 'GTEE|TYPE' format a4
col num heading 'GUARANTEE|NUMBER' format a12
col crncy_code heading 'CURR|CODE' format a4
col bg_amt heading 'AMOUNT (IN Rs.)' format b999,99,99,999.99
col effdate heading 'EFFECTIVE|DATE' format a10
col exp_date heading 'CLAIM EXP|DATE' format a10
col ben_name heading 'BENIFICIARY|NAME' format a25
break on cust_id on name skip 1 on report
compute sum LABEL "PARTY TOTAL" of bg_amt on cust_id
compute sum LABEL "GRAND TOTAL" of bg_amt on report
ttitle center 'ICICI BANK LIMITED' skip 1 -
center br skip 2 -
center 'REPORT ON OUTSTANDING BANK GUARANTEES AS ON ' '&dt1' -
right 'PAGE :     ' format 999 sql.pno skip 1 - 
right 'DATE : ' today_date skip 1
btitle center 'THE LIABILITY SHOWN IN AMOUNT COLUMN IS RUPEE LIABILITY' skip 2 -
right 'SIGNATURE'
spool bgformatR6.lst    

select ltrim(a.cust_id) cust_id, b.cust_name name, bg_type type, bg_srl_num num, effective_date effdate,claim_expiry_date exp_date, decode(a.crncy_code,a.crncy_code,a.crncy_code,' ') crncy_code, bg_amt*decode(rate,0,1,rate) bg_amt,substr(beneficiary_name,1,25) ben_name 
from bgm a, cmg b
	where a.bg_type!='DPG'
	and a.cust_id=b.cust_id
	and effective_date <= '&dt1'
	and ((bg_status in('A','E','G','O') or
		invocn_date > '&dt1' or
		reversal_date > '&dt1' or
		close_date > '&dt1') 
		or (bg_status='O' and claim_expiry_date >= '&dt1'))
	and a.crncy_code = 'INR'	
	and a.sol_id = '&solid'
union
select ltrim(a.cust_id) cust_id, b.cust_name name, bg_type type, bg_srl_num num, effective_date effdate,claim_expiry_date exp_date, decode(a.crncy_code,a.crncy_code,a.crncy_code,' ') crncy_code,round( bg_amt*decode(rate,0,1,rate),0) bg_amt,substr(beneficiary_name,1,25) ben_name
from bgm a, cmg b
	where a.bg_type!='DPG'
	and a.cust_id=b.cust_id
	and effective_date <= '&dt1'
	and ((bg_status in('A','E','G','O') or
		invocn_date > '&dt1' or
		reversal_date > '&dt1' or
		close_date > '&dt1') 
		or (bg_status='O' and claim_expiry_date >= '&dt1'))
	and a.crncy_code != 'INR'	
	and a.sol_id = '&solid'
union
select ltrim(a.cust_id), b.cust_name, bg_type, a.bg_srl_num, effective_date,claim_expiry_date exp_date, decode(a.crncy_code,a.crncy_code,a.crncy_code,' '), bg_amt*decode(rate,0,1,rate),substr(beneficiary_name,1,25) ben_name 
from bgm a, cmg b,bgi x
	where a.cust_id=b.cust_id
	and a.bg_type='DPG'
	and a.bg_srl_num=x.bg_srl_num
	and effective_date <= '&dt1'
	and ((bg_status in('A','E','G','O') or
		invocn_date > '&dt1' or
		reversal_date > '&dt1' or
		close_date > '&dt1') 
		or (bg_status='O' and claim_expiry_date >= '&dt1')) and
		a.bg_srl_num not in (select distinct bg_srl_num from bgi y
		where y.bg_srl_num=a.bg_srl_num and
		y.tran_date is not null)
	and a.sol_id = '&solid'
union
select ltrim(a.cust_id), b.cust_name, bg_type, a.bg_srl_num, effective_date,claim_expiry_date exp_date, decode(a.crncy_code,a.crncy_code,a.crncy_code,' '), (bg_amt*decode(rate,0,1,rate) -sum(tran_amt)),substr(beneficiary_name,1,25) ben_name 
from bgm a, cmg b,bgi x
	where a.cust_id=b.cust_id
	and a.bg_type='DPG'
	and a.bg_srl_num=x.bg_srl_num
	and effective_date <= '&dt1'
	and ((bg_status in('A','E','G','O') or
		invocn_date > '&dt1' or
		reversal_date > '&dt1' or
		close_date > '&dt1') 
		or (bg_status='O' and claim_expiry_date >= '&dt1')) and
		x.tran_date is not null and
		x.tran_date <='&dt1'
	and a.sol_id = '&solid'
group by a.cust_id,b.cust_name,bg_type,a.bg_srl_num,effective_date,claim_expiry_date,a.crncy_code, bg_amt,rate,beneficiary_name
order by 2,6
/
spool off
exit
