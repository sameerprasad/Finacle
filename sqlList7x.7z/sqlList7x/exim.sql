rem accept dt1 prompt "Enter date of Report ::::"
accept solid prompt 'ENTER THE SOL_ID OF YOUR BRANCH : '
set echo off
set verify off
set feedback off
set head off
set termout off
set pages 66
set numformat b99,99,99,99,99,99,999.99
column today new_value dt1
column nop noprint
select to_char(db_stat_date,'dd-mm-yyyy') today from gct ;
spool exim.lst

select '             EXPORT / IMPORT TRANSACTIONS' from dual; 
select '   Fortnightly statement of outstanding export and import bills' from dual; 
select '                  as on &dt1' from dual;
select ' -----------------------------------------------------------' from dual;
select '1. Outstanding Pre-Shipment Export Credit ' from dual;
select 'A) In Rupees                         ',sum(tran_date_bal) from eab e , gam g
where ltrim(g.sol_id) = '&solid'
and g.gl_sub_head_code = '60015'
and g.acct_crncy_code='INR'
and g.acid = e.acid
and eod_date = (select max(eod_date) from eab b
		where e.acid = b.acid
		and trunc(b.eod_Date) <= to_date('&dt1','dd-mm-yyyy') )
union
select 'B) In foreign Currency               ', sum(tran_date_bal) from eab e , gam g
where  ltrim(g.sol_id) = '&solid'
and g.gl_sub_head_code = '60016'
and g.acid = e.acid
and eod_date = (select max(eod_date) from eab b
		where e.acid = b.acid
		and trunc(b.eod_Date) <= to_date('&dt1','dd-mm-yyyy') )
/
select ' ---------------------------------------------------------------------' from dual;
select '2. Outstanding Post-Shipment Export Credit :' from dual;
select ' A) Export Bills(sight as also usance) negotiated/purchased/discounted' from dual;
select '            i) In Rupees             ',sum(fbm.bp_liab) from fbm,fbh
where fbm.sol_id = fbh.sol_id
and fbm.bill_id = fbh.bill_id
and fbm.reg_type = 'FOBP'
and fbm.bp_liab > 0
and fbh.event_num = (select max(event_num) from fbh A
            where A.bill_func = 'P'
            and A.sol_id = fbm.sol_id
            and fbm.bill_id = A.bill_id)
and fbh.bill_func = 'P'
and fbm.cls_flg != 'Y'
and fbm.del_flg != 'Y'
and fbm.bill_stat in ('G','P')
and trunc(lodg_Date) <= to_date('&dt1','dd-mm-yyyy')
union
select '             ii) In Foreign Currency ',sum(fbm.bp_liab) from fbm, fbh
where fbm.sol_id = fbh.sol_id
and fbm.bill_id = fbh.bill_id
and fbm.reg_type = 'FBPF' 
and fbm.del_flg != 'Y'
and fbm.cls_flg != 'Y'
and fbm.bill_stat in ('G','P')
and trunc(lodg_Date) <= to_date('&dt1','dd-mm-yyyy')
/
select ' B) Advance against Export Bills (sight as also usance ) sent on collection' from dual;
select'            i) In Rupees             ',sum(fbm.bp_liab) from fbm,fbh
where fbm.sol_id = fbh.sol_id
and fbm.bill_id = fbh.bill_id
and fbm.reg_type = 'FOBP'
and fbm.bp_liab > 0
and fbh.event_num = (select max(event_num) from fbh A
				      where A.sol_id = fbm.sol_id
					  and fbm.bill_id = A.bill_id)	
and fbh.bill_func ='H'
and  not exists(select 'x' from fbh
            where fbh.bill_func = 'P'
            and fbh.sol_id = fbm.sol_id
            and fbm.bill_id = fbh.bill_id)
and fbm.cls_flg != 'Y'
and fbm.del_flg != 'Y'
and fbm.bill_stat in ('G','P')
and trunc(lodg_Date) <= to_date('&dt1','dd-mm-yyyy')
/
select '            ii) In Foreign Currency    '  from dual; 
select ' ---------------------------------------------------------------------' from dual;
select ' 3. Outstanding import Letters of Credit ' from dual;
select '            i) Sight                ',sum(round(((((d.current_value*(1+(d.actl_tolerance_pcnt/100)))-d.dc_nobill_util_amt-d.dc_nobill_fruct_amt-d.advance_value+d.dc_reinst_amt+d.interest_addtnl_amt-d.dc_bill_util_amt)*d.rate/r.fxd_crncy_units)),0))
from dcmm d,rtm r
where d.current_value > 0
  and  dc_reg_type = 'OUTFR' 
  and  r.ratecode=d.ratecode 
  and  r.fxd_crncy_code=d.actl_crncy_code 
  and  r.var_crncy_code='INR'
  and  actl_usance = 0  
  and  trunc(date_opnd) <= to_date('&dt1','dd-mm-yyyy')
	and (trunc(date_clsd) >= to_date('&dt1','dd-mm-yyyy') or date_clsd is null)
	and d.del_flg != 'Y'
union
select '            ii) Usance                ',sum(round(((((d.current_value*(1+(d.actl_tolerance_pcnt/100)))-d.dc_nobill_util_amt-d.dc_nobill_fruct_amt-d.advance_value+d.dc_reinst_amt+d.interest_addtnl_amt-d.dc_bill_util_amt)*d.rate/r.fxd_crncy_units)),0))
from dcmm d,rtm r
where d.current_value > 0
  and  dc_reg_type = 'OUTFR'  
  and  r.ratecode=d.ratecode 
  and  r.fxd_crncy_code=d.actl_crncy_code 
  and  r.var_crncy_code='INR'
  and  actl_usance > 0  
  and  trunc(date_opnd) <= to_date('&dt1','dd-mm-yyyy')
	and (trunc(date_clsd) >= to_date('&dt1','dd-mm-yyyy') or date_clsd is null)
	and d.del_flg != 'Y'
/
select ' -----------------------------------------------------------------------' from dual;
select '4. Outstanding import bills (under LC as also collection) pending payment by customers' from dual;
select '             i) Sight bills under LC  ',sum(fbm.bill_amt_inr)
from fbm,fbi
where fbm.sol_id = fbi.sol_id
and fbm.bill_id=fbi.bill_id  
and fbm.usance_months=0
and fbm.usance_days= 0
and fbm.cls_flg!='Y'
and fbm.bill_stat in ('G','P')
and fbm.under_lc_flg = 'Y'
and trunc(fbm.lodg_Date) <= to_date('&dt1','dd-mm-yyyy')
union
select '             ii) Usance bills under LC ',sum(fbm.bill_amt_inr)
from fbm,fbi
where fbm.sol_id = fbi.sol_id
and fbm.bill_id=fbi.bill_id  
and fbm.under_lc_flg = 'Y'
and (fbm.usance_months > 0 or fbm.usance_days > 0) 
and fbm.cls_flg!='Y'
and fbm.bill_stat in ('G','P')
and trunc(fbm.lodg_Date) <= to_date('&dt1','dd-mm-yyyy')
union
select '             iii) Collection bills     ',sum(bill_amt_inr) 
from fbm,fbi
where fbm.sol_id = fbi.sol_id
and fbm.bill_id=fbi.bill_id  
and fbm.under_lc_flg != 'Y'
and fbm.bill_stat in ('G','P')
and fbm.cls_flg!='Y'
and fbm.del_flg != 'Y'
and trunc(fbm.lodg_Date) <= to_date('&dt1','dd-mm-yyyy')
/
select '----------------------------------------------------------------------- ' from dual;
select ' 5. Outstanding Export Bills (sight as also usance) sent on collection,
including those against which credit has been given ::    ' from dual; 
select '  		 i) Export Collection Bill  ',sum(fbm.bill_amt_inr) 
from fbm,fbe
where fbm.bill_id =fbe.bill_id
and fbm.sol_id = fbe.sol_id
and fbm.bill_stat in ('G','P')
and fbm.cls_flg!='Y'
and fbm.bp_liab = 0
and trunc(fbm.lodg_Date) <= to_date('&dt1','dd-mm-yyyy')
/
select '		 ii) Adv against Export Bills',sum(fbm.bp_liab)
from fbm,fbh
where fbm.sol_id = fbh.sol_id
and fbm.bill_id = fbh.bill_id
and fbm.reg_type = 'FOBP'
and fbm.bp_liab > 0
and fbh.event_num = (select max(event_num) from fbh A
				      where A.sol_id = fbm.sol_id
					  and fbm.bill_id = A.bill_id)	
and fbh.bill_func ='H'
and  not exists(select 'x' from fbh
            where fbh.bill_func = 'P'
            and fbh.sol_id = fbm.sol_id
            and fbm.bill_id = fbh.bill_id)
and fbm.cls_flg != 'Y'
and fbm.del_flg != 'Y'
and fbm.bill_stat in ('G','P')
and trunc(lodg_Date) <= to_date('&dt1','dd-mm-yyyy')
/
select'_________________________________________________________________________' from dual;
select '       ' from dual;
select '       ' from dual;
select '                                                         SIGNATURE ' from dual; 
spool off
skip 33
exit
