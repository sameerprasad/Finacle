Rem Auhtor: Rahul Nimkar
Rem Usage: In ICIRSQLS to generate report of bills lodged under register FOCP taking sub-register as an input
set lines 142
set pages 60
set verify off
set feedback off
set termout off
set trims on

col rowno heading 'Sr. No.' justify right format B999999
col id heading 'SXP No.' justify right format B99999999999999
col crncy heading 'Curr.' justify right format A5
col amt1 heading 'Amount' justify right format B99,99,99,999.99
col dt_rmt heading 'Value Date' justify left format A10
col amt2 heading 'Value Amount' justify right format B99,99,99,999.99
col crefno heading 'Credit Ref. No.' justify left format A16
col dealno heading 'Deal Number' justify left format A16
col enter heading 'Entered by' justify right format A15
col verfd heading 'Verified by' justify right format A15

spool irm_select
select  rownum rowno,
        m.bill_id id,
        m.bill_crncy_code crncy,
        m.bill_amt amt1,
        h.bp_value_date dt_rmt,
        h.nostro_amt amt2,
        a1.trea_ref_num crefno,
        a2.trea_ref_num dealno,
        h.entry_user_id enter,
        h.vfd_user_id verfd
from fbm m, fbh h, fae a1, fae a2
where m.reg_type = 'FOCP'
and m.reg_sub_type = '&1'
and h.bill_id = m.bill_id
and h.sol_id = m.sol_id
and h.bill_func = 'R'
and a1.sol_id = h.sol_id
and a1.bill_id = h.bill_id
and a1.tran_id = h.tran_id
and a1.part_tran_srl_num = '   1'
and a2.sol_id = h.sol_id
and a2.bill_id = h.bill_id
and a2.tran_id = h.tran_id
and a2.part_tran_srl_num = '   2'
and a1.tran_date= '&2'
/
spool off
set verify on
set feedback on
set termout on
