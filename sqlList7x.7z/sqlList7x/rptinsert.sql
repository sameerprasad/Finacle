insert into CLRPT values ('RPT01','PRINT RECEIPT REPORT','lcrntrpt.jsp',user,sysdate,user,sysdate,'N')
/
insert into CLRPT values ('RPT02','RENT COLLECTED REPORT - Manual Collection','lcrntcolrpt.jsp','user',SYSDATE,'user',SYSDATE,'N')
/
insert into CLRPT values ('RPT03','RENT COLLECTED REPORT - System Collection','lcrntsys.jsp','user',SYSDATE,'user',SYSDATE,'N')
/
insert into CLRPT values ('RPT04','LOCKER CURRENTLY IN OVERDUE REPORT','lcovdrpt.jsp','user',SYSDATE,'user',SYSDATE,'N')
/

