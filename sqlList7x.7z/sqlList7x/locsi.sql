--##############################################################################################
--#                     File Name   : locsi.sql
--#                     Author : Chandra Sekar (BBSSL)
--#                     Report : Locker Si Due Letter
--#                     Date   :
--#                     Module  : LOCKER
--#                     Called Menu     : LOCKRPT
--#                     Called By       : locsi.com
--##############################################################################################
CREATE OR REPLACE PACKAGE locsi AS
        PROCEDURE locsi(inp_str IN VARCHAR2,
                out_retCode OUT NUMBER,
                out_rec OUT VARCHAR2);
END locsi;
/
CREATE OR REPLACE PACKAGE BODY locsi AS
v_solid			sst.set_id%type;
v_date			date;
v_name		varchar2(200);
v_addr_1		varchar2(200);
v_addr_2		varchar2(200);
v_city_code		varchar2(200);
v_state_code		varchar2(200);
v_cntry_code		varchar2(200);
v_pin_code		varchar2(200);
v_rent_amount1		varchar2(200);
v_rent_amount2		varchar2(200);
v_part_tran_type1	varchar2(200);
v_part_tran_type2	varchar2(200);
v_acct_no1		varchar2(200);
v_acct_no2		varchar2(200);
v_city			varchar2(200);
v_state			varchar2(200);
v_country		varchar2(200);

cursor c1 is
	SELECT  DISTINCT(sih.si_srl_num), 
	'A',
	tran_id,
	tran_date,
	tdtd.SI_ORG_EXEC_DATE,
	sih.cust_id,
	SUBSTR(SUBSTR(sih.RMKS_FREE_TEXT,INSTR(sih.RMKS_FREE_TEXT,'/LOC/'),LENGTH(sih.RMKS_FREE_TEXT)),6,1),
	SUBSTR(SUBSTR(sih.RMKS_FREE_TEXT,INSTR(sih.RMKS_FREE_TEXT,'/LOC/'),LENGTH(sih.RMKS_FREE_TEXT)),8,LENGTH(sih.RMKS_FREE_TEXT))
	FROM  TDTD, SST, SIH  
	WHERE  sih.si_srl_num >= '           1'  
	AND tdtd.si_srl_num(+) = sih.si_srl_num  
	AND sih.last_tried_date = TO_DATE(v_date, 'DD-MM-YYYY HH24:MI:SS')  
	AND (sih.sol_id = sst.sol_id AND sst.set_id = v_solid ) 
	AND (tdtd.si_org_exec_date(+) = TO_DATE(v_date , 'DD-MM-YYYY HH24:MI:SS')) 
	AND tdtd.dtd_pstd_flg!= 'Y' 
	AND sih.RMKS_FREE_TEXT LIKE ('%/LOC/%')
	UNION 
	SELECT DISTINCT(sic.si_srl_num), 
	'A',
	tran_id,
	tran_date,
	tdtd.SI_ORG_EXEC_DATE,
	sih.cust_id,
	SUBSTR(SUBSTR(sih.RMKS_FREE_TEXT,INSTR(sih.RMKS_FREE_TEXT,'/LOC/'),LENGTH(sih.RMKS_FREE_TEXT)),6,1),
	SUBSTR(SUBSTR(sih.RMKS_FREE_TEXT,INSTR(sih.RMKS_FREE_TEXT,'/LOC/'),LENGTH(sih.RMKS_FREE_TEXT)),8,LENGTH(sih.RMKS_FREE_TEXT))
	FROM tdtd,sst,sic,sih 
	WHERE sih.si_srl_num >= '           1'  
	AND tdtd.si_srl_num(+) = sic.si_srl_num  
	AND (tdtd.si_org_exec_date(+) = sic.si_org_exec_date)  
	AND sih.si_srl_num = sic.si_srl_num  
	AND (SIC.last_tried_date = TO_DATE( v_date , 'DD-MM-YYYY HH24:MI:SS'))  
	AND ((sic.sol_id || NULL = sst.sol_id AND sst.set_id = v_solid )) 
	AND tdtd.dtd_pstd_flg!= 'Y' 
	AND sih.RMKS_FREE_TEXT LIKE ('%/LOC/%')
	UNION
	SELECT DISTINCT(sih.si_srl_num),
	'B',
	tran_id,
	tran_date,
	tdtd.SI_ORG_EXEC_DATE,
	sih.cust_id,
	SUBSTR(SUBSTR(sih.RMKS_FREE_TEXT,INSTR(sih.RMKS_FREE_TEXT,'/LOC/'),LENGTH(sih.RMKS_FREE_TEXT)),6,1),
	SUBSTR(SUBSTR(sih.RMKS_FREE_TEXT,INSTR(sih.RMKS_FREE_TEXT,'/LOC/'),LENGTH(sih.RMKS_FREE_TEXT)),8,LENGTH(sih.RMKS_FREE_TEXT))
	FROM  TDTD, SST, SIH  
	WHERE  sih.si_srl_num >= '           1'  
	AND tdtd.si_srl_num(+) = sih.si_srl_num  
	AND sih.last_tried_date = TO_DATE(v_date, 'DD-MM-YYYY HH24:MI:SS')  
	AND (sih.sol_id = sst.sol_id AND sst.set_id = v_solid ) 
	AND (tdtd.si_org_exec_date(+) = TO_DATE(v_date , 'DD-MM-YYYY HH24:MI:SS')) 
	AND tdtd.dtd_pstd_flg!= 'N' 
	AND sih.RMKS_FREE_TEXT LIKE ('%/LOC/%')
	UNION 
	SELECT DISTINCT(sic.si_srl_num), 
	'B',
	tran_id,
	tran_date,
	tdtd.SI_ORG_EXEC_DATE,
	sih.cust_id,
	SUBSTR(SUBSTR(sih.RMKS_FREE_TEXT,INSTR(sih.RMKS_FREE_TEXT,'/LOC/'),LENGTH(sih.RMKS_FREE_TEXT)),6,1),
	SUBSTR(SUBSTR(sih.RMKS_FREE_TEXT,INSTR(sih.RMKS_FREE_TEXT,'/LOC/'),LENGTH(sih.RMKS_FREE_TEXT)),8,LENGTH(sih.RMKS_FREE_TEXT))
	FROM tdtd,sst,sic,sih 
	WHERE sih.si_srl_num >= '           1'  
	AND tdtd.si_srl_num(+) = sic.si_srl_num  
	AND (tdtd.si_org_exec_date(+) = sic.si_org_exec_date)  
	AND sih.si_srl_num = sic.si_srl_num  
	AND (SIC.last_tried_date = TO_DATE( v_date , 'DD-MM-YYYY HH24:MI:SS'))  
	AND ((sic.sol_id || NULL = sst.sol_id AND sst.set_id = v_solid )) 
	AND tdtd.dtd_pstd_flg!= 'N' 
	AND sih.RMKS_FREE_TEXT LIKE ('%/LOC/%');

PROCEDURE locsi(inp_str IN VARCHAR2,
        out_retCode OUT NUMBER,
        out_rec OUT VARCHAR2) IS

outArr                  basp0099.ArrayType;
v_si_srl_num		sih.si_srl_num%type;
v_ind			varchar2(5);
v_tran_id		tdtd.tran_id%type;
v_tran_date		tdtd.tran_date%type;
v_SI_ORG_EXEC_DATE	tdtd.SI_ORG_EXEC_DATE%type;
v_cust_id		sih.cust_id%type;
v_period		varchar2(5);
v_locker_number		varchar2(12);
v_cust_name		cmg.cust_name%type;
v_rent_amount		dtd.tran_amt%type;
v_oper_acc		gam.foracid%type;
v_oper_type		gam.schm_type%type;
v_reason		varchar2(10) := NULL;
v_acid			gam.acid%type;
v_status		char(1) := NULL;


Begin
        --{
        basp0099.formInputArr(inp_str,outArr);
	v_solid         := outArr(0);
	v_date          := outArr(1);
        out_retCode     :=  0;
        out_rec         := NULL;

------------------------------------------------------------
--Opening cursor
------------------------------------------------------------
        IF(NOT c1%ISOPEN) THEN
        --{
        out_retCode:= 0;
        open c1;
        --}
        END IF;
-------------------------------------------------------------
--Fetching Data
-------------------------------------------------------------
        IF(c1%ISOPEN)  THEN
        FETCH C1
        INTO	v_si_srl_num,
		v_ind,
		v_tran_id,
		v_tran_date,
		v_SI_ORG_EXEC_DATE,
		v_cust_id,
		v_period,
		v_locker_number;
        end if;
        if (c1%ISOPEN AND c1%NOTFOUND) THEN
        --{
            close c1;
            out_retcode := 1;
            return;
        --}
        end if;
------------------------------------------------------------
--Fetching Limits and Expiry Date
------------------------------------------------------------

begin
	SELECT cust_name INTO v_cust_name
	FROM cmg
	WHERE cust_id = v_cust_id;
	exception when no_data_found then
		v_cust_id := NULL;
end;

begin
        SELECT acid,tran_amt INTO v_acid,v_rent_amount
        FROM (SELECT acid,tran_amt FROM dtd
                WHERE tran_id = v_tran_id
                AND tran_date = v_tran_date
                AND part_tran_type = 'D'
                UNION
                SELECT acid,tran_amt FROM htd
                WHERE tran_id = v_tran_id
                AND tran_date = v_tran_date
                AND part_tran_type = 'D');
        exception when no_data_found then
                v_rent_amount := 0;
end;

begin
        SELECT foracid,schm_type INTO v_oper_acc,v_oper_type
        FROM gam
        WHERE acid = v_acid;
        exception when no_data_found then
                v_oper_acc := NULL;
                v_oper_type := NULL;
end;
begin
	SELECT CONCAT(CONCAT(DECODE(ADDRESS_TYPE,'P',nvl(CUST_PERM_ADDR1,''),'C',nvl(CUST_COMU_ADDR1,''),'E',
	nvl(CUST_EMP_ADDR1,'')),','),
	DECODE(ADDRESS_TYPE,'P',nvl(CUST_PERM_ADDR2,''),'C',nvl(CUST_COMU_ADDR2,''),'E',
	nvl(CUST_EMP_ADDR2,'')))ADDRESS_TYPE1,

	CONCAT(CONCAT(DECODE(ADDRESS_TYPE,'P',nvl((SELECT SUBSTR(ref_desc,1,25) FROM rct WHERE ref_rec_type='02' AND
	ref_code=CUST_PERM_CITY_CODE),''),'C',nvl((SELECT SUBSTR(ref_desc,1,25) FROM rct WHERE ref_rec_type='01' AND 
	ref_code=CUST_COMU_CITY_CODE),''),'E',nvl((SELECT SUBSTR(ref_desc,1,25) FROM rct WHERE ref_rec_type='01' AND 
	ref_code=CUST_EMP_CITY_CODE),'')),'-'),
	DECODE(ADDRESS_TYPE,'P',nvl(CUST_PERM_PIN_CODE,''),'C',nvl(CUST_COMU_PIN_CODE,''),'E',
        nvl(CUST_EMP_PIN_CODE,'')))state_abbr,
	DECODE(ADDRESS_TYPE,'P',nvl((SELECT SUBSTR(ref_desc,1,25) FROM rct WHERE ref_rec_type='02' AND
	ref_code=CUST_PERM_STATE_CODE),''),'C',nvl((SELECT SUBSTR(ref_desc,1,25) FROM rct
	WHERE ref_rec_type='02' AND ref_code=CUST_COMU_STATE_CODE),''),'E',nvl((SELECT SUBSTR(ref_desc,1,25) FROM rct 
	WHERE ref_rec_type='02' AND ref_code=CUST_EMP_STATE_CODE),''))state_abbr,
	DECODE(ADDRESS_TYPE,'P',nvl((SELECT SUBSTR(ref_desc,1,25) FROM rct WHERE ref_rec_type='03' AND
	ref_code=CUST_PERM_CNTRY_CODE),''),'C',nvl((SELECT SUBSTR(ref_desc,1,25) FROM rct WHERE ref_rec_type='03' AND 
	ref_code=CUST_COMU_CNTRY_CODE),''),'E',nvl((SELECT SUBSTR(ref_desc,1,25) FROM rct WHERE ref_rec_type='03' AND 
	ref_code=CUST_EMP_CNTRY_CODE),''))cntry_abbr 
into    v_addr_1,v_city,v_state,v_country
from	cmg
where	cust_id = v_cust_id;
	exception when NO_DATA_FOUND then
	v_addr_1 := null; 
	v_city := null; 
	v_state := null;
	v_country := null;
end;
	
--*****************************************************************
begin
        SELECT	acid,
		tran_amt, 
		part_tran_type, 
		foracid 
	INTO	v_acid,v_rent_amount1, v_part_tran_type1, v_acct_no1
        FROM		(SELECT	dtd.acid,
			dtd.tran_amt, 
			dtd.part_tran_type, 
			gam.foracid 
		FROM	dtd, gam
                WHERE	gam.acid = dtd.acid
		AND	dtd.tran_id = v_tran_id
                AND	dtd.tran_date = v_tran_date
                AND	dtd.part_tran_type = 'D'
                UNION
                SELECT	htd.acid,
			htd.tran_amt, 
			htd.part_tran_type, 
			gam.foracid 
		FROM	htd, gam
                WHERE	gam.acid = htd.acid
		AND	htd.tran_id = v_tran_id
                AND	htd.tran_date = v_tran_date
                AND	htd.part_tran_type = 'D');
        exception when no_data_found then
                v_rent_amount := 0;
end;

begin
        SELECT	acid,
		tran_amt, 
		part_tran_type, 
		foracid
	INTO	v_acid,v_rent_amount2, v_part_tran_type2, v_acct_no2 
        FROM		(SELECT	dtd.acid,
			dtd.tran_amt,
			dtd.part_tran_type, 
			gam.foracid  
		FROM	dtd, gam
                WHERE	gam.acid = dtd.acid
		AND	dtd.tran_id = v_tran_id
                AND	dtd.tran_date = v_tran_date
                AND	dtd.part_tran_type = 'C'
                UNION
                SELECT	htd.acid,
			htd.tran_amt,	
			htd.part_tran_type,
			gam.foracid  
		FROM	htd, gam
                WHERE	gam.acid = htd.acid
		AND	htd.tran_id = v_tran_id
                AND	htd.tran_date = v_tran_date
                AND	htd.part_tran_type = 'C');
        exception when no_data_found then
                v_rent_amount := 0;
end;
--************************************************************************

--######################################################################

--#######################################################################

        out_rec := 	
			trim(v_si_srl_num)	||'|'||
			v_ind			||'|'||
			v_locker_number		||'|'||
			v_cust_id		||'|'||
			v_cust_name		||'|'||
			v_oper_acc		||'|'||
			v_oper_type		||'|'||
			v_reason		||'|'||
			v_tran_date		||'|'||
			v_rent_amount		||'|'||
			v_period		||'|'||
			v_rent_amount1		||'|'||
			v_rent_amount2		||'|'||
			v_part_tran_type1	||'|'||
			v_part_tran_type2	||'|'||
			v_acct_no1		||'|'||
			v_acct_no2		||'|'||
			v_addr_1		||'|'||
			v_city			||'|'||
			v_state			||'|'||
			v_country;	

END locsi;
END locsi;
/
DROP  PUBLIC SYNONYM locsi
/
CREATE PUBLIC SYNONYM locsi FOR locsi
/
GRANT EXECUTE ON locsi to  tbagen, tbautil, tbacust,tbaadm
/
