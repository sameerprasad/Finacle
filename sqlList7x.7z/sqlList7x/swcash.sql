set feedback off

alter session set nls_date_format='dd-mm-yyyy';
rem prompt *****USE THIS OPTION ONLY TO GENERATE SWITCH CASH REPORT*****
rem prompt *****        FOR DATES ON OR AFTER 19-10-2001           *****
rem prompt 
rem accept as_on_date prompt 'ENTER REPORT DATE IN DD-MM-YYYY FORMAT  :  '
rem accept solid prompt 'ENTER THE SOL_ID FOR WHICH REPORT IS REQUIRED   :  '

set termout off
set echo off
set linesize 150
set pagesize 60
set newpage 0
set space 1
set wrap off
set pause off
set verify off

column dt new_value report_date
select to_char(sysdate,'DD-MM-YYYY HH24:MM:SS') dt from dual;

define all_dashes = '-----------------------------------------------------------------------------
-------------------------------------------------------'

ttitle 'ATM CASH WITHDRAWAL TRANSACTION REPORT FOR &1 FOR BRANCH &2' skip 1 -
right 'Page : ' format 999 sql.pno skip 1 -
right 'Date : ' report_date skip 1 -
btitle left all_dashes

column tran_date heading 'Tran Date' format a10
column tran_id heading 'Tran Id' format a9
column stan heading 'STAN' format a12
column sys_date_time heading 'Sys Date Time' format a20
column cmd heading 'Tran' format a8
column cust_or_card_id heading 'ATM Card No' format a16
column acct_num heading 'A/C Number' format a16

column dr_tran_amt heading 'Debit' format b999,99,99,999.99
column cr_tran_amt heading 'Credit' format b999,99,99,999.99
column saf_ind heading 'SAF' format a5

break on cmd on report

compute sum of dr_tran_amt on cmd
compute sum of dr_tran_amt on report
compute sum of cr_tran_amt on cmd
compute sum of cr_tran_amt on report

spool swcash
select
        value_date tran_date,
        tran_id tran_id,
        substr(tran_rmks,1,4) stan,
        substr(tran_particular,14,14) sys_date_time,
        substr(tran_particular,5,8) cmd,
        substr(tran_rmks,15,16) cust_or_card_id,
        substr(tran_particular,31,12) acct_num,
        decode(part_tran_type, 'D' ,1, 0)*tran_amt cr_tran_amt,
        decode(part_tran_type, 'C' ,1, 0)*tran_amt dr_tran_amt
from DTD
where acid=(select acid from gam where foracid='&2'||'SLATMWDL')
and value_date ='&1'
and sol_id = '&2'
and del_flg='N'
and tran_particular like 'ATM/%'
UNION ALL
select
        value_date tran_date,
        tran_id tran_id,
        substr(tran_rmks,1,4) stan,
        substr(tran_particular,14,14) sys_date_time,
        substr(tran_particular,5,8) cmd,
        substr(tran_rmks,15,16) cust_or_card_id,
        substr(tran_particular,31,12) acct_num,
        decode(part_tran_type, 'D' ,1, 0)*tran_amt cr_tran_amt,
        decode(part_tran_type, 'C' ,1, 0)*tran_amt dr_tran_amt
from CTD
where acid=(select acid from gam where foracid='&2'||'SLATMWDL')
and value_date ='&1'
and sol_id='&2'
and del_flg='N'
and tran_particular like 'ATM/%'
order by 5,4
/
spool off
