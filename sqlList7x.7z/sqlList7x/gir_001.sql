-- SQL script written by Rahul Nimkar to fetch details of Bank Guarantees issued across all SOLs for a given date range
-- CRCTF33375 for Quick BG. Called from gir_001.com
set serverout on size 1000000 lines 1000 verify off feedback off pages 0
var frm_iss_date varchar2(10); 
var to_iss_date varchar2(10);
	begin
		:frm_iss_date := '&1';
		:to_iss_date := '&2';
	end;
/
spool gir_001
declare
city_nm RCT.ref_desc%type;
state_nm RCT.ref_desc%type;
cntry_nm RCT.ref_desc%type;
solid01 SOL.sol_id%type;
syschrg CXL.SYSTEM_CALC_AMT%type;
actchrg CXL.ACTUAL_AMT_COLL%type;
margamt GMMT.COLLECT_AMT%type;

cursor s1 is select sol_id from sst where set_id = 'ALL' order by 1;

cursor b1(solid03 SOL.sol_id%type) is 
select bgm.sol_id,bgm.cust_id,substr(cmg.cust_name,1,60) cus_name,bgm.bg_srl_num,bgm.issue_date,bgm.bg_class,
bgm.beneficiary_type, bgm.beneficiary_name,bgm.beneficiary_addr_1,bgm.beneficiary_addr_2,bgm.city_code,bgm.state_code,
bgm.cntry_code,bgm.pin_code, bgm.amend_rmks,bgm.purpose_of_bg,bgm.counter_bg_dtls,bgm.bg_b2kid,bgm.limit_pcnt
from bgm,cmg where cmg.cust_id = bgm.cust_id 
and bgm.sol_id = solid03 
and BGM.ISSUE_DATE >= TO_DATE(:frm_iss_date) 
and BGM.ISSUE_DATE <= TO_DATE(:to_iss_date) 
ORDER BY 1,2; 

cursor c1(bgb2kid BGM.bg_b2kid%type) is
select SYSTEM_CALC_AMT,ACTUAL_AMT_COLL from cxl where COMP_B2KID_TYPE = 'BNKGR' and comp_b2kid = bgb2kid ;

begin
for a in s1
loop
	for b in b1(a.sol_id)
	loop
	begin
		select ref_desc into city_nm from rct where ref_rec_type = '01' and ref_code = b.city_code;
		exception 
			when no_data_found then
			city_nm := '';
	end;
	begin
		select ref_desc into state_nm from rct where ref_rec_type = '02' and ref_code = b.state_code;
		exception
                        when no_data_found then
                        state_nm := '';
	end;
	begin
		select ref_desc into cntry_nm from rct where ref_rec_type = '03' and ref_code = b.cntry_code;
		exception
                        when no_data_found then
                        cntry_nm := '';
	end;
        begin
                select sum(COLLECT_AMT) into margamt from gmmt where b2kid_type = 'BNKGR' and b2kid = b.bg_b2kid and
                entity_cre_flg = 'Y';
                exception
                        when no_data_found then
                        margamt := 0.0;
        end;

	syschrg := 0;
	actchrg := 0;

	for c in c1(b.bg_b2kid)
	loop
	begin
		syschrg := syschrg + c.SYSTEM_CALC_AMT;
		actchrg := actchrg + c.ACTUAL_AMT_COLL;
	end;
	end loop;
	
		dbms_output.put_line(b.sol_id||'|'||b.cust_id||'|'||b.cus_name||'|'||b.bg_srl_num||'|'||b.issue_date||'|'||b.bg_class||'|'||b.beneficiary_type||'|'||b.beneficiary_name||'|'||b.beneficiary_addr_1||'|'||b.beneficiary_addr_2||'|'||city_nm||'|'||state_nm||'|'||cntry_nm||'|'||b.pin_code||'|'||b.amend_rmks||'|'||b.purpose_of_bg||'|'||b.counter_bg_dtls||'|'||syschrg||'|'||actchrg||'|'||margamt||'|'||b.limit_pcnt);


        syschrg := 0;
        actchrg := 0;

	end loop;
end loop;

exception
	when no_data_found then null;
	when others then null;

end;
/
spool off
