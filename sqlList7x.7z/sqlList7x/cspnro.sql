spool cspnro
select  CASH_CR_LIM_EXCP_CODE from csp
where schm_code in ('SBNRO','CANRO')
/
update csp
set  CASH_CR_LIM_EXCP_CODE = '633'
where schm_code in ('SBNRO','CANRO')
/
select  CASH_CR_LIM_EXCP_CODE from csp
where schm_code in ('SBNRO','CANRO')
/
spool off


