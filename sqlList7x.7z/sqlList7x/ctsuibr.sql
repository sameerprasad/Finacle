accept rpdt prompt "Enter the date for which report is required (dd-mm-yyyy) :: "

set echo off
set verify off feedback off pagesi 60 linesi 145 
spool ctsuibr.&rpdt

column cb noprint new_val ab  
column br heading "BR CODE" for a4
column ex heading "EXTN" for a2
column td heading "TRAN DATE" for a10
column ti heading "TRAN ID" jus cen for a10
column sh heading "SCHEME" for a5
column ib heading "IBR NUM" jus cen for a16
column dc heading "DR/CR" jus cen for a5
column am heading "TRAN AMT" jus cen for 99,99,99,990.99
column h1 heading "PARTICULAR_1" jus cen for a20
column h2 heading "PARTICULAR_2" jus cen for a20
column rp heading "ACCOUNT NUMBER" jus cen for a16

break on cb skip page 
ttitle cent " IBR ENTRY FOR THE BRANCH " ab   skip 2
btitle "--------------------------------------------------------------------------------------------------------------------------"

select contra_br_code cb,br_code br,extn_cntr_code ex,tran_date td,
entry_tran_id ti,schm_code sh,iba_num ib,
dr_cr_ind dc,tran_amt am,resp_acct_num_1 rp,ADVC_PARTCLS_1 h1,
ADVC_PARTCLS_2 h2 from ib4 where schm_code = 'HOFXP' and tran_cat_code in (' CTSU','FXCHG')
and recvd_date = '&rpdt' order by contra_br_code,br_code
/

spool off
