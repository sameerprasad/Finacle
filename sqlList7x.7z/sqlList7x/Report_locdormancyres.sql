--------------------------------------------
--File Name   : Report_locdormancy.sql 
--Description : Locker Dormancy Reset report 
--Author      : Priscilla & Vijay
--Date        : 01-06-2010
------------------------------------------

set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_locdormancyres.lst 

DECLARE

lv_solid         gam.sol_id%type :='&1';
date1	         clmt.LCHG_TIME%type := '&2';
date2	         clmt.LCHG_TIME%type := '&3';
V_ChngDate		 date;
v_riskprofile    varchar2(20);

CURSOR c1 IS

select distinct clmt.sol_id,
       clmt.cust_id ref_no,
       wlckmh.rack_id,
       clmt.LOCKER_TYPE,
       clmt.locker_num,
       substr(cmg.CUST_NAME,1,40) Hirer_name,
        (case when cmg.CUST_HLTH_CODE in ('03','02','01') then cmg.CUST_HLTH_CODE else '03' end) risk_profile,
       lcops.CHECK_DATE last_acces_Date,
           substr(wlckmh.LCHG_TIME,1,10) Mod_date,
       wlckmh.remarks reason
from   clmt,cmg,wlckmh,lcops
where  clmt.sol_id=wlckmh.sol_id
and wlckmh.sol_id = lcops.sol_id
and    lpad(clmt.cust_id,9,' ') = cmg.cust_id
and    lcops.LOCKER_NO = CLMT.LOCKER_NUM
and    lcops.cust_id = CLMT.cust_id
AND    CLMT.LOCKER_NUM = WLCKMH.LOCKER_NUM
and    clmt.sol_id = lv_solid
and    to_date(wlckmh.LCHG_TIME,'DD-MM-YYYY') between to_date(date1,'DD-MM-YYYY') and to_date(date2,'DD-MM-YYYY')
and    wlckmh.status='D'
and    clmt.del_flg != 'Y'
and    wlckmh.del_flg != 'Y'
and    wlckmh.ENTITY_CRE_FLG = 'Y'
and    clmt.ENTITY_CRE_FLG = 'Y'
order by 9,8,5;

BEGIN

    for f1 in c1
    loop
	BEGIN
	--{
		SELECT substr(LCHG_TIME,1,10) 
		INTO V_ChngDate 
		from wlckm 
		where locker_num = f1.locker_num 
		and sol_id = lv_solid
		and ENTITY_CRE_FLG = 'Y' 
		and del_flg != 'Y';
	EXCEPTION WHEN NO_DATA_FOUND THEN
		V_ChngDate := null;
	--}
	END;
	BEGIN
	--{
		SELECT REF_DESC 
		into v_riskprofile 
		FROM RCT 
		WHERE REF_REC_TYPE = '24' 
		AND REF_CODE = f1.risk_profile
		AND DEL_FLG!='Y';
	EXCEPTION WHEN NO_DATA_FOUND THEN
		v_riskprofile := null;
	--}
	END;
	v_riskprofile := f1.risk_profile ||'-'||v_riskprofile;
	 dbms_output.enable(buffer_size => NULL);	
	dbms_output.put_line(	f1.sol_id         	||'|'||
		      				f1.ref_no         	||'|'||
		      				f1.rack_id        	||'|'||	
		      				f1.LOCKER_TYPE    	||'|'||	
		      				f1.locker_num     	||'|'||
		      				f1.Hirer_name     	||'|'|| 
		      				v_riskprofile   	||'|'||	
                      		f1.last_acces_Date	||'|'||
		      				V_ChngDate			||'|'|| 
							f1.reason
		      		    ); 
   end loop; 
END;
/
spool off
