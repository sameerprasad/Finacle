--##############################################################################################
--#                     File Name       : LCWAIT.sql
--#                     Author : Mari (BBSSL)
--#                     Report : Locker Waitlist Report
--#                     Date   :
--#                     Module  : LOCKER
--#                     Called Menu     : LOCKRPT
--#                     Called By       : LCWAIT.com
--##############################################################################################

CREATE OR REPLACE PACKAGE LCWAIT_pack AS
PROCEDURE LCWAIT_proc(
			inp_str IN VARCHAR2,
			out_retcode OUT NUMBER,
			out_rec   OUT VARCHAR2
		     );
end LCWAIT_pack;
/
CREATE OR REPLACE PACKAGE BODY LCWAIT_pack AS
v_sol_id		GAM.sol_id%TYPE;
v_date			date;
v_app_date		date;
v_waitupto		date;
v_waitlist_no		CLWT.WAITLIST_NO%TYPE;
v_cust_id		CMG.cust_id%TYPE;
v_cust_name		cmg.cust_name%TYPE;
v_lock_type		CLWT.LOCKER_TYPE%TYPE;
v_lock_size		CLWT.LOCKER_SIZE%TYPE;
v_prior_flg		CHAR(1);
v_lock_period		CLWT.locker_period%TYPE;

CURSOR LCWAIT(v_sol_id GAM.sol_id%TYPE,v_date date) IS
				SELECT 
					CLWT.LOCKER_TYPE,
					CLWT.LOCKER_SIZE,
					CLWT.cust_id,
					CLWT.CUST_NAME,
					CLWT.WAITLIST_NO,
					CLWT.APP_DATE,
					CLWT.LOCKWAIT_DATE,
					CLWT.PRIOR_FLG,
					CLWT.LOCKER_PERIOD
				FROM
					CLWT
				WHERE
					SOL_ID = v_sol_id
				AND	APP_DATE <= to_date(v_date,'dd-mm-yyyy')
				AND	LOCKWAIT_DATE >=  to_date(v_date,'dd-mm-yyyy')
				AND	DEL_FLG != 'Y'
				AND	ENTITY_CRE_FLG != 'N'
				AND	STATUS IS NULL
				ORDER BY LOCKER_TYPE,WAITLIST_NO,LOCKWAIT_DATE;
				
OutArr	basp0099.ArrayType;
	PROCEDURE LCWAIT_proc
	(
		inp_str IN varchar2,
		out_retcode  OUT number,
		out_rec  OUT varchar2
	) AS
BEGIN
	out_retcode := 0;
	IF (NOT LCWAIT%ISOPEN) THEN
		basp0099.formInputArr(inp_str,outArr);
			v_sol_id	:=	outArr(0);
			v_date	:=	outArr(1);
			
		OPEN LCWAIT(v_sol_id,v_date);
	END IF;

	IF(LCWAIT%ISOPEN) THEN
			FETCH LCWAIT into
					v_lock_type,
					v_lock_size,
					v_cust_id,
					v_cust_name,
					v_waitlist_no,
					v_app_date,
					v_waitupto,
					v_prior_flg,
					v_lock_period;
	END IF;
				
	IF(LCWAIT%NOTFOUND) THEN
			close LCWAIT;
			out_retcode := 1;
			return;

		END IF;	
		
	
		
			out_rec :=
					v_lock_type		||'|'||
					v_lock_size		||'|'||
					v_cust_id		||'|'||
					v_cust_name		||'|'||
					v_waitlist_no		||'|'||
					v_app_date		||'|'||
					v_waitupto		||'|'||
					v_prior_flg		||'|'||
					v_lock_period;
			return;

end LCWAIT_proc;
end LCWAIT_pack;
/
drop public synonym LCWAIT_pack
/
create or replace public synonym LCWAIT_pack for LCWAIT_pack
/
grant execute on LCWAIT_pack to tbautil, tbacust, tbagen,tbaadm
/
			
				
			
