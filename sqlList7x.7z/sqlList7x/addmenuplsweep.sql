rem this sql is to add new menu option

spool addmenuopt
create table temp50
as (select * from oat where mop_id = 'ICIFSTMT' )
/
update temp50
set mop_id = 'PLSWEEP'
/
insert into oat
(select * from temp50)
/

create table temp51
as (select * from mod where mop_id = 'ICIFSTMT')
/

update temp51
set mop_id = 'PLSWEEP'
/

update temp51
set input_filename = ''
/

update temp51
set exe_name = 'fxsweep.com'
/

insert into mod
(select * from temp51)
/
update mod set mop_type='G' where mop_id='PLSWEEP';

create table temp52
as (select * from mod_txt where mop_id = 'ICIFSTMT')
/

update temp52
set mop_id = 'PLSWEEP'
/

update temp52
set user_mop_id = 'PLSWEEP'
/

update temp52
set mop_text  = 'P'||'&'||'L Sweeping of Balances'
/

insert into mod_txt
(select * from temp52)
/

drop table temp50
/

drop table temp51
/

drop table temp52
/

spool off
