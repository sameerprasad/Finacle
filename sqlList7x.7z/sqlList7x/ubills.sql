---alter session set optimizer_goal = RULE;
set pages 0
set lines 98
set feedback on
set termout on
set verify off
spool /tmp/&3
select 'Unverified Bills'||'|'||
       audit_date        ||'|'||
       table_name        ||'|'||
	   table_key         ||'|'||
	   substr(rmks,1,40) ||'|'||
	   init_sol_id       ||'|'||
	   audit_sol_id      ||'|'
from   adt 
where  init_sol_id='&1' 
and    auth_id = '!' 
and    table_name in ('FBM','BLT')
/
spool off

