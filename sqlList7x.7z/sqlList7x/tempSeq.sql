drop    sequence        icici.srl_seq;
drop    public          synonym         srl_seq;
create  sequence        icici.srl_seq increment by 1 START WITH 1
        minvalue        1               maxvalue 9999999999 nocycle nocache;
create  public          synonym srl_seq for icici.srl_seq;
grant   select          on              icici.srl_seq to tbautil,tbagen,tbacust;
