drop table AC_FULL_TABLE
/
drop public synonym TBA_AC_FULL_TBL
/
drop public synonym ACFF
/
create table AC_FULL_TABLE
(
	foracid				varchar(20),
	schm_code			varchar(5),
	mode_of_oper_code	varchar(5),
	cust_id				varchar(20),
	acct_opn_date		date
)
/

create public synonym TBA_AC_FULL_TBL
	for AC_FULL_TABLE
/
create public synonym ACFF
	for AC_FULL_TABLE
/
grant select, insert, update, delete on TBA_AC_FULL_TBL to icici
/
grant select, insert, update, delete on TBA_AC_FULL_TBL to tbagen
/
grant select on TBA_AC_FULL_TBL to tbacust
/
grant select on TBA_AC_FULL_TBL to tbautil
/
