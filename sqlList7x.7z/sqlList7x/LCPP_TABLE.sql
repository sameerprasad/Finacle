Rem     This file will create LOCKER_PAYABLE_PAID
Rem     with the following characteristics.

Rem     Coded by : Chandra Sekar (BBSSL)

Rem     Module  : LOCKER


Rem TABLE NAME: LOCKER_PAYABLE_PAID

Rem SYNONYM:    LOCKER_PAYABLE_PAID

drop table icici.LOCKER_PAYABLE_PAID
/
drop public synonym LCPP
/
create table icici.LOCKER_PAYABLE_PAID
( 
	sol_id varchar2(8),
	cust_id varchar2(9),
	locker_number varchar2(12),
	rent_payable_amount number(20,4) default 0,
	rent_paid_amount number(20,4) default 0,
	charge_payable_amount number(20,4) default 0,
	charge_paid_amount number(20,4) default 0,
	tax_paid number(20,4) default 0,
	del_flg char(1)
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
create public synonym LCPP for icici.LOCKER_PAYABLE_PAID
/
create index IDX_LCPP on icici.LOCKER_PAYABLE_PAID( SOL_ID,CUST_ID,LOCKER_NUMBER )
/
grant select, insert, update, delete on LCPP to tbagen
/
grant select on LCPP to tbacust
/
grant select on LCPP to tbautil
/
grant all on LCPP to tbaadm
/
