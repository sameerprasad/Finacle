set echo off 
set pause off
set pages 0

rem Script For Generating List Of Customers Opened Today.
rem This will be used to generate a letter of thanks for banking
rem with ICICI. The letter template is cust.let
rem
rem Note that this has to be run every day. Else, the data is lost.
rem
rem Input parameters in command line -
rem	None
rem
rem Tables accessed -
rem       CMG, RCT.
rem
rem The table RCT is used to pick up the address of the customer
rem from the codes given in CMG.
rem
rem This script can be run at any time During the Day.

set termout off
set verify off
set wrap on
set feedback off
set linesize 246
set space 1
set heading off

spool  &1 

select	decode(cust_title_code,NULL,' ',cust_title_code)||'|'||
	cust_name||'|'||
	decode(cust_comu_addr1,NULL,' ',cust_comu_addr1)||'|'||
	decode(cust_comu_addr2,NULL,' ',cust_comu_addr2)||'|'||
	b.ref_desc||'|'||
	decode(c.ref_desc,NULL,' ',c.ref_desc)||'|'||
        decode(d.ref_desc,NULL,' ',d.ref_desc)||'|'||
	decode(cust_comu_pin_code,NULL,' ',cust_comu_pin_code)||'|'||
	decode ( cust_title_code, 'M/S', 'Sirs', cust_title_code )||'|'||
	decode ( cust_title_code, 'M/S', ' ', cust_name )||'|'
from	rct b, rct c, rct d,cmg,gam
where gam.foracid = '&2'
and cmg.cust_id = gam.cust_id 
and 	cmg.entity_cre_flg = 'Y'
and	cmg.del_flg != 'Y'
and	b.ref_rec_type = '01'
and	b.ref_code = cust_comu_city_code
and	b.del_flg != 'Y'
and	c.ref_rec_type = '02'
and	c.ref_code = cust_comu_state_code
and	c.del_flg != 'Y'
and	d.ref_rec_type = '03'
and	d.ref_code = cust_comu_cntry_code
and	d.del_flg != 'Y' 
/
spool off
exit
