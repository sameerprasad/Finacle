rem : this is a sample script
rem : SBNRE has to be replaced with correct schm_code

set echo off
set pause off
set verify off
whenever sqlerror exit sql.sqlcode
set feedback off
set linesize 85
set pages 0
set newpage 0
set space 0
set head off

col foracid format 'A15'
col acct_name format 'A40'
col PIPE1 format 'A1'
col PIPE2 format 'A1'
col PIPE3 format 'A1'
col PIPE4 format 'A1'
col RDATE1 format 'A8'
col RDATE2 format 'A8'

spool ACCTIMP1

select 
	   foracid, 
	   '|' PIPE1,
       acct_name,
	   '|' PIPE2,
       to_char(acct_opn_date,'yyyymmdd') RDATE1,
	   '|' PIPE3,
       to_char(acct_cls_date,'yyyymmdd') RDATE2,
	   '|' PIPE4,
	   sol_id
from gam
where foracid= '&1'
/
--where schm_code='CABRK' 
spool off
set verify on
set feedback on
set termout on
