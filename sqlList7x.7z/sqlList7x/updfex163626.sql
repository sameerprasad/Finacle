
rem This is an update script required for fex transactions
rem in version 1.6.36.27
rem by shashi/25-03-2000

spool updfex163626.lst

update let
set sql_parameter_format = 'FROM (DD-MM-YYYY) TO (BOD) (DD-MM-YYYY) SOL ID'
where letter_id in ('ABDUE','BEF1','BEF2','BEF3','BGEXP','BIDUE','LCPAY')
/
-- This script is prepared for updating revaluationaccount bacid
-- to EXFX-OTHERS for branches   and seed database
-- author murali reviewed by Shashi
select schm_Code, fcnr_Reval_bacid, crncy_code
from csp
where crncy_code != 'INR'
/
update csp
set fcnr_reval_bacid='EXFX-OTHERS'
where crncy_code !='INR'
/
select schm_Code, fcnr_Reval_bacid, crncy_code
from csp
where crncy_code != 'INR'
/
--update GSPM for autorenewal for FCNR
select auto_renewal_flg, perd_mths_for_auto_renew from tsp
where schm_code in ('FDHUS','FDHGB','FDHDM','FDHEU','FDHJY','CFDUS','CFDGB',
'CFDDM','CFDEU','CFDJY')
/
update tsp
set auto_renewal_flg = 'U',
perd_mths_for_auto_renew = '12'
where schm_code in ('FDHUS','FDHGB','FDHDM','FDHEU','FDHJY','CFDUS','CFDGB',
'CFDDM','CFDEU','CFDJY')
/
select schm_code, auto_renewal_flg, perd_mths_for_auto_renew from tsp
where schm_code in ('FDHUS','FDHGB','FDHDM','FDHEU','FDHJY','CFDUS','CFDGB',
'CFDDM','CFDEU','CFDJY')
/
-- this will take care of ADMA 3/2000 for reporting XOS 
-- thecriteria has been changed to 180 days from date of shipment
select reg_type,reg_sub_type,SHIPMENT_DATE_GRACE_DAYS,OVERDUE_REPORT_CRITERIA from fxp
where reg_type in ('FOBP','FBPF','FOBC') 
/
update fxp
set SHIPMENT_DATE_GRACE_DAYS = 180,
OVERDUE_REPORT_CRITERIA = 'S'
where reg_type in ('FOBP','FBPF','FOBC')
/
select reg_type,reg_sub_type,SHIPMENT_DATE_GRACE_DAYS,OVERDUE_REPORT_CRITERIA from fxp
where reg_type in ('FOBP','FBPF','FOBC') 
/
-- This will blank out the Charge code indicator in DCRM in case of Outward DCs
select reg_type,dc_chrg_code from dcrm
where DC_CHRG_CODE in ('IMPORTDC','INLANDDC')
/
update DCRM
set DC_CHRG_CODE = NULL
where DC_CHRG_CODE in ('IMPORTDC','INLANDDC')
/
select reg_type,dc_chrg_code from dcrm
where DC_CHRG_CODE in ('IMPORTDC','INLANDDC')
/
select gam.foracid, gam.schm_code,tam.auto_renewal_flg, tam.perd_mths_for_auto_renew, tam.auto_renewal_schm_code, tam.AUTO_RENWL_GL_SUBHEAD_CODE, tam.auto_renewal_int_tbl_code,itc.int_tbl_code from tam, gam,itc
where gam.acid = tam.acid
and itc.acid = gam.acid
and itc.acid = tam.acid
and gam.acct_cls_flg = 'N'
and gam.gl_sub_head_code = '20010'
and tam.auto_renewal_flg = 'N' 
and itc.int_tbl_code = (select max(int_tbl_code) from itc z
						where z.acid = gam.acid
						and z.acid = tam.acid)
and (tam.safe_custody_flg = 'Y' or tam.print_cntr < 1)
/
update tam
set perd_mths_for_auto_renew = '12'
where tam.acid in (select acid from gam
					where gam.acct_cls_flg = 'N'
					and gam.gl_sub_head_code = '20010')
and tam.auto_renewal_flg = 'N'
and (tam.safe_custody_flg = 'Y' or tam.print_cntr < 1)
/
update tam
set auto_renewal_schm_code = (select schm_code from gam 
                               where  gam.acid = tam.acid)
where tam.acid in (select acid from gam
					where gam.acct_cls_flg = 'N'
					and gam.gl_sub_head_code = '20010')
and tam.auto_renewal_flg = 'N'
and (tam.safe_custody_flg = 'Y' or tam.print_cntr < 1)
/
update tam
set auto_renwl_gl_subhead_code = '20010'
where tam.acid in (select acid from gam   
					where gam.acct_cls_flg = 'N'
					and gam.gl_sub_head_code = '20010')
and tam.auto_renewal_flg = 'N' 
and (tam.safe_custody_flg = 'Y' or tam.print_cntr < 1)
/
update tam
set auto_renewal_int_tbl_code = (select int_tbl_code from itc,gam
								where tam.acid = itc.acid
								and gam.acid = tam.acid
								and gam.acid = itc.acid
								and int_tbl_code_srl_num =(select max(int_tbl_code_srl_num) from itc z
								where z.acid = tam.acid ))
where tam.acid in (select acid from gam   
					where gam.acct_cls_flg = 'N'
					and gam.gl_sub_head_code = '20010')
and tam.auto_renewal_flg = 'N'
and (tam.safe_custody_flg = 'Y' or tam.print_cntr < 1)
/
update tam
set tam.auto_renewal_flg = 'U'
where tam.auto_renewal_flg = 'N'
and tam.acid in (select acid from gam   
					where gam.acct_cls_flg = 'N'
					and gam.gl_sub_head_code = '20010')
and (tam.safe_custody_flg = 'Y' or tam.print_cntr < 1)
/
select gam.foracid, gam.schm_code,tam.auto_renewal_flg, tam.perd_mths_for_auto_renew, tam.auto_renewal_schm_code, tam.AUTO_RENWL_GL_SUBHEAD_CODE, tam.auto_renewal_int_tbl_code,itc.int_tbl_code from tam, gam,itc
where gam.acid = tam.acid
and itc.acid = gam.acid
and itc.acid = tam.acid
and gam.acct_cls_flg = 'N'
and gam.gl_sub_head_code = '20010'
and itc.int_tbl_code = (select max(int_tbl_code) from itc z
						where z.acid = gam.acid
						and z.acid = tam.acid)
/
--The XOS reporting criteria has been changed from due date to
-- 180 days from the shipment date
--In this sql we are updating the xos due date field to shipment date in FEI
-- table and then again update it with shpmnt_date = 180 days
set heading off
select ' ' from dual;
select 'THE FOLLOWING SQL WILL TAKE SOME TIME PLEASE WAIT' from dual;
select ' ' from dual;
select ' ' from dual;
select ' ' from dual;
update fba z
set z.xos_rep_due_date = (select b.shpmnt_date from fbm a,fei b
			where a.bill_id = b.bill_id
			and a.bill_id = z.bill_id
			and z.bill_id = b.bill_id
			and a.bill_stat in ('G','P','K','O','N')
			and a.reg_type in ('FOBC','FOBP','FBPF'))
where z.bill_id = (select fbm.bill_id from fbm,fei
			where fbm.bill_id = fei.bill_id
			and fei.bill_id = z.bill_id
			and z.bill_id = fbm.bill_id
			and fbm.sol_id = fei.sol_id
			and z.sol_id = fei.sol_id
			and z.sol_id = fbm.sol_id
			and fbm.bill_stat in ('G','P','K','O','N')
			and fbm.reg_type in ('FOBC','FOBP','FBPF'))
/
update fba
set xos_rep_due_date = xos_rep_due_date + 180
where fba.bill_id = (select fbm.bill_id from fbm,fei
			where fbm.bill_id = fei.bill_id
			and fei.bill_id = fba.bill_id
			and fba.bill_id = fbm.bill_id
			and fbm.sol_id = fei.sol_id
			and fba.sol_id = fei.sol_id
			and fba.sol_id = fbm.sol_id
			and fbm.bill_stat in ('G','P','K','O','N')
			and fbm.reg_type in ('FOBC','FOBP','FBPF'))
/
set heading on
-- for updating Report codes in GSPM
-- by murali
-- to bring about consistancy in tran report code vis a vis schm_code

insert into rct values
('10','EEUSB','N','EEFC EURO SB','UPDATED',sysdate,'UPDATED',sysdate)
/
commit
/
insert into rct values
('10','CFDEU','N','FCNR CUM FD EURO','UPDATED',sysdate,'UPDATED',sysdate)
/
commit
/
insert into rct values
('10','CFEEU','N','EEFC CUM- EURO','UPDATED',sysdate,'UPDATED',sysdate)
/
commit
/
insert into rct values
('10','FDHEU','N','FCNR -TRAD-HLY EUR','UPDATED',sysdate,'UPDATED',sysdate)
/
commit
/
insert into rct values
('10','RFEUH','N','RFC-TRAD-PLAN-HRLY-EUR','UPDATED',sysdate,'UPDATED',sysdate)
/
commit
/
insert into rct values
('10','REUSB','N','RFC -EUR-SB','UPDATED',sysdate,'UPDATED',sysdate)
/
commit
/
insert into rct values
('10','EFEUH','N',' EEFC HYRLY TRAD PLAN EURO','UPDATED',sysdate,'UPDATED',sysdate)
/
commit
/
insert into rct values
('10','CFREU','N','RFC CUM PLAN EURO','UPDATED',sysdate,'UPDATED',sysdate)
/
commit
/
insert into rct values
('10','EFEUD','N','EUR -D-FIXED DEPOSIT','UPDATED',sysdate,'UPDATED',sysdate)  
/
commit
/
insert into rct values
('10','RFEUD','N','RFC-EUF-D-FIXED DEPOSIT','UPDATED',sysdate,'UPDATED',sysdate)
/
commit
/
insert into rct values
('10','EEUCA','N','FC EUR CURRENT ACCOUNT','UPDATED',sysdate,'UPDATED',sysdate)
/
commit
/
insert into rct values
('10','SBNRE','N','SAVINGS BANK NRE','UPDATED',sysdate,'UPDATED',sysdate)
/
commit
/
--updates str tables with the above report codes where the report codes are wrong

update STR
set tran_rpt_code = schm_code 
where tran_rpt_code = 'EUSSB'
and schm_code = 'EEUSB' 
/
update STR
set tran_rpt_code = schm_code 
where tran_rpt_code = 'CFDDM'
and schm_code = 'CFDEU' 
/
update STR
set tran_rpt_code = schm_code 
where tran_rpt_code = 'CFEUS'
and schm_code = 'CFEEU' 
/
update STR
set tran_rpt_code = schm_code 
where tran_rpt_code = 'FDHDM'
and schm_code = 'FDHEU' 
/
update STR
set tran_rpt_code = schm_code 
where tran_rpt_code = 'RFUSH'
and schm_code = 'RFEUH' 
/
update STR
set tran_rpt_code = schm_code 
where tran_rpt_code = 'RUSSB'
and schm_code = 'REUSB' 
/
update STR
set tran_rpt_code = schm_code 
where tran_rpt_code = 'EFUSH'
and schm_code = 'EFEUH' 
/
update STR
set tran_rpt_code = schm_code 
where tran_rpt_code = 'CFRUS'
and schm_code = 'CFREU' 
/
update STR
set tran_rpt_code = schm_code 
where tran_rpt_code = 'EFDMD'
and schm_code = 'EFEUD' 
/
update STR
set tran_rpt_code = schm_code 
where tran_rpt_code = 'RFUSD'
and schm_code = 'RFEUD' 
/
-- This will insert the values of EEUCA as tran report code in schm_code EEUCA
insert into str
values ('EEUCA','EEUCA','EUR',999999999999.00,999999999999.00)
/
commit
/
insert into str
values ('SBNRE','SBNRE','EUR',999999999999.00,999999999999.00)
/
commit
/
update csp
set int_debit_rpt_code = schm_code,
	int_credit_rpt_code = schm_code
where schm_code = 'SBNRE'
/
spool off
exit
