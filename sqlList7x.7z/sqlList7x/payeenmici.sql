set serveroutput on size 1000000
set feedback off
set verify off
set linesize 500
set trims on
set termout off
set numformat 999D09
spool &1-&2-&3-&7..dat

DECLARE
particular	CTD.TRAN_PARTICULAR%TYPE;
loc_acid         GAM.foracid%TYPE;
custStat	CMG.cust_stat_code%type;
instr		CTD.INSTRMNT_NUM%TYPE;
dummy		number;
solId                           ICI.sol_id%type;
tranDate                        ICI.zone_date%TYPE;
zoneId                        ICI.zone_code%TYPE;
recNotFound                     number;
recFnd                     number;
dtdFound                     number;
dbDate                        ICI.zone_date%TYPE;

CURSOR  CUR_ZONE IS
        select zone_code,zone_date,
		acid,zone_srl_num,tran_particulars ,inst_num,inst_amt,tran_rmks
		from ICI 
		where SOL_ID = solId 
		and ZONE_CODE = zoneId
		and ZONE_DATE=tranDate;

BEGIN--{

		solId := '&5';
		tranDate := '&4';
		zoneId := '&6';
		dtdFound :=0;
		recFnd :=0;

--		select to_char(db_stat_date,'DD-MM-YYYY') into dbDate from gct ;
        FOR CUR_ZONE_REC in CUR_ZONE

        LOOP--{
		recNotFound := 0;
		loc_acid := '';
		if ( recFnd = 0 ) then
			dbms_output.put_line('PNM');
--		dbms_output.put_line('Sol '||'|'||'ZoneCode'||'|'||'Zone Date'||'|'||'|'||'Srl No.'||'|'||'Acid'||'|'||'Foracid'||'|'||'Number'||'|'||'Amount'||'|'||'Payee Name'||'|'||'Customer Status');
		end if;
		recFnd := recFnd + 1;
    	begin--{
			
			select gam.foracid, cmg.cust_stat_code 
			into loc_acid,custStat
			from GAM,CMG 
			where gam.ACID=CUR_ZONE_REC.acid and gam.acct_ownership != 'O' and gam.cust_id = cmg.cust_id;	

		exception
				when no_data_found then 
				recNotFound := 1;
		end;--}
		if ( recNotFound = 0 ) then
				dbms_output.put_line(solId||'|'||CUR_ZONE_REC.zone_code||'|'||CUR_ZONE_REC.zone_date||'|'||CUR_ZONE_REC.zone_srl_num||'|'||CUR_ZONE_REC.acid||'|'||loc_acid||'|'||CUR_ZONE_REC.inst_num||'|'||to_char(CUR_ZONE_REC.inst_amt,'99999999999.99')||'|'||CUR_ZONE_REC.tran_particulars||'|'||custStat);
		end if;
		recNotFound :=0;
       END LOOP;--}
END;--}
/
set termout on
spool off
