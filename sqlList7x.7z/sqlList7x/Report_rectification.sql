--------------------------------------------
--File Name   : Report_rectification.sql 
--Description : Rectification Entries Passed report 
--Author      : Priscilla & Vijay
--Date        : 02-06-2010
------------------------------------------
set serveroutput on size 1000000
set head off
set pau off
set echo off
set lines 250
set pages 0
set termout off
set verify off
set feedback off
spool Report_rectification.lst 

DECLARE

    v_solid            	wlckm.sol_id%type:='&1';
	v_frmdt			clrt.REV_TRAN_DATE%type:= '&2';
	v_todt			clrt.REV_TRAN_DATE%type:= '&3';
	v_RACK_ID          	wlckm.RACK_ID%type;
	v_LOCKER_NUM       	clnd.LOCKER_NUM%type;
	v_locker_type           wlckm.locker_type%type;	
	v_REV_TRAN_ID           clrt.REV_TRAN_ID%type;
	v_REV_TRAN_DATE         clrt.REV_TRAN_DATE%type;
	v_cust_id               clmt.cust_id%type;
	v_tran_amt 	 	dctd_acli.tran_amt%type;
	v_part_tran_type 	dctd_acli.part_tran_type%type;
	v_entry_user_id  	dctd_acli.entry_user_id%type;
	v_TRAN_RMKS1     	dctd_acli.TRAN_RMKS%type;
	v_VFD_USER_ID    	dctd_acli.VFD_USER_ID%type;
	v_TRAN_RMKS2     	dctd_acli.TRAN_RMKS%type;
	v_PSTD_DATE      	dctd_acli.PSTD_DATE%type;



 
cursor c1(v_solid varchar2,v_frmdt date,v_todt date) is 
select
        clrt.REV_TRAN_DATE RevTranDate,
        clrt.cust_id CustId,
        clrt.locker_num LockNum,
        wlckm.rack_id RackId,
        wlckm.locker_type LockType,
        clrt.REV_TRAN_ID RevTranId
from clrt,wlckm,clmt
where clrt.LOCKER_NUM = wlckm.LOCKER_NUM
and clmt.locker_num = clrt.locker_num
and clrt.sol_id = wlckm.sol_id
and clrt.cust_id = clmt.cust_id
and clrt.sol_id = v_solid
and clrt.ENTITY_CRE_FLG = 'Y'
and clrt.REV_TRAN_DATE between to_date(v_frmdt,'dd-mm-yyyy') and to_date(v_todt,'dd-mm-yyyy')
and clrt.del_flg !='Y'
and clmt.del_flg!='Y'
and wlckm.del_flg!='Y'
order by 1,6,3; 

cursor c2(v_solid varchar2,v_REV_TRAN_ID varchar2,v_REV_TRAN_DATE varchar2) is
select  tran_amt TranAmt,
        part_tran_type PartTranType,
        entry_user_id EntryUserId,
        TRAN_RMKS TranRmks1,
        VFD_USER_ID VfdUserId,
        TRAN_RMKS TranRmks2,
        PSTD_DATE PstdDate
from    dctd_acli
where   tran_id = lpad(v_REV_TRAN_ID,9,' ')
and     tran_DATE = v_REV_TRAN_DATE
and     dctd_acli.sol_id = v_solid
and	del_flg!='Y';
      
BEGIN
	for i in c1(v_solid,v_frmdt,v_todt)
    LOOP
        for j in c2(v_solid,i.RevTranId,i.RevTranDate)
        LOOP
		dbms_output.enable(buffer_size => NULL);
		dbms_output.put_line (
                                        i.RevTranDate      ||'|'||
                                        i.CustId             ||'|'||
                                        i.LockNum         ||'|'||
                                        i.RackId            ||'|'||
                                        i.LockType        ||'|'||
                                        i.RevTranId        ||'|'||
                                        j.TranAmt            ||'|'||
                                        j.PartTranType     ||'|'||
                                        j.EntryUserId      ||'|'||
                                        j.TranRmks1         ||'|'||
                                        j.VfdUserId        ||'|'||
                                        j.TranRmks2         ||'|'||
                                        j.PstdDate
                                );
        END LOOP;
    end loop;
END;	   			
/
spool off
