set head off
set verify off
set feedback off
set pages 0
set term off
set echo off
set trims on
spool sbdr_acct.lst
select 
sol_id||'|'||foracid||'|' 
from gam,gsp
where gam.schm_code = gsp.schm_code
and gsp.schm_type = 'SBA'
and acct_cls_flg != 'Y'
and (clr_bal_amt+un_clr_bal_amt) < 0
/
spool off
exit
