--##############################################################################################
--#                     File Name       : lcrsi.sql
--#                     Author : Ashwani Bhat (BBSSL)
--#                     Report : Revision Of Locker Rent
--#                     Date   :
--#                     Module  : LOCKER
--#                     Called Menu     : LOCKRPT
--#                     Called By       : lcrsi.com
--##############################################################################################

CREATE OR REPLACE PACKAGE rntrpt_pack AS
PROCEDURE rntrpt_proc (
		inp_str IN varchar2,
		out_retcode OUT number,
		out_rec OUT varchar2
		);

END rntrpt_pack;
/
CREATE OR REPLACE PACKAGE BODY rntrpt_pack AS   

v_locker_type		wlckm.locker_type%type;
v_locker_no		clmt.locker_num%type;
v_locker_period		clrm.rent_period%type;
v_key_no		clmt.locker_key_num%type;
v_cust_name		cmg.cust_name%type;
v_add1			varchar2(200);
v_add2			varchar2(200);
v_RENT_EFFECTIVE_DATE	date;
v_Loc_code		sst.set_id%type;
v_rent_code		clrm.rent_version_code%type;
rent_amt		clrm.rent_amt%type;
v_sno			varchar2(30):= null;
v_custid		cmg.cust_id%type;
v_next_exec_date	sih.next_exec_date%type;
v_pin			cmg.cust_comu_pin_code%type;
v_sol_id		clrm.sol_id%type;
v_SI_flg		varchar2(200);

CURSOR rntrpt (v_sol_id  clrm.sol_id%type) IS
	select 	distinct SI_SRL_NUM, 
		SUBSTR(rmks_free_text,8,12),
		SUBSTR(rmks_free_text,6,1)
	from	sih,clmt
	where	sih.sol_id = clmt.sol_id
	AND	locker_num = SUBSTR(rmks_free_text,8,12)	
	AND	sih.sol_id = v_sol_id
	AND	SI_SRL_NUM is not null
	AND	sih.ENTITY_CRE_FLG = 'Y'
	AND	clmt.del_flg = 'N'
	AND	sih.del_flg = 'N';

CURSOR rntrptAll (v_sol_id  clrm.sol_id%type) IS
	select 	LOCKER_NUM,
		LOCKER_PERIOD,
		CUST_ID,
		LOCKER_KEY_NUM
	from	clmt
	where	clmt.sol_id = v_sol_id
	AND	clmt.del_flg = 'N';

	OutArr	basp0099.ArrayType;

PROCEDURE rntrpt_proc
(
	inp_str IN varchar2,
	out_retcode  OUT number,
	out_rec  OUT varchar2
) AS
BEGIN

	out_retcode := 0;

	
		basp0099.formInputArr(inp_str,outArr);	
		v_sol_id := outArr(0);
		v_SI_flg := outArr(1);


	IF (v_SI_flg = 'Y') THEN
		IF (NOT rntrpt%ISOPEN) THEN
			OPEN rntrpt (v_sol_id);
		END IF;
	ELSE
		IF (NOT rntrptAll%ISOPEN) THEN
			OPEN rntrptAll (v_sol_id);
		END IF;
	END IF;

	IF (rntrpt%ISOPEN) THEN
		FETCH rntrpt INTO	v_sno,
					v_locker_no,
					v_locker_period;
	END IF;

	IF (rntrpt%ISOPEN AND rntrpt%NOTFOUND) THEN
		close rntrpt;
		out_retcode := 1;
		return;
	END IF;

	IF (rntrptAll%ISOPEN) THEN
		FETCH rntrptAll INTO	v_locker_no,
					v_locker_period,
					v_custid,
					v_key_no;
	END IF;

	IF(rntrptAll%ISOPEN AND rntrptAll%NOTFOUND) THEN
		close rntrptAll;
		out_retcode := 1;
		return;
	END IF;

	BEGIN
		select	locker_type 
		into	v_locker_type 
		from	wlckm 
		where	locker_num = v_locker_no
		AND	sol_id = v_sol_id;
		EXCEPTION WHEN NO_DATA_FOUND THEN
			v_locker_type := null;
	END;

	BEGIN
		select		set_id 
		into		v_Loc_code
		from		sst 
		where		set_id like  'LOC%' 
		AND		sol_id = v_sol_id;
		EXCEPTION WHEN NO_DATA_FOUND THEN
			v_Loc_code :=	null;
	END;

	BEGIN
		SELECT		a.RENT_EFFECTIVE_DATE
		into		v_RENT_EFFECTIVE_DATE
		FROM		CLRM a 
		WHERE		a.sol_id = v_sol_id
		AND			a.locker_type = v_locker_type
		AND			a.location_code =  v_Loc_code
		AND			a.rent_period = v_locker_period
		AND			a.rent_version_code = (select max(b.rent_version_code)
									from clrm b
									where a.sol_id = b.sol_id AND
									a.locker_type = b.locker_type AND
									a.location_code = b.location_code AND 
									a.rent_period = b.rent_period AND
									b.RENT_EFFECTIVE_DATE = (select max(c.rent_effective_date)
														from clrm c
													        where b.sol_id = c.sol_id AND
					                                                                        b.locker_type = c.locker_type AND
										                                b.location_code = c.location_code AND
					                                                                        b.Rent_period = c.Rent_period))
		AND  a.del_flg != 'Y' 
		AND  a.entity_cre_flg != 'N';
		EXCEPTION WHEN NO_DATA_FOUND THEN 
			BEGIN
				SELECT	a.RENT_EFFECTIVE_DATE
				into	v_RENT_EFFECTIVE_DATE
				FROM	CLRM a 
				WHERE	a.sol_id = '0000'
				AND		a.locker_type = v_locker_type
				AND		a.location_code =  v_Loc_code
				AND		a.rent_period = v_locker_period
				AND		a.rent_version_code = (select max(b.rent_version_code)
										from clrm b
										where a.sol_id = b.sol_id AND
										a.locker_type = b.locker_type AND
										a.location_code = b.location_code AND 
										a.rent_period = b.rent_period AND
										b.RENT_EFFECTIVE_DATE = (select max(c.rent_effective_date)
														from clrm c
													        where b.sol_id = c.sol_id AND
					                                                                        b.locker_type = c.locker_type AND
										                                b.location_code = c.location_code AND
					                                                                        b.Rent_period = c.Rent_period))
				AND  a.del_flg != 'Y' 
				AND  a.entity_cre_flg != 'N';
				exception when no_data_found then 
					v_RENT_EFFECTIVE_DATE	:= null;
		END;
	END;

	BEGIN
		select a.rent_version_code into v_rent_code
		from clrm a
		where a.sol_id = v_sol_id AND
		a.locker_type = v_locker_type AND
		a.location_code = v_Loc_code AND 
		a.rent_period = v_locker_period AND 
		a.RENT_EFFECTIVE_DATE = (select max(b.rent_effective_date)
						from clrm b
					        where a.sol_id = b.sol_id AND
			                        a.locker_type = b.locker_type AND
				                a.location_code = b.location_code AND
						a.Rent_period = b.Rent_period)
		AND  a.del_flg != 'Y' 
		AND  a.entity_cre_flg != 'N';
		EXCEPTION WHEN OTHERS then
		BEGIN
			select max(a.rent_version_code) into v_rent_code
			from clrm a
			where a.sol_id = '0000' AND
			a.locker_type = v_locker_type AND
			a.location_code = v_Loc_code AND 
			a.rent_period = v_locker_period AND
			a.RENT_EFFECTIVE_DATE = (select max(b.rent_effective_date)
							from clrm b
							where a.sol_id = b.sol_id AND
							a.locker_type = b.locker_type AND
							a.location_code = b.location_code AND
							a.Rent_period = b.Rent_period)
			AND  a.del_flg != 'Y' 
			AND  a.entity_cre_flg != 'N';
			exception when no_data_found then 
				v_rent_code := null;
		END;
	END;

	BEGIN
		IF (v_SI_flg = 'Y') THEN
			BEGIN
				SELECT	next_exec_date,
					locker_key_num,
					clmt.cust_id,
					cmg.cust_name,
					nvl(cust_comu_addr1, cust_perm_addr1),
					nvl(cust_comu_addr2, cust_perm_addr2),
					nvl(CUST_COMU_PIN_CODE, CUST_PERM_PIN_CODE)
				into	v_next_exec_date,
					v_key_no,
					v_custid,
					v_cust_name,
					v_add1,
					v_add2,
					v_pin
				FROM	sih,clmt,cmg
				WHERE	sih.sol_id = clmt.sol_id
				AND	locker_num = v_locker_no
				AND	clmt.locker_num = SUBSTR(rmks_free_text,8,12)
				AND	clmt.cust_id = cmg.cust_id
				AND	sih.sol_id = v_sol_id
				AND	sih.del_flg = 'N'
				AND	clmt.del_flg = 'N'
				AND	cmg.del_flg = 'N'
				AND	sih.ENTITY_CRE_FLG = 'Y'
				AND	next_exec_date >= v_RENT_EFFECTIVE_DATE;
				exception when no_data_found then 
					v_key_no	:= null;
					v_custid	:= null;
					v_cust_name	:= null;
					v_add1		:= null;
					v_add2		:= null;
			END;
		ELSE
			BEGIN
				SELECT	cmg.cust_name,
					nvl(cust_comu_addr1, cust_perm_addr1),
					nvl(cust_comu_addr2, cust_perm_addr2),
					nvl(CUST_COMU_PIN_CODE, CUST_PERM_PIN_CODE)
				INTO	v_cust_name,
					v_add1,
					v_add2,
					v_pin
				FROM CMG
				where cmg.cust_id = v_custid
				and del_flg = 'N';
				exception when no_data_found then 
					v_cust_name := null;
					v_add1  := null;
					v_add2  := null;
					v_pin	 := null;       

			END;

			BEGIN
				select 	distinct SI_SRL_NUM
				into	v_sno
				from	sih,clmt
				where	sih.sol_id = clmt.sol_id
				AND	locker_num = SUBSTR(rmks_free_text,8,12)
				AND	locker_num = v_locker_no
				AND	rmks_free_text like '%LOC%'
				AND	sih.sol_id = v_sol_id
				AND	SI_SRL_NUM is not null
				AND	clmt.del_flg = 'N'
				AND	sih.ENTITY_CRE_FLG = 'Y'
				AND	sih.del_flg = 'N';
				exception when no_data_found then 
					v_sno := null;
			END;
		
		END IF;
	END;


	BEGIN
		select  RENT_AMT into rent_amt
	        from    clrm
		where   rent_period = v_locker_period
	        AND     rent_version_code = v_rent_code
		AND     clrm.sol_id = v_sol_id
	        AND     clrm.location_code = v_Loc_code
		AND     clrm.locker_type = v_locker_type;
		exception when no_data_found then 
		BEGIN
			select  RENT_AMT into rent_amt
			from    clrm
			where   rent_period = v_locker_period
			AND     rent_version_code = v_rent_code
			AND     clrm.sol_id = '0000'
			AND     clrm.location_code = v_Loc_code
			AND     clrm.locker_type = v_locker_type;
			exception when no_data_found then 
			rent_amt := null;
		END;	
	END;

	
		out_rec :=	v_sno			||'|'||
				v_locker_type		||'|'||
				v_locker_no		||'|'||
				v_locker_period		||'|'||
				v_key_no		||'|'||
				v_cust_name		||'|'||
				v_add1			||'|'||
				v_add2			||'|'||
				v_pin			||'|'||
				v_RENT_EFFECTIVE_DATE	||'|'||
				rent_amt;
	
			return;

end rntrpt_proc;
end rntrpt_pack;

/
drop public synonym rntrpt_pack
/
create public synonym rntrpt_pack for rntrpt_pack
/
grant execute on rntrpt_pack to tbacust,tbautil,tbagen,tbaadm
/

