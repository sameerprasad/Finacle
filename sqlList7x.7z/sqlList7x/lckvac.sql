--##############################################################################################
--#                     File Name       : lckvac.sql
--#                     Author : Saravanan.S (BBSSL)
--#                     Report : LOCKER VACCANT REPORT
--#                     Date   :
--#                     Module  : LOCKER
--#                     Called Menu     : LOCKCALL
--##############################################################################################

set head off
set verify off
set feedback off
set termout off
set lines 140
set pages 0
set echo off
set pause off
set serveroutput on size 1000000

spool lckvac.lst

declare
v_status	wlckm.status%type;	
v_sol_id		wlckm.sol_id%type;
v_new_locker_num	wlckm.locker_num%type; 
v_locker_type		wlckm.locker_type%type; 
v_old_locker_num	wlckm.locker_num%type; 
v_old_locker_key	wlckm.key_num%type; 
v_surrender_date	lcsm.surrender_date%type; 
cursor C1 (v_sol_id wlckm.sol_id%type)  is


SELECT		locker_num, 
		status, 
		DECODE(status,'S',(SELECT SUBSTR(surrender_date,1,10) FROM lcsm WHERE lock_no = locker_num),surrender_date),
		locker_type,
		LTRIM((SUBSTR(wlckm.locker_num,-5)),0),
		LTRIM((SUBSTR(wlckm.key_num,-5)),0)
FROM		wlckm
WHERE		status IN ('A','S') 
AND		sol_id = v_sol_id
order by	locker_type;

BEGIN
	v_sol_id := '&1';
	
open C1 (v_sol_id);
loop
fetch C1 into
		v_new_locker_num,
		v_status,
		v_surrender_date,
		v_locker_type,
		v_old_locker_num,
		v_old_locker_key;

exit when C1%NOTFOUND;

dbms_output.put_line(	
			v_new_locker_num	||'|'||
			v_status	     	||'|'||
			v_surrender_date	||'|'||
			v_locker_type		||'|'||
			v_old_locker_num	||'|'||
			v_old_locker_key	
		    );       
end loop;
close C1;
end;
/
spool off



