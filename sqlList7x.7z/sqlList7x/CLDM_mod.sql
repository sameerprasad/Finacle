REM####################################################################
REM File Name   : CLDM_MOD.sql
REM Description : Table creation for Locker Document Maintenance mod Table
REM Author      : Prabhu.B (BBSSL)
REM Date        : 04-06-2008
REM Module	: LOCKER
REM####################################################################
drop table cust_locker_docu_maint_mod
/
drop public synonym CLDM_MOD
/
create table icici.cust_locker_docu_maint_mod
(
	sol_id 			varchar2(8),
	cust_id         	varchar2(9),
	locker_num		varchar2(12),
	document_1		varchar2(20),
	document_2		varchar2(20),
	del_flg         	char(1),
	entity_cre_flg  	char(2),
	LCHG_USER_ID    	VARCHAR2(15),
	LCHG_TIME       	date,
	RCRE_USER_ID    	VARCHAR2(15),
	RCRE_TIME       	date,
	document_3		varchar2(100)
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
create public synonym CLDM_MOD for icici.cust_locker_docu_maint_mod
/
grant select,insert,update,delete on CLDM_MOD to tbagen
/
grant select on CLDM_MOD to tbacust
/
grant select on CLDM_MOD to tbautil
/
grant all on CLDM_MOD to tbaadm
/
