----------------------------------------------------------------------
-- SQL NAME      :  cust50ktds.sql 
-- AUTHOR        : Sheetal Kulkarni
-- MODIFICATIONS : Sampath Kumar(INFOSYS)
-- DESC          : PL/SQL to dump the accounts and the interest for the
--		   accounts of the input customer id. This list also
--                 includes customer accounts whose tds_cust_id is the 
--		   customer id involved. (EX:)
--		   Cust_id		Tds_cust_id
--			A			D
--			B			D
--			C			C
--			D			D
--		   Now if the cust_id is given as A or B or D then the list
--		   contains deposit accounts of all three A,B&D. If C is given
--		   then only accounts of C are taken.
-- BANK          : ICICI Bank
----------------------------------------------------------------------
SET SERVEROUTPUT ON SIZE 1000000
SET LINESIZE 500
SET PAGESIZE 0
SET HEADING OFF
SET FEEDBACK OFF
SET VERIFY OFF
SET TERMOUT OFF
SET TRIMS ON

spool cust50ktds.lst
----------------------------------------------------------------------
--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- what is done ? 	: Selecting  customers and their account with the scheme type TDA 
--					  (term deposit) in a given sol
--why is it done ? 	: Requirement states that interest on TDA accounts which are non recurring 
--						in nature are to be considered for interest calculation . 
--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

DECLARE

	in_TDS_start_date 		GCT.TDS_start_date%type;
	in_TDS_end_date 		GCT.TDS_end_date%type;
	GCT_db_stat_date 		GCT.db_stat_date%type;
	in_TDT_start_date 		GCT.TDS_start_date%type;

	in_cust_id 				CMG.cust_id%type;
	in_cust_name 			CMG.cust_name%type;
	in_TDS_cust_id 			CMG.TDS_cust_id%type;
	in_tds_cust_name 		CMG.cust_name%type;

	in_acct_cls_flg 		GAM.acct_cls_flg%type;
	in_clr_bal_amt			GAM.clr_bal_amt%type;
	in_acid 				GAM.acid%type;
	in_foracid 				GAM.foracid%type;
	in_wtax_flg 			GAM.wtax_flg%type;
	loc_acid				GAM.acid%type;
	depositAmount           TAM.deposit_amount%type;

	in_int_amt 				TDS.int_amt%type;
	max_tran_date 			TDS.tran_date%type;

	n_flow_date				TDT.flow_date%type;
	in_flow_date 			TDT.flow_date%type;
	f_flow_date 			TDT.flow_date%type;
	in_flow_amt 			TDT.flow_amt%type;
	in_flow_amt1 			TDT.flow_amt%type;
	f_flow_amt 				TDT.flow_amt%type;
	lastFlowInterval 		number(6);

	part_amt			number(20,4);
	prev_flow_amt 			number(20,4);
	flow_date_bef_cur_fin_yr 	TDT.flow_date%type;
	tot_period  			number(20,4);
	tot_days			number(20,4);
	min_tdt_date  			TDT.flow_date%type;  
	prev_fin_date			TDT.flow_date%type; 
	flow_amt 			number(20,4);
	lastPartialFlow 		number(20,4);
	in_flow_amt_tot 		number(20,4);
	in_int_amt_tot 			number(20,4);
	estimatedinterest 		number(25,4);
	estimatedDays 			number(6);
	estimatedInterestClosed number(20, 4);
	estimatedInterestOpen number(20, 4);
	taxLimit			number(20,4);
	recCnt				number(6) := 0;


CURSOR CustId_TDS50000 (in_cust_id varchar2, in_tds_cust_id varchar2, in_tds_startdate date) IS
	SELECT 
		A.CUST_ID, 
		A.CUST_NAME, 
		B.ACID, 
		B.FORACID, 
		B.WTAX_FLG, 
		B.ACCT_CLS_FLG, 
		A.TDS_CUST_ID, 
		B.CLR_BAL_AMT 
	FROM CMG A, GAM B , TSP C, CSP D
	WHERE
	D.WTAX_FLG = 'T' 
	AND B.ACCT_CRNCY_CODE = 'INR' 
	AND A.ENTITY_CRE_FLG = 'Y' 
	AND B.ENTITY_CRE_FLG = 'Y' 
	AND B.DEL_FLG ='N' 
	AND (A.CUST_ID = in_cust_id OR A.TDS_CUST_ID = in_tds_cust_id 
			OR A.CUST_ID = in_tds_cust_id) 
	AND NVL(B.ACCT_CLS_DATE,'31-03-2099') >= in_tds_startdate
	AND D.SCHM_CODE = C.SCHM_CODE  
	AND C.SCHM_CODE = B.SCHM_CODE
	AND B.CUST_ID = A.CUST_ID 
	ORDER BY A.tds_cust_id;
			

BEGIN
--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
--what is done ?  : Hard coding values for Tax limit .
--why it is done ?: Requirement specifies the current tax limit ,above which the customer
--					is to be taxed (INR).
--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	taxLimit := 50000;
--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- what is done  ?	: Cursor 1 selecting different service outlet's in a given Data center
-- why it is done ? : To calculate total interest from the TD accounts sol wise for a customer. 
--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	SELECT 	GCT.tds_start_date, 
			GCT.tds_end_date, 
			db_stat_date
	INTO 	in_TDS_start_date, 
			in_TDS_end_date, 
			GCT_db_stat_date
	FROM 	GCT;
		

	LOOP
--	{
--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
--what is done ?   : Cursor 2 will select customer and their account for a given service outlet 
--why is it done ? : Total interest for TD account of a customer can be calculated for that given sol
--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		IF(NOT CustId_TDS50000%ISOPEN) THEN
--		{
			estimatedinterest := 0;
			estimatedInterestClosed :=0;

			BEGIN

			SELECT DECODE(tds_cust_id, '', cust_id, tds_cust_id),
				cust_id
			INTO   in_tds_cust_id,
				in_cust_id
			FROM CMG
			WHERE cust_id = lpad('&1',9);


			EXCEPTION
			when no_data_found then
				-- Handle for no data found condition --
					dbms_output.put_line('INVALIDCUSTID|||||');
					GOTO INVALIDCUSTID;
			END;

			--dbms_output.put_line('solid: '||in_sol_id||'cust_id :'||in_cust_id);
		
			OPEN CustId_TDS50000(in_cust_id, in_tds_cust_id, in_TDS_start_date);
--		}
		END IF;

		IF (CustId_TDS50000%ISOPEN) THEN
--		{
			FETCH 	CustId_TDS50000
			INTO	in_cust_id,
				in_cust_name,
				in_acid,
				in_foracid,
				in_wtax_flg,
				in_acct_cls_flg,
				in_TDS_cust_id,
				in_clr_bal_amt;
						
			--dbms_output.put_line('after fetch');
		
			IF (CustId_TDS50000%FOUND) THEN
--			{
--				{
					in_flow_amt_tot 	:= 0;
					estimatedinterest 	:=0;
					in_int_amt_tot  	:=0;
--				}

				BEGIN
					SELECT  deposit_amount
					INTO    depositAmount
					FROM    TAM
					WHERE   acid = in_acid;

					IF ((in_clr_bal_amt < depositAmount) AND (in_acct_cls_flg = 'N')) THEN
--              	{
						in_int_amt_tot:=0;
						GOTO CONTINUEACID;
--              	}
					END IF;

				EXCEPTION
					WHEN NO_DATA_FOUND THEN
					BEGIN
						in_int_amt_tot:=0;
						GOTO CONTINUEACID;
					END;
				END;

				BEGIN
					SELECT DISTINCT(ACID) 
					INTO loc_acid
					FROM TDT
                    WHERE flow_date >= in_TDS_start_date
                    AND flow_code IN ('IO', 'II')
					AND acid = in_acid;
				EXCEPTION
					when no_data_found then
						GOTO CONTINUEACID;
				END;
		
				recCnt := recCnt + 1;

				IF((in_TDS_cust_id is not NULL) and (in_TDS_cust_id != in_cust_id)) THEN
					BEGIN
						SELECT cust_name
						INTO   in_tds_cust_name
						FROM CMG
						WHERE cust_id = in_TDS_cust_id;
					EXCEPTION
						when no_data_found then
							in_tds_cust_name := NULL;
					END;
				END IF;
				IF((in_TDS_cust_id is NULL) or (in_TDS_cust_id = in_cust_id)) THEN
					in_tds_cust_name := in_cust_name;
				END IF;
--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- what is done ? 	: Interest calculation for all open and closed term deposits 
-- why it is done ? : this gives details about the amount and the date upto which the 
--					tax deduction at source is calculated from the beginning of the financial year
--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			--dbms_output.put_line('records fetched');
				SELECT 	max(tran_date), 
						sum(int_amt)
				INTO 	max_tran_date, 
						in_int_amt
				FROM 	TDS 
				WHERE 	tran_date >= in_TDS_start_date
				AND 	tran_date <= in_TDS_end_date
				AND 	tds.acid = in_acid;
				
			--dbms_output.put_line('after tds select');
				IF  (max_tran_date IS NOT NULL) THEN
--				{
					in_int_amt_tot 		:= in_int_amt_tot + in_int_amt;
					estimatedDays 		:= in_TDS_end_date - max_tran_date;
					in_TDT_start_date 	:= max_tran_date + 1;
				ELSE
					in_int_amt 			:= 0;
					estimatedDays 		:= in_TDS_end_date - in_TDS_start_date + 1;
					in_TDT_start_date 	:= in_TDS_start_date;
--				}
				END IF;

                IF (in_acct_cls_flg = 'Y') THEN
--              {
					estimatedInterestClosed := estimatedInterestClosed + in_int_amt;
				ELSE
					estimatedInterestOpen   := estimatedInterestOpen + in_int_amt;
--              }
				END IF;

--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
--what is done ?   : calculation for open term deposits
--why is it done ? : this will calculate the interest from the date on which TDS was 
--					calculated till the financial year end
--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
				IF (in_acct_cls_flg = 'N' ) THEN
--				{
			--dbms_output.put_line('before tdt select');
					SELECT 	max(flow_date), 
							sum(flow_amt)
					INTO 	in_flow_date, 
							in_flow_amt1
					FROM 	TDT
					WHERE 	flow_code IN ('IO', 'II')
					AND 	acid = in_acid
					AND 	flow_date >= in_TDT_start_date
					AND 	flow_date <= in_TDS_end_date;

	
			--dbms_output.put_line('after tdt select');
					IF (in_flow_date IS NULL) THEN
--					{
						in_flow_amt1 	:= 0;
						BEGIN
--						{
							SELECT acct_opn_date
							INTO n_flow_date
							FROM GAM
							WHERE acid = in_acid;
	
							IF (n_flow_date > in_TDT_start_date) THEN
--							{
								in_flow_date    := n_flow_date;
--							}
							ELSE
--							{
								in_flow_date := in_TDT_start_date;
--							}
							END IF;
	
						EXCEPTION
						WHEN NO_DATA_FOUND THEN
							BEGIN
								in_flow_date := in_TDT_start_date;
							END;
--						}
						END;
--					}
					END IF;
					
					estimatedDays := (in_TDS_end_date - in_flow_date) + 1;

					lastPartialFlow := 0;

					IF (in_flow_date < in_TDS_end_date) THEN
--					{
			--dbms_output.put_line('before tdt select for future partial flow');
						BEGIN
							SELECT 	flow_amt, 
									flow_date
							INTO 	f_flow_amt, 
									f_flow_date
							FROM 	TDT
							WHERE 	flow_date IN   (SELECT 	min(flow_date)
													FROM 	TDT
													WHERE 	flow_date > in_TDS_end_date
													AND 	acid = in_acid
													AND 	flow_code IN ('IO', 'II'))
							AND 	flow_code IN ('IO', 'II')
							AND 	acid = in_acid;
								
							lastFlowInterval 	:= f_flow_date - in_flow_date;
							lastPartialFlow 	:= estimatedDays * (f_flow_amt / lastFlowInterval);

						EXCEPTION
							WHEN NO_DATA_FOUND THEN

							BEGIN
--							{
								lastPartialFlow := 0;
--							}
							END;
						END;
			--dbms_output.put_line('after tdt select for future partial flow');
--					}
					END IF;

					prev_flow_amt := 0;  
					
					IF ( in_TDT_start_date = in_TDS_start_date )  THEN
--					{
						prev_fin_date := in_TDS_start_date - 1;

			--dbms_output.put_line('before tdt select for past partial flow 1');
						select 	max(flow_date )
						into    flow_date_bef_cur_fin_yr
						from 	TDT  	
						where 	flow_date <= prev_fin_date 
						and 	acid = in_acid
						AND		flow_code in ( 'II','IO')    ;
			--dbms_output.put_line('after tdt select for past partial flow 1');

						IF ( flow_date_bef_cur_fin_yr IS NOT NULL ) THEN
--                      {
                            BEGIN
			--dbms_output.put_line('before tdt select for past partial flow 2');

                                SELECT  flow_amt,
										flow_date
                                INTO    part_amt,
                                        min_tdt_date
                                FROM    TDT
                                WHERE   flow_date in (  select  min(flow_date)
                                        	            FROM    TDT
                                            	        WHERE   flow_date >= in_TDT_start_date
                                                	    AND     flow_date <= in_TDS_end_date
                                                    	AND 	flow_code in ( 'II','IO')
                                                    	AND 	acid = in_acid )
                                AND    	flow_code in ('II','IO' )
                                AND 	acid =in_acid ;

								
                                	tot_period  := min_tdt_date - flow_date_bef_cur_fin_yr ;

                                	tot_days    := prev_fin_date - flow_date_bef_cur_fin_yr;

                               	 	prev_flow_amt   := (part_amt / tot_period ) * tot_days;

			--dbms_output.put_line('after tdt select for past partial flow 2');
--								                         
						    	EXCEPTION
                                    WHEN NO_DATA_FOUND THEN
                                     BEGIN
                                        prev_flow_amt := 0;
                                    END;
                            END;
                            ELSE
                                BEGIN

									SELECT  acct_opn_date
                                    INTO    n_flow_date
                                    FROM    GAM
                                    WHERE   acid = in_acid;

                                    IF (n_flow_date >= in_TDS_start_date) THEN
--                                  {
                                        prev_flow_amt := 0;

                                    ELSE

			--dbms_output.put_line('before tdt select for past partial flow 3');
                                        SELECT  flow_amt,flow_date
                                        INTO    part_amt,
                                                min_tdt_date
                                        FROM    TDT
                                        WHERE   flow_date in (	select  min(flow_date)   
   																FROM    TDT    
 	        													WHERE   flow_date >= in_TDT_start_date                                                	
    															AND     flow_date <= in_TDS_end_date                                                    	
																AND 	flow_code in ( 'II','IO')
                                                    			AND 	acid = in_acid )
                        		        AND     flow_code in ('II','IO' )
                                		AND 	acid =in_acid ;

		                                tot_period  := min_tdt_date - n_flow_date;

        		                        tot_days    := prev_fin_date - n_flow_date;

                		                prev_flow_amt   := (part_amt / tot_period ) * tot_days;

			--dbms_output.put_line('after tdt select for past partial flow 3');

--                                  }
                                    END IF;
						    	EXCEPTION
                                    WHEN NO_DATA_FOUND THEN
                                     BEGIN
                                        prev_flow_amt := 0;
                                    END;
                                END;

--                      }
                        END IF;
--              }
                END IF;
					in_flow_amt 	:= lastPartialFlow + in_flow_amt1;
					in_flow_amt 	:= in_flow_amt - prev_flow_amt; 
					in_flow_amt_tot := in_flow_amt_tot + in_flow_amt;
						
					estimatedInterestOpen := estimatedInterestOpen + in_flow_amt;		

--				}
				END IF;

--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- what is done ? : Intrest of all Term deposits of a customer summed .
-- why it is done ? : This amount excceds the Tax limit then the customer has to be taxed
--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			--dbms_output.put_line(in_cust_id||'|'||in_foracid||'|'||in_int_amt_tot||'|'||in_flow_amt_tot);
				estimatedinterest 	:= in_int_amt_tot + in_flow_amt_tot;
			dbms_output.put_line(in_cust_id||'|'||in_cust_name||'|'||in_tds_cust_id||'|'||in_tds_cust_name||'|'||in_foracid||'|'||estimatedinterest);

--			}
			END IF;

			IF (CustId_TDS50000%NOTFOUND) THEN
--			{
				CLOSE CustId_TDS50000;
				IF(recCnt = 0) THEN
					dbms_output.put_line('NORECFOUND|||||');
				END IF;
				GOTO FINISH;
--			}
			END IF;
--		}
		END IF;
		<<CONTINUEACID>>
		NULL;
--	}
	END LOOP;
<<INVALIDCUSTID>>
NULL;

<<FINISH>>
NULL;

END;
/
spool off
