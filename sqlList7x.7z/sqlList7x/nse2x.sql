rem : In the last line , sample accounts have been used
rem : This list has to be updated using correct account numbers

set echo off
set pause off
set verify off
whenever sqlerror exit sql.sqlcode
set feedback off
set linesize 41
set pages 0
set newpage 0
set space 0
set head off

col CID format 'A15'
col amt format '999999999999.99'
col PIPE1 format 'A1'
col PIPE2 format 'A1'
col RDATE format 'A8'
spool NSEXBAL


select 
	   gam.foracid CID,
	   '|' PIPE1,
	   ((gam.clr_bal_amt+gam.sanct_lim+gam.clean_single_tran_lim) - (gam.system_reserved_amt+gam.lien_amt)) amt,
	   '|' PIPE2,
	   to_char(gct.db_stat_date,'yyyymmdd') RDATE
from gam,gct
where gam.foracid in ( ACCTNUMBERS )
/

spool off
set verify on
set feedback on
set termout on
exit
/
