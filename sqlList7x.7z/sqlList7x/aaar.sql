set serveroutput on size 1000000;
set feedback off
set verify   off
set termout   off
set pages 0
set trims on
spool iciaar.lst
declare
 mqt_dr_amt MQT.tran_amt%type;
 mqt_cr_amt MQT.tran_amt%type;
 ib4_amt MQT.tran_amt%type;
 tot_amt MQT.tran_amt%type;
 mqt_sno IB4.iba_num%type;
 cursor ib4_mqt  is select iba_num,tran_amt,tran_date from ib4 
where (contra_bank_code,CONTRA_BR_CODE) =(select bank_code,br_code from sol where sol_id='&1')
and tran_date > '01-01-2004' and substr(iba_num,5,2)='AN';
begin
   for  mqt_ib4_rec in ib4_mqt
   loop
  begin
     SELECT  SUM(TRAN_AMT) into mqt_dr_amt   FROM MQT
         WHERE
         SDS_ID = substr(mqt_ib4_rec.iba_num,1,4) AND
         SNO = substr(mqt_ib4_rec.iba_num,7,7) AND
         PROCESSED_FLG = 'D' AND
         SOL_ID = '&1' AND
         QUALIFIER  NOT IN('LO','99') AND
         (INTERCHANGE_PTRAN_TYPE = 'D'
         OR
         ( ( INTERCHANGE_PTRAN_TYPE IS NULL AND QUALIFIER != '01')
         OR
         ( ASCII(INTERCHANGE_PTRAN_TYPE) = 0 AND QUALIFIER != '01')))
         GROUP BY SOL_ID, sds_id, src_id, luno, date_time, sno, sol_id;
         exception
        when no_data_found then
            mqt_dr_amt:= 0;

end;
begin
      SELECT  SUM(TRAN_AMT) into  mqt_cr_amt  FROM MQT
         WHERE
         SDS_ID = substr(mqt_ib4_rec.iba_num,1,4) AND
         SNO = substr(mqt_ib4_rec.iba_num,7,7) AND
         PROCESSED_FLG = 'D' AND
         SOL_ID = '&1' AND
         QUALIFIER  NOT IN('LO','99')  AND 
         (INTERCHANGE_PTRAN_TYPE = 'C'
         OR
         ( ( INTERCHANGE_PTRAN_TYPE IS NULL AND QUALIFIER = '01')
         OR
         ( ASCII(INTERCHANGE_PTRAN_TYPE) = 0 AND QUALIFIER = '01')))
         GROUP BY SOL_ID, sds_id, src_id, luno, date_time, sno, sol_id ;
         if (sqlcode !=0 ) then
            mqt_cr_amt:=0; 
         end if;
       
         exception
        when no_data_found then
            mqt_cr_amt:= 0;

end;
 
         ib4_amt:=mqt_ib4_rec.tran_amt;
         tot_amt:= abs(mqt_cr_amt - mqt_dr_amt) - ib4_amt;
        if (tot_amt != 0) then
           dbms_output.put_line(mqt_ib4_rec.iba_num||'|'||mqt_ib4_rec.tran_date);
       end if;

end loop;
end;
/
select 'EOF' from dual;
spool off
