--##############################################################################################
--#                     File Name       : LCKREG.sql
--#                     Author : Arun Kumar.V (BBSSL)
--#                     Report : LOCKER REGISTER REPORT
--#                     Date   :
--#                     Module  : LOCKER
--#                     Called Menu     : LOCKCALL
--#                     Called By       : LCKREG.com
--##############################################################################################

create or replace package RC15_pack as
procedure RC15_proc (	
		inp_str IN varchar2, 
		out_retcode OUT number, 
		out_rec OUT varchar2
	      );
end RC15_pack;
/
create or replace package body RC15_pack as
	v_sol_id		gam.sol_id%type;
	v_date1 		date;
	v_hire_date		date;
	v_lock_num		clmt.locker_num%type;
	v_old_lock_num		clmt.locker_num%type;
	v_key_num		clmt.LOCKER_KEY_NUM%type;
	v_rack_id		wlckm.RACK_ID%type;
	v_cust_name		cmg.cust_name%type;
	v_oper_acnt		gam.foracid%type;
	v_dep_acnt		gam.foracid%type;
	v_pin_code		cmg.cust_comu_pin_code%type;
	v_cust_id		cmg.cust_id%type;
	v_addr1			cmg.CUST_COMU_ADDR1%type;
	v_addr2			cmg.CUST_COMU_ADDR1%type;
	v_state			cmg.cust_comu_state_code%type;
	v_city			cmg.CUST_COMU_CITY_CODE%type;
	v_city_name		varchar2(50);
	v_state_name		varchar2(50);
	v_cust_jh_name		cmg.cust_name%type;
	v_cust_jh_id		cmg.cust_id%type;
	v_oper_mode		clmt.operation_mode%type;
	v_staff			clmt.STAFF_FLG%TYPE;
	v_agreement_no		clmt.CONTRACT_NO%TYPE;
	v_rent_paid		clmt.DUE_DATE%TYPE;	
	v_remarks		clmt.REMARKS%TYPE;
	v_enterer_id		clmt.RCRE_USER_ID%TYPE;
	v_verifier_id		clmt.LCHG_USER_ID%TYPE;
	v_status		varchar2(20);
	v_oper_desc		varchar2(60);
	v_old_key_num		clmt.LOCKER_KEY_NUM%type;
	v_lock_type		 CLMT.LOCKER_TYPE%type;
	v_tran_date		DATE;
	v_jh_count		number(3);
CURSOR RC15(v_sol_id  gam.sol_id%type) IS
		SELECT 	
			   clmt.LOCKER_NUM,
			   clmt.LOCKER_KEY_NUM,
			   wlckm.RACK_ID,
			   clmt.OPERATION_MODE,
			   clmt.OPER_ACNT,
			   clmt.DEP_ACNT,
			   clmt.cust_id,
			   clmt.STAFF_FLG,
			   clmt.issue_date,
			   clmt.CONTRACT_NO,
			   clmt.DUE_DATE,	
			   clmt.REMARKS,
			   clmt.RCRE_USER_ID,
			   clmt.LCHG_USER_ID,
			   decode(wlckm.status,'A','AVAILABLE','B','FOR BANK USE','L','LOST','U','USED','S','SURRENDER','F','FREEZE')stat,
			   CLMT.LOCKER_TYPE,
			   CLJH.cust_jh_id
                from 
			  clmt,wlckm,cljh	   
		WHERE clmt.cust_id = cljh.cust_mh_id(+)
                AND cLMT.sol_id = cljh.sol_id(+)
                AND clmt.locker_num = cljh.locker_num(+)
		AND clmt.locker_num = wlckm.locker_num
                AND CLMT.sol_id = v_sol_id
                and clmt.DEL_FLG !='Y'
                and clmt.ENTITY_CRE_FLG!= 'N'
                order by clmt.LOCKER_TYPE,clmt.LOCKER_NUM;

OutArr	basp0099.ArrayType;
	PROCEDURE RC15_proc
	(
		inp_str IN varchar2,
		out_retcode  OUT number,
		out_rec  OUT varchar2
	) AS
BEGIN
	out_retcode := 0;
		basp0099.formInputArr(inp_str,outArr);
			v_sol_id	:=	outArr(0);
	IF (NOT RC15%ISOPEN) THEN
	    OPEN RC15(v_sol_id);
	END IF;
			FETCH RC15 into	v_lock_num,
					v_key_num,
					v_rack_id,
					v_oper_mode,
					v_oper_acnt,
					v_dep_acnt,
					v_cust_id,
					v_staff,
					v_hire_date,
					v_agreement_no,
					v_rent_paid,	
					v_remarks,
					v_enterer_id,
					v_verifier_id,
					v_status,
					v_lock_type,
					v_cust_jh_id;
			BEGIN
				 SELECT
		                         substr(cust_name,1,40),
               			         RTRIM(cust_comu_addr1,' '),
               			         cust_comu_addr2,
  		                         CUST_COMU_CITY_CODE,
       			                 cust_comu_state_code,
       			                 CUST_COMU_PIN_CODE
          			 INTO
   			                     v_cust_name,
  			                     v_addr1,
  			                     v_addr2,
 			                     v_city,
   			                     v_state,
			                     v_pin_code
      			          FROM
           			             cmg
		                   WHERE
   			                     cust_id = v_cust_id;
       			         Exception
     			                   when no_data_found then
      			                    v_cust_name := null;
   			                    v_addr1:= null;
			                    v_addr2:= null;
  			                    v_city := null;
			                    v_state:= null;
 			                    v_pin_code:= null;
			END;

	        	BEGIN
              		          SELECT
                       	          	    RTRIM(ref_desc,' ')
                  	          INTO
            		                    v_city_name
     		                   FROM
            		                    rct
          	                   WHERE
            		                    ref_code=v_city
             		           AND
             		                   ref_rec_type = '01';
   	                          Exception
          		                    when no_data_found then
         	                           v_city_name := null;
     	                END;
		        BEGIN
	                        SELECT
       		                         RTRIM(ref_desc,' ')
               		         INTO
                   		         v_state_name
    	                         FROM
   	                                  rct
  	                         WHERE
 	                                 ref_code  = v_state
	                         AND
	                                ref_rec_type = '02';
	                        Exception
 	                               when no_data_found then
	                                v_state_name := null;
		        END;
        	BEGIN
	   		select 
				 SUBSTR(cust_name,1,40) 
	   		INTO 
				v_cust_jh_name 
	   		from
				cmg
	   		where
				cust_id = v_cust_jh_id;
			EXCEPTION WHEN NO_DATA_FOUND THEN
				  v_cust_jh_name :=null;
         	END;
			
		IF(RC15%NOTFOUND) THEN
			close RC15;
			out_retcode := 1;
			return;

		END IF;


	BEGIN
			SELECT	
				LTRIM((SUBSTR(locker_num,-5)),0),LTRIM((SUBSTR(LOCKER_KEY_NUM,-5)),0)
			INTO 
				v_old_lock_num,
				v_old_key_num
			FROM 
				clmt
			where 
				locker_num = v_lock_num
			AND     clmt.sol_id    = v_sol_id
			AND     clmt.del_flg = 'N'
			order by v_old_lock_num,v_old_key_num;
			EXCEPTION WHEN NO_DATA_FOUND THEN
				  v_old_lock_num := null;
				  v_old_key_num  := null;
	END;
	BEGIN
			SELECT
				ref_desc
			INTO
				v_oper_desc
			FROM
				rct
			WHERE
				ref_code = v_oper_mode
			AND
				ref_rec_type = '27';
			EXCEPTION WHEN NO_DATA_FOUND THEN
				  v_oper_desc :=null;
	END;

	   
		out_rec :=
				v_lock_num		||'|'||
				v_key_num		||'|'||
				v_rack_id		||'|'||
				v_oper_desc		||'|'||
				v_oper_mode		||'|'||
				v_oper_acnt		||'|'||
	   			v_dep_acnt		||'|'||
				v_cust_id		||'|'||
	   			v_cust_jh_id		||'|'||
				v_staff			||'|'||
				v_hire_date		||'|'||
				v_agreement_no		||'|'||
				v_rent_paid		||'|'||
				v_remarks		||'|'||
				v_enterer_id		||'|'||
				v_verifier_id		||'|'||		
				v_status		||'|'||		
				v_cust_name		||'|'||
	   			v_addr1			||'|'||
	   			v_addr2			||'|'||
	   			v_city_name		||'|'||
	   			v_state_name		||'|'||
				v_pin_code		||'|'||		
				v_cust_jh_name		||'|'||		
				v_old_lock_num		||'|'||
				v_old_key_num		||'|'||
				v_lock_type;
				
			return;
	   			
end RC15_proc;
end RC15_pack;
/
drop public synonym RC15_pack
/
create or replace public synonym RC15_pack for RC15_pack
/
grant execute on RC15_pack to tbautil, tbacust, tbagen,tbaadm
/
