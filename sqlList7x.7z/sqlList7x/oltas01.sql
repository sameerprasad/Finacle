set serveroutput on size 1000000
set feedback off
set verify off
set linesize 500
set pages 0
set trims on
set termout off
set numformat 999D09
spool &2
select distinct '01^639'||'^'||substr(a.BSR_CODE,length(a.bsr_code)-3,4)||'^'||to_char(a.cheque_dep_date,'yy^mm^dd')||'^'||'C'||'^'||substr(a.cin_no,length(a.cin_no)-4,5)||'^'||substr(a.ASSESSMENT_YEAR,0,4)||'^'||a.MAJOR_TAX_HEAD||'^'||a.MINOR_TAX_HEAD||'^'||decode(a.pan_tan_flg,'P','^'||a.pan_tan_no,a.pan_tan_no||'^')||'^'||a.name||'^'||a.ADDRESS1||'^'||a.ADDRESS2||'^'||a.ADDRESS3||'^'||a.ADDRESS4||'^'||a.city||'^'||f.STATE_CODE||'^'||a.pin||'^'||a.NATURE_OF_PAYMENT||'^'||decode(a.BASE_AMOUNT,'0','',a.BASE_AMOUNT)||'^'||decode(a.SURCHARGE,'0','',a.SURCHARGE)||'^'||decode(a.EDUCATION_CESS,'0','',a.EDUCATION_CESS)||'^'||decode(a.INTEREST_AMOUNT,'0','^','INTE^'||a.INTEREST_AMOUNT)||'^'||decode(a.PENALTY_CODE,'0','',a.PENALTY_CODE)||'^'||decode(a.PENALTY_AMOUNT,'0','',a.PENALTY_AMOUNT)||'^'||decode(a.OTHERS,'0','^','OTHR^'||a.OTHERS)||'^'||decode(a.ADDITIONAL_CODE_FIELD,'0','',a.ADDITIONAL_CODE_FIELD)||'^'||decode(a.ADDITIONAL_AMOUNT_FIELD,'0','',a.ADDITIONAL_AMOUNT_FIELD)||''||'^'||a.CHALLAN_AMOUNT||'^'||decode(a.MAJOR_TAX_HEAD,'0020','C','0021','I','0023','H','0024','N','0028','O','0031','E','0032','W','0033','G','0026','F','0036','B','0034','S',' ')||a.SCROLL_NO||'^'||decode(e.tax_tran_type,'L','G',e.tax_tran_type)||'^'||to_char(a.realisation_date,'ddmmyy')||'^'||to_char(a.realisation_date,'ddmmyy')||'^'||a.PAO_CODE||'^'||decode(a.MAJOR_TAX_HEAD,'0020','C','0021','I','0023','H','0024','N','0028','O','0031','E','0032','W','0033','G','0026','F','0036','B','0034','S')||a.SCROLL_NO||'^'||to_char(a.realisation_date,'ddmmyy')
from ici_gbm_challan_master a,icici_gbm_trn_hdr e,ici_gbm_territory f
where
a.PAYOUT_DT='&1'
and a.sol_id=e.sol_id
and e.tax_tran_id=a.tax_tran_id
and e.tax_tran_date = a.tax_tran_date
and (e.tax_type='C' or e.tax_type='c')
and a.del_flg='N'
and f.STATE_NAME= a.STATE
and a.BSR_CODE != '6390005'
/
spool off
