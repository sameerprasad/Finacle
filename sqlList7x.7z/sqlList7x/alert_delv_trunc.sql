-- truncates alert info table
--
set echo on
spool icici_alert_delv_trunc
--
create table icici.icici_alert_temp TABLESPACE ICICI_CUST_SMALL
as (select * from icici.icici_alert_tbl where delv_flg = 'N')
/
--
truncate table ICICI.ICICI_ALERT_TBL
/
--
insert into ICICI.icici_alert_tbl (select * from icici.icici_alert_temp)
/
--
drop table icici.icici_alert_temp
/
--
spool off
