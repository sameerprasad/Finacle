drop sequence customsuppcrrefno_seq;
drop public synonym tba_customsuppcrrefno_seq;
create sequence customsuppcrrefno_seq increment by 1
        minvalue 5651 maxvalue 999999999 cycle nocache;
grant select on customsuppcrrefno_seq to TBAGEN;
create public synonym tba_customsuppcrrefno_seq for customsuppcrrefno_seq;
