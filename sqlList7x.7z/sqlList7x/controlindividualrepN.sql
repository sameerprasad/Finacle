set serveroutput on size 1000000
set feedback off
set verify off
set linesize 500
set pages 0
set trims on
set termout off
set numformat 999D09
spool &3
select rownum||','||to_char(a.CHEQUE_DEP_DATE,'dd-mm-yyyy')||','||to_char(a.realisation_date,'dd-mm-yyyy')||','||a.sol_id||','||decode(b.tax_type,'C','0004','0005')||','||b.tax_tran_type||','||substr(cin_no,length(cin_no)-4,5)||','||decode(a.ASSESSEE_CODE,'',a.pan_tan_no,a.ASSESSEE_CODE)||','||a.name||','||a.major_tax_head||','||a.challan_amount||','||a.tran_id||','||a.part_tran_srl_num||','||decode(a.ASSESSEE_CODE,'',a.ADDRESS1||','||a.ADDRESS2||','||a.PIN,a.ADDRESS1||','||a.CITY||','||a.STATE)||','||decode(a.ASSESSEE_CODE,'',a.MINOR_TAX_HEAD||','||a.NATURE_OF_PAYMENT||','||a.BASE_AMOUNT||','||a.SURCHARGE||','||a.OTHERS||','||a.EDUCATION_CESS||','||a.INTEREST_AMOUNT||','||a.PENALTY_AMOUNT||','||a.PENALTY_CODE,a.COMMISSIONARATE_CODE||','||a.DIVISION_CODE||','||a.RANGE_CODE||','||a.REDUCED_ACCT_CODE_1||','||a.REDECED_ACCT_AMT_1||','||a.REDUCED_ACCT_CODE_2||','||a.REDECED_ACCT_AMT_2||','||a.REDUCED_ACCT_CODE_3||','||a.REDECED_ACCT_AMT_3||','||a.REDUCED_ACCT_CODE_4||','||a.REDECED_ACCT_AMT_4||','||a.REDUCED_ACCT_CODE_5||','||a.REDECED_ACCT_AMT_5||','||a.REDUCED_ACCT_CODE_6||','||a.REDECED_ACCT_AMT_6)||','||a.tax_tran_id
from ici_gbm_challan_master a,icici_gbm_trn_hdr b
where b.tax_tran_id = a.tax_tran_id and b.tax_tran_date = a.tax_tran_date and a.del_flg='N' and entity_creation_flg='Y' and a.realisation_date between '&1' and '&4' and b.sol_id in (select distinct sol_id from ici_gbm_terminal_master where parent_sol_id='&2') and b.tax_tran_type='&5' and b.tax_type='&6' order by b.tax_type
/
spool off
