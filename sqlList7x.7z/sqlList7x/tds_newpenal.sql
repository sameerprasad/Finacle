clear scr
accept solid char prompt " ENTER THE SOL ID FOR WHICH REPORT IS TO BE GENERATED : "
set linesi 120
set serveroutput on size 100000
set verify off
set echo off
set head off
set feedback off
spool tds_newpenal
Declare
scheme		 		GAM.SCHM_CODE%type;
schm_code	 		GAM.SCHM_CODE%type;
flow_dt				TDT.flow_date%type;
bran				SOL.br_code%type;
brname				BCT.br_name%type;
account				GAM.foracid%type;
acct				GAM.foracid%type;
bal			 		GAM.clr_bal_amt%type;
gam_acid			GAM.acid%type;
penalty				TAM.penalty_amount%type;
penalty_sum			TAM.penalty_amount%type;
penalty_sum1		TAM.penalty_amount%type;
recovered			TAM.penalty_recovered%type;
recovered_sum		TAM.penalty_recovered%type;
recovered_sum1		TAM.penalty_recovered%type;
waived 				TAM.penalty_waived%type;
waived_sum			TAM.penalty_waived%type;
waived_sum1			TAM.penalty_waived%type;
balance 			TAM.penalty_waived%type;
balance_sum			TAM.penalty_waived%type;
balance_sum1		TAM.penalty_waived%type;
fp					utl_file.file_type;
fp1					utl_file.file_type;
tmp_cnt1			number(2);
step			number(2);
Cursor pen_sel is
SELECT
		 g.schm_code ,
		 g.foracid ,
		 g.acid,
		 t.penalty_amount ,
		 t.penalty_recovered ,
		 t.penalty_waived ,
  		 (t.penalty_amount-t.penalty_recovered-t.penalty_waived)
from tam t, gam g
where t.acid = g.acid
and t.penalty_amount > 0
and (t.penalty_amount-t.penalty_recovered-t.penalty_waived) > 0
and substr(g.foracid,5,2) in ('10','15')
and g.acct_cls_flg = 'N'
and g.sol_id=ltrim(rtrim('&solid'))
order by 1,2;

BEGIN

waived_sum:=0;
penalty_sum:=0;
recovered_sum:=0;
balance_sum:=0;
waived_sum1:=0;
penalty_sum1:=0;
recovered_sum1:=0;
balance_sum1:=0;
dbms_output.put_line('SOL ID IS '||'&solid');
-- fp:=utl_file.fopen('/tmp','penal.lst','w');
-- fp1:=utl_file.fopen('/tmp','flnm.lst','w');
-- utl_file.put_line(fp1,'&solid'||to_char(sysdate,'ddmmyyyy')||'NEWPENAL.lst:');
-- utl_file.fclose(fp1);
step:=1;
SELECT br_code into bran from sol
		where sol_id=ltrim(rtrim('&solid'));
step:=2;
SELECT br_name into
brname from bct,sol
where sol.br_code = bct.br_code
and ltrim(sol.sol_id) = ltrim(rtrim('&solid'));
dbms_output.put_line('									ICICI Bank Limited');
dbms_output.put_line('');
dbms_output.put_line('									'||brname);
dbms_output.put_line('');
dbms_output.put_line('			Statement of Account Level Penalty Amount Oustanding as on ' ||sysdate);
dbms_output.put_line('');
dbms_output.put_line('---------------------------------------------------------------------------------------------');
dbms_output.put_line('');
dbms_output.put_line('DATE : ' ||sysdate);
dbms_output.put_line('SCHEM ACCT NUMBER          PENALTY       RECOVERED          WAIVED         BALANCE  FLOW DATE');
dbms_output.put_line('---------------------------------------------------------------------------------------------');
open pen_sel;
loop
fetch pen_sel
	  into
		scheme,
		account,
		gam_acid,
		penalty,
		recovered,
		waived,
		balance;
if (pen_sel%NOTFOUND)
then
close pen_sel;
exit;
end if;
if (pen_sel%rowcount >1)
then

	if (schm_code != scheme)
	then
dbms_output.put_line('---------------------------------------------------------------------------------------------');
		dbms_output.put_line('TOTAL              '||lpad(to_char(penalty_sum,'999G999G990D99','NLS_NUMERIC_CHARACTERS = ''.,'''),15)||' '||lpad(to_char(recovered_sum,'999G999G990D99','NLS_NUMERIC_CHARACTERS = ''.,'''),15)||''||lpad(to_char(waived_sum,'999G999G990D99','NLS_NUMERIC_CHARACTERS = ''.,'''),15)||'   '||lpad(to_char(balance_sum,'999G999G990D99','NLS_NUMERIC_CHARACTERS = ''.,'''),15));
dbms_output.put_line('---------------------------------------------------------------------------------------------');
		recovered_sum1:=recovered_sum1 + recovered_sum;
		penalty_sum1:=penalty_sum1 + penalty_sum;
		waived_sum1:=waived_sum1 + waived_sum;
		balance_sum1:=balance_sum1+ balance_sum;
		recovered_sum:=0;
		penalty_sum:=0;
		waived_sum:=0;
		balance_sum:=0;
	end if;
end if;
schm_code:=scheme;
select count(*)
	into tmp_cnt1
	from tdt where
	acid = gam_acid
	and flow_date >= sysdate;
if (tmp_cnt1 < 1)
then
	select maturity_date 
	into flow_dt 
	from tam 
	where acid= gam_acid;
else
select min(flow_date)
		into
		flow_dt
		from tdt
		where flow_date >= sysdate
		and acid = gam_acid;
end if;
dbms_output.put_line(scheme||' '||account||' '||lpad(to_char(penalty,'999G999G990D99','NLS_NUMERIC_CHARACTERS = ''.,'''),15)||' '||lpad(to_char(recovered,'999G999G990D99','NLS_NUMERIC_CHARACTERS = ''.,'''),15)||''||lpad(to_char(waived,'999G999G990D99','NLS_NUMERIC_CHARACTERS = ''.,'''),15)||'   '||lpad(to_char(balance,'999G999G990D99','NLS_NUMERIC_CHARACTERS = ''.,'''),15)||' '||flow_dt);
recovered_sum:=recovered_sum + recovered;
penalty_sum:=penalty_sum + penalty;
waived_sum:=waived_sum + waived;
balance_sum:=balance_sum + balance;
end loop;
dbms_output.put_line('---------------------------------------------------------------------------------------------');
		dbms_output.put_line('TOTAL              '||lpad(to_char(penalty_sum,'999G999G990D99','NLS_NUMERIC_CHARACTERS = ''.,'''),15)||' '||lpad(to_char(recovered_sum,'999G999G990D99','NLS_NUMERIC_CHARACTERS = ''.,'''),15)||''||lpad(to_char(waived_sum,'999G999G990D99','NLS_NUMERIC_CHARACTERS = ''.,'''),15)||'   '||lpad(to_char(balance_sum,'999G999G990D99','NLS_NUMERIC_CHARACTERS = ''.,'''),15));
		recovered_sum1:=recovered_sum1 + recovered_sum;
		penalty_sum1:=penalty_sum1 + penalty_sum;
		waived_sum1:=waived_sum1 + waived_sum;
		balance_sum1:=balance_sum1+ balance_sum;
dbms_output.put_line('---------------------------------------------------------------------------------------------');
		dbms_output.put_line(' GRAND TOTAL       '||lpad(to_char(penalty_sum1,'999G999G990D99','NLS_NUMERIC_CHARACTERS = ''.,'''),15)||' '||lpad(to_char(recovered_sum1,'999G999G990D99','NLS_NUMERIC_CHARACTERS = ''.,'''),15)||''||lpad(to_char(waived_sum1,'999G999G990D99','NLS_NUMERIC_CHARACTERS = ''.,'''),15)||'   '||lpad(to_char(balance_sum1,'999G999G990D99','NLS_NUMERIC_CHARACTERS = ''.,'''),15));
dbms_output.put_line('---------------------------------------------------------------------------------------------');
dbms_output.put_line('AUTHORISED SIGNATORY' );
dbms_output.put_line('' );
dbms_output.put_line('' );
dbms_output.put_line('									ICICI Bank Limited');
dbms_output.put_line('');
dbms_output.put_line('									'||brname);
dbms_output.put_line('');
dbms_output.put_line('			Balance outstanding in SA / TDS account as on '||sysdate);
dbms_output.put_line('');
dbms_output.put_line('---------------------------------------------------------------------------------------------');
dbms_output.put_line('');
select foracid ,abs(clr_bal_amt+un_clr_bal_amt)
	into ACCT,BAL
from gam
where foracid = ltrim(rtrim('&solid'))||'SA000TDS';
dbms_output.put_line('ACCOUNT                       BALANCE');
dbms_output.put_line('----------------------------------------');
dbms_output.put_line(acct||'			'||lpad(to_char(bal,'999G999G990D99','NLS_NUMERIC_CHARACTERS = ''.,'''),15));
utl_file.fclose(fp);
EXCEPTION 			WHEN NO_DATA_FOUND
					THEN
						dbms_output.put_line('NO DATA FOUND AT STEP '||step);
					WHEN OTHERS
					THEN
						dbms_output.put_line('ERROR IS '||SQLCODE);
						dbms_output.put_line('MESG IS '||SQLERRM);
end;
/
spool off
-- !cp /tmp/penal.lst `cat /tmp/flnm.lst|cut -f1 -d":"`
exit;
