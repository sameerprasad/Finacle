Rem     This file will create cust_locker_discnt_master_table 
Rem     with the following characteristics.

Rem     Coded by : Prabhu.B (BBSSL)

Rem     Module  : LOCKER


Rem TABLE NAME: LOCKER_CUST_DISCNT_MAST_TABLE

Rem SYNONYM:    LOCKER_CUST_DISCNT_MAST_TABLE 

drop table icici.LOCKER_CUST_DISCNT_MAST_TABLE
/
drop public synonym CLDMT
/
create table icici.LOCKER_CUST_DISCNT_MAST_TABLE
( 
	SOL_ID VARCHAR2(8),
	CUST_ID VARCHAR2(9),
	LOCKER_NUMBER VARCHAR2(12),
	DISCNT_TYPE VARCHAR2(20),
	DISCNT_VALUE number (20,5),
	DISCNT_AMT number (20,5),
	from_date	DATE,
	to_date		DATE,
	LCHG_USER_ID VARCHAR2(15),
 	LCHG_TIME DATE,
 	RCRE_USER_ID VARCHAR2(15),
 	RCRE_TIME DATE,
	DEL_FLG CHAR(1),
	entity_cre_flg CHAR(1)
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE ACCT_DETAILS_2_SMALL
/* STORE_END */
/
create public synonym CLDMT for icici.LOCKER_CUST_DISCNT_MAST_TABLE
/
create index IDX_CLDMT on icici.LOCKER_CUST_DISCNT_MAST_TABLE(SOL_ID,CUST_ID,LOCKER_NUMBER,DEL_FLG,from_date,to_date)
/
grant select, insert, update, delete on CLDMT to tbagen
/
grant select on CLDMT to tbacust
/
grant select on CLDMT to tbautil
/
grant all on CLDMT to tbaadm
/
