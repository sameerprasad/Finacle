set head off
set feedback on
spool correct_DST_33767.log
Select '================================================' from dual;
Select 'Enter the date of Migration from 1.5.x to 1.6.3x' from dual;
Select '      Date should be in DD-MM-YYYY format       ' from dual;
Select '================================================' from dual;

update dst set dst.entered_by = 'S'
where  exists ( select 'X' from ib4
	where ltrim(ib4.iba_num) = ltrim(dst.dd_num) and
	ib4.br_code = dst.issu_br_code and
	ib4.tran_date = dst.issue_date and
	ib4.bank_code = dst.issu_bank_code and
	ib4.crncy_code = dst.dd_crncy_code and
	ib4.schm_code = dst.schm_code )
and dst.rcre_time >= TO_DATE('&migr_date','DD-MM-YYYY');
spool off
quit
