spool mknewrollonl
drop rollback segment new_roll;
create public rollback segment new_roll 
tablespace TBA_TEMP
storage (initial 10M next 2M  maxextents 121);
alter public rollback segment new_roll online;
alter public rollback segment TBA_REF_ROLLBACK offline;
alter public rollback segment TBA_MAST1_ROLLBACK offline;
alter public rollback segment TBA_MAST2_ROLLBACK offline;
alter public rollback segment TBA_TRANS_ROLLBACK offline;
alter public rollback segment TBA_HIST1_ROLLBACK offline;
alter public rollback segment TBA_HIST2_ROLLBACK offline;
alter public rollback segment TBA_HIST3_ROLLBACK offline;
alter public rollback segment TBA_TEMP_ROLLBACK offline;
alter public rollback segment TBA_SYS_ROLLBACK  offline;
spool off
