rem This script will generate Report on National Clearing Cheques
rem lodged under sub-reg_type of 'NCCC' or 'NCCP' of Bill Module
rem This report will generate according to requirements of CAT, Mumbai.

rem author  :: Narayan Rao, ICICI Infotech, Mumbai 

accept dt1 prompt 'ENTER LODGE DATE FOR REPORT (DD-MM-YYYY) : '
set termout off
set verify off
set echo off
set feedback off
set pages 50
set linesize 80 
set newpage 0

column today new_value today_date
select to_char(sysdate, 'dd/mm/yyyy') today from  dual;

column spoolday newvalue spool_date
select to_char(lodg_date, 'ddmmyyyy') spoolday from blt
            where lodg_date='&dt1';




col sol_desc  heading 'BR. NAME' format a10 word_wrap
col city_name heading 'CITY' format a9 
col sol_id heading 'SOLID format a5
col bill_id heading 'OUR REF. NO' format a12
col drawee_name heading 'DRAWEE' format a6 word_wrap
col lodg_date heading 'LODGE DATE'
col bill_amt heading 'AMOUNT (IN Rs.)' format b999,99,99,999.99

break on city_name skip page  on report skip 5   
--on page skip 2 on report skip 5
compute sum LABEL "SUBTOTAL" of bill_amt on city_name skip 2 
compute count LABEL "TOT. INS." of lodg_date  on city_name report skip 2
compute sum LABEL "GR.TOTAL" of bill_amt on report

ttitle center 'ICICI BANK LIMITED' skip 1 -
center  'REGIONAL PROCESSING CENTER, HYDERABAD' skip 2 -
center 'REPORT ON NATIONAL CLEARING CHEQUES AS ON ' '&dt1'  skip 1 -
left 'DATE : ' today_date  right 'PAGE :     ' format 999 sql.pno  skip 2

btitle  skip 2 left 'AUTHORISED SIGNATORY' 




spool nclgreport_hyd.lst

 
select 
       city_name,
	   sol.sol_id,
	   sol_desc,
	   lodg_date,
	   Bill_id,
       drawee_name,
       bill_amt
	      from blt, bct, cty, sol
				where reg_sub_type in ('NCCC', 'NCCP') 
                      and lodg_date='&dt1'
					  and blt.lodg_coll_br_code=bct.br_code
					  and bct.br_city_code=cty.city_code
					  and cty.city_code in ('BBY', 'CAL', 'ND', 'MDS')
					  and bill_stat is not null
					  and blt.sol_id=sol.sol_id
					  and ltrim(sol.sol_id) in ('0008', '0076', '0048', '0040', '0050', '0075' ) 
						order by city_name, bill_id 



/




clear breaks
clear compute
clear columns
ttitle off
btitle off

ttitle center 'ICICI BANK LIMITED' skip 1 -
center  'REGIONAL PROCESSING CENTER, HYDERABAD' skip 2 -
center 'CENTERWISE CONSOLIDATED REPORT ON' skip1 -
center 'NATIONAL CLEARING CHEQUES AS ON ' '&dt1' -
									 skip 1 -
left 'DATE : ' today_date  right 'PAGE :     ' format 999 sql.pno  skip 2

btitle  skip 2 left 'AUTHORISED SIGNATORY'

break on city_name skip 2 on drawee_name on report
compute count LABEL "TOT. INS." of count(bill_amt)  on city_name  skip 2
compute sum LABEL "BANKWISE TOTAL" of sum(bill_amt) on city_name skip 1
compute count LABEL "GR.TOT INS" of count(bill_amt) on report  skip 2
compute sum LABEL "GRAND TOTAL" of sum(bill_amt) on report skip 1


COLUMN city_name FORMAT A15 HEADING 'CITY'
COLUMN drawee_name  FORMAT A30 HEADING 'DRAWEE BANK'
column sum(bill_amt) heading 'AMOUNT' format       b999,99,99,999.99
column count(bill_amt) heading 'NO.OF CHQS'

select
       city_name,
       drawee_name,
         count(bill_amt)  ,
       sum(bill_amt) 
          from blt,bct,cty, sol
            where reg_sub_type in ('NCCC', 'NCCP')
                  and lodg_date ='&dt1'
               and blt.lodg_coll_br_code=bct.br_code
               and bct.br_city_code=cty.city_code
                  and bill_stat is not null
                  and blt.sol_id=sol.sol_id
				and ltrim(blt.sol_id) in ('0008', '0076','0048', '0040', '0050', '0075' )
        group by city_name, drawee_name
                      order by city_name
/

clear breaks
clear compute
clear columns
ttitle off
btitle off

ttitle center 'ICICI BANK LIMITED' skip 1 -
center  'REGIONAL PROCESSING CENTER, HYDERABAD' skip 2 -
   center 'BANKWISE CONSOLIDATED REPORT ON' skip 1 -
center 'NATIONAL CLEARING CHEQUES AS ON ' '&dt1' -
                                     skip 1 -
left 'DATE : ' today_date  right 'PAGE :     ' format 999 sql.pno  skip 2

btitle skip 2 left 'AUTHORISED SIGNATORY'

break on drawee_name skip 2 on city_name on report
compute count LABEL "TOT. INS." of count(bill_amt)  on drawee_name  skip 2
compute sum LABEL "BANKWISE TOTAL" of sum(bill_amt) on drawee_name skip 1
compute count LABEL "GR.TOT INS" of count(bill_amt) on report  skip 2
compute sum LABEL "GRAND TOTAL" of sum(bill_amt) on report skip 1


COLUMN city_name FORMAT A15 HEADING 'CITY'
COLUMN drawee_name  FORMAT A30 HEADING 'DRAWEE BANK'
column sum(bill_amt) heading 'AMOUNT' format       b999,99,99,999.99
column count(bill_amt) heading 'NO.OF CHQS'


select
       drawee_name,
	   city_name,
         count(bill_amt)  ,
       sum(bill_amt)
          from blt,bct,cty, sol
            where reg_sub_type in ('NCCC', 'NCCP')
                  and lodg_date ='&dt1'
               and blt.lodg_coll_br_code=bct.br_code
               and bct.br_city_code=cty.city_code
                  and bill_stat is not null
                  and blt.sol_id=sol.sol_id
                and ltrim(blt.sol_id) in ('0008', '0076','0048', '0040', '0050',
 '0075' )
        group by  drawee_name, city_name
                      order by drawee_name
/


spool off

clear breaks
clear compute
ttitle off
btitle off
set head on
set verify on
set termout on 
set trimspool off
----set wrap off
