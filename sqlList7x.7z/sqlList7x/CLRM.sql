REM####################################################################
REM File Name   : CLRM.sql
REM Description : Table creation for Locker Rent Maintenance
REM Author      : Prabhu.B (BBSSL)
REM Date        : 07-07-2008
REM Module	: LOCKER
REM####################################################################
drop table icici.cust_locker_rent_maintenance
/
drop public synonym CLRM
/
create table icici.cust_locker_rent_maintenance
(
	sol_id 			varchar2(8),
	location_code         	varchar2(10),
	locker_type		varchar2(5),
	Rent_Version_Code	varchar2(5),
	Rent_period		varchar2(3),
	rent_amt         	number(20,4),
	rent_effective_date  	date,
	del_flg                 char(1),
	entity_cre_flg  	char(2),
	LCHG_USER_ID    	VARCHAR2(15),
	LCHG_TIME       	date,
	RCRE_USER_ID    	VARCHAR2(15),
	RCRE_TIME       	date
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
CREATE INDEX IDX_CLRM ON icici.cust_locker_rent_maintenance(SOL_ID,location_code,locker_type,Rent_Version_Code)
TABLESPACE SYSTEM PCTFREE 10  STORAGE(INITIAL 10240 NEXT 10240 PCTINCREASE 50 ) 
/
CREATE UNIQUE INDEX UIDX_CLRM ON icici.cust_locker_rent_maintenance(SOL_ID,location_code,locker_type,Rent_Version_Code,Rent_period)
TABLESPACE SYSTEM PCTFREE 10  STORAGE(INITIAL 10240 NEXT 10240 PCTINCREASE 50 ) 
/
create public synonym CLRM for icici.cust_locker_rent_maintenance
/
grant select,insert,update,delete on CLRM to tbagen
/
grant select on CLRM to tbacust
/
grant select on CLRM to tbautil
/
grant all on CLRM to tbaadm
/
