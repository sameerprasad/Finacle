-- -----------------------------------------------------------------------------------#
-- Program Name    : fsgPspTmpDump.sql
-- Author          : Mandar Raddi
-- Date Written	   : 27-Feb-2001
--
-- -----------------------------------------------------------------------------------#   
-- Brief Description :                                                                #
-- -----------------------------------------------------------------------------------#
-- This PL/SQL program is responsible for creating Customer ID and Accout ID lists    #
-- in the PSP_TMP table for the given Sol ID. These two lists are required in the     #
-- Customer Statement generation process. This program creates the List id as         # 
-- Run ID (Input to the program) + 'C' for customer ids and Run ID + 'A' for accounts #
-- for the customers.                                                                 #
--                                                                                    #
-- In addition to generating the above two lists, the program also creates an output  #
-- file by name <Run ID>-CNA.dat which contains customer details for each customer in #
-- the input Sol ID.                                                                  #
-- -----------------------------------------------------------------------------------# 
--                                                                                    #
-- Input Parameters : &1 - Run Id for the Statement Generation                        #
--                    &2 - Sol Id                                                     #
--                    &3 - Start Date                                                 #
--                    &4 - End Date                                                   #
--                    &5 - Open/Exclude Indicator ('O', 'E' or 'A')                   #
--                    &6 - Customer Status Codes (quoted and comma delimied)          #
--                                                                                    #
-- Input Files      : None                                                            #
-- Output Files     : <Run ID>-CNA-<Sol Id>.dat                                       #
-- Called Programs  : None                                                            #
--                                                                                    #
-- -----------------------------------------------------------------------------------#
--                                 Version History                                    #
-- -----------------------------------------------------------------------------------#
--   Ver.No |     Date   |    Author    |           Reason For Change                 #
-- -----------------------------------------------------------------------------------#
--     1    | 27-02-2001 | Mandar Raddi | Initial Release                             #
-- -----------------------------------------------------------------------------------#

-- set serveroutput on size 1000000
set linesize 512
set trims    on
set feedback off
set verify   off
set head     off
set pages 0
-- spool &1-CNA-&2

-- -------------------------#
-- Start of DELCARE Section 
-- -------------------------#

DECLARE
	ciftCustId				ICICI_CIFT.CUST_ID%Type;
	cmgCustId				CMG.CUST_ID%Type;
	cmgCustTitleCode		CMG.CUST_TITLE_CODE%Type;
	cmgCustName				CMG.CUST_NAME%Type;
	cmgCustStatCode			CMG.CUST_STAT_CODE%Type;
	cmgPermAddr1			CMG.CUST_PERM_ADDR1%Type;
	cmgPermAddr2			CMG.CUST_PERM_ADDR2%Type;
	cmgCityCode				CMG.CUST_PERM_CITY_CODE%Type;
	cmgStateCode			CMG.CUST_PERM_STATE_CODE%Type;
	cmgCntryCode			CMG.CUST_PERM_CNTRY_CODE%Type;
	cmgPinCode				CMG.CUST_PERM_PIN_CODE%Type;
	custCity				RCT.REF_DESC%Type;
	custState				RCT.REF_DESC%Type;
	custCountry				RCT.REF_DESC%Type;
	gamForacid				GAM.FORACID%Type;
	gamSolId				GAM.SOL_ID%Type;
	custSolId				PSP_TMP.HOME_SOL_ID%Type;
	custRecType				VARCHAR(3);
	custSubRecType			VARCHAR(3);
	pspCustListId			PSP_TMP.LISTID%Type;
	pspAcctListId			PSP_TMP.LISTID%Type;
	out_record				VARCHAR(300);
    endOfCiftCursor         NUMBER;
    endOfGamCursor          NUMBER;
    skipThisCustId          CHAR;
    custStatSelectFlg       VARCHAR(2);
	fp						UTL_FILE.FILE_TYPE;
	
	CURSOR CIFT_CURSOR IS
	SELECT	
		CUST_ID
	FROM	
		ICICI_CFT
	WHERE	
		HOME_SOL_ID = '&2';


	CURSOR gamCur IS 
	SELECT	
		FORACID,
		SOL_ID
	FROM	
		GAM
	WHERE	
		CUST_ID      = cmgCustId
	AND	(SCHM_TYPE = 'SBA' OR ACCT_PREFIX = '05')
	AND	((ACCT_CLS_FLG = 'N' AND ACCT_OPN_DATE <= '&4') OR
		 (ACCT_CLS_FLG = 'Y' AND ACCT_CLS_DATE >= '&3'))
	AND	ENTITY_CRE_FLG = 'Y';


-- --------------------------------------------------------------------------------#
-- PROCEDURE to Select customer details from CMG. The customer id is selected from #
-- ICICI_CIFT for the input SOL ID                                                 #
-- --------------------------------------------------------------------------------#

    PROCEDURE getCmgData(dummy NUMBER) IS
    BEGIN
        BEGIN
            SELECT
                 CUST_ID
                ,CUST_TITLE_CODE
                ,CUST_NAME
                ,CUST_PERM_ADDR1
                ,CUST_PERM_ADDR2
                ,CUST_PERM_CITY_CODE
                ,CUST_PERM_STATE_CODE
                ,CUST_PERM_PIN_CODE
                ,CUST_STAT_CODE
				,CUST_PERM_CNTRY_CODE
            INTO
                 cmgCustId
                ,cmgCustTitleCode
                ,cmgCustName
                ,cmgPermAddr1
                ,cmgPermAddr2
                ,cmgCityCode
                ,cmgStateCode
                ,cmgPinCode
                ,cmgCustStatCode
				,cmgCntryCode
            FROM
                CMG
            WHERE
                CUST_ID = ciftCustId;

            EXCEPTION
                WHEN NO_DATA_FOUND THEN 
                	skipThisCustId := 'Y';
	                RETURN;
        END;

--        if( custStatSelectFlag = 'E' ) then
--           if (cmgCustStatCode IN (&6)) then
--              skipThisCustId := 'Y';
--             RETURN;
--        end if;
--   else if( custStatSelectFlag = 'O') then
--		if (cmgCustStatCode NOT IN (&6)) then
--			skipThisCustId := 'Y';
--			RETURN;
--		end if;
--	end if;
    END getCmgData;


    PROCEDURE getCodeDesc( dummy NUMBER ) IS
    BEGIN
        BEGIN
            SELECT
                REF_DESC
            INTO
                custCity
            FROM RCT
            WHERE
                REF_REC_TYPE = '01'
            AND REF_CODE     = cmgCityCode;

            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    NULL;
        END;

        BEGIN
            SELECT
                REF_DESC
            INTO
                custState
            FROM
                RCT
            WHERE
                REF_REC_TYPE = '02'
            AND REF_CODE     = cmgStateCode;

            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    NULL;
        END;

        BEGIN
            SELECT
                REF_DESC
            INTO
                custCountry
            FROM
                RCT
            WHERE
                REF_REC_TYPE = '03'
            AND REF_CODE     = cmgCntryCode;

            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    NULL;
        END;
    END;

	PROCEDURE insertPspTmp( pspListId VARCHAR2,
			                pspEntityId VARCHAR2,
			                pspEntityType CHAR,
						    pspHomeSolId VARCHAR2) IS
	BEGIN
		INSERT INTO
		PSP_TMP
			(LISTID
			,ENTITY_ID
			,ID_TYPE
			,HOME_SOL_ID)
		VALUES
			(pspListId
			,pspEntityId
			,pspEntityType
			,pspHomeSolId);
	END;


    PROCEDURE writeCustRec( dummy NUMBER ) IS
    BEGIN
		out_record := custSolId||'|'||
                      cmgCustId||'|'||
                      custRecType||'|'||
                      custSubRecType||'|'||
                      cmgCustTitleCode||' '||
                      cmgCustName||'|'||
                      cmgPermAddr1||'|'||
                      cmgPermAddr2||'|'||
                      custCity||'|'||
                      custState||'|'||
                      custCountry||'|'||
                      cmgPinCode;

		UTL_FILE.PUT_LINE(fp, out_record);
    END;


	PROCEDURE processGamCursor( dummy NUMBER) IS
	BEGIN
		FETCH gamCur INTO
			 gamForacid
			,gamSolId;
		
		if( gamCur%NOTFOUND ) then
			endOfGamCursor := 1;
			RETURN;
		end if; 

		UTL_FILE.PUT_LINE(fp, pspAcctListId|| '|' ||gamForacid || '|' ||gamSolId);
--        insertPspTmp(pspAcctListId, gamForacid, 'A', gamSolId);

	END;
			

    PROCEDURE processCiftCursor( dummy NUMBER ) IS
    BEGIN

        skipThisCustId := 'N';
        FETCH CIFT_CURSOR INTO
            ciftCustId;

        if( CIFT_CURSOR%NOTFOUND ) then
            endOfCiftCursor := 1;
            RETURN;
        end if;

        getCmgData(0);
        if( skipThisCustId = 'Y') then
            RETURN;
        end if;

		OPEN gamCur;
		endOfGamCursor := 0;

		WHILE endOfGamCursor = 0 LOOP
			processGamCursor(0);
		END LOOP;

		CLOSE gamCur;

--		insertPspTmp(pspCustListId, ciftCustId, 'C', custSolId);

        getCodeDesc(0);
        writeCustRec(0);
    END;


BEGIN
	custRecType       := '01';
	custSubRecType    := '0';
	custSolId         := '&2';
	pspCustListId     := '&1'||'C';
	pspAcctListId     := '&1'||'A';
    custStatSelectFlg := '&5';

	fp := UTL_FILE.FOPEN('/tmp','bull.dat','w');
	UTL_FILE.PUT_LINE(fp, 'Hello world');

--	DELETE FROM
--		PSP_TMP
--	WHERE
--		LISTID LIKE '&1%' 
--	AND HOME_SOL_ID = '&2';
--
	OPEN CIFT_CURSOR;
	endOfCiftCursor := 0;

	WHILE (endOfCiftCursor = 0) LOOP
		processCiftCursor(0);
	END LOOP;

	CLOSE CIFT_CURSOR;

	COMMIT;
	UTL_FILE.FCLOSE(fp);

EXCEPTION
  WHEN UTL_FILE.INVALID_PATH THEN
    RAISE_APPLICATION_ERROR(-20100,'Invalid Path');
  WHEN UTL_FILE.INVALID_MODE THEN
    RAISE_APPLICATION_ERROR(-20101,'Invalid Mode');
  WHEN UTL_FILE.INVALID_OPERATION then
    RAISE_APPLICATION_ERROR(-20102,'Invalid Operation');
  WHEN UTL_FILE.INVALID_FILEHANDLE then
    RAISE_APPLICATION_ERROR(-20103,'Invalid Filehandle');
  WHEN UTL_FILE.WRITE_ERROR then
    RAISE_APPLICATION_ERROR(-20104,'Write Error');
  WHEN UTL_FILE.READ_ERROR then
    RAISE_APPLICATION_ERROR(-20105,'Read Error');
  WHEN UTL_FILE.INTERNAL_ERROR then
    RAISE_APPLICATION_ERROR(-20106,'Internal Error');
  WHEN OTHERS THEN
    UTL_FILE.FCLOSE(fp);

END;
/
-- spool off
set verify   on
set head     on
set feedback on
