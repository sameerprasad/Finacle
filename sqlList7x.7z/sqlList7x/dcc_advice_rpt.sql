--=======================================================
-- Author : SUBHASISH PARAMANIK 
l
-- Date   :
-- [Author]         [Date]          [Line]      [Desc]
--=======================================================
CREATE OR REPLACE PACKAGE TBAADM.BG_DCC_STAX AS
PROCEDURE BG_DCC_STAXProc(  inp_str         IN VARCHAR2,
                out_retCode         OUT NUMBER,
                out_rec         OUT VARCHAR2) ;
g_mode        Char(1):= 'S';
END BG_DCC_STAX;
/
CREATE OR REPLACE PACKAGE BODY TBAADM.BG_DCC_STAX AS--{
------------------------------------------------------------------------------
TYPE rec_output IS RECORD(record_output  VARCHAR2(2000));
TYPE output_type IS TABLE OF rec_output INDEX BY BINARY_INTEGER;
output_table                            OUTPUT_TYPE;
g_number                                NUMBER;
g_current_row                           BINARY_INTEGER;
v_insert_row                            BINARY_INTEGER;
g_rowcount                              NUMBER;
------------------------------------------------------------------------------
-- GLOBAL VARIABLE
Input_bgNum                             BGM.BG_SRL_NUM%type;
Input_From_Date                         VARCHAR2(10);
------------------------------------------------------------------------------
CURSOR Cur_bg1(Input_bgNum BGM.BG_SRL_NUM%type,Input_From_Date date)
    IS
SELECT  actual_amt_coll,
		chrg_tran_id,
		chrg_tran_date,
		nvl(ptran_bus_type,'!') ptran_bus_type,
		tran_rmks,
		event_type,
		event_id
FROM   	cxl 
where   comp_b2kid =(select bg_b2kid from bgm where bg_srl_num=Input_bgNum)
AND 	chrg_tran_date	=	Input_From_Date
order by chrg_tran_id;

PROCEDURE BG_DCC_STAXProc(  inp_str         IN VARCHAR2,
			    out_RetCode         OUT NUMBER,
			    out_rec         OUT VARCHAR2)
IS
OutArr                      basp0099.ArrayType;
v_record_output             VARCHAR2(2000);
-------------------------------------------------------------------
-- Local Variable
v_sol_id					BGM.SOL_ID%TYPE;
v_bg_type					BGM.BG_TYPE%TYPE;
v_bg_class					BGM.BG_CLASS%TYPE;
v_bg_amt					BGM.BG_AMT%TYPE;
v_bg_crncy_code				BGM.CRNCY_CODE%TYPE;
v_cust_id					BGM.CUST_ID%TYPE;
v_bg_exp_date				BGM.BG_EXPIRY_DATE%TYPE;
v_claim_exp_date			BGM.CLAIM_EXPIRY_DATE%TYPE;
v_beneficiary_name			BGM.BENEFICIARY_NAME%TYPE;
v_beneficiary_addr_1		BGM.BENEFICIARY_ADDR_1%TYPE;
v_beneficiary_addr_2		BGM.BENEFICIARY_ADDR_2%TYPE;
v_city_code					BGM.CITY_CODE%TYPE;
v_city_code_bene			RCT.REF_DESC%TYPE;
v_state_code				BGM.STATE_CODE%TYPE;
v_cntry_code				BGM.CNTRY_CODE%TYPE;
v_cntry_code_bene			RCT.REF_DESC%TYPE; 
v_pin_code					BGM.PIN_CODE%TYPE;
v_oper_acid					BGM.OPER_ACID%TYPE;

v_tax_amt					ICICI_BTX.TAX_AMT%TYPE;
v_foracid					GAM.FORACID%TYPE;

v_cust_name                 CMG.cust_name%TYPE;
v_cust_comu_addr1           CMG.cust_comu_addr1%TYPE;
v_cust_comu_addr2           CMG.cust_comu_addr2%TYPE;
v_cust_comu_city_code       CMG.cust_comu_city_code%TYPE;
v_cust_comu_state_code      CMG.cust_comu_state_code%TYPE;
v_cust_comu_pin_code        CMG.cust_comu_pin_code%TYPE;
v_cust_comu_cntry_code      CMG.cust_comu_cntry_code%TYPE;
v_cust_comu_city			RCT.REF_DESC%TYPE;
v_cust_comu_state			RCT.REF_DESC%TYPE;
v_cust_comu_cntry			RCT.REF_DESC%TYPE;
v_sol_desc					SOL.SOL_DESC%TYPE;
v_addr_1					SOL.addr_1%TYPE;
v_addr_2					SOL.addr_2%TYPE;
v_city					SOL.city_code%TYPE;
v_state				SOL.state_code%TYPE;
v_pin_code_sol				SOL.pin_code%TYPE;

v_sol_city					RCT.REF_DESC%TYPE;
v_sol_state					RCT.REF_DESC%TYPE;

v_loop_cnt					VARCHAR2(1 CHAR);
v_total						NUMBER(20,6) :='0';

v_ect_srl_num				dcc.ect_srl_num%type;
v_dcc_key_srl_num			dcc.dcc_key_srl_num%type;

v_pstd_flg_cnt				NUMBER(5);
v_tran_stat					VARCHAR2(8);
v_tax_tran_id				CHT.TRAN_ID%TYPE:='';
v_tax_pstd_flg_cnt			NUMBER(5);
------------------------------------------------------------------
BEGIN --{
        out_retCode := 0;
        out_rec := '';

        IF g_mode = 'S'  THEN --{
        basp0099.formInputArr(inp_str,OutArr);

            Input_bgNum         :=      OutArr(0);
            Input_From_Date     :=      to_char(to_date(OutArr(1),'DD-MM-YYYY'),'DD-MM-YYYY');
            dbms_output.put_line('BGNum'||Input_bgNum);
            dbms_output.put_line('FROM_DATE'||Input_From_Date);
------------------------------------------------------------------------------
        v_insert_row := 0;
		v_loop_cnt := 'Y';
		For Cur_bg IN Cur_bg1(Input_bgNum,Input_From_Date)
        LOOP                --{
			IF(v_loop_cnt = 'Y') THEN
			BEGIN
				SELECT		SOL_ID,	
							BG_TYPE,
							BG_CLASS,	
							BG_AMT,
							CRNCY_CODE,	
							CUST_ID,
							BG_EXPIRY_DATE,
							CLAIM_EXPIRY_DATE,
							BENEFICIARY_NAME,
							BENEFICIARY_ADDR_1,
							BENEFICIARY_ADDR_2,
							CITY_CODE,
							STATE_CODE,	
							CNTRY_CODE,
							PIN_CODE,
							OPER_ACID
				INTO		v_sol_id,	
							v_bg_type,
							v_bg_class,
							v_bg_amt,
							v_bg_crncy_code,
							v_cust_id,
							v_bg_exp_date,
							v_claim_exp_date,
							v_beneficiary_name,
							v_beneficiary_addr_1,
							v_beneficiary_addr_2,
							v_city_code,
							v_state_code,
							v_cntry_code,
							v_pin_code,
							v_oper_acid
				FROM		BGM
				WHERE		BG_SRL_NUM = Input_bgNum;
			EXCEPTION WHEN NO_DATA_FOUND THEN
				v_bg_type := '';
			END;
			
           BEGIN
               SELECT      cust_name,
                           cust_comu_addr1,
                           cust_comu_addr2,
                           cust_comu_city_code,
                           cust_comu_state_code,
                           cust_comu_pin_code,
                           cust_comu_cntry_code
               INTO        v_cust_name,
                           v_cust_comu_addr1,
                           v_cust_comu_addr2,
                           v_cust_comu_city_code,
                           v_cust_comu_state_code,
                           v_cust_comu_pin_code,
                           v_cust_comu_cntry_code
               FROM        CMG
               WHERE       CUST_ID = v_cust_id;
           EXCEPTION       WHEN NO_DATA_FOUND THEN
               v_cust_name := '';
               v_cust_comu_addr1 := '';
               v_cust_comu_addr2 := '';
               v_cust_comu_city_code := '';
               v_cust_comu_state_code := '';
               v_cust_comu_pin_code := '';
               v_cust_comu_cntry_code := '';
           END;
		   
		    BEGIN
				SELECT		SOL_DESC,
							ADDR_1,
							ADDR_2,
							CITY_CODE,
							STATE_CODE,
							PIN_CODE
				INTO		v_sol_desc,
							v_addr_1,
							v_addr_2,
							v_city,
							v_state,
							v_pin_code_sol
				FROM		SOL
				WHERE		SOL_ID = v_sol_id;
	 		EXCEPTION WHEN NO_DATA_FOUND THEN
				v_sol_desc := '';
				v_addr_1 := '';
				v_addr_2 := '';
				v_city := '';
				v_state := '';
				v_pin_code_sol := '';
			END;
					if(v_city is not null)then
						begin
							select		REF_DESC
							into		v_sol_city
							from 		RCT
							where		REF_CODE = v_city
							and 		REF_REC_TYPE='01';
						exception WHEN NO_DATA_FOUND then
							v_sol_city := '';
						end;
					end if;
					
                    if(v_state is not null)then
                        begin
                            select      REF_DESC
                            into        v_sol_state
                            from        RCT
                            where       REF_CODE = v_state
							and 		REF_REC_TYPE='02';
                        exception WHEN NO_DATA_FOUND then
                            v_state_code := '';
                        end;
                    end if;
                    
					if(v_cust_comu_state_code is not null)then
                        begin
                            select      REF_DESC
                            into        v_cust_comu_state
                            from        RCT
                            where       REF_CODE = v_cust_comu_state_code
							and 		REF_REC_TYPE='02';
                        exception WHEN NO_DATA_FOUND then
                            v_cust_comu_state := '';
                        end;
                    end if;										

                    if(v_cust_comu_cntry_code is not null)then
                        begin
                            select      REF_DESC
                            into        v_cust_comu_cntry
                            from        RCT
                            where       REF_CODE = v_cust_comu_cntry_code
							and 		REF_REC_TYPE='03';
                        exception WHEN NO_DATA_FOUND then
                            v_cust_comu_cntry := '';
                        end;
                    end if;					

                    if(v_cust_comu_city_code is not null)then
                        begin
                            select      REF_DESC
                            into       	v_cust_comu_city 
                            from        RCT
                            where       REF_CODE = v_cust_comu_city_code
							and 		REF_REC_TYPE='01';
                        exception WHEN NO_DATA_FOUND then
                            v_cust_comu_city := '';
                        end;
                    end if;
					if(v_city_code is not null)then
						begin
							select      REF_DESC
							into        v_city_code_bene
							from        RCT
							where       REF_CODE = v_city_code
							and 		REF_REC_TYPE='01';
						exception WHEN NO_DATA_FOUND then
							v_city_code_bene := '';
						end;
					end if;		
					if(v_cntry_code is not null)then
						if(v_cntry_code = 'IN')then
							begin
								select      REF_DESC
								into        v_cntry_code_bene
								from        RCT
								where       REF_CODE = v_cntry_code
								and 		REF_REC_TYPE = '03';
							exception WHEN NO_DATA_FOUND then
								v_cntry_code_bene := '';
							end;
						else
							begin
								select      REF_DESC
								into        v_cntry_code_bene
								from        RCT
								where       REF_CODE = v_cntry_code
								and 		REF_REC_TYPE = '03';
							exception WHEN NO_DATA_FOUND then
                                v_cntry_code_bene := '';
                            end;
						end if;
					end if;
	        END IF;
        	v_loop_cnt := 'N';

			BEGIN
				select	ect_srl_num, dcc_key_srl_num
				into	v_ect_srl_num,v_dcc_key_srl_num
				from ect,dcc 
				where ect.b2k_id = dcc.b2k_id
				and   ect.b2kid_type = dcc.b2kid_type
				and   ect.ptran_bus_type = dcc.ptran_bus_type
				and   ect.ect_key_srl_num = dcc.ect_srl_num
				and   ect.b2k_id in (select bg_b2kid from bgm where bg_srl_num = Input_bgNum)
				and   ect.event_id = Cur_bg.event_id
				and   ect.event_type = Cur_bg.event_type
				and   dcc.tran_date =Cur_bg.chrg_tran_date
				and   dcc.ptran_bus_type = Cur_bg.PTRAN_BUS_TYPE
				and   dcc.tran_id = lpad(Cur_bg.chrg_tran_id,9,' ')
				and   dcc.tran_amt = Cur_bg.actual_amt_coll;
				EXCEPTION WHEN NO_DATA_FOUND THEN
				v_ect_srl_num := '';
				v_dcc_key_srl_num := '';
				when others then
				v_ect_srl_num := '';
				v_dcc_key_srl_num := '';
			END;
			
dbms_output.put_line('ect'||'|'||Input_bgNum||'|'||Cur_bg.chrg_tran_id||'|'||Cur_bg.chrg_tran_date||'|'||Cur_bg.event_id||'|'||Cur_bg.actual_amt_coll||'|'||Cur_bg.event_type||'|'||v_ect_srl_num||'|'||Cur_bg.PTRAN_BUS_TYPE);

if (v_ect_srl_num is null)  then
            BEGIN
                select  ect_key_srl_num
                into    v_ect_srl_num
                from ect
                where ect.b2k_id in (select bg_b2kid from bgm where bg_srl_num = Input_bgNum)
                and   ect.event_id = Cur_bg.event_id
                and   ect.event_type = Cur_bg.event_type
                and   ect.ptran_bus_type = Cur_bg.PTRAN_BUS_TYPE
				and   ect.TTL_CHRG_COLL_AMT = Cur_bg.actual_amt_coll;
                EXCEPTION WHEN NO_DATA_FOUND THEN
                v_ect_srl_num := '';
                when others then
                v_ect_srl_num := '';
            END;
dbms_output.put_line('INNNNNNNN'||'|'||Input_bgNum||'|'||Cur_bg.chrg_tran_id||'|'||Cur_bg.chrg_tran_date||'|'||Cur_bg.event_id||'|'||Cur_bg.actual_amt_coll||'|'||Cur_bg.event_type||'|'||v_ect_srl_num||'|'||Cur_bg.PTRAN_BUS_TYPE);
end if;

    if (v_ect_srl_num is null) then
		BEGIN
			select ECT_SRL_NUM 
			into v_ect_srl_num
			from cht 
			where   cht.b2k_id in (select bg_b2kid from bgm where bg_srl_num = Input_bgNum)
			and   cht.event_id = Cur_bg.event_id
			and   cht.event_type = Cur_bg.event_type
			and   ((cht.ptran_bus_type = Cur_bg.ptran_bus_type) OR  (cht.ptran_bus_type is null)) 
			and   tran_date = Cur_bg.chrg_tran_date
			and   tran_id = lpad(Cur_bg.chrg_tran_id,9,' ');
			EXCEPTION WHEN NO_DATA_FOUND THEN
			v_ect_srl_num := '';
			when others then
			v_ect_srl_num := '';
		END;
    end if;

		
			BEGIN 
				SELECT		FORACID
				INTO		v_foracid
				FROM		GAM
				WHERE		ACID   = v_oper_acid;
			EXCEPTION WHEN NO_DATA_FOUND THEN
				v_foracid := '';
			END;	


			-- this blockis used to check whether the deffered tran is posted ?
			-- If noy posted then v_tran_stat will mafe "F" and the tran would not appear in report
            if(Cur_bg.chrg_tran_id is not null)then
                BEGIN
                    select sum(pstd_flg_cnt) INTO        v_pstd_flg_cnt FROM(
                    SELECT      COUNT(*)    pstd_flg_cnt FROM     DTD
                    WHERE       TRAN_ID   = lpad(Cur_bg.chrg_tran_id,'9',' ')
                    AND         TRAN_DATE = Cur_bg.chrg_tran_date
                    AND         PSTD_FLG !='Y'
                    and         ACID = (select acid from gam where foracid =v_foracid)
                    union all
                    SELECT      COUNT(*)    pstd_flg_cnt FROM     HTD
                    WHERE       TRAN_ID   = lpad(Cur_bg.chrg_tran_id,'9',' ')
                    AND         TRAN_DATE = Cur_bg.chrg_tran_date
                    AND         PSTD_FLG !='Y'
                    and         ACID = (select acid from gam where foracid =v_foracid));
                EXCEPTION WHEN NO_DATA_FOUND THEN
                    v_pstd_flg_cnt := '';
                END;
                if(v_pstd_flg_cnt > 0)then
                    v_tran_stat := 'F';
                else
                    v_tran_stat := 'S';
                end if;
            end if;

dbms_output.put_line('N---'||'|'||v_tran_stat);


	if (v_tran_stat = 'S') then 
			BEGIN
				SELECT		TAX_AMT,TAX_TRAN_ID
				INTO		v_tax_amt,v_tax_tran_id
				FROM		ICICI_BTX
				WHERE		BG_SRL_NUM = Input_bgNum
				AND 		TRAN_ID = lpad(Cur_bg.chrg_tran_id,9,' ')
				AND			TRAN_DATE = Cur_bg.chrg_tran_date
				AND			EVENT_ID = Cur_bg.event_id
				AND 		tran_amt =Cur_bg.actual_amt_coll
				AND			EVENT_TYPE = Cur_bg.event_type
				and 		ECT_SRL_NUM = v_ect_srl_num;
			EXCEPTION WHEN NO_DATA_FOUND THEN
				v_tax_amt := 0;
				v_tax_tran_id := '';
				when others then
				v_tax_amt := 0;
				v_tax_tran_id := '';
			END;
		else
			v_tax_amt := 0;
			v_tax_tran_id := '';
		end if;

dbms_output.put_line('N---'||'|'||v_tran_stat||'|'||v_tax_amt||'|'||v_tax_tran_id);
				
            if(v_tax_tran_id is not null)then
                BEGIN
                    select sum(pstd_flg_cnt) INTO        v_tax_pstd_flg_cnt FROM(
                    SELECT      COUNT(*)    pstd_flg_cnt FROM     DTD
                    WHERE       TRAN_ID   = lpad(v_tax_tran_id,'9',' ')
                    AND         TRAN_DATE = Cur_bg.chrg_tran_date
                    AND         PSTD_FLG !='Y'
                    and         ACID = (select acid from gam where foracid =v_foracid)
                    union all
                    SELECT      COUNT(*)    pstd_flg_cnt FROM     HTD
                    WHERE       TRAN_ID   = lpad(v_tax_tran_id,'9',' ')
                    AND         TRAN_DATE = Cur_bg.chrg_tran_date
                    AND         PSTD_FLG !='Y'
                    and         ACID = (select acid from gam where foracid =v_foracid));
                EXCEPTION WHEN NO_DATA_FOUND THEN
                    v_tax_pstd_flg_cnt := '';
                END;
                if(v_tax_pstd_flg_cnt > 0)then
					-- Tax tran id is not posted Making tax amount zero so that it will not display in report
                    v_tax_amt := 0;
                end if;
            end if;
dbms_output.put_line('N---'||'|'||v_tran_stat||'|'||v_tax_amt||'|'||v_tax_tran_id||'|'||v_tax_pstd_flg_cnt);

dbms_output.put_line('----'||'|'||Input_bgNum||'|'||Cur_bg.chrg_tran_id||'|'||Cur_bg.chrg_tran_date||'|'||Cur_bg.event_id||'|'||Cur_bg.actual_amt_coll||'|'||Cur_bg.event_type||'|'||v_ect_srl_num||'|'||v_tax_amt);
			
			v_total := Cur_bg.actual_amt_coll + v_tax_amt;	
														
--------------------------------------------------------------------------
     v_insert_row:=v_insert_row+1;
---------------------------------------------------------------------------
		
	if (v_tran_stat = 'S') then 
         v_record_output:=	Input_bgNum				||'|'||
                Cur_bg.actual_amt_coll 			||'|'||
				Cur_bg.chrg_tran_id                      ||'|'||
				Cur_bg.chrg_tran_date                    ||'|'||
				Cur_bg.ptran_bus_type               ||'|'||
				Cur_bg.tran_rmks                    ||'|'||
				v_bg_type                           ||'|'||
				v_bg_class              ||'|'||
				v_bg_amt                ||'|'||
				v_bg_crncy_code			||'|'||
				v_cust_id               ||'|'||
				v_bg_exp_date               ||'|'||
				v_claim_exp_date            ||'|'||
				v_beneficiary_name          ||'|'||
				v_beneficiary_addr_1            ||'|'||
				v_beneficiary_addr_2            ||'|'||
				v_city_code_bene             ||'|'||
				v_state_code                ||'|'||
				v_cntry_code_bene                ||'|'||
				v_pin_code              ||'|'||
				v_oper_acid             ||'|'||
				--v_tran_date_head                ||'|'||
				v_cust_name             ||'|'||
				v_cust_comu_addr1           ||'|'||
				v_cust_comu_addr2                   ||'|'||
				v_cust_comu_city           ||'|'||
				v_cust_comu_state          ||'|'||
				v_cust_comu_pin_code            ||'|'||
				v_cust_comu_cntry          ||'|'||
				v_tax_amt               ||'|'||
				v_foracid               ||'|'||
				v_sol_desc    			||'|'||
				v_addr_1      			||'|'||
				v_addr_2      			||'|'||
				v_pin_code_sol			||'|'||
				v_sol_city    			||'|'||
				v_sol_state   			||'|'||
				Input_From_Date			||'|'||
				v_total;			

        output_table(v_insert_row).Record_output:=v_record_output;

	end if;

				dbms_output.put_line('de intial');
				-- re intializing the values
				v_tax_amt	:= '0';
				v_total		:= '0';
				v_ect_srl_num		:='';
				v_dcc_key_srl_num	:= '';
				v_pstd_flg_cnt		:= '';
				v_tran_stat			:= '';			
				v_tax_tran_id		:= '';
				v_tax_pstd_flg_cnt	:= '';

				dbms_output.put_line('end');
---------------------------------------------------------------------------
---------------------------------------------------------------------------
-------------------------------------------------------------------------
        END LOOP;           --}

-------------------------------------------------------------------------

                g_mode := 'G';
                g_rowcount := output_table.Count;
                g_current_row := 0;

                ELSIF g_mode = 'G' THEN --}{
                        g_current_row := g_current_row + 1;
                        IF g_current_row > g_rowcount
                        THEN
                                output_table.delete ;
                                g_current_row := 0;
                                g_rowcount := 0;
                                out_retcode := 1;
                                g_mode := 'S' ;
                                Return ;
                        END IF;
                        out_rec := output_table(g_current_row).record_output;
        END IF; --}
-------------------------------------------------------------------------
END BG_DCC_STAXProc; --}
END BG_DCC_STAX; --}
/
DROP PUBLIC SYNONYM  BG_DCC_STAX
/
CREATE PUBLIC SYNONYM  BG_DCC_STAX FOR  TBAADM.BG_DCC_STAX
/
GRANT EXECUTE ON  TBAADM.BG_DCC_STAX TO TBAGEN, TBAUTIL, TBACUST
/
