--------------------------------------------
--File Name   : Report_Rprpt.sql
--Description : Risk profiling Report
--Author      : Priscilla & Vijay
--Date        : 01-06-2010
------------------------------------------

set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_Rprpt.lst

DECLARE

lv_solid         gam.sol_id%type :='&1';
lv_frmdate       date:='&2';
lv_todate        date:='&3';
v_riskprofile	 varchar2(20);

CURSOR c1 IS
select clmt.sol_id,
        wlckm.rack_id,
        cmg.cust_id locref_no,
        clmt.locker_type,
        clmt.locker_num,
        substr(cmg.cust_name,1,40) cust_name,
        (case when cmg.CUST_HLTH_CODE in ('03','02','01') then cmg.CUST_HLTH_CODE else '03' end) risk_profile
from    clmt,wlckm,cmg,lcops
where   wlckm.locker_num = clmt.locker_num
and     lcops.LOCKER_NO = clmt.locker_num
and     wlckm.sol_id = clmt.sol_id
and     clmt.sol_id = lcops.sol_id
and     lpad(clmt.cust_id,9,' ') = cmg.cust_id
and     wlckm.status = 'U'
and     clmt.sol_id = lv_solid
and	(CHECK_DATE||' '||CHECK_IN_TIME) = (  SELECT max(CHECK_DATE||' '||CHECK_IN_TIME)
	FROM
	LCOPS WHERE CHECK_DATE between lv_frmdate and lv_todate
	AND     LOCKER_NO = CLMT.LOCKER_NUM
	AND     SOL_ID = lv_solid
	AND     DEL_FLG != 'Y'
	)
and     clmt.del_flg != 'Y'
AND     WLCKM.DEL_FLG != 'Y'
AND     LCOPS.DEL_FLG != 'Y'
AND     CLMT.ENTITY_CRE_FLG = 'Y'
AND     WLCKM.ENTITY_CRE_FLG = 'Y';

BEGIN

    for f1 in c1

    loop
	BEGIN
	--{	
		SELECT REF_DESC 
		into v_riskprofile 
		FROM RCT 
		WHERE REF_REC_TYPE = '24' AND 
		REF_CODE = f1.risk_profile
		AND DEL_FLG!='Y';
	EXCEPTION WHEN NO_DATA_FOUND THEN
		v_riskprofile := null;
	--}
	END;

    v_riskprofile := f1.risk_profile ||'-'||v_riskprofile;
      
	dbms_output.put_line( 	f1.sol_id         ||'|'||
	      					f1.rack_id        ||'|'||
		      				f1.locref_no      ||'|'||	 	
		      				f1.locker_type    ||'|'||
		      				f1.locker_num     ||'|'||
		      				f1.cust_name      ||'|'||
                      		v_riskprofile
						); 	
	       	     
   end loop; 
END;
/
spool off
