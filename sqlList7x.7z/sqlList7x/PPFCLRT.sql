REM####################################################################
REM File Name   : PPFCLRT.sql
REM Description : Table creation for custom PPF Reversal Transaction table
REM Author      : E.K.R.MADAN (BBSSL)
REM Date        : 11-05-2010
Rem     Module  : PPF    
REM####################################################################
drop table icici.cust_ppf_reversal_tran
/
drop public synonym PPFCLRT
/
create table icici.cust_ppf_reversal_tran
(
	sol_id 		varchar(8),
    CR_FORACID  varchar(16),
	DR_FORACID  varchar(16),
    CR_TRAN_AMT				NUMBER(20,4),
	DR_TRAN_AMT             NUMBER(20,4),
	org_tran_id	VARCHAR2(9),
	org_tran_date   DATE,
	rev_tran_id     VARCHAR2(9),
	rev_tran_date   DATE,
	org_part_tran__no VARCHAR2(4),
	LCHG_USER_ID    VARCHAR2(15),
	LCHG_TIME       date,
	RCRE_USER_ID    VARCHAR2(15),
	RCRE_TIME       date,
	PSTD_FLG        char(1),
	del_flg         char(1),
	REVERSED_FLG     char(1)
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE ICICI_CUST
/* STORE_END */
/
CREATE INDEX IDX_cust_ppf_reversal_tran ON ICICI.cust_ppf_reversal_tran(SOL_ID,CR_FORACID,DR_FORACID)
TABLESPACE ICICI_IDX_CUST
/
CREATE INDEX IDX_cust_ppf_rev_tranid ON ICICI.cust_ppf_reversal_tran(org_tran_id,org_tran_date)
TABLESPACE ICICI_IDX_CUST
/
CREATE unique INDEX UIDX_cust_ppf_reversal_tran ON ICICI.cust_ppf_reversal_tran(SOL_ID,CR_FORACID,DR_FORACID,org_tran_id,org_tran_date,rev_tran_id,rev_tran_date)
TABLESPACE ICICI_IDX_CUST
/
create public synonym PPFCLRT for icici.cust_ppf_reversal_tran
/
grant select,insert,update,delete on PPFCLRT to tbagen
/
grant select on PPFCLRT to tbacust
/
grant all on PPFCLRT to tbaadm
/
grant select on PPFCLRT to tbautil
/
