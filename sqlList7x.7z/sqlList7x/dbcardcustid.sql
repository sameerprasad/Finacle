rem this sql is to give custids where debit card request is recd

set pagesize 66
set linesize 132

spool dbcardcustid

select 'cust-ids with VD in card type 1' from dual
/

select cust_id, card_1_name from ici_cdt
where card_1_name is not null and card_1_number  = 'VD'
/

select 'cust-ids with VD in card type 2' from dual
/

select cust_id, card_2_name from ici_cdt
where card_2_name is not null and card_2_number  = 'VD'
/

select 'cust-ids with VD in card type 3' from dual
/

select cust_id, card_3_name from ici_cdt
where card_3_name is not null and card_3_number  = 'VD'
/

select 'cust-ids with VD in card type 4' from dual
/

select cust_id, card_4_name from ici_cdt
where card_4_name is not null and card_4_number  = 'VD'
/

select 'cust-ids with VD in card type 5' from dual
/

select cust_id, card_5_name from ici_cdt
WHERe card_5_name is not null and card_5_number  = 'VD'
/

spool off

