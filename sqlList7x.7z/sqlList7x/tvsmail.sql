set feedback off
set verify   off
set echo     off
set lines 100
--set page 60
--*********ici1486 abhishek for sending int upload mail**********
spool &1
select RPAD(ICV.START_DATE,15) START_DATE, RPAD(ICV.INT_TBL_CODE,15) INT_CODE, RPAD(ICV.CRNCY_CODE,15) CCY_CODE
from icv 
 where ICV.INT_TBL_CODE=replace('&2','0','')
 and To_char(ICV.LCHG_TIME,'dd-mm-yyyy') = to_Char(SYSDATE,'dd-mm-yyyy')
 and ICV.CRNCY_CODE='&3'
/
select RPAD(TVS.MAX_CONTRACTED_MTHS,15) MAX_CONT_MTHS, RPAD(TVS.MAX_CONTRACTED_DAYS,15) MAX_CONT_DAYS, RPAD(TVS.NRML_INT_PCNT,15) NORMAL_RATE, RPAD(TVS.PENAL_PCNT,15) PENAL_RATE
from tvs
 where TVS.INT_TBL_CODE=replace('&2','0','')
 and TVS.CRNCY_CODE='&3'
 and To_char(TVS.LCHG_TIME,'dd-mm-yyyy') = to_Char(SYSDATE,'dd-mm-yyyy')
 and TVS.MAX_CONTRACTED_MTHS !='999' 
/
spool off
exit
