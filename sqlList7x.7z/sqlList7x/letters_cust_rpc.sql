set verify off
set wrap on
set feedback off
set linesize 400
set space 1
set heading off
alter session set nls_date_format='DD-MON-YYYY';
set serveroutput on size 1000000;
declare
acctno gam.foracid%type;
ccustid cmg.cust_id%type;
c1title1 cmg.cust_title_code%type;
c1name  cmg.cust_name%type;
c1addr1 cmg.cust_comu_addr1%type;
c1addr2 cmg.cust_comu_addr2%type;
cpin cmg.cust_comu_pin_code%type;
c1title2 cmg.cust_title_code%type;
c1title3 cmg.cust_name%type;
scity rct.ref_desc%type;
sstate rct.ref_desc%type;
scntry rct.ref_desc%type;
ccity cmg.cust_comu_city_code%type;
cstate cmg.cust_comu_state_code%type;
ccntry  cmg.cust_comu_cntry_code%type;
sstatec rct.ref_desc%type;
scityc rct.ref_desc%type;
scntryc rct.ref_desc%type;
dt gct.db_stat_date%type;
aref_desc rct.ref_desc%type;
bref_desc rct.ref_desc%type;
cref_desc rct.ref_desc%type;
dref_desc rct.ref_desc%type;
eref_desc rct.ref_desc%type;
branchname bct.br_name%type;
saddr1 sol.addr_1%type;
saddr2 sol.addr_2%type;
spin sol.pin_code%type;
c2title cmg.cust_title_code%type;
c2name  cmg.cust_name%type;
c2addr1 cmg.cust_comu_addr1%type;
c2addr2 cmg.cust_comu_addr2%type;
dbsdate gct.db_stat_date%type;
loc_fp                          utl_file.file_type;
loc_filename                    varchar2(200);
loc_filepath                    varchar2(100);
loc_filemode                    varchar(10);
cursor cmgcur is
select  y.cust_id,g.foracid,
	decode(y.cust_title_code,NULL,'',y.cust_title_code),
	decode(y.cust_name,NULL,'',y.cust_name),
	decode(y.cust_comu_addr1,NULL,'',y.cust_comu_addr1),
 	decode(y.cust_comu_addr2,NULL,'',y.cust_comu_addr2),
	decode(y.cust_comu_pin_code,NULL,'',y.cust_comu_pin_code),
	decode(y.cust_title_code, 'M/S', 'Sirs',y.cust_title_code),
	decode(y.cust_title_code, 'M/S', '',y.cust_name),
	y.cust_comu_city_code,
	y.cust_comu_state_code,
	y.cust_comu_cntry_code,
	decode(bct.br_name,NULL,' ',bct.br_name)
from gam g,cmg y,bct where
y.entity_cre_flg = 'Y'
and  y.rcre_time > (select to_char(db_stat_date,'dd-mon-yyyy') from gct)
and y.del_flg = 'N'
and g.cust_id = y.cust_id
and y.cust_stat_code not like 'P%'
and bct.br_code = substr(ltrim(y.cust_id),1,2);

begin --{
open cmgcur;
loc_filepath := '&1';
        loc_filename := 'cust.lst';
        loc_filemode := 'w';
        loc_fp := utl_file.fopen(loc_filepath, loc_filename, loc_filemode);
loop --{

fetch cmgcur into ccustid,acctno,c1title1,c1name,c1addr1,c1addr2,cpin,c1title2,c1title3,ccity,cstate,ccntry,branchname;
exit when cmgcur%notfound;
begin --{
begin --{
select decode(a.ref_desc,NULL,' ',a.ref_desc) into aref_desc
from rct a
where   a.ref_rec_type = '01'
and     a.ref_code = ccity
and     a.del_flg = 'N';
exception 
when no_data_found then
aref_desc:='*';
end; --}
begin --{
select decode(b.ref_desc,NULL,' ',b.ref_desc) into bref_desc
from rct b
where   b.ref_rec_type = '02'
and     b.ref_code = cstate
and     b.del_flg = 'N';
exception 
when no_data_found then
bref_desc:='*';
end; --}
begin --{
select decode(c.ref_desc,NULL,' ',c.ref_desc) into cref_desc
from rct c
where   c.ref_rec_type = '03'
and     c.ref_code = ccntry
and     c.del_flg = 'N';
exception
when no_data_found then
cref_desc:='*';
end; --}
begin --{
select addr_1,addr_2,pin_code,city_code,state_code into saddr1,saddr2,spin,scityc,sstatec
from sol
where  br_code = substr(ltrim(ccustid),1,2);
exception
when no_data_found then
saddr1:='*';
saddr2:='*';
spin:=0;
end; --}
begin --{
select decode(c.ref_desc,NULL,' ',c.ref_desc) into scity
from rct c
where   c.ref_rec_type = '01'
and     c.ref_code = scityc
and     c.del_flg = 'N';
exception
when no_data_found then
cref_desc:='*';
end; --}
begin --{
select decode(c.ref_desc,NULL,' ',c.ref_desc) into sstate
from rct c
where   c.ref_rec_type = '02'
and     c.ref_code = sstatec
and     c.del_flg = 'N';
exception
when no_data_found then
cref_desc:='*';
end; --}
begin --{
select decode(c.ref_desc,NULL,' ',c.ref_desc) into scntry
from rct c
where   c.ref_rec_type = '03'
and     c.ref_code = scntryc
and     c.del_flg = 'N';
exception
when no_data_found then
cref_desc:='*';
end; --}
begin --{
select db_stat_date into dt
from gct c;
exception
when no_data_found then
dt:='*';
end; --}
utl_file.put_line(loc_fp,c1title1||'|'||c1name||'|'||c1addr1||'|'||c1addr2||'|'||aref_desc||'|'||bref_desc||'|'||cref_desc||'|'||cpin||'|'||branchname||'|'||saddr1||'|'||saddr2||'|'||spin||'|'||scity||'|'||sstate||'|'||c2title||'|'||c2name||'|'||dt||'|'||ccustid||'|'||acctno||'|');
end; --}
end loop; --}
end; --}
/
