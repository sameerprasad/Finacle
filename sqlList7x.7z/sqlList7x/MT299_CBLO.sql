set serveroutput on
set pages 0
set verify off
set feedback off
set termout off
set lines 200
set trimspool on
set numf 99999999999999999999999999.99
spool &4..cblo

DECLARE

loc_date varchar(100);
loc_tran_id varchar(100);
loc_tran_perticular varchar(100);
ccil_tran varchar(100);
loc_dr_foracid varchar(100);
loc_cr_foracid varchar(100);
ccil_tran_date varchar(100);
loc_tran_type  char(2);
loc_file_nom char(6);
loc_eff_bal number(20,2);
ccil_amt number(20,2);
ccil_amt_204 number(20,2) :=0;
ccil_amt_202 number(20,2) :=0;
tot_ccil_amt number(20,2) :=0;
loc_oblig_bal number(20,2);
loc_file_name varchar(100);
temp_yymmdd varchar(100);
temp_chr_bal varchar(100);
sft_char varchar(20000) := '';
temp_chk integer :=0;
field20 varchar(100);
run_srl_num     varchar(10);
bal	number(20,2);
sql_foracid  varchar(16);
sql_tran_perti varchar(100);
sql_amt1 number(20,2);
sql_amt2 number(20,2);
sql_trandate varchar(100);
sql_tranid varchar(10);
loc_seq_no      varchar(10);
seq	integer :=0;
file_chk_cnt	integer :=0;
loc_ccil_acctno varchar(100) := '&1';
loc_loc_acctno varchar(100) := '&5';
file_tran_date varchar(100);

cursor CUR_FILE_NAMES is
select distinct file_name from ici_ccil where TRAN_DATE=file_tran_date and upper(file_name) like '%CBLO%'  order by substr(FILE_NAME,11,5) desc;



cursor CUR_MT204 is
select a.DRFORACID,a.CRFORACID,a.CUST_NAME,a.OBLIG_AMT,nvl(a.EFFECTIVE_AVIL_BAL,'0'),a.TRAN_PARTICULAR,a.TRAN_ID,to_char(a.TRAN_DATE,'YYMMDD') TRNDT,
b.SFT_AMOUNT,b.TRAN_ID sft_tranid,a.TRAN_DATE
from ici_ccil a , ici_ccil_sft b
where upper(a.file_name)=upper(loc_file_name) and a.TRAN_TYPE='D' and a.DEL_FLG='N'
and a.file_name=b.file_name and a.DRFORACID=b.FORACID ;


BEGIN

DBMS_OUTPUT.PUT_LINE('{1:F01'||'&2'||'00000000000}{2:B299'||'&3'||'XN}{4:');
 select lpad(count(distinct file_name),7,0) into run_srl_num from ici_ccil where tran_date=(select db_stat_date from gct);
 select to_char(db_stat_date,'YYYYMMDD') into loc_date from gct;
 select (count(1) +1) into seq from ICI_CCIL_REP where to_char(tran_date,'DD-MM-YYYY')=(select to_char(max(pstd_date),'DD-MM-YYYY') from dtd);
 field20 := loc_date||run_srl_num;
 DBMS_OUTPUT.PUT_LINE(':20:'||field20);
select to_char(db_stat_date,'DD-MM-YYYY') into file_tran_date from gct;
for f1 in CUR_FILE_NAMES LOOP
loc_file_name := f1.file_name;
select count(1) into file_chk_cnt from ici_ccil_rep where file_name=loc_file_name and MNEMONIC='1458';

if (file_chk_cnt < 1) then

---{ Check alredy generated


	select upper(substr(loc_file_name,10,5)) into loc_file_nom from dual;

	select count(1) into temp_chk from ici_ccil_sft where upper(file_name)=upper(loc_file_name);

	select TRAN_PARTICULAR,nvl(OBLIG_AMT,'0'),to_char(TRAN_DATE,'YYMMDD') 
	into ccil_tran,ccil_amt,ccil_tran_date 
	from ici_ccil 
	where upper(FILE_NAME)=upper(loc_file_name) and CUST_NAME like 'CCIL%';

if (loc_file_nom ='MT204') then
	ccil_amt_204 := ccil_amt;
end if;

if (loc_file_nom ='MT202') then
        ccil_amt_202 := ccil_amt;
end if;



	select to_char(db_stat_date,'YYYYMMDD') into loc_date from gct;
	tot_ccil_amt := tot_ccil_amt + ccil_amt;
	if (temp_chk > 0) then
		for c in CUR_MT204 
		loop
			-- sft_char := sft_char||c.CRFORACID||','||trim(replace(to_char(c.OBLIG_AMT,99999999999999999999.99),'.','.'))||','||c.TRAN_PARTICULAR||','||trim(replace(to_char(c.SFT_AMOUNT,99999999999999999999.99),'.','.'))||','||c.DRFORACID||'(';
			sft_char := sft_char||c.CRFORACID||','||trim(replace(to_char(c.SFT_AMOUNT,99999999999999999999.99),'.','.'))||','||c.TRAN_PARTICULAR||','||trim(replace(to_char(c.SFT_AMOUNT,99999999999999999999.99),'.','.'))||','||loc_loc_acctno||'(';
	Select to_char(PSTD_DATE,'DD/MM/YYYY  hh24:mi:ss') into sql_trandate from dtd where tran_id=c.sft_tranid and tran_date=c.TRAN_DATE and  rownum=1;
        sql_foracid := loc_loc_acctno;
        sql_tran_perti := c.TRAN_PARTICULAR;
        sql_amt1 := c.SFT_AMOUNT;
       -- sql_trandate := c.TRAN_DATE;
        sql_tranid := c.sft_tranid;
        select lpad(to_char(seq),5,'0') into loc_seq_no  from dual;
        insert into ICI_CCIL_REP values(loc_file_name,loc_ccil_acctno,sql_foracid,'C',TO_DATE(sql_trandate,'DD/MM/YYYY  hh24:mi:ss'),sql_amt1,loc_eff_bal,sql_tran_perti,sql_tranid,loc_seq_no,'N','1458','CBLO');
	seq := seq +1;
        commit;

	end loop;
	end if;
end if;
end loop;
		
		select nvl(sum(SFT_AMOUNT),'0') into bal from ici_ccil_sft where tran_date=file_tran_date and DEL_FLG='N' and upper(file_name) like '%CBLO%';

		loc_eff_bal := ccil_amt - bal;

	if (length(sft_char) > 0) then

		--DBMS_OUTPUT.PUT_LINE(':79:S,F,'||ccil_tran_date||','||trim(replace(to_char(ccil_amt,99999999999999999999.99),'.','.'))||','||trim(replace(to_char(loc_eff_bal,99999999999999999999.99),'.','.'))||','||trim(replace(to_char((ccil_amt-loc_eff_bal),99999999999999999999.99),'.','.'))||',INR,'||trim(replace(to_char(temp_chk,99999999999999999999.99),'.','.'))||'('||sft_char);
		DBMS_OUTPUT.PUT_LINE(':79:S,F,'||ccil_tran_date||','||trim(replace(to_char(ccil_amt,99999999999999999999.99),'.','.'))||','||trim(replace(to_char(loc_eff_bal,99999999999999999999.99),'.','.'))||','||trim(replace(to_char(bal,99999999999999999999.99),'.','.'))||',INR,'||trim(to_char(temp_chk,99999999999999999999))||'('||sft_char);

	else
		if (ccil_amt_204 > 0) then
			ccil_amt := ccil_amt_204;
		else
			ccil_amt := ccil_amt_202;
		end if;
		DBMS_OUTPUT.PUT_LINE(':79:S,F,'||ccil_tran_date||','||trim(replace(to_char(ccil_amt,99999999999999999999.99),'.','.'))||','||replace(to_char(ccil_amt),'.','.')||',0,INR,0(');

	end if;


	DBMS_OUTPUT.PUT_LINE('-}');
end;
/
spool off;
