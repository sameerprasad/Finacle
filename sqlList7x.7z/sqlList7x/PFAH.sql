REM################################################################################
REM File Name   : PFAH.sql
REM Description : Table creation for customer Provident fund Account History(PFAH)
Rem     Module  : PPF
REM################################################################################
drop table CUST_PPF_ACCOUNT_HISTORY
/
drop public synonym PFAH
/
create table CUST_PPF_ACCOUNT_HISTORY
(
SOL_ID                                       VARCHAR2(8)  ,
FORACID                                      VARCHAR2(16) ,
FINANCIAL_YEAR_END                           DATE         ,
TOTAL_PRINCIPAL_FY                           NUMBER(20,4) ,
TOTAL_INTEREST_FY                            NUMBER(20,4) ,
ACCOUNT_BALANCE_FY                           NUMBER(20,4) ,
CREDIT_TRAN_COUNT                            NUMBER       ,
DEBIT_TRAN_COUNT                             NUMBER       ,
WITHDRAW_AMOUNT_FY                           NUMBER(20,4) ,
CURRENT_FY_WITHDRAW_LIMIT_AMT                NUMBER(20,4) ,
ENTITY_CRE_FLG                               CHAR(1)      ,
LCHG_USER_ID                                 VARCHAR2(15) ,
LCHG_TIME                                    DATE         ,
RCRE_USER_ID                                 VARCHAR2(15) ,
RCRE_TIME                                    DATE         ,
DEL_FLG                                      CHAR(1)
)
/
CREATE INDEX IDX_CUST_PPF_ACCOUNT_HISTORY ON 
CUST_PPF_ACCOUNT_HISTORY(FORACID) 
/
CREATE unique INDEX UIDX_CUST_PPF_ACCOUNT_HISTORY  ON
CUST_PPF_ACCOUNT_HISTORY(SOL_ID,FORACID,FINANCIAL_YEAR_END)
/
create public synonym PFAH for CUST_PPF_ACCOUNT_HISTORY
/
grant select,insert,update,delete on PFAH to tbagen
/
grant select on PFAH to tbacust
/
grant select on PFAH to tbautil
/
grant all on PFAH to tbaadm
/
