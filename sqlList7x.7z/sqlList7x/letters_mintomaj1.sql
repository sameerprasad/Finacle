declare
	loc_fp               utl_file.file_type;
	loc_filename         varchar2(200);
	loc_filepath         varchar2(100);
	loc_filemode         varchar(10);
	genrep 					number;
	repdt  					date;
	repdd  					number;
	repmmyyyy 				char(6);
	hldy 						char(1);
	city_desc            varchar2(50);
	state_desc           varchar2(50);
	recline					varchar2(500);

cursor min2maj (dt in date) is
select  a.cust_id	   cust_id	,
   cust_title_code, 
   cust_name,	
   cust_comu_addr1,
   cust_comu_addr2,
	cust_comu_city_code,
	cust_comu_state_code,
   cust_comu_pin_code,
   substr(cust_name,1,40) cust_name_40,
   foracid   
	from cmg a, cmt c,gam d where 
	primary_sol_id in (select sol_id from sol)
	and d.acct_cls_flg = 'N'
	and minor_attain_major_date = (dt+30) 
	and a.cust_id=c.cust_id
	and a.cust_id=d.cust_id
	order by a.cust_id;

begin

	loc_filepath := '/tmp';
	loc_filename := 'mintomaj1.lst';
	loc_filemode := 'w';
	loc_fp := utl_file.fopen(loc_filepath, loc_filename, loc_filemode);


	select db_stat_date into repdt from gct;

	genrep := 1;
	while (genrep = 1)
	loop
		for rec in min2maj(repdt)
		loop
			begin
				select ref_desc into city_desc from rct where ref_rec_type = '01' and ref_code = 
						rec.cust_comu_city_code ;
			exception
				when others then
					city_desc := '';
			end;
			begin
				select ref_desc into state_desc from rct where ref_rec_type = '02' and ref_code = 
						rec.cust_comu_city_code ;
			exception
				when others then
					state_desc := '';
			end;
			recline  := rec.cust_id 				|| '|' ||
							rec.cust_title_code 		|| '|' ||
							rec.cust_name 				|| '|' ||
							rec.cust_comu_addr1 		|| '|' ||
							rec.cust_comu_addr2 		|| '|' ||
							city_desc 					|| '|' ||
							state_desc 					|| '|' ||
							rec.cust_comu_pin_code 	|| '|' ||
							rec.cust_name_40 			|| '|' ||
							rec.foracid ;

			utl_file.put_line(loc_fp, recline);
		end loop;


		repdt := repdt - 1;
		repdd := to_number(to_char(repdt, 'dd'));
		repmmyyyy := to_char(repdt, 'mmyyyy');

		select substr(hldy_str,repdd,1) into hldy from hol where 
		cal_b2k_type = 'DC' and mmyyyy = repmmyyyy ;

		if (hldy = 'Y') then
			genrep := 1;
		else
			genrep := 0;
		end if;

	end loop;
	utl_file.fclose(loc_fp);
				
end;
/
