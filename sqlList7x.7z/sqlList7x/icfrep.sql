set heading off
set verify off
set feedback off
set line 300
set trims on
set serveroutput on SIZE 1000000
spool icfrep-&1-&2

DECLARE

loc_cust_name				CMG.cust_name%type;
loc_date_of_birth			CMG.date_of_birth%type;
loc_cust_comu_addr1			CMG.cust_comu_addr1%type;
loc_cust_comu_addr2			CMG.cust_comu_addr2%type;
loc_cust_comu_city_code 	CMG.cust_comu_city_code%type;
loc_cust_comu_phone_num_1 	CMG.cust_comu_phone_num_1%type;
loc_cust_occp_code 			CMG.cust_occp_code%type;
loc_nom_name				ANT.nom_name%type;
loc_nom_reltn_code			ANT.nom_reltn_code%type;
loc_nom_desc				RCT.ref_desc%type;
loc_city_desc				RCT.ref_desc%type;
loc_acid					GAM.acid%type;

CURSOR	icfa_cur IS
SELECT	foracid,
		cust_id,
		premium_debit_date,
        ins_schm
FROM	ICICI_ICFA
WHERE	PREMIUM_DEBIT_DATE  = '&1' 
AND		PREMIUM_RECOVER_FLG = 'R'
AND     INS_SCHM = '&2' ;

BEGIN

	FOR rec in icfa_cur
	LOOP --{

		SELECT	substr(cust_name,1,25),
				date_of_birth,
				cust_comu_addr1,
				cust_comu_addr2,
				cust_comu_city_code,
				cust_comu_phone_num_1,
				cust_occp_code 
		INTO	loc_cust_name,
				loc_date_of_birth,
				loc_cust_comu_addr1,
				loc_cust_comu_addr2,
				loc_cust_comu_city_code,
				loc_cust_comu_phone_num_1,
				loc_cust_occp_code 
		FROM CMG
		WHERE cust_id = rec.cust_id;

		SELECT	acid
		INTO	loc_acid
		FROM	 GAM 
		WHERE	foracid = rec.foracid;

		BEGIN
			SELECT	substr(nom_name,1,25),
					nom_reltn_code
			INTO	loc_nom_name,
					loc_nom_reltn_code
			FROM	ANT
			WHERE	acid = loc_acid;

			EXCEPTION 
				WHEN NO_DATA_FOUND THEN 
					loc_nom_name := '*';
					loc_nom_reltn_code := '*';
		END;

		IF (loc_nom_reltn_code != '*') THEN
			SELECT	ref_desc
			INTO	loc_nom_desc
			FROM	RCT
			WHERE	ref_rec_type = '04'
			AND		ref_code = loc_nom_reltn_code;
		ELSE
			loc_nom_desc := '*';
		END IF;

		SELECT	ref_desc
		INTO	loc_city_desc
		FROM	RCT
		WHERE	ref_rec_type = '01'
		AND		ref_code = loc_cust_comu_city_code;

		dbms_output.put_line(	rec.foracid||'|'||
								loc_cust_name||'|'||	
								loc_date_of_birth||'|'||
								loc_cust_comu_addr1||'|'||
								loc_cust_comu_addr2||'|'||
								loc_city_desc||'|'||
								loc_cust_comu_phone_num_1||'|'||
								loc_cust_occp_code||'|'||
								loc_nom_name||'|'||
								loc_nom_desc||'|'||
                                rec.ins_schm||'|'||
								rec.premium_debit_date
							);

	END LOOP; --}

END;
/
spool off
