accept solid prompt 'PLEASE ENTER YOUR SOL ID (4 DIGITS)     ::'
accept dt1 prompt 'PLEASE ENTER THE FROM DATE FOR THE REPORT (DD-MM-YYYY) ::'
accept dt2 prompt 'PLEASE ENTER THE  TO  DATE FOR THE REPORT (DD-MM-YYYY) ::'
accept cutoff prompt 'PLEASE ENTER THE CUT OFF AMOUNT OF DISCOUNT : '

set feedback off
set echo off
set verify off
set pause off
set wrap on
set trims on
set trimout on
set termout off
set newpage 0
set linesize 132
set pagesize 66

rem given by shashi for finding out trfr pricing for 1999-2000
rem for bills where rate of interest < accepted rate of interest as given by 
rem the user
column a heading "AC NUMBER" format a12
column b heading "BILL NO" format a15 
column c heading "AMOUNT" format b999,99,99,99,999.00   
column d heading "USANCE" format b999 
column e heading "PUR ON" format a10 
column f heading "DUE DATE" format a10 
column g heading "RATE" format b999.00 
column h heading "DISC COLLECTED  " format b999,99,99,99,999.00 
column i heading "PERIOD" format b999 
column j heading "DIFF IN DISC" format b999.00 
column k heading "AMT RECEIVABLE" format b999,99,99,99,999.00 


column today new_value today_date
select to_char(sysdate,'dd-mm-yyyy') today from dual;
column bran new_value br
select br_name bran from bct where br_code=(select br_code from sol where sol_id= '&solid'
tle center 'ICICI BANK LIMITED,' br  right 'PAGE :    ' format 999 sql.pno skip 1 -
center 'BILLS DISCOUNTED AT LESS THAN &cutoff BETWEEN &dt1 AND &dt2 REPORT AS ON ' today_date skip 1
left '-------------------------------------------------------------------------------------------------------------------------------------------------------------'

spool &solid.trfrpriceobd.lst

break on report
compute sum LABEL 'GRAND TOTAL' of k on report 

select  gam.foracid a,
	blt.bill_id b,
	blt.bill_amt c,
	blt.usance_perd d,
	beh.vfd_bod_date e,
	blt.due_date f,
	itc.int_tbl_code g,
	blt.nrml_int_collected h,
	(blt.due_date - beh.vfd_bod_date) i,
	('&cutoff' - itc.int_tbl_code) j,
	((blt.bill_amt)*('&cutoff' - itc.int_tbl_code)*(blt.due_date - beh.vfd_bod_date)/36500) k
from blt,beh,gam, itc
where blt.bill_id = beh.bill_id
and itc.entity_type='IBIL'
and itc.entity_id=blt.bill_b2k_id
and blt.sol_id = beh.sol_id
and blt.sol_id = '&solid'
and beh.vfd_bod_date between '&dt1' and '&dt2'
and beh.bill_func = 'G'
and blt.reg_type in ('OBD','OURLC')
and itc.int_tbl_code < '&cutoff'
and (itc.int_tbl_code not like 'D%' 
	or itc.int_tbl_code not like 'C%'
	or itc.int_tbl_code is not NULL) 
and blt.del_flg != 'Y'
and blt.bp_acid = gam.acid 
and gam.sol_id = '&solid'
order by 1,5
/
spool off
exit
