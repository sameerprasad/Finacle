set echo off 
set pause off
set pagesize 1000
rem Script For Generating Letters to Customers for whom there are  import bills
rem realised in the ABLC/FIBC registers, but bill of entry is not yet submitted.
rem  There are 2 reminders ., this is the second one
rem
rem
rem
rem  author::  BHUSHAN, IT dept., Bombay
rem This script can be run at any time During the Day.
set verify off
set wrap on
set feedback off
set linesize 500
set space 0
set termout off
set heading off
alter session set nls_date_format = 'DD-MM-YYYY';
column bill_amt format b9999,99,99,999.99 
column other_bank_chrg format b9999,99,99,999.99 
spool &1
select distinct 	fbm.party_name||'|'||
	decode(fbm.party_addr1,NULL,' ',fbm.party_addr1)||'|'||
	decode(fbm.party_addr2,NULL,' ',fbm.party_addr2)||'|'||
	decode(fbm.party_addr3,NULL,' ',fbm.party_addr3)||'|'|| 
           fbm.bill_id||'|'||
           fbm.bill_crncy_code||'|'||
           ltrim(to_char(abs(fbm.bill_amt),'b99,99,99,99,999.99'))||'|'||
           fbm.lodg_date||'|'||
           fbm.due_date||'|'||
        decode(fei.lc_number,NULL,' ',fei.lc_number)||'|'||
        decode(fei.lc_date,NULL,' ',fei.lc_date)||'|'||
    	sol.bod_sys_date||'|'||
        decode(fbm.other_party_name,NULL,' ',fbm.other_party_name)||'|'
from	fct, sol, fbm, fei, fbi,fxp 
where   fbm.del_flg !='Y'
and     fbm.bill_stat !='N'
and     fbi.bill_of_entry is null
and     fbi.bill_of_entry_submit_date is null
and     fbm.lodg_date + 120 >= '&2'
and     fbm.lodg_date + 120 <= '&3'
and     fbm.bill_id =fei.bill_id
and     fbm.bill_id =fbi.bill_id
and     fei.bill_id = fbi.bill_id 
and     fbm.sol_id= sol.sol_id
and     fbm.sol_id=fei.sol_id 
and     fbm.sol_id=fbi.sol_id 
and     fei.sol_id= fbi.sol_id
and     sol.sol_id = '&4'
and     fbm.sol_id = '&4'
and     fbi.sol_id = '&4'
and     fei.sol_id = '&4'
and     fct.sol_id = '&4'
/
spool off
exit

