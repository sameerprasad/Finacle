set trims    on
set feedback off
set verify   off
set head     off
set termout off
spool fsgGetCustCnt
select count(*) from psp_tmp 
/
spool off
quit
