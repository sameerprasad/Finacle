set echo off 
set pause off
set pagesize 1000

rem Script For Generating List Of Customers Opened Today not introduced by existing customers of the Bank.
rem This will be used to generate a letter of thanks for banking
rem with ICICI. The letter template is cust_nointro.let
rem
rem Note that this has to be run every day. Else, the data is lost.
rem
rem Input parameters in command line -
rem	None
rem
rem Tables accessed -
rem       CMG, RCT.
rem
rem The table RCT is used to pick up the address of the customer
rem from the codes given in CMG.
rem
rem This script can be run at any time During the Day.

set verify off
set wrap on
set feedback off
set linesize 246
set space 1
set termout off
set heading off

var acopdt varchar2(11);
var solid varchar2(8);
var schtyp varchar2(3);

begin
	:acopdt := '&2';
	:solid  := '&3';
	:schtyp := '&4';
end;
/

spool  &1 

select  decode(cust_title_code,NULL,' ',cust_title_code)||'|'||
        cust_name||'|'||
        decode(cust_comu_addr1,NULL,' ',cust_comu_addr1)||'|'||
        decode(cust_comu_addr2,NULL,' ',cust_comu_addr2)||'|'||
        b.ref_desc||'|'||
        decode(c.ref_desc,NULL,' ',c.ref_desc)||'|'||
        decode(d.ref_desc,NULL,' ',d.ref_desc)||'|'||
        decode(cust_comu_pin_code,NULL,' ',cust_comu_pin_code)||'|'||
        sol.sol_desc||'|'||
        decode ( cust_title_code, 'M/S', 'Sirs', cust_title_code )||'|'||
        decode ( cust_title_code, 'M/S', ' ', cust_name )||'|'||
	trim(cmg.cust_id)||'|'
from    cmg, rct b, rct c, rct d, sol, gam
where   cmg.entity_cre_flg = 'Y'
and     to_char ( gam.acct_opn_date, 'DD-MON-YYYY' ) = :acopdt
and     gam.cust_id = cmg.cust_id 
and     gam.schm_type = :schtyp
and     gam.schm_code not in ( 'SBKIT','CAKIT') 
and     cmg.del_flg != 'Y'
and     b.ref_rec_type = '01'
and     b.ref_code = cust_comu_city_code
and     b.del_flg != 'Y'
and     c.ref_rec_type = '02'
and     c.ref_code = cust_comu_state_code
and     c.del_flg != 'Y'
and     d.ref_rec_type = '03'
and     d.ref_code = cust_comu_cntry_code
and     d.del_flg != 'Y'
and     sol.sol_id = cmg.primary_sol_id
and     cmg.cust_introd_cust_id is null
and     gam.sol_id = :solid
/
spool off
exit
