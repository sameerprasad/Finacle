REM####################################################################
REM File Name   : CLDHM.sql
REM Description : Table creation for Locker Document History Maintenance Table
REM Author      : Prabhu.B (BBSSL)
REM Date        : 04-06-2008
REM Module	: LOCKER
REM####################################################################
drop table icici.cust_locker_docu_hist_maint
/
drop public synonym CLDHM
/
create table icici.cust_locker_docu_hist_maint
(
	sol_id 			varchar2(8),
	cust_id         	varchar2(9),
	locker_num		varchar2(12),
	document_1		varchar2(20),
	document_2		varchar2(20),
	del_flg         	char(1),
	entity_cre_flg  	char(2),
	LCHG_USER_ID    	VARCHAR2(15),
	LCHG_TIME       	date,
	RCRE_USER_ID    	VARCHAR2(15),
	RCRE_TIME       	date,
	document_3		varchar2(100)
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
create public synonym CLDHM for icici.cust_locker_docu_hist_maint
/
grant select,insert,update,delete on CLDHM to tbagen
/
grant select on CLDHM to tbacust
/
grant select on CLDHM to tbautil
/
grant all on CLDHM to tbaadm
/
