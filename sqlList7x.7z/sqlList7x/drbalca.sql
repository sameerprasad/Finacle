accept solid prompt "ENTER FOUR DIGIT SOLID:::"
set echo off
set verify off
set termout off
set feedback off
set pages 72
set lines 80
column BAL format 99,99,99,999.99
ttitle center 'LIST OF ACCOUNTS WITH DEBIT BALANCES ' skip 2
spool &solid.drbalca
select acct_prefix prefix,acct_num num,substr(acct_name,1,25) name,(clr_bal_amt+un_clr_bal_amt) BAL from gam
where  acct_cls_flg != 'Y'
and (clr_bal_amt+un_clr_bal_amt) < 0
and gl_sub_head_code between '05010' and '05050'
and gam.sol_id='&solid'
/
spool off
exit
