set feedback off

alter session set nls_date_format='dd-mm-yyyy';
accept dt prompt 'ENTER REPORT DATE IN DD-MM-YYYY FORMAT  :  '

set termout off
set echo off
set linesize 200
set pagesize 60
set newpage 0
set wrap off 
set pause off
set verify off

column dcal new_value dcalias
select dc_alias dcal from gct;


define all_dashes = '-----------------------------------------------------------------------------
ttitle 'CONSOLIDATED DELIVERY CHANNEL TRANSACTION REPORT FOR &dt FOR &dcalias' skip 1

right 'Page : ' format 999 sql.pno skip 1 -
right 'Date : ' report_date skip 1 -
btitle left all_dashes

column type heading 'TYPE' format a5
column type1 heading 'TYPE' format a5 noprint
column solid heading 'SOL_ID' format a5
column solid1 heading 'SOL_ID' format a5 noprint
column tran_date heading 'Tran Date' format a10
column tran_id heading 'Tran Id' format a9
column stan heading 'STAN' format a12
column sys_date_time heading 'Sys Date Time' format a20
column cmd heading 'Tran' format a8
column cmd1 heading 'Tran' format a8 noprint
column cust_or_card_id heading 'ATM Card No' format a16
column acct_num heading 'A/C Number' format a16

column dr_tran_amt heading 'Debit' format b999,99,99,999.99
column cr_tran_amt heading 'Credit' format b999,99,99,999.99


break on cmd1 on solid1 on type1 

compute sum of dr_tran_amt on cmd1 
compute sum of dr_tran_amt on solid1
compute sum of cr_tran_amt on cmd1 
compute sum of cr_tran_amt on solid1

host rm dctran&dt*lst 2>/dev/null
host rm dctran&dt*txt 2>/dev/null
host rm dctran&dt*txt*uuc 2>/dev/null
host rm dctran&dt..txt.Z 2>/dev/null
host rm dctran&dt..lst.Z 2>/dev/null

spool dctran&dt

select 
	substr(ltrim(tran_particular),1,4) type,'|',
	substr(ltrim(tran_particular),1,4) type1,'|',
	substr(foracid,1,4) solid,'|',
	substr(foracid,1,4) solid1,'|',
	value_date tran_date,'|',
	tran_id tran_id,'|',
	substr(tran_rmks,1,4) stan,'|',
	substr(tran_particular,14,14) sys_date_time,'|',
	substr(tran_particular,5,8) cmd,'|',
	substr(tran_particular,5,8) cmd1,'|',
	substr(tran_rmks,15,16) cust_or_card_id,'|',
	foracid acct_num,'|',
	decode(part_tran_type, 'C' ,1, 0)*tran_amt cr_tran_amt,'|',
	decode(part_tran_type, 'D' ,1, 0)*tran_amt dr_tran_amt
from GAM g,DTD d
where d.acid=g.acid
and d.value_date ='&dt'
and g.sol_id=d.sol_id 
and substr(tran_particular,1,4)='ATM/' 
UNION ALL
select
	substr(ltrim(tran_particular),1,4) type,'|',
	substr(ltrim(tran_particular),1,4) type1 ,'|',
	substr(foracid,1,4) solid,'|',
	substr(foracid,1,4) solid1,'|',
	value_date tran_date,'|',
	tran_id tran_id,'|',
	substr(tran_rmks,1,4) stan,'|',
	substr(tran_particular,14,14) sys_date_time,'|',
	substr(tran_particular,5,8) cmd,'|',
	substr(tran_particular,5,8) cmd1,'|',
	substr(tran_rmks,15,16) cust_or_card_id,'|',
	foracid acct_num,'|',
	decode(part_tran_type, 'C' ,1, 0)*tran_amt cr_tran_amt,'|',
	decode(part_tran_type, 'D' ,1, 0)*tran_amt dr_tran_amt
from GAM g,CTD d
where d.acid=g.acid
and d.value_date ='&dt'
and g.sol_id=d.sol_id
and substr(tran_particular,1,4)='ATM/'
order by type,solid,cmd,stan
/

select 
	substr(ltrim(tran_particular),1,4) type,'|',
	substr(ltrim(tran_particular),1,4) type1,'|',
	substr(foracid,1,4) solid,'|',
	substr(foracid,1,4) solid1,'|',
	value_date tran_date,'|',
	tran_id tran_id,'|',
	substr(tran_rmks,1,4) stan,'|',
	substr(tran_particular,14,14) sys_date_time,'|',
	substr(tran_particular,5,8) cmd,'|',
	substr(tran_particular,5,8) cmd1,'|',
	substr(tran_rmks,15,16) cust_or_card_id,'|',
	foracid acct_num,'|',
	decode(part_tran_type, 'C' ,1, 0)*tran_amt cr_tran_amt,'|',
	decode(part_tran_type, 'D' ,1, 0)*tran_amt dr_tran_amt
from GAM g,DTD d
where d.acid=g.acid
and d.value_date ='&dt'
and g.sol_id=d.sol_id
and substr(tran_particular,1,4) in ('VAT/','VPS/','VFS/','CCN/','UBP/','EBA/','CCD/','PFS/','INF/','SCD/')
UNION ALL
select
	substr(ltrim(tran_particular),1,4) type,'|',
	substr(ltrim(tran_particular),1,4) type1,'|',
	substr(foracid,1,4) solid,'|',
	substr(foracid,1,4) solid1,'|',
	value_date tran_date,'|',
	tran_id tran_id,'|',
	substr(tran_rmks,1,4) stan,'|',
	substr(tran_particular,14,14) sys_date_time,'|',
	substr(tran_particular,5,8) cmd,'|',
	substr(tran_particular,5,8) cmd1,'|',
	substr(tran_rmks,15,16) cust_or_card_id,'|',
	foracid acct_num,'|',
	decode(part_tran_type, 'C' ,1, 0)*tran_amt cr_tran_amt,'|',
	decode(part_tran_type, 'D' ,1, 0)*tran_amt dr_tran_amt
from GAM g,CTD d
where d.acid=g.acid
and d.value_date ='&dt'
and g.sol_id=d.sol_id
and substr(tran_particular,1,4)in ('VAT/','VPS/','VFS/','CCN/','UBP/','EBA/','CCD/','PFS/','INF/','SCD/')
order by type,solid,cmd,stan
/

spool off
ttitle off
btitle off
set pagesize 0 
set linesize 80 
undefine all_dashes
clear breaks


host grep "|" dctran&dt..lst > dctran&dt..txt
host compress dctran&dt..lst
host compress dctran&dt..txt
host uuencode dctran&dt..lst.Z dctran&dt..lst.Z  > dctran&dt..lst.uuc
host uuencode dctran&dt..txt.Z dctran&dt..txt.Z  > dctran&dt..txt.uuc
host mailx -s "DCTRAN-XL &dcalias  &dt " switchrecon@ibank.icicibank.com < dctran&dt..txt.uuc 
host mailx -s "DCTRAN-RPT &dcalias  &dt " switchrecon@ibank.icicibank.com < dctran&dt..lst.uuc 
host rm dctran&dt..txt.Z
host rm dctran&dt..lst.Z
exit
