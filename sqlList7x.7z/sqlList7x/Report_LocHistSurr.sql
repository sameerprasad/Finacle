-------------------------------------------------------------------------
--Author    :  BBSSL  
--Date      : 
--Desc      :  Surrendered LockerS History Report  
--File Name :  Report_LocHistSurr.sql  
------------------------------------------------------------------------

set serveroutput on size 1000000
set lines 2000
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_LocHistSurr.lst

Declare
v_sol_id    		wlckm.sol_id%type:='&1';
v_locker_num 		wlckm.locker_num%type:='&2';
c_clmt_count	        varchar2(100) := 0;
s_clmt_count	        varchar2(100) := 0;
c_key_num               wlckm.key_num%type := 'NA';
c_locker_type           clmt.LOCKER_TYPE%type := 'NA';
c_cust_id               clmt.cust_id%type := 'NA';
c_rack_id               wlckm.RACK_ID%type := 'NA';
c_cust_name             cmg.cust_name%type := 'NA';
v_SURRENDER_DATE	date;	
v_issue_date		clmt.issue_date%type;
v_due_date              clmt.due_date%type;
v_renewal_date 		clmt.renewal_date%type;
v_NO_HIRER		clmt.NO_HIRER%type;

cursor Surr1 is
select MODE_OF_OPER,
SURRENDER_DATE,
CUST_ID,
CUST_NAME,
JH_ID_1,
JH_NAME_1,
JH_ID_2,
JH_NAME_2,
JH_ID_3,
JH_NAME_3,
JH_ID_4,
JH_NAME_4,
JH_ID_5,
JH_NAME_5,
JH_ID_6,
JH_NAME_6,
OPER_ACC,
KEY_NO
from LCSM 
where SOL_ID = v_sol_id
and LOCK_NO = v_locker_num
order by SURRENDER_DATE desc ;

begin
for i in Surr1
loop
--{
	begin
		select count(1) into c_clmt_count from clmt where 
		sol_id = v_sol_id and locker_num = v_locker_num and del_flg = 'N';
	end;		

	begin
		select key_num,RACK_ID,LOCKER_TYPE into c_key_num,c_rack_id,c_locker_type 
		from wlckm where sol_id = v_sol_id and locker_num = v_locker_num 
		and del_flg = 'N';
		EXCEPTION
		WHEN NO_DATA_FOUND THEN
		c_key_num := null;
		c_rack_id := null;
		c_locker_type := null;
	end;		
	if(c_clmt_count > 0)then	
		begin
			select cust_id into c_cust_id from clmt 
			where sol_id = v_sol_id and locker_num = v_locker_num and del_flg = 'N';
			
			select cust_name into c_cust_name from cmg 
			where cust_id = lpad(c_cust_id,9); 
		end;
		
	end if;

	v_SURRENDER_DATE := substr(i.SURRENDER_DATE,1,10);	
     
		begin
     
	    	select count(1) into s_clmt_count
         	from clmt
         	where sol_id = v_sol_id
         	and locker_num = v_locker_num
         	and cust_id = i.cust_id
   		    and LOCKER_KEY_NUM = i.KEY_NO
	        and del_flg = 'Y';
   
	     end;
   
	     if(s_clmt_count = 0)then
   
	             begin
                        select issue_date,due_date,renewal_date,NO_HIRER
                        into v_issue_date,v_due_date,v_renewal_date,v_NO_HIRER
                        from clmht
                        where sol_id = v_sol_id
                        and locker_num = v_locker_num
                        and cust_id = i.cust_id
                        and LOCKER_KEY_NUM = i.KEY_NO
                        and lchg_time = (SELECT MAX(lchg_time) from CLMHT
                        WHERE sol_id = v_sol_id and locker_num = v_locker_num
                        and cust_id = i.cust_id
                        and substr(lchg_time,1,10) = v_SURRENDER_DATE
                        and del_flg = 'N');
                        EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                        v_issue_date := null;
                        v_due_date := null;
                        v_renewal_date := null;
                        v_NO_HIRER := null;

            	end;
		else
                begin

                        select issue_date,due_date,renewal_date,NO_HIRER
                        into v_issue_date,v_due_date,v_renewal_date,v_NO_HIRER
                        from clmt
                        where sol_id = v_sol_id
                        and locker_num = v_locker_num
                        and cust_id = i.cust_id
                        and LOCKER_KEY_NUM = i.KEY_NO
                        and del_flg = 'Y';
                        EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                        v_issue_date := null;
                        v_due_date := null;
                        v_renewal_date := null;
                        v_NO_HIRER := null;

                end;
        end if;

	 
	dbms_output.put_line(  v_locker_num	   ||'|'||
				c_key_num          ||'|'||
				c_rack_id          ||'|'||
				c_locker_type      ||'|'||
				c_cust_id          ||'|'||
				c_cust_name        ||'|'||		
				i.MODE_OF_OPER     ||'|'||
			  	v_SURRENDER_DATE   ||'|'||
				i.cust_id	   ||'|'||
				i.CUST_NAME	   ||'|'||
				i.JH_ID_1	   ||'|'||
				i.JH_NAME_1        ||'|'||
				i.JH_ID_2	   ||'|'||
				i.JH_NAME_2	   ||'|'||
				i.JH_ID_3          ||'|'||
				i.JH_NAME_3        ||'|'||
				i.JH_ID_4          ||'|'||
				i.JH_NAME_4        ||'|'||
				i.JH_ID_5          ||'|'||
				i.JH_NAME_5        ||'|'||
				i.JH_ID_6          ||'|'||
                i.JH_NAME_6        ||'|'||
				i.OPER_ACC	   	   ||'|'||
				i.KEY_NO           ||'|'||
				v_issue_date       ||'|'||
				v_due_date         ||'|'||
				v_renewal_date     ||'|'||
				v_NO_HIRER         );
--}
end loop;
end;
/
spool off										
