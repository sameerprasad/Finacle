set pages 0 line 400 feed off term off veri off echo off head off
set serveroutput on
set trimspool on
spool icidca.list

DECLARE

vstr_CUST_COMU_STATE_CODE	varchar2(100);
vstr_CUST_COMU_CNTRY_CODE	varchar2(100);
vstr_CUST_COMU_CITY_CODE	varchar2(100);
vstr_CUST_COMU_CITY		varchar2(100);
vstr_CUST_COMU_STATE		varchar2(100);
vstr_CUST_COMU_CNTRY		varchar2(100);
vstr_MODE_OF_OPER               varchar2(100);

CURSOR getData IS
SELECT cmg.cust_id,foracid,acct_crncy_code,deposit_amount,
	maturity_amount,open_effective_date,maturity_date,
	deposit_period_mths,deposit_period_days,schm_code,
	mode_of_oper_code,cust_title_code,cust_name,cust_comu_addr1,
	cust_comu_addr2,cust_comu_city_code,cust_comu_cntry_code,
	cust_comu_state_code,cust_comu_pin_code,cust_comu_phone_num_1,
	cust_comu_phone_num_2 
FROM gam,tam,cmg 
WHERE gam.acid=tam.acid 
AND gam.cust_id = cmg.cust_id 
AND gam.foracid = '&1' 
AND cmg.cust_nre_flg = 'Y';

BEGIN
	FOR A in getData
	LOOP
	--begin
		BEGIN
		--{
			SELECT REF_DESC 
			INTO vstr_CUST_COMU_CITY
			FROM RCT
			WHERE REF_CODE = A.cust_comu_city_code
			AND ref_rec_type = '01';

			EXCEPTION
			WHEN NO_DATA_FOUND THEN
			vstr_CUST_COMU_CITY := '';
		--}	
		END;

		BEGIN
		--{
			SELECT REF_DESC 
			INTO vstr_CUST_COMU_STATE
			FROM RCT
			WHERE REF_CODE = A.cust_comu_state_code
			AND ref_rec_type = '02';

			EXCEPTION
			WHEN NO_DATA_FOUND THEN
			vstr_CUST_COMU_STATE := '';
		--}	
		END;
		
		BEGIN
                --{
                        SELECT REF_DESC
                        INTO vstr_MODE_OF_OPER
                        FROM RCT
                        WHERE REF_CODE = A.mode_of_oper_code
                        AND ref_rec_type = '27';

                        EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                        vstr_CUST_COMU_CNTRY := '';
                --}
                END;


		BEGIN
		--{
			SELECT REF_DESC 
			INTO vstr_CUST_COMU_CNTRY
			FROM RCT
			WHERE REF_CODE = A.cust_comu_cntry_code
			AND ref_rec_type = '03';

			EXCEPTION
			WHEN NO_DATA_FOUND THEN
			vstr_CUST_COMU_CNTRY := '';
		--}	
		END;
	dbms_output.put_line(A.cust_id||'|'||A.foracid||'|'||A.acct_crncy_code||'|'||A.deposit_amount||'|'||A.maturity_amount||'|'||A.open_effective_date||'|'||A.maturity_date||'|'||A.deposit_period_mths||'|'||A.deposit_period_days||'|'||A.schm_code||'|'||vstr_MODE_OF_OPER||'|'||A.cust_title_code||'|'||A.cust_name||'|'||A.cust_comu_addr1||'|'||A.cust_comu_addr2||'|'||vstr_CUST_COMU_CITY||'|'||vstr_CUST_COMU_STATE||'|'||A.cust_comu_pin_code||'|'||vstr_CUST_COMU_CNTRY||'|'||A.cust_comu_phone_num_1||'|'||A.cust_comu_phone_num_2);
	END LOOP;
END;

/
spool off
