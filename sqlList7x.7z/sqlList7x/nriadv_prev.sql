alter session set nls_date_format = 'DD-MM-YYYY';
set serveroutput on size 1000000
set linesize 256
set trims on
set feedback off
set verify off
set echo off
DECLARE
brname				SOL.SOL_DESC%type;
facid 				GAM.FORACID%type;
solid				GAM.SOL_ID%type;
gacid  				GAM.ACID%type;
modecode 			GAM.MODE_OF_OPER_CODE%type;
custid 				GAM.CUST_ID%type;
schemecode			GAM.SCHM_CODE%type;
crncycode			GAM.ACCT_CRNCY_CODE%type;
opendate 			varchar2(10);
valdate 			varchar2(10);
matdate 			varchar2(10);
periodmonth 		varchar2(3);
perioddays 			varchar2(3);
formatdepamt 		varchar2(17);
formatmatamt 		varchar2(17);
roi 				varchar2(7);
title 			    CMG.CUST_TITLE_CODE%type;
Name 				GAM.ACCT_NAME%type;
comaddr1 		    CMG.cust_comu_addr1%type;
comaddr2			CMG.cust_comu_addr2%type;
custcitycode		CMG.cust_comu_city_code%type;
custstatecode		CMG.cust_comu_state_code%type;
city 				RCT.REF_DESC%type;
state				RCT.REF_DESC%type;
pin					CMG.CUST_COMU_PIN_CODE%type;
cntry			rct.ref_desc%type;
cntrycode 		cmg.CUST_COMU_CNTRY_CODE%type;
phno			cmg.CUST_COMU_PHONE_NUM_1%type;
modeofoper 			RCT.REF_DESC%type;
prntflg				number(3);
nomregnum           ANT.NOM_REG_NUM%type;
opt					varchar(2);
parameter			varchar(12);
dbstatdate			GCT.DB_STAT_DATE%type;
schemedesc			varchar2(20);
modedesc			varchar2(20);
currency 			varchar2(3);
email          icici_cift.email_id%type; 
lnkacct				tam.link_oper_account%type;
loc_fp                          utl_file.file_type;
loc_filename                    varchar2(200);
loc_filepath                    varchar2(100);
loc_filemode                    varchar(10);
CURSOR GAMMAINALL IS
(SELECT gam.acid,
	gam.foracid,
	gam.sol_id,
	gam.schm_code,
   nvl(gam.acct_crncy_code,' '),
   nvl(cmg.cust_title_code,' '),
   nvl(cmg.cust_name,' '),
   nvl(cmg.cust_comu_addr1,' '),
   nvl(cmg.cust_comu_addr2,' '),
   nvl(cmg.cust_comu_city_code,' '),
   nvl(cmg.cust_comu_state_code,' '),
   nvl(ltrim(cust_comu_pin_code),' '),
   nvl(CUST_COMU_CNTRY_CODE,' '),
   nvl(CUST_COMU_PHONE_NUM_1,' '),
   ltrim(GAM.CUST_ID),
   nvl(mode_of_oper_code,'*')
FROM GAM,CMG,TAM
	where gam.acct_prefix in ('10','15','31')
	and GAM.ACCT_OPN_DATE = '&1'
	and GAM.clr_bal_amt >0
	and gam.cust_id=cmg.cust_id
	and cmg.cust_nre_flg='Y'
  	and GAM.ACCT_CLS_FLG != 'Y'
    and GAM.acid = TAM.acid 
    and TAM.deposit_type != 'F')
UNION
(SELECT gam.acid,
	gam.foracid,
	gam.sol_id,
	gam.schm_code,
   nvl(gam.acct_crncy_code,' '),
   nvl(cmg.cust_title_code,' '),
   nvl(cmg.cust_name,' '),
   nvl(cmg.cust_comu_addr1,' '),
   nvl(cmg.cust_comu_addr2,' '),
   nvl(cmg.cust_comu_city_code,' '),
   nvl(cmg.cust_comu_state_code,' '),
   nvl(ltrim(cust_comu_pin_code),' '),
   nvl(CUST_COMU_CNTRY_CODE,' '),
   nvl(CUST_COMU_PHONE_NUM_1,' '),
   ltrim(GAM.CUST_ID),
   nvl(mode_of_oper_code,'*')
FROM GAM,CMG,TAM
	where gam.acct_prefix in ('10','15','31')
	and GAM.ACID in (select acid from rht where tran_date = '&1')
	and GAM.clr_bal_amt >0
	and gam.cust_id=cmg.cust_id
	and cmg.cust_nre_flg='Y'
  	and GAM.ACCT_CLS_FLG != 'Y'
    and GAM.acid = TAM.acid
    and TAM.deposit_type != 'F');
--ORDER BY gam.cust_id;
BEGIN -- {
open gammainall;
	loc_filepath := '&2';
        loc_filename := 'nriadv_prev.lst';
        loc_filemode := 'w';
        loc_fp := utl_file.fopen(loc_filepath, loc_filename, loc_filemode);
BEGIN -- {
LOOP -- {
brname := ' ';
facid := ' ';
solid := ' ';
gacid := ' ';
modecode := ' ';
custid := ' ';
crncycode := ' ';
schemecode := ' ';
opendate := ' ';
valdate := ' ';
matdate := ' ';
periodmonth := ' ';
perioddays := ' ';
formatdepamt := ' ';
formatmatamt := ' ';
roi := ' ';
title := ' ';
Name := ' ';
comaddr1 := ' ';
comaddr2 := ' ';
custcitycode := ' ';
custstatecode := ' ';
city := ' ';
state := ' ';
pin := ' ';
modeofoper := ' ';
nomregnum := ' ';
cntry := ' ';
cntrycode := ' ';
schemedesc := ' ';
phno := ' ';
begin --{
	Fetch gammainall
	into
		gacid,
		facid,
		solid,
		schemecode,
		crncycode,
		title,name,
		comaddr1,
		comaddr2,
		custcitycode,
		custstatecode,
		pin,
		cntrycode,
		phno,
		custid,
		modecode;
exit when gammainall%notfound;
end; --}
begin --{
Select  db_stat_date
into
        dbstatdate
from    gct where rownum <2;
exception
        WHEN NO_DATA_FOUND then null;
end; --}
BEGIN -- {
Select  sol_desc
into
		brname
from 	sol
where
		sol_id = solid;
exception
		WHEN NO_DATA_FOUND then null;
WHEN OTHERS THEN
       dbms_output.put_line('SOL SELECTION ERROR');
end; --}
BEGIN -- {
Select  nom_reg_num
into
        nomregnum
from    ant
where
        acid = gacid ;
exception
        WHEN NO_DATA_FOUND then null;
WHEN OTHERS THEN
       dbms_output.put_line('ANT SELECTION ERROR');
end;--}
BEGIN -- {
Select	to_char(tam.open_effective_date,'dd/mm/yyyy'),
	to_char(TAM.MATURITY_DATE,'dd/mm/yyyy'),
	ltrim(to_char(TAM.DEPOSIT_PERIOD_MTHS,'990')),
	ltrim(to_char(TAM.DEPOSIT_PERIOD_DAYS,'990')),
	ltrim(to_char(TAM.DEPOSIT_AMOUNT,'99999999990.99')),
	ltrim(to_char(TAM.MATURITY_AMOUNT,'99999999990.99'))
into
	opendate,
	matdate,
	periodmonth,
	perioddays,
	formatdepamt,
	formatmatamt
FROM TAM
WHERE
	acid =  gacid;
exception
			WHEN NO_DATA_FOUND  then null;
WHEN OTHERS THEN
       dbms_output.put_line('TAM SELECTION ERROR');
end; --}
BEGIN -- {
select ltrim(to_char(TDT.int_pcnt,'990.99')) into roi
FROM TDT
WHERE tdt.acid = gacid
	and tdt.srl_num = (select max(d.srl_num) from tdt d
			where d.acid = gacid
			and d.flow_code in('II','IO') and int_pcnt != 0);
exception
			WHEN NO_DATA_FOUND  then null;
WHEN OTHERS THEN
       dbms_output.put_line('TDT SELECTION ERROR');
END;--}
-- BEGIN -- {
-- Select x.ref_desc, y.ref_desc, z.ref_desc, zz.ref_desc
-- into city,state,modeofoper,cntry
-- FROM rct x,rct y,rct z,rct zz
-- WHERE x.ref_rec_type = '01'
-- and   x.ref_code = custcitycode and   zz.ref_rec_type = '03'
-- and   zz.ref_code = cntrycode and   y.ref_rec_type = '02'
-- and   y.ref_code = custstatecode and   z.ref_rec_type = '27'
-- and   z.ref_code = modecode;
begin
select ref_desc into city from rct WHERE ref_rec_type='01' and ref_code=custcitycode;
exception
	when others then null;
end;

begin
select ref_desc into state from rct WHERE ref_rec_type='02' and ref_code=custstatecode;
exception
        when others then null;
end;

begin
select ref_desc into cntry from rct WHERE ref_rec_type='03' and ref_code=cntrycode;
exception
        when others then null;
end;

begin
select ref_desc into modeofoper from rct WHERE ref_rec_type='27' and ref_code=modecode;
exception
        when others then null;
end;

-- exception
-- 			WHEN NO_DATA_FOUND  then null;
-- WHEN OTHERS THEN
--        dbms_output.put_line('RCT SELECTION ERROR');
-- END;--}
/*
BEGIN -- {
	prntflg := 0;
	select count(*)
	into prntflg
	from
	tam
	where
	acid = gacid;
	dbms_output.put_line(prntflg||'|'||gacid);
exception
WHEN OTHERS THEN
       dbms_output.put_line('FFL SELECTION ERROR');
END;--}
*/

/*
BEGIN

	prntflg := 0;
	select link_oper_account into lnkacct from tam where  acid = gacid;
	
	if ( lnkacct is null )
	then
		prntflg := 0;
	else
		prntflg := 1;
	end if;

END
*/

BEGIN --{
Select email_id into email
from icici_cift
where cust_id=custid
and stmt_reqd ='E';
EXCEPTION
WHEN NO_DATA_FOUND THEN
email:=' ';
END;--}

begin
if( schemecode = 'FDSIO') then
	schemedesc := 'NROFD';
end if;
if( schemecode = 'FDISO') then
	schemedesc := 'NROFD';
end if;
if( schemecode = 'FDSIE') then
	schemedesc := 'NREFD';
end if;
if( schemecode = 'FDISE') then
	schemedesc := 'NREFD';
end if;
if( schemecode = 'FDQTE') then
	schemedesc := 'NREFD';
end if;
if( schemecode = 'FDQTO') then
	schemedesc := 'NROFD';
end if;
if( schemecode = 'CFDEO') then
	schemedesc := 'NROFD';
end if;
if( schemecode = 'CFDEE') then
	schemedesc := 'NREFD';
end if;
if( schemecode = 'CFDUS') then
	schemedesc := 'FCNR-USD';
end if;
if( schemecode = 'CFDGB') then
	schemedesc := 'FCNR-GBP';
end if;
if( schemecode = 'CFDJY') then
	schemedesc := 'FCNR-JPY';
end if;
if( schemecode = 'CFDEU') then
	schemedesc := 'FCNR-EURO';
end if;
if( schemecode = 'FDHUS') then
	schemedesc := 'FCNR-USD';
end if;
if( schemecode = 'FDHGB') then
	schemedesc := 'FCNR-GBP';
end if;
if( schemecode = 'FDHJY') then
	schemedesc := 'FCNR-JPY';
end if;
if( schemecode = 'FDHEO') then
	schemedesc := 'FCNR-EURO';
end if;
if( schemecode = 'CFDNR') then
	schemedesc := 'NRNRFD';
end if;
if( schemecode = 'FDQNR') then
	schemedesc := 'NRNRFD';
end if;
if( schemecode = 'FDQRS') then
	schemedesc := 'NRSRFD';
end if;
if( schemecode = 'FD90S') then
	schemedesc := 'NRSRFD';
end if;
if( schemecode = 'FDISS') then
	schemedesc := 'NRSRFD';
end if;
if( schemecode = 'CFDES') then
	schemedesc := 'NRSRFD';
end if;
if(modecode = 'SING') then
	modedesc := 'SELF';
end if;
if(modecode = 'ERS') then
	modedesc := 'EITHER/SURVIVOR';
end if;
if(modecode = 'FOR') then
	modedesc := 'FORMER/SURVIVOR';
end if;
if(modecode = 'ANY') then
	modedesc := 'ANY/SURVIVOR';
end if;
if(modecode = '1') then
	modedesc := 'JOINTLY BY ALL';
end if;
if(modecode = 'JLY2') then
	modedesc := 'ANY TWO JOINTLY';
end if;
if(crncycode = ' ') then
	currency := 'INR';
else
	currency := crncycode;
end if;
end;
begin --{
--if ( prntflg  < 1 ) then
dbms_output.put_line(facid);
utl_file.put_line(loc_fp,dbstatdate||'|'||brname||'|'||custid||'|'||facid||'|'||currency||'|'||formatdepamt||'|'|| formatmatamt||'|'||opendate||'|'||matdate||'|'||periodmonth||'|'||perioddays||'|'||roi||'|'||schemedesc||'|'||modedesc||'|'||title||'|'||nomregnum||'|'||name||'|'||comaddr1||'|'||comaddr2||'|'||city||'|'||state||'|'||pin||'|'||cntry||'|'||phno||'|'||email);
--end if;
end; --}
END LOOP;--}
END;--}
end; --}
/
