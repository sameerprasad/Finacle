
rem script for Account balances from GAM
rem   Tables accessed -
rem       1)  GAM
rem   Author : Revathy

set verify off
whenever sqlerror exit sql.sqlcode
set feedback off
set termout off
set linesize 132
set newpage 0
set pagesize 60
column solid new_value sol

select br_name solid from bct where br_code=(select br_code from sol where sol_id='&1') and bank_code='ICI';
define all_dashes = '---------------------------------------------------------------------------------------------------------------------------------------------------'
column today new_value today_date
select to_char(sysdate, 'dd/mm/yyyy') today
from   dual;

spool $ICICI_CUST_REP/offlbk.&1

ttitle center '   ICICI BANK LTD. , ' skip 1 -
center '   OFFICE ACCOUNT BALANCES AS ON'   '  '  today_date -
right 'Page :       ' format 999 sql.pno skip 1 -
center        '----------------------------------------------' SKIP 1 -
center sol skip 1 -
right 'Date : ' today_date skip 2 -
left all_dashes
column ledger heading "LEDG" format 999
column acct_id heading "Account No." format a12
column acct_name heading "Name" format a35
column clr_bal heading "CLR-BAL" format 9999,99,99,999.99
column unclr_bal heading "UNCLR-BAL" format 9999,99,99,999.99
column BALANCE format 9999,99,99,999.99
column STATUS format a15
break on ledger  skip page on report 
COMPUTE SUM OF clr_bal unclr_bal BALANCE ON LEDGER REPORT

select ledg_num ledger,foracid acct_id, acct_name,
clr_bal_amt clr_bal, un_clr_bal_amt unclr_bal, clr_bal_amt+un_clr_bal_amt BALANCE, decode(frez_code, 'D','DEBIT FREEZE', 'C', 'CREDIT FREEZE', 'T', 'TOTAL FREEZE',' ') STATUS
FROM GAM
where sol_id='&1'
and not exists (select cust_id from cmg where gam.cust_id = cmg.cust_id) 
and acct_cls_flg != 'Y'
order by ledg_num, foracid ;

spool off
undefine all_dashes

whenever sqlerror continue 
set termout on
set feedback on
set verify on
set heading off
clear breaks
set echo on
exit

