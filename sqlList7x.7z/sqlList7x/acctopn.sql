accept dt prompt 'Enter Date for which Report Reqd (DD-MON-YY) :: '
accept sol prompt 'Enter Sol Id for which Report Reqd :: '
ttitle center 'ICICI-BANK - Report of Total Number Of Accounts Opened  on ' &dt skip -1
set newpage 0
set feedback off
set termout off
set verify off
set linesize 132
set pagesize 60
set number b999,99,99,999.99
break on a skip 2 on report 
spool acctopn
select cust_id CUST_ID,foracid,acct_name NAME,clr_bal_amt BALANCE,
ledg_num from gam
where sol_id='&sol' and acct_opn_date = '&dt' and acct_cls_flg!='Y'
order by cust_id,ledg_num
/
spool out
exit


