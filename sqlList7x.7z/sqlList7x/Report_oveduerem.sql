--------------------------------------------
--File Name   : Report_oveduerem.sql 
--Description : Overdue Reminders 
--Author      : Priscilla & Vijay
--Date        : 01-06-2010
------------------------------------------
set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_oveduerem.lst

DECLARE

lv_solid         gam.sol_id%type :='&1';
v_LOCKER_NUM	 clmt.LOCKER_NUM%type:= '&2';

CURSOR c1 IS
select  clmt.sol_id,
        clmt.locker_num,
        clmt.due_date,
        clmt.DISC_RENT_AMT,
        clmt.cust_id,
        substr(cmg.CUST_NAME,1,40) CUST_NAME,
        decode(address_type,'P',cmg.cust_perm_addr1,'C',cmg.CUST_COMU_ADDR1) addr1,
        decode(address_type,'P',cmg.cust_perm_addr2,'C',cmg.CUST_COMU_ADDR2) addr2,
        decode(address_type,'P',cmg.cust_perm_pin_code,'C',cmg.CUST_comu_PIN_CODE) pin_code,
        clmt.OPER_ACNT,
        (lcpp.RENT_PAYABLE_AMOUNT-lcpp.RENT_PAID_AMOUNT) arrear
from    clmt,cmg,lcpp
where   lcpp.LOCKER_NUMBER=CLMT.LOCKER_NUM
and     clmt.cust_id = lcpp.cust_id
and     lpad(clmt.cust_id,9,' ')=cmg.cust_id
and     lpad(lcpp.cust_id,9,' ')=cmg.cust_id
and     floor(ABS((due_date - decode(renewal_date,'',(due_date+1),renewal_date))/365)) > 0
and     clmt.sol_id=lcpp.sol_id
and     clmt.del_flg!='Y'
and     lcpp.del_flg!='Y'
and	(lcpp.RENT_PAYABLE_AMOUNT-lcpp.RENT_PAID_AMOUNT) > 0
and     clmt.sol_id = lv_solid
and     clmt.LOCKER_NUM  like decode (v_LOCKER_NUM,null,'%',v_LOCKER_NUM)
UNION
select  clmt.sol_id,
        clmt.locker_num,
        clmt.due_date,
        clmt.DISC_RENT_AMT,
        clmt.cust_id,
        substr(cmg.CUST_NAME,1,40) CUST_NAME,
        decode(address_type,'P',cmg.cust_perm_addr1,'C',cmg.CUST_COMU_ADDR1) addr1,
        decode(address_type,'P',cmg.cust_perm_addr2,'C',cmg.CUST_COMU_ADDR2) addr2,
        decode(address_type,'P',cmg.cust_perm_pin_code,'C',cmg.CUST_comu_PIN_CODE) pin_code,
        clmt.OPER_ACNT,
        (lcpp.RENT_PAYABLE_AMOUNT-lcpp.RENT_PAID_AMOUNT) arrear
from    clmt,cmg,lcpp
where   lcpp.LOCKER_NUMBER=CLMT.LOCKER_NUM
and     clmt.cust_id = lcpp.cust_id
and     lpad(clmt.cust_id,9,' ')=cmg.cust_id
and     lpad(lcpp.cust_id,9,' ')=cmg.cust_id
and     floor(ABS((due_date - decode(renewal_date,'',(due_date+1),renewal_date))/365)) = 0
and     clmt.sol_id=lcpp.sol_id
and     clmt.del_flg!='Y'
and     lcpp.del_flg!='Y'
and	(lcpp.RENT_PAYABLE_AMOUNT-lcpp.RENT_PAID_AMOUNT) > 0
and     clmt.sol_id = lv_solid
and     clmt.LOCKER_NUM  like decode (v_LOCKER_NUM,null,'%',v_LOCKER_NUM)
order by 3,2;

BEGIN

    for f1 in c1
    loop

dbms_output.enable(buffer_size => NULL);
dbms_output.put_line(	f1.cust_id			||'|'||
						f1.arrear	||'|'||
						f1.cust_name        ||'|'||
						f1.addr1        	||'|'||
						f1.addr2        	||'|'||
						f1.pin_code     	||'|'||
						f1.locker_num       ||'|'||
                        f1.OPER_ACNT   
		      		); 
   end loop; 
END;
/
spool off
