rem This script will generate Report on National Clearing Cheques
rem lodged under sub-reg_type of 'NCCC' or 'NCCP' of Bill Module
rem This report will generate according to requirements of CAT, Mumbai.

rem author  :: Narayan Rao, ICICI Infotech, Mumbai 

accept dt1 prompt 'ENTER LODGE DATE FOR REPORT (BANGALORE) (DD-MM-YYYY) : '
set termout off
set verify off
set echo off
set feedback off
set pages 50
set linesize 80 
set newpage 0

column today new_value today_date
select to_char(sysdate, 'dd/mm/yyyy') today from  dual;

column spoolday newvalue spool_date
select to_char(lodg_date, 'ddmmyyyy') spoolday from blt
            where lodg_date='&dt1';


col sol_desc  heading 'BR. NAME' format a11 word_wrap
col city_name heading 'CITY' format a10 
col sol_id heading 'SOLID format a5
col bill_id heading 'OUR REF. NO' format a12
col bank_name heading 'DRAWEE' format a6 word_wrap
col lodg_date heading 'LODGE DATE'
col bill_amt heading 'AMOUNT (IN Rs.)' format b999,99,99,999.99

break on city_name skip page  on sol_id on sol_desc skip 2 on report skip 5   
--on page skip 2 on report skip 5

compute count LABEL "Sub.Bill" of bill_id on city_name skip 2
compute sum LABEL "SUBTOTAL" of bill_amt on city_name skip 2 

compute count LABEL "Br.Bill TOT" of bill_id on sol_desc skip 2
compute sum LABEL "BR.TOTAL" of bill_amt on sol_desc skip 3
compute count LABEL "BILL TOT " of bill_id   on report skip 2 
compute sum LABEL "GR.TOTAL" of bill_amt on report
ttitle center 'ICICI BANK LIMITED' skip 1 -
center  'BANGALORE BRANCHES' skip 2 -
center 'REPORT ON NATIONAL CLEARING CHEQUES AS ON ' '&dt1'  skip 1 -
left 'DATE : ' today_date  right 'PAGE :     ' format 999 sql.pno  skip 2

btitle  skip 2 left 'AUTHORISED SIGNATORY' 




spool nclgreport_blr&dt1..lst
 
select 
       city_name,
	   sol.sol_id,
	   sol_desc,
	   lodg_date,
	   Bill_id,
           bank_name,
       bill_amt
	      from blt, bct, cty, sol, bkc
				where reg_sub_type in ('NCCC', 'NCCP') 
                      and lodg_date='&dt1'
					  and blt.lodg_coll_br_code=bct.br_code
					  and bct.br_city_code=cty.city_code
					  and cty.city_code in ('BBY', 'CAL', 'ND', 'MDS')
					  and bill_stat is not null
					  and blt.drawee_centre_code=bkc.bank_code
					  and blt.sol_id=sol.sol_id
					  and ltrim(sol.sol_id) in ('0002', '0078', '0053', '0047', '0084')
						order by city_name, bill_id 



/




clear breaks
clear compute
clear columns
ttitle off
btitle off

ttitle center 'ICICI BANK LIMITED' skip 1 -
center  'BANGALORE BRANCHES' skip 2 -
center 'CITYWISE CONSOLIDATED REPORT ON ' skip1 -
center 'NATIONAL CLEARING CHEQUES AS ON ' '&dt1' skip1 -
left 'DATE : ' today_date  right 'PAGE :     ' format 999 sql.pno  skip 2

----- btitle 'NO. OF INSTRUMENTS FOR THE DAY' gr_ins skip 2

break on city_name skip 2 on bank_name on report

compute sum LABEL "CITYWISE TOTAL " of count(bill_amt) on city_name skip 2 
compute sum LABEL "CITYWISE TOTAL" of sum(bill_amt) on city_name skip 1
compute sum LABEL "GRAND TOTAL" of count(bill_amt) on report  skip 2
compute sum LABEL "GRAND TOTAL" of sum(bill_amt) on report skip 1


COLUMN city_name FORMAT A15 HEADING 'CITY'
COLUMN bank_name  FORMAT A30 HEADING 'DRAWEE BANK'
column sum(bill_amt) heading 'AMOUNT' format       b999,99,99,999.99
column count(bill_amt) heading 'NO.OF CHQS'


select
       city_name,
       bank_name,
         count(bill_amt),
       sum(bill_amt) 
          from blt,bct,cty, sol, bkc
            where reg_sub_type in ('NCCC', 'NCCP')
                  and lodg_date ='&dt1'
               and blt.lodg_coll_br_code=bct.br_code
	       and blt.drawee_centre_code=bkc.bank_code 
               and bct.br_city_code=cty.city_code
                  and bill_stat is not null
                  and blt.sol_id=sol.sol_id
				and ltrim(blt.sol_id) in ('0002','0078','0053','0047', '0084' )
        group by city_name, bank_name
                      order by city_name
/

clear breaks
clear compute
clear columns
ttitle off
btitle off



ttitle center 'ICICI BANK LIMITED' skip 1 -
center  'BANGALORE BRANCHES' skip 2 -
center 'CITYWISE CONSOLIDATED REPORT ON ' skip1 -
center 'NATIONAL CLEARING CHEQUES AS ON ' '&dt1' skip1 -
left 'DATE : ' today_date  right 'PAGE :     ' format 999 sql.pno  skip 2

---- btitle 'NO. OF INSTRUMENTS FOR THE DAY' gr_ins skip2

break on  bank_name skip 2 on city_name   on report

compute sum LABEL "BANKWISE TOTAL" of count(bill_amt)  on bank_name skip 2 
compute sum LABEL "BANKWISE TOTAL" of sum(bill_amt) on bank_name skip 2
compute sum LABEL "GRAND TOTAL" of count(bill_amt) on report  skip 2
compute sum LABEL "GRAND TOTAL" of sum(bill_amt) on report skip 1


COLUMN city_name FORMAT A15 HEADING 'CITY'
COLUMN bank_name  FORMAT A30 HEADING 'DRAWEE BANK'
column sum(bill_amt) heading 'AMOUNT' format       b999,99,99,999.99
column count(bill_amt) heading 'NO.OF CHQS'


select
       bank_name,
	city_name,
         count(bill_amt),
       sum(bill_amt)
          from blt,bct,cty, sol, bkc
            where reg_sub_type in ('NCCC', 'NCCP')
                  and lodg_date ='&dt1'
               and blt.lodg_coll_br_code=bct.br_code
	       and blt.drawee_centre_code=bkc.bank_code 
               and bct.br_city_code=cty.city_code
                  and bill_stat is not null
                  and blt.sol_id=sol.sol_id
                                and ltrim(blt.sol_id) in ('0002', '0078', '0053', '0047', '0084')
        group by  bank_name, city_name
                      order by bank_name
/
spool off

clear breaks
clear compute
ttitle off
btitle off
set head on
set verify on
set termout on 
set trimspool off
----set wrap off
