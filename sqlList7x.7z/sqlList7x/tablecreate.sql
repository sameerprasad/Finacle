drop table ICICI.ICICI_CUST_ALERT_DETAIL_TBL
/
create table ICICI.ICICI_CUST_ALERT_DETAIL_TBL
(
 CUST_ID                                            VARCHAR2(9),
 ALERT_TYPE                                         VARCHAR2(4),
 THRESHOLD                                          NUMBER(20,4),
 MODE_OF_DELIVERY                                   VARCHAR2(1),
 FREQUENCY                                          VARCHAR2(1),
 MODE_ID                                            VARCHAR2(60),
 ALERT_FILTER                                       NUMBER(2),
 BAL_FILTER                                         NUMBER(2),
 SAME_DUP_ALERT                                     VARCHAR2(1),
 OTH_DUP_ALERT                                      VARCHAR2(1),
 FREQ_TYPE                                          NUMBER(2),
 DEL_CHNL                                           VARCHAR2(10),
 RCRE_TIME                                          DATE,
 USER_ID                                            VARCHAR2(15),
 DEL_FLG                                            VARCHAR2(1),
 CHECKER_USERID                                     VARCHAR2(15),
 SOL_ID                                             VARCHAR2(8) 
)
/
drop public synonym ICICI_CUST_ALERT_DETAIL
/
create public synonym ICICI_CUST_ALERT_DETAIL for ICICI.ICICI_CUST_ALERT_DETAIL_TBL
/
grant select, insert, delete, update on ICICI.ICICI_CUST_ALERT_DETAIL_TBL to tbagen
/
grant select, insert, delete, update on ICICI.ICICI_CUST_ALERT_DETAIL_TBL to tbaadm
/
grant select on ICICI.ICICI_CUST_ALERT_DETAIL_TBL to tbautil
/
grant select, insert, delete, update on ICICI.ICICI_CUST_ALERT_DETAIL_TBL to tbacust
/
grant select, insert, delete, update on ICICI.ICICI_CUST_ALERT_DETAIL_TBL to icici
/
