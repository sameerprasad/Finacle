rem accept solid prompt 'PLEASE ENTER FOUR DIGIT SOL ID OF REPORT BRANCH : '
set feedback off
set verify off
set termout off
set echo off

set linesize 80
set pagesize 60
break on bill_crncy_code  skip 2 on report
compute sum of bill_amt on bill_crncy_code  
compute sum of bill_amt_inr on bill_crncy_code report 
column br new_value bran

set echo off
select br_name br from bct where
br_code = (select br_code from sol
			where sol_id = '&1');

column today new_value today_date
select to_char (sysdate,'dd/mm/yyyy') today
from dual;

spool &1.usance
column unformatted_bill_id  heading 'BILL NO' format a12
column bill_crncy_code heading CURRENCY format a8
column party_name heading PARTY format a25 trunc
column fbm.bill_amt heading FC format b99,99,99,999.99 
column fbm.bill_amt_inr heading INR format b99,99,99,999.99


ttitle center 'ICICI BANKING CORPORATION LIMITED' skip 1-
center bran 'BRANCH AS ON' today_date skip 3-
center 'USANCE BILLS UNDER LETTER OF CREDIT' skip 2-

define all_dashes = '--------------------------------------------------------------------------------'
 
select fbm.bill_id,party_name ,bill_crncy_code ,
fbm.bill_amt , fbm.bill_amt_inr from
fbm, dcmm, fei
where fbm.sol_id = dcmm.sol_id
and fbm.sol_id = fei.sol_id
and dcmm.dc_ref_num = fei.lc_number
and fei.bill_id = fbm.bill_id
and fbm.reg_type = 'ABLC'
and fbm.reg_sub_type='U'
and fbm.cls_flg!='Y'
and fbm.bill_stat in ('G','K')
and dcmm.dc_reg_type = 'OUTFR'
and fbm.sol_id = '&1'
and dcmm.sol_id = '&1'
and fei.sol_id = '&1'
order by bill_crncy_code,party_name
/
spool off
ttitle off
exit

