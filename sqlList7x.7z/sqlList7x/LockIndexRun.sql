REM CLRM Table
REM ---------------------

drop index IDX_CLRM
/
drop index UIDX_CLRM
/
CREATE INDEX IDX_CLRM ON ICICI.cust_locker_rent_maintenance(SOL_ID,location_code,locker_type,Rent_Version_Code)
/
CREATE UNIQUE INDEX UIDX_CLRM ON ICICI.cust_locker_rent_maintenance(SOL_ID,location_code,locker_type,Rent_Version_Code,Rent_period)
/

REM WLCPM Table
REM ------------------

drop index IDX_WLCPM
/
create unique index IDX_WLCPM on ICICI.WLOCKER_PARAMETER_MAINTENANCE(SOL_ID,LOCATION_CODE,LOCKER_TYPE,SIZE_OF_LOCKER)
/

REM WLCPMH Table
REM----------------------

drop index IDX_WLCPMH
/
create index IDX_WLCPMH on ICICI.WLOCKER_PARAM_MAINT_HISTORY(SOL_ID,LOCATION_CODE,LOCKER_TYPE,SIZE_OF_LOCKER)
/

REM WLCRM Table
REM -----------------

drop index idx_wlcrm_main
/
create unique index idx_wlcrm_main on ICICI.RACK_ID_MAINTENENCE(SOL_ID,RACK_ID,DEL_FLG)
/

REM WLCKM Table
REM -----------------

drop index idx_wlckm 
/
drop index idx_wlckm_locknum 
/
drop index idx_wlckm_locknum2 
/
create unique index idx_wlckm on ICICI.LOCKER_KEY_MAINTENENCE(SOL_ID,LOCKER_TYPE,LOCKER_NUM,KEY_NUM,STATUS)
/
create index idx_wlckm_locknum on ICICI.LOCKER_KEY_MAINTENENCE(SOL_ID,LOCKER_NUM)
/
create index idx_wlckm_locknum2 on ICICI.LOCKER_KEY_MAINTENENCE(SOL_ID,LOCKER_NUM,del_flg)
/

REM WLCKMH Table
REM ----------------

drop index idx_wlckmh_main
/
drop index idx_wlckmh_key_main
/
drop index idx_wlckmh_lock_main
/
create index idx_wlckmh_main on ICICI.LOCKER_KEY_MAINTENENCE_HISTORY(SOL_ID,LOCKER_NUM,KEY_NUM,STATUS)
/
create index idx_wlckmh_key_main on ICICI.LOCKER_KEY_MAINTENENCE_HISTORY(SOL_ID,KEY_NUM)
/
create index idx_wlckmh_lock_main on ICICI.LOCKER_KEY_MAINTENENCE_HISTORY(SOL_ID,LOCKER_NUM)
/

REM CLMT Table
REM ---------------

drop index IDX_cust_locker_master_table
/
drop index UIDX_cust_locker_master_table
/
drop index IDX_clmt_locknum
/
drop index IDX_clmt_lockcustid
/
drop index IDX_clmt_locknumdel
/
CREATE INDEX IDX_cust_locker_master_table ON ICICI.cust_locker_master_table(SOL_ID,locker_type,locker_num,cust_id)
/
CREATE unique INDEX UIDX_cust_locker_master_table  ON ICICI.cust_locker_master_table (SOL_ID,locker_type,locker_num,cust_id,del_flg)
/
CREATE INDEX IDX_clmt_locknum ON ICICI.cust_locker_master_table(SOL_ID,locker_num)
/
CREATE INDEX IDX_clmt_lockcustid ON ICICI.cust_locker_master_table(SOL_ID,locker_num,cust_id)
/
CREATE INDEX IDX_clmt_locknumdel ON ICICI.cust_locker_master_table(SOL_ID,locker_num,del_flg)
/

REM CLJH Table
REM ------------------

drop index IDX_CLJH
/
drop index UIDX_CLJH
/
create index IDX_CLJH on ICICI.cust_locker_joint_holder(SOL_ID,cust_MH_id,locker_num)
/
create unique index UIDX_CLJH on ICICI.cust_locker_joint_holder(SOL_ID,cust_MH_id,locker_num,cust_JH_id,lkr_JH_SRL_No)
/

REM CLDM Table
REM ----------------

drop index IDX_CLDM
/
CREATE UNIQUE INDEX IDX_CLDM ON ICICI.cust_locker_docu_maintenance(SOL_ID,cust_id,locker_num)
/

REM CLND Table
REM ------------------

drop index IDX_CLND
/
CREATE UNIQUE INDEX IDX_CLND ON ICICI.cust_locker_nomination_detail(SOL_ID,nominee_no,cust_id,locker_num)
/

REM CLMHT Table
REM -----------------

drop index IDX_SOL_ID_CLMHT
/
CREATE INDEX IDX_SOL_ID_CLMHT ON ICICI.cust_locker_mast_hist_table(SOL_ID,cust_id,locker_num)
/

REM LCPY Table
REM -------------

drop index IDX_LCPY
/
create index IDX_LCPY on ICICI.LOCKER_PAYABLE_DETAILS(SOL_ID,CUST_ID,LOCKER_NUMBER)
/

REM LCPD Table
REM ------------------

drop index IDX_LCPD
/
create unique index IDX_LCPD on ICICI.LOCKER_PAID_DETAILS(SOL_ID,TRAN_ID,TRAN_DATE,PART_TRAN_SRL_NUM,CUST_ID,LOCKER_NUMBER )
/

REM LCPP Table
REM --------------------

drop index IDX_LCPP
/
create index IDX_LCPP on ICICI.LOCKER_PAYABLE_PAID( SOL_ID,CUST_ID,LOCKER_NUMBER )
/

REM LCSM Table
REM --------------

drop index IDX_LCSM
/
create unique index IDX_LCSM on ICICI.LOCKER_SURRENDER(SOL_ID,LOCKER_TYPE,LOCK_NO,KEY_NO,CUST_ID)
/

REM LCBRKOP Table
REM ------------------

drop index IDX_LCBRKOP
/
create unique index IDX_LCBRKOP on ICICI.LOCKER_BREAK_OPEN(SOL_ID,LOCKER_TYPE,LOCK_NO,KEY_NO,CUST_ID)
/

REM LCBRKOPH Table
REM -----------------

drop index IDX_LCBRKOPH
/
CREATE INDEX IDX_LCBRKOPH ON  ICICI.LOCKER_BREAK_OPEN_HISTORY(SOL_ID, LOCKER_TYPE, LOCK_NO, KEY_NO, CUST_ID)
/

REM LCOPS Table
REM ------------------

drop index IDX_LCOPS
/
CREATE INDEX IDX_LCOPS ON ICICI.LOCKER_OPERATION_MAINTANCE(SOL_ID,CHECK_DATE,LOCKER_TYPE,LOCKER_NO,KEY_NO,CHECK_IN_TIME,CHECK_OUT_TIME)
/

REM CLCET Table
REM ---------------

drop index IDX_CLCET
/
create index IDX_CLCET on ICICI.CUST_LOCKER_EXCEPTION_DETAILS( SOL_ID,CUST_ID,LOCKER_NUMBER,EXCP_CODE,EXCP_DATE )
/

REM CLCLA Table
REM ----------------

drop index IDX_CLCLA
/
create index IDX_CLCLA on ICICI.CLOCKER_LETTER_OF_AUTHORITY( SOL_ID,LOCKER_NUMBER,KEY_NUMBER,CUST_MH_ID,CLCLA_SRL_NUM )
/

REM CLCLAH Table
REM -------------

drop index  IDX_CLCLAH
/
create index IDX_CLCLAH on ICICI.CLOCKER_LETTER_OF_AUTHORITYH( SOL_ID,LOCKER_NUMBER,KEY_NUMBER,CUST_MH_ID,CLCLA_SRL_NUM )
/

REM CLCWT Table
REM -------------

drop index IDX_CLCWT
/
create index IDX_CLCWT on ICICI.LOCKER_WAIVE_TABLE( SOL_ID,CUST_ID,LOCKER_NUMBER )
/

REM LCPWD Table
REM -------------

drop index IDX_LCPWD
/
create index IDX_LCPWD on ICICI.LOCKER_PASSWORD_TABLE( SOL_ID,LOCKER_NUMBER )
/

REM LCRRM Table
REM -----------------

drop index IDX_LCRRM
/
create unique index IDX_LCRRM on ICICI.LOCK_RENT_REMAINDER(SOL_ID,LOCKER_NUM,CUST_ID)
/

REM LCCTM Table
REM ---------------

drop index IDX_LCCTM
/
create index IDX_LCCTM on ICICI.LOCKER_CUST_TYPE_TABLE(sol_id,location_code,cust_type )
/

REM CLCTDD Table
REM ------------------

drop index IDX_CLCTDD
/
create index IDX_CLCTDD on ICICI.LOCKER_CUST_TYPE_DISC_DETAIL( SOL_ID,CUST_ID,LOCKER_NUMBER )
/

REM C_SVRSETVAR Table
REM ------------------

drop index IDX_C_SVRSETVAR
/
CREATE INDEX IDX_C_SVRSETVAR ON  ICICI.cust_locker_setvar_maintenance(MODULE_NAME,SUB_MODULE_NAME,VARIABLE_NAME)
/

REM CLRT Table
REM ------------------

drop index IDX_cust_locker_reversal_tran
/
drop index IDX_cust_locker_rev_tranid
/
drop index UIDX_cust_locker_reversal_tran
/
CREATE INDEX IDX_cust_locker_reversal_tran ON ICICI.cust_locker_reversal_tran(SOL_ID,locker_num,cust_id)
/
CREATE INDEX IDX_cust_locker_rev_tranid ON ICICI.cust_locker_reversal_tran(locker_num,org_tran_id,org_tran_date)
/
CREATE unique INDEX UIDX_cust_locker_reversal_tran ON ICICI.cust_locker_reversal_tran(SOL_ID,locker_num,cust_id,org_tran_id,org_tran_date)
/

REM WLSM Table
REM ------------------

drop index IDX_SCHM_MASTER_TABLE
/
CREATE  INDEX IDX_SCHM_MASTER_TABLE ON icici.LOC_SCHM_MASTER_TABLE(SOL_ID,Scheme_name,Disc_Based_On)
/

REM WLCRMT Table
REM ------------------

drop index idx_WLCRMT_main
/
CREATE  UNIQUE INDEX  idx_WLCRMT_main ON icici.RACK_ID_TRAN_MAIN(SOL_ID1,RACK_ID,del_flg)
/

REM WLPM Table
REM ------------------

drop index idx_WLPM_TABLE
/
CREATE  INDEX IDX_WLPM_TABLE ON icici.LOC_PREMIUM_MODTABLE(SOL_ID,LOCKER_NUM,CUST_ID,TYPE)
/

REM WLPM Table
REM ------------------

drop index IDX_cust_locker_tran_ledger
/
drop index IDX_cust_locker_tran_date
/
CREATE INDEX IDX_cust_locker_tran_ledger ON ICICI.cust_locker_tran_ledger(SOL_ID,locker_num,cust_id)
/
CREATE INDEX IDX_cust_locker_tran_date ON ICICI.cust_locker_tran_ledger(locker_num,APPLICABLE_DATE)
/

REM CLONUM Table
REM ------------------

drop index IDX_cust_locker_oldnum_table
/
CREATE INDEX IDX_cust_locker_oldnum_table ON ICICI.cust_locker_oldnum_table(old_sol_id,old_locker_num)
/

REM LCLOST Table
REM ------------------

drop index IDX_LCLOST
/
CREATE INDEX IDX_LCLOST ON icici.LOCKER_KEY_LOST_MAINTENENCE(SOL_ID,LOCKER_NUM,CUST_ID)
/
