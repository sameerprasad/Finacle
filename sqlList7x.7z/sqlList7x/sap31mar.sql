set echo off verify off feedback off term off
set serveroutput on size 1000000
set numformat 9999999999999.99

spool &2.sap31 

declare
trandate varchar2(11);
nrate number(21,10);

cursor Acctsel is
select 
   sol_id,
   gl_sub_head_code,
   substr(foracid, 5,11) facid,
   acid,
   acct_crncy_code,
   acct_opn_date,
   (clr_bal_amt + un_clr_bal_amt) gambal
from gam
where sol_id = '&2' 
   and (gl_sub_head_code like '40%' or gl_sub_head_code like '75%') 
   and acct_cls_flg != 'Y'; 

bal      eab.tran_date_bal%type := 0.00;
drbal    eab.tran_date_bal%type;
crbal    eab.tran_date_bal%type;

begin --{

trandate := '&1';
for i in Acctsel
loop --{

   if (i.gambal is null)
   then
      i.gambal := 0.00;
   end if;

   begin --{
   select nvl(var_crncy_units/fxd_crncy_units,1)  into nrate
     from rth
     where ratecode='NOR'
        and var_crncy_code='INR'
        and fxd_crncy_code = i.acct_crncy_code
        and rtlist_date =
           (select max(rtlist_date) from rth
            where fxd_crncy_code = i.acct_crncy_code
             and var_crncy_code='INR'
             and ratecode='NOR'
             and rtlist_date<=to_date(trandate,'dd-mm-yyyy'))
             and rtlist_num=
                 (select max(rtlist_num) from rth
                  where fxd_crncy_code= i.acct_crncy_code
                  and var_crncy_code='INR'
                  and ratecode='NOR'
                  and rtlist_date=
                      (select max(rtlist_date) from rth
                       where fxd_crncy_code= i.acct_crncy_code
                       and var_crncy_code='INR'
                       and ratecode='NOR'
                       and rtlist_date<=to_date(trandate,'dd-mm-yyyy')));
      exception
      when no_data_found
      then
         nrate:=1;
      end; --}

   bal := (i.gambal * nrate);

   if ( bal > 0 ) then
	   drbal := 0 ;
	   crbal := bal ;
   elsif ( bal < 0 ) then
	   drbal := bal * -1 ;
	   crbal := 0 ;
   else
	   drbal := 0 ;
	   crbal := 0 ;
   end if ;

   if ( drbal !=0 or crbal != 0 )
   then 
       begin --{
          dbms_output.put_line(
             i.sol_id||'|'||
             '00'||'|'||
             i.gl_sub_head_code||'|'||
             i.facid||'|'||
             round(drbal,4)||'|'||
             round(crbal,4)||'|'||
             trandate);
       END; --}
   end if;

   bal := 0.00;

end loop; --}

end; --}
/
spool off
