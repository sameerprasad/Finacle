-------------------------------------------------------------------------
--Author    :    Manjunath(BBSSL)
--Date      :    10-11-2011
--Desc      :    Report Of Masters
--File Name :    Report_LocMaster3.sql
--------------------------------------------------------------------------


set serveroutput on size 1000000
set lines 2000 
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_LocMaster3.lst

Declare
v_sol_id    			wlckm.sol_id%type:='&1';
v_rack_id				wlckm.rack_id%type;
v_count					number;
v_total_locker_units	wlcrm.total_locker_units%type;
v_start_no	    		wlcrm.start_no%type;
v_end_no        		wlcrm.end_no%type;



cursor t2 is
		select SOL_ID,RACK_ID,(select count(locker_num) from wlckm a
		where sol_id = v_sol_id and a.sol_id = b.sol_id and a.rack_id = b.rack_id
		and a.del_flg = 'N') count,TOTAL_LOCKER_UNITS,START_NO,END_NO from wlcrm b
		where sol_id = v_sol_id and del_flg = 'N';
begin
open t2;
loop
--{
		fetch t2 into v_sol_id,v_rack_id,v_count,v_total_locker_units,v_start_no,v_end_no;

		if t2%NOTFOUND then
    	--{
        	close t2;
        	exit;
    	--}
    	end if;


			dbms_output.enable(buffer_size => NULL);
			dbms_output.put_line(v_sol_id    		  ||'|'||
                     		 v_rack_id       		  ||'|'||
                     		 v_count   		    	  ||'|'||
                     		 v_total_locker_units  	  ||'|'||
                     		 v_start_no 			  ||'|'||
                             v_end_no);
--}
end loop;
end;
/
spool off

