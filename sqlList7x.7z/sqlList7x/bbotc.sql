--   **********************************************************************    
--    File     :        bbotc.sql
--    PACKAGE bbotc
--   ....................................................... 
--   **********************************************************************   
--
--	Mod:	
--	Date:	30-10-2007
--	Auth:	Eldo
--	desc:	To avoid FTS on PST table, sol_id criteria is added
--
set serveroutput on size 100000
	
	CREATE or REPLACE PACKAGE bbotc AS
		
		PROCEDURE getcrncy(inp_string IN VARCHAR2,
						   out_endOfFile OUT  NUMBER,     
						   out_string    OUT  VARCHAR2);
	
	end bbotc;
/

-- ***********************************************************  
CREATE or REPLACE PACKAGE BODY  bbotc AS

	CURSOR BOTCCursor is
		SELECT DISTINCT SOL_ID, CRNCY_PURCHSD,CRNCY_SOLD from PST 
		WHERE ho_tran_id is  null and ho_tran_date is  null
		and entity_cre_flg='Y' and CRNCY_PURCHSD != CRNCY_SOLD
		and pst_date = ( select db_stat_date from gct) and sol_id in (select sol_id from sst where set_id = 'ALL');

--  --------------------------------------------------------------------------- 
--
--  --------------------------------------------------------------------------- 

	PROCEDURE getcrncy(inp_string IN VARCHAR2,  
					    out_endOfFile OUT  NUMBER,
						out_string    OUT  VARCHAR2) IS

	inpArr      basp0099.ArrayType;
	botc_rec	BOTCCursor%ROWTYPE;
	pl_hol_pur		GAM.BACID%TYPE;
	pl_hol_sale		GAM.BACID%TYPE;
	startdate   gct.db_stat_date%type;

	BEGIN
		basp0099.formInputArr (inp_string, inpArr);  
select (db_stat_date -3 ) into startdate from gct;	
		out_endOfFile := 1;
		out_string := '';    

		IF NOT BOTCCursor%ISOPEN THEN
			Open BOTCCursor;
		END IF;


		FETCH BOTCCursor into botc_rec;

		IF BOTCCursor%NOTFOUND THEN
			CLOSE BOTCCursor;
			out_endOfFile := 1403;  -- When All Records have been Fetched.  
			RETURN;
		ELSE

select decode(botc_rec.CRNCY_PURCHSD,'INR','IBFX-SALE','FS201') into pl_hol_pur from dual;
select decode(botc_rec.CRNCY_SOLD,'INR','IBIBIT','FS201') into pl_hol_sale from dual;

out_string := botc_rec.sol_id||'|'||botc_rec.crncy_purchsd||'|'||botc_rec.crncy_sold||'|'||pl_hol_pur||'|'||pl_hol_sale||'|'||'E'||'|'||startdate;
out_endOfFile := 0; 

		END IF;

EXCEPTION 
	WHEN OTHERS THEN 
		IF BOTCCursor%ISOPEN THEN
			CLOSE BOTCCursor;
		END IF;
	out_endOfFile := 1;   

END getcrncy;
--********************************************************************** 
END bbotc;
--********************************************************************** 
/
GRANT EXECUTE ON bbotc TO TBAGEN, TBAUTIL, TBACUST   
/
DROP PUBLIC SYNONYM bbotc
/
CREATE PUBLIC SYNONYM bbotc FOR TBAADM.bbotc
/
-------------------------  END OF SOURCE    ---------------------------- 
