####################################################################
REM File Name   : CLJHT.sql
REM Description : Table creation for Locker Joint holders History details
REM Author      : Prabhu.B (BBSSL)
REM Date        : 15-05-2008
REM Module	: LOCKER
REM####################################################################
drop table cust_locker_joint_holder_hist
/
drop public synonym CLJHT
/
create table icici.cust_locker_joint_holder_hist
(
	sol_id 		varchar(8),
	lkr_JH_SRL_No   number(4),
	cust_MH_id 	varchar(9),
	locker_num	varchar(12),
	cust_JH_id 	varchar(9),
	relation_type   char(1),
	relation_code   varchar2(5),
	del_flg         char(1),
	entity_cre_flg  char(2),
	LCHG_USER_ID    VARCHAR2(15),
	LCHG_TIME       date,
	RCRE_USER_ID    VARCHAR2(15),
	RCRE_TIME       date,
        STAFF_DISCOUNT_FLG  char(1)
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
create public synonym CLJHT for icici.cust_locker_joint_holder_hist
/
grant select,insert,update,delete on CLJHT to tbagen
/
grant select on CLJHT to tbacust
/
grant all on CLJHT to tbaadm
/
grant select on CLJHT to tbautil
/
