--##############################################################################################
--#                     File Name       : lccort.sql
--#                     Author : Ashwani Bhat (BBSSL)
--#                     Report : LOCKER LEGAL DISPUTE REPORT
--#                     Date   :
--#                     Module  : LOCKER
--#                     Called Menu     : LOCKRPT
--#                     Called By       : lccort.com
--##############################################################################################


CREATE OR REPLACE PACKAGE lccort_pack AS

    PROCEDURE lccort_proc (
		inp_str IN varchar2,
		out_retcode OUT number,
		out_rec OUT varchar2
			   );

END lccort_pack;
/

CREATE OR REPLACE PACKAGE BODY lccort_pack AS   

v_locker_num		wlclck.locker_num%type; 
v_locker_type		clmt.locker_type%type;  
v_locker_key_num	clmt.locker_key_num%type;
v_cust_id		clmt.cust_id%type;      
v_cust_name		cmg.cust_name%type;     
v_advice		wlclck.advice%type;     
v_lock_reason		wlclck.lock_reason%type;
v_unlock_reason		wlclck.unlock_reason%type;
v_lock_date		wlclck.lock_date%type;  
v_lock_time		wlclck.lock_time%type;  
v_unlock_date		wlclck.unlock_date%type;
v_unlock_time		wlclck.unlock_time%type;
v_date			wlclck.lock_date%type;
v_sol_id		wlclck.sol_id%type;

CURSOR lccort (v_sol_id   clmt.sol_id%type, v_date  date) IS

select		wlclck.locker_num, 
		clmt.locker_type, 
		clmt.locker_key_num, 
		clmt.cust_id, 
		cmg.cust_name, 
		wlclck.advice, 
		wlclck.lock_reason,
		wlclck.unlock_reason,
		wlclck.lock_date, 
		wlclck.lock_time, 
		wlclck.unlock_date, 
		wlclck.unlock_time
from		wlclck, clmt, cmg
where		wlclck.locker_num = clmt.locker_num
and		wlclck.sol_id = clmt.sol_id
and		clmt.cust_id = cmg.cust_id
and		wlclck.status in ('U','F')
and		wlclck.advice like ('COURT%')
and		wlclck.sol_id = v_sol_id
and             clmt.del_flg = 'N'
and             cmg.del_flg = 'N'
and             wlclck.del_flg = 'N'
and		wlclck.lock_date <= to_date(v_date,'dd-mm-yyyy');

OutArr	basp0099.ArrayType;

	PROCEDURE lccort_proc
	(
		inp_str IN varchar2,
		out_retcode  OUT number,
		out_rec  OUT varchar2
	) AS

BEGIN

	out_retcode := 0;

	IF (NOT lccort%ISOPEN) THEN
		basp0099.formInputArr(inp_str,outArr);
		v_sol_id := outArr(0);
		v_date := outArr(1);
		


	OPEN lccort (v_sol_id, v_date);

	END IF;

			IF (lccort%ISOPEN) then

				FETCH lccort INTO

					v_locker_num,	
					v_locker_type,	
					v_locker_key_num,
					v_cust_id,	
					v_cust_name,	
					v_advice,	
					v_lock_reason,	
					v_unlock_reason,
					v_lock_date,	
					v_lock_time,	
					v_unlock_date,	
					v_unlock_time;	

			END IF;

			IF (lccort%NOTFOUND) THEN

				close lccort;
				out_retcode := 1;
				return;

			END IF;

		
			out_rec :=
					v_locker_num		||'|'||
					v_locker_type		||'|'||
					v_locker_key_num	||'|'||
					v_cust_id		||'|'||
					v_cust_name		||'|'||
					v_advice		||'|'||
					v_lock_reason		||'|'||
					v_unlock_reason		||'|'||
					v_lock_date		||'|'||
					v_lock_time		||'|'||
					v_unlock_date		||'|'||
					v_unlock_time;	 
			return;
end lccort_proc;
end lccort_pack;
/
drop public synonym lccort_pack
/
create public synonym lccort_pack for lccort_pack
/
grant execute on lccort_pack to tbacust,tbautil,tbagen,tbaadm
/

