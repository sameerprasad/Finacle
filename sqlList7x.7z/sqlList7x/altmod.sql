set verify off
set heading off
set feedback off
set serveroutput on SIZE 1000000
spool altmod.log

select 'Updating ALT for .....' from DUAL;

DECLARE

cursor	altCur is
SELECT	acid,
		lien_reason_code
FROM	ALT
WHERE	lien_remarks = 'Entry created during E-brok migration'
for update;

locForacid			GAM.foracid%TYPE;
locAcid				GAM.acid%TYPE;
locBlockType		ICICI_BLKT.block_type%TYPE;
locDccReasonCode	ICICI_BLKT.reason_code%TYPE;
locSubCommand	ICICI_BLKH.sub_command%TYPE;
locFinReasonCode	ALT.lien_reason_code%TYPE;
locSignInd          char;
locRemarks			ALT.lien_remarks%TYPE;
locBlockAmount	ICICI_BLKH.block_amount%TYPE;

step number;
BEGIN
	step := 0;

	if (altCur%isopen) then
		close altCur;
	end if;

	OPEN	altCur;

	LOOP ---{
	
		FETCH	altCur
		INTO	locAcid,
				locFinReasonCode;
		
		IF (altCur%NOTFOUND) THEN
			CLOSE altCur;
			commit;
			exit;
		END IF;
		

		step := 1;
		SELECT	foracid
		INTO	locForacid
		FROM	GAM
		WHERE	acid = locAcid;

		SELECT	dcc_reason_code
		INTO	locDccReasonCode
		FROM	ICICI_RCMT
		WHERE	dcc_id = 'EBA'
		AND		fin_reason_code = locFinReasonCode;

		dbms_output.put_line('DCC reson code ' || locDccReasonCode);
		select sub_command, block_amount, block_remarks
		into locSubCommand,
			locBlockAmount,
			locRemarks
		from icici_blkh
		where foracid = locForacid
		and ser_num = (select max(ser_num) from icici_blkh where foracid = locForacid
		and block_type = 'EBA' and reason_code = locDccReasonCode);

		step := 2;
		IF (((locSubCommand = '01') OR (locSubCommand = '98')) AND (locBlockAmount < 0)) THEN
			locSignInd := 'N';
		ELSE
			locSignInd := 'P';
		END IF;

		update alt set lien_remarks = locSubCommand||locSignInd||locDccReasonCode || substr(locRemarks,1, 42) where current of altCur;

	END LOOP ; --}

	COMMIT;

	EXCEPTION
		WHEN	OTHERS THEN
				DBMS_OUTPUT.PUT_LINE('altmod failed at step ' || step);
				DBMS_OUTPUT.PUT_LINE('altmod failed for account'||locForacid);
				DBMS_OUTPUT.PUT_LINE('!!!!  CHECK SQL ERROR,  AND TRY AGAIN !!!!!');
				DBMS_OUTPUT.PUT_LINE('SQL ERROR CODE IS        : ' || SQLCODE );
				DBMS_OUTPUT.PUT_LINE('SQL ERROR DESCRIPTION IS : '|| SQLERRM);
				ROLLBACK;
				DBMS_OUTPUT.PUT_LINE('ROLLBACK COMPLETE');
END ;
/
select 'Successfully Updated ALT ...' from DUAL;
spool off
quit
