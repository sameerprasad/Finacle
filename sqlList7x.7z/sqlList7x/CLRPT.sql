Rem     This file will create cust_locker_report_maintenance 
Rem     with the following characteristics.

Rem     Coded by : Prabhu.B (BBSSL)

Rem     Module  : LOCKER


Rem TABLE NAME: CUST_LOCKER_REPORT_MAINTENANCE

Rem SYNONYM:    CUST_LOCKER_REPORT_MAINTENANCE 

drop table icici.CUST_LOCKER_REPORT_MAINTENANCE
/
drop public synonym CLRPT
/
create table icici.CUST_LOCKER_REPORT_MAINTENANCE
( 
	REPORT_CODE VARCHAR2(20),
	REPORT_DESC VARCHAR2(50),
	INPUT_FILENAME VARCHAR2(100),
	LCHG_USER_ID VARCHAR2(15),
 	LCHG_TIME DATE,
 	RCRE_USER_ID VARCHAR2(15),
 	RCRE_TIME DATE,
	DEL_FLG CHAR(1)
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE ACCT_DETAILS_2_SMALL
/* STORE_END */
/
create public synonym CLRPT for icici.CUST_LOCKER_REPORT_MAINTENANCE
/
create index IDX_CLRPT on icici.CUST_LOCKER_REPORT_MAINTENANCE(REPORT_CODE)
/
grant select, insert, update, delete on CLRPT to tbagen
/
grant select on CLRPT to tbacust
/
grant select on CLRPT to tbautil
/
grant all on CLRPT to tbaadm
/
