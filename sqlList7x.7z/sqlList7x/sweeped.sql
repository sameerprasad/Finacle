set feedback off
set echo off
set termout off
set lines 200
set verify off
set trimspool on
set serveroutput on size 100000
spool &1..fxsweep.txt
declare
acctnum gam.foracid%type;
currency gam.acct_crncy_code%type;
bal gam.clr_bal_amt%type;
parttrantype varchar2(1);
totaldr gam.clr_bal_amt%type;
totalcr gam.clr_bal_amt%type;
revamt gam.clr_bal_amt%type;
dbdate gct.db_stat_date%type;
pandltrf gam.clr_bal_amt%type;
pandsign varchar2(1);
conv_rate number(20,10);
cursor income is
select foracid, clr_bal_amt, decode(sign(clr_bal_amt),-1,'C',1,'D') from gam where sol_id='&1' and gl_sub_heaD_code between '40010' and '40070' and acct_cls_flg!='Y' and entity_cre_flg!='N' and clr_bal_amt!=0 and acct_crncy_code ='INR';

cursor charges is
select foracid, clr_bal_amt, decode(sign(clr_bal_amt),-1,'C',1,'D') from gam where sol_id='&1' and gl_sub_heaD_code between '75010' and '75040' and acct_cls_flg!='Y' and entity_cre_flg!='N' and clr_bal_amt!=0 and acct_crncy_code ='INR';

cursor crncy is
select distinct crncy_code from csp where del_flg!='Y' and crncy_code!='INR';

cursor fxincome(crn gam.acct_crncy_code%type) is
select foracid, clr_bal_amt, decode(sign(clr_bal_amt),-1,'C',1,'D') from gam 
where sol_id='&1' and gl_sub_head_code between '40010' and '40070' and acct_cls_flg!='Y' and entity_cre_flg!='N' and clr_bal_amt!=0 and acct_crncy_code=crn;

cursor fxcharges (crn gam.acct_crncy_code%type) is
select foracid, clr_bal_amt, decode(sign(clr_bal_amt),-1,'C',1,'D') from gam where sol_id='&1' and gl_sub_heaD_code between '75010' and '75040' and acct_cls_flg!='Y' and entity_cre_flg!='N' and clr_bal_amt!=0 and acct_crncy_code=crn;

begin
select db_stat_date into dbdate from gct;
totaldr:=0;
totalcr:=0;
pandltrf:=0;
conv_rate:=1;
open charges;
loop
fetch charges into acctnum, bal, parttrantype;
exit when charges%notfound;
totaldr:=totaldr + bal; 
dbms_output.put_line(acctnum||'|'||'INR'||'|'||'&1'||'|'||parttrantype||'|'||abs(bal)||'|'||'TRFR TO P n L ACCNT'||'|'||'CFG'||'|'||conv_rate||'|'||abs(totaldr)||'|'||'INR'||'|'||'0');
end loop;
close charges;
select decode(sign(totaldr),-1,'D',1,'C') into pandsign from dual;
dbms_output.put_line('&1'||'SL000P'||'&'||'L'||'|'||'INR'||'|'||'&1'||'|'||pandsign||'|'||abs(totaldr)||'|'||'TRFR frm CHARGES ACCTS'||'|'||'CFG'||'|'||conv_rate||'|'||abs(totaldr)||'|'||'INR'||'|'||'0');

open income;
loop
fetch income into acctnum, bal, parttrantype;
exit when income%notfound;
totalcr:=totalcr + bal;
dbms_output.put_line(acctnum||'|'||'INR'||'|'||'&1'||'|'||parttrantype||'|'||abs(bal)||'|'||'TRFR TO P n L ACCNT'||'|'||'CFG'||'|'||conv_rate||'|'||abs(totaldr)||'|'||'INR'||'|'||'0');
end loop;
close income;
select decode(sign(totalcr),-1,'D',1,'C') into pandsign from dual;
dbms_output.put_line('&1'||'SL000P'||'&'||'L'||'|'||'INR'||'|'||'&1'||'|'||pandsign||'|'||abs(totalcr)||'|'||'TRFR frm INCOME ACCTS'||'|'||'CFG'||'|'||conv_rate||'|'||abs(totaldr)||'|'||'INR'||'|'||'0');

open crncy;
loop
fetch crncy into currency;
exit when crncy%notfound;
totaldr:=0;
totalcr:=0;
revamt:=0;
pandltrf:=0;
conv_rate:=1;

open fxcharges(currency);
loop
fetch fxcharges into acctnum, bal, parttrantype;
exit when fxcharges%notfound;
totaldr:=totaldr + bal;
dbms_output.put_line(acctnum||'|'||currency||'|'||'&1'||'|'||parttrantype||'|'||abs(bal)||'|'||'TRFR TO P n L ACCNT'||'|'||'CFG'||'|'||conv_rate||'|'||abs(totaldr)||'|'||currency||'|'||'0');
end loop;
close fxcharges;

select decode(sign(totaldr),-1,'D',1,'C') into pandsign from dual;
if (totaldr!=0) then
begin
begin
select nvl(var_crncy_units/fxd_crncy_units,1)  into conv_rate from rth where ratecode='NOR' and ((var_crncy_code='INR' and fxd_crncy_code = currency) or (var_crncy_code=currency and fxd_crncy_code = 'INR')) and rtlist_date = (select max(rtlist_date) from rth where ((var_crncy_code='INR' and fxd_crncy_code = currency) or (var_crncy_code=currency and fxd_crncy_code = 'INR')) and ratecode='NOR' and rtlist_date<=dbdate) and rtlist_num= (select max(rtlist_num) from rth where ((var_crncy_code='INR' and fxd_crncy_code = currency) or (var_crncy_code=currency and fxd_crncy_code = 'INR')) and ratecode='NOR' and rtlist_date= (select max(rtlist_date) from rth where ((var_crncy_code='INR' and fxd_crncy_code = currency) or (var_crncy_code=currency and fxd_crncy_code = 'INR')) and ratecode='NOR' and rtlist_date<=dbdate)) ; 
exception when no_data_found then conv_Rate:=1; 
end;
revamt:=totaldr * conv_rate;

if ( currency = 'JPY' )
then
        conv_rate := conv_rate * 100;
end if;

dbms_output.put_line('&1'||'SL000P'||'&'||'L'||'|'||'INR'||'|'||'&1'||'|'||pandsign||'|'||abs(revamt)||'|'||'TRFR frm '||currency||' CHARGES ACCTS'||'|'||'CFG'||'|'||conv_rate||'|'||abs(totaldr)||'|'||currency||'|'||'1');
end; --}
end if;

open fxincome(currency);
loop
fetch fxincome into acctnum, bal, parttrantype;
exit when fxincome%notfound;
totalcr:=totalcr + bal;
dbms_output.put_line(acctnum||'|'||currency||'|'||'&1'||'|'||parttrantype||'|'||abs(bal)||'|'||'TRFR TO P n L ACCNT'||'|'||'CFG'||'|'||conv_rate||'|'||abs(totalcr)||'|'||currency||'|'||'0');
end loop;
close fxincome;

select decode(sign(totalcr),-1,'D',1,'C') into pandsign from dual;
if (totalcr!=0) then
begin
begin
select nvl(var_crncy_units/fxd_crncy_units,1)  into conv_rate from rth where ratecode='NOR' and ((var_crncy_code='INR' and fxd_crncy_code = currency) or (var_crncy_code=currency and fxd_crncy_code = 'INR')) and rtlist_date = (select max(rtlist_date) from rth where ((var_crncy_code='INR' and fxd_crncy_code = currency) or (var_crncy_code=currency and fxd_crncy_code = 'INR')) and ratecode='NOR' and rtlist_date<=dbdate) and rtlist_num= (select max(rtlist_num) from rth where ((var_crncy_code='INR' and fxd_crncy_code = currency) or (var_crncy_code=currency and fxd_crncy_code = 'INR')) and ratecode='NOR' and rtlist_date= (select max(rtlist_date) from rth where ((var_crncy_code='INR' and fxd_crncy_code = currency) or (var_crncy_code=currency and fxd_crncy_code = 'INR')) and ratecode='NOR' and rtlist_date<=dbdate)) ;
exception when no_data_found then conv_Rate:=1;
end;
revamt:=totalcr * conv_rate;

if ( currency = 'JPY' )
then
	conv_rate := conv_rate * 100;
end if;

dbms_output.put_line('&1'||'SL000P'||'&'||'L'||'|'||'INR'||'|'||'&1'||'|'||pandsign||'|'||abs(revamt)||'|'||'TRFR frm '||currency||' INCOME ACCTS'||'|'||'CFG'||'|'||conv_rate||'|'||abs(totalcr)||'|'||currency||'|'||'1');
end;
end if;

end loop;
close crncy;
end;
/
