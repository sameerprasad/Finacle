REM####################################################################
REM File Name   : WLPM_MOD.sql 
REM Description : Table creation for Locker Discount/Premium Mod Table 
REM Author      : SARIKA (BBSSL)
REM Date        : 04-01-2010
REM Module	: LOCKER
REM####################################################################
drop table icici.LOC_PREMIUM_MODTABLE
/
drop public synonym WLPM_MOD
/
create table icici.LOC_PREMIUM_MODTABLE
(
	SOL_ID                  varchar2(8),
        LOCKER_NUM              varchar2(14),
        KEY_NUM                 varchar2(9),
        LOCKER_TYPE             varchar2(3),
        CUST_ID           	varchar2(9),
        TYPE                    varchar2(20),
        DISCOUNT_METHOD         char(1),
        DISCOUNT_AMOUNT         number(10,4),
        DISDURATION             VARCHAR2(10),
        DPERIOD_FROM            date,
        DPERIOD_TO              date,
        DREASON                 varchar2(50),
        DREMARKS                varchar2(20),
        PREMIUM_METHOD          char(1),
        PREMIUM_AMOUNT          number(10,4),
        DURATION                VARCHAR2(10),
        PERIOD_FROM             date,
        PERIOD_TO               date,
        REASON                  varchar2(50),
        REMARKS                 varchar2(20),
        SCHM_TYPE               varchar2(30),
        DISC_AMT                number(10,4),
        SPERIOD_FROM            date,
        SPERIOD_TO              date,
        SREASON                 varchar2(50),
        SREMARKS                varchar2(20),
        del_flg                 char(1),
        entity_cre_flg          char(2),
        LCHG_USER_ID            varchar2(15),
        LCHG_TIME               date,
        RCRE_USER_ID            varchar2(15),
        RCRE_TIME               date,
	DISCOUNT_TYPE		char(2)
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
create public synonym WLPM_MOD for icici.LOC_PREMIUM_MODTABLE
/
grant select,insert,update,delete on WLPM_MOD to tbagen
/
grant select on WLPM_MOD to tbacust
/
grant select on WLPM_MOD to tbautil
/
grant all on WLPM_MOD to tbaadm
/
