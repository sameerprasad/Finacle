set head off
set pages 0 
set echo off
set feedback off
set verify off
set termout off
spool CALAS.lst
select foracid||'|'||clr_bal_amt||'|'||rtrim(to_char(db_stat_date,'ddmmyyyy'))
from gam,gct where gam.schm_code='CALAS'
and gam.sol_id='&1';
spool off
exit

