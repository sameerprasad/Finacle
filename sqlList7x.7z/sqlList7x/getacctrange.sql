set head off
set linesize 300
set pages 0
set feedback off
set verify off
set termout off
spool carange.lst
select max(foracid)||'|'||min(foracid)||'|' from gam
where acct_prefix='05'
and cust_id between lpad('&1',9) and lpad('&2',9)
and acct_cls_flg='N' and sol_id='&3'
/
spool off
spool sbrange.lst
select max(foracid)||'|'||min(foracid)||'|' from gam
where schm_code  in (select schm_code from gsp where schm_type='SBA')
and cust_id between lpad('&1',9) and lpad('&2',9)
and acct_cls_flg='N' and sol_id='&3'
/

spool  datediff.dat
select (to_date('&4','dd-mm-yyyy') - db_stat_date)||'|'||
(to_date('&5','dd-mm-yyyy') - db_stat_date)||'|'||
decode ( sign(substr('&4',4,2) -3 ),1,substr('&4',7,4),substr('&4',7,4) - 1 )||'|'
from gct;
spool off

spool custstmt.lst
select foracid||'|'||cust_id||'|'||tran_date_bal||'|'||'&5'||'|'
FROM EAB A,GAM 
where 
GAM.SOL_ID  =   '&3' AND
GAM.ACCT_OPN_DATE   <=  '&5' AND
GAM.CUST_ID         >=  lpad('&1',9) AND
GAM.CUST_ID         <=  lpad('&2',9) AND
( (GAM.ACCT_CRNCY_CODE = '&6')
                            or
(GAM.crncy_code = '&6') )
AND
GAM.DEL_FLG         !=  'Y' AND
GAM.ACCT_OWNERSHIP != 'O' AND
GAM.ENTITY_CRE_FLG = 'Y' 
and A.ACID= GAM.ACID 
and  EOD_DATE IN (
SELECT MAX(EOD_DATE) FROM EAB B
WHERE B.ACID = A.ACID  AND EOD_DATE <='&5' AND END_EOD_DATE >='&5')
ORDER BY GAM.CUST_ID, GAM.CRNCY_CODE, GAM.FORACID;
spool off
spool  soltest.dat
select rtrim(sol_id)||'|'||br_name||'|'||br_addr_1||'|'||
       br_addr_2||' '||br_pin_code||'||'
       from sol,bct  where sol.del_flg !='Y'
 and sol.bank_code = bct.bank_code  and sol.br_code=bct.br_code;

spool off
