--  Source          :   rtgs_inw_chrg.sql
--  STR No          :   ICI6944
--  Author          :   Arkaja Sachan
--  Date            :   06/08/2008
--  Description     :   To generate a dump of the Account Numbers which have received
--                      credit through RTGS on the current date
--  Input           :   
--  Output          :   /tmp/rtgs_inw.lst


set serveroutput on size 1000000
set head off
set pages 0
set feedback off
set verify off
set linesize 500
set trims on
set termout off

spool /tmp/rtgs_inw.lst

SELECT	GAM.FORACID||'|'||GAM.SOL_ID 
FROM 	GAM, OTC
WHERE	OTC.paysys_id = 'GROSS'	
AND	OTC.mesg_id = 'R41'
AND	OTC.in_out_ind = 'I'	
AND	OTC.tran_date = (SELECT DB_STAT_DATE from GCT)	
AND	OTC.cr_acct = GAM.acid 	
AND	GAM.schm_type = 'SBA'
/
spool off;
