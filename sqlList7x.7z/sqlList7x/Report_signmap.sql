--------------------------------------------
--File Name   : Report_signmap.sql 
--Description : Signature not mapped report 
--Author      : Priscilla & Vijay
--Date        : 01-06-2010
------------------------------------------

set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_signmap.lst

DECLARE

lv_solid         gam.sol_id%type :='&1';
v_cnt			 number(10);
V_CUSTNAME		 varchar2(40);

CURSOR c1 IS

select 	distinct clmt.cust_id,
		clmt.sol_id,
		wlckm.rack_id,
		clmt.LOCKER_TYPE,
		clmt.locker_num,
		'',
		cmg.CUST_NAME Hirer_name,
		clmt.ISSUE_DATE allot_date 
from   clmt,cmg,wlckm
where  clmt.sol_id = lv_solid
and    lpad(clmt.cust_id,9,' ') = cmg.cust_id
and    wlckm.LOCKER_NUM=CLMT.LOCKER_NUM
and    clmt.del_flg != 'Y'
and    wlckm.ENTITY_CRE_FLG = 'Y'
and    clmt.sol_id=wlckm.sol_id
order by 8;

cursor c2(V_CUST_MH_ID cljh.CUST_MH_ID%type,V_LOCK_NO cljh.LOCKER_NUM%type) is
SELECT
		CUST_MH_ID,
		CUST_JH_ID
FROM
		CLJH,wlckm
WHERE
		wlckm.locker_num = cljh.locker_num
and		wlckm.sol_id = cljh.sol_id
and		CUST_MH_ID = V_CUST_MH_ID
AND		cljh.LOCKER_NUM = V_LOCK_NO
AND		cljh.SOL_ID = LV_SOLID
AND		cljh.DEL_FLG != 'Y'
AND		cljh.ENTITY_CRE_FLG = 'Y'
AND		wlckm.DEL_FLG != 'Y'
AND		wlckm.ENTITY_CRE_FLG = 'Y';

BEGIN

for f1 in c1
loop
	begin
	select count(1) into v_cnt from imt where cust_id = lpad(f1.cust_id,9);
	exception when no_data_found then
	v_cnt := 1;
	end;
	if(v_cnt = 0) then
	--{
			dbms_output.put_line( 	f1.sol_id         ||'|'||
									f1.rack_id        ||'|'||	
									f1.LOCKER_TYPE    ||'|'||	
									f1.locker_num     ||'|'||
									f1.cust_id        ||'|'||
									f1.Hirer_name     ||'|'|| 
									f1.allot_Date	 
								); 
	--}
	end if;
	for f2 in c2(f1.cust_id,f1.locker_num)
	loop
		begin
			SELECT COUNT(1) INTO V_CNT FROM IMT WHERE CUST_ID = lpad(F2.CUST_JH_ID,9)
			AND DEL_FLG != 'Y' AND ENTITY_CRE_FLG = 'Y';
			exception when no_data_found then
			v_cnt := 1;
		end;

		begin
			SELECT SUBSTR(CUST_NAME,1,40) INTO V_CUSTNAME FROM CMG WHERE CUST_ID = lpad(F2.CUST_JH_ID,9)
			AND DEL_FLG != 'Y' AND ENTITY_CRE_FLG = 'Y';
			exception when no_data_found then
			V_CUSTNAME := ' ';
		end;
		if(v_cnt = 0) then
		--{
				dbms_output.put_line(   f1.sol_id         ||'|'||
										f1.rack_id        ||'|'||
										f1.LOCKER_TYPE    ||'|'||
										f1.locker_num     ||'|'||
										f2.CUST_JH_ID     ||'|'||
										V_CUSTNAME     	  ||'|'||
										f1.allot_Date
									);
		--}
		end if;
	end loop;
end loop; 
END;
/
spool off
