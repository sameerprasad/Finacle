REM####################################################################
REM File Name   : WLSM.sql
REM Description : Table creation for Locker Setvar 
REM Author      : Prabhu.B (BBSSL)
REM Date        : 30-01-2010
REM Module	: LOCKER
REM####################################################################
drop table icici.LOC_SCHM_MASTER_TABLE
/
drop public synonym WLSM
/
create table icici.LOC_SCHM_MASTER_TABLE
(
	SOL_ID                  VARCHAR2(8),
        Scheme_name             VARCHAR2(15),
        Scheme_Desc             VARCHAR2(40),
        Disc_Based_On 	        VARCHAR2(25),
        Disc_Method1   	        CHAR(1),
        Disc_Value1             VARCHAR2(15),
        Effective_Frm1          DATE,
        Almnt_Date_Frm     	DATE,
        Almnt_Date_To       	DATE,
        Disc_Method2            CHAR(1),
        Disc_Value2             VARCHAR2(15),
        Effective_Frm2          DATE,
        Schm_Date_frm        	DATE,
        Schm_Date_To          	DATE,
        Disc_Method3            CHAR(1),
        Disc_Value3             VARCHAR2(15),
        Effective_Frm3          DATE,
        DEL_FLG                 CHAR(1),
        ENTITY_CRE_FLG          CHAR(1),
        LCHG_USER_ID            VARCHAR2(15),
        LCHG_TIME               DATE,
        RCRE_USER_ID            VARCHAR2(15),
        RCRE_TIME               DATE
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
create public synonym WLSM for icici.LOC_SCHM_MASTER_TABLE
/
grant select,insert,update,delete on WLSM to tbagen
/
grant select on WLSM to tbacust
/
grant select on WLSM to tbautil
/
grant all on WLSM to tbaadm
/

--==========================================

REM####################################################################
REM File Name   : WLSM_MOD.sql
REM Description : Table creation for Locker Setvar 
REM Author      : Prabhu.B (BBSSL)
REM Date        : 30-01-2010
REM Module	: LOCKER
REM####################################################################
drop table icici.LOC_SCHM_MOD_TABLE
/
drop public synonym WLSM_MOD
/
create table icici.LOC_SCHM_MOD_TABLE
(
	SOL_ID                  VARCHAR2(8),
        Scheme_name             VARCHAR2(15),
        Scheme_Desc             VARCHAR2(40),
        Disc_Based_On 	        VARCHAR2(25),
        Disc_Method1   	        CHAR(1),
        Disc_Value1             VARCHAR2(15),
        Effective_Frm1          DATE,
        Almnt_Date_Frm     	DATE,
        Almnt_Date_To       	DATE,
        Disc_Method2            CHAR(1),
        Disc_Value2             VARCHAR2(15),
        Effective_Frm2          DATE,
        Schm_Date_frm        	DATE,
        Schm_Date_To          	DATE,
        Disc_Method3            CHAR(1),
        Disc_Value3             VARCHAR2(15),
        Effective_Frm3          DATE,
        DEL_FLG                 CHAR(1),
        ENTITY_CRE_FLG          CHAR(1),
        LCHG_USER_ID            VARCHAR2(15),
        LCHG_TIME               DATE,
        RCRE_USER_ID            VARCHAR2(15),
        RCRE_TIME               DATE
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
create public synonym WLSM_MOD for icici.LOC_SCHM_MOD_TABLE
/
grant select,insert,update,delete on WLSM_MOD to tbagen
/
grant select on WLSM_MOD to tbacust
/
grant select on WLSM_MOD to tbautil
/
grant all on WLSM_MOD to tbaadm
/

--===================================================

REM####################################################################
REM File Name   : WLSMH.sql
REM Description : Table creation for Locker Setvar 
REM Author      : Prabhu.B (BBSSL)
REM Date        : 30-01-2010
REM Module	: LOCKER
REM####################################################################
drop table icici.LOC_SCHM_HIST_TABLE
/
drop public synonym WLSMH
/
create table icici.LOC_SCHM_HIST_TABLE
(
	SOL_ID                  VARCHAR2(8),
        Scheme_name             VARCHAR2(15),
        Scheme_Desc             VARCHAR2(40),
        Disc_Based_On 	        VARCHAR2(25),
        Disc_Method1   	        CHAR(1),
        Disc_Value1             VARCHAR2(15),
        Effective_Frm1          DATE,
        Almnt_Date_Frm     	DATE,
        Almnt_Date_To       	DATE,
        Disc_Method2            CHAR(1),
        Disc_Value2             VARCHAR2(15),
        Effective_Frm2          DATE,
        Schm_Date_frm        	DATE,
        Schm_Date_To          	DATE,
        Disc_Method3            CHAR(1),
        Disc_Value3             VARCHAR2(15),
        Effective_Frm3          DATE,
        DEL_FLG                 CHAR(1),
        ENTITY_CRE_FLG          CHAR(1),
        LCHG_USER_ID            VARCHAR2(15),
        LCHG_TIME               DATE,
        RCRE_USER_ID            VARCHAR2(15),
        RCRE_TIME               DATE
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
create public synonym WLSMH for icici.LOC_SCHM_HIST_TABLE
/
grant select,insert,update,delete on WLSMH to tbagen
/
grant select on WLSMH to tbacust
/
grant select on WLSMH to tbautil
/
grant all on WLSMH to tbaadm
/

