Rem     This file will create C_ATMCHGS
Rem     with the following characteristics.

Rem TABLE NAME: C_ATMCHGS

Rem SYNONYM:    C_ATMCHGS

drop table C_ATMCHGS
/
drop public synonym C_ATMCHGS
/
drop public synonym CATMCHGS
/
create table C_ATMCHGS
(
     foracid varchar2(16),
     begin_date date,
     tran_type varchar2(6),
     schm_type  varchar(3),
     free_tran_count number(9),
     free_tran_list varchar2(999),
     total_tran_count number(9),
     Us_On_Us_Ind Char(1)
)
/

/* STORE_START */
TABLESPACE ACCT_DETAILS_2_SMALL
/* STORE_END */
/

create public synonym C_ATMCHGS 
		for C_ATMCHGS
/
create public synonym CATMCHGS
                for C_ATMCHGS
/
create unique index IDX_C_ATMCHGS
on C_ATMCHGS(foracid,begin_date)
/* STORE_START */
storage ( PCTINCREASE 0 )
TABLESPACE IDX_ACCT_DETAILS_2_SMALL
/* STORE_END */
/
 grant select,insert,update,delete on C_ATMCHGS to tbaadm
/ 
 grant select, insert, update, delete on C_ATMCHGS to tbagen
/
 grant select on C_ATMCHGS to tbacust
/
grant select on C_ATMCHGS  to tbautil
/

