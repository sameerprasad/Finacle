Rem     This file will create CLOCKER_LETTER_OF_AUTHORITYM
Rem     with the following characteristics.

Rem     Coded by : Chandra Sekar (BBSSL)

Rem     Module  : LOCKER


Rem TABLE NAME: CLOCKER_LETTER_OF_AUTHORITYM

Rem SYNONYM:    CLOCKER_LETTER_OF_AUTHORITYM

drop table icici.CLOCKER_LETTER_OF_AUTHORITYM
/
drop public synonym CLCLA_MOD
/
create table icici.CLOCKER_LETTER_OF_AUTHORITYM
(
        sol_id varchar2(8),
        locker_number varchar2(12),
        key_number varchar2(8),
        cust_mh_id varchar2(9),
        holder_type char(1),
		HIRER_ID    VARCHAR2(9),
        clcla_srl_num number(4),
        cust_ah_id varchar2(9),
        cust_name varchar2(80),
        cust_addr1 varchar2(50),
        cust_addr2 varchar2(50),
        cust_city varchar2(5),
        cust_state varchar2(5),
        cust_country varchar2(5),
        cust_postal varchar2(6),
        cust_phone1 varchar2(15),
        cust_phone2 varchar2(15),
        access_from_date date,
        access_to_date date,
        foracid varchar2(16),
	LCHG_USER_ID varchar2(15),
        LCHG_TIME date,
        RCRE_USER_ID varchar2(15),
        RCRE_TIME date,
        del_flg char(1)
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
create public synonym CLCLA_MOD for icici.CLOCKER_LETTER_OF_AUTHORITYM
/
grant select, insert, update, delete on CLCLA_MOD to tbagen
/
grant select on CLCLA_MOD to tbacust
/
grant select on CLCLA_MOD to tbautil
/
grant all on CLCLA_MOD to tbaadm
/
