rem accept dt1 prompt "Enter date of Report ::::"
accept solid prompt 'ENTER THE SOL_ID OF YOUR BRANCH : '
set echo off
set verify off
set feedback off
set head off
set termout off
set pages 100
set numformat b99,99,99,99,99,99,999.99
column today new_value dt1
select to_char(db_stat_date,'dd-mm-yyyy') today from gct ;
break on a on report
break on b on report
compute sum of a on report
compute sum of b on report
spool listexim.lst

select '                  as on &dt1' from dual;
select ' -----------------------------------------------------------' from dual;
select 'The Outstanding EPC Balance To Be Tallied With GL' from dual;
select '2. Outstanding Post-Shipment Export Credit :' from dual;
select ' A) Export Bills(sight as also usance) negotiated/purchased/discounted' from dual;
select 'List of bills Purchased' from dual;
select (fbm.bill_id),(fbm.bp_liab) a from fbm,fbh
where fbm.sol_id = fbh.sol_id
and fbm.bill_id = fbh.bill_id
and fbm.reg_type = 'FOBP'
and fbm.bp_liab > 0
and fbh.event_num = (select max(event_num) from fbh A
            where A.bill_func = 'P'
            and A.sol_id = fbm.sol_id
            and fbm.bill_id = A.bill_id)
and fbh.bill_func = 'P'
and fbm.cls_flg != 'Y'
and fbm.del_flg != 'Y'
and fbm.bill_stat in ('G','P')
and trunc(lodg_Date) <= to_date('&dt1','dd-mm-yyyy')
and fbm.sol_id = '&solid'
and fbh.sol_id = '&solid' 
/
select 'List of Bills Purchased in Foreign Currency ' from dual;
select (fbm.bill_id),(fbm.bp_liab) a from fbm, fbh
where fbm.sol_id = fbh.sol_id
and fbm.bill_id = fbh.bill_id
and fbm.reg_type = 'FBPF' 
and fbm.del_flg != 'Y'
and fbm.cls_flg != 'Y'
and fbm.bill_stat in ('G','P')
and trunc(lodg_Date) <= to_date('&dt1','dd-mm-yyyy')
and fbm.sol_id = '&solid'
and fbh.sol_id = '&solid' 
/
select ' B) Advance against Export Bills (sight as also usance ) sent on collection' from dual;
select (fbm.bill_id),(fbm.bp_liab) a from fbm,fbh
where fbm.sol_id = fbh.sol_id
and fbm.bill_id = fbh.bill_id
and fbm.reg_type = 'FOBP'
and fbm.bp_liab > 0
and fbh.event_num = (select max(event_num) from fbh A
					 where A.sol_id = fbm.sol_id
					 and fbm.bill_id = A.bill_id)
and fbh.bill_func ='H'
and  not exists(select 'x' from fbh
            where fbh.bill_func = 'P'
            and fbh.sol_id = fbm.sol_id
            and fbm.bill_id = fbh.bill_id)
and fbm.cls_flg != 'Y'
and fbm.del_flg != 'Y'
and fbm.bill_stat in ('G','P')
and trunc(lodg_Date) <= to_date('&dt1','dd-mm-yyyy')
and fbm.sol_id = '&solid'
and fbh.sol_id = '&solid' 
/
select ' -----------------------------------------------------------------------' from dual;
select '4. Outstanding import bills (under LC as also collection) pending payment by customers' from dual;
select 'List of Sight Bills Under DC' from dual;
select distinct(fbm.bill_id),(fbm.bill_amt_inr) b 
from fbm,fbi
where fbm.sol_id = fbi.sol_id
and fbm.bill_id=fbi.bill_id  
and fbm.usance_months=0
and fbm.usance_days= 0
and fbm.cls_flg!='Y'
and fbm.bill_stat in ('G','P')
and fbm.under_lc_flg = 'Y'
and trunc(fbm.lodg_Date) <= to_date('&dt1','dd-mm-yyyy')
and fbm.sol_id = '&solid'
and fbi.sol_id = '&solid' 
/
select 'List of Usance Bills Under DC' from dual;
select distinct(fbm.bill_id),(fbm.bill_amt_inr) b
from fbm,fbi
where fbm.sol_id = fbi.sol_id
and fbm.bill_id=fbi.bill_id  
and fbm.under_lc_flg = 'Y'
and (fbm.usance_months > 0 or fbm.usance_days > 0) 
and fbm.cls_flg!='Y'
and fbm.bill_stat in ('G','P')
and trunc(fbm.lodg_Date) <= to_date('&dt1','dd-mm-yyyy')
and fbm.sol_id = '&solid' 
and fbi.sol_id = '&solid' 
/
select 'List of Import Collection Bills (FIBC + FDIC)' from dual;
select distinct(fbm.bill_id),(bill_amt_inr) b 
from fbm,fbi
where fbm.sol_id = fbi.sol_id
and fbm.bill_id=fbi.bill_id  
and fbm.under_lc_flg != 'Y'
and fbm.bill_stat in ('G','P')
and fbm.cls_flg!='Y'
and fbm.del_flg != 'Y'
and trunc(fbm.lodg_Date) <= to_date('&dt1','dd-mm-yyyy')
and fbm.sol_id = '&solid' 
and fbi.sol_id = '&solid' 
/
select '----------------------------------------------------------------------- ' from dual;
select ' 5. Outstanding Export Bills (sight as also usance) sent on collection,
including those against which credit has been given ::    ' from dual; 
select distinct(fbm.bill_id),(fbm.bill_amt_inr) b 
from fbm,fbe
where fbm.bill_id =fbe.bill_id
and fbm.sol_id = fbe.sol_id
and fbm.bill_stat in ('G','P')
and fbm.cls_flg!='Y'
and fbm.bp_liab = 0
and trunc(fbm.lodg_Date) <= to_date('&dt1','dd-mm-yyyy')
and fbm.sol_id = '&solid' 
and fbe.sol_id = '&solid' 
/
select 'List of Bills against which rupee finance has been provided' from dual;
select distinct(fbm.bill_id),(fbm.bp_liab) a
from fbm,fbh
where fbm.sol_id = fbh.sol_id
and fbm.bill_id = fbh.bill_id
and fbm.reg_type = 'FOBP'
and fbm.bp_liab > 0
and fbh.bill_func ='H'
and  not exists(select 'x' from fbh
            where fbh.bill_func = 'P'
            and fbh.sol_id = fbm.sol_id
            and fbm.bill_id = fbh.bill_id)
and fbm.cls_flg != 'Y'
and fbm.del_flg != 'Y'
and fbm.bill_stat in ('G','P')
and trunc(lodg_Date) <= to_date('&dt1','dd-mm-yyyy')
and fbh.sol_id = '&solid' 
and fbm.sol_id = '&solid' 
/
spool off
exit
