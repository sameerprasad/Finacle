set escape "\"
--DROP PACKAGE TEST2
--/
CREATE OR REPLACE PACKAGE TEST2 AS
PROCEDURE TEST2( inp_str IN VARCHAR2,
                    out_retCode OUT NUMBER,
                    out_rec OUT VARCHAR2);
END TEST2;
/
CREATE OR REPLACE PACKAGE BODY TEST2 AS

OutArr                  basp0099.ArrayType;
CT_tran_date			CTD.tran_date%type;
billid					FBH.bill_id%type;
solid					FBH.sol_id%type;
F_sol_id				FBH.sol_id%type;
F_bill_id				FBH.bill_id%type;
F_vfd_bod_date			FBH.vfd_bod_date%type;
F_tran_id				FBH.tran_id%type;
F_bill_func				FBH.bill_func%type;
F_event_amt_crncy		FBH.event_amt_crncy%type;
F_event_amt				FBH.event_amt%type;
F_event_rate			FBH.event_rate%type;
F_event_amt_inr			Number(40,2);
--CT_tran_date			CTD.tran_date%type;
CT_tran_id				CTD.tran_id%type; 
CT_part_tran_srl_num    CTD.part_tran_srl_num%type;
CT_part_tran_type		CTD.part_tran_type%type;
CT_foracid				GAM.foracid%type;
CT_sol_id				GAM.sol_id%type;
CT_bacid				GAM.bacid%type;
CT_gl_sub_head_code 	GAM.gl_sub_head_code%type;
CT_acct_ownership 		GAM.acct_ownership%TYPE;
CT_acct_crncy_code 		GAM.acct_crncy_code%TYPE;
CT_tran_crncy_code		CTD.tran_crncy_code%TYPE;
CT_tran_amt				CTD.tran_amt%type;
CT_ref_crncy_code		CTD.ref_crncy_code%TYPE;
CT_ref_amt				CTD.ref_amt%type;
CT_tran_particular		CTD.tran_particular%type; 
CT_tran_rmks			CTD.tran_rmks%type;
CT_rate					CTD.rate%type;
indicator               char(1);
counter             	Number(2) := 0;
loc_cname				CMG.cust_name%TYPE;
loc_cc					CMG.cust_const%TYPE;
loc_cstate				CMG.cust_comu_state_code%TYPE;
loc_bill_id           	FBM.bill_id%TYPE;
loc_party_code          FBM.party_code%TYPE;
loc_party_name          FBM.party_name%TYPE;
loc_sol_id     			FBM.sol_id%type;
loc_reg_type      		FBM.reg_type%TYPE;
loc_reg_sub_type       	FBM.reg_sub_type%TYPE;
loc_bill_amt           	FBM.bill_amt%TYPE;
loc_bill_amt_inr        FBM.bill_amt_inr%TYPE;
loc_lodg_date			FBM.lodg_date%TYPE;
loc_due_date			FBM.due_date%TYPE;
loc_bill_date			FBM.bill_date%TYPE;
loc_amt_purchsd			PST.amt_purchsd%TYPE;
loc_crncy_purchsd		PST.crncy_purchsd%TYPE;
loc_amt_sold			PST.amt_sold%TYPE;
loc_crncy_sold			PST.crncy_sold%TYPE;
loc_rate				PST.rate%TYPE;
loc_base_rate			PST.base_rate%TYPE;
loc_party_addr1         FBM.party_addr1%type;
loc_party_addr2         FBM.party_addr2%type;
loc_party_addr3         FBM.party_addr3%type;
loc_party_cntry_code    FBM.party_cntry_code%type;
loc_bill_crncy_code     FBM.bill_crncy_code%type;
loc_other_party_code    FBM.other_party_code%type;
loc_other_party_name    FBM.other_party_name%type;
loc_other_party_addr_1  FBM.other_party_addr_1%type;
loc_other_party_addr_2  FBM.other_party_addr_2%type;
loc_other_party_addr_3  FBM.other_party_addr_3%type;
loc_other_party_cntry_code  FBM.other_party_cntry_code%type;
loc_fd_ref_num          	FBM.fd_ref_num%type;
loc_solid               	SOL.sol_id%type;
loc_bnkcode               	BKC.bank_code%type;
loc_bnknm               	BKC.bank_name%type;
loc_soldesc             	SOL.sol_desc%type;
loc_addr1               	SOL.addr_1%type;
loc_addr2               	SOL.addr_2%type;
loc_citycode           		SOL.city_code%type;
loc_statecode          		SOL.state_code%type;
loc_pincode            		SOL.pin_code%type;
loc_invoice_num        		FEI.invoice_num%type;
loc_invoice_date      		FEI.invoice_date%type;
br_city_desc            RCT.ref_desc%type;
br_state_desc           RCT.ref_desc%type;
cu_country_desc         RCT.ref_desc%type;
ot_country_desc         RCT.ref_desc%type;
loc_dbstatdate          GCT.db_stat_date%type;
loc_glcode              GSH.gl_code%type;
loc_billfunc            FBH.bill_func%type;
cu_state_desc           RCT.ref_desc%type;
tmpcuscr  		        varchar2(100):='';
tmpcusdr        	   	varchar2(100):='';
trantype          		char(1):='';
------------------
--Define Cursor 1
------------------
-- I hardcoded sol id just to debug,here output should be based on input condn of sol and bill id
------------------------------------------------------------------------------------------------
		CURSOR 	fbill_det(solid varchar2, billId varchar2) is 
		SELECT  FBH.bill_id,
				FBH.sol_id,
				FBH.vfd_bod_date,
				FBH.tran_id,
				FBH.bill_func,
				FBH.event_amt_crncy,
				FBH.event_amt,
				FBH.event_rate ,
				decode(FBH.event_amt_crncy,'JPY',(FBH.event_amt * FBH.event_rate/100),'INR',FBH.event_amt,(FBH.event_rate * FBH.event_amt)) event_amt_inr
		FROM    FBH
		WHERE	FBH.del_flg <> 'Y'
		AND	FBH.entity_cre_flg <> 'N'
		AND FBH.sol_id = solid 
		AND FBH.bill_id = billid;

------------------
--Define Cursor 2
------------------
CURSOR  ctd_det(F_tran_id varchar2,F_vfd_bod_date varchar2) is
select tran_date,
	   tran_id,
	   part_tran_srl_num,
	   part_tran_type,
	   gam.foracid,
	   gam.sol_id,
	   gam.bacid,
	   gam.gl_sub_head_code,
	   gam.acct_ownership,
	   gam.acct_crncy_code crncy_code,
	   tran_crncy_code,
	   tran_amt,
	   ref_crncy_code,
	   ref_amt,
	   tran_particular,
	   tran_rmks,
	   rate
from   ctd,gam
where  tran_id  = F_tran_id 
  and  ctd.acid=gam.acid
  and  tran_date=F_vfd_bod_date
  and  ctd.del_flg <> 'Y'
union
 select tran_date,
		tran_id,
		part_tran_srl_num,
		part_tran_type,
		gam.foracid,
		gam.sol_id,
		gam.bacid,
		gam.gl_sub_head_code,
		gam.acct_ownership,
		gam.acct_crncy_code crncy_code,
		tran_crncy_code,
		tran_amt,
		ref_crncy_code,
		ref_amt,
		tran_particular,
		tran_rmks,
		rate
from 	dtd,gam
where 	tran_id=F_tran_id
  and 	dtd.acid=gam.acid
  and 	tran_date=F_vfd_bod_date
  and 	dtd.del_flg <> 'Y';
----------------------------
--Describing  procedure body
----------------------------

PROCEDURE TEST2(    inp_str     IN  VARCHAR2,
			 out_retCode OUT NUMBER,
			 out_rec     OUT VARCHAR2) AS

BEGIN
--{
		out_retCode     := 0;

	IF NOT fbill_det%ISOPEN AND NOT ctd_det%ISOPEN THEN
		--{
		basp0099.formInputArr (inp_str,OutArr);
		solid        := OutArr(0);
		billId        := OutArr(1);
		OPEN fbill_det(solid,billId);
		--}
	END IF;

--	IF fbill_det%NOTFOUND THEN
	IF fbill_det%NOTFOUND AND NOT ctd_det%ISOPEN THEN
		CLOSE fbill_det;
		dbms_output.put_line('5');
		out_retCode := 1;
--		return;
	END IF;

	

			IF ((fbill_det%ISOPEN))  THEN 
--{
			dbms_output.put_line('1st cursor open');
				FETCH fbill_det INTO 	F_bill_id,
										F_sol_id,
										F_vfd_bod_date,
										F_tran_id,
										F_bill_func,
										F_event_amt_crncy,
										F_event_amt,
										F_event_rate,
										F_event_amt_inr;
				dbms_output.put_line('cursor 1');


BEGIN --{first cursor begin


		BEGIN
		--{
			dbms_output.put_line('First select of main curs');	
			SELECT 	
					sol_id, 
					party_code, 
					party_name,
					party_addr1,
					party_addr2,
					party_addr3,
					party_cntry_code,
					bill_id, 
					due_date, 
					bill_date,
					bill_crncy_code,
					other_party_code,
					other_party_name,
					other_party_addr_1,
					other_party_addr_2,
					other_party_addr_3,
					other_party_cntry_code,
					reg_type,
					reg_sub_type, 
					bill_amt, 
					bill_amt_inr,
					lodg_date, 
					fd_ref_num
			INTO 	
					loc_sol_id, 
					loc_party_code, 
					loc_party_name,
					loc_party_addr1,
					loc_party_addr2,
					loc_party_addr3,
					loc_party_cntry_code,
					loc_bill_id, 
					loc_due_date, 
					loc_bill_date,
					loc_bill_crncy_code,
					loc_other_party_code,
					loc_other_party_name,
					loc_other_party_addr_1,
					loc_other_party_addr_2,
					loc_other_party_addr_3,
					loc_other_party_cntry_code,
					loc_reg_type, 
					loc_reg_sub_type, 
					loc_bill_amt,
					loc_bill_amt_inr, 
					loc_lodg_date, 
					loc_fd_ref_num
			FROM 	FBM
			WHERE 	FBM.sol_id 		= F_sol_id
			AND 	FBM.bill_id 	= F_bill_id;
			EXCEPTION
			WHEN no_data_found THEN
			loc_bill_id			:= 'NULL';
			loc_party_code		:= 'NULL';
			loc_sol_id			:= 'NULL';
			loc_reg_type		:= 'NULL';
			loc_reg_sub_type	:= 'NULL';
			loc_bill_amt		:= 0;
			loc_bill_amt_inr	:= 0;
			loc_lodg_date		:= '';
			loc_due_date		:= '';
			loc_bill_date		:= '';
			
				END;
			--}

			BEGIN
			--{
				SELECT 	sol_id,bank_code,sol_desc,addr_1,addr_2,city_code,state_code,pin_code
				INTO 	
						loc_solid,
						loc_bnkcode,
						loc_soldesc,
						loc_addr1,
						loc_addr2,
						loc_citycode,
						loc_statecode,
						loc_pincode
				FROM 	SOL
				WHERE 	SOL.sol_id = loc_sol_id
				AND		del_flg <> 'Y';
				EXCEPTION
				WHEN no_data_found THEN
					loc_solid  		:= '';
					loc_bnkcode  	:= '';
					loc_soldesc 	:= '';
					loc_addr1 		:= '';
					loc_addr2 		:= '';
					loc_citycode 	:= '';
					loc_statecode 	:= '';
					loc_pincode 	:= '';
			END;
			--}

				BEGIN
				--{
					SELECT 	bank_name
					INTO 	loc_bnknm
					FROM 	BKC
					WHERE bank_code=loc_bnkcode	
					AND del_flg <> 'Y';
				EXCEPTION
					WHEN no_data_found THEN
					loc_bnknm :='';
				END;
				--}

				BEGIN
				--{
					SELECT 	db_stat_date
					INTO 	loc_dbstatdate
					FROM 	GCT;
					EXCEPTION
						WHEN no_data_found THEN
						loc_dbstatdate:='';
				--}
				END;

				BEGIN
				--{
						SELECT 	cust_name,nvl(cust_perm_state_code, cust_comu_state_code),cust_const
						INTO 	loc_cname, loc_cstate, loc_cc
						FROM 	CMG
						WHERE 	CMG.cust_id = loc_party_code
						AND		del_flg <> 'Y'
						AND		entity_cre_flg <> 'N';
						EXCEPTION
						WHEN no_data_found THEN
							loc_cname 	:= '';
							loc_cc		:= '';
							loc_cstate  := '';
				END;
				--}

				BEGIN
				--{
					SELECT  ref_desc
					INTO    cu_state_desc
					FROM    RCT
					WHERE   ref_rec_type = '02'
					AND     ref_code = loc_cstate;
					EXCEPTION
					WHEN NO_DATA_FOUND THEN
						cu_state_desc := 'NULL';
				END;
				--}

				BEGIN
				--{
				SELECT 	invoice_num, invoice_date
				INTO 	loc_invoice_num,loc_invoice_date
				FROM 	FEI
				WHERE 	FEI.bill_id = F_bill_id
				AND     del_flg <> 'Y';
				EXCEPTION
					WHEN no_data_found THEN
						loc_invoice_num := '';
						loc_invoice_date := '';
				END;
				--}


				if ((loc_party_code is null) or (loc_party_code = '')) then
					loc_cname := loc_party_name;
				end if;


				-- Address Descriptions
				BEGIN
				--{
					SELECT  ref_desc
					INTO    br_city_desc
					FROM    RCT
					WHERE   ref_rec_type = '01'
					AND     ref_code = loc_citycode;
					exception
						WHEN no_data_found THEN
							br_city_desc := 'NULL';
				END;
				--}

				BEGIN
				--{
					SELECT  ref_desc
					INTO    br_state_desc
					FROM    RCT
					WHERE   ref_rec_type = '02'
					AND     ref_code = loc_statecode;
					exception
					WHEN no_data_found THEN
						br_state_desc := 'NULL';
				--}
				END;

				BEGIN
				--{
					SELECT  ref_desc
					INTO    cu_country_desc
					FROM    RCT
					WHERE   ref_rec_type = '03'
					AND     ref_code = loc_party_cntry_code;
					exception
						WHEN no_data_found THEN
							cu_country_desc := 'NULL';
				--}
				END;

				BEGIN
				--{
					SELECT  ref_desc
					INTO    ot_country_desc
					FROM    RCT
					WHERE   ref_rec_type = '03'
					AND     ref_code = loc_other_party_cntry_code;
					exception
						WHEN no_data_found THEN
						ot_country_desc := 'NULL';
				--}
					END;

--- Open the 2nd cursor if the 1st cursor is open 
		
				IF fbill_det%ISOPEN AND NOT ctd_det%ISOPEN THEN 
					OPEN ctd_det(F_tran_id,F_vfd_bod_date);
				END IF;



--				IF fbill_det%ISOPEN AND ctd_det%ISOPEN THEN 
				IF  ctd_det%ISOPEN THEN 
--{
				--{
						FETCH ctd_det INTO
					   	CT_tran_date,
					   	CT_tran_id,
					   	CT_part_tran_srl_num,
					   	CT_part_tran_type,
					   	CT_foracid,
					   	CT_sol_id,
					   	CT_bacid,
					   	CT_gl_sub_head_code,
					   	CT_acct_ownership,
					   	CT_acct_crncy_code,
					   	CT_tran_crncy_code,
					   	CT_tran_amt,
					   	CT_ref_crncy_code,
					   	CT_ref_amt,
					   	CT_tran_particular,
					   	CT_tran_rmks,
					   	CT_rate;
					--}
IF ctd_det%NOTFOUND  THEN
        -- {
			dbms_output.put_line('ctd closed');
            CLOSE ctd_det;
        -- }
END IF;
BEGIN --{ second cursor begin
			    BEGIN
			  --{
				SELECT 	gl_code
				INTO 	loc_glcode
				FROM 	GSH
				WHERE 	gl_sub_head_code = CT_gl_sub_head_code
				AND 	sol_id = CT_sol_id
				AND 	crncy_code = CT_acct_crncy_code;
				EXCEPTION
					WHEN no_data_found THEN
						loc_glcode := '';
				END;
			  --}
				BEGIN
              --{
                SELECT  BILL_FUNC
                INTO    loc_billfunc
                FROM    FBH
                WHERE   FBH.sol_id = solid
                AND     FBH.bill_id = billid
                AND     FBH.tran_id = CT_tran_id;
                EXCEPTION
                    WHEN no_data_found THEN
                        loc_billfunc := '';
                END;
              --}
                dbms_output.put_line('BILLFUNC:'||loc_billfunc);


	if (CT_ref_crncy_code  = 'INR' and CT_tran_crncy_code = 'INR' and CT_acct_ownership = 'C' and CT_part_tran_type = 'C' and (CT_gl_sub_head_code in ('60010','60012','60013','60014') or (CT_gl_sub_head_code like '05%' or CT_gl_sub_head_code like '08%'))) then
			  indicator := 'A';

			  tmpcuscr  := CT_foracid || '-' || CT_part_tran_type || '-' || CT_tran_crncy_code || '-' || CT_tran_amt;
	elsif (CT_part_tran_type = 'D' and (CT_bacid in ( 'CNFBEXP', 'CNFBIMP', 'CNFX-OTHER', 'ICFBEXP', 'ICFBIMP','CHCOURFEX', 'CHCOURIER', 'CHP\&T', 'CHP\&TFEX', 'CHTLX', 'EXFT', 'EXFT-OTHERS'))) then
			  indicator := 'E';

	elsif (CT_bacid = 'CONSOL' and CT_part_tran_type = 'C') then

			  indicator := 'C';
	elsif (CT_gl_sub_head_code in ('63040','63042') and CT_part_tran_type = 'D') then

			  indicator := 'D';

	elsif (CT_ref_crncy_code  = 'INR' and CT_tran_crncy_code = 'INR' and CT_acct_ownership = 'C' and CT_part_tran_type = 'D' and (CT_gl_sub_head_code in ('60010','60012','60013','60014') or (CT_gl_sub_head_code like '05%' or CT_gl_sub_head_code like '08%'))) then
			  indicator := 'B';
			  tmpcusdr  := CT_foracid || '-' || CT_part_tran_type || '-' || CT_tran_crncy_code || '-' || CT_tran_amt;
	elsif (CT_part_tran_type = 'C' and (CT_bacid in ( 'CNFBEXP', 'CNFBIMP', 'CNFX-OTHER', 'ICFBEXP', 'ICFBIMP','CHCOURFEX', 'CHCOURIER', 'CHP\&T', 'CHP\&TFEX', 'CHTLX', 'EXFT', 'EXFT-OTHERS'))) then
			  indicator := 'F';
	elsif (CT_bacid = 'CONSOL' and CT_part_tran_type = 'D') then
			  indicator := 'G';
	elsif (CT_gl_sub_head_code in ('63040','63042') and CT_part_tran_type = 'C') then
			  indicator := 'H';
	elsif (CT_ref_crncy_code  != 'INR' or CT_tran_crncy_code != 'INR' and CT_acct_ownership = 'C' and CT_part_tran_type = 'C' and (CT_gl_sub_head_code in ('60010','60012','60013','60014') or (loc_glcode in ('05','08')))) then
			  indicator := 'I';
			  tmpcuscr  := CT_foracid || '-' || CT_part_tran_type || '-' || CT_tran_crncy_code || '-' || CT_tran_amt;
	elsif (CT_ref_crncy_code  != 'INR' or CT_tran_crncy_code != 'INR' and CT_acct_ownership = 'C' and CT_part_tran_type = 'D' and (CT_gl_sub_head_code in ('60010','60012','60013','60014') or (loc_glcode in ('05','08')))) then
			  indicator := 'J';
			  tmpcusdr  := CT_foracid || '-' || CT_part_tran_type || '-' || CT_tran_crncy_code || '-' || CT_tran_amt;
	elsif (CT_gl_sub_head_code in ('60015','60016')) then
			  indicator := 'K'; 
	elsif (CT_gl_sub_head_code in ('63055')) then
			  indicator := 'L'; 
	else
			  indicator := 'X';
	end if;


		if indicator = 'E' then
				trantype := 'C';
		elsif indicator = 'F' then 
				trantype := 'D';
		elsif (F_bill_func = 'P'  or F_bill_func = 'H') and (indicator = 'D' or indicator = 'H') and (CT_part_tran_type = 'C') then
				trantype := 'D';
		elsif (F_bill_func = 'P'  or F_bill_func = 'H') and (indicator = 'D' or indicator = 'H') and (CT_part_tran_type = 'D') then
		   		trantype := 'C';
		elsif (F_bill_func = 'O') and (indicator = 'L') and (CT_part_tran_type = 'D') then
				 trantype := 'C';
		elsif (F_bill_func = 'O') and (indicator = 'L') and (CT_part_tran_type = 'C') then
				 trantype := 'D';
		else
				 trantype := CT_part_tran_type;
		end if;

		IF CT_gl_sub_head_code in ('63040','63042','60010','60012', '60013','60014','60015','60016','63055') or (CT_gl_sub_head_code like '05%' or CT_gl_sub_head_code like '08%') or (CT_bacid in ( 'CNFBEXP', 'CNFBIMP', 'CNFX-OTHER', 'ICFBEXP', 'ICFBIMP','CONSOL', 'CHCOURFEX','CHCOURIER', 'CHTLX', 'CHP\&T', 'CHP\&TFEX','EXFT', 'EXFT-OTHERS')) THEN
		--{
		out_rec :=			loc_solid ||'|'||
                     		loc_soldesc ||'|'||
                     		loc_addr1 ||'|'||
                     		loc_addr2 ||'|'||
                      		loc_citycode ||' '||
                      		br_city_desc ||'|'||
                      		loc_statecode ||' '||
                      		br_state_desc ||'|'||
                     		loc_pincode ||'|'||
                     		loc_party_code ||'|'||
                     		loc_cname ||'|'||
                     		loc_party_addr1 ||'|'||
                     		loc_party_addr2 ||'|'||
                     		loc_party_addr3 ||'|'||
                      		loc_party_cntry_code ||' '||
                      		cu_country_desc ||'|'||
                     		loc_bill_id ||'|'||
                     		loc_due_date  ||'|'||
                     		loc_bill_date  ||'|'||
                     		loc_bill_crncy_code ||'|'||
                     		loc_other_party_code ||'|'||
                     		loc_other_party_name ||'|'||
                     		loc_other_party_addr_1 ||'|'||
                     		loc_other_party_addr_2 ||'|'||
                     		loc_other_party_addr_3 ||'|'||
                     		loc_other_party_cntry_code ||' '||
                      		ot_country_desc ||'|'||
                     		loc_reg_type  ||'|'||
                     		loc_reg_sub_type  ||'|'||
                     		loc_bill_amt ||'|'||
                     		loc_bill_amt_inr  ||'|'||
                     		loc_lodg_date  ||'|'||
                     		loc_fd_ref_num ||'|'||
                     		loc_invoice_num ||'|'||
                     		loc_invoice_date ||'|'||
--                     F_bill_func   ||'|'||
                     		loc_billfunc   ||'|'||
                     		F_event_amt_crncy ||'|'||
                     		F_event_amt   ||'|'||
                     		F_event_rate   ||'|'||
                     		F_event_amt_inr   ||'|'||
                     		CT_tran_date ||'|'||
                     		CT_tran_id ||'|'||
                     		CT_part_tran_srl_num ||'|'||
                     		CT_part_tran_type ||'|'||
                     		CT_foracid ||'|'||
                     		CT_bacid ||'|'||
                     		CT_gl_sub_head_code ||'|'||
					 		CT_acct_ownership ||'|'||
                     		CT_tran_crncy_code ||'|'||
	                     	CT_tran_amt ||'|'||
                     		CT_ref_crncy_code ||'|'||
                     		CT_ref_amt ||'|'||
                     		CT_tran_particular ||'|'||
                     		CT_tran_rmks ||'|'||
                     		CT_rate     ||'|'||
                     		loc_bnknm ||'|'||
                      		loc_cstate ||' '||
                      		cu_state_desc ||'|'||
                     		loc_dbstatdate ||'|'||
                     		loc_glcode     ||'|'||
                     		tmpcuscr     ||'|'||
                     		tmpcusdr     ||'|'||
                     		trantype     ||'|'||
                     		indicator;
					END IF;
					--}
END; --}  second cursor end
		END IF;
--}
--					CLOSE ctd_det;
END; --} first cursor end
END IF;
--}

END TEST2;
--}
END TEST2;
/
DROP PUBLIC SYNONYM TEST2
/
CREATE PUBLIC SYNONYM TEST2 FOR TEST2
/
GRANT EXECUTE ON TEST2 TO TBAGEN, TBAUTIL, TBACUST
/
