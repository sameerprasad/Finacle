set head off
set linesize 300
set trims on
set pages 0
set feedback off
set verify off
set termout off
spool acctsolid
select	distinct(home_sol_id)
from	psp_tmp
where	listid = '&1'||'A';
spool off
