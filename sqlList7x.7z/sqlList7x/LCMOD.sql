Rem     This file will create LOCKER_MODIFICATION TABLE
Rem     with the following characteristics.

Rem     Coded by : BBSSL

Rem     Module  : LOCKER


Rem TABLE NAME: LOCKER_MODIFICATION

Rem SYNONYM:    LCMOD

drop table icici.LOCKER_MODIFICATION
/
drop public synonym LCMOD
/
create table icici.LOCKER_MODIFICATION
(
SOL_ID			VARCHAR2(8),
LOCKER_NUM		VARCHAR2(12),
MODIFIED_FIELD		VARCHAR2(12),
MODIFIED_VALUE		VARCHAR2(50),
LCHG_USER_ID		VARCHAR2(15),
LCHG_TIME		VARCHAR2(25)
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2_SMALL
/* STORE_END */
/
create public synonym LCMOD for icici.LOCKER_MODIFICATION
/
grant select, insert, update, delete on LCMOD to tbagen
/
grant select on LCMOD to tbacust
/
grant select on LCMOD to tbautil
/
grant all on LCMOD to tbaadm
/
