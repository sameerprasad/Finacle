rem set echo off
rem set termout off
set pause off
rem script for printing  details of DD Issued for bod date in pre-eod
rem author VIDYA
rem version 1.0 dated  5-12-1995
set verify off
whenever sqlerror exit sql.sqlcode
set feedback off
set linesize 132 
set pages 66
set newpage 0
set space 0
define all_dashes = '__________________________________________________________________________________________________________________'
column today new_value today_date

select to_char(db_stat_date,'dd/mm/yyyy') today
from gct;

spool ibddpayee

ttitle center  'Details of DD Issued with Payee name > 40 chars as on ' today_date skip 1 - 
right 'Page :       ' format 999 sql.pno skip 1 -
left all_dashes skip 2

set space 1
	
col dd_num heading 'DD Num' format a8 
rem col tran_date heading 'DD Date' format a12
col b heading 'Br.Code & Name' format a20 trunc
rem col br_name heading 'Br.Name' format a20
col payee_name heading 'Payee Name' format a80
col dd_amt format b999,999,999,999.99
break on report

select dd_num, ddc.br_code||' '||br_name b, payee_name, dd_amt
from ddc, bct,sol
where sol.sol_id='&1'
and sol.br_code = bct.br_code
and 
      trunc(tran_date)=(select trunc(db_stat_date) from gct)
and   length(payee_name)>40 
and   ddc.br_code=bct.br_code
/

ttitle off
btitle off
set termout on
set feedback on
set verify on
set heading on
clear breaks
clear computes
spool out
set echo on
exit
