set verify off
set feedback off
set termout off
set serveroutput on size 1000000
set pagesize 0
set linesize 150
set trims on
--set timing on
spool nretran.txt

DECLARE
output_var		varchar2(30000);

CURSOR trancur IS 
SELECT 	hth.tran_id,
		hth.tran_date
FROM hth 
WHERE hth.init_sol_id = '&&1'
AND hth.tran_date = '&&2'
AND hth.del_flg <>'Y'	;

CURSOR trancur2 (trid htd.tran_id%type, trdt htd.tran_date%type) IS
SELECT	tran_id,
		tran_date,
		tran_amt,
		part_tran_srl_num,
		rpt_code,
		entry_user_id,
		pstd_user_id,
		vfd_user_id,
		to_char(entry_date,'DD-MM-YYYY hh24:mi:ss') entry_time,
		to_char(pstd_date,'DD-MM-YYYY hh24:mi:ss') pstd_time,
		to_char(vfd_date,'DD-MM-YYYY hh24:mi:ss') vfd_time,
		acid
FROM HTD
WHERE tran_id = trid
and tran_date = trdt
and part_tran_type = 'C'
and del_flg <> 'Y';

CURSOR gamcur(facid gam.acid%type) IS
SELECT 	foracid,
		schm_code,
		gl_sub_head_code,
		acid
FROM gam 
WHERE acid = facid
and (acct_cls_flg <>'Y' or acct_cls_date > '&2')
and acct_opn_date <= '&2'
and schm_code in (select schm_code from gsp where  NRE_SCHM_FLG='Y' and schm_type in ('CAA','SBA','ODA')
					and schm_code not in ('CANUO','CANRO','SBFNO','SBNRO'))
and schm_type in ('CAA','SBA','ODA');


BEGIN
header_blk :='sol_id|tran_date|acct_no|schm_code|tran_id|part_tran_srl_no|amt|rpt_code|maker_id|maker_time|verifier_id|verifier_time';

DBMS_OUTPUT.PUT_LINE(header_blk);

	FOR A IN trancur 
	LOOP
		FOR X IN trancur2(A.tran_id,A.tran_date)
		LOOP
		FOR B IN gamcur(X.acid)
		LOOP
	output_var := 
					'&&1'		||'|'||
					'&&2'		||'|'||
					B.foracid	||'|'||
					B.schm_code	||'|'||
					X.tran_id	||'|'||
					X.part_tran_srl_num	||'|'||
					X.tran_amt	||'|'||
					X.RPT_CODE	||'|'||
					X.entry_user_id	||'|'||
					X.entry_time		||'|'||
					X.vfd_user_id		||'|'||
					X.vfd_time
					;
		DBMS_OUTPUT.PUT_LINE(output_var);	
		END LOOP;
		END LOOP;
	END LOOP;

END;
/
spool off
