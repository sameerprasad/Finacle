create sequence tbaadm.icici_ngoc_seq increment by 1
       minvalue 1 maxvalue 99999999 cycle nocache
/
create public synonym icici_ngoc_seq for tbaadm.icici_ngoc_seq
/
grant select on tbaadm.icici_ngoc_seq to TBAGEN , tbacust , tbautil
/
