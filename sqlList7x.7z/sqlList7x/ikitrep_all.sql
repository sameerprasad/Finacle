rem Sources:  --

set serveroutput on size 1000000
set feedback off
set verify off
set linesize 500
set trims on
set termout off
spool ikit_&1..txt 
declare
date1 icici_kit.rcre_time%type;
solid1 sol.sol_id%type; 
card1 varchar2(3);

cursor c2 is
	select
			i.rcre_time, i.sol_id, card_type, i.foracid, g.schm_code
	from 
			icici_kit i , gam g
	where  
			i.sol_id        = solid1
			and i.rcre_time = date1	
			and i.foracid   = g.foracid
			and i.sol_id    = g.sol_id;
begin		
		solid1 := '&1';
		date1 := '&2';
		for c2rec in c2
		loop
			dbms_output.put_line(c2rec.rcre_time||'|'||c2rec.sol_id||'|'||c2rec.card_type||'|'||c2rec.foracid||'|'||c2rec.schm_code);
		end loop;
EXCEPTION
		WHEN OTHERS THEN
			DBMS_OUTPUT.PUT_LINE('Invalid'||'|'||' '||'|'||' '||'|'||' '||'|'||' ');
end;
/
spool off;
