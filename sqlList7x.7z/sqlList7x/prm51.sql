set feedback off
set verify off
col tran_particular format a20
accept solid prompt 'Please enter sol_id::'
spool prm51
select tran_id,foracid,tran_amt,part_tran_type,tran_particular,
decode(pstd_flg,'Y','POSTED','N','ENTERED') STATUS from dtd,gam where tran_date='31-03-2004'
and dtd.del_flg!='Y'
and dtd.acid=gam.acid
and tran_id in (select tran_id from dtd where tran_date='31-03-2004'
                and acid=(select acid from gam where sol_id='&solid'
                          and bacid='PRM51' and acct_crncy_code='INR'))
and tran_id in (select tran_id from dtd where tran_date='31-03-2004'
				and acid=(select acid from gam where sol_id='&solid'
						  and bacid='SLBOOKIN'))
/
spool off
exit
