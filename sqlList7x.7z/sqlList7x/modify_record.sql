---Sql to insert the record for the given School Id
SET SERVEROUTPUT ON SIZE 1000000
set head off echo off verify off feedback off
	Declare
	recpresent	varchar2(5) := 'Y';
	gam_rec		varchar2(5) := 'Y';	
	schlid		varchar2(16) := '&1';
	schlname	varchar2(150);
--	schlname	varchar2(150) := '&2';
	solid		gam.sol_id%type := '&3';
	acctnum		gam.foracid%type := '&4';
	loc_acctnum gam.foracid%type;
	loc_solid	gam.sol_id%type;
	loc_school_id school_acct_mast.school_id%type;
    loc_school_name school_acct_mast.school_name%type;
    loc_sol_id 		school_acct_mast.sol_id%type;
    loc_foracid 	school_acct_mast.foracid%type;


Begin
		Begin
		--{
			Select 'Y',school_id,school_name,sol_id,foracid
			  into recpresent,loc_school_id,loc_school_name,loc_sol_id,loc_foracid
		  	  from school_acct_mast
			 where school_id = schlid
			   and del_flg <> 'Y';
			Exception
			when no_data_found then
				recpresent := 'N';
				loc_school_id := NULL;
				loc_school_name := NULL;
				loc_sol_id := NULL;
				loc_foracid := NULL;

		--}
		End;
		if recpresent = 'N' then
			dbms_output.put_line('Record does not exist in the Database!');
		else
				if schlname = 'XXX'  then
					schlname := loc_school_name;
				end if;
				if solid = 'XXX' then
					solid := loc_sol_id;
				end if;
				if acctnum = 'XXX' then
					acctnum := loc_foracid;
				end if;

			Begin
			Select foracid,sol_id,'Y'
			  into loc_acctnum,loc_solid,gam_rec
			  from gam
			  where sol_id = solid
				and foracid = acctnum;
			Exception
			when no_data_found then
				loc_acctnum := NULL;
				loc_solid	:= NULL;
				gam_rec     := 'N';
			End;

			if gam_rec = 'N' then
				dbms_output.put_line('Account does not exists in Database!');
				dbms_output.put_line('Record'||'|'||loc_acctnum||'|'||loc_solid||'|'||gam_rec);
			else

				dbms_output.put_line('Modifying the data in the school_acct_mast table');
				update school_acct_mast  set school_name = replace('&2','^^',' '), sol_id = solid , foracid = acctnum
				 where school_id = schlid;
				dbms_output.put_line('Record Updated');
				commit;
			end if;
		end if;
--}
End;
/
