set serveroutput on size 1000000
set verify   off
set termout   off
set head off
set pages 0
set trims on
set feedback off
set echo off
set linesize 512
spool anyFail

DECLARE

CURSOR curStatus IS
SELECT	req_id ,nvl(to_char(REQ_TIME,'DD-MM-YYYY'),'NA') reqtime , 
		nvl(to_char(RES_TIME,'DD-MM-YYYY'),'NA') restime , 
		REMOTE_FORACID , LOCAL_FORACID , AMOUNT , nvl(CHEQUE_NO,'NA') CHEQUE_NO , 
		nvl(SUC_FAIL_FLG,'N')SUC_FAIL_FLG , nvl(RESCODE,'0')RESCODE , nvl(TRAN_ID,'NA')TRAN_ID
FROM	ICI_ANY_TRAN_DETAIL
WHERE	USERID in (select user_id  from upr where sol_id='&2' and del_flg <>'Y' and virtual_flg<>'Y')
--	substr(LOCAL_FORACID,1,4) = '&2'
AND		to_char(REQ_TIME,'DD-MM-YYYY') = '&1'
AND		((SUC_FAIL_FLG = 'N' and (RESCODE is NULL or RESCODE = '0'))
OR		SUC_FAIL_FLG is NULL)
ORDER 	by req_id;

BEGIN
    FOR statRec in curStatus
    LOOP
        EXIT WHEN curStatus%NOTFOUND;
        BEGIN
            dbms_output.put_line(statRec.req_id ||'|'|| statRec.reqtime ||'|'|| statRec.restime ||'|'||
            statRec.REMOTE_FORACID ||'|'|| statRec.LOCAL_FORACID ||'|'|| statRec.AMOUNT ||'|'||
            statRec.CHEQUE_NO ||'|'|| statRec.SUC_FAIL_FLG ||'|'|| statRec.rescode ||'|'|| statRec.TRAN_ID);
        END;
    END LOOP;

EXCEPTION
    when others then
		dbms_output.put_line('No record found|||||||||');
END;
/
spool off
