--##############################################################################################
--#                     File Name       : LCKKEY.sql
--#                     Author : Saravanan.S  (BBSSL)
--#                     Report : Locker Key Report
--#                     Date   :
--#                     Module  : LOCKER
--#                     Called Menu     : LOCKRPT
--##############################################################################################

SET SERVEROUTPUT ON;
SET SERVEROUTPUT ON SIZE 1000000;
set trimspool on;
SET VERIFY OFF;
set echo off
set feedback off
set embedded off
set lines 10000
set head off
set pages 0
spool LCKKEY.lst


SELECT 	LOCKER_NUM			||'|'||
	RACK_ID				||'|'||
	SIZE_OF_LOCKER			||'|'||
	LOCKER_TYPE			||'|'||
	KEY_NUM				||'|'||
	C_SVRSETVAR.VARIABLE_VALUE	||'|'||
	REMARKS
FROM WLCKM,C_SVRSETVAR
WHERE WLCKM.sol_id='&1'
AND WLCKM.del_flg != 'Y'
AND C_SVRSETVAR.VARIABLE_NAME = WLCKM.STATUS
AND C_SVRSETVAR.MODULE_NAME = 'LOCKER'
AND C_SVRSETVAR.SUB_MODULE_NAME = 'LCKM'
/
spool off
