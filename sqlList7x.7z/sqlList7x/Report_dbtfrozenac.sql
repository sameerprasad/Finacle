--------------------------------------------
--File Name   : Report_ClosedFrz.sql 
--Description : Debit Frozen Accounts 
--Author      : Priscilla & Vijay
--Date        : 02-06-2010
--------------------------------------------
set serveroutput on size 1000000
set head off
set pau off
set lines 1000
set echo off
set pages 0
set termout off
set verify off
set feedback off
spool Report_dbtfrozenac.lst

DECLARE

	v_solid            	clmt.sol_id%type:='&1';
	v_cust_id			cmg.cust_id%type;
	v_dt1				date:='&2';
	v_dt2				date:='&3';
	v_issue_date		date;
	v_last_attempt_dt  	date;
	v_oper_acnt         clmt.OPER_ACNT%type;
	v_RACK_ID          	wlckm.RACK_ID%type;
	v_LOCKER_NUM       	clnd.LOCKER_NUM%type;
	v_locker_type       wlckm.locker_type%type;	
	v_key1      	    wlckm.key_num%type;
	v_Prevkey      	    lcks.KEY_NUM1%type;
	v_status            wlckm.status%type; 
	v_acct_cls_flg		gam.acct_cls_flg%type;
	v_frez_code			gam.frez_code%type;
	v_cust_name			cmg.cust_name%type;
	v_reason			varchar2(30):='';

cursor c1(v_solid varchar2,v_dt1 date,v_dt2 date) is 
SELECT          clmt.SOL_ID,
                        clmt.CUST_ID,
                        substr(cmg.cust_name,1,40) cust_name,
                        wlckm.rack_id,
                        clmt.LOCKER_NUM,
                        clmt.ISSUE_DATE,
                        substr(clmt.LCHG_TIME,1,10),
                        ACCT_CLS_FLG,
                        FREZ_CODE
FROM        clmt,wlckm,cmg,gam
WHERE       clmt.locker_num=wlckm.locker_num
and         clmt.sol_id = wlckm.sol_id
and         cmg.cust_id = lpad(clmt.cust_id,9,' ')
and         gam.foracid = clmt.OPER_ACNT
AND     clmt.sol_id = v_solid
AND     clmt.due_date BETWEEN to_date(v_dt1,'dd-mm-yyyy') AND to_date(v_dt2,'dd-mm-yyyy')
and         clmt.OPER_ACNT is not null
and         floor(ABS((due_date - decode(renewal_date,'',(due_date+1),renewal_date))/365)) > 0
AND         CLMT.DEL_FLG != 'Y'
AND         WLCKM.DEL_FLG != 'Y'
AND         CLMT.ENTITY_CRE_FLG = 'Y'
AND         WLCKM.ENTITY_CRE_FLG = 'Y'
order by    6,5;

BEGIN
	for f1 in c1(v_solid,v_dt1,v_dt2)
	LOOP
			if (f1.ACCT_CLS_FLG='Y') THEN
			--{
				v_reason:='ACCOUNT CLOSED';
			else
				IF(f1.FREZ_CODE='D') THEN
				--{
				   v_reason:='ACCOUNT DEBIT FROZED';
				ELSE
				   v_reason:='';
				--}
				END IF;
			--}
			END IF; 
			BEGIN
			--{	
				SELECT NEXT_EXEC_DATE - 1 
				into v_last_attempt_dt 
				FROM BJS 
				WHERE JOB_ID = 'LCRNT' AND 
				SOL_ID = v_solid
				AND DEL_FLG !='Y';
			EXCEPTION WHEN NO_DATA_FOUND THEN
				v_last_attempt_dt := null;
			--}
			END;
		
		dbms_output.enable(buffer_size => NULL);
		dbms_output.put_line (	f1.sol_id           ||'|'||
				      			f1.CUST_ID          ||'|'||
       		                    f1.rack_id          ||'|'||	
                                f1.LOCKER_NUM       ||'|'||
				      			f1.cust_name	 	||'|'||
                                f1.ISSUE_DATE 		||'|'||
				      			v_reason			||'|'||
				      			v_last_attempt_dt
							 );
			
	END LOOP;
END;	   			
/
spool off
