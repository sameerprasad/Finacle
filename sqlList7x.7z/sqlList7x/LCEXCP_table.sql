Rem     This file will create LOCKER_EXCP_PARAM_TABLE
Rem     with the following characteristics.

Rem     Coded by : Mariappan (BBSSL)

Rem     Module  : LOCKER


Rem TABLE NAME: LOCKER_EXCP_PARAM_TABLE

Rem SYNONYM:    LCEXCP

drop table icici.LOCKER_EXCP_PARAM_TABLE
/
drop public synonym LCEXCP
/
create table icici.LOCKER_EXCP_PARAM_TABLE
( 
	AccPrd_EXCP_CODE	VARCHAR2(3),
	AccGap_EXCP_CODE	VARCHAR2(3),
	AccTime_EXCP_CODE	VARCHAR2(3),
	RentDue_EXCP_CODE	VARCHAR2(3),
	ChrgDue_EXCP_CODE	VARCHAR2(3),
	LockDue_EXCP_CODE	VARCHAR2(3),
	LockDep_EXCP_CODE	VARCHAR2(3),
	LessDep_EXCP_CODE	VARCHAR2(3),
	WaitList_EXCP_CODE	VARCHAR2(3),
	WaiveLetter_EXCP_CODE	VARCHAR2(3),
	LockDueFif_EXCP_CODE	VARCHAR2(3),
	MhAbsent_EXCP_CODE	VARCHAR2(3),
	RentWaive_EXCP_CODE	VARCHAR2(3),
	LCHG_USER_ID		VARCHAR2(15),
	LCHG_TIME		date,
	RCRE_USER_ID		VARCHAR2(15),
	RCRE_TIME		date
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
create public synonym LCEXCP for icici.LOCKER_EXCP_PARAM_TABLE
/
grant select, insert, update, delete on LCEXCP to tbagen
/
grant select on LCEXCP to tbacust
/
grant select on LCEXCP to tbautil
/
grant all on LCEXCP to tbaadm
/
