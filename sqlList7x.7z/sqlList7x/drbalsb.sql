accept solid prompt 'ENTER FOUR DIGIT SOL ID OF REPORT BRANCH : '
set echo off
set verify off
set termout off
set feedback off
set pages 72
set lines 80
column BAL format 99,99,99,999.99
col name format a35 trunc
ttitle center 'LIST OF SB ACCOUNTS WITH DEBIT BALANCES ' skip 2
spool &solid.drbalsb
select foracid num,acct_name name,(clr_bal_amt+un_clr_bal_amt) BAL from gam
where acct_cls_flg = 'N'
and (clr_bal_amt+un_clr_bal_amt) < 0
and gl_sub_head_code between '08010' and '08050'
and gam.sol_id = '&solid'
/
spool off
exit
