--------------------------------------------
--File Name   : Report_rentpremium.sql
--Description : Locker Rent Premium Report
--Author      : Priscilla & Vijay
--Date        : 01-06-2010
------------------------------------------

set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_rentpremium.lst

DECLARE

lv_solid    gam.sol_id%type :='&1';
lv_date		date :='&2';

CURSOR c1 IS
SELECT  
	WLPM.SOL_ID,
	WLCKM.RACK_ID,
	WLPM.LOCKER_TYPE,
	WLPM.LOCKER_NUM,
	WLPM.CUST_ID,
	substr(CMG.CUST_NAME,1,25) CUST_NAME,
	CLMT.RENT_AMT,
	WLPM.PREMIUM_METHOD,
	WLPM.PREMIUM_AMOUNT,
	WLPM.REASON,
	WLPM.REMARKS
FROM 
	CLMT,WLPM,WLCKM,CMG
WHERE 
	CLMT.LOCKER_NUM = WLPM.LOCKER_NUM
AND	CLMT.LOCKER_NUM = WLCKM.LOCKER_NUM
AND WLPM.CUST_ID = CMG.CUST_ID
AND WLPM.CUST_ID = CLMT.CUST_ID
AND	CLMT.SOL_ID = WLPM.SOL_ID
AND	WLPM.SOL_ID= lv_solid
AND	PREMIUM_AMOUNT IS NOT NULL
AND	lv_date BETWEEN PERIOD_FROM AND PERIOD_TO
and	CLMT.DEL_FLG != 'Y'
AND WLPM.DEL_FLG != 'Y'
AND WLCKM.DEL_FLG != 'Y'
AND CLMT.ENTITY_CRE_FLG = 'Y'
AND WLPM.ENTITY_CRE_FLG = 'Y'
AND WLCKM.ENTITY_CRE_FLG = 'Y'
ORDER BY LOCKER_NUM;

BEGIN

    for f1 in c1

    loop
      
dbms_output.put_line( 	f1.sol_id         ||'|'||
		      			f1.rack_id        ||'|'||
		      			f1.locker_type    ||'|'||
		      			f1.locker_num     ||'|'||
		      			f1.cust_id		  ||'|'||
						f1.cust_name	  ||'|'||
		      			f1.RENT_AMT       ||'|'||
                      	f1.PREMIUM_METHOD ||'|'||
                      	f1.PREMIUM_AMOUNT ||'|'||
		      			f1.REASON         ||'|'|| 
		      			f1.REMARKS
					);
	       	     
   end loop; 
END;
/
spool off

