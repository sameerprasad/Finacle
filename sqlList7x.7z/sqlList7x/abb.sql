!/bin/rm abb.txt
rem Script for Printing DEPOSIT ACCOUNTS WITH AUTO RENEWAL/SAFE CUST. FLAG 
REM AUTHOR  M K JAIN , MAMANGER (SYSTEMS)
set feedback off
set verify off
set termout off
set echo off
set trimspool on
set lines 400
alter session set nls_date_format = 'DD-MON-YYYY';
set serveroutput on size 1000000
spool abb.txt
DECLARE
dummy varchar2(3);
facid  gam.foracid%type;
gacid  gam.acid%type;
Name varchar2(80);
limit number(17,2);
dp number(17,2);
trandate date;
balance number(17,2);
valbalance varchar2(17);

CURSOR GAMMAIN IS

select foracid,acid,acct_name,drwng_power,sanct_lim
from gam
where foracid in (
'000205001002',
'000305000520',
'000705001225',
'000204001002',
'000405002329',
'000605000844',
'000605000846',
'000605000847',
'000605000848',
'000605000849',
'000705001201',
'000705001202',
'000705001200',
'000751000109',
'000905000937',
'000905000928',
'001105000381',
'001105000382',
'002705000403',
'001305000354',
'001205000791',
'005505000085',
'000305000522',
'005905000158',
'008905000028',
'004205000169',
'000805000791',
'006105000018',
'000205001003',
'000205001004',
'000205001005',
'000205001006',
'000205001007',
'000205001008',
'000205001009',
'000205001010',
'000205001011',
'000205001012',
'000205001013',
'008305000621',
'000505000742',
'002705000755',
'008305000890',
'623905025136');
BEGIN
open gammain;
begin
loop
BEGIN
Fetch gammain into facid,gacid,name,limit,dp;
exit when gammain%notfound;
END;
BEGIN
select eod_date,tran_date_bal,value_date_bal
	into trandate,balance,valbalance
from eab
where eab.acid = gacid
and eab.eod_date = (select max(eod_Date) from eab f
			where f.acid = gacid
			and f.eod_Date <= '&1');
EXCEPTION When no_data_found then
trandate := '&1';
balance := 0;
valbalance := 0;
END;
DBMS_OUTPUT.PUT_LINE(facid||'|'||name||'|'||limit||'|'||dp||'|'||trandate||'|'||'&1'||'|'||balance||'|'||valbalance);
END LOOP;
end;
close gammain;
END;
/
spool off
exit
