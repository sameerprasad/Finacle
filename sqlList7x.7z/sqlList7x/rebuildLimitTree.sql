SET SERVEROUTPUT ON SIZE 100000
set numformat 999999999999999.99
set pages 65
set lines 80

-- Creation Of Temporary LLT table for Security
-- CREATE TABLE TEMP_LLT AS SELECT * FROM LLT
--/
--------------------------------------------------------------------------------
-- THIS SCRIPT SHOULD BE RUN ONLY AFTER running testrebuildLimitTree.sql
--------------------------------------------------------------------------------
-- This is the upgrade script for the LLT table to set the values of
-- contingent_liability  utilised_limit,liab to their correct values. 
-- BG's , - Contingent Liabillty is increased only for bg_status ( 'A'- Add  , 'E'
-- Extend 'O'  Expired and records with 'G' Mark Invoke). For claculating
-- Utilised limit all ther BGs except Mark Pend BG's are considered.
-- 
-- DC's - For utlised limits The available value + reInstated amount is
-- considered
-- For Contingent liablity it is availalbe value + re Instated amount - bill
--fruct - no bill fruct - bill util - no bill util and records only which 
--are not deleted or closed are considerd
-- 
-- Accounts - For utilised limit , for only single tran limits , it is
--calculated from CTD based on the part trans on that account
--------------------------------------------------------------------------------
--  Declare variables
--------------------------------------------------------------------------------
  spool OldLlt;
  SELECT limit_prefix , limit_suffix,liab,contingent_liab,utilised_limit
  FROM LLT;
  spool off;

DECLARE
recCount					NUMBER;
posToNeg					NUMBER;
loc_count					NUMBER;
message						VARCHAR(200);
locHomeCrncyCode			FCT.home_crncy_code%TYPE;

locLltLiab					LLT.liab%TYPE;
locLltContingentLiab		LLT.contingent_liab%TYPE;
locLltSecuredLiab			LLT.secured_liab%TYPE;
locLltUtilisedLimit			LLT.utilised_limit%TYPE;
locLltSingleTranFlg			LLT.lc_single_tran_flg%TYPE;
locLltParLimSufix			LLT.parent_limit_suffix%TYPE;
locLltParLimPrefix			LLT.parent_limit_prefix%TYPE;
locLltLimSufix				LLT.limit_suffix%TYPE;
locLltLimPrefix				LLT.limit_prefix%TYPE;

locSBgAmt					BGM.bg_amt%TYPE;
locSBgCrncyCode				BGM.crncy_code%TYPE;
locSBgRateCode				BGM.rate_code%TYPE;
locSBgRate					BGM.rate%TYPE;
locSBgStatus				BGM.bg_status%TYPE;
locSBgSolid					BGM.sol_id%TYPE;

locTempContLiab				LLT.contingent_liab%TYPE;
locTotContLiab				LLT.contingent_liab%TYPE;
locTotUtilisedLimit			LLT.utilised_limit%TYPE;
locBgTotUtilisedLimit		LLT.utilised_limit%TYPE;
locDcTotUtilisedLim			LLT.utilised_limit%TYPE;
locDcTempUtilisedLim		LLT.utilised_limit%TYPE;
locBgTotContLiab			LLT.contingent_liab%TYPE;
locDcTotContLiab			LLT.contingent_liab%TYPE;
locFxdCrncyUnits			RTM.fxd_crncy_units%TYPE;
locPrintAmt					LLT.contingent_liab%TYPE;

locDcCurrentValue			DCMM.current_value%TYPE;
locDcCrncyCode				DCMM.actl_crncy_code%TYPE;
locDcRateCode				DCMM.ratecode%TYPE;
locDcRate					DCMM.rate%TYPE;
locDcSolid					DCMM.sol_id%TYPE;
locDcDateClosed				DCMM.date_clsd%TYPE;
locDcB2kId					DCMM.dc_b2kid%TYPE;
locDcRefNum					DCMM.dc_ref_num%TYPE;
locDcDelFlg					DCMM.del_flg%TYPE;

locDCUtilisedAmt			LLT.utilised_limit%TYPE;
locReinstAmt				LLT.utilised_limit%TYPE;

locAccAcid					GAM.acid%TYPE;
locAccForacid				GAM.foracid%TYPE;

locTempLiab					LLT.contingent_liab%TYPE;
locAcTotLiab				LLT.contingent_liab%TYPE;
locTempUtilisedLim			LLT.utilised_limit%TYPE;
locAcTotUtilisedLim			LLT.utilised_limit%TYPE;

locTranAmt					CTD.tran_amt%TYPE;
locPrevTotTranAmt			CTD.tran_amt%TYPE;
locTotTranAmt				CTD.tran_amt%TYPE;
locPartTranType				CTD.part_tran_type%TYPE;


CURSOR LLT_Record IS
	SELECT
		liab,contingent_liab,secured_liab,utilised_limit,lc_single_tran_flg ,
		parent_limit_prefix, parent_limit_suffix, limit_prefix, limit_suffix
	FROM LLT
	WHERE   
		ENTITY_CRE_FLG = 'Y' AND del_flg != 'Y';
	
CURSOR BG_RECORD IS
	SELECT
		bg_amt,crncy_code ,rate_code , rate, bg_status,sol_id
		FROM BGM
	WHERE 
		limit_prefix = locLltLimPrefix AND
		limit_suffix = locLltLimSufix  AND
		bg_status not in ('D');
-- Except NO PEND BG's 'D' Select all BG's

CURSOR DC_RECORD IS 
	SELECT 
		current_value,actl_crncy_code ,ratecode , rate, date_clsd,sol_id,
		dc_b2kid,dc_ref_num ,del_flg
	FROM DCMM
	WHERE 
		our_party_limit_prefix = locLltLimPrefix AND
		our_party_limit_suffix = locLltLimSufix  AND
		entity_cre_flg = 'Y';


CURSOR ACCOUNT_RECORD IS
		SELECT 
		acid,foracid from GAM where 
		limit_prefix = locLltLimPrefix AND
		limit_suffix = locLltLimSufix ;
	
CURSOR AC_TRAN_RECORD IS
	SELECT
		tran_amt,part_tran_type
		FROM CTD
	WHERE 
		CTD.pstd_flg = 'Y' AND
		CTD.del_flg != 'Y' AND
		CTD.acid = locAccAcid
		order by CTD.pstd_date;

--------------------------------------------------------------------------------

BEGIN 


	UPDATE LLT
	SET liab =0 ,contingent_liab = 0 ,secured_liab =0,utilised_limit =0; 
-- FIRST Make The liabilities Zero

	IF (NOT LLT_Record%ISOPEN) THEN
	    OPEN LLT_Record;
	END IF;

	recCount := 0;
	locTempContLiab := 0;
	locTotContLiab := 0;
	locTotUtilisedLimit := 0;
	locDcTotContLiab :=0;
	locBgTotContLiab:= 0;
	locDcTotUtilisedLim:=0;
	locBgTotUtilisedLimit:=0;
	locAcTotUtilisedLim :=0;
	locTotContLiab := 0;
	locTotUtilisedLimit:= 0;
	locAcTotLiab:= 0;
	locTempUtilisedLim := 0;


	LOOP -- {
		FETCH LLT_Record 
		INTO   
				locLltLiab,
				locLltContingentLiab,
				locLltSecuredLiab, 
				locLltUtilisedLimit, 
				locLltSingleTranFlg,
				locLltParLimPrefix,
				locLltParLimSufix,
				locLltLimPrefix,
				locLltLimSufix;

		IF (LLT_Record%NOTFOUND) THEN -- {
			CLOSE LLT_Record;
			  COMMIT;
			DBMS_OUTPUT.PUT_LINE ('UPDATE RUN SUCCESSFULL') ;
			EXIT;
		ELSE 
			recCount := recCount + 1;
		END IF; -- }
		--DBMS_OUTPUT.PUT_LINE(recCount);
		
		IF (NOT BG_RECORD%ISOPEN) THEN -- {
			OPEN BG_RECORD;
		END IF; --}

-- Calculation Logic based On Bank Gurantees Starts Here

		LOOP -- {
			FETCH BG_RECORD
			INTO
				locSBgAmt,
				locSBgCrncyCode,
				locSBgRateCode,
				locSBgRate,
				locSBgStatus,
				locSBgSolid;
			IF (BG_RECORD%NOTFOUND) THEN -- {
				CLOSE BG_RECORD;
				EXIT;
			END IF; -- }
	-- This Part is to convert the amount in different Cuurrencies To Home
	-- Currency	, As the limits are in Home Currency

			SELECT home_crncy_code
			INTO locHomeCrncyCode
			FROM FCT
			WHERE FCT.sol_id = locSBgSolid;

			IF (locHomeCrncyCode = locSBgCrncyCode) THEN -- {
				locTempContLiab := locSBgAmt;
			ELSE
				message:='NO DATA IN RTM TABLE FOR : '||locSBgCrncyCode||'-'||locHomeCrncyCode||'/'||locSBgRateCode;
				SELECT fxd_crncy_units
				INTO locFxdCrncyUnits
				FROM RTM
				WHERE fxd_crncy_code = locSBgCrncyCode 
				AND ratecode = locSBgRateCode
				AND var_crncy_code = locHomeCrncyCode;

				locTempContLiab := ROUND((locSBgAmt*(locSBgRate/locFxdCrncyUnits)));
			END IF; -- }

			locBgTotUtilisedLimit := locBgTotUtilisedLimit + locTempContLiab;

			IF ((locSBGstatus = 'A') OR (locSBGstatus = 'E') OR (locSBGstatus = 'O') OR (locSBGstatus = 'G')) THEN
				locBgTotContLiab := locBgTotContLiab + locTempContLiab;
	-- Consider contingent liability only if the status is ISSUED, EXTENDED 
	-- EXPIRED , MARK INVOKED
			END IF;

			locTempContLiab:=0;
		END LOOP; -- } 


-- Calculation Logic Based On LC's Starts Here 

		IF (NOT DC_RECORD%ISOPEN) THEN -- {
			OPEN DC_RECORD;
		END IF; --}
		LOOP -- {
			FETCH DC_RECORD
			INTO
				locDcCurrentValue,
				locDcCrncyCode,
				locDcRateCode,
				locDcRate,
				locDcDateClosed,
				locDcSolid,
				locDcB2kId,
				locDcRefNum,
				locDcDelFlg;
			IF (DC_RECORD%NOTFOUND) THEN -- {
				CLOSE DC_RECORD;
				EXIT;
			END IF; -- }
		locDcCurrentValue:=0;

		SELECT 
		   (dc_bill_util_amt + dc_nobill_util_amt
		   		+ dc_bill_fruct_amt + dc_nobill_fruct_amt),
		   (current_value * (1 + (actl_tolerance_pcnt/100))
		   + interest_addtnl_amt - advance_value) + dc_reinst_amt
		into locDCUtilisedAmt, locDcTempUtilisedLim
		FROM DCMM
		where sol_id = locDcSolId
		  and dc_ref_num = locDcRefNum;

		IF ((locDcDelFlg != 'Y') AND (locDcDateClosed IS NULL)) THEN
			locTempContLiab := (locDcTempUtilisedLim - locDCUtilisedAmt);
		-- For contingent liab consider current value + reinstated Value - Bill
		-- utlised and non bill utlised amount
		END IF;

	-- This Part is to convert the amount in different Currencies To Home
	-- Currency	, As the limits are in Home Currency

			SELECT home_crncy_code
			INTO locHomeCrncyCode
			FROM FCT
			WHERE FCT.sol_id = locDcSolid;

			IF (locHomeCrncyCode = locDcCrncyCode) THEN -- {

				locDcTotUtilisedLim := locDcTotUtilisedLim + locDcTempUtilisedLim;
				locDcTotContLiab := locDcTotContLiab + locTempContLiab;
				
			ELSE
				message:='NO DATA IN RTM TABLE FOR : '||locDcCrncyCode||'-'||locHomeCrncyCode||'/'||locDcRateCode;
				SELECT fxd_crncy_units
				INTO locFxdCrncyUnits
				FROM RTM
				WHERE fxd_crncy_code = locDcCrncyCode 
				AND ratecode = locDcRateCode
				AND var_crncy_code = locHomeCrncyCode;
				
				locTempContLiab := ROUND(((locTempContLiab) * (locDcRate/locFxdCrncyUnits)));
				locDcTempUtilisedLim := ROUND(((locDcTempUtilisedLim) * (locDcRate/locFxdCrncyUnits)));
				locDcTotUtilisedLim := locDcTotUtilisedLim + locDcTempUtilisedLim;
				locDcTotContLiab := locDcTotContLiab + locTempContLiab;

			END IF; -- }
			locDcTempUtilisedLim := 0;
			locTempContLiab := 0;

		END LOOP; -- } 

 -- Calculation Logic Due to Accounts Starts Here 

		IF (NOT ACCOUNT_RECORD%ISOPEN) THEN -- {
			OPEN ACCOUNT_RECORD;
		END IF; --}

		LOOP -- {
			FETCH ACCOUNT_RECORD
			INTO
				locAccAcid,
				locAccForacid;
			IF (ACCOUNT_RECORD%NOTFOUND) THEN -- {
				CLOSE ACCOUNT_RECORD;
				EXIT;
			END IF; -- }

			-- ENTER CTD LOOP For accounts only For Single Tran Limit
			IF (locLltSingleTranFlg = 'Y') THEN -- {
				IF(NOT AC_TRAN_RECORD%ISOPEN) THEN -- {
					OPEN AC_TRAN_RECORD;
				END IF; -- }

				locPrevTotTranAmt := 0;
				posToNeg := 0;

				LOOP -- {
					FETCH AC_TRAN_RECORD
					INTO
						locTranAmt,
						locPartTranType;
					IF (AC_TRAN_RECORD%NOTFOUND) THEN -- {
						CLOSE AC_TRAN_RECORD;
						EXIT;
					END IF; -- }
					IF (locPartTranType = 'C') THEN -- {
						locTotTranAmt := locTotTranAmt + locTranAmt;
					ELSE 
						locTotTranAmt := locTotTranAmt - locTranAmt;
					END IF; -- }

					IF (locTotTranAmt < locPrevTotTranAmt) THEN -- {
						IF (posToNeg = 1) THEN
							locTempUtilisedLim :=locTempUtilisedLim + (-1 * locTotTranAmt);
						ELSE
							locTempUtilisedLim := locTempUtilisedLim + locTranAmt;
						END IF;
					END IF; -- }

					locPrevTotTranAmt := locTotTranAmt;

					IF (locPrevTotTranAmt > 0) THEN -- {
						posToNeg := 1;
						locPrevTotTranAmt := 0;
					ELSE 
						posToNeg:= 0;
					END IF; -- }

				END LOOP; -- }
			END IF; -- }

			locTotTranAmt:=0;
			locPrevTotTranAmt:=0;

			locAcTotUtilisedLim := locAcTotUtilisedLim + locTempUtilisedLim;
			locTempLiab :=0;

			SELECT  (clr_bal_amt + un_clr_bal_amt) 
			INTO 
				locTempLiab FROM GAM WHERE 
				GAM.acid = locAccAcid; 


			IF (locTempLiab < 0) THEN -- {
				locAcTotLiab := locAcTotLiab + (-1 * locTempLiab);
			END IF; -- }

			locTempUtilisedLim := 0;
			locTempLiab := 0;

		END LOOP; -- } 

		locTotContLiab := locDcTotContLiab + locBgTotContLiab;
	-- Contingent Liability due to BG's and DC's 

		locTotUtilisedLimit:= locDcTotUtilisedLim + locBgTotUtilisedLimit + locAcTotUtilisedLim;
	-- Utlised Libility due to BG's DC's and Accounts


		locDcTotContLiab :=0;
		locBgTotContLiab:= 0;
		locDcTotUtilisedLim:=0;
		locBgTotUtilisedLimit:=0;
		locAcTotUtilisedLim :=0;

-- Actual Updation OF Limits is In this Loop

		LOOP -- {
		-- Upadtion For Contingent Liabilty


			UPDATE LLT
			SET contingent_liab = contingent_liab + locTotContLiab
			WHERE 
				limit_prefix = locLltLimprefix AND
				limit_suffix = locLltLimSufix ;



		-- Updation For Utilised Limit


			UPDATE LLT
			SET utilised_limit = utilised_limit + locTotUtilisedLimit
			WHERE 
				limit_prefix = locLltLimprefix AND
				limit_suffix = locLltLimSufix AND
				lc_single_tran_flg = 'Y';

		-- Updation for Libaility
			UPDATE LLT
			SET liab = liab + locAcTotLiab
			WHERE 
				limit_prefix = locLltLimprefix AND
				limit_suffix = locLltLimSufix ;


			SELECT  count(*)
			INTO loc_count
			FROM LLT
			WHERE 
				limit_prefix = locLltLimPrefix AND
				limit_suffix = locLltLimSufix AND
				parent_limit_prefix IS NOT NULL;

			IF (loc_count = 0) THEN
				EXIT;
			END IF;
			
			message:='NO DATA IN LLT TABLE FOR LIMIT NODE : '||locLltLimPrefix||'/'||locLltLimSufix;
			SELECT  parent_limit_prefix, parent_limit_suffix
			INTO locLltLimPrefix, locLltLimSufix
			FROM LLT
			WHERE 
				limit_prefix = locLltLimPrefix AND
				limit_suffix = locLltLimSufix ;

		END LOOP; -- }
	-- Reset the local variables to Zero
		locTotContLiab := 0;
		locTempContLiab := 0;
		locTotUtilisedLimit:= 0;
		locAcTotLiab:= 0;

		IF (recCount = 100) THEN
			  COMMIT;
			recCount := 0;
		END IF;
	
	END LOOP; -- }

	EXCEPTION
		WHEN NO_DATA_FOUND THEN 
		DBMS_OUTPUT.PUT_LINE(message);
		DBMS_OUTPUT.PUT_LINE('USE OLD_LLT TABLE TO RESTORE LLT TABLE, FIX THE PROBLEM AND RUN THIS SCRIPT AGAIN');


END ;
/
 spool NewLlt;
SELECT limit_prefix , limit_suffix,liab,contingent_liab,utilised_limit
FROM LLT;
 spool off;
-------------------------  END OF SOURCE    ----------------------------
