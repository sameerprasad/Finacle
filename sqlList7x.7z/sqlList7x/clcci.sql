drop table icici.cust_locker_change_custid
/
drop public synonym clcci
/
create table icici.cust_locker_change_custid
(
sol_id 		varchar(8),
locker_num  	varchar(12),
old_cust_id 	varchar(9),
new_cust_id 	varchar(9),
hirer_type 	char(3),
entity_cre_flg  char(1),
LCHG_USER_ID    VARCHAR2(15),
LCHG_TIME       date,
RCRE_USER_ID    VARCHAR2(15),
RCRE_TIME       date,
del_flg 	char(1),
cust_id		varchar(9)
)
/
CREATE INDEX IDX_cust_locker_change_custid ON ICICI.cust_locker_change_custid(SOL_ID,cust_id,old_cust_id)
/
create public synonym clcci for icici.cust_locker_change_custid
/
grant select,insert,update,delete on clcci to tbagen
/
grant all on clcci to tbaadm
/
grant select on clcci to tbacust
/
grant select on clcci to tbautil
/
