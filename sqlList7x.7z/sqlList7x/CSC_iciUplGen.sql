set pagesize 0
set linesize 1000
set trimspool on
set feedback off
set termout off
set echo off
set verify off
set serveroutput on size 999999 escape on
spool genuplcarm.dat 

DECLARE
--{
	funcmode varchar(1);
	cat CMG.chrg_level_code%TYPE;
	event PTT.event_type%TYPE;
	base char(1);

	CURSOR ADDGEN IS
	SELECT RULE_ID,EVENT_TYPE,EVENT_ID,PTRAN_BUS_TYPE,CHRG_BASE FROM ICI_RMM
	WHERE EVENT_TYPE = event AND CHRG_BASE = base AND DEL_FLG = 'N' AND
	ENTITY_CRE_FLG = 'Y' ORDER BY EVENT_ID;

	CURSOR MODIFYGEN IS
	SELECT RULE_ID,EVENT_TYPE,EVENT_ID,PTRAN_BUS_TYPE,CHRG_BASE,CHRG_CODE FROM ICI_CARM
	WHERE CAT_CODE = cat AND EVENT_TYPE = event AND CHRG_BASE = base AND 
	DEL_FLG = 'N' AND ENTITY_CRE_FLG = 'Y' ORDER BY EVENT_ID;
--}

BEGIN
--{
	funcmode:='&1';
	cat:='&2';
	event:='&3';
	base:='&4';
	DBMS_OUTPUT.PUT_LINE('CARM'||'|');
	if(funcmode = 'A') then
	--{
		FOR ADD IN ADDGEN
		LOOP
		--{
			DBMS_OUTPUT.PUT_LINE(cat||'|'||TRIM(ADD.RULE_ID)||'|'||TRIM(ADD.EVENT_TYPE)||'|'||TRIM(ADD.EVENT_ID)||'|'||TRIM(ADD.PTRAN_BUS_TYPE)||'|'||TRIM(ADD.CHRG_BASE)||'|');
		--}
		END LOOP;
	--}
	END IF;

	if(funcmode = 'M') then
	--{
        FOR MODIFY IN MODIFYGEN
       LOOP
        --{
	DBMS_OUTPUT.PUT_LINE(cat||'|'||TRIM(MODIFY.RULE_ID)||'|'||TRIM(MODIFY.EVENT_TYPE)||'|'||TRIM(MODIFY.EVENT_ID)||'|'||TRIM(MODIFY.PTRAN_BUS_TYPE)||'|'||TRIM(MODIFY.CHRG_BASE)||'|'||TRIM(MODIFY.CHRG_CODE));
		--}
		END LOOP;
	--}
	END IF;
	exception when no_data_found then null;
END;
/
spool off

host chmod 755 GEN_UPL.lst
exit
/

