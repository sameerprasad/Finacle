set serveroutput on size 1000000
set feedback off
set verify off
set linesize 500
set trims on
set trims on
accept solid prompt "Enter Sol_id    "
spool nom_daily
DECLARE
nom_reg_num                         icici_cndt_daily.nom_reg_num%TYPE;
cust_id                             icici_cndt_daily.cust_id%TYPE;
nom_name                            icici_cndt_daily.nom_name%TYPE;
nom_reltn_code                      icici_cndt_daily.nom_reltn_code%TYPE;
nom_date_of_birth                   icici_cndt_daily.nom_date_of_birth%TYPE;
cust_name                           cmg.cust_name%TYPE;
cst_id                              icici_cift.cust_id%TYPE;
reltn_desc                          rct.ref_desc%TYPE;
rcr_time                            icici_cndt.rcre_time%TYPE;
lch_time                            icici_cndt.lchg_time%TYPE;
today                               varchar2(15);
flg									number(1);
error								varchar2(100);
sol_id                               icici_cift.home_sol_id%TYPE;
sol_nm                               sol.sol_desc%TYPE;
CURSOR nom_daily IS SELECT 				cust_id,nom_reg_num,nom_name,
                                        nom_reltn_code,nom_date_of_birth,
                                        nom_minor_flg
					 FROM ICICI_CNDT_DAILY; 

BEGIN --{
--fmode := 'w';
        begin
           select sol_id,sol_desc into sol_id,sol_nm from sol where sol_id = '&solid';
			EXCEPTION
				WHEN OTHERS THEN
                    flg:=1;
	                goto avr1;	
        end;
        begin
            select to_char(sysdate,'DD-MM-YYYY') into today from dual;
        end;
        dbms_output.put_line('0000000'||'|'||sol_id||'|'||sol_nm||'|'||'D'||'|'||' '||'|'||' '||'|'||' '||'|'||' '||'|'||' ');
	FOR nom_daily_rec in nom_daily 
	LOOP --{
            flg:=0;
        BEGIN
			SELECT  ref_desc    
			INTO 	reltn_desc 
			FROM 	RCT 
            WHERE   ref_rec_type='04' 
            AND ref_code = nom_daily_rec.nom_reltn_code;
			EXCEPTION
				WHEN OTHERS THEN
                    flg:=1;
                    error:='Relation Ship Code Not Found';
	                goto avr2;	
        END;
		BEGIN
			SELECT 	home_sol_id
            INTO    sol_id
			FROM    icici_cift
			WHERE cust_id  = nom_daily_rec.cust_id;

			EXCEPTION
				WHEN OTHERS THEN
                    flg:=1;
                    error:='Customer does not refelect in cift file';
	                goto avr2;	
		END;
        begin
			SELECT 	cust_name
            INTO    cust_name
			FROM    cmg
			WHERE cust_id  = nom_daily_rec.cust_id;

			EXCEPTION
				WHEN OTHERS THEN
                    flg:=1;
                    error:='Customer record not found in cmg';
	                goto avr2;	
         END;
        begin
			SELECT 	rcre_time,lchg_time
            INTO    rcr_time,lch_time
			FROM    icici_cndt
			WHERE cust_id  = nom_daily_rec.cust_id;

			EXCEPTION
				WHEN OTHERS THEN
                    flg:=1;
                    error:='Customer record not found in cndt';
	                goto avr2;	
         END;
if(sol_id = '&solid') then
   flg:=0;
else
   flg:=1;
end if;	
<<avr2>>
IF (flg < 1) THEN
		dbms_output.put_line(to_char(lch_time,'YYYYMMDD')||'|'||lch_time||'|'||rpad(nom_daily_rec.nom_reg_num,10,' ')||'|'||rpad(nom_daily_rec.cust_id,10)||'|'||rpad(cust_name,40)||'|'||rpad(nom_daily_rec.nom_name,40)||'|'||rpad(reltn_desc,15)||'|'||nom_daily_rec.nom_date_of_birth||'|'||rcr_time);
END IF ;
flg:=0;
END LOOP; 
<<avr1>>
flg:=0;
END;  
/
spool off
quit

