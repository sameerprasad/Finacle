prompt 'Creation of Menu option PPFCFG :'

select 'Adding the new menu option PPFCFG...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'PPFCFG';
end;
/
delete mod where mop_id = 'PPFCFG';
set escape \

insert into mod values ('PPFCFG','Y','N','U','http://$W/finbranch/','custom/PPFCONFIG.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','120','999','','999','999','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'PPFCFG';
insert into oat values ('PPFCFG', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
insert into oat values ('PPFCFG', 'DB', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
insert into oat values ('PPFCFG', 'OP', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);


delete mod_txt where mop_id = 'PPFCFG';

insert into mod_txt values ('PPFCFG', 'INFENG', 'PPFCFG', 'PPF Account Closure', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

insert into ppfcfg values('70000','12','500','3','6','7','2','50','60','1','1','5','25','SBPPY',
'0','9','2205001','50','TRG1','09-09-2011','TRG1','09-09-2011'); 

commit
/
