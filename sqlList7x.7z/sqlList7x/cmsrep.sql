set pages 0
set head off
set term off
set echo off
set verify off
set feed off
set pause off
set lines 300
set trims on

spool cmsrep

Select	'A'										||'|'|| 
		eod_date								||'|'||
		A.foracid								||'|'||
		A.acct_name								||'|'||
		NULL									||'|'||
		NULL									||'|'||
		NULL									||'|'||
		0										||'|'||
		0										||'|'||
		tran_date_bal 							||'|'||
		'&2'									||'|'||
		'&3'			
from EAB, GAM A
where 	EAB.acid = A.acid
and	A.foracid = upper('&1')
and	EAB.eod_date <=     (to_date('&2')-1)
and	EAB.end_eod_date >= (to_date('&2')-1) 
/

Select  'B'										||'|'||
		C.tran_date								||'|'||
		A.foracid								||'|'||
		A.acct_name								||'|'||
		B.init_sol_id							||'|'||
		C.instrmnt_num							||'|'||
		C.tran_particular						||'|'||
		decode(C.part_tran_type,'D',C.tran_amt)	||'|'||
		decode(C.part_tran_type,'C',C.tran_amt)	||'|'||
		0										||'|'||
		'&2'									||'|'||
		'&3'
from GAM A, DTD C, DTH B
where 	A.acid = C.acid
and	C.tran_date = B.tran_date
and	C.tran_id = B.tran_id
and	A.foracid = upper('&1')
and	C.tran_date between '&2' and '&3'
and	C.pstd_flg = 'Y'
and	C.del_flg <> 'Y'
and	B.del_flg <> 'Y'
/

Select  'B'                                     ||'|'||
        C.tran_date                             ||'|'||
		A.foracid								||'|'||
		A.acct_name								||'|'||
        B.init_sol_id                           ||'|'||
		C.instrmnt_num							||'|'||
        C.tran_particular                       ||'|'||
        decode(C.part_tran_type,'D',C.tran_amt) ||'|'||
        decode(C.part_tran_type,'C',C.tran_amt)	||'|'||
		0										||'|'||
		'&2'									||'|'||
		'&3'
from GAM A, CTD C, CTH B
where   A.acid = C.acid
and     C.tran_date = B.tran_date
and     C.tran_id = B.tran_id
and		A.foracid = upper('&1')
and     C.tran_date between '&2' and '&3'
and     C.pstd_flg = 'Y'
and     C.del_flg <> 'Y'
and     B.del_flg <> 'Y'
/

spool off
exit
