-- Minor Debit Freeze Report
set serveroutput on size 1000000
set linesize 200
set pagesize 10000
set verify off
set trimspool on
set feedback off
set termout off
set echo off

spool &1
declare
cursor mincur1 is
	select d.sol_id, foracid, substr(acct_name,1,30) acname, 
	       to_char(minor_attain_major_date,'dd-mm-yyyy') major_date, 
		frez_code, frez_reason_code,
	       to_char(d.lchg_time,'dd-mm-yyyy')  last_change_dt, e.cust_id, 
		substr(cust_name, 1, 25) cust_name
	from cmt c,gam d, cmg e 
	where c.cust_id = d.cust_id 
	and c.cust_id = e.cust_id 
	and schm_type = 'SBA'
	and d.acct_cls_flg!='Y' 
	and minor_attain_major_date between  to_date('&2','dd-mm-yyyy')  
	and to_date('&3','dd-mm-yyyy') 
	and cust_minor_flg = 'Y' ;

cursor mincur2 is
	select d.sol_id, foracid, substr(acct_name,1,25) acname, 
	       to_char(minor_attain_major_date,'dd-mm-yyyy') major_date, 
		frez_code, frez_reason_code,
	       to_char(d.lchg_time,'dd-mm-yyyy')  last_change_dt, e.cust_id, 
		substr(cust_name, 1, 25) cust_name
	from cmt c,gam d , cmg e, tam f
	where c.cust_id = d.cust_id 
	and c.cust_id = e.cust_id 
	and d.acid = f.acid
	and schm_type = 'TDA'
	and deposit_type != 'F'
	and d.acct_cls_flg!='Y' 
	and minor_attain_major_date between  to_date('&2','dd-mm-yyyy')  
	and to_date('&3','dd-mm-yyyy')
	and cust_minor_flg = 'Y' ;

from_date      varchar(12);
to_date      varchar(12);

begin

   from_date := '&2';
   to_date := '&3';

   for minrec in mincur1
   loop
      dbms_output.put_line(from_date || '|' || to_date ||'|'|| 
			minrec.sol_id ||'|'|| minrec.foracid ||'|'||
			minrec.acname ||'|'|| minrec.major_date ||'|'|| 
			minrec.frez_code ||'|'|| minrec.frez_reason_code ||'|'||
		 	minrec.last_change_dt || '|' || minrec.cust_id || '|' ||
		 	minrec.cust_name);	
   end loop;
   for minrec in mincur2
   loop
      dbms_output.put_line(from_date || '|' || to_date ||'|'|| 
			minrec.sol_id ||'|'|| minrec.foracid ||'|'||
			minrec.acname ||'|'|| minrec.major_date ||'|'|| 
			minrec.frez_code ||'|'|| minrec.frez_reason_code ||'|'||
		 	minrec.last_change_dt || '|' || minrec.cust_id || '|' ||
			minrec.cust_name );	
   end loop;
end;
/
spool off
exit
