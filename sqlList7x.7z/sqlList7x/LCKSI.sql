--##############################################################################################
--#                     File Name       : LCKSI.sql
--#                     Author : Mari (BBSSL)
--#                     Report : LOCKER SI DUE REPORT
--#                     Date   :
--#                     Module  : LOCKER
--#                     Called Menu     : LOCKRPT
--#                     Called By       : LCKSI.com
--##############################################################################################


CREATE OR REPLACE PACKAGE LCKSI AS
	PROCEDURE LCKSI(	inp_str IN VARCHAR2,
				out_retCode OUT NUMBER,
				out_rec OUT VARCHAR2);
				
END LCKSI;
/
CREATE OR REPLACE PACKAGE BODY LCKSI	AS
	v_sol_id		sst.sol_id%type;
	date1 			date;
	date2 			date;
	v_issue_date		date;
	v_locker_num		clmt.locker_num%type;
	v_cust_name		cmg.cust_name%type;
	v_due_date		date;
	v_locker_period		clmt.locker_period%type;
	v_cust_id		cmg.cust_id%type;
	v_locker_type		clmt.locker_type%type;
	v_rent_amt		clmt.RENT_AMT%type:=0;
	v_locker_key_num	clmt.LOCKER_KEY_NUM%type;
	v_oper_acnt		clmt.OPER_ACNT%type;
	v_si_srl_num		sih.SI_SRL_NUM%type;
	v_si_expiry_date	sih.SI_END_DATE%type;
	v_si_next_exec_date	sih.NEXT_EXEC_DATE%type;
	
cursor c1 is 
	SELECT  DISTINCT(sih.si_srl_num) ,sih.cust_id,
	SUBSTR(SUBSTR(sih.RMKS_FREE_TEXT,INSTR(sih.RMKS_FREE_TEXT,'/LOC/'),LENGTH(sih.RMKS_FREE_TEXT)),6,1),
	SUBSTR(SUBSTR(sih.RMKS_FREE_TEXT,INSTR(sih.RMKS_FREE_TEXT,'/LOC/'),LENGTH(sih.RMKS_FREE_TEXT)),8,LENGTH(sih.RMKS_FREE_TEXT)),
	SI_END_DATE,NEXT_EXEC_DATE,A.fixed_amt
	FROM  ADM A,ADM B,PYRH,PYRD,SIH,SST
	WHERE  sih.si_srl_num >= '           1'  
	AND (sih.sol_id = sst.sol_id AND sst.set_id = v_sol_id )
	and pyrh.pr_b2k_id = sih.si_srl_num 
	and pyrd.pr_srl_num = pyrh.pr_srl_num 
	and B.amt_drv_srl_num = pyrd.amt_drv_srl_num 
	and A.amt_drv_srl_num = pyrh.amt_drv_srl_num 
	and sih.RMKS_FREE_TEXT LIKE ('%/LOC/%')
	AND sih.NEXT_EXEC_DATE between to_date(date1,'dd-mm-yyyy') and to_date(date2,'dd-mm-yyyy')
	AND sih.del_flg = 'N'
	AND sih.ENTITY_CRE_FLG = 'Y';
	
	PROCEDURE LCKSI (	inp_str IN VARCHAR2,
				out_retCode OUT NUMBER,
				out_rec OUT VARCHAR2) IS
	

	OutArr          	basp0099.ArrayType;
BEGIN
		basp0099.formInputArr (inp_str,OutArr);
		v_sol_id := OutArr(0);
		date1 := OutArr(1);
		date2 := OutArr(2);
		out_retCode := 0;
		out_rec     := NULL;
IF(NOT c1%ISOPEN) THEN
        --{
        out_retCode:= 0;
        open c1;
        --}
        END IF;
        IF(c1%ISOPEN)  THEN	
	FETCH c1 INTO	v_si_srl_num,
			v_cust_id,
			v_locker_period,
			v_locker_num,
			v_si_expiry_date,
			v_si_next_exec_date,
			v_rent_amt;
	end if;

	if (c1%ISOPEN AND c1%NOTFOUND) THEN
        --{
            close c1;
            out_retcode := 1;
            return;
        --}	
	end if;

	BEGIN
		select LOCKER_KEY_NUM,nvl(RENEWAL_DATE,ISSUE_DATE),OPER_ACNT,DUE_DATE,LOCKER_TYPE
		into v_locker_key_num,v_issue_date,v_oper_acnt,v_due_date,v_locker_type
		from clmt
		where clmt.sol_id = v_sol_id
		and clmt.del_flg = 'N'
		and clmt.LOCKER_NUM = v_locker_num;
		EXCEPTION WHEN NO_DATA_FOUND THEN
			v_locker_key_num:=null;
			v_issue_date:=null;
			v_oper_acnt:=null;
			v_due_date:=null;
			v_locker_type :=null;
	END;
	BEGIN
		select cust_name
		into v_cust_name
		from cmg
		where cmg.cust_id = v_cust_id;
		EXCEPTION WHEN NO_DATA_FOUND THEN
			v_cust_name := null;
	END;
		
	        
	        	
			out_rec	:=		v_locker_num 		||'|'||
						v_cust_id 		||'|'||
						v_cust_name		||'|'||
						v_locker_type 		||'|'||
						v_issue_date 		||'|'||
						v_due_date 		||'|'||
						v_rent_amt		||'|'||
						v_locker_key_num	||'|'||
						v_oper_acnt		||'|'||
						v_si_srl_num		||'|'||
						v_si_expiry_date	||'|'||
						v_si_next_exec_date;
END LCKSI;
END LCKSI;
/
create or replace public synonym LCKSI for LCKSI
/
grant all on LCKSI to tbautil,tbagen,tbacust,tbaadm
/
