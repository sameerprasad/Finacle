rem Author: Abhishek Agrawal
rem Modified by: Rahul Nimkar on Feb 20 based on changed requirements

ttitle center 'ICICI BANK LIMITED' skip 2 -
center 'Mini PWO for ' '&1' ' ' '&2' ' ' '&3' ' ' skip 2 -
center '                 ' skip 2
-- center '--------------------------------------------------------------             ' -
btitle right 'Tran ID: ' tranid ' ' 'Page : ' format 999 sql.pno skip 1

set verify off
set feedback off
set trims on
set lines 112
set pages 60

col set_num heading 'SET ' justify right format B99999
col instrmnt_id heading 'CHQ.NO.' justify right format B9999999
col status  heading 'Type' justify left format A5
col cust_stat heading 'Status' justify left format A6
col accnum  heading 'A/c. No.' justify left format B99999999999999
col acctname heading 'ACCOUNT NAME' justify left format A50
column instrmnt_amt heading 'AMOUNT' justify right format B9,99,99,99,999.99
column seg	heading SEGMENT justify right format A7
col tran_id new_value tranid NOPRINT

spool minipwo.lst

clear breaks
clear computes
break on seg skip page on report
break on row skip 1 on report
compute count LABEL '#Chqs' sum LABEL 'Total Amount' of instrmnt_amt on report
SELECT  rpad(X.set_num,5) set_num,
        substr(Y.instrmnt_id,9,16) instrmnt_id,
        (case when trunc(sol.bod_sys_date-gam.acct_opn_date) > 365 then ' ' else ' NEW' end) status,
        (case when gsp.nre_schm_flg = 'Y' then GSP.schm_code
	      when gsp.schm_code='SBFCR' then GSP.schm_code else ' ' end) cust_stat,
        rpad(lpad(GAM.foracid,13),14) accnum,
        (rpad(GAM.acct_name,50)) acctname,
        Y.instrmnt_amt, 
        X.tran_id,nvl((select segement from ICICI_CUST_SEG where cust_id=GAM.cust_id),'XX') seg
FROM OCP X, OCI Y, OCS Z, GAM ,SST, SOL, GSP
WHERE SST.set_id      = '&1'
AND X.clg_zone_code   = upper('&3') 
AND X.del_flg        != 'Y'
AND X.sol_id          = SST.sol_id
AND X.clg_zone_date   = '&2' 
AND X.clg_zone_code   = Y.clg_zone_code
AND X.clg_zone_date   = Y.clg_zone_date
AND X.sol_id          = Y.sol_id
AND X.clg_zone_code   = Z.clg_zone_code
AND X.clg_zone_date   = Z.clg_zone_date
AND X.sol_id          = Z.sol_id
AND Y.del_flg        !='Y'
AND X.set_num         = Y.set_num
AND X.set_num         = Z.set_num
AND X.acid            = GAM.acid
AND SOL.sol_id        = SST.sol_id
AND GAM.schm_code     = GSP.schm_code
ORDER BY X.tran_id, X.set_num

/
spool off
