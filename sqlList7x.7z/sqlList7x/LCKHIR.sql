--##############################################################################################
--#                     File Name       : LCKHIR.sql
--#                     Author : Arun Kumar (BBSSL)
--#                     Report : Locker Hire Report
--#                     Date   :
--#                     Module  : LOCKER
--#                     Called Menu     : LOCKRPT
--#			Called By	: LCKHIR.com
--##############################################################################################

create or replace package LCKHIR_pack AS
procedure LCKHIR_proc(
			inp_str IN VARCHAR2,
			out_retcode OUT NUMBER,
			out_rec OUT VARCHAR2
		     );
END LCKHIR_pack;
/
create or replace package body LCKHIR_pack AS
	solid			gam.sol_id%type;
	date1 			date;
	date2			date;
	v_issue_date		date;
	v_lock_num		clmt.locker_num%type;
	v_key_num		clmt.locker_key_num%type;
	v_cust_name		cmg.cust_name%type;
	v_due_date		date;
	v_Locker_period		clmt.locker_period%type;
	v_oper_acnt		clmt.oper_acnt%type;
	v_dep_acnt		clmt.dep_acnt%type;
	v_pin_code		cmg.cust_comu_pin_code%type;
	v_cust_id		cmg.cust_id%type;
	v_addr1			cmg.CUST_COMU_ADDR1%type;
	v_addr2			cmg.CUST_COMU_ADDR1%type;
	v_state			cmg.CUST_COMU_ADDR1%type;
	v_city			cmg.CUST_COMU_ADDR1%type;
	v_cntry			cmg.CUST_COMU_ADDR1%type;
	city_name		cmg.CUST_COMU_ADDR1%type;
	state_name		cmg.CUST_COMU_ADDR1%type;
	v_cust_jh_name		varchar2(1000);
	v_cust_jh_id		cljh.CUST_JH_ID%type;
	v_oper_mode		rct.ref_desc%type;
	v_jh_name 		varchar2(1000);
	v_jh_str 		varchar2(1000);
	v_jh_srl_no 		cljh.LKR_JH_SRL_NO%type :=1;
        v_jh_cnt 		number(10);
	v_status		c_svrsetvar.variable_value%type;
	v_staff_disc_method	wlcpm.staff_discount_method%type;
	v_staff_disc_value	wlcpm.staff_discount_value%type;
	v_locker_type		clmt.locker_type%type;
	v_LocCode		sst.set_id%type;
	v_staff_discount_flg	clmt.staff_discount_flg%type;
	v_flg			varchar2(4);
	v_flg1                   varchar2(4);
	v_cust_type		c_svrsetvar.variable_value%type;
	v_custtype_disc_type	lcctm.DISC_TYPE%type;
	v_custtype_disc_amnt	lcctm.DISC_AMNT%type;
	v_surrender_date	wlckm.SURRENDER_DATE%type;
	

CURSOR c1 IS
	SELECT 
	   clmt.ISSUE_DATE,
	   clmt.LOCKER_NUM,
	   clmt.LOCKER_KEY_NUM,
	   clmt.cust_id,
	   clmt.DUE_DATE,
	   clmt.Locker_period,
	   clmt.OPER_ACNT,
	   clmt.DEP_ACNT,
	   clmt.staff_discount_flg,
	   (select substr(rct.ref_desc,1,40) from rct where ref_code=clmt.OPERATION_MODE and ref_rec_type='27') 
	from
        	clmt
	where clmt.sol_id = solid
	and clmt.ISSUE_DATE between to_date(date1,'dd-mm-yyyy') and to_date(date2,'dd-mm-yyyy')
	and clmt.DEL_FLG !='Y'
	and clmt.ENTITY_CRE_FLG = 'Y'
	order by nvl2(v_flg,clmt.issue_date,''),
	nvl2(v_flg1,clmt.locker_num,'');


CURSOR c2 IS
	select 
		cmg.cust_name
	from cljh,cmg
	where cljh.cust_jh_id = cmg.cust_id
	and locker_num=v_lock_num
	and cust_mh_id=v_cust_id
	and cljh.sol_id=solid
	and cljh.del_flg = 'N';

OutArr  basp0099.ArrayType;

procedure LCKHIR_proc(
                        inp_str IN VARCHAR2,
                        out_retcode OUT NUMBER,
                        out_rec OUT VARCHAR2
                     ) AS
BEGIN
--{
			out_retcode := 0;
			basp0099.formInputArr(inp_str,outArr);
			solid	:=  outArr(0);	
			date1	:=  outArr(1);	
			date2	:=  outArr(2);
			v_flg	:=  outArr(3);
			v_flg1   :=  outArr(4);

	IF(NOT c1%ISOPEN) THEN
		OPEN c1;
	END IF;				

	FETCH c1
	INTO	v_issue_date,
		v_lock_num,
		v_key_num,
		v_cust_id,
		v_due_date,
		v_Locker_period,
		v_oper_acnt,
		v_dep_acnt,
		v_staff_discount_flg,
		v_oper_mode;

	IF(c1%NOTFOUND) THEN
		out_retcode := 1;
		CLOSE c1;
		return;	
	END IF;
		
		
	BEGIN
	--{
		SELECT	substr(cust_name,1,40),
			cust_comu_addr1,
	                cust_comu_addr2,
		        CUST_COMU_CITY_CODE,
			cust_comu_state_code,
	                CUST_COMU_PIN_CODE
		INTO    v_cust_name,
                        v_addr1,
                        v_addr2,
                        v_city,
                        v_state,
                        v_pin_code
                FROM    cmg
                WHERE   cust_id=v_cust_id;
                Exception when no_data_found then
                	v_cust_name:=null;
                	v_addr1:=null;
                	v_addr2:=null;
                	v_state:=null;
                	v_city:=null;
                	v_pin_code:=null;
	--}
        END;
	
	BEGIN
	--{
		SELECT  ref_desc
		INTO    city_name
		FROM    rct
		WHERE   ref_code=v_city
		AND     ref_rec_type='01';
		Exception when no_data_found then
		city_name:=null;
	--}
	END;
	
	BEGIN
	--{
		SELECT  ref_desc
		INTO    state_name
		FROM    rct
		WHERE   ref_code=v_state
		AND     ref_rec_type='02';
		Exception when no_data_found then
		state_name:=null;
	--}
	END;
		
	BEGIN
	--{
		SELECT c_svrsetvar.variable_value,wlckm.locker_type,wlckm.SURRENDER_DATE
			INTO v_status,v_locker_type,v_surrender_date
			from wlckm,c_svrsetvar
			where wlckm.locker_num=v_lock_num
			and c_svrsetvar.MODULE_NAME = 'LOCKER'
			and c_svrsetvar.SUB_MODULE_NAME = 'LCKM'
			and c_svrsetvar.VARIABLE_NAME = wlckm.STATUS;
			Exception when no_data_found then
				v_status:=null;
				v_locker_type:=null;
				v_surrender_date :=null;
	--}
	END;	
		
	BEGIN
	--{
		select set_id 
		into v_LocCode
		from sst
		where sol_id = solid
		and set_id like 'LOC%';
	--}
	END;
		
		
	--#####################################################
			-- To find Staff Discount value
	--#####################################################
	BEGIN
	--{
		SELECT staff_discount_method,staff_discount_value 
		INTO v_staff_disc_method,v_staff_disc_value 
		FROM WLCPM 
		WHERE sol_id=solid and 
		location_code= v_LocCode and 
		locker_type=v_locker_type and
		del_flg != 'Y' and 
		v_flg != 'N' and
		effective_from <= (select db_stat_date from gct);
		Exception when no_data_found then
		BEGIN
		--{
			SELECT a.staff_discount_method,a.staff_discount_value
			INTO v_staff_disc_method,v_staff_disc_value
			FROM WLCPMH a
			WHERE a.sol_id=solid and
			a.location_code= v_LocCode and
			a.locker_type= v_locker_type and
			a.del_flg != 'Y' and
			a.v_flg != 'N' and
			a.effective_from <= (select db_stat_date from gct) and
			a.lchg_time = (SELECT MAX(lchg_time) FROM wlcpmh b
					WHERE b.sol_id=solid AND
					a.location_code= v_LocCode AND
					a.locker_type=v_locker_type AND
					b.del_flg != 'Y' AND
					b.v_flg!='N');		
			Exception when no_data_found then
			BEGIN
			--{
				SELECT staff_discount_method,staff_discount_value
				INTO v_staff_disc_method,v_staff_disc_value
				FROM WLCPM
				WHERE sol_id='0000' and
				location_code= v_LocCode and
				locker_type=v_locker_type and
				del_flg != 'Y' and
				v_flg != 'N' and
				effective_from <= (select db_stat_date from gct);
				Exception when no_data_found then
				BEGIN
				--{
					SELECT a.staff_discount_method,a.staff_discount_value
					INTO v_staff_disc_method,v_staff_disc_value
					FROM WLCPMH a
					WHERE a.sol_id='0000' and
					a.location_code= v_LocCode and
					a.locker_type=v_locker_type and
					a.del_flg != 'Y' and
					a.v_flg != 'N' and
					a.effective_from <= (select db_stat_date from gct) and
					a.lchg_time = (SELECT MAX(lchg_time) FROM wlcpmh b
								WHERE b.sol_id=a.sol_id AND
								a.location_code= b.location_code AND
								a.locker_type=b.locker_type AND
								b.del_flg != 'Y' AND
								b.v_flg!='N');			
					Exception when no_data_found then
						v_staff_disc_method := '0';
						v_staff_disc_value := 0;
				--}
				END;
			--}
			END;
		--}
		END;
	--}
	END;	 	
		
			
	--##########################################################################################	
	   	
	BEGIN
	--{
	   	BEGIN
		--{
		                select count(1) into v_jh_cnt
		                from cljh
		                where locker_num=v_lock_num
		                and cust_mh_id = v_cust_id
		                and sol_id =solid
				and del_flg = 'N';
		--}
		END;
		IF (v_jh_cnt > '1') THEN
		--{
		        
			BEGIN
			--{
				IF(NOT c2%ISOPEN) THEN
					OPEN c2;
				END IF;				
			
				FETCH c2
				INTO	v_jh_name;

				v_jh_str := v_jh_str ||','||v_jh_name;

				IF(c2%NOTFOUND) THEN
					CLOSE c2;
					return;
				END IF;
			--}
		        END;        
			v_jh_str := substr(v_jh_str,instr(v_jh_str,',')+1,length(v_jh_str));
        		v_cust_jh_name := v_jh_str;
		        v_jh_str :='';
			v_jh_srl_no:=1;
		--}
        	ELSE
		--{
			BEGIN
			--{
			select 	cmg.cust_name
			into v_cust_jh_name
			from cljh,cmg
			where cljh.cust_jh_id = cmg.cust_id
			and locker_num=v_lock_num
			and cust_mh_id=v_cust_id
			and cljh.sol_id=solid
			and cljh.del_flg = 'N';
			Exception when no_data_found then
			v_cust_jh_name := null;
			--}
			END;
		--}	
		END IF;
	--}
       	END;

	BEGIN
	--{
		select	c_svrsetvar.variable_value,lcctm.DISC_TYPE,lcctm.DISC_AMNT
		into v_cust_type,v_custtype_disc_type,v_custtype_disc_amnt
		from clctdd,c_svrsetvar,lcctm
		where clctdd.sol_id = solid
		and clctdd.cust_id = v_cust_id
		and clctdd.locker_number = v_lock_num
		and clctdd.del_flg = 'N'
		and clctdd.entity_cre_flg = 'Y'
		and c_svrsetvar.module_name = 'LOCKER'
		and c_svrsetvar.sub_module_name = 'CUSTTYPE'
		and c_svrsetvar.VARIABLE_NAME = clctdd.CUST_TYPE
		and clctdd.CUST_TYPE = lcctm.CUST_TYPE
		and lcctm.DEL_FLG != 'Y'
		and clctdd.LCHG_TIME >= lcctm.LCHG_TIME;
		Exception when no_data_found then
		BEGIN
			select	c_svrsetvar.variable_value,lcctmh.DISC_TYPE,lcctmh.DISC_AMNT
			into v_cust_type,v_custtype_disc_type,v_custtype_disc_amnt
			from clctdd,c_svrsetvar,lcctmh
			where clctdd.sol_id = solid
			and clctdd.cust_id = v_cust_id
			and clctdd.locker_number = v_lock_num
			and clctdd.del_flg = 'N'
			and clctdd.entity_cre_flg = 'Y'
			and c_svrsetvar.module_name = 'LOCKER'
			and c_svrsetvar.sub_module_name = 'CUSTTYPE'
			and c_svrsetvar.VARIABLE_NAME = clctdd.CUST_TYPE
			and clctdd.CUST_TYPE = lcctmh.CUST_TYPE
			and lcctmh.DEL_FLG != 'Y'
			and clctdd.LCHG_TIME >= lcctmh.LCHG_TIME
			and lcctmh.LCHG_TIME >= (SELECT MAX(lcctmh.lchg_time) FROM lcctmh,clctdd
							where clctdd.sol_id = solid
							and clctdd.cust_id = v_cust_id
							and clctdd.locker_number = v_lock_num
							and clctdd.del_flg = 'N'
							and clctdd.entity_cre_flg = 'Y'
							and clctdd.CUST_TYPE = lcctmh.CUST_TYPE
							and lcctmh.DEL_FLG != 'Y'
							and clctdd.LCHG_TIME >= lcctmh.LCHG_TIME);
			Exception when no_data_found then
			v_cust_type := null;
			v_custtype_disc_type := null;
			v_custtype_disc_amnt := null;
		END;
	--}
	END;

	 	out_rec :=	v_issue_date	||'|'||
				v_lock_num	||'|'||
				v_key_num	||'|'||
				v_cust_name	||'|'||
				v_due_date	||'|'||
	   			v_Locker_period ||'|'||
	   			v_oper_acnt	||'|'||
	   			v_dep_acnt	||'|'||
	   			v_cust_id	||'|'||
	   			v_addr1		||'|'||
	   			v_addr2		||'|'||
	   			city_name	||'|'||
	   			state_name	||'|'||
	   			v_pin_code	||'|'||
	   			v_cust_jh_name	||'|'||
	   			v_oper_mode	||'|'||
				v_status	||'|'||
				v_staff_discount_flg ||'|'||
				v_staff_disc_method ||'|'||
				v_staff_disc_value ||'|'||
				v_flg		||'|'||
				v_cust_type	||'|'||
				v_surrender_date||'|'||
				v_custtype_disc_type||'|'||
				v_custtype_disc_amnt;
	return;
--}
end LCKHIR_proc;
end LCKHIR_pack;
/
drop public synonym LCKHIR_pack
/
create or replace public synonym LCKHIR_pack for LCKHIR_pack
/
grant execute on LCKHIR_pack to tbautil, tbacust, tbagen,tbaadm
/
