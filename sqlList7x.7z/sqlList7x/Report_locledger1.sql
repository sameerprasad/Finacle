SET SERVEROUTPUT ON size 1000000
set lines 650
set pages 0
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_locledger1.lst

DECLARE

v_solid                	gam.sol_id%type:='&1';
v_locker_num           	wlckm.locker_num%type:='&2';      
DATE1           		DATE:= '&3';
DATE2           		DATE:= '&4';
v_surstat              	lcsm.SURRENDER_DATE%type; 
V_DISCOUNT				number(10,2);
V_PREMIUM				number(10,2);
v_cust_id		CLMT.cust_id%type;

cursor c1(v_solid varchar2,v_locker_num varchar2,v_cust_id CLMT.cust_id%type) is 
select  distinct clmt.cust_id,
        cmg.cust_name hirer_name,
        wlckm.status||'-'||wlckm.remarks loc_status,
        clmt.issue_date allot_date,
        clmt.rent_amt actual_rent,
    (clmt.rent_amt - clmt.disc_rent_amt) discount,
        clmt.due_date NEXT_PAYMENT_DATE,
        clmt.disc_rent_amt net_rent,
        clmt.operation_mode,
        '' rent_revision_date,
        clmt.locker_num,
        wlckm.rack_id rack,
        clmt.locker_type type,
        substr(wlckm.SIZE_OF_LOCKER,1,2) hight,
        substr(wlckm.SIZE_OF_LOCKER,4,2) depth,
        substr(wlckm.SIZE_OF_LOCKER,7,2) width,
        wlckm.KEY_NUM
from    clmt,cmg,wlckm
where   lpad(clmt.cust_id,9,' ') = cmg.cust_id
and     clmt.locker_num = wlckm.locker_num
and clmt.sol_id = wlckm.sol_id
and     clmt.locker_num = v_locker_num
and     clmt.sol_id = v_solid
and     clmt.cust_id = v_cust_id
and     clmt.ENTITY_CRE_FLG = 'Y'
and     clmt.del_flg !='Y';

BEGIN
	BEGIN
		--To select cust id for the given locker number--------
		SELECT DISTINCT CUST_ID
		INTO v_cust_id
		FROM CLMT
		WHERE sol_id = v_solid
		AND locker_num = v_locker_num
		AND del_flg !='Y';		
	EXCEPTION WHEN NO_DATA_FOUND THEN
		v_cust_id := null;
	END;
		
FOR f1 IN c1(v_solid,v_locker_num,v_cust_id)
LOOP
	BEGIN
		SELECT
                            SUM(AMOUNT)
                    INTO
							v_premium 
                    FROM
                            CLTLG
                    WHERE
                            LOCKER_NUM = v_locker_num
			AND cust_id = v_cust_id
                    AND     PARTICULARS NOT LIKE ('%RENT%') AND PARTICULARS LIKE ('%Prem%')
			AND del_flg!='Y'		
                    AND     APPLICABLE_DATE = ( select max(applicable_date) from cltlg
                                                where applicable_date <= DATE1
                                                and locker_num = v_locker_num
						AND cust_id = v_cust_id
						AND del_flg!='Y');
					EXCEPTION 
					WHEN NO_DATA_FOUND THEN
					V_PREMIUM := 0;
			END;
			
			BEGIN
                    SELECT
                            SUM(AMOUNT)
                    INTO
                            V_DISCOUNT
                    FROM
                            CLTLG
                    WHERE
                            LOCKER_NUM = v_locker_num
			AND cust_id = v_cust_id
                    AND     PARTICULARS NOT LIKE ('%RENT%') AND PARTICULARS NOT LIKE ('%Prem%')
			AND del_flg!='Y'		
                    AND     APPLICABLE_DATE = ( select max(applicable_date) from cltlg
                                                where applicable_date <= DATE1
                                                and locker_num = v_locker_num
						AND cust_id = v_cust_id
						AND del_flg!='Y');
		    EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                    V_DISCOUNT := 0;
            END;

			BEGIN
                                select lcsm.SURRENDER_DATE into v_surstat
                                from   lcsm
                                where  LOCK_NO = v_locker_num
				AND cust_id = v_cust_id;

                        		exception when no_data_found then
                                v_surstat     := '';
			END;	

                 dbms_output.put_line ( f1.cust_id				||'|'|| 
										f1.hirer_name			||'|'|| 
										v_surstat               ||'|'||
										f1.loc_status           ||'|'|| 
										f1.allot_date           ||'|'|| 
										f1.actual_rent			||'|'|| 
										v_discount				||'|'|| 
										v_premium				||'|'|| 
										f1.NEXT_PAYMENT_DATE    ||'|'|| 
										f1.net_rent				||'|'|| 
										f1.operation_mode		||'|'|| 
										f1.rent_revision_date   ||'|'||
										f1.locker_num           ||'|'|| 
										f1.rack					||'|'|| 
										f1.type					||'|'|| 
										f1.hight				||'|'|| 
										f1.depth				||'|'||
										f1.width				||'|'||
										f1.key_num              
			         				);
END LOOP;
END;
/
spool off;
