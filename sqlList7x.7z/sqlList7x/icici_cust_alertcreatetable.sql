  
drop table ICICI.ICICI_CUST_ALERT_TBL
/

create table ICICI.ICICI_CUST_ALERT_TBL
  (CUST_ID              VARCHAR2(9),
   FUNC_CODE        VARCHAR2(1),
   MODE_OF_DEL     VARCHAR2(1),
   COUNTRY_CODE         NUMBER(5),
   MOBILE_NO            VARCHAR2(60),
   EMAIL_ID             VARCHAR2(60),
   FREE_TEXT_1          VARCHAR2(200),
   FREE_TEXT_2          VARCHAR2(200),
   FREE_TEXT_3          VARCHAR2(50),
   FREE_TEXT_4          VARCHAR2(50),
   FREE_TEXT_5          VARCHAR2(50),
   DEL_FLG              VARCHAR2(1),
   ENTITY_CRE_FLG          VARCHAR2(1),
   RCRE_TIME            DATE,
   RCRE_USER_ID            VARCHAR2(15),
   LCHG_TIME             DATE,
   LCHG_USER_ID             VARCHAR2(15),
   CHECKER_USERID       VARCHAR2(15)
   )
  /

drop public synonym ICICI_CUST_ALERT
/
create public synonym ICICI_CUST_ALERT for ICICI.ICICI_CUST_ALERT_TBL
/
grant select, insert, delete, update on ICICI.ICICI_CUST_ALERT_TBL to tbagen
/
grant select, insert, delete, update on ICICI.ICICI_CUST_ALERT_TBL to tbaadm
/
grant select on ICICI.ICICI_CUST_ALERT_TBL to tbautil
/
grant select, insert, delete, update on ICICI.ICICI_CUST_ALERT_TBL to tbacust
/
grant select, insert, delete, update on ICICI.ICICI_CUST_ALERT_TBL to icici
/

