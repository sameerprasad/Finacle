Rem     This file will create RACK_ID_MAINTENENCE Table
Rem     with the following characteristics.

Rem     Coded by : Saravanan (BBSSL)

Rem     Module  : LOCKER

Rem TABLE NAME: RACK_ID_MAINTENENCE

Rem SYNONYM:    WLCRM

drop table icici.RACK_ID_MAINTENENCE
/
drop public synonym WLCRM
/
create table icici.RACK_ID_MAINTENENCE
(
	SOL_ID		VARCHAR2(8),
	RACK_ID		VARCHAR2(3) NOT NULL, 
	START_NO  	NUMBER (5), 
	END_NO    	NUMBER (5),
	DEL_FLG		CHAR(1),
	ENTITY_CRE_FLG  CHAR(1),
	LCHG_USER_ID    VARCHAR2(15),
	LCHG_TIME       DATE,
	RCRE_USER_ID    VARCHAR2(15),
	RCRE_TIME       DATE,
	MANUF_NAME                      VARCHAR2(30),
	ASSET_CODE                      VARCHAR2(20),
	TOTAL_LOCKER_UNITS		VARCHAR2(12),
	REMARKS                         VARCHAR2(100)
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
create public synonym WLCRM for icici.RACK_ID_MAINTENENCE
/
grant select, insert, update, delete on WLCRM to tbagen
/
grant select on WLCRM to tbacust
/
grant select on WLCRM to tbautil
/
grant all on WLCRM to tbaadm
/
create unique index idx_wlcrm_main on WLCRM(SOL_ID,RACK_ID)
/
