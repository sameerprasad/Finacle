set feedback off
set echo off
set termout off
set verify off
set serveroutput on size 10000
spool &1..sweep.txt
declare
acctnum gam.foracid%type;
bal gam.clr_bal_amt%type;
parttrantype varchar2(1);
totaldr gam.clr_bal_amt%type;
totalcr gam.clr_bal_amt%type;
pandltrf gam.clr_bal_amt%type;
pandsign varchar2(1);
cursor charges is
select foracid, clr_bal_amt, decode(sign(clr_bal_amt),-1,'C',1,'D') from gam where sol_id='&1' and gl_sub_heaD_code between '40010' and '40070' and acct_cls_flg!='Y' and entity_cre_flg!='N' and clr_bal_amt!=0 and acct_crncy_code ='INR';


cursor income is
select foracid, clr_bal_amt, decode(sign(clr_bal_amt),-1,'C',1,'D') from gam where sol_id='&1' and gl_sub_heaD_code between '75010' and '75040' and acct_cls_flg!='Y' and entity_cre_flg!='N' and clr_bal_amt!=0 and acct_crncy_code ='INR';

begin
totaldr:=0;
totalcr:=0;
pandltrf:=0;
open charges;
loop
fetch charges into acctnum, bal, parttrantype;
exit when charges%notfound;
totaldr:=totaldr + bal; 
dbms_output.put_line(acctnum||'|'||'INR'||'|'||'&1'||'|'||parttrantype||'|'||abs(bal)||'|'||'TRFR TO P n L ACCNT'||'|'||'CFG');
end loop;
close charges;
select decode(sign(totaldr),-1,'D',1,'C') into pandsign from dual;
dbms_output.put_line('&1'||'SL000P'||'&'||'L'||'|'||'INR'||'|'||'&1'||'|'||pandsign||'|'||abs(totaldr)||'|'||'TRFR frm CHARGES ACCTS'||'|'||'CFG');

open income;
loop
fetch income into acctnum, bal, parttrantype;
exit when income%notfound;
totalcr:=totalcr + bal;
dbms_output.put_line(acctnum||'|'||'INR'||'|'||'&1'||'|'||parttrantype||'|'||abs(bal)||'|'||'TRFR TO P n L ACCNT'||'|'||'CFG');
end loop;
close income;
select decode(sign(totalcr),-1,'D',1,'C') into pandsign from dual;

dbms_output.put_line('&1'||'SL000P'||'&'||'L'||'|'||'INR'||'|'||'&1'||'|'||pandsign||'|'||abs(totalcr)||'|'||'TRFR frm INCOME ACCTS'||'|'||'CFG');
pandltrf:=totaldr + totalcr;

end;
/
