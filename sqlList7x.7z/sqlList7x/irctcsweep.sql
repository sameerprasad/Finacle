set echo off verify off feedback off term off pagesi 0 trims on serveroutput on size 1000000 timing off time off
spool irctcsweep 
declare 

cursor AcctList is
select foracid,clr_bal_amt,decode(sign(clr_bal_amt),-1,'C','D') parttran,sol_id from gam where sol_id = '0018'
and bacid in (
'SLIRCTC0',
'SLIRCTC1',
'SLIRCTC2',
'SLIRCTC3',
'SLIRCTC4',
'SLIRCTC5',
'SLIRCTC6',
'SLIRCTC7',
'SLIRCTC8',
'SLIRCTC9')   and acct_crncy_code = 'INR'
and acct_cls_flg = 'N';

contratran varchar2(1) := 'D';

begin

for i in AcctList
loop


    dbms_output.put_line(i.foracid||'|'||'INR'||'|'||i.sol_id||'|'||i.parttran||'|'||abs(i.clr_bal_amt)||'|'||
                            'DAY END BALANCE TRF');

    if ( i.parttran = 'C' )
    then
        contratran := 'D';
    else
        contratran := 'C';
    end if;

    dbms_output.put_line('000705004422'||'|'||'INR'||'|'||'0007'||'|'||contratran||'|'||abs(i.clr_bal_amt)||'|'||
                            'DAY END BALANCE TRF');

end loop;
end;
/
spool off
