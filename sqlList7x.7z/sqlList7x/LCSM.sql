--##############################################################################################
--#                     File Name       : LCSM.sql
--#                     Author : Arun Kumar (BBSSL)
--#                     Report : LOCKER SURRENDER REPORT
--#                     Date   :
--#                     Module  : LOCKER
--#                     Called Menu     : LOCKRPT
--#                     Called By       : LCSM.com
--##############################################################################################

create or replace package LCSM_pack as
procedure LCSM_proc (
			inp_str IN VARCHAR2,
			out_retcode OUT NUMBER,
			out_rec	OUT VARCHAR2
		     );
end LCSM_pack;
/
 create or replace package body LCSM_pack as
 
 v_sol_id		gam.sol_id%type;
 v_date1		date;
 v_date2		date;
 v_lock_no		clmt.locker_num%type;
 v_lock_type		varchar2(5);
 v_cust_id		cmg.cust_id%type;
 v_cust_name		cmg.cust_name%type;
 v_issue_date		clmt.issue_date%type;
 v_surr_date		date;
 v_reason		varchar2(100);
 v_authorisedby		varchar2(80);
 v_due_date		clmt.due_date%type;
 v_rent_paid		lcpp.RENT_PAID_AMOUNT%type;
 v_mnths_bet		number(30,10);
 v_disc_rent_amt	clmt.disc_rent_amt%type;
 v_LocCode		sst.set_id%type;
 v_rent_amt		clrm.rent_amt%type;
 v_amt			lcpp.RENT_PAYABLE_AMOUNT%type;
 v_lock_period		clmt.LOCKER_PERIOD%type;
 v_period          	clmt.LOCKER_PERIOD%type;
 v_ref_amt		lcpp.RENT_PAYABLE_AMOUNT%type;
 v_rem_period		number(30,10);
 v_used_period		number(30,10);	
 v_stat_flag		char(10);	

 
 CURSOR WLCKM(v_sol_id gam.sol_id%type,v_date1 date,v_date2 date,v_stat_flag char) IS
 			SELECT
				wlckm.LOCKER_NUM,
				wlckm.LOCKER_TYPE,
				lcsm.CUST_ID,
				lcsm.CUST_NAME,
				to_date((SUBSTR(wlckm.SURRENDER_DATE,1,10)),'DD-MM-YYYY'),
				lcsm.REASON,
				lcsm.LCHG_USER_ID
			FROM	wlckm,lcsm
			WHERE   wlckm.sol_id = lcsm.sol_id
			AND	wlckm.LOCKER_NUM = LOCK_NO
			and	TO_DATE(SUBSTR(WLCKM.SURRENDER_DATE,1,10),'dd-mm-yyyy') 
			BETWEEN TO_DATE(v_date1,'dd-mm-yyyy') AND TO_DATE(v_date2,'dd-mm-yyyy')
			and     wlckm.status like decode(v_stat_flag,'Y','S','%')
			and	wlckm.sol_id = v_sol_id

			order by wlckm.SURRENDER_DATE;
			
OutArr	basp0099.ArrayType;

	PROCEDURE LCSM_proc
	(
		inp_str IN varchar2,
		out_retcode  OUT number,
		out_rec  OUT varchar2
	) AS
BEGIN
	out_retcode := 0;
		basp0099.formInputArr(inp_str,outArr);
			v_sol_id	:=	outArr(0);
			v_date1		:=	outArr(1);
			v_date2		:=	outArr(2);
			v_stat_flag	:=	outArr(3);
			

	IF(NOT WLCKM%ISOPEN) THEN
		OPEN WLCKM(v_sol_id,v_date1,v_date2,v_stat_flag);
	END IF;
	FETCH WLCKM INTO
			v_lock_no,
			v_lock_type,
			v_cust_id,
			v_cust_name,
			v_surr_date,
			v_reason,
			v_authorisedby;
	BEGIN
			select issue_date,due_date,LOCKER_PERIOD
			into v_issue_date,v_due_date,v_lock_period
			from clmt
			where cust_id = v_cust_id
			and locker_num = v_lock_no
			and sol_id = v_sol_id
			and del_flg != 'N'
			order by locker_num;
			Exception when no_data_found then
                        	v_issue_date := null;
				v_due_date := null;
				v_lock_period :=0;
	END;	

	BEGIN
			SELECT 
				RENT_PAID_AMOUNT 
			INTO 
				v_rent_paid
			FROM 
				LCPP
			where 	lcpp.sol_id  =  v_sol_id
	 		AND   	lcpp.LOCKER_NUMBER = v_lock_no
			and    	lcpp.cust_id = v_cust_id 
			and     lcpp.del_flg !='Y';
			Exception when no_data_found then
			    v_rent_paid := 0;
	END;
	
	IF(WLCKM%NOTFOUND) THEN
		out_retcode := 1;
		CLOSE WLCKM;
		RETURN;
	END IF;
	
	BEGIN
		select
			months_between(nvl(RENEWAL_DATE,issue_date),v_date2),disc_rent_amt 
		into
			v_mnths_bet,v_disc_rent_amt
		from 	clmt
		where 	locker_num = v_lock_no
		and    	cust_id =    v_cust_id	
		and     sol_id =     v_sol_id	
		and    del_flg != 'Y';
		Exception when no_data_found then
                            v_mnths_bet := 0;
			    v_disc_rent_amt := 0;
	END;
	
	BEGIN
		select
			set_id
		into
			v_LocCode
		from 	sst
		where	sol_id = v_sol_id
		and 	set_id like 'LOC%';
		Exception when no_data_found then
		v_LocCode := null; 
	END;

	--##############################################
	--# CALCULATION OF REFUND AMOUNT	
	--##############################################	

	BEGIN
		select a.rent_amt 
		into   v_rent_amt	
		from clrm a 
		WHERE a.sol_id = v_sol_id
		and a.location_code = v_LocCode
		and a.locker_type = v_lock_type
		and a.Rent_period = '1' 
		and a.Rent_Version_Code = (select max(b.Rent_Version_Code) 
					   from clrm b
				           where a.location_code = b.location_code and
					       	a.locker_type = b.locker_type and
						a.sol_id = b.sol_id and
						a.Rent_period = b.Rent_period and
						b.Rent_period = '1' and
						b.rent_effective_date <= v_issue_date)
		and a.del_flg != 'Y';
		EXCEPTION WHEN NO_DATA_FOUND THEN	
				BEGIN
					select a.rent_amt 
					into   v_rent_amt 
					from clrm a 
					WHERE a.sol_id = '0000'
					and   a.location_code = v_LocCode
					and   a.locker_type =  v_lock_type
					and   a.Rent_period = '1' 
					and   a.Rent_Version_Code = (select max(b.Rent_Version_Code) 
								     from clrm b
							             where a.location_code = b.location_code and
							             	   a.locker_type = b.locker_type and
								           a.sol_id = b.sol_id and
								           a.Rent_period = b.Rent_period and
									   b.Rent_period = '1' and
									   b.rent_effective_date <= v_issue_date)
					and a.del_flg != 'Y';
					EXCEPTION WHEN NO_DATA_FOUND THEN
						v_rent_amt := 0;
				END;
	END;	
	
		v_rent_amt := v_rent_amt/2;
	
	BEGIN
	
	  		select
	  			(nvl(RENT_PAYABLE_AMOUNT,0) - (nvl(RENT_PAID_AMOUNT,0))) + ((nvl(CHARGE_PAYABLE_AMOUNT,0)) - (nvl(CHARGE_PAID_AMOUNT,0))) 
	  		into
	  			v_amt
	  		from
	  			lcpp
	  		where
	  			sol_id = v_sol_id
	  		and	Locker_number = v_lock_no
	  		and	cust_id = v_cust_id
	  		and 	del_flg != 'N';
			EXCEPTION WHEN NO_DATA_FOUND THEN
				  v_amt := 0;
	 		
	  				
			if (v_lock_period = '1') then
				IF (v_amt > 0) then
					v_ref_amt := '0';
				else
					v_ref_amt := abs(v_amt * (-1));
					
				end if;
			else
			IF (v_due_date <> NULL) THEN
			BEGIN
				BEGIN
							
					if(v_mnths_bet< 0)  then
						select
							SUBSTR(months_between(due_date,v_date2)/6,1,1) 
						into
							v_rem_period
						from 	clmt 
						where 	locker_num = v_lock_no
						and 	cust_id = v_cust_id
						and 	sol_id =  v_sol_id
						and 	del_flg = 'N';
					else
					BEGIN
						select
							substr(months_between(v_due_date,(add_months(v_issue_date,12)-1))/6,1,1) 
						into
							v_rem_period
						from dual;
						EXCEPTION WHEN NO_DATA_FOUND THEN
							v_rem_period := 0;
					END;
					end if;	
				END;
					v_period := v_lock_period * 2;
					v_used_period := (v_period - v_rem_period);
					v_ref_amt := abs((v_disc_rent_amt -  (v_rent_amt * v_used_period)) * 75 /100);
			END;
			END IF;	
			END IF; 
	END;
	
		

--####################
--# Locker Period in Months
--#####################
				v_lock_period := v_lock_period * 12;
		
		
	
		out_rec := 
				v_lock_no	||'|'||
				v_cust_id	||'|'||
				v_cust_name	||'|'||
				v_surr_date	||'|'||
				v_lock_period	||'|'||
				v_rent_paid	||'|'||
				v_ref_amt	||'|'||
				v_reason	||'|'||
				v_authorisedby;
				
			return;
end LCSM_proc;
end LCSM_pack;
/
drop public synonym LCSM_pack
/
create or replace public synonym LCSM_pack for LCSM_pack
/
grant execute on LCSM_pack to tbautil,tbacust,tbagen,tbaadm
/
