spool updfcnrparam
select schm_code, auto_renewal_flg, perd_mths_for_auto_renew from tsp
where schm_code in ('FDHUS','FDHGB','FDHDM','FDHEU','FDHJY','CFDUS','CFDGB',
'CFDDM','CFDEU','CFDJY')
/
update tsp
set auto_renewal_flg = 'U',
perd_mths_for_auto_renew = '12'
where schm_code in ('FDHUS','FDHGB','FDHDM','FDHEU','FDHJY','CFDUS','CFDGB',
'CFDDM','CFDEU','CFDJY')
/
select schm_code, auto_renewal_flg, perd_mths_for_auto_renew from tsp
where schm_code in ('FDHUS','FDHGB','FDHDM','FDHEU','FDHJY','CFDUS','CFDGB',
'CFDDM','CFDEU','CFDJY')
/
spool off
