prompt 'Creation of Menu option PPFTRFSO :'

select 'Adding the new menu option PPFTRFSO...' from DUAL;

variable mopNum varchar2(2);

begin
select nvl(to_char(to_number(max(mop_num))+1), '1') into :mopNum from mno where menu_id = 'PPFTRFSO';
end;
/
delete mod where mop_id = 'PPFTRFSO';
set escape \

insert into mod values ('PPFTRFSO','Y','N','U','http://$W/finbranch/','custom/PPFTRFSOUT.jsp?sessionid=$S','\&sectok=$T\&finsessionid=$S\&fabsessionid=$C\&mo=HCUMM','C','120','999','','999','999','','BT','FT','MT','TT','','','','','','','FINW','M','N','','','','','F',user,user,sysdate, sysdate, 1);

delete oat where mop_id = 'PPFTRFSO';
insert into oat values ('PPFTRFSO', 'GU', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
insert into oat values ('PPFTRFSO', 'DB', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);
insert into oat values ('PPFTRFSO', 'OP', 'SYSTEM', sysdate, 'SYSTEM', sysdate, 1);


delete mod_txt where mop_id = 'PPFTRFSO';

insert into mod_txt values ('PPFTRFSO', 'INFENG', 'PPFTRFSO', 'PPF Transfer Out', '', 'SYSTEM', 'SYSTEM', sysdate, sysdate, 1);

commit
/
