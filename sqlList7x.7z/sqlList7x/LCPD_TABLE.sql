Rem     This file will create LOCKER_PAID_DETAILS
Rem     with the following characteristics.
Rem     Coded by : Chandra Sekar (BBSSL)

Rem     Module  : LOCKER

Rem TABLE NAME: LOCKER_PAID_DETAILS

Rem SYNONYM:    LCPD

drop table icici.LOCKER_PAID_DETAILS
/
drop public synonym LCPD
/
create table icici.LOCKER_PAID_DETAILS
( 
	sol_id varchar2(8),
	tran_id varchar2(9),
	tran_date date,
	part_tran_srl_num varchar2(4),
	cust_id varchar2(9),
	locker_number varchar2(12),
	paid_amount number(20,4),
	remarks varchar2(50),
	del_flg char(1)
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
create public synonym LCPD for icici.LOCKER_PAID_DETAILS
/
create unique index IDX_LCPD on icici.LOCKER_PAID_DETAILS(SOL_ID,TRAN_ID,TRAN_DATE,PART_TRAN_SRL_NUM,CUST_ID,LOCKER_NUMBER )
/
grant select, insert, update, delete on LCPD to tbagen
/
grant select on LCPD to tbacust
/
grant select on LCPD to tbautil
/
grant all on LCPD to tbaadm
/
