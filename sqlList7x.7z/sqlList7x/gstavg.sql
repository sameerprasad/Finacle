rem accept sol prompt 'ENTER THE FOUR DIGIT SOL ID     :: '
rem accept dt1 prompt 'ENTER START DATE  (DD-MON-YYYY) :: '
rem accept dt2 prompt 'ENTER END   DATE  (DD-MON-YYYY) :: '
set echo off
set termout off
set pause off
rem script for  GL AVERAGES 
rem author M K JAIN
rem version 1.0 dated  17-MAY-95
set verify off
whenever sqlerror exit sql.sqlcode
set feedback off
set linesize 80 
set pages 66
set newpage 0
define all_dashes = '______________________________________________________________________________'
column today new_value today_date
column bran new_value br
select to_char(sysdate,'dd/mm/yyyy') today
from dual;
select sol_desc bran from sol where sol_id = '&1';

ttitle center  'ICICI BANKING CORPORATIONS LTD.' skip 1 -
center  br skip 2 -
CENTER 'DETAILS OF GL AVERAGES FOR PERIOD &2 TO &3' skip 1 - 
left today_date right 'Page :       ' format 999 sql.pno skip 1 -
left all_dashes skip 2
set numf b9999,99,99,999.99
break on gl skip 2 on sub_head on report
compute sum of dr cr net on GL report
column gl format a3
spool gstavg
select substr(gl_sub_head_code,1,2) gl,gl_sub_head_code sub_head,
avg(tot_dr_bal) dr,
avg(tot_cr_bal) cr, avg(tot_cr_bal)-avg(tot_dr_bal) net
from gst
where (gl_sub_head_code between '05010' and '28050' 
or gl_sub_head_code between '60010' and '63999')
and tran_date  between to_Date(upper('&2'),'DD-MM-YYYY') and to_Date(upper('&3'),'DD-MM-YYYY')
and sol_id = '&1'
group by substr(gl_sub_head_code,1,2),gl_sub_head_code
order by 1,2 
/
ttitle off
btitle off
set termout on
set feedback on
set verify on
set heading on
clear breaks
clear computes
spool off
set echo on
exit

