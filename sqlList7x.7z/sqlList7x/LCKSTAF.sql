--##############################################################################################
--#                     File Name       : LCKSTAF.sql
--#                     Author : Saravanan.S (BBSSL)
--#                     Report : LOCKER DETAILS REPORT
--#                     Date   :
--#                     Module  : LOCKER
--#                     Called Menu     : LOCKCALL
--##############################################################################################

set serveroutput on size 1000000
set head off
set pau off
set echo off
set pages 0
set termout off
set verify off
set feedback off
spool LCKSTAF.lst

DECLARE
		v_sol_id		gam.sol_id%type:='&1';			
		v_locker_num		clmt.locker_num%type;
		v_key_no		wlckm.key_num%type;
		v_rack_id		wlckm.rack_id%type;
		v_status		wlckm.remarks%type;
		v_locker_type		clmt.locker_type%type;
		v_issue_date		date;
		v_rent_amt1		clrm.RENT_AMT%type;
		v_rent_amt2		clrm.RENT_AMT%type;
		v_rent_amt3		clrm.RENT_AMT%type;
		v_staff_disc_method	wlcpm.staff_discount_method%type;
		v_staff_disc_value	wlcpm.staff_discount_value%type;
		v_loc_code1		wlcpm.LOCATION_CODE%type;
		v_locker_size		wlckm.size_of_locker%type;
		LocCode                 sst.set_id%type;
		
		
cursor c2(v_sol_id varchar2) is 

SELECT  	DISTINCT(a.rack_id),
		sst.set_id LocCode,
		a.locker_type,
		a.size_of_locker
	FROM wlckm a,wlcrm b,sst 
	WHERE  a.sol_id = sst.sol_id 
	AND  a.sol_id=b.sol_id
	AND a.rack_id = b.rack_id 
	AND a.sol_id = v_sol_id
	AND sst.set_id like 'LOC%';
	
BEGIN
	
	FOR f1 IN c2(v_sol_id)
	LOOP
		BEGIN
			select 	a.rent_amt
			INTO v_rent_amt1
			from clrm a
			where a.RENT_VERSION_CODE =(select max(b.RENT_VERSION_CODE) 
							from clrm b 
							where a.LOCATION_CODE =b.LOCATION_CODE and 
							a.sol_id=b.sol_id and 
							a.LOCKER_TYPE = b.LOCKER_TYPE
							and a.rent_period = b.rent_period
							and b.RENT_EFFECTIVE_DATE =(select max(c.rent_effective_date)
                                                                        		from clrm c
                                                                        		where b.sol_id = c.sol_id and
                                                                        		b.locker_type = c.locker_type and
                                                                        		b.location_code = c.location_code and
                                                                        		b.Rent_period = c.Rent_period and
                                                                        		c.rent_effective_date <= (select db_stat_date from gct)))
			and a.LOCATION_CODE = f1.LocCode
			and a.sol_id=v_sol_id
			and a.rent_period = '1'
			and a.LOCKER_TYPE = f1.locker_type;
			Exception when no_data_found then
			BEGIN
				select 	a.rent_amt
				INTO v_rent_amt1
				from clrm a
				where a.RENT_VERSION_CODE =(select max(b.RENT_VERSION_CODE) 
							from clrm b 
							where a.LOCATION_CODE =b.LOCATION_CODE and 
							a.sol_id=b.sol_id and 
							a.LOCKER_TYPE = b.LOCKER_TYPE
							and a.rent_period = b.rent_period
							and b.RENT_EFFECTIVE_DATE =(select max(c.rent_effective_date)
                                                                        		from clrm c
                                                                        		where b.sol_id = c.sol_id and
                                                                        		b.locker_type = c.locker_type and
                                                                        		b.location_code = c.location_code and
                                                                        		b.Rent_period = c.Rent_period and
                                                                        		c.rent_effective_date <= (select db_stat_date from gct)))
				and a.LOCATION_CODE = f1.LocCode
				and a.sol_id='0000'
				and a.rent_period = '1'
				and a.LOCKER_TYPE = f1.locker_type;
				Exception when no_data_found then
					v_rent_amt1:='0';
			END;
							
		END;
		
		BEGIN
			select 	a.rent_amt
			INTO v_rent_amt2
			from clrm a
			where a.RENT_VERSION_CODE =(select max(b.RENT_VERSION_CODE) 
							from clrm b 
							where a.LOCATION_CODE =b.LOCATION_CODE
							and a.sol_id=b.sol_id and a.LOCKER_TYPE = b.LOCKER_TYPE
							and a.rent_period = b.rent_period
							and b.RENT_EFFECTIVE_DATE =(select max(c.rent_effective_date)
                                                                        		from clrm c
                                                                        		where b.sol_id = c.sol_id and
                                                                        		b.locker_type = c.locker_type and
                                                                        		b.location_code = c.location_code 
											and b.Rent_period = c.Rent_period and
                                                                	      		c.rent_effective_date <= (select db_stat_date from gct)))
			and a.LOCATION_CODE = f1.LocCode
			and a.sol_id=v_sol_id
			and a.rent_period = '2'
			and a.LOCKER_TYPE = f1.locker_type;
			Exception when no_data_found then

			BEGIN
				select 	a.rent_amt
				INTO v_rent_amt2
				from clrm a
				where a.RENT_VERSION_CODE =(select max(b.RENT_VERSION_CODE) 
							from clrm b 
							where a.LOCATION_CODE =b.LOCATION_CODE
							and a.sol_id=b.sol_id and a.LOCKER_TYPE = b.LOCKER_TYPE
							and a.rent_period = b.rent_period
							and b.RENT_EFFECTIVE_DATE =(select max(c.rent_effective_date)
                                                                        		from clrm c
                                                                        		where b.sol_id = c.sol_id and
                                                                        		b.locker_type = c.locker_type and
                                                                        		b.location_code = c.location_code 
											and b.Rent_period = c.Rent_period and
                                                                	      		c.rent_effective_date <= (select db_stat_date from gct)))
				and a.LOCATION_CODE = f1.LocCode
				and a.sol_id='0000'
				and a.rent_period = '2'
				and a.LOCKER_TYPE = f1.locker_type;
				Exception when no_data_found then
				v_rent_amt2:='0';
			END;
									
		END;
		
		BEGIN
			select 	a.rent_amt
			INTO v_rent_amt3
			from clrm a
			where a.RENT_VERSION_CODE =(select max(b.RENT_VERSION_CODE) 
							from clrm b 
							where a.LOCATION_CODE =b.LOCATION_CODE
							and a.sol_id=b.sol_id and a.LOCKER_TYPE = b.LOCKER_TYPE
							and a.rent_period = b.rent_period
							and b.RENT_EFFECTIVE_DATE =(select max(c.rent_effective_date)
                                                                        		from clrm c
                                                                        		where b.sol_id = c.sol_id and
                                                                        		b.locker_type = c.locker_type and
                                                                        		b.location_code = c.location_code and
                                                                        		b.Rent_period = c.Rent_period and
                                                                        		c.rent_effective_date <= (select db_stat_date from gct)))
			and a.LOCATION_CODE = f1.LocCode
			and a.sol_id=v_sol_id
			and a.rent_period = '3'
			and a.LOCKER_TYPE = f1.locker_type;
			Exception when no_data_found then
			BEGIN
				select 	a.rent_amt
				INTO v_rent_amt3
				from clrm a
				where a.RENT_VERSION_CODE =(select max(b.RENT_VERSION_CODE) 
							from clrm b 
							where a.LOCATION_CODE =b.LOCATION_CODE
							and a.sol_id=b.sol_id and a.LOCKER_TYPE = b.LOCKER_TYPE
							and a.rent_period = b.rent_period
							and b.RENT_EFFECTIVE_DATE =(select max(c.rent_effective_date)
                                                                        		from clrm c
                                                                        		where b.sol_id = c.sol_id and
                                                                        		b.locker_type = c.locker_type and
                                                                        		b.location_code = c.location_code and
                                                                        		b.Rent_period = c.Rent_period and
                                                                        		c.rent_effective_date <= (select db_stat_date from gct)))
				and a.LOCATION_CODE = f1.LocCode
				and a.sol_id='0000'
				and a.rent_period = '3'
				and a.LOCKER_TYPE = f1.locker_type;
				Exception when no_data_found then
				v_rent_amt3:='0';
			END;
													
		END;
		--#####################################################
		-- To find Staff Discount value
		--#####################################################
		BEGIN
			SELECT staff_discount_method,staff_discount_value 
			INTO v_staff_disc_method,v_staff_disc_value 
			FROM WLCPM 
			WHERE sol_id=v_sol_id and 
			location_code= f1.LocCode and 
			locker_type=f1.locker_type and
			del_flg != 'Y' and 
			v_flg != 'N' and
			effective_from <= (select db_stat_date from gct);
			Exception when no_data_found then
			BEGIN
				SELECT a.staff_discount_method,a.staff_discount_value
                        	INTO v_staff_disc_method,v_staff_disc_value
                        	FROM WLCPMH a
                        	WHERE a.sol_id=v_sol_id and
                        	a.location_code= f1.LocCode and
                        	a.locker_type=f1.locker_type and
                        	a.del_flg != 'Y' and
                        	a.v_flg != 'N' and
                        	a.effective_from <= (select db_stat_date from gct) and
				a.lchg_time = (SELECT MAX(lchg_time) FROM wlcpmh b
						WHERE b.sol_id=a.sol_id AND
						a.location_code= b.location_code AND
						a.locker_type=b.locker_type AND
						b.del_flg != 'Y' AND
					        b.v_flg!='N');		
                        	Exception when no_data_found then
				BEGIN
					SELECT staff_discount_method,staff_discount_value
                        		INTO v_staff_disc_method,v_staff_disc_value
                        		FROM WLCPM
                        		WHERE sol_id='0000' and
                        		location_code= f1.LocCode and
                        		locker_type=f1.locker_type and
                        		del_flg != 'Y' and
                        		v_flg != 'N' and
                        		effective_from <= (select db_stat_date from gct);
                        		Exception when no_data_found then
					BEGIN
						SELECT a.staff_discount_method,a.staff_discount_value
                        			INTO v_staff_disc_method,v_staff_disc_value
                        			FROM WLCPMH a
                        			WHERE a.sol_id='0000' and
                        			a.location_code= f1.LocCode and
                        			a.locker_type=f1.locker_type and
                        			a.del_flg != 'Y' and
                        			a.v_flg != 'N' and
                        			a.effective_from <= (select db_stat_date from gct) and
					        a.lchg_time = (SELECT MAX(lchg_time) FROM wlcpmh b
                                                		WHERE b.sol_id=a.sol_id AND
                                                		a.location_code= b.location_code AND
                                                		a.locker_type=b.locker_type AND
                                                		b.del_flg != 'Y' AND
                                                		b.v_flg!='N');			
                        			Exception when no_data_found then
						v_staff_disc_method := '0';
						v_staff_disc_value := 0;
					END;
				END;
			END;
		END;	 	
		IF (v_rent_amt1 <> 0) AND (v_rent_amt2 <> 0) AND (v_rent_amt3 <> 0) AND (v_staff_disc_method <>'0') AND (v_staff_disc_value <> 0) THEN 
		
		DBMS_OUTPUT.PUT_LINE (f1.LocCode		||'|'||
					f1.rack_id 		||'|'||
					f1.locker_type		||'|'||
					f1.size_of_locker       ||'|'||	
					v_staff_disc_method     ||'|'||
					v_staff_disc_value      ||'|'||
					v_rent_amt1 		||'|'||
					v_rent_amt2 		||'|'||
					v_rent_amt3);
		END IF;
	END LOOP;
END;	   			
/
spool off

