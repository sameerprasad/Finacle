REM####################################################################
REM File Name   : fxb_orm_custom_k.sql
REM Description : orm upload custom table
REM Author      : Paresh Maru
REM Date        : 24-04-2013
REM Module	: ORM UPLOAD
REM####################################################################

REM TABLE NAME: fxb_orm_custom_k

REM SYNONYM:    fxb_orm_custom_k

drop table icici.fxb_orm_custom_k
/
drop public synonym fxb_orm_custom_k
/
create table icici.fxb_orm_custom_k
(
 BILL_ID                                            VARCHAR2(15),
 SOL_ID                                             VARCHAR2(8),
 BILL_CRNCY_CODE                                    VARCHAR2(3),
 OPER_ACCT                                          VARCHAR2(16),
 OPER_CHRG_ACCT                                     VARCHAR2(16),
 BILL_AMT                                           NUMBER(20,4),
 BILL_CNTRY_CODE                                    VARCHAR2(5),
 CORR_COLL_BANK_CODE                                VARCHAR2(6),
 CORR_COLL_BR_CODE                                  VARCHAR2(6),
 OTHER_PARTY_NAME                                   VARCHAR2(80),
 OTHER_PARTY_ADDR_1                                 VARCHAR2(45),
 OTHER_PARTY_ADDR_2                                 VARCHAR2(45),
 OTHER_PARTY_ADDR_3                                 VARCHAR2(45),
 PURPOSE_OF_REM                                     VARCHAR2(5),
 DRAWEE_BANK_NAME                                   VARCHAR2(80),
 DRAWEE_BANK_ADDR_1                                 VARCHAR2(45),
 DRAWEE_BANK_ADDR_2                                 VARCHAR2(45),
 DRAWEE_BANK_ADDR_3                                 VARCHAR2(45),
 DETAILS_BEN_OTH                                    VARCHAR2(10),
 FW_CNTR_DET                                        VARCHAR2(16),
 CONV_RATE                                          NUMBER(21,10),
 TRES_RATE                                          NUMBER(21,10),
 TRES_RATE_CODE                                     VARCHAR2(16),
 A56                                                VARCHAR2(35),
 A57                                                VARCHAR2(35),
 A70                                                VARCHAR2(35),
 A71                                                VARCHAR2(35),
 UPLOAD_STATUS                                      NUMBER(2),
 INPUT_FILE                                         VARCHAR2(35)
 SXR_NO                                             VARCHAR2(15),
 REG_TYPE                                           VARCHAR2(5),
 REG_SUB_TYPE                                       VARCHAR2(5),
 PASSPORT_DET                                       VARCHAR2(45)
)
/* STORE_START */
TABLESPACE ICICI_CUST_SMALL
/* STORE_END */
/
create public synonym fxb_orm_custom_k for icici.fxb_orm_custom_k
/
grant select, insert, update, delete on fxb_orm_custom_k to tbagen
/
grant select on fxb_orm_custom_k to tbacust
/
grant select on fxb_orm_custom_k to tbautil
/
grant all on fxb_orm_custom_k to tbaadm
/
create unique index IDX_fxb_orm_custom_k on fxb_orm_custom_k(BILL_ID, SOL_ID)
/
