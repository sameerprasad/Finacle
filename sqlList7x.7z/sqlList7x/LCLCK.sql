--##############################################################################################
--#                     File Name       : LCLCK.sql
--#                     Author : Arun Kumar (BBSSL)
--#                     Report : LOCKER LOCK UNLOCK REPORT
--#                     Date   :
--#                     Module  : LOCKER
--#                     Called Menu     : LOCKRPT
--#                     Called By       : LCLCK.com
--##############################################################################################

SET SERVEROUTPUT ON;
SET SERVEROUTPUT ON SIZE 1000000;
set trimspool on;
SET VERIFY OFF;
set echo off
set feedback off
set embedded off
set lines 10000
set head off
set pages 0
spool LCLCK.lst


SELECT	A.LOCKER_NUM						||'|'||
	B.CUST_ID						||'|'||
	C.CUST_NAME						||'|'||
	decode(A.STATUS,'U','UNFREEZE','F','FREEZE')		||'|'||
	A.LOCK_DATE						||'|'||
	A.LOCK_TIME						||'|'||
	A.UNLOCK_DATE						||'|'||
	A.ADVICE						||'|'||        
	A.LOCK_REASON						||'|'|| 
	A.UNLOCK_REASON
FROM WLCLCK A,CLMT B,CMG C
WHERE A.LOCKER_NUM = B.LOCKER_NUM
AND A.SOL_ID = B.SOL_ID
AND A.SOL_ID = '&1'
AND B.CUST_ID = C.CUST_ID
AND A.LOCK_DATE BETWEEN to_date('&2','dd-mm-yyyy') AND to_date('&3','dd-mm-yyyy')
AND A.STATUS in ('&4','&5')
AND A.ENTITY_CRE_FLG <> 'N'
AND A.DEL_FLG <> 'Y'
ORDER BY A.LOCKER_NUM
/

spool off
