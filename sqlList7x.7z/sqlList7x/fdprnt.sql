rem This script is written by K.S.Seshadri during the audit of Calcutta Br
rem on 29.2.1996
rem Script takes set_id as input

set echo off
set pagesize 60
set linesize 132
set newpage 0
set termout off
set feedback off
set trimspool on
set verify off

column today new_value today_date
select to_char(sysdate,'dd/mm/yyyy') today from dual;

column setid new_value solset
column soldesc new_value solname 
column solid new_value sole

select sol.sol_id solid,sol.sol_desc soldesc, sst.set_id setid
from sol, sst
where sol.sol_id=sst.sol_id
and set_id='&1';

column a heading 'A/C NUM' 
column b heading 'INVENT| NUM' format 999999
column c heading 'AMOUNT OF DEPOSIT' format 99,99,99,999.99
column d heading 'PRINTED DATE'    
column e heading 'PRINT|COUNT' format 99999
column f heading 'PRINTED USER' format a15
column g heading 'DEP|ST' 

ttitle center 'DETAILS OF TDRs PRINTED MORE THAN ONCE' skip 1 -
center ' SOLSET ' solset skip 1 -
center ' SOLNAME ' solname skip 1 -
center ' ------------------- ' skip 1 -
right 'PAGE :   ' format 99 sql.pno skip 1 -
right 'Date : ' today_date skip 1 -

break on solid
break on soldesc skip page on report

spool fdprnt.&1

select sol.sol_desc soldesc,gam.foracid a, drt.srl_num b, tam.deposit_amount c, drt.printed_date d, drt.print_count e, drt.last_printed_user_id f, tam.deposit_status g
from gam, tam, sol,drt
where tam.acid = gam.acid
and drt.acid=gam.acid
and drt.print_count > 1
and gam.sol_id in (select sol_id from sst where set_id = '&1')
and sol.sol_id=gam.sol_id
order by 1,2

/

spool out
spool off
exit
