set head off
set feedback off
set verify off
set linesize 5
set pagesi 0
spool ALL.list
select sol_id from sol where sol_id not in ('0266','0407','0447','1041')
/
spool off
exit
