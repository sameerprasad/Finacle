alter session set nls_date_format='dd-mm-yyyy';
rem accept 1 prompt 'ENTER REPORT DATE IN DD-MON-YY FORMAT  :  '
accept a prompt 'ENTER START ATM TRAN-ID  :  '
accept b prompt 'ENTER END ATM TRAN-ID  :  '
accept dt prompt 'ENTER DATE OF LAST ATM EOD IN DD-MM-YYYY FORMAT : '
accept atmno prompt 'ENTER THE ATM NO (002 FOR FIRST ATM 004 FOR SECOND ATM) :'
set echo off 
set termout off
set pause off

rem script for printing ATM initiated Xsactions.

set verify off
set feedback off
set linesize 132
set newpage 0
set pagesize 60
set space 1
set wrap off
set echo off

column rpt_time new_value dt1
select to_char(sysdate,'HH:MM:SS') rpt_time from dual;

rem column atm_no new_value atm_num
rem select decode(&atmno,002,'MAIN BRANCH','NIIT') atm_no from dual;

column rpt_date new_value dt2
select to_char(sysdate,'dd-mm-yyyy') rpt_date from dual;

define all_dashes = '------------------------------------------------------------------------------------------------------------------------------------'

ttitle 'ATM ONLINE TRANSACTIONS REPORT FOR TRAN-ID BETWEEN &a AND &b for ATM AT ' atm_num skip 1 -
left dt1 -
right 'Page : ' format 999 sql.pno skip 1 -
right 'Date : ' dt2 skip 1 -
btitle left all_dashes

column tran_date heading 'Tran Date' format a10
column tran_id heading 'Tran Id' format a9
column tot_amt heading '' format B99,99,99,999.99
column tran_type heading 'Tran Type' format a16
column acct_id heading 'A/C Number' format a16
column dr heading 'Withdrawals' format b99,99,99,990.99
column cr heading 'Deposits' format b99,99,99,990.99
column recon heading Reconciled format a5
column Proc heading Processed format a9
column mesg heading 'ATM|Tran id' format a7
column rmks heading 'ATM Card No.' format a16

break on tran_type on report

compute sum of dr on tran_type
compute sum of dr on report
compute sum of cr on tran_type
compute sum of cr on report

spool atmcash
select 
	tran_date tran_date
	,tran_id
	,decode(cmd,'0100','Cash Withdrawal',
				'0350','Transfer',
				'0200','Cash Deposit',
				'0300','Reversal') tran_type
	,decode(cmd, '0100',d.foracid,
	'0200',c.foracid,
	'0300',c.foracid,
				'0350',decode(interchange_ptran_type, 
							'D',c.foracid,
							'C',d.foracid,
							d.foracid||' to '||c.foracid)) acct_id
	,decode(cmd, '0100',1,'0350',decode(interchange_ptran_type,'C',1,0),0)*tran_amt dr
	,decode(cmd,'0200',1,'0300',1,'0350',decode(interchange_ptran_type,'D',1,0),0)*tran_amt cr
	,decode (recon_mesg_flg, 'Y','Yes',
							 'N',' No') Recon
	,decode (processed_flg, 'N', ' No',
							'P', ' No',
							'D', 'Yes') Proc
,sno mesg,
decode(substr(decrypted_mesg,1,4),'0322',substr(decrypted_mesg,185,16),substr(decrypted_mesg,194,16)) rmks
from MQT,gam c,gam d,ssr
where sno between '000&a' and '000&b' and
cmd in('0100','0350','0200','0300') and
tran_date>='&dt' and
mqt.sds_id=(select sds_id from ssr) and
MQT.dr_acid=d.acid and
MQT.cr_acid=c.acid and
luno='&atmno'
order by cmd,mesg
/

rem spool off
ttitle off
btitle off
set pagesize 0 
set linesize 80 
undefine all_dashes

whenever sqlerror continue 
select '  ' from dual;
select '  ' from dual;
select 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx' from dual;
select '  ' from dual;
select 'Number of Transactions During This Period',count(*) from MQT where 
sno between '000&a' and '000&b' and
cmd in('0100','0350','0200','0300') and 
tran_date >= '&dt' and
luno='&atmno'
/
select '  ' from dual;
select 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx' from dual;
set termout on
set feedback on
set verify on
set heading on
clear breaks
spool off
exit
