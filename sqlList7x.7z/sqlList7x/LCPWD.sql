Rem     This file will create LOCKER_PASSWORD_TABLE
Rem     with the following characteristics.

Rem     Coded by : Mariappan (BBSSL)

Rem     Module  : LOCKER


Rem TABLE NAME: LOCKER_PASSWORD_TABLE

Rem SYNONYM:    LOCKER_PASSWORD_TABLE

drop table icici.LOCKER_PASSWORD_TABLE
/
drop public synonym LCPWD
/
create table icici.LOCKER_PASSWORD_TABLE
( 
	sol_id varchar2(8),
	locker_number varchar2(12),
	password RAW(70),
	lchg_user_id varchar2(15),
	lchg_time date,
	rcre_user_id varchar2(15),
	rcre_time date,
	del_flg char(1)
)
/
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
create public synonym LCPWD for icici.LOCKER_PASSWORD_TABLE
/
create index IDX_LCPWD on icici.LOCKER_PASSWORD_TABLE( SOL_ID,LOCKER_NUMBER )
/
grant select, insert, update, delete on LCPWD to tbagen
/
grant select on LCPWD to tbacust
/
grant select on LCPWD to tbautil
/
grant all on LCPWD to tbaadm
/
