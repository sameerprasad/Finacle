set serveroutput on
set pages 0
set verify off
set feedback off
set termout off
set lines 200
set trimspool on
spool /tmp/mt942_seq.lst
DECLARE
noDays      NUMBER(10);
begin

SELECT MT942_NUM_SEQ.nextval INTO noDays from dual;
dbms_output.put_line(noDays);

end;
/
spool off
