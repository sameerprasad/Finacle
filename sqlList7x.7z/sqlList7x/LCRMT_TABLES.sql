Rem     This file will create RACK_ID_TRANSFER_MAINTENENCE_MOD Table
Rem     with the following characteristics.

Rem     Coded by : Priscilla.M (BBSSL)

Rem     Module  : LOCKER

Rem TABLE NAME: RACK_ID_TRANSFER_MAINTENENCE_MOD

Rem SYNONYM:    WLCRMT


drop table icici.RACK_ID_TRAN_MAIN
/
drop public synonym WLCRMT
/
create table icici.RACK_ID_TRAN_MAIN
(
        SOL_ID1          VARCHAR2(8),
        RACK_ID         VARCHAR2(3) NOT NULL,
        START_NO        NUMBER (5),
        END_NO          NUMBER (5),
        SOL_ID2         VARCHAR2(8),
        STATUS          CHAR(1),
        DEL_FLG         CHAR(1),
        ENTITY_CRE_FLG  CHAR(1),
        LCHG_USER_ID    VARCHAR2(15),
        LCHG_TIME       DATE,
        RCRE_USER_ID    VARCHAR2(15),
        RCRE_TIME       DATE,
        REMARKS         VARCHAR2(40),
        MANUFACT_NAME   VARCHAR2(40)
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
create public synonym WLCRMT for icici.RACK_ID_TRAN_MAIN
/
grant select, insert, update, delete on WLCRMT to tbagen
/
grant select on WLCRMT to tbacust
/
grant select on WLCRMT to tbautil
/
create unique index idx_WLCRMT_main on WLCRMT(SOL_ID1,RACK_ID)
/
grant all on WLCRMT to tbaadm
/

--==========================================================

Rem     This file will create RACK_ID_TRANSFER_MAINTENENCE_MOD Table
Rem     with the following characteristics.

Rem     Coded by : Priscilla.M (BBSSL)

Rem     Module  : LOCKER

Rem TABLE NAME: RACK_ID_TRANSFER_MAINTENENCE_MOD

Rem SYNONYM:    WLCRMT_MOD

drop table icici.RACK_ID_TRAN_MAIN_MOD
/
drop public synonym WLCRMT_MOD
/
create table icici.RACK_ID_TRAN_MAIN_MOD
(
SOL_ID1		VARCHAR2(8),
RACK_ID		VARCHAR2(3) NOT NULL, 
START_NO  	NUMBER (5), 
END_NO    	NUMBER (5),
SOL_ID2		VARCHAR2(8),
STATUS		CHAR(1),
DEL_FLG		CHAR(1),
ENTITY_CRE_FLG  CHAR(1),
LCHG_USER_ID    VARCHAR2(15),
LCHG_TIME       DATE,
RCRE_USER_ID    VARCHAR2(15),
RCRE_TIME       DATE,
REMARKS         VARCHAR2(40),
MANUFACT_NAME   VARCHAR2(40)
)
/
create public synonym WLCRMT_MOD for icici.RACK_ID_TRAN_MAIN_MOD
/
grant select, insert, update, delete on WLCRMT_MOD to tbagen
/
grant select on WLCRMT_MOD to tbacust
/
grant select on WLCRMT_MOD to tbautil
/
grant all on WLCRMT_MOD to tbaadm
/
