--Date 29-07-08 Sanjay K Jain for CIB migration - STR 6669
set feedback off
set verify off
set termout off
set echo off
set lines 400
alter session set nls_date_format = 'DD-MM-YYYY';
set serveroutput on size 1000000;

DECLARE
dummy varchar2(3);
sol1	varchar2(8);
facid gam.foracid%type;
ofacid gam.foracid%type;
nreflg varchar2(10);
gacid  gam.acid%type;
modecode gam.mode_of_oper_code%type;
acp varchar2(2);
acn varchar2(9);
custid gam.cust_id%type;
opendate gam.acct_opn_date%type;
valdate gam.acct_opn_date%type;
matdate gam.acct_opn_date%type;
periodmonth varchar2(3);
perioddays varchar2(3);
formatdepamt varchar2(17);
depamt number(17,2);
formatmatamt varchar2(17);
matamt number(17,2);
formatbal varchar2(17);
depstatus varchar2(1);
lienflag varchar2(1);
safecustflag varchar2(1);
ledger varchar2(3);
roi varchar2(7);
printflag varchar2(1);
sex varchar2(1);
title varchar2(5);
Name varchar2(80);
comaddr1 varchar2(45);
comaddr2 varchar2(45);
ccity  cmg.cust_comu_city_code%type;
cstate  cmg.cust_comu_state_code%type;
scity  sol.city_code%type;
sstate sol.state_code%type;
city varchar2(25);
state varchar2(25);
pin varchar2(8);
modeofoper varchar2(25);
relatedacp varchar2(2);
relatedacn varchar2(9);
qo varchar2(9);
inf varchar2(9);
qoflg char(1) ;
infflg char(1) ;
phonenum varchar2(20);
faxnum varchar2(20);
bbrname varchar(40);
braddr1	varchar(40);
braddr2 varchar(40);
brcity varchar(40);
brstate varchar(40);
oldacid gam.acid%type;
oldforacid gam.foracid%type;
schmcode gam.schm_code%type; 
renewschmcode gam.schm_code%type; 
renewperdmonth varchar2(3);
renewperddays varchar2(3);


loc_fp                          utl_file.file_type;
loc_filename                    varchar2(200);
loc_filepath                    varchar2(100);
loc_filemode                    varchar(10);
CURSOR GAMMAIN IS
SELECT acid,substr(GAM.FORACID,5,2),
	to_number(substr(GAM.FORACID,7,6)),gam.foracid,
	GAM.CUST_ID,
	to_char(GAM.ACCT_OPN_DATE,'dd/mm/yyyy'),
	ltrim(to_char((GAM.CLR_BAL_AMT+GAM.UN_CLR_BAL_AMT),'999999,99,990.99')),
	ltrim(GAM.LEDG_NUM),
	nvl(mode_of_oper_code,'*'),sol_id,
	bct.br_name,
	nvl(substr(foracid,5,2),'NO'),
        nvl(substr(foracid,7,6),'NO'),
	gam.schm_code 
FROM GAM,bct
	where gam.acct_prefix in ('10','15','20')
and GAM.ACCT_OPN_DATE = (select db_stat_date from gct)
	and GAM.clr_bal_amt >0
  	and GAM.ACCT_CLS_FLG!= 'Y'
	and bct.br_code=substr(gam.sol_id,3,2)
	and bct.bank_code='ICI';
CURSOR TAMMAIN IS
Select  to_char(tam.open_effective_date,'dd/mm/yyyy'),
	to_char(TAM.MATURITY_DATE,'dd/mm/yyyy'),
	ltrim(to_char(TAM.DEPOSIT_PERIOD_MTHS,'990')),
	ltrim(to_char(TAM.DEPOSIT_PERIOD_DAYS,'990')),
	ltrim(to_char(TAM.PERD_MTHS_FOR_AUTO_RENEW,'990')),
	ltrim(to_char(TAM.PERD_DAYS_FOR_AUTO_RENEW,'990')),
	ltrim(to_char(TAM.DEPOSIT_AMOUNT,'999999,99,990.99')),
	ltrim(TAM.DEPOSIT_AMOUNT),
	ltrim(to_char(TAM.MATURITY_AMOUNT,'999999,99,990.99')),
	ltrim(TAM.MATURITY_AMOUNT),
	nvl(TAM.DEPOSIT_STATUS,'.'),
	decode(ascii(TAM.safe_custody_flg),0,'Y','N'),
	nvl(TAM.printing_flg,'.'),
	TAM.AUTO_RENEWAL_SCHM_CODE
FROM TAM
WHERE
	(TAM.AUTO_RENEWAL_FLG in ('U','L')
		OR TAM.SAFE_CUSTODY_FLG='Y')
	and TAM.PRINTING_FLG='N'
	AND TAM.ACID=GACID;
BEGIN --{
open gammain; --{
	loc_filepath := '&1';
        loc_filename := 'autoren.lst';
        loc_filemode := 'w';
        loc_fp := utl_file.fopen(loc_filepath, loc_filename, loc_filemode);
begin --{
loop --{
BEGIN --{
Fetch gammain into gacid,acp,acn,facid,custid,opendate,formatbal,ledger,modecode,sol1,bbrname,
relatedacp,relatedacn,schmcode;
exit when gammain%notfound;
END; --}
BEGIN --{
	select nvl(related_acid,'NO') into oldacid 
	from tam 
	where acid=gacid; 
	exception 
	when no_data_found then
	oldacid:='NO';	
END; --}
BEGIN --{
	select nvl(foracid,'NO') into oldforacid 
	from gam 
	where acid=oldacid; 
	exception 
	when no_data_found then
	oldforacid:='NO';	
END; --}
BEGIN --{
open tammain; --{
begin --{
loop --{
begin --{
fetch tammain into valdate,matdate,periodmonth,perioddays,renewperdmonth,renewperddays,
formatdepamt,depamt,formatmatamt,matamt,depstatus,safecustflag,printflag,renewschmcode;
exit when tammain%notfound;
END; --}
BEGIN --{
select ltrim(to_char(TDT.int_pcnt,'990.99')) into roi
FROM TDT
WHERE tdt.acid = gacid
	and tdt.srl_num = (select max(d.srl_num) from tdt d
			where d.acid = gacid
			and d.flow_code in('II','IO'));
END; --}
BEGIN --{
nreflg:='NONNRE';
select a.cust_sex,a.cust_title_code,a.cust_name,a.cust_comu_addr1,
	nvl(a.cust_comu_addr2,'.'),nvl(ltrim(a.cust_comu_pin_code),'.'),
	nvl(a.cust_comu_city_code,'*'),nvl(a.cust_comu_state_code, '*')
	into sex,title,name,comaddr1,comaddr2,pin,ccity,cstate
from CMG a
where a.cust_id = custid
and cust_nre_flg='N';
exception
when no_data_found then
nreflg:='NRE';
end; --}
begin --{
select x.ref_desc into city
from rct x where
	x.ref_rec_type = '01'
	and x.ref_code =ccity ;
exception
when no_data_found then
city:='*';
end; --}
begin --{
select y.ref_desc into state
from rct y where
y.ref_rec_type = '02'
and y.ref_code = cstate;
exception
when no_data_found then
state:='*';
end; --}
begin --{
select z.ref_desc into modeofoper
from rct z where
z.ref_rec_type = '27'
and z.ref_code = modecode;
exception
when no_data_found then
modeofoper:='*';
end; --}
BEGIN --{
	qoflg := 'Y';
	select ffd_acid into qo from ffl
	where ffd_acid = gacid;
	EXCEPTION
WHEN no_data_found then
	qoflg := 'N';
END; --}
BEGIN --{
	infflg := 'Y';
	SELECT  'Y' INTO infflg FROM dual where exists(select '1' from bdt where cust_id = custid);
	EXCEPTION
WHEN no_data_found then
	infflg := 'N';
END; --}
BEGIN --{
	select sol.addr_1,sol.addr_2,sol.city_code,sol.state_code
	into braddr1,braddr2,scity,sstate from sol
	where sol.sol_id = sol1;
exception
WHEN no_data_found then
	braddr1:='NO ADDR1';
	braddr2:='NO ADDR2';
	scity:='NO CITY';
	sstate:='NO STATE';
end; --}
begin --{
	select a.ref_desc
	into brcity
	from rct a
	where
	a.ref_code =scity
	and a.ref_rec_type = '01';
exception
WHEN no_data_found then
	brcity:='NO BR CITY';
end; --}
begin --{
	select b.ref_desc
        into brstate
        from rct b
        where
	b.ref_code = sstate
	and b.ref_rec_type = '02';
exception
WHEN no_data_found then
        brstate:='NO BR STATE';
end; --}
if ( nreflg = 'NONNRE' ) then
UTL_FILE.PUT_LINE(loc_fp,acp||'|'||acn||'|'||facid||'|'||custid||'|'||opendate||'|'|| valdate||'|'||matdate||'|'||periodmonth||'|'||perioddays||'|'||formatdepamt||'|'||depamt||'|'||formatmatamt||'|'||matamt||'|'||formatbal||'|'||depstatus||'|'||safecustflag||'|'||ledger||'|'||roi||'|'||printflag||'|'||sex||'|'||title||'|'||name||'|'||comaddr1||'|'||comaddr2||'|'||city||'|'||state||'|'||pin||'|'||modeofoper||'|'||relatedacp||'|'||relatedacn||'|'||oldforacid||'|'||qoflg||'|'||infflg||'|'||bbrname||'|'||braddr1||'|'||braddr2||'|'||brcity||'|'||brstate||'|'||schmcode||'|'||renewschmcode||'|'||renewperdmonth||'|'||renewperddays);
end if;
end loop; --}
end; --}
close tammain; --}
end; --}
END LOOP; --}
END; --}
close gammain; --}
utl_file.fclose(loc_fp);
END; --}
/
