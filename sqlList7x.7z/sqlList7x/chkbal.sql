rem set echo off 
Rem set termout off
set pause off

rem script for finding A/C numbers having less than the min balance in GAM

set verify off
set feedback off
set linesize 80
set newpage 0
set pagesize 60
set space 1
set wrap on
set echo off

define all_dashes = '------------------------------------------------------------------------'

set heading off
column today new_value today_date
select to_char(sysdate, 'dd/mm/yyyy') today
from   dual 
/
set heading on
ttitle center 'CARD HOLDERS HAVING A/C BALANCES LESS THAN THE REQD BALANCE' skip 1 -
left 'Date : ' today_date -
right 'Page : ' format 999 sql.pno skip 1 -
btitle left all_dashes

column brName new_value brname
select br_name brName from bct,sol where
sol_id = '&1' and
sol.br_code = bct.br_code;

ttitle center  'ICICI BANK LIMITED , ' brname skip 1 -
column sol heading 'SOL ID' format a8
column id heading '     CARD NUMBER' format a16
column acct_id heading 'A/C NUMBER' format a16
column curr heading 'CURRENT A/C BAL' justify right format B999,99,99,99,999.99
column expt heading 'MINIMUM BAL REQD' justify right format B999,99,99,99,999.99


spool chkbal.log
select 
A.sol_id sol,
B.consid id,
A.foracid acct_id,
A.clr_bal_amt curr,
B.min_balance expt
from CAR B,GAM A
where
B.acid = A.acid and
B.min_balance >= A.clr_bal_amt and
B.del_flg ='N' and
B.entity_cre_flg ='Y'
order by A.sol_id,A.acid,A.clr_bal_amt
/

spool off
ttitle off
btitle off
undefine all_dashes

whenever sqlerror continue 
set termout on
set feedback on
set verify on
set heading on
clear breaks
exit
