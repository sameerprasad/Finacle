clear scr
accept solid prompt 'ENTER SOL ID FOR WHICH REPORT REQD  : '
accept y prompt ' Enter Acct_prefix    			 : ' 
accept 1 prompt 'Enter From Date (DD-MON-YYYY): '
accept 2 prompt 'Enter To Date (DD-MON-YYYY-max upto last eod date)	 : '

rem SCRIPT FOR TURNOVER DETAILS FOR INDIVIDUAL / ALL ACCOUNTS  
rem THIS CANNOT BE USED FOR TODAYS TRANSACTIONS / CAN BE USED AFTER EOD 
rem AUTHOR : Mukesh Kumar Jain / V.V.Sundar 
rem Version 1 of 12-01-1996 and modified by Sundar on 21/7/99.
set pagesi 60
set linesi 80
set newpage 0
set verify off
set termout off
set feedback off
break on  report

break on report
compute sum of debit credit on report
col debit heading DEBITS   format B99,99,999
col credit heading CREDITS format B99,99,999
col account heading ACCOUNT format a12
col name heading NAME format a40 trunc

column today new_value today_date
select to_char(sysdate, 'DD-MM-YY:HH24:MI:SS') today
from dual;
 
column br new_value branch 
select br_name br from bct
where br_code=(select br_code from sol where sol_id = '&solid');

ttitle center 'ICICI BANK LTD ' skip 1 -
center branch 'Branch ' skip 1 -
center ' ACCOUNT TURNOVER DETAILS FROM &1 TO &2'  skip 1 -
left 'DATE :' today_date right 'RS.in LACS' skip1

spool actnvr16

select gam.foracid ACCOUNT,gam.acct_name NAME,
sum((decode(part_tran_type,'D',1,0))*tran_amt)/100000  debit ,
sum((decode(part_tran_type,'D',0,1))*tran_amt)/100000  credit 
from gam,ctd
where ctd.sol_id='&solid'
and substr(gam.foracid,5,2) ='&y'
and tran_date between to_Date('&1','DD-MON-YYYY') and to_Date('&2','DD-MON-YYYY')
and gam.sol_id=ctd.sol_id
and ctd.acid=gam.acid
group by gam.foracid,gam.acct_name   
order by gam.foracid
/
spool off
exit
