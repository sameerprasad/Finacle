REM####################################################################
REM File Name   : ICI_ANYWHERE_AMT_LIMIT.sql
REM Description : Any where Transaction
REM Author      : Paresh Maru
REM Date        : 11-05-2011
REM Module	: Anywhere Tran
REM####################################################################

REM TABLE NAME: ICI_ANYWHERE_AMT_LIMIT

REM SYNONYM:    ICI_ANYWHERE_AMT

drop table icici.ICI_ANYWHERE_AMT_LIMIT
/
drop public synonym ICI_ANYWHERE_AMT
/
create table icici.ICI_ANYWHERE_AMT_LIMIT
(
ACCOUNT_NUMBER     VARCHAR2(16),
AMOUNT_LIMIT_DR    NUMBER(20,4),
AMOUNT_LIMIT_CR    NUMBER(20,4),
ENTITY_CRE_FLG     CHAR(1),
DEL_FLG            CHAR(1),
LCHG_USER_ID       VARCHAR2(15),
LCHG_TIME          DATE,
RCRE_USER_ID       VARCHAR2(15),
RCRE_TIME          DATE
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
create public synonym ICI_ANYWHERE_AMT for icici.ICI_ANYWHERE_AMT_LIMIT
/
grant select, insert, update, delete on ICI_ANYWHERE_AMT to tbagen
/
grant select on ICI_ANYWHERE_AMT to tbacust
/
grant select on ICI_ANYWHERE_AMT to tbautil
/
grant all on ICI_ANYWHERE_AMT to tbaadm
/
create unique index IDX_ICI_ANYWHERE_AMT on ICI_ANYWHERE_AMT(ACCOUNT_NUMBER)
/
