set echo off
set termout off
set pause off

rem script for printing transactions in IBR Originating Accounts
rem author M K JAIN
rem version 1.0 dated 23-06-1995
rem version 1.1 dated 23-12-1995 added Inter Branch DDs 

set verify off

whenever sqlerror exit sql.sqlcode
rem set feedback off
set linesize  132
set pages 66
set newpage 0
set space 0
define all_dashes = '_____________________________________________________________________________'
column today new_value today_date
column bran new_value br

select to_char(db_stat_date,'dd/mm/yyyy') today from gct;

select br_name bran from bct
where br_code = (select br_code from sol where sol_id='&1');


spool /tmp/ibrplus

ttitle '  '  skip 1 -
left   '           ' br  skip 1 -
left   '           ____________________________________________________________' skip 2 -
center  ' IBR TRANSACTIONS ON  ' today_date  - 
right 'Page :       ' format 999 sql.pno skip 1  -
left all_dashes  skip 1  

btitle left 'Date : ' today_date skip 1 -
right 'Authorised Signatory'

set space 1

col B heading 'Tran #' Format a11
col C heading 'Particulars and Remarks' format a30 
Col E heading 'Debit'  Justify Right format B99999999,99,99,999.99
Col F heading 'Credit' Justify Right format B99999999,99,99,999.99
col G heading 'ACCT #' format a9
col TYPE   format a4
rem break on ref_num skip page on report
break on G skip 2  on report
compute sum of E F on G
compute sum of E F on report

select
	ltrim(gam.foracid) G,
	dtd.tran_id||'/'||dtd.part_tran_srl_num B,
	rpad(dtd.tran_particular,30)||rpad(dtd.tran_rmks,30) C,
	hoc.ho_tran_type type,
	(dtd.tran_amt * decode(dtd.part_tran_type,'D',1,0)) E,
	(dtd.tran_amt * decode(dtd.part_tran_type,'C',1,0)) F
from hoc,DTD,gam
where gam.sol_id = '&1'
and dtd.acid = gam.acid
	and substr(gam.foracid,3,6) = upper('IBIBIT')
	and dtd.tran_date = (select db_stat_date from gct)
	and dtd.del_flg != 'Y'
	and dtd.pstd_flg = 'Y'   
	and hoc.sol_id = '&1'
	and hoc.tran_id = dtd.tran_id
	and hoc.part_tran_srl_num = dtd.part_tran_srl_num
	and hoc.tran_date = dtd.tran_date
order by 1,2,3
/

ttitle off
btitle off
clear columns
clear breaks
clear computes

ttitle '  '  skip 1 -
left   '           ' br  skip 1 -
left   '           ____________________________________________________________' skip 2 -
center  ' INTER BRANCH DRAFTS ISSUED TRANSACTIONS ON  ' today_date  - 
right 'Page :       ' format 999 sql.pno skip 1  -
left all_dashes  skip 1  

btitle left 'Date : ' today_date skip 1 -
right 'Authorised Signatory'

col dd_num heading 'DD Num' format a8 
col b heading 'Br.Code - Name' format a20 trunc
col payee_name heading 'Payee Name' format a80
col dd_amt heading 'Amount (Cr)' format b99999999,999,999,999.99
break on report
compute sum of dd_amt on report

select dd_num, ddc.br_code||' '||br_name b, payee_name, dd_amt
from ddc, bct
where sol_id='&1'
and 
      trunc(tran_date)=(select trunc(db_stat_Date) from gct )
and   bct.bank_code='ICI'
and   ddc.br_code=bct.br_code
and   ddc.del_flg != 'Y'
/

REM DDD entries should also be picked ....

ttitle off
btitle off
clear columns
clear breaks
clear computes

ttitle '  '  skip 1 -
left   '           ' br  skip 1 -
left   '           ____________________________________________________________' skip 2 -
center  ' INTER BRANCH DRAFTS RESPONDED TRANSACTIONS ON  ' today_date  - 
right 'Page :       ' format 999 sql.pno skip 1  -
left all_dashes  skip 1  

btitle left 'Date : ' today_date skip 1 -
right 'Authorised Signatory'

col dd_num heading 'DD Num' format a8 
col b heading 'Br.Code - Name' format a20 trunc
col payee_name heading 'Payee Name' format a80
col dd_amt heading 'Amount (Dr)' format b99999999,999,999,999.99
break on report
compute sum of dd_amt on report

select dd_num, ddd.br_code||' '||br_name b, payee_name, dd_amt
from ddd, bct
where sol_id='&1'
and 
      trunc(tran_date)=(select trunc(db_stat_date) from gct )
and   bct.bank_code='ICI'
and   ddd.br_code=bct.br_code
and   ddd.del_flg != 'Y'
/

REM ---------------------------------------------------------------------- 

ttitle off
btitle off
clear columns
clear breaks
clear computes

ttitle '  '  skip 1 -
left   '           ' br  skip 1 -
left   '           ____________________________________________________________' skip 2 -
center  ' IBR TRANSACTIONS (SUMMARY) ON  ' today_date  - 
right 'Page :       ' format 999 sql.pno skip 1  -
left all_dashes  skip 1  

btitle left 'Date : ' today_date skip 1 -
right 'Authorised Signatory'

set space 1

col A heading 'TRAN #' format 9999
Col E heading 'Debit'  Justify Right format B99999999,99,99,999.99
Col F heading 'Credit' Justify Right format B99999999,99,99,999.99

break on report
compute sum of A E F on report

select
        'IBR TRANSACTIONS' Particulars,
	count(*) A,
	sum((dtd.tran_amt * decode(dtd.part_tran_type,'D',1,0))) E,
	sum((dtd.tran_amt * decode(dtd.part_tran_type,'C',1,0))) F
from hoc,DTD,gam
where gam.sol_id = '&1'
	and dtd.acid = gam.acid
	and substr(gam.foracid,3,6) = upper('IBIBIT')
	and ltrim(dtd.acct_num) != 'IBIT'
	and dtd.tran_date = (select db_stat_date from gct)
	and dtd.del_flg != 'Y'
	and dtd.pstd_flg = 'Y'   
	and hoc.sol_id = '00'
	and hoc.tran_id = dtd.tran_id
	and hoc.part_tran_srl_num = dtd.part_tran_srl_num
	and hoc.tran_date = dtd.tran_date
union
select 
       'DD ISSUED TRANS' Particulars,
	count(*) A,
	0 E,
        sum(dd_amt) F
from ddc, bct
where sol_id='&1'
and 
      trunc(tran_date)=(select trunc(db_stat_date) from gct) 
and   bct.bank_code='ICI'
and   ddc.br_code=bct.br_code
and   ddc.del_flg != 'Y'
union
select 
      'DD RESPONDED TRANS' Particulars,
      count(*) A,
      sum(dd_amt) E,
      0 F
from ddd, bct
where extn_cntr_code='00'
and 
      trunc(tran_date)=(select trunc(db_stat_date) from gct )
and   bct.bank_code='ICI'
and   ddd.br_code=bct.br_code
and   ddd.del_flg != 'Y'
/

REM ---------------------------------------------------------------------- 


ttitle off
btitle off
set termout on
set feedback on
set verify on
set heading on
clear breaks
clear computes
spool out
set echo on
exit
