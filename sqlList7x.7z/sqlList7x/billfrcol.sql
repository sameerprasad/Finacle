rem accept solid prompt 'PLEASE ENTER FOUR DIGIT SOL ID OF REPORT BRANCH : '
set feedback off
set termout off
set echo off
set verify off
set linesize 132
set pagesize 60
set numformat b999,99,99,99,99,99,999.99
break on bill_crncy_code
break on report
compute sum of INR on report
column br new_value bran
column dt new_value todate

select sysdate dt from dual;
select br_name br from bct where
br_code = (select br_code from sol); 

spool &1.billfrcol
column bill_crncy_code heading CURRENCY format a25
column bill_amt heading FC format 99,99,99,99,999.99
column bill_amt_inr heading INR format 99,99,99,99,999.99


ttitle center 'ICICI BANKING CORPORATION LIMITED' skip 1-
center bran 'BRANCH AS ON &todate' skip 3-
'INWARD BILLS' skip 2-

define all_dashes = '--------------------------------------------------------------------------------'
 
select bill_crncy_code CURRENCY,sum(bill_amt)FC ,sum(bill_amt_inr) INR from fbm
where fbm.reg_type in ('FIBC')
and fbm.cls_flg!='Y'
and fbm.bill_stat = 'G'
and fbm.sol_id = '&1'
group by bill_crncy_code;

ttitle off

ttitle 'OUTWARD BILLS' skip 2-

select bill_crncy_code CURRENCY,sum(bill_amt)FC ,sum(bill_amt_inr) INR from fbm
where fbm.reg_type in ('FOBC')
and fbm.cls_flg!='Y'
and fbm.bill_stat = 'G'
and fbm.sol_id = '&1'
group by bill_crncy_code
union
select bill_crncy_code CURRENCY,sum(bill_amt)FC ,sum(bill_amt_inr) INR from fbm
where fbm.reg_type in ('FOCC')
and fbm.reg_sub_type = 'CHQ'
and fbm.cls_flg!='Y'
and fbm.bill_stat = 'G'
and fbm.sol_id = '&1'
group by bill_crncy_code
/
spool off
exit
