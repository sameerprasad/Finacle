rem This script is to get the Total Term Deposit Amount linked to Operative 
rem account of the customer. This will be generated as part of the 
rem Fallback reports along with other reports.
rem This report should be used to check the Balances for Passing of Cheques
rem for FFD accounts.
rem Since the script is selecting the reserved amount field everytime it
rem checks for the Deposit account under a operative account, the reserved 
rem amount is divided by the count(*) to get the correct reserved amount.
rem V.V.Sundar	29th April 1997
rem Modified by Mukesh Kumar Jain to get the Fallback Reports
rem modified by V.V.Sundar to declude those deposit accounts which are not
rem to be broken + to show the correct reserved amount.
set pause off
set newpage 0
set pages 60
set linesi 132
set numformat B9999,99,99,99,999.00
set heading on
set feedback off
set echo off
set verify off
set termout off
break on cust_id on Oper_acct skip 2 on reserved on Name on report
compute sum of Deposit Balance on Oper_acct skip 1 
compute sum of Deposit Balance  on report
column today new_value todate
column solid new_value sol
column num_of_accts heading 'Num_of_Accts'
select to_char(sysdate,'DD-MON-YYYY') today from dual;
select br_name solid from bct where br_code =(select br_code from sol where sol_id='&1') and bank_code='ICI'; 
ttitle center ' ICICI BANK LIMITED ' skip 1-
center sol ' BRANCH ' skip 1-
center ' LIST OF ACCOUNTS WITH TOTAL AMOUNT OF LINKED FIXED DEPOSITS'skip 1-
left  ' Date : ' todate  skip 1

spool $ICICI_CUST_REP/ffdflbk.&1

select  g.foracid Oper_acct,
	substr(m.acct_name,1,15) Name,
	sum(g.lien_amt)/count(*) reserved,
	sum(deposit_amount) Deposit,sum(m.clr_bal_amt) Dep_Balance,
	count(*) num_of_accts
--from gam g,gam m,tam,ffl
from gam g,gam m,tam
where g.sol_id=m.sol_id
--and ffl.acid=g.acid
and tam.link_oper_account =g.acid
--and ffl.ffd_acid=tam.acid
--and ffl.ffd_acid=m.acid
and tam.acid=m.acid
--and ffl.del_flg!='Y'
and g.acct_cls_flg!='Y'
-- and regul_tod_in_oper_acct_flg='Y'
and g.sol_id = '&1'
group by m.cust_id,g.foracid,substr(m.acct_name,1,15)
order by 1
/
spool off
exit
