REM####################################################################
REM File Name   : WLSMM_MOD.sql
REM Description : Table creation for Locker Scheme Mapping Master-Verification
REM Author      : Ashwani Bhat (BBSSL)
REM Date        : 04-01-2010
REM Module	: LOCKER
REM####################################################################
drop table ICICI.LOC_SCHM_MAPP_MOD_TABLE
/
drop public synonym WLSMM_MOD
/
create table ICICI.LOC_SCHM_MAPP_MOD_TABLE
(
	SOL_ID			VARCHAR2(8),
	SCHEME_NAME		VARCHAR2(15),
	SCHEME_DESC		VARCHAR2(40),
	Disc_Based_On           VARCHAR2(25),
	APPLICABLE_SOLS		VARCHAR2(8),
	DEL_FLG       		CHAR(1),
	ENTITY_CRE_FLG		CHAR(1),
	LCHG_USER_ID  		VARCHAR2(15),
	LCHG_TIME     		DATE,
	RCRE_USER_ID  		VARCHAR2(15),
	RCRE_TIME     		DATE
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
CREATE INDEX IDX_ICICI.LOC_SCHM_MAPP_MOD_TABLE ON
ICICI.LOC_SCHM_MAPP_MOD_TABLE(SOL_ID,SCHEME_NAME,SCHEME_DESC,Disc_Based_On,APPLICABLE_SOLS)
/
CREATE unique INDEX UIDX_LOC_SCH_MAS_MOD_TABLE  ON
ICICI.LOC_SCHM_MAPP_MOD_TABLE(SOL_ID,SCHEME_NAME,DEL_FLG,Disc_Based_On,APPLICABLE_SOLS)
/
create public synonym WLSMM_MOD for ICICI.LOC_SCHM_MAPP_MOD_TABLE
/
grant select,insert,update,delete on WLSMM_MOD to tbagen
/
grant select on WLSMM_MOD to tbacust
/
grant select on WLSMM_MOD to tbautil
/
grant all on WLSM to tbaadm
/
