rem This script will generate Report on National Clearing Cheques
rem lodged under sub-reg_type of 'NCCC' or 'NCCP' of Bill Module
rem This report will generate according to requirements of CAT, Mumbai.

rem author  :: Narayan Rao, ICICI Infotech, Mumbai 

rem ******************************************************************
rem Input : Lodge Date
rem         Date Center Name

rem output : Sol-description 
rem          bill_id
rem          lodg_date
rem          bill_amt

rem ******************************************************************


accept dt1 prompt 'ENTER LODGE DATE FOR REPORT (DD-MM-YYYY) : '
accept dcnm prompt 'ENTER DATA CENTER NAME (IN CAPITAL LETTERS) : '
set termout off
set verify off
set echo off
set feedback off
set pages 60
set linesize 132 

column today new_value today_date
select to_char(sysdate, 'dd/mm/yyyy') today from  dual;

column spoolday newvalue spool_date
select to_char(lodg_date, 'ddmmyyyy') spoolday from blt
            where lodg_date='&dt1';




col sol_desc  heading 'BR. NAME' format a15
col city_name heading 'CITY' format a13 
col sol_id heading 'SOLID format a5
col bill_id heading 'OUR REF. NO'
col drawee_name heading 'DRAWEE BANK' format a15 word_wrap
col lodg_date heading 'LODGE DATE'
col doc_list1 heading 'CHEQUE DETAILS'
col bill_amt heading 'AMOUNT (IN Rs.)' format b999,99,99,999.99

break on city_name skip 3  on report skip 5   
compute sum LABEL "TOTAL AMOUNT" of bill_amt on city_name skip 2 
compute count LABEL 'NO.OF INSTR.' of lodg_date  on report skip 2
compute sum LABEL "GRAND TOTAL" of bill_amt on report

ttitle center 'ICICI BANK LIMITED' skip 1 -
center '&dcnm' ' DATA CENTER' skip 2 -
center 'REPORT ON NATIONAL CLEARING CHEQUES AS ON ' '&dt1'  skip 1 -
left 'DATE : ' today_date  right 'PAGE :     ' format 999 sql.pno  skip 2

btitle left 'AUTHORISED SIGNATORY' 




spool nclg.lst

 
select 
       city_name,
	   sol.sol_id,
	   sol_desc,
	   lodg_date,
	   Bill_id,
       drawee_name,
       bill_amt
	      from blt, bct, cty, sol
				where reg_sub_type in ('NCCC', 'NCCP') 
                      and lodg_date='&dt1'
					  and blt.lodg_coll_br_code=bct.br_code
					  and bct.br_city_code=cty.city_code
					  and cty.city_code in ('BBY', 'CAL', 'ND', 'MDS')
					  and bill_stat is not null
					  and blt.sol_id=sol.sol_id
                      and ltrim(rtrim(blt.sol_id)) in
						 ('0011', '0038', '0028', '0018', '0032',
							'0036', '0026', '0019', '0020', '0035', '0057', '0008')
					
						order by cty.city_name, blt.bill_id 



/




clear breaks
clear compute
clear columns
ttitle off
btitle off

ttitle center 'ICICI BANK LIMITED' skip 1 -
center '&dcnm' ' DATA CENTER' skip 2 -
   center 'CONSOLIDATED REPORT ON NATIONAL CLEARING CHEQUES AS ON ' '&dt1' -
									 skip 1 -
left 'DATE : ' today_date  right 'PAGE :     ' format 999 sql.pno  skip 2

break on city_name skip 2 on drawee_name


COLUMN city_name FORMAT A15 HEADING 'CITY'
COLUMN bill_amt FORMAT 999999999999.99 HEADING 'AMOUNT'
COLUMN drawee_name  FORMAT A30 HEADING 'DRAWEE BANK'

select
       city_name,
       drawee_name,
       count(bill_amt)  "NO.OF CHQS"  ,
       sum(bill_amt) AMOUNT
          from blt,bct,cty
            where reg_sub_type in ('NCCC', 'NCCP')
                  and lodg_date ='&dt1'
                  and blt.lodg_coll_br_code=bct.br_code
                  and bct.br_city_code=cty.city_code
                  and bill_stat is not null
                  and  ltrim(blt.sol_id) in ('0011', '0038', '0028', '0008' )
        group by city_name, drawee_name
/
spool off

clear breaks
clear compute
ttitle off
btitle off
set head on
set verify on
set termout on 
set trimspool off
