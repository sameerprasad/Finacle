set feedback off
set pages 0
set echo off
set termout off
set trims on
set lines 200 
set verify off
set serveroutput on size 1000000
set head off
set trimspool on

--spool &1-&2-&3..rpt
spool chrghist

DECLARE
fdate date;
tdate date;
tname ici_adt.table_name%type;

CURSOR csc_report IS
select table_key,rmks,mod_fields_data from ici_adt where 
table_name = tname and
to_date(audit_date,'DD-MM-YYYY') >= to_date(fdate,'DD-MM-YYYY') and
to_date(audit_date,'DD-MM-YYYY') <= to_date(tdate,'DD-MM-YYYY');

BEGIN

fdate:='&1';
tdate:='&2';
tname:='&3';

for cscreport in csc_report
loop
	dbms_output.put_line(ltrim(rtrim(cscreport.table_key))||'|'||ltrim(rtrim(cscreport.rmks))||'|'||ltrim(rtrim(cscreport.mod_fields_data)));
end loop;
exception when no_data_found then null;


END;
/

spool off
host chmod 777 chrghist.lst

exit
