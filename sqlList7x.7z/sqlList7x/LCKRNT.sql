--##############################################################################################
--#                     File Name       : LCKRNT.sql
--#                     Author : Ashwani Bhat (BBSSL)
--#                     Report : Locker Rent Report
--#                     Date   :
--#                     Module  : LOCKER
--#                     Called Menu     : LOCKRPT
--#                     Called By       : LCKRNT.com
--##############################################################################################
SET SERVEROUTPUT ON SIZE 1000000;
SET VERIFY OFF
SET TERMOUT OFF
SET TRIMSPOOL ON
SET ECHO OFF
SET FEEDBACK OFF
SET EMBEDDED ON
SET LINES 400
SET HEAD OFF
SET PAGES 0
clear columns
clear breaks
clear computes  
spool LCKRNT.lst

DECLARE
	solid			gam.sol_id%type:='&1';
	date1 			date:='&2';
	date2			date:='&3';
	v_issue_date		date;
	v_lock_num		clmt.locker_num%type;
	v_lock_size		clmt.locker_size%type;
	v_lock_type		clmt.locker_type%type;
	v_key_num		clmt.locker_key_num%type;
	v_cust_name		cmg.cust_name%type;
	v_oper_acnt		clmt.oper_acnt%type;
	v_pin_code		cmg.cust_comu_pin_code%type;
	v_cust_id		cmg.cust_id%type;
	v_addr1			cmg.CUST_COMU_ADDR1%type;
	v_addr2			cmg.CUST_COMU_ADDR1%type;
	v_state			cmg.CUST_COMU_ADDR1%type;
	v_city			cmg.CUST_COMU_ADDR1%type;
	city_name		cmg.CUST_COMU_ADDR1%type;
	state_name		cmg.CUST_COMU_ADDR1%type;
	v_oper_mode		clmt.operation_mode%type;
	v_due_date 		date;
	v_phone			cmg.CUST_COMU_PHONE_NUM_1%type;
	v_rent_amt		clmt.rent_amt%type;
	v_locker_period         clmt.locker_period%type;
	v_rent_from		date;
	v_last_tran_date	date;
	v_check_flg		varchar2(20) := '&4';

CURSOR c1 (solid gam.sol_id%TYPE,date1 DATE,date2 DATE) IS
SELECT	LOCKER_NUM,
	LOCKER_TYPE,
	LOCKER_KEY_NUM,
	LOCKER_PERIOD,
        ISSUE_DATE,
        CUST_ID,
        oper_acnt,
        due_date,
        disc_rent_amt,
	decode(RENEWAL_DATE,NULL,ISSUE_DATE,RENEWAL_DATE)
FROM clmt 
where sol_id = solid
and due_date between to_date(date1,'dd-mm-yyyy') and to_date(date2,'dd-mm-yyyy')
and DEL_FLG !='Y'
and ENTITY_CRE_FLG = 'Y'
order by due_date;

CURSOR c2 (solid gam.sol_id%TYPE,date1 DATE,date2 DATE) IS
SELECT	LOCKER_NUM,
	LOCKER_TYPE,
	LOCKER_KEY_NUM,
	LOCKER_PERIOD,
        ISSUE_DATE,
        CUST_ID,
        oper_acnt,
        due_date,
        disc_rent_amt,
	decode(RENEWAL_DATE,NULL,ISSUE_DATE,RENEWAL_DATE)
FROM clmt 
where sol_id = solid
and DEL_FLG !='Y'
and ENTITY_CRE_FLG = 'Y'
order by due_date;

BEGIN
--{
	--DBMS_OUTPUT.PUT_LINE(v_check_flg);
	if (v_check_flg = 'ALL') then
		OPEN c2(solid,date1,date2);
	else
		OPEN c1(solid,date1,date2);
	end if;
	
	LOOP
	--{
		if (c1%ISOPEN) then
			FETCH c1
			INTO	
			v_lock_num,
			v_lock_type,
			v_key_num,
			v_locker_period,
			v_issue_date,
			v_cust_id,
			v_oper_acnt,
			v_due_date,
			v_rent_amt,
			v_rent_from;
		end if;
		
		IF (c1%ISOPEN and c1%NOTFOUND) THEN
		--{
			CLOSE c1;
			EXIT;
		--}
		END IF;

		if (c2%ISOPEN) then
			FETCH c2
			INTO	
			v_lock_num,
			v_lock_type,
			v_key_num,
			v_locker_period,
			v_issue_date,
			v_cust_id,
			v_oper_acnt,
			v_due_date,
			v_rent_amt,
			v_rent_from;
		end if;
		
		IF (c2%ISOPEN and c2%NOTFOUND) THEN
		--{
			CLOSE c2;
			EXIT;
		--}
		END IF;
				
		BEGIN
		--{
			SELECT  cust_name,
				cust_comu_addr1,
		                cust_comu_addr2,
			        CUST_COMU_CITY_CODE,
				cust_comu_state_code,
	                        CUST_COMU_PIN_CODE,
		                CUST_COMU_PHONE_NUM_1
				INTO    v_cust_name,
				v_addr1,
	                        v_addr2,
		                v_city,
			        v_state,
				v_pin_code,
	                        v_phone
		        FROM    cmg
			WHERE   cust_id=v_cust_id;
	                Exception when no_data_found then
		        	v_cust_name:=null;
				v_addr1:=null;
                		v_addr2:=null;
	                	v_state:=null;
		        	v_city:=null;
				v_pin_code:=null;
                		v_phone :=null;
		--}
	        END;
	
		BEGIN
		--{
	                SELECT  ref_desc
	                INTO    city_name
	                FROM    rct
	                WHERE   ref_code=v_city
	                AND     ref_rec_type='01';
	                Exception when no_data_found then
	                city_name:=null;
		--}
	        END;
	
	        BEGIN
		--{
	                SELECT  ref_desc
	                INTO    state_name
	                FROM    rct
	                WHERE   ref_code=v_state
	                AND     ref_rec_type='02';
	                Exception when no_data_found then
	                state_name:=null;
		--}
	        END;

		BEGIN
		--{
			SELECT max(tran_date)
			INTO v_last_tran_date
			FROM lcpd
			where SOL_ID = solid
			and LOCKER_NUMBER = v_lock_num
			and CUST_ID = v_cust_id
			and DEL_FLG = 'N'
			and REMARKS like 'LOCKER%RENT%';
		--}
		END;
	   	
		DBMS_OUTPUT.PUT_LINE(	v_lock_num	||'|'||
					v_lock_type	||'|'||
					v_key_num	||'|'||
					v_locker_period ||'|'||
					v_issue_date	||'|'||
					v_cust_name	||'|'||
					v_oper_acnt	||'|'||
					v_rent_amt	||'|'||
					v_due_date	||'|'||
					v_addr1		||'|'||
					v_addr2		||'|'||
					city_name	||'|'||
					state_name	||'|'||
	   				v_pin_code	||'|'||
	   				v_phone		||'|'||
					v_rent_from	||'|'||
					v_last_tran_date);
	--}			
	END LOOP;					
--}	   			
END;	   			
/
spool off

