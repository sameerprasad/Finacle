--##############################################################################################
--#                     File Name       : LCKRMDNO.sql
--#                     Author : Ashwani Bhat (BBSSL)
--#                     Report : LOCKER REMINDER - LOCKNO REPORT
--#                     Date   :
--#                     Module  : LOCKER
--#                     Called Menu     : LOCKRPT
--#                     Called By       : LCKRMDNO.com
--##############################################################################################

CREATE OR REPLACE PACKAGE LCKRMDNO AS
	PROCEDURE LCKRMDNO(	inp_str IN VARCHAR2,
				out_retCode OUT NUMBER,
				out_rec OUT VARCHAR2);
				
END	LCKRMDNO;
/
CREATE OR REPLACE PACKAGE BODY LCKRMDNO	AS
	v_sol_id		sst.set_id%type;
	date1 			date;
	v_issue_date		date;
	LockNo			clmt.locker_num%type;
	v_locker_num		clmt.locker_num%type;
	v_cust_name		cmg.cust_name%type;
	v_due_date		date;
	v_locker_period		clmt.locker_period%type;
	v_cust_id		cmg.cust_id%type;
	v_addr1			cmg.CUST_EMP_ADDR1%type;
	v_addr2			cmg.CUST_EMP_ADDR1%type;
	v_state			cmg.CUST_EMP_ADDR1%type;		
	v_phone			varchar2(15);
	v_pin_code		varchar2(15);
	v_city			varchar2(45);
	v_cntry			varchar2(45);
	v_locker_type		clmt.locker_type%type;
	v_loc_code1		wlcpm.LOCATION_CODE%type;
	v_loc_code		wlcpm.LOCATION_CODE%type;
	v_lock_type		wlcpm.LOCKER_TYPE%type;
	v_rent_period		clrm.RENT_PERIOD%type;
	v_rent_amt1		clrm.RENT_AMT%type;
	v_rent_amt2		clrm.RENT_AMT%type;
	v_rent_amt3		clrm.RENT_AMT%type;
	city_name		cmg.CUST_COMU_ADDR1%type;
	state_name		cmg.CUST_COMU_ADDR1%type;
	v_rent_amt		clrm.RENT_AMT%type;
	v_penal_charges		wlcpm.penal_charges%type;
	
cursor c1 (v_sol_id sst.set_id%type,LockNo clmt.locker_num%type) is 
	select  sol_id,
		LOCKER_NUM,
		cust_id,
		LOCKER_TYPE,
		ISSUE_DATE,
		RENT_AMT,
		LOCKER_PERIOD,
		DUE_DATE
	from clmt 
	where  sol_id=v_sol_id
	and del_flg = 'N'
	AND LOCKER_NUM = LockNo
	order by DUE_DATE;
	
	PROCEDURE LCKRMDNO (	inp_str IN VARCHAR2,
				out_retCode OUT NUMBER,
				out_rec OUT VARCHAR2) AS
	

	OutArr          	basp0099.ArrayType;
BEGIN
		basp0099.formInputArr (inp_str,OutArr);
		v_sol_id := OutArr(0);
		LockNo := OutArr(1);
		out_retCode := 0;
		out_rec     := NULL;
IF(NOT c1%ISOPEN) THEN
        --{
        out_retCode:= 0;
        open c1(v_sol_id,LockNo);
        --}
        END IF;
        IF(c1%ISOPEN)  THEN	
	FETCH c1 INTO	v_sol_id,
			v_locker_num,
			v_cust_id,
			v_locker_type,
			v_issue_date,
			v_rent_amt,
			v_locker_period,
			v_due_date;
	end if;
	if (c1%ISOPEN AND c1%NOTFOUND) THEN
        --{
            close c1;
            out_retcode := 1;
            return;
        --}	
	end if;
			BEGIN
				select set_id 
				INTO	v_loc_code1
				FROM	sst 
				where sol_id = v_sol_id
				and set_id like 'LOC%';
			END;
			
			BEGIN
				select 	a.rent_amt
				INTO v_rent_amt1
				from clrm a
				where a.RENT_VERSION_CODE =(select max(b.RENT_VERSION_CODE) 
				from clrm b where a.LOCATION_CODE =b.LOCATION_CODE
				and a.sol_id=b.sol_id and a.LOCKER_TYPE = b.LOCKER_TYPE
				and a.rent_period = b.rent_period
				and b.RENT_EFFECTIVE_DATE <= v_due_date)
				and a.LOCATION_CODE = v_loc_code1
				and a.sol_id=v_sol_id
				and a.rent_period = '1'
				and a.LOCKER_TYPE = v_locker_type;
				Exception when no_data_found then
				BEGIN
					select 	a.rent_amt
					INTO v_rent_amt1
					from clrm a
					where a.RENT_VERSION_CODE =(select max(b.RENT_VERSION_CODE) 
							            from clrm b 
							            where a.LOCATION_CODE =b.LOCATION_CODE and 
								    a.sol_id=b.sol_id and 
								    a.LOCKER_TYPE = b.LOCKER_TYPE
								    and a.rent_period = b.rent_period
								    and b.RENT_EFFECTIVE_DATE <= v_due_date)
					and a.LOCATION_CODE = v_loc_code1
					and a.sol_id='0000'
					and a.rent_period = '1'
					and a.LOCKER_TYPE = v_locker_type;
					Exception when no_data_found then
						v_rent_amt1:='0';
				END;
					
			END;
			
			BEGIN
				select 	rent_amt
				INTO v_rent_amt2
				from clrm a
				where a.RENT_VERSION_CODE =(select max(b.RENT_VERSION_CODE) 
				from clrm b where a.LOCATION_CODE =b.LOCATION_CODE
				and a.sol_id=b.sol_id and a.LOCKER_TYPE = b.LOCKER_TYPE
				and a.rent_period = b.rent_period
				and b.RENT_EFFECTIVE_DATE <= v_due_date)
				and a.LOCATION_CODE = v_loc_code1
				and a.sol_id=v_sol_id
				and a.rent_period = '2'
				and a.LOCKER_TYPE = v_locker_type;
				Exception when no_data_found then
				BEGIN
					select 	a.rent_amt
					INTO v_rent_amt2
					from clrm a
					where a.RENT_VERSION_CODE =(select max(b.RENT_VERSION_CODE) 
								    from clrm b 
								    where a.LOCATION_CODE =b.LOCATION_CODE and 
								    a.sol_id=b.sol_id and 
								    a.LOCKER_TYPE = b.LOCKER_TYPE
								    and a.rent_period = b.rent_period
								    and b.RENT_EFFECTIVE_DATE <= v_due_date)
					and a.LOCATION_CODE = v_loc_code1
					and a.sol_id='0000'
					and a.rent_period = '2'
					and a.LOCKER_TYPE = v_locker_type;
					Exception when no_data_found then
					v_rent_amt2:='0';
				END;
					
					
								
			END;
			
			BEGIN
				select 	rent_amt
				INTO v_rent_amt3
				from clrm a
				where a.RENT_VERSION_CODE =(select max(b.RENT_VERSION_CODE) 
				from clrm b where a.LOCATION_CODE =b.LOCATION_CODE
			    	and a.sol_id=b.sol_id and a.LOCKER_TYPE = b.LOCKER_TYPE
				and a.rent_period = b.rent_period
				and b.RENT_EFFECTIVE_DATE <= v_due_date)
				and a.LOCATION_CODE = v_loc_code1
				and a.sol_id=v_sol_id
				and a.rent_period = '3'
				and a.LOCKER_TYPE = v_locker_type;
				Exception when no_data_found then
				BEGIN
					select 	a.rent_amt
					INTO v_rent_amt3
					from clrm a
					where a.RENT_VERSION_CODE =(select max(b.RENT_VERSION_CODE) 
							    from clrm b 
							    where a.LOCATION_CODE =b.LOCATION_CODE and 
							    a.sol_id=b.sol_id and 
							    a.LOCKER_TYPE = b.LOCKER_TYPE
							    and a.rent_period = b.rent_period
							    and b.RENT_EFFECTIVE_DATE <= v_due_date)
					and a.LOCATION_CODE = v_loc_code1
					and a.sol_id='0000'
					and a.rent_period = '3'
					and a.LOCKER_TYPE = v_locker_type;
					Exception when no_data_found then
					v_rent_amt3:='0';
				END;
				
				
								
											
			END;
			
			BEGIN
                		SELECT  substr(cust_name,1,40),
                        		cust_comu_addr1,
                        		cust_comu_addr2,
                        		CUST_COMU_CITY_CODE,
                        		cust_comu_state_code,
                        		CUST_COMU_PIN_CODE,
                        		CUST_COMU_PHONE_NUM_1
                		INTO    v_cust_name,
                        		v_addr1,
                        		v_addr2,
                        		v_city,
                        		v_state,
                        		v_pin_code,
                        		v_phone
               			FROM    cmg
                		WHERE   cust_id=v_cust_id;
                		Exception when no_data_found then
                			v_cust_name:=null;
                			v_addr1:=null;
                			v_addr2:=null;
                			v_state:=null;
                			v_city:=null;
                			v_pin_code:=null;
                			v_phone :=null;
        		END;
	
		BEGIN
	                SELECT  ref_desc
	                INTO    city_name
	                FROM    rct
	                WHERE   ref_code=v_city
	                AND     ref_rec_type='01';
	                Exception when no_data_found then
	                city_name:=null;
	        END;
	
	        BEGIN
	                SELECT  ref_desc
	                INTO    state_name
	                FROM    rct
	                WHERE   ref_code=v_state
	                AND     ref_rec_type='02';
	                Exception when no_data_found then
	                state_name:=null;
	        END;	
	        
	        BEGIN
	        	SELECT DISTINCT PENAL_CHARGES
	        	INTO v_penal_charges
	        	from wlcpm
	        	where locker_type = v_locker_type
	        	and sol_id = v_sol_id
	        	and effective_from <= v_due_date
	        	and LOCATION_CODE = v_loc_code1;
	        	Exception when no_data_found then
	        	
	        	BEGIN
	        		SELECT DISTINCT PENAL_CHARGES
			       	INTO v_penal_charges
			       	from wlcpm
			       	where locker_type = v_locker_type
			       	and sol_id = '0000'
			       	and effective_from <= v_due_date
	        		and LOCATION_CODE = v_loc_code1;
				Exception when no_data_found then
					v_penal_charges := 0;	
	                END;
	        END;	
			out_rec	:=		v_locker_num 	||'|'||
						v_cust_id 	||'|'||
						v_cust_name	||'|'||
						v_addr1		||'|'||
						v_addr2		||'|'||
						city_name	||'|'||
						state_name	||'|'||
						v_state		||'|'||	
						v_pin_code	||'|'||
						v_phone		||'|'||
						v_locker_type 	||'|'||
						v_issue_date 	||'|'||
						v_rent_amt1 	||'|'||
						v_rent_amt2 	||'|'||
						v_rent_amt3 	||'|'||
						v_due_date 	||'|'||
						v_penal_charges ||'|'||
						v_loc_code1;
				
END LCKRMDNO;
END LCKRMDNO;
/
create or replace public synonym LCKRMDNO for LCKRMDNO
/
grant all on LCKRMDNO to tbautil,tbagen,tbacust,tbaadm
/
