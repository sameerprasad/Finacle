--  Source          :   members_deleted.sql
--  STR No          :   ICI6527
--  Author          :   Vinayak Vasant Sonkaramble
--  Date            :   31/01/2008
--  Description     :   To geberate dump of family Id's added

set serveroutput on size 1000000
set feedback off
set verify off
set head off
set colsep |
set pages 0
set linesize 500
set trims on
set termout off
set echo off
/
-----------Family ids Created----------------------------------------
spool mail_member_deleted.lst

SELECT distinct	a.cust_id,
	b.cust_name
FROM icici_fammem a,cmg b
where 
family_id = '&1'
and lpad(a.cust_id,9) = b.cust_id
and a.ENTITY_CRE_FLG = 'Y'
and a.del_flg = 'Y'
UNION
SELECT distinct	a.head_cust_id,
b.cust_name
FROM icici_famdet a,cmg b
where 
family_id = '&1'
and lpad(a.head_cust_id,9) = b.cust_id
and a.ENTITY_CRE_FLG = 'Y'
and a.del_flg = 'Y';

spool off
/

-----------This generates all members list----------------------------------------
spool all_members_deleted.lst


DECLARE

vstr_CUST_COMU_ADDR1		varchar2(100);
vstr_CUST_COMU_ADDR2		varchar2(100);
vstr_CUST_COMU_PIN_CODE		varchar2(100);
vstr_CUST_COMU_PHONE_NUM_1	varchar2(100);
vstr_CUST_COMU_PHONE_NUM_2	varchar2(100);
vstr_CUST_COMU_TELEX_NUM	varchar2(100);
vstr_CUST_COMU_STATE_CODE	varchar2(100);
vstr_CUST_COMU_CNTRY_CODE	varchar2(100);
vstr_sol_CITY_CODE		varchar2(100);
vstr_CUST_COMU_CITY_CODE	varchar2(100);
vstr_CUST_COMU_CITY		varchar2(100);
vstr_CUST_COMU_STATE		varchar2(100);
vstr_CUST_COMU_CNTRY		varchar2(100);
vstr_sysdate			varchar2(100);
vstr_email_id			varchar2(100);
vstr_cust_name			varchar2(100);
vstr_cust_id			varchar2(9);
vstr_cust_title_code		VARCHAR2(5);

BEGIN

SELECT head_cust_id 
INTO vstr_cust_id
FROM icici_famdet
WHERE family_id = '&1'
AND del_flg = 'Y';
	
begin
	select	c.CUST_COMU_ADDR1,
		c.CUST_COMU_ADDR2,
		c.CUST_COMU_PIN_CODE,
		c.CUST_COMU_PHONE_NUM_1,
		c.CUST_COMU_STATE_CODE,
		c.CUST_COMU_CNTRY_CODE,
		c.CUST_COMU_CITY_CODE,
		c.CUST_COMU_PHONE_NUM_2,
		c.CUST_COMU_TELEX_NUM,
		c.EMAIL_ID,
		c.CUST_NAME,
		c.cust_title_code
	into
		vstr_CUST_COMU_ADDR1,
		vstr_CUST_COMU_ADDR2,
		vstr_CUST_COMU_PIN_CODE,
		vstr_CUST_COMU_PHONE_NUM_1,
		vstr_CUST_COMU_STATE_CODE,
		vstr_CUST_COMU_CNTRY_CODE,
		vstr_CUST_COMU_CITY_CODE,
		vstr_CUST_COMU_PHONE_NUM_2,
		vstr_CUST_COMU_TELEX_NUM,
		vstr_email_id,
		vstr_cust_name,
		vstr_cust_title_code
	from	cmg c
	where	c.cust_id = lpad(vstr_cust_id,9);

	EXCEPTION
	when no_data_found then
	    vstr_CUST_COMU_ADDR1:=null;
		vstr_CUST_COMU_ADDR2:=null;
		vstr_CUST_COMU_PIN_CODE:=null;
		vstr_CUST_COMU_PHONE_NUM_1:=null;
		vstr_CUST_COMU_STATE_CODE:=null;
		vstr_CUST_COMU_CNTRY_CODE:=null;
		vstr_CUST_COMU_CITY_CODE:=null;
		vstr_CUST_COMU_PHONE_NUM_2:=null;
		vstr_CUST_COMU_TELEX_NUM:=null;

end;

	BEGIN
	--{
		SELECT REF_DESC 
		INTO vstr_CUST_COMU_CITY
		FROM RCT
		WHERE REF_CODE = vstr_CUST_COMU_CITY_CODE
		AND ref_rec_type = '01';

		EXCEPTION
		WHEN NO_DATA_FOUND THEN
		vstr_CUST_COMU_CITY := '';
	--}	
	END;

	BEGIN
	--{
		SELECT REF_DESC 
		INTO vstr_CUST_COMU_STATE
		FROM RCT
		WHERE REF_CODE = vstr_CUST_COMU_STATE_CODE
		AND ref_rec_type = '02';

		EXCEPTION
		WHEN NO_DATA_FOUND THEN
		vstr_CUST_COMU_STATE := '';
	--}	
	END;

	BEGIN
	--{
		SELECT to_char(db_stat_date,'Monthdd yyyy') 
		INTO vstr_sysdate
		FROM GCT;
		
		EXCEPTION
		WHEN NO_DATA_FOUND THEN
		vstr_sysdate := '';
	--}
	END;

	BEGIN
	--{
		SELECT REF_DESC 
		INTO vstr_CUST_COMU_CNTRY
		FROM RCT
		WHERE REF_CODE = vstr_CUST_COMU_CNTRY_CODE
		AND ref_rec_type = '03';

		EXCEPTION
		WHEN NO_DATA_FOUND THEN
		vstr_CUST_COMU_CNTRY := '';
	--}	
	END;

	
dbms_output.put_line('&1'||'|'||vstr_cust_id||'|'||vstr_cust_name||'|'||vstr_email_id||'|'||vstr_sysdate||'|'||vstr_CUST_COMU_ADDR1||'|'||vstr_CUST_COMU_ADDR2||'|'||vstr_CUST_COMU_CITY||'|'||vstr_CUST_COMU_PIN_CODE||'|'||vstr_CUST_COMU_PHONE_NUM_1||'|'||vstr_CUST_COMU_STATE||'|'||vstr_CUST_COMU_CNTRY||'|'||vstr_CUST_COMU_PHONE_NUM_2||'|'||vstr_cust_title_code);
	
END;

/
spool off
/
