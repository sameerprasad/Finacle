rem Accept solid prompt " Enter the SolId :"
rem Accept custid prompt " Enter the CustId :"
rem Accept fromdate prompt " Enter the FromDate :"
rem Accept todate prompt " Enter the Todate :"

SET SERVEROUTPUT ON SIZE 1000000
SET PAGESIZE 45000
SET LINESIZE 250
SET HEADING ON
SET FEEDBACK OFF
SET VERIFY OFF
SET TERM  OFF


spool tdsipcus

select foracid AcctNum ,'|',
		TDS.cust_id CustId ,'|',
		to_char(TDS.tran_date,'DD-MM-YYYY') TRANDATE , '|',
		int_amt INT ,'|',
		shortfall_amt STFL_AMT ,'|' ,
		(tds_from_org_acct+tds_from_op_acct+tds_from_suspense_acct) TDS_AMT ,'|',
		tds_cert_num 
from gam,tds
where
tds.sol_id = '&1' and
tds.cust_id = lpad('&2',9) and
tds.tran_date >= to_date('&3') and
tds.tran_date <= to_date('&4') and
tds.acid = gam.acid 
and tds.sol_id = gam.sol_id
order by tds.cust_id , tds.tran_date,foracid
/
spool off

SET TERM  ON
exit
