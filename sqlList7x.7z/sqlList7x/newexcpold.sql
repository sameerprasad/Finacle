rem accept solid prompt "ENTER SOL ID FOR WHICH REPORT IS REQD::::"
rem accept dt prompt "ENTER DATE  FOR WHICH REPORT IS REQD::::"
set echo off
set termout off
set pause off
rem script for printing  details of exceptional transaction  for bod date in eod
rem author M K JAIN
rem version 1.0 dated 20-12-1994

set verify off
set feedback off
set linesize 132 
set pages 66
set newpage 0
set space 0

whenever sqlerror exit sql.sqlcode

col sol format a2
col a heading 'TRAN # ' format a12
col id heading ' ACCT # ' format a16
col name heading 'ACCOUNT NAME' format a20 trunc
col amount format b999,999,999,999.99
col b heading 'CREATOR' format a10
col e heading 'Vfd by' format a10
col type heading 'D|OR|C' format a2
col code heading 'EXCEPTION DETAIL' format a30 trunc

define all_dashes = '_____________________________________________________________________________________________________________________'

column today new_value today_date
column setid new_value solset
column soldesc new_value solname

select to_char(db_stat_date,'dd/mm/yyyy') today from gct; 
select sol.sol_id solid, sol.sol_desc soldesc, sst.set_id setid
from sol, sst
where sol.sol_id=sst.sol_id
and sst.set_id='&1';

ttitle center 'ICICI BANKING CORPORATION LTD.' skip 1 -
center ' SOLSET ' solset  skip 1 -
center ' SOLNAME ' solname  skip 1 -
center ' -------------------- ' skip 1 -
center  'Details of Exceptional Transactions as on ' &2 skip 1 - 
right 'Page :       ' format 999 sql.pno skip 1 -
left all_dashes skip 1

btitle center 'ABOVE TRANSACTIONS CHECKED AND FOUND IN ORDER' skip 2 -
right 'MANAGER'
set space 1

break on sol skip page on report
	
spool newexcpold  
select 
	substr(s.sol_id,2,3),c.tran_id||'/'||ltrim(c.part_tran_srl_num) a,
	b.foracid id,
	a.tran_amt amount,
	a.part_tran_type type,
	a.rcre_user_id b,a.lchg_user_id e,d.msg_literal code ,
	b.acct_name name
from mmsg d,gam b,ctd a,pte c, sol s
	where s.sol_id=b.sol_id
	and a.sol_id=s.sol_id
	and s.sol_id='&1'
	and c.tran_date = upper('&2')
	and a.tran_date = c.tran_date
	and a.tran_id = c.tran_id 
	and a.part_tran_srl_num = c.part_tran_srl_num  
	and a.del_flg != 'Y'
	and b.acid = a.acid
	and d.msg_id = 'EXT'||c.excp_code
order by 1,7,3   
/
ttitle off
btitle off
set termout on
set feedback on
set verify on
set heading on
clear breaks
clear computes
spool off
set echo on
exit
