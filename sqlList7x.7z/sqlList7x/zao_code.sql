set serveroutput on size 1000000
set head off
set linesize 512
set trims on
set pages 0
set feedback off
set verify off
set termout off
spool zao_code

select distinct ZAO_CODE from ici_gbm_nodal_master order by ZAO_CODE
/
spool off
