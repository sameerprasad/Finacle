--------------------------------------------
--File Name   : Report_blkstrpt.sql 
--Description : Blocked status report 
--Author      : Priscilla & Vijay
--Date        : 01-06-2010
------------------------------------------

set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_blkstrpt.lst

DECLARE

lv_solid		gam.sol_id%type :='&1';
date1		 	wlclck.LOCK_DATE%type := '&2';
date2			wlclck.LOCK_DATE%type := '&3';

CURSOR c1 IS
select  distinct wlclck.sol_id,
                wlckm.rack_id,
                clmt.locker_type,
                wlclck.locker_num,
				clmt.cust_id,
                cmg.cust_name,
                wlclck.LOCK_DATE,
                wlclck.LOCK_REASON,
                wlclck.advice
from    wlclck,wlckm,clmt,cmg
where   clmt.locker_num = wlclck.locker_num
and     wlckm.locker_num = clmt.locker_num
and wlclck.locker_num = wlckm.locker_num
and      wlckm.sol_id = clmt.sol_id
and     wlclck.sol_id = wlckm.sol_id
and     cmg.cust_id=lpad(clmt.cust_id,9,' ')
and     wlclck.del_flg!='Y'
and     wlckm.del_flg!='Y'
and     clmt.del_flg!='Y'
and     wlclck.sol_id = lv_solid
and     wlckm.status = 'F'
and     wlclck.status = 'F'
and     wlclck.LOCK_DATE between to_date(date1) and to_date(date2)
ORDER by 6,4;

BEGIN

    for f1 in c1
    loop
dbms_output.enable(buffer_size => NULL);
dbms_output.put_line( 	f1.sol_id       ||'|'||
						f1.rack_id      ||'|'||
						f1.locker_type  ||'|'||
						f1.locker_num   ||'|'||
						f1.cust_id		||'|'||
						f1.cust_name    ||'|'|| 
						f1.lock_date	||'|'||
						f1.lock_reason	||'|'||
						f1.advice);
   end loop; 
END;
/
spool off
