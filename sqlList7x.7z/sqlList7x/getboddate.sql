set pagesize 0
set feedback off
set termout off
col a format A6
spool boddt.lst
select to_char(db_stat_date,'YYMMDD') a from gct;
exit;
