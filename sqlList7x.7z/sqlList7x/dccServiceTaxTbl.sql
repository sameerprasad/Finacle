REM####################################################################
REM File Name   : dccServiceTaxTbl.sql
REM Author      : Subhasish Paramanik
REM Date        : 20 APR-2011
REM####################################################################

drop table ICICI.ICICI_BGTAX
/
create table ICICI.ICICI_BGTAX
(
    BG_SRL_NUM      VARCHAR2(16),
    SOL_ID          VARCHAR2(8),
    PTRAN_BUS_TYPE  VARCHAR2(5),
    ECT_SRL_NUM     VARCHAR2(5),
    CHT_KEY_SRL_NUM VARCHAR2(5),
    EVENT_ID        VARCHAR2(25),
    EVENT_TYPE      VARCHAR2(5),
    UPFRONT_DEF_FLG CHAR(1),
    TRAN_ID         VARCHAR2(9),
    TRAN_AMT        NUMBER(20,4),
    TRAN_DATE       DATE,
    TRAN_RMKS       VARCHAR2(30),
    OPER_ACCT       VARCHAR2(12),
    TAX_TRAN_ID     VARCHAR2(9),
    TAX_AMT         NUMBER(20,6),
	DCC_KEY_SRL_NUM	VARCHAR2(5),
	TRAN_CRNCY_CODE VARCHAR2(3)
)
storage ( initial 8M next 4M PCTINCREASE 0 )
TABLESPACE ICICI_CUST
/
drop public synonym ICICI_BTX
/
create public synonym ICICI_BTX
    for ICICI.ICICI_BGTAX
/
grant select, insert, update, delete on ICICI_BTX to tbaadm
/
grant select, insert, update, delete on ICICI_BTX to tbagen
/
grant select on ICICI_BTX to tbacust
/
grant select on ICICI_BTX to tbautil
/

