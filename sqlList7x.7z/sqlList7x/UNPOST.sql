SET HEAD OFF
SET ARRAYSIZE 1
SET MAXDATA  60000
SET FEEDBACK OFF
SET VERIFY OFF
SET TERM OFF
SET PAGESIZE 0
SET TRIMS ON
SET LINESIZE  5000
SPOOL &1
select dth.tran_id || '|' || TO_CHAR(dth.tran_date, 'DD-MM-YYYY HH24:MI:SS') || '|' || dth.remarks
from 	dth
where 	num_dr_tran_pstd + num_cr_tran_pstd = 0 
and  	init_sol_id = '&2'
and 	substr(tran_id, 1, 1) = 'S'
--AND b2k_EVENT_TYPE='CDCI'
/
SPOOL OFF
