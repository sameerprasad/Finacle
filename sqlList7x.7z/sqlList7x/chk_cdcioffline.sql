set verify off
set feedback off
set termout off
set echo off
set pages 0
set head off
set trimspool on
spool chk_cdcioffline
select 'cdcioffline'||'|'|| count (1) from gct  where  cdci_operating_status  = 'F'
/
spool off

spool chk_ent_tran
select 'pendtran'||'|'|| count(1)||'|'||foracid 
from dtd,gam 
where gam.sol_id = '0018'
 and bacid in 
('SLUBPTR0',
 'SLUBPTR1',
 'SLUBPTR2',
 'SLUBPTR3',
 'SLUBPTR4',
 'SLUBPTR5',
 'SLUBPTR6',
 'SLUBPTR7',
 'SLUBPTR8',
 'SLUBPTR9',
 'SLUBPSTR',
 'SLBWYTR0',
 'SLBWYTR1',
 'SLBWYTR2',
 'SLBWYTR3',
 'SLBWYTR4',
 'SLBWYTR5',
 'SLBWYTR6',
 'SLBWYTR7',
 'SLBWYTR8',
 'SLBWYTR9',
 'SLBWAYTR',
 'SLECMTR0',
 'SLECMTR1',
 'SLECMTR2',
 'SLECMTR3',
 'SLECMTR4',
 'SLECMTR5',
 'SLECMTR6',
 'SLECMTR7',
 'SLECMTR8',
 'SLECMTR9',
 'SLECOMTR',
 'SLIPSWDL',
 'SLNFSWDL',
 'SLVATWDL',
 'SLEUROTR',
 'SLVPSWDL',
 'SLMPSWDL',
 'SLMATWDL'
)
and gam.acid = dtd.acid
and dtd.pstd_flg = 'N'
and dtd.del_flg = 'N'
group by foracid
having count(1) > 0
/
spool off

spool pending_tran_list
select 'TRAN ID|TRAN AMT|ACCT NO|PTRAN SRL|DR/CR' from dual;
select tran_id||'|'||tran_amt||'|'||foracid||'|'||part_tran_srl_num||'|'||part_tran_type
from dtd,gam
where gam.sol_id = '0018'
and bacid in 
('SLUBPTR0',
 'SLUBPTR1',
 'SLUBPTR2',
 'SLUBPTR3',
 'SLUBPTR4',
 'SLUBPTR5',
 'SLUBPTR6',
 'SLUBPTR7',
 'SLUBPTR8',
 'SLUBPTR9',
 'SLUBPSTR',
 'SLBWYTR0',
 'SLBWYTR1',
 'SLBWYTR2',
 'SLBWYTR3',
 'SLBWYTR4',
 'SLBWYTR5',
 'SLBWYTR6',
 'SLBWYTR7',
 'SLBWYTR8',
 'SLBWYTR9',
 'SLBWAYTR',
 'SLECMTR0',
 'SLECMTR1',
 'SLECMTR2',
 'SLECMTR3',
 'SLECMTR4',
 'SLECMTR5',
 'SLECMTR6',
 'SLECMTR7',
 'SLECMTR8',
 'SLECMTR9',
 'SLECOMTR',
 'SLIPSWDL',
 'SLNFSWDL',
 'SLVATWDL',
 'SLEUROTR',
 'SLVPSWDL',
 'SLMPSWDL',
 'SLMATWDL'
)
and gam.acid = dtd.acid
and dtd.pstd_flg = 'N'
and dtd.del_flg = 'N'
/
spool off
exit;
