column suffix new_value suffix
column dc new_value dc
column today new_value dt
column branch new_value br
break on SOL_ID skip page on part_tran_type skip 2
compute sum of tran_amt on part_tran_type
select to_char(db_stat_date,'ddmmyyyy') suffix from gct;
select dc_alias dc from gct;
set linesize 132
set escape /
set head off
set pages 0
set numformat 9999999999.99
set feedback off
set verify off
spool NEWEBA${CDCI_DC_ALIAS}&suffix
---alter session set optimizer_goal=rule
---/
select 'ALT'||'|'||
gam.foracid||'|'||
substr(lien_reason_code,1,3)||'|'||
substr(lien_remarks,4,5)||'|'||
alt.ts_cnt||'|'||
alt.lien_amt||'|'
from alt, gam
where alt.acid = gam.acid
and substr(lien_reason_code,1,3) = 'EBA'
order by gam.foracid
/
select 'ALH'||'|'||
alh.srl_num||'|'||
icici_udmt.ser_num||'|'||
gam.foracid||'|'||
substr(lien_remarks, 4, 5)||'|'||
alh.event_lien_amt||'|'||
alh.lien_amt||'|'||
substr(lien_remarks, 8, 50) ||'|'||
to_char(icici_udmt.date_time,'DD-MM-YYYY HH24:MI:SS')||'|'||
substr(lien_remarks, 1, 2)||'|'
from alh, icici_udmt, gam
where alh.acid = gam.acid
and icici_udmt.command = 'USTR'
and icici_udmt.sub_command = substr(lien_remarks, 1, 2)
and icici_udmt.date_time >= (select db_stat_date from gct) 
and icici_udmt.dcc_id = 'EBA'
and icici_udmt.b2k_key = gam.foracid
and icici_udmt.b2k_ser_num = alh.srl_num
/
select 'DTD'
||'|'||
substr(tran_rmks,1,12)
||'|'||
gam.foracid
||'|'||
part_tran_type
||'|'||
to_char(value_date,'DD-MM-YYYY HH24:MI:SS')
||'|'||
ltrim(tran_id)
||'|'||
decode(part_tran_type,'C',1*tran_amt,-1*tran_amt)
||'|'||
TRAN_PARTICULAR
||'|'||
substr(rpad(tran_rmks,30,' '),15,17)||'|'
FROM DTD,GAM
where dtd.del_flg!='Y'
and dtd.acid=gam.acid
and dtd.tran_id in (select distinct tran_id from dtd where acid in (select distinct acid from gam where foracid
like '00%SLECMTR%'))
and substr(gam.foracid,5,2) in ('01','05','51')
order by dtd.sol_id
/
spool off
