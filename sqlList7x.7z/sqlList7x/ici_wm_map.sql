  set serveroutput on size 1000000
  set head off
  set linesize 512
  set trims on
  set pages 0
  set feedback off
  set verify off
  set termout off
  spool output.lst 


declare


custid       ici_wm_map.CUST_ID%type;
rmname       ici_wm_map.RM_NAME%type;    
rmmobile     ici_wm_map.RM_MOBILE%type;  
rmemail      ici_wm_map.RM_EMAIL%type; 
ecmname      ici_wm_map.ESM_NAME%type;     
ecmmobile    ici_wm_map.ESM_MOBILE%type;      
ecmemail     ici_wm_map.ESM_EMAIL%type;
cflag         ici_wm_map.ENTITY_CRE_FLG%type;
dflag         ici_wm_map.DEL_FLG%type;
luser         ici_wm_map.LCHG_USER_ID%type;
ldate         ici_wm_map.LCHG_TIME%type;
ruser         ici_wm_map.RCRE_USER_ID%type;
rdate         ici_wm_map.RCRE_TIME%type;


 begin
  custid    := '&1';
  rmname    := '&2';
  rmemail   := '&3'; 
  rmmobile  := '&4';
  ecmname   := '&5';
  ecmemail  := '&6';
  ecmmobile := '&7';
  cflag     := '&8';
  dflag     := '&9';
  luser     := '&10';
  ldate     := '&11'; 
  ruser     := '&12';
  rdate     := '&13';

 dbms_output.put_line(custid || '|' ||rmname || '|' ||rmemail || '|' ||rmmobile || '|' || ecmname || '|' ||ecmemail || '|' ||ecmmobile || '|' ||cflag || '|' ||dflag || '|' ||luser || '|' ||ldate || '|' ||ruser || '|' ||rdate );

insert into ici_wm_map values(custid,rmname,rmemail,rmmobile,ecmname,ecmemail,ecmmobile,cflag,dflag,luser,ldate,ruser,rdate);

 commit;
end;

/

spool off

