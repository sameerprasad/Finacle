set echo off verify off feedback off 
set serveroutput on size 1000000
set numformat 9999999999999.99

spool &2.pfm 

declare
trandate 	varchar2(11);
nrate 	number(21,10);

       cursor Acctsel
       is
       select sol_id,
       gl_sub_head_code,
       acid,
       foracid, 
       acct_prefix,
       acct_crncy_code 
       from gam 
       where sol_id = '&2' 
       and (gl_sub_head_code like '40%' or gl_sub_head_code like '75%') 
       and acct_cls_flg != 'Y'; 

		cursor gstsel
		is
		select sol_id,
		gl_sub_head_code,
		tot_dr_bal,
		tot_cr_bal,
		crncy_code 
		from gst 
		where sol_id = '&2' 
		and (gl_sub_head_code like '40%' or gl_sub_head_code like '75%')
		and end_tran_date >=to_date(trandate,'dd-mm-yyyy') and tran_date <=to_date(trandate,'dd-mm-yyyy');
	--	and tran_date = to_date(trandate,'dd-mm-yyyy');

cursor ngl is
select
      substr(sol_id,0,4) brcd,
      gl_sub_head_code glhd,
      substr(foracid,5,2) frcd,
      lpad(ltrim(substr(foracid,7,9),0),9,' ') frsb,
      substr(acct_name,0,40) fnam 
from  gam
where
       sol_id='&2' and
       (gl_sub_head_code like '75%' or
      gl_sub_head_code like '40%') and
      acct_cls_flg='N' and
      acct_opn_date between '&3' and '&1';


minbal eab.tran_date_bal%type := 0.0;
bal40 eab.tran_date_bal%type := 0.00;
bal75 eab.tran_date_bal%type := 0.00;
bal eab.tran_date_bal%type := 0.00;
begin

for i in ngl
loop

     DBMS_OUTPUT.PUT_LINE('NGL'||','||i.brcd||','||i.glhd||','||i.frcd||','||i.frsb||','||i.fnam);
end loop;

begin --{

trandate := '&1';
	for i in Acctsel
	loop
	begin --{
		select tran_date_bal into minbal 
		from eab 
		where acid = i.acid and 
		eod_date <= trandate 
		and end_eod_date >= trandate;
		exception
		when no_data_found 
		then minbal := 0.00;
	end; --}

		if (minbal is null)
		then
			minbal := 0.00;
		end if;

		  begin --{
         		select nvl(var_crncy_units/fxd_crncy_units,1)  into nrate
              		from rth
              		where ratecode='NOR'
                	and var_crncy_code='INR'
                	and fxd_crncy_code = i.acct_crncy_code
                	and rtlist_date =
                  	 (select max(rtlist_date) from rth
                      	where
                        fxd_crncy_code = i.acct_crncy_code
                        and var_crncy_code='INR'
                        and ratecode='NOR'
                        and rtlist_date<=to_date(trandate,'dd-mm-yyyy'))
                	and rtlist_num=
                    	(select max(rtlist_num) from rth
                      	where
                        fxd_crncy_code= i.acct_crncy_code
                        and var_crncy_code='INR'
                        and ratecode='NOR'
                        and rtlist_date=
                           (select max(rtlist_date) from rth
                        where
                           fxd_crncy_code= i.acct_crncy_code
                           and var_crncy_code='INR'
                          and ratecode='NOR'
                          and rtlist_date<=to_date(trandate,'dd-mm-yyyy')));
        		exception
       			 when no_data_found
        		then
        		nrate:=1;
        	end; --}

		if ( substr(i.gl_sub_head_code,1,2) = '75')
		then
			bal := -1 * (minbal * nrate);
		else
			bal := (minbal * nrate);
		end if;

		dbms_output.put_line('PLD'||','||i.sol_id||','||to_char(to_date(trandate,'dd-mm-yyyy'),'dd-mon-yyyy')||','||
		i.gl_sub_head_code	||','||	substr(i.foracid,5,2)	||','||
		lpad(ltrim(substr(i.foracid,7,9),0),9) ||','||to_char(bal,'9999999999999999.99'));

		minbal := 0.00;
		bal := 0.00;

	end loop;

	for j in gstsel
	loop

	 begin --{
         select nvl(var_crncy_units/fxd_crncy_units,1)  into nrate
              from rth
              where ratecode='NOR'
                and var_crncy_code='INR'
                and fxd_crncy_code = j.crncy_code
                and rtlist_date =
                   (select max(rtlist_date) from rth
                      where
                        fxd_crncy_code = j.crncy_code
                        and var_crncy_code='INR'
                        and ratecode='NOR'
                        and rtlist_date<=to_date(trandate,'dd-mm-yyyy'))
                and rtlist_num=
                    (select max(rtlist_num) from rth
                      where
                        fxd_crncy_code= j.crncy_code
                        and var_crncy_code='INR'
                        and ratecode='NOR'
                        and rtlist_date=
                           (select max(rtlist_date) from rth
                      where
                        fxd_crncy_code= j.crncy_code
                        and var_crncy_code='INR'
                        and ratecode='NOR'
                        and rtlist_date<=to_date(trandate,'dd-mm-yyyy')));
        exception
        when no_data_found
        then
        nrate:=1;
        end; --}
	
		if ( substr(j.gl_sub_head_code,1,2) = '75' )
		then
			bal75 := bal75 + ((j.tot_dr_bal - j.tot_cr_bal) * nrate);
		else
			bal40 := bal40 + ((j.tot_cr_bal - j.tot_dr_bal) * nrate);
		end if;
	
	end loop;

	 dbms_output.put_line(
			'PLT'																	||','|| '&2'																||','|| to_char(to_date(trandate,'dd-mm-yyyy'),'dd-mon-yyyy')||','||
         '40'||'999'  									 					||','||
			'zz'																	||','||
			'zzzzzzzzz'															||','||
         to_char(bal40,'9999999999999999.99'));

	dbms_output.put_line(
			'PLT'             	                                 ||','||
         '&2'																||','||
         to_char(to_date(trandate,'dd-mm-yyyy'),'dd-mon-yyyy')||','||
         '75'||'999' 														||','||
         'zz'                                                  ||','||
         'zzzzzzzzz'                                           ||','||
         to_char(bal75,'9999999999999999.99'));

end; --}
end;
/

spool off
