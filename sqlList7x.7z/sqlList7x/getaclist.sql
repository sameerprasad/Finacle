set head off
set verify off
set feedback off
set pages 0
set term off
set echo off
set trims on
spool &1..aclist
select foracid from eab,gam
where gam.schm_type='SBA'
and gam.sol_id='&1'
and gam.acid=eab.acid
and eab.eod_date=(select max(x.eod_Date) from eab x
where x.acid=eab.acid and x.eod_Date <='27-09-2001')
and eab.tran_date_bal <0
/
spool off
exit
