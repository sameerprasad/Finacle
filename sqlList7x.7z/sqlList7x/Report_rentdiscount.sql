--------------------------------------------
--File Name   : Report_rentdiscount.sql
--Description : Locker Rent discount Report
--Author      : Priscilla & Vijay
--Date        : 01-06-2010
------------------------------------------

set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_rentdiscount.lst

DECLARE

lv_solid        gam.sol_id%type :='&1';
lv_date        	date :='&2';
lv_cust_name	cmg.cust_name%type;

CURSOR c1 IS
SELECT  
	WLPM.SOL_ID,
	WLCKM.RACK_ID,
	WLPM.LOCKER_TYPE,
	WLPM.LOCKER_NUM,
	CLMT.CUST_ID,
	CLMT.RENT_AMT,
	WLPM.DISCOUNT_METHOD,
	WLPM.DISCOUNT_AMOUNT,
	WLPM.DPERIOD_FROM,
	WLPM.DPERIOD_TO,
	WLPM.DREASON,
	WLPM.DREMARKS
FROM 
	CLMT,WLPM,WLCKM
WHERE 
	CLMT.LOCKER_NUM = WLPM.LOCKER_NUM
AND	CLMT.LOCKER_NUM = WLCKM.LOCKER_NUM
AND	CLMT.SOL_ID = WLPM.SOL_ID
and wlpm.cust_id = clmt.cust_id
AND	WLPM.SOL_ID= lv_solid
AND	DISCOUNT_AMOUNT IS NOT NULL
AND	lv_date BETWEEN DPERIOD_FROM AND DPERIOD_TO
and	clmt.del_flg != 'Y'
and	WLPM.del_flg != 'Y'
and	WLCKM.del_flg != 'Y'
and	clmt.entity_cre_flg = 'Y'
and	wlpm.entity_cre_flg = 'Y'
and	wlckm.entity_cre_flg = 'Y'
ORDER BY LOCKER_NUM;

BEGIN

    for f1 in c1

    loop
dbms_output.enable(buffer_size => NULL);      
	BEGIN
	 select cust_name into lv_cust_name from cmg where cust_id = lpad(f1.cust_id,9,' ');	
	 Exception when no_data_found then
	 lv_cust_name:=null;
	END;
dbms_output.put_line( 	f1.sol_id         	||'|'||
		      			f1.rack_id        	||'|'||
		      			f1.locker_type    	||'|'||
		      			f1.locker_num     	||'|'||
		      			f1.CUST_ID          ||'|'||
						lv_cust_name		||'|'||
		      			f1.RENT_AMT       	||'|'||
                      	f1.DISCOUNT_METHOD 	||'|'||
                      	f1.DISCOUNT_AMOUNT  ||'|'||
						f1.DPERIOD_FROM		||'|'||
						f1.DPERIOD_TO		||'|'||
	              		f1.DREASON			||'|'||
                      	f1.DREMARKS
					);
	       	     
   end loop; 
END;
/
spool off

