REM####################################################################
REM File Name   : CLND.sql
REM Description : Table creation for Nomination details of locker
REM               customers
REM Author      : Prabhu.B (BBSSL)
REM Date        : 26-05-2008
REM Module	: LOCKER
REM####################################################################
drop table icici.cust_locker_nomination_detail
/
drop public synonym CLND
/
create table icici.cust_locker_nomination_detail
(
	sol_id 			varchar2(8),
	nominee_no              varchar2(10),
	nominee_name    	varchar2(80),
	cust_id         	varchar2(9),
	locker_num		varchar2(12),
	nominee_relation 	varchar2(5),
	date_of_birth   	varchar2(10),
	age             	number(4),
	nominee_add1    	varchar2(45),
	nominee_add2    	varchar2(45),
	nominee_stat_code 	varchar2(5),
	nominee_city_code 	varchar2(5),
	nominee_cntry_code 	varchar2(5),
	nominee_pin_code 	varchar2(6),
	nominee_ph_num1         varchar2(15),
	nominee_ph_num2         varchar2(15),
	guardian_name    	varchar2(80),
	guardian_relation 	varchar2(5),
	guardian_add1    	varchar2(45),
	guardian_add2    	varchar2(45),
	guardian_stat_code 	varchar2(5),
	guardian_city_code 	varchar2(5),
	guardian_cntry_code 	varchar2(5),
	guardian_pin_code 	varchar2(6),
	guardian_ph_num1        varchar2(15),
	guardian_ph_num2        varchar2(15),
	del_flg         	char(1),
	entity_cre_flg  	char(2),
	LCHG_USER_ID    	VARCHAR2(15),
	LCHG_TIME       	date,
	RCRE_USER_ID    	VARCHAR2(15),
	RCRE_TIME       	date,
	DATE_OF_NOMINATION	VARCHAR2(10)
)
/* STORE_START */
INITRANS 64 STORAGE (FREELISTS 16)
TABLESPACE IDX_ACCT_DETAILS_2
/* STORE_END */
/
CREATE UNIQUE INDEX IDX_CLND ON icici.cust_locker_nomination_detail(SOL_ID,nominee_no,cust_id,locker_num)
TABLESPACE SYSTEM PCTFREE 10  STORAGE(INITIAL 10240 NEXT 10240 PCTINCREASE 50 ) 
/
create public synonym CLND for icici.cust_locker_nomination_detail
/
grant all on CLND to tbaadm
/
grant select,insert,update,delete on CLND to tbagen
/
grant select on CLND to tbacust
/
grant select on CLND to tbautil
/
