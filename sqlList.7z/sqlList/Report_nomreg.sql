----------------------------------------------------------------------------------------------------
--   Source Name            : Report_nomreg.sql 
--   Description            : Nominee Register Report.
--   Input Values           : None
--   Output Values          : None
--   Called Script          : N.A
--   Calling Script         : N.A
--   Modification History:
--   Sl No.         Date              Author                     Description
--   --------------------------------------------------------------------------------------
--     01         15-Oct-2012         Priyanka                 Original Version
----------------------------------------------------------------------------------------------------

set serveroutput on size 1000000
set head off
set pau off
set echo off
set lines 250
set pages 0
set termout off
set verify off
set feedback off
spool Report_nomreg.lst

DECLARE

lv_solid         gam.sol_id%type :='&1';
lv_bankid     clmt.bank_id%type := '&2';


CURSOR c1 IS
select  clnd.sol_id,
        clnd.nominee_no,
        clnd.cif_id,
        wlckm.rack_id,
        clnd.locker_num,
        wlckm.locker_type,
        substr(cmg.cust_name,1,40) cust_name,
        clnd.nominee_name,
        clnd.nominee_add1,
        clnd.nominee_add2,
        clnd.nominee_stat_code,
        clnd.nominee_city_code,
        clnd.nominee_cntry_code,
        clnd.nominee_pin_code,
        clnd.date_of_birth,
        clnd.nominee_relation,
        DATE_OF_NOMINATION rcre_time
from    clnd, wlckm, cmg, clmt
where   wlckm.locker_num = clnd.locker_num
and    clmt.locker_num = wlckm.locker_num
and    clmt.locker_num = clnd.locker_num
and    clnd.cif_id = clmt.cif_id
and    cmg.cif_id = clnd.cif_id
and    clnd.sol_id = clmt.sol_id
and    clmt.sol_id = wlckm.sol_id
and    clnd.sol_id = lv_solid
and    clnd.bank_id = clmt.bank_id
and    clmt.bank_id = wlckm.bank_id
and    clnd.bank_id = lv_bankid
and    clnd.entity_cre_flg != 'N'
and    clnd.del_flg!='Y'
and    wlckm.del_flg!='Y'
and    clnd.del_flg!='Y'
and    clmt.del_flg!='Y'
union
select  clnd.sol_id,
        clnd.nominee_no,
        clnd.cif_id,
        wlckm.rack_id,
        clnd.locker_num,
        wlckm.locker_type,
        substr(cmg.cust_name,1,40) cust_name,
        clnd.nominee_name,
        clnd.nominee_add1,
        clnd.nominee_add2,
        clnd.nominee_stat_code,
        clnd.nominee_city_code,
        clnd.nominee_cntry_code,
        clnd.nominee_pin_code,
        clnd.date_of_birth,
        clnd.nominee_relation,
        DATE_OF_NOMINATION rcre_time
from    clnd, wlckm, cmg, clmt,cljh
where   wlckm.locker_num = clnd.locker_num
and    clmt.locker_num = wlckm.locker_num
and    clmt.locker_num = clnd.locker_num
and    clmt.locker_num = cljh.locker_num
and    clmt.cif_id = cljh.cif_mh_id
and    cljh.cif_jh_id = clnd.cif_id
and    cmg.cif_id = clnd.cif_id
and    clmt.sol_id = clnd.sol_id
and    clnd.sol_id = wlckm.sol_id
and    clmt.sol_id = cljh.sol_id
and    clnd.sol_id = lv_solid
and    clmt.bank_id = clnd.bank_id
and    clnd.bank_id = wlckm.bank_id
and    clmt.bank_id = cljh.bank_id
and    clnd.bank_id = lv_bankid
and    clnd.entity_cre_flg != 'N'
and    clnd.del_flg!='Y'
and    cljh.del_flg!='Y'
and    clmt.del_flg!='Y'
order by 2,5;
BEGIN

    for f1 in c1
    loop
dbms_output.enable(buffer_size => NULL);
dbms_output.put_line(    f1.sol_id        ||'|'||
            f1.nominee_no        ||'|'||
            f1.cif_id        ||'|'||
            f1.rack_id        ||'|'||
            f1.locker_num        ||'|'||
            f1.locker_type        ||'|'||
                f1.cust_name        ||'|'||
            f1.nominee_name        ||'|'||
            f1.nominee_add1        ||'|'||
            f1.nominee_add2        ||'|'||
            f1.nominee_stat_code    ||'|'||
            f1.nominee_city_code    ||'|'||
            f1.nominee_cntry_code    ||'|'||
            f1.nominee_pin_code    ||'|'||
            f1.date_of_birth    ||'|'||
            f1.nominee_relation    ||'|'||
            f1.rcre_time
        );
   end loop;
END;
/
spool off

