SET HEAD OFF
SET ARRAYSIZE 1
SET FEEDBACK OFF
SET VERIFY OFF
SET PAGESIZE 0
SET TRIMS ON
spool getBODdatediff.lst
select ltrim(db_stat_date - to_date('&1', 'dd-mm-yyyy')) from gct
/
spool off