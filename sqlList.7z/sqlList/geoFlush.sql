set head off
set trims on
set pages 0
set feedback off
set verify off
set termout off
spool &1-Flush.log

SELECT 'Flushing the PSP_TMP table for list &1' FROM DUAL;

DELETE	PSP_TMP
WHERE	listid LIKE '&1'||'%' ;

COMMIT;

spool off
