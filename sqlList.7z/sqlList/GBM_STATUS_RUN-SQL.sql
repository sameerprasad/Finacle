==============================================================================
-- File Name: GBM_STATUS_RUN-SQL.sql
-- Description: for spooling gbmstatus
-- Start Date: 17-Oct-2012 
-- Author: Ashutosh K Pandey
-- Modification History  :
-- Sl #      Date          Author Name            Description
-- ----  --------   -----------------         --------------
--  1    18-Oct-2012   Ashutosh K Pandey	Original Version
===============================================================================

set head off
set echo off
set verify off
set trims on
set pagesize 1000
spool gbmStatus
select 'SOL:'||count(distinct(SOL_ID))||',Amount:'||nvl(sum(challan_amount),0)||',Challan-Cnt:'||count(*) from ici_gbm_challan_master where tax_tran_date='&1' and del_flg='N';
spool off

