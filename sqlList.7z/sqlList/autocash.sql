set serveroutput on size 1000000
set pages 0
set lines 5000
set trims on
set verify off
set feedback off 
set termout off
--@autocash JASJI17 B 01 23 25-04-2003  0017 

var usid varchar2(15);
var tsubtype varchar2(10);
var trndate varchar2(10);
var end_time varchar2(2);
var start_time varchar2(2);
var usolid varchar2(4);
var bankid varchar2(8);
begin
        :usid := ('&1');
        :tsubtype := ('&2');
        :start_time := '&3';
        :end_time := '&4';
	:trndate := '&5';
	:usolid := '&6';
        :bankid := '&7';
end;
/

spool autocash.log

DECLARE
	locvar1 varchar2(100);
	accno GAM.foracid%type;
	accname GAM.acct_name%type;
	cnt_acid number:=0;
	dbdate   date;

	CURSOR hth_dth Is
		select tran_date, tran_id
		from hth where 
		tran_type = 'C'
		and init_sol_id = :usolid
		and tran_date = to_date(:trndate,'DD-MM-YYYY')
		and lchg_time >= to_date(to_char(lchg_time,'DD-MM-YYYY')||' '||:start_time, 'dd-mm-yyyy hh24')
      		and lchg_time < to_date(to_date(lchg_time,'DD-MM-YYYY')||' '||:end_time, 'dd-mm-yyyy hh24')	
		and ((tran_sub_type = (:tsubtype)) or ( 'B' = (:tsubtype)))
		and del_flg = 'N'
		and rcre_user_id = :usid
	        and bank_id = :bankid	
                union all
		select tran_date, tran_id
       	from dth where
       	tran_type = 'C'
       	and init_sol_id = :usolid
		and tran_date = to_date(:trndate,'DD-MM-YYYY')
		and lchg_time >= to_date(to_char(lchg_time,'DD-MM-YYYY')||' '||:start_time, 'dd-mm-yyyy hh24')
      and lchg_time < to_date(to_char(lchg_time,'DD-MM-YYYY')||' '||:end_time, 'dd-mm-yyyy hh24')
		and ((tran_sub_type = (:tsubtype)) or ( 'B' = (:tsubtype)))
       	and del_flg = 'N'
       	and rcre_user_id = :usid
         and bank_id = :bankid;
		hth_dth_rec hth_dth%rowtype;

	CURSOR auto_verify IS 
		select g.foracid accno,substr(g.acct_name,1,30) accname,d.tran_id trid, d.pstd_user_id pstid,d.tran_date trdt, d.tran_amt tramt, d.instrmnt_type instype, d.instrmnt_date instdt,substr(d.instrmnt_num,9,8) instno, d.tran_sub_type trst, d.part_tran_type prtt, d.part_tran_srl_num srlnum, d.tran_particular partlr
		from dtd d, gam g
		where 
			d.tran_date= hth_dth_rec.tran_date
		and d.tran_id= hth_dth_rec.tran_id
		and d.tran_amt < 50000
		and d.entry_user_id = :usid
		and d.pstd_user_id = :usid
		and d.pstd_flg = 'Y'
		and d.del_flg = 'N'
		and d.acid = g.acid
	        and d.bank_id = g.bank_id	
                and d.bank_id = :bankid 
                union all
		select g.foracid accno,substr(g.acct_name,1,30) accname,d.tran_id trid, d.pstd_user_id pstid,d.tran_date trdt, d.tran_amt tramt, d.instrmnt_type instype, d.instrmnt_date instdt,substr(d.instrmnt_num,9,8) instno, d.tran_sub_type trst, d.part_tran_type prtt, d.part_tran_srl_num srlnum, d.tran_particular partlr
        from htd d, gam g
	where d.tran_date= hth_dth_rec.tran_date
	and d.tran_id= hth_dth_rec.tran_id
                and d.tran_amt < 50000
               and d.entry_user_id = :usid
                and d.pstd_user_id = :usid
                and d.pstd_flg = 'Y'
                and d.del_flg = 'N'
                and d.acid = g.acid
                and d.bank_id = g.bank_id
                and d.bank_id = :bankid;

	auto_verify_rec auto_verify%rowtype;

BEGIN
	open hth_dth;	
	loop
	fetch hth_dth into hth_dth_rec;
	exit when hth_dth%notfound;
		open auto_verify;
		loop
		fetch auto_verify into auto_verify_rec;
		exit when auto_verify%notfound;
		begin
        	select PAYEE_NAME||'-'||br_code into locvar1
        	from ddc c
        	where c.tran_date = auto_verify_rec.trdt
        	and c.tran_id = auto_verify_rec.trid
        	and c.part_tran_srl_num = auto_verify_rec.srlnum 
                and c.bank_id = :bankid;
        exception
        when no_data_found then
            locvar1 := auto_verify_rec.partlr;
        end;


			dbms_output.put_line(auto_verify_rec.accno||'|'||auto_verify_rec.accname||'|'||auto_verify_rec.trid||'|'||auto_verify_rec.tramt||'|'||auto_verify_rec.instype||'|'||auto_verify_rec.instdt||'|'||auto_verify_rec.instno||'|'||auto_verify_rec.trst||'|'||auto_verify_rec.pstid||'|'||auto_verify_rec.trdt||'|'||auto_verify_rec.prtt||'|'||locvar1);
		end loop;
		close auto_verify;
	end loop;
	close hth_dth;
END;
/
spool off
exit
