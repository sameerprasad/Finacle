--#----------------------------------------------------------------------------------------
--#--    Name                : fqsPspAmtCal.sql
--#--    Description         : sql file for creating a list file with the foracid and to Amount
--#--    Author              : Amal
--#--    Date                : 19-12-2012
--#--    Called Menu Option  : Statement Generation
--#--    Modification History:
--#--
--#--     Sl. No       Date           Author              Description
--#--    --------     ------      --------------        -------------------------------
--#--    1            19-12-2012  Amal                  sql file for creating a list file with the foracid and to Amount
--#-- 	 2	      15-01-2013	Kumar Gandharv	changes made for proper sql execution
--#-----------------------------------------------------------------------------------------
set serveroutput on size 1000000 
set feedback off 
set verify off
set echo off
set trims on
set term off
set linesize 400
spool /tmp/tranList
DECLARE
foracid		    	   ICICI_STMT_FRE.foracid%TYPE;
chargeAmt              NUMBER;
recCount			   NUMBER;	
totAmt                 NUMBER;

CURSOR	CUR_FOR IS 
	select foracid from ICICI_STMT_FRE where bank_id = '&3';

BEGIN --{

	FOR CUR_FOR_REC in CUR_FOR 
	LOOP --{
	BEGIN

	  BEGIN
		SELECT NVL(CHARGE_AMT,0) into chargeAmt
		FROM ICICI_STMT_FRE 
		WHERE FORACID = CUR_FOR_REC.foracid and bank_id = '&3';
		exception
		WHEN NO_DATA_FOUND THEN chargeAmt:=0;
		 when OTHERS then null;
	  END;

	  BEGIN
		SELECT count(FORACID) INTO recCount 
		FROM  ICICI_STMT_CUST 
		WHERE to_char(LPRNT_DATE,'mm')= '&1' and to_char(LPRNT_DATE,'yyyy')= '&2'
		and FORACID = CUR_FOR_REC.foracid and bank_id = '&3';
		exception when OTHERS then NULL;
	  END;

		totAmt := chargeAmt * recCount; 

		DBMS_OUTPUT.PUT_LINE(CUR_FOR_REC.foracid|| '|' ||totAmt|| '|' ||'D');

	END;
	END LOOP;--} 
END; --} 
/
spool off

