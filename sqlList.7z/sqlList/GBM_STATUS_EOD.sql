==============================================================================
-- File Name: GBM_STATUS_EOD.sql
-- Description: spooling gbmEod
-- Start Date: 17-Oct-2012 
-- Author: Ashutosh K Pandey
-- Modification History  :
-- Sl #      Date          Author Name            Description
-- ----  --------   -----------------         --------------
--  1    18-Oct-2012   Ashutosh K Pandey	Original Version
===============================================================================

set head off
set echo off
set verify off
set trims on
set pagesize 1000
spool gbmEod
select 'EOD-NS:'||trim(count(decode(EOD_STATUS,'','Not Started')))||',ES:'||trim(count(decode(EOD_STATUS,'ES','EOD STARTED')))||',EE:'||trim(count(decode(EOD_STATUS,'EE','EOD ENDED')))||',CS:'||trim(count(decode(EOD_STATUS,'CS','CEOD STARTED')))||',CE:'||trim(count(decode(EOD_STATUS,'CE','CEOD ENDED'))) from ici_gbm_eod_ceod where EOD_DATE='&1'
/
spool off

