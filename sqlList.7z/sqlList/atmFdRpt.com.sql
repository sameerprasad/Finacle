-----------------------------------------------------------------------------------------------------
-- Filename         : atmFdRp.sql
-- Description      : This sql file spools out details from ici_adh_req_change table for a given date
--                    in specific format
-- Date             :  28-11-2012
-- Author           : Aparna Ashok
-- Menu Option      : atmFdRpt.com 
-- Modification History
-- Sl.#       Date           Author         Modification                              
-- -----   ----------   --------------    ----------------                               
--  1.0     28-11-2012   Aparna Ashok    Original Version                          
------------------------------------------------------------------------------------------------------



set pages 0 feedback off echo off verify off trims on lines 2000
spool atmfdreport_&1..txt

select FORACID||'^'||CIF_ID||'^'||SR_NO||'^'||REQUEST||'^'||REQ_FLG||'^'||PROC_FLG||'^'||RCRE_TIME||'^'||UPLOAD_DATE||'^'||UPDATE_USER_ID||'^'||REASON from ici_adh_req_change where SR_NO not like 'SR%' and rcre_time>='&1' and bank_id='&2'
/
spool off
