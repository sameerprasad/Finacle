rem accept solid prompt 'ENTER FOUR DIGIT SOL ID OF REPORT BRANCH : '
set feedback off
set echo off
set termout off
set verify off
set newpage 0
set linesize 80 
set pagesize 60
set numformat b999,99,99,99,99,99,999.99
set heading off
column today new_value today_date
column branch new_value bran 
select to_char(sysdate,'dd/mm/yyyy') today
from dual;
select br_name branch from bct where bank_id='&2' and br_code=(select br_code from sol			
												where sol_id = '&1' and bank_id='&2');
spool &1.allliabnew
--center 'REPORT ON LC LIABILITY AS ON ' today_date skip2 
----break on lc_type skip 1  on report  
--break on  report
--compute sum of lc_liab on lc_type 
--compute sum of lc_liab on report 
--col lc_type heading 'TYPE' format a10
--column lc_ref_num  heading lc_no
--column lc_liab format b999,999,99,999 
--set heading on
--select decode(lc_type, 'F', 'IMPORT', 'INLAND' ) lc_type,usance,
--sum(to_number(to_char(available_value * rate / B.fxd_crncy_units,999999999999))) lc_liab from dcmm, rtm B
-- -- where available_value > 0
--  and ( dc_reg_type ='OUTFR' and
--	B.ratecode=dcmm.ratecode and
--	B.fxd_crncy_code=dcmm.actl_crncy_code and
--	B.var_crncy_code='INR')
--and dcmm.sol_id = '&1' 
--group by lc_type,usance
--union
--select decode(dc_reg_type, 'OUTFR', 'IMPORT', 'INLAND' ) lc_type,usance,
--sum(to_number(to_char(available_value))) lc_liab from lcm 
--  where available_value > 0
--  and  lc_type='I' 
--group by lc_type,usance 
/
col cust_id format b999999999
col bg_type heading 'BG-TYPE' format a7
col bg_class format a3
col bg_amt format b999,99,99,999.99
col bg_perd_mths format 999
col bg_perd_days format 999
col claim_perd_mths format 999
col claim_perd_days format 999
col beneficiary_name format a40
col bg_status format a5 
break on bg_type on report
compute sum of bg_amt on bg_type 
compute sum of TOT_AMOUNT on report
set heading on
rem column today new_value today_date
rem select to_char (sysdate,'dd/mm/yyyy') today
rem from dual;
ttitle on
ttitle center ' ICICI BANKING CORPORATION LTD ' skip 1 -
center bran ' BRANCH' skip 1 -
center '  REPORT ON OUTSTANDING BANK GUARANTEES AS ON '  today_date ;
btitle left 'LIABILITY SHOWN IS RUPEE LIABILITY FOR INLAND/FOREIGN GUARANTEES'
set heading on
select bg_type, sum(BG_AMT*decode(rate,0,1,rate)) TOT_AMOUNT
from bgm  
        where (bg_status in ('A','E','G','O'))
and bgm.sol_id = '&1'
and bank_id='&2'
group by bg_type
/
ttitle off
btitle off
break on reg_type  on report
compute sum of VALUE on report
set heading off
rem column today new_value today_date
rem select to_char (sysdate,'dd/mm/yyyy') today
rem from dual;
ttitle on
ttitle center ' ICICI BANKING CORPORATION LTD ' skip 1 -
center bran ' BRANCH' skip 1 -
center 'SUMMARY OF INLAND BILLS SENT/RECD ON COLLECTION AS ON '  today_date 
set heading on
select reg_type,reg_sub_type,sum(bill_amt) VALUE
from blt
where bill_stat='G'
and cls_flg!='Y'
and reg_type in ('IBC','OCC','OBC')
and blt.sol_id = '&1'
and bank_id='&2'
group by reg_type,reg_sub_type
/
ttitle off
btitle off
break on reg_type  on reg_sub_type skip 1 on report
compute sum of VALUE on reg_type report
compute sum of VALUE on reg_sub_type report
set heading off
rem column today new_value today_date
rem select to_char (sysdate,'dd/mm/yyyy') today
rem from dual;
ttitle on
ttitle center ' ICICI BANKING CORPORATION LTD ' skip 1 -
center bran ' BRANCH' skip 1 -
center 'LIABILITY OF INLAND BILLS SENT/RECD ON COLLECTION AS ON '  today_date skip 1 - 
center '( INDIVIDUAL BILLS OUTSTANDING ) '
set heading on
select reg_type,reg_sub_type,unformatted_bill_id BillNo, bill_amt VALUE
from blt
where bill_stat='G'
and cls_flg!='Y'
and reg_type in ('IBC','OCC','OBC')
and blt.sol_id = '&1'
and bank_id='&2'
order by reg_type,reg_sub_type,BillNo 
/
ttitle off
break on reg_type  on report
compute sum of VALUE on report
set heading off
rem column today new_value today_date
rem select to_char (sysdate,'dd/mm/yyyy') today
rem from dual;
ttitle on
ttitle center ' ICICI BANKING CORPORATION LTD ' skip 1 -
center bran ' BRANCH' skip 1 -
center 'LIABILITY OF INLAND BILLS RECD ON COLLECTION AS ON ' today_date skip 1 -
center '(OTHER THAN OUR BRANCHES)' 
set heading on
select reg_type,reg_sub_type,sum(bill_amt) VALUE
from blt
where bill_stat='G'
and cls_flg!='Y'
and reg_type ='IBC'
and (lodg_coll_br_code not in (select br_code from bct where bank_code = 'ICI' and bank_id='&2')
or lodg_coll_br_code is null)
and blt.sol_id = '&1'
and bank_id='&2'
group by reg_type,reg_sub_type
/
ttitle off
break on reg_type on reg_sub_type on report
compute sum of VALUE on report
set heading off
rem column today new_value today_date
rem select to_char (sysdate,'dd/mm/yyyy') today
rem from dual;
ttitle on
ttitle center ' ICICI BANKING CORPORATION LTD ' skip 1 -
center bran ' BRANCH' skip 1 -
center 'LIABILITY OF INLAND BILLS RECD ON COLLECTION AS ON ' today_date skip 1 - 
center ' (INDIVIDUAL BILLS- BILLS FROM OUR BRANCHES EXCLUDED ) ' 
set heading on
select reg_type,reg_sub_type,unformatted_bill_id BILLNO,lodg_coll_br_code 
LodgBr,bill_amt VALUE
from blt
where bill_stat='G'
and cls_flg!='Y'
and reg_type = 'IBC'
and (lodg_coll_br_code not in (select br_code from bct where bank_code = 'ICI' and bank_id='&2')
or lodg_coll_br_code is null)
and blt.sol_id = '&1'
and bank_id='&2'
order by BILLNO
/
break on  report
break on reg_type on reg_sub_type on report
break on lc_ref_num skip 1 on report
compute sum of VALUE on lc_ref_num 
compute sum of VALUE on report 
set heading off
rem column today new_value today_date
rem select to_char (sysdate,'dd/mm/yyyy') today
rem from dual;
ttitle on
ttitle center ' ICICI BANKING CORPORATION LTD ' skip 1 -
center bran ' BRANCH' skip 1 -
center   'LIABILITY OF INLAND BILLS RECD UNDER L/C AS ON '  today_date ;
set heading on
select lc_ref_num,bill_id,reg_type,reg_sub_type,bill_amt VALUE
from blt
where bill_stat='G'
and cls_flg!='Y'
and reg_type = 'IBC'
and lc_dpg_co_ind='L'
and blt.sol_id = '&1'
and bank_id='&2'
/
ttitle off
break on reg_type,bill_crncy_code  on report
compute sum of INR_AMOUNT on report
set numformat b999,99,99,99,999.99
rem column today new_value today_date
col bill_crncy_code heading BILL-CURRNCY format a12
rem select to_char (sysdate,'dd/mm/yyyy') today
rem from dual;
ttitle on
ttitle center ' ICICI BANKING CORPORATION LTD ' skip 1 -
center bran ' BRANCH' skip 1 -
center 'LIABILITY OF FOREIGN BILLS SENT ON COLLECTION AS ON '  today_date skip2 
select reg_type,reg_sub_type,bill_crncy_code,sum(bill_amt) Amount,
sum(bill_amt_inr) INR_AMOUNT
from fbm
where bill_stat in ('G','P')
and cls_flg!='Y'
and reg_type in ('FOBC','FOCC')
and fbm.sol_id = '&1'
and bank_id='&2'
group by reg_type,reg_sub_type,bill_crncy_code
/
break on reg_type,bill_crncy_code  on report
compute sum of INR_AMOUNT on report
set numformat b999,99,99,99,999.99
rem column today new_value today_date
col bill_crncy_code heading BILL-CURRNCY format a12
rem select to_char (sysdate,'dd/mm/yyyy') today
rem from dual;
ttitle on
ttitle center ' ICICI BANKING CORPORATION LTD ' skip 1 -
center bran ' BRANCH' skip 1 -
center 'LIABILITY OF FOREIGN BILLS RECEIVED FOR COLLECTION AS ON '  today_date skip2 
select reg_type,reg_sub_type,bill_crncy_code,sum(bill_amt) Amount,
sum(bill_amt_inr) INR_AMOUNT
from fbm
where bill_stat in ('G', 'P')
and cls_flg!='Y'
and reg_type in ('ABLC','FIBC','FDIC')
and fbm.sol_id = '&1'
and bank_id='&2'
group by reg_type,reg_sub_type,bill_crncy_code
/
ttitle off
ttitle on
set linesi 135
set pagesi 60
set numformat B999,99,99,99,999.00
break on PARTYCODE skip 2 on NAME on LCNUM skip 2  on CRNCY  on report
compute sum of BILL_AMT_INR on LCNUM skip 1
compute sum of BILL_AMT on CRNCY 
compute sum of BILL_AMT on LCNUM skip 1 on report
compute sum of BILL_AMT_INR on report
ttitle center 'ICICI BANKING CORPORATION LTD  ' skip 1 -
center bran ' BRANCH' skip 1 -
center 'LIST OF IMPORT USANCE BILLS RECIVED UNDER L/C AS ON ' today_date
select fbm.party_code PARTYCODE,fbm.party_name NAME,dcmm.dc_ref_num LCNUM,
fbm.bill_id BILLNO,fbm.bill_crncy_code CRNCY,
fbm.bill_amt BILL_AMT,fbm.bill_amt_inr BILL_AMT_INR
from fbm,dcmm,fei
where fbm.sol_id=fei.sol_id
and dcmm.sol_id=fei.sol_id
and dcmm.dc_ref_num=fei.lc_number
and fei.bill_id= fbm.bill_id
and fbm.reg_type='ABLC'
and fbm.reg_sub_type='U'
and dcmm.sol_id=fbm.sol_id
and fbm.cls_flg!='Y'
and fbm.bill_stat in ('G','K', 'P')
and dcmm.dc_reg_type='OUTFR'
and fbm.sol_id = '&1'
and fei.sol_id = '&1'
and dcmm.sol_id = '&1'
and fbm.bank_id='&2'
and dcmm.bank_id='&2'
and fei.bank_id='&2'
order by PARTYCODE,LCNUM,CRNCY,BILLNO
/
spool off
exit
