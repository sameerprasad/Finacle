REM 'SCRIPT FOR FINDING ACCOUNT BALANCE of all accounts with BACID - SLSTAX'
REM 'AUTHOR :: T.Guhan'
set pages 60
set lines 80
set echo off
set feedback off
set verify off
set termout on
set serveroutput on SIZE 1000000
set newpage 0
ttitle center  'ICICI BANK LTD.' skip 1 -
center ' Report on Service tax balances in respective Sol for the period ' &1 ' - ' &2 skip 3 
spool sertax

DECLARE
opbal                eab.tran_date_bal%type;
clbal                eab.tran_date_bal%type;
difbal             	 eab.tran_date_bal%type;
total             	 eab.tran_date_bal%type:=0;

frdt                 date := to_date('&1','dd-mm-yyyy');
todt                 date := to_date('&2','dd-mm-yyyy');


cursor mygam is

select a.acid,a.sol_id Sol_Id,substr(b.sol_desc,1,40) Sol_Desc,a.foracid Acct_Name,
a.clr_bal_amt Balance from gam a,sol b where a.bacid='SLSTAX' and a.sol_id=b.sol_id 
and a.bank_id='&3' and b.bank_id='&3'
order by a.sol_id;

BEGIN
	 DBMS_OUTPUT.PUT_LINE('Sol Id|Sol Description|Account Name|Amount Collected');
    FOR tcur in mygam
    LOOP
        opbal:=0;
        BEGIN
            select nvl(tran_date_bal,0) into opbal
            from eab
            where acid=tcur.acid
            and end_eod_date >= (frdt-1)
            and eod_date <= (frdt-1)
            and bank_id='&3';
            exception
            when no_data_found
            then
            opbal:=0;
        END;

        clbal:=0;
        BEGIN
            select nvl(tran_date_bal,0) into clbal
            from eab
            where acid=tcur.acid
            and end_eod_date >= (todt)
            and eod_date <= (todt)
            and bank_id='&3';
            exception
            when no_data_found
            then
            clbal:=0;
        END;

      difbal:=clbal-opbal;
	  total:=total+difbal;

	DBMS_OUTPUT.PUT_LINE(tcur.sol_id||'|'||tcur.sol_desc||'|'||tcur.Acct_Name||'|'||difbal);

    END LOOP;

    DBMS_OUTPUT.PUT_LINE('Total Amount Collected |'||total);

EXCEPTION
when no_data_found then
null;
END;
/

set feedback on
set feedback on
set verify on
set heading on
spool off
set echo on
exit
