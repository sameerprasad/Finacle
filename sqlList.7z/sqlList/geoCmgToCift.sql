-- The cust_id has been modified to cif_id for both the tables cmg & icici_cift
set serveroutput on size 1000000
set linesize 512
set pages 0
set verify off
spool fsgCmgToCift
declare
locSolId UPR.sol_id%TYPE;

cursor custCur is
select cif_id,
       rcre_user_id
from   cmg
where  cif_id not in (select cif_id from icici_cift);

begin
for custRec in custCur loop
begin
	select sol_id
	into   locSolId
	from   UPR
	where  user_id = custRec.rcre_user_id;

	insert into icici_cift (cif_id, home_sol_id, stmt_reqd) 
	values (custRec.cif_id, locSolId, 'Y');

	EXCEPTION
	WHEN NO_DATA_FOUND THEN NULL;

	dbms_output.put_line(custRec.cif_id);
end;
end loop;

end;
/
spool off
quit
