set serveroutput on size unlimited
set pages 0
set verify off
set feedback off
set termout off
set lin 225
spool ifs

DECLARE

/* ##### VARIABLE DECLARATION ############## */
loc_billid        varchar(100);
loc_solid         varchar(100);
loc_iec_code      varchar(100);
loc_partyname     varchar(100);
loc_orign_city    varchar(100);
loc_orign_cntry   varchar(100);
loc_ifscCode      varchar(100);
loc_rownum        integer :=0;
loc_ifscCodeStat  varchar(100);
loc_gr_srl_num    varchar(100);
cnt               integer :=0;
conv_Rate number(9,4) :=1;
loc_relamt                number(20,2);
loc_relamt_inr    number(20,2);
loc_reldate               varchar(100);
loc_sbNum         varchar(100);
loc_port          varchar(100);
ifs_sol_id        varchar(100);
loc_shipbilldate varchar(100);
loc_invoiceBillDate date;
loc_statusOfBrc   varchar(10) := '&2';
loc_day_of_year varchar(100) := '000';

/* ##### END OF VARIABLE DECLARATION ####### */


/* ###### CURSOR CONSTRUCTOR ############### */
CURSOR C1 IS
Select 'A' loc_id,bill_id,GR_SRL_NUM,SOL_ID,tr_crncy,GR_NUM,REALISE_DATE,AMT_REALIZED
from gde
where REALISE_DATE = '&1'
and bill_id = decode('&3','ALL',bill_id,'&3')
and del_flg !='Y'
and bank_id='BM3'
and AMT_REALIZED > 0
union all
select 'B' loc_id,fbm.bill_id,SRL_NUM "GR_SRL_NUM",fbm.SOL_ID,GR_CRNCY_CODE "tr_crncy",GR_NUM,LODG_DATE "REALISE_DATE",ADV_PAYMENT_AMT "AMT_REALIZED"
from fbm,grh
where grh.bill_id=fbm.bill_id
and fbm.bill_id = decode('&3','ALL',fbm.bill_id,'&3')
and grh.sol_id=fbm.sol_id
and REG_TYPE='FOBC' and REG_SUB_TYPE='EXADV' and LODG_DATE='&1' and fbm.del_flg !='Y'
and grh.del_flg !='Y'
and fbm.bank_id='BM3'
and grh.bank_id='BM3'
order by bill_id,GR_SRL_NUM;


CURSOR C2 IS
Select BILL_CRNCY_CODE,CORR_COLL_BANK_CODE,SB_NUM,PORT_CODE,SHPMNT_DATE,GR_AMT,ADV_PAYMENT_AMT,SB_DATE,fbm.PARTY_NAME,PARTY_CODE,OTHER_PARTY_CNTRY_CODE,substr(SB_NUM,1,2) chksb,fbm.purpose_of_rem
from fbm,grh
where fbm.sol_id=loc_solid
and fbm.bill_id=loc_billid
and fbm.bill_id=grh.bill_id
and grh.SRL_NUM=loc_gr_srl_num
and fbm.bank_id='BM3'
and grh.bank_id='BM3'
and fbm.del_flg !='Y'
and grh.del_flg !='Y';



/* ###### END OF CURSOR CONSTRUCTOR ####### */

/*  fp              UTL_FILE.FILE_TYPE; */
 /* fname           varchar(100); */
 /* fpath           varchar(100); */
 /* fmode           varchar(100); */

BEGIN
/*   fpath := '/mistmp1';  */
/*   fname := 'ifs.txt';  */
/*   fmode := 'w';  */

/*  fp := UTL_FILE.FOPEN(fpath,fname,fmode); */
 loc_ifscCodeStat := 'ICIC0000000';

        select to_char(to_date('&1'),'DDD')||to_char(to_date('&1'),'YY') into loc_day_of_year from dual;

if ('&3' = 'ALL') then
        loc_rownum :=0;
else
        select (substr('&3',length('&3') -3,length('&3'))) into loc_rownum from dual;
end if;


FOR c in C1 Loop
begin
loc_solid := c.SOL_ID;
loc_billid := c.bill_id;
loc_gr_srl_num := c.GR_SRL_NUM;
cnt := 0;
        FOR d in C2 Loop
         Begin

                loc_relamt_inr :=0;

                Select to_number(loc_solid) into ifs_sol_id from dual;

                if (length(ifs_sol_id)) < 2 then

                        ifs_sol_id:='0'||ifs_sol_id;
                end if;

                Begin
                Select ORIGIN_OF_GOODS,origin_cntry_code into loc_orign_city,loc_orign_cntry
                from fei where sol_id=loc_solid and bill_id=loc_billid and del_flg !='Y' and bank_id='BM3' and rownum=1;
                exception
                when no_data_found then
                        loc_orign_city :='';
                        loc_orign_cntry :='';
                end;
                Begin
                Select BANK_IDENTIFIER into loc_ifscCode
                from BRBIC
                where brbic.branch_code = ifs_sol_id and PAYSYS_ID='NEFT' and BANK_IDENTIFIER like '%ICI%' and bank_id='BM3' and rownum=1;
                exception
                when no_data_found then
                        loc_ifscCode:='';
                end;

                if (loc_ifscCode = '') then
                        begin
                        Select BANK_IDENTIFIER into loc_ifscCode
                        from BRBIC
                        where brbic.branch_code = ifs_sol_id and PAYSYS_ID='GROSS' and BANK_IDENTIFIER like '%ICI%' and bank_id='BM3' and rownum=1;
                        exception
                        when no_data_found then
                                loc_ifscCode:='';
                        end;
                end if;

                begin
                        select JCCI_CODE into loc_iec_code from tbaadm.fpc
                         where PARTY_CODE = d.PARTY_CODE and bank_id='BM3' and rownum=1;

                exception
                when no_data_found then
                        loc_iec_code :='';
                end;

                if(d.chksb = 'ZZ') then
                Begin
                        Select INVOICE_NUM,INVOICE_DATE into loc_sbNum,loc_invoiceBillDate from grh where
                        grh.sol_id=loc_solid
                        and grh.bill_id=loc_billid
                        and c.gr_num = grh.gr_num
                        and c.GR_SRL_NUM = grh.SRL_NUM
                        and grh.del_flg !='Y'
			and bank_id='BM3'
                        and rownum =1;
                exception
                        when no_data_found then
                        loc_sbNum :='';
                        loc_invoiceBillDate := '';
                end;
                        if (trim(d.purpose_of_rem) = 'P1505') then
                                loc_port := 'DEEMED';
                        else
                                loc_port := 'OTHERS';
                        end if;
                else
                        loc_invoiceBillDate := d.SB_DATE;
                        loc_sbNum:=d.SB_NUM;
                        loc_port := 'IN'||d.PORT_CODE;
                end if;

                /* ###### Calculating Realise Amount in INR  ####### */
                conv_Rate:=1;
                begin --{
                select nvl(var_crncy_units/fxd_crncy_units,1) into conv_rate from rth
                        where ratecode='NOR'
                                and var_crncy_code='INR'
                                and fxd_crncy_code=c.tr_crncy
				and bank_id='BM3'
                                and rtlist_date =
                                (select max(rtlist_date) from rth
                                 where fxd_crncy_code=c.tr_crncy
                                 and var_crncy_code='INR'
                                 and ratecode='NOR'
				 and bank_id='BM3'
                                 and rtlist_date<=c.REALISE_DATE)
                                and rtlist_num =
                                 (select max(rtlist_num) from rth
                                  where fxd_crncy_code=c.tr_crncy
                                  and var_crncy_code='INR'
				  and bank_id='BM3'
                                  and ratecode='NOR'  and rtlist_date=
                                (select max(rtlist_date) from rth
                                 where fxd_crncy_code= c.tr_crncy
                                 and var_crncy_code='INR'
                                 and ratecode='NOR'
				 and bank_id='BM3'
                                 and rtlist_date<=c.REALISE_DATE)) ;
                exception
                        when no_data_found
                        then
                                conv_Rate:=1;
                end; --}

                loc_relamt_inr := conv_Rate * c.AMT_REALIZED;

                loc_rownum := loc_rownum +1;
                DBMS_OUTPUT.PUT_LINE(loc_ifscCode||''||loc_day_of_year||''||lpad(loc_rownum,4,0)||'|'||to_char(to_date('&1'),'YYYY-MM-DD')||'|'||loc_statusOfBrc||'|'||loc_iec_code||'|'||d.PARTY_NAME||'|'||loc_ifscCode||'|'||loc_billid||'|'||loc_sbNum||'|'||loc_port||'|'||to_char(to_date(loc_invoiceBillDate),'YYYY-MM-DD')||'|'||d.BILL_CRNCY_CODE||'|'||to_char(d.GR_AMT,'9999999999.99')||'|'||c.tr_crncy||'|'||to_char(c.AMT_REALIZED,'9999999999.99')||'|'||to_char(to_date(c.REALISE_DATE),'YYYY-MM-DD')||'|'||to_char(loc_relamt_inr,'9999999999.99')||'|');
                cnt := cnt +1;
        end;
        END LOOP;
end;
END LOOP;

/* UTL_FILE.FCLOSE(fp); */
/* EXCEPTION */
/*         WHEN OTHERS THEN */
/*         BEGIN */
/*                 UTL_FILE.PUT_LINE(fp,'ERROR'); */
/*                 UTL_FILE.PUT_LINE(fp,sqlerrm||'|'||sqlcode); */
/*                 UTL_FILE.FCLOSE(fp); */
/*         END; */
END;
/
SPOOL OFF
