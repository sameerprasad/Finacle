---------------------------------------------------------------------------------
-- Filename         : cibsollist.sql
-- Description      : This sql file spools out sol ids from the sol table 
-- Date             : 20-09-2012
-- Author           : Aparna Ashok
-- Menu Option      : HEXECOM
-- Modification History
-- Sl.#       Date           Author         Modification                              
-- -----   ----------   --------------    ----------------                               
--  1.0    20-09-2012   Aparna Ashok    Original Version                          
----------------------------------------------------------------------------------------------


set head off
set feedback off
set verify off
set linesize 5
set pagesi 0
spool cibALL.txt
select sol_id from sol
where bank_id = '&1' 
order by sol_id
/
spool off
exit
