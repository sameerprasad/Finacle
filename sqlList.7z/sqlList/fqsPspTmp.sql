----------------------------------------------------------------------------------------
--    Name                : fqsPspTmp.sql
--    Description         : sql file for inserting values into PSP_TMP table
--    Author              : Amal
--    Date                : 19-12-2012
--    Called Menu Option  : Statement Generation
--    Modification History:
--
--     Sl. No       Date           Author              Description
--    --------     ------      --------------        -------------------------------
--    1            19-12-2012  Amal                  sql file for inserting values into PSP_TMP table
--	2	   07-01-2013	Kumar Gandharv		changed query for proper execution
-----------------------------------------------------------------------------------------
set serveroutput on size 1000000 
set feedback off 
set verify off
set linesize 500
set echo off
set trims on
set term on

spool gandharv.txt 
DECLARE
foracid		    	   ICICI_STMT_FRE.foracid%TYPE;
sub_type	    	   ICICI_STMT_FRE.sub_type%TYPE;
listId                 	   TBAADM.PSP_TMP.LISTID%TYPE;
solId     		     TBAADM.PSP_TMP.HOME_SOL_ID%TYPE;

CURSOR	CUR_PSP IS 
	select	foracid,
		sub_type 
	from ICICI_STMT_FRE;

BEGIN --{

	FOR CUR_PSP_REC in CUR_PSP 
	LOOP --{
	begin
	    solId  := SUBSTR(CUR_PSP_REC.foracid,1,4);
	    dbms_output.put_line('Foracid : ' || CUR_PSP_REC.foracid);
	    delete from tbaadm.psp_tmp where ENTITY_ID = CUR_PSP_REC.foracid and bank_id = '&1' ;
	    COMMIT;
	    IF (CUR_PSP_REC.sub_type != 'N') THEN
	       insert into tbaadm.psp_tmp values ('FRE'||solID||'0'||'_A',CUR_PSP_REC.foracid,'0',solId,'&1');
--	       exception when OTHERS then NULL;
        END IF;
	END;
	END LOOP;--} 
	COMMIT;
END; --} 
/
spool off

