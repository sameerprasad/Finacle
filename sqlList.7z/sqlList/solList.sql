--===================================================================================================================
--Filename             :  solList.sql
--Description          :  sql to select solId from sol table.             
--Date                 :  12-09-2012
--Author               :  Amal,Vaibhav Bansal
--Menu Option          :  EXECOM1,BJSTM20
--Modification History
--    Sl. #             Date             Author             Modification                              
--    -----            -----            --------           ----------------                               
--    01	      30-08-2012	Amal			                              
--    02              12-09-2012       Vaibhav Bansal       Coding Standard Changes                          
--===================================================================================================================
set head off
set feedback off
set verify off
set linesize 5
set pagesi 0
//spool solALL.txt
spool solList.lst
SELECT sol_id FROM tbaadm.sol
WHERE bank_id = '&1' ORDER BY sol_id
/
spool off
exit


