----------------------------------------------------------------------------------------------------
--   Source Name            : lcvactrpt.sql
--   Description            : Vacant Locker Report.
--   Input Values           : None
--   Output Values          : None
--   Called Script          : N.A
--   Calling Script         : N.A
--   Modification History:
--   Sl No.         Date              Author                     Description
--   --------------------------------------------------------------------------------------
--     01         16-Oct-2012         Priyanka                 Original Version
----------------------------------------------------------------------------------------------------

SET SERVEROUTPUT ON SIZE 1000000;
SET VERIFY OFF
SET TERMOUT OFF
SET TRIMSPOOL ON
SET ECHO OFF
SET FEEDBACK OFF
SET EMBEDDED ON
SET LINES 400
SET HEAD OFF
SET PAGES 0
clear columns
clear breaks
clear computes
set serveroutput on

spool lcvactrpt.lst

declare

v_sol_id                clmt.sol_id%type;
v_rack_id               wlckm.rack_id%type;
v_locker_type           wlckm.locker_type%type;
v_locker_num            clmt.locker_num%type;
v_key_num               wlckm.key_num%type;
v_rent_amt              lclrm.rent_amt%type;
lv_bod_date		date;

v_solid                 clmt.sol_id%type;
v_rpt_type		varchar2(20) ;
v_set_id		sst.set_id%type;
v_bankid		clmt.bank_id%type ;

cursor solval (v_solid clmt.sol_id%type,v_bankid clmt.bank_id%type) is
SELECT     SOL_ID 
FROM     SST 
WHERE     SET_ID in v_solid
AND       BANK_ID = v_bankid;

cursor c1 (v_set_id sst.set_id%type,v_bankid clmt.bank_id%type) is
SELECT    SOL_ID,
    RACK_ID,
    LOCKER_TYPE,
    COUNT(LOCKER_NUM) 
FROM    WLCKM 
WHERE	   STATUS = 'A' 
AND        SOL_ID = v_set_id
AND        BANK_ID = v_bankid
AND        DEL_FLG != 'Y'
AND        ENTITY_CRE_FLG = 'Y'
GROUP BY SOL_ID,RACK_ID,LOCKER_TYPE 
ORDER BY RACK_ID,COUNT(LOCKER_NUM);

cursor c2 (v_set_id sst.set_id%type,v_bankid clmt.bank_id%type) is
SELECT    SOL_ID,
    RACK_ID,
    LOCKER_TYPE,
    LOCKER_NUM,
    KEY_NUM 
FROM    WLCKM 
WHERE    STATUS = 'A'
AND      SOL_ID = v_set_id
AND      BANK_ID = v_bankid
AND      DEL_FLG != 'Y'
AND      ENTITY_CRE_FLG = 'Y'
GROUP BY SOL_ID,RACK_ID,LOCKER_TYPE,LOCKER_NUM,KEY_NUM 
ORDER BY RACK_ID,LOCKER_NUM;


BEGIN
    v_rpt_type := '&1';
    v_solid    := '&2';
    v_bankid   := '&3';
    
    Open solval(v_solid,v_bankid);
    loop
    --{
        if(solval%ISOPEN) then
        --{
            FETCH solval INTO
            v_set_id;
            
             IF (solval%NOTFOUND) THEN
                CLOSE solval;
                EXIT;
            END IF;
        --}
        end if;
        
        if (v_rpt_type = 'C') then
        --{
            OPEN c1(v_set_id,v_bankid);
            loop
            --{
                if (c1%ISOPEN) then
                --{
                FETCH c1
                INTO
                    v_sol_id,
                    v_rack_id,
                    v_locker_type,
                    v_locker_num;

                     IF (c1%NOTFOUND) THEN
                        CLOSE c1;
                        EXIT;
                    END IF;
                --}
                end if;
                dbms_output.enable(buffer_size => NULL);    
                dbms_output.put_line(   v_sol_id		||'|'||
					v_rack_id               ||'|'||
					v_locker_type           ||'|'||
					v_locker_num		||'|'||
					v_rpt_type		||'|'||
					v_key_num		||'|'||
					v_rent_amt);
            --}
            end loop;
        --}
        end if;

         if (v_rpt_type = 'D') then
        --{
            OPEN c2(v_set_id,v_bankid);
            loop
            --{
                if (c2%ISOPEN) then
                --{
                FETCH c2
                INTO
                    v_sol_id,
                    v_rack_id,
                    v_locker_type,
                    v_locker_num,
                    v_key_num;
                    ---------------------------------------------------
                    ----To Arrive Rent for each locker type
                    ---------------------------------------------------
                    -----------Find BOD Date-------------------
                    BEGIN
                    --{
                        SELECT to_date(DB_STAT_DATE,'dd-mm-yyyy')
                        INTO lv_bod_date
                        FROM GCT
                        WHERE DEL_FLG!='Y';
                    EXCEPTION when no_data_found THEN
                        lv_bod_date := null;
                    --}
                    END;
                    ------------------To Arrive the Rent---------------------
                    BEGIN
                    --{
                        SELECT distinct a.rent_amt
                        INTO v_rent_amt
                        FROM lclrm a,sst c
                        WHERE a.sol_id = c.set_id
                        and     a.location_code = c.set_id
                        and     c.set_id like 'LOC%'
                        and     c.sol_id = v_sol_id
                        and     a.bank_id = c.bank_id
                        and     c.bank_id = v_bankid
                        and     a.locker_type = v_locker_type
                        and     a.RENT_PERIOD='1'
                        and     a.Rent_Version_Code = (SELECT max(b.Rent_Version_Code)
                        FROM lclrm b
                        WHERE a.location_code = b.location_code
                        and     a.locker_type=b.locker_type
                        and     a.RENT_PERIOD=b.RENT_PERIOD
                        and     a.sol_id = b.sol_id
                        and     b.rent_effective_date <= lv_bod_date)
                        and     a.del_flg != 'Y'
                        and     a.entity_cre_flg != 'N';
                    EXCEPTION when no_data_found THEN
                        v_rent_amt := 0;
                    --}
                    END;
                     IF (c2%NOTFOUND) THEN
                        CLOSE c2;
                        EXIT;
                    END IF;
                --}
                end if;
                dbms_output.enable(buffer_size => NULL);
                dbms_output.put_line(   v_sol_id                ||'|'||
					v_rack_id               ||'|'||
					v_locker_type           ||'|'||
					v_locker_num            ||'|'||
					v_rpt_type		||'|'||
					v_key_num		||'|'||
					v_rent_amt);
            --}
            end loop;
            --}
            end if;
    --}
    end loop;
end;
/
spool off

