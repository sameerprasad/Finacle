-------------------------------------------------------------------------------------------------------------
-- FileName                 : clmAdtTraildp001.sql
-- Author                   : Chokkalingam Lakshmanan
-- Date                     : 16-12-2005
-- Description              : selects the fields corresponding to the inputs
-- Input1                   : From date
-- Input2                   : To date
-- Output                   :
-- Calling Script           : adtTraildp001.com
-- Modifications            : None
-------------------------------------------------------------------------------------------------------------
-- ---------------------------------------------
-- Declaration of the package and the Procedure
-- ---------------------------------------------

CREATE OR REPLACE PACKAGE clmAdtTrailpack AS
    PROCEDURE clmAdtTrailproc(inp_str VARCHAR2,
            out_retCode OUT NUMBER,
            out_rec OUT VARCHAR2);

END clmAdtTrailpack;

/

CREATE OR REPLACE PACKAGE BODY clmAdtTrailpack AS
--{
-------------------------------------------------------------------
--Declaring the variables to be used in the Procedure
-------------------------------------------------------------------
outArr          basp0099.ArrayType;
from_date       DATE;
to1_date         DATE;
	
cursor getclmAdtTrailAccts(from_date DATE,to_date DATE) is
--{

SELECT	REF_NUMBER,
		DOC_CRE_NUM,
		TOT_AMT_CLAIMED_A2,
		TOT_AMT_CLAIMED_A3,
		ISSU_BANK_A1,
		CLAIM_BANK_REF,
		TOT_AMT_CLAIMED_A1,
		RCRE_TIME,
		PRIN_AMT_CLAIMED,
		ADDT_AMT_CLM,
		RCRE_USER_ID,
		LCHG_USER_ID
FROM	C_742
WHERE	RCRE_TIME >= from_date 
AND		RCRE_TIME <= to1_date;

--}


-- --------------------------------------------------------------------
--Procedure body
-- --------------------------------------------------------------------

PROCEDURE clmAdtTrailproc(	inp_str     IN  VARCHAR2,
                      	out_retCode OUT NUMBER,
                     	out_rec     OUT VARCHAR2) AS


	out_arr 				basp0099.ArrayType;
	refNumber				C_742.REF_NUMBER%TYPE;
	docCreNum				C_742.DOC_CRE_NUM%TYPE;
	crncy					C_742.TOT_AMT_CLAIMED_A2%TYPE;
	totAmt					C_742.TOT_AMT_CLAIMED_A3%TYPE;
	issueBank				C_742.ISSU_BANK_A1%TYPE;
	claimBankRefNum			C_742.CLAIM_BANK_REF%TYPE;
	valueDate				C_742.TOT_AMT_CLAIMED_A1%TYPE;
	rcre_date				C_742.RCRE_TIME%TYPE;
	dc_open_bank			C_740.LC_NUM%TYPE;
	prn_amt_claim			C_742.PRIN_AMT_CLAIMED%TYPE;
	add_amt_claim			C_742.ADDT_AMT_CLM%TYPE;
	entered_by				C_742.RCRE_USER_ID%TYPE;
	vrfd_by					C_742.LCHG_USER_ID%TYPE;
	

BEGIN
--{
	out_retCode := 0;

---------------------------------------------
-- Checking whether the cursor is open if not
-- it is opened
---------------------------------------------

	IF NOT getclmAdtTrailAccts%ISOPEN THEN
	--{
		basp0099.formInputArr(inp_str,out_arr);
		from_date	:=  to_date(out_arr(0),'dd-mm-yyyy'); 
		to1_date	    := to_date(out_arr(1),'dd-mm-yyyy'); 
		OPEN getclmAdtTrailAccts(from_date,to1_date);
	--}
	END IF;


	IF getclmAdtTrailAccts%ISOPEN THEN
	--{
		FETCH	getclmAdtTrailAccts
		INTO	refNumber,
   		 		docCreNum,
				crncy,
				totAmt,
				issueBank,
				claimBankRefNum,
				valueDate,
				rcre_date,
				prn_amt_claim,
				add_amt_claim,
				entered_by,
				vrfd_by;
	--}
	END IF;

	totAmt	:=	prn_amt_claim + add_amt_claim;

	IF getclmAdtTrailAccts%NOTFOUND THEN
	--{
		CLOSE getclmAdtTrailAccts;
		out_retCode := 1;
		RETURN;
	--}
	END IF;

	BEGIN
	--{
		SELECT	SWIFT_CODE
		INTO	dc_open_bank
		FROM	C_740
		WHERE	LC_NUM	=	docCreNum
		AND		ROWNUM	<	2;
	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			dc_open_bank	:=	'';
	--}
	END;

	out_rec := 	
	refNumber			||'|'||
    docCreNum			||'|'||
    crncy				||'|'||
    totAmt				||'|'||
    issueBank			||'|'||
    claimBankRefNum		||'|'||
    valueDate			||'|'||
	rcre_date			||'|'||
	dc_open_bank		||'|'||
	entered_by			||'|'||
	vrfd_by;



END clmAdtTrailproc; 				 --}Procedure ends

END clmAdtTrailpack; 			     --}Package ends

-------------------------------------------------------
-- Execution grants are given to Tbacust Tbautil Tbagen
-------------------------------------------------------
/
DROP PUBLIC SYNONYM clmAdtTrailpack
/
CREATE PUBLIC SYNONYM clmAdtTrailpack FOR clmAdtTrailpack
/
GRANT EXECUTE ON clmAdtTrailpack TO TBAGEN, TBAUTIL, TBACUST
/
show err
