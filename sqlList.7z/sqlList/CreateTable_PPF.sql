-- This is the main script for Locker tables creation.
-- Do not run the individual SQL scripts separately
-- This script also does the rename of cust_id field to CIF_ID
-- This script changes the size of CIF_ID Field to 50
-- This table also does alter table for adding bank_id field
----------------------------------------------------------------------------------------------------
set echo on
set feedback on
set verify on
spool CreateTable_PPF

start CreateTable_PFAH.sql
start CreateTable_PFAM.sql
start CreateTable_PFAMTRFS_MOD.sql
start CreateTable_PFAM_ARR.sql
start CreateTable_PFAM_MOD.sql
start CreateTable_PPFCFG.sql
start CreateTable_PPFOCL.sql
start CreateTable_PPFTRFS_OUT.sql
start CreateTable_CPTMSG.sql


spool alterTable_PPF
start alterTable_PPF.sql

spool CreateIndex_PPF
start CreateIndex_PFAH.sql
start CreateIndex_PFAM.sql
start CreateIndex_PFAM_ARR.sql
start CreateIndex_PFAM_MOD.sql
start CreateIndex_PPFOCL.sql
start CreateIndex_PPFTRFS_OUT.sql
start CreateIndex_CPTMSG.sql

spool ppfcfgInsert
start ppfcfgInsert.sql

spool off

