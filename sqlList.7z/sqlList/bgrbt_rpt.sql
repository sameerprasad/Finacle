--=======================================================
-- Menu		: BGRBT
-- Modification	:
-- Source Name  : bgrbt_rpt.sql
-- [Author]         [Date]          [Line]      [Desc]
-- Kumar          19-03-2012		      Changes according
--					      Coding Standards incorporated
-- Pavan          11-02-2013                  Changes 
--                                            For TOL 327416
--=======================================================
set serveroutput on size unlimited
set lines 2000
set feedback off
set trims on
set pages 0
set echo off
set verify off
set head off
spool bgRbateMn002.lst


declare
max_dueDt date := '';
min_dueDt date := '';
next_dueDt date := '';
tot_days number := '0';
v_days number := '0';
accr_amt number(20,4) := '0';
v_tran_amt number(20,4) := '0';
v_srlnum VARCHAR2(5):= '0';
v_rbt_amt number(20,4) := '0';
v_nxtduedate date := '';
v_dsrlnum VARCHAR2(5):= '0';

cursor cursor1 is 
(select b.B2K_ID,
b.B2KID_TYPE, 
b.PTRAN_BUS_TYPE,
b.event_srl_num, 
b.tfct_key_srl_num,
b.chrg_event_id,
b.EVENT_TYPE,
b.chrg_coll_type UPFRONT_DEF_FLG,
b.CR_DR_IND, 
b.CHRG_CRNCY_CODE,
b.TTL_SYS_CALC_CHRG_AMT,
b.TTL_CHRG_TOBE_COLL_AMT,
d.CHRG_TRAN_ID tran_id,
d.CHRG_TRAN_DATE,
--g.TRAN_RMKS,
b.REMARKS_CHARGES TRAN_RMKS,
b.OPER_ACID,
b.OPER_CRNCY_CODE,
b.CHRG_ACID,
b.RATE_CODE,
b.RATE,
b.REFUND_FLG,
b.DR_CONS_FLG,
d.del_flg SUPERSEDE_FLG,
b.TTL_CHRG_DUE_AMT,
b.TTL_CHRG_COLL_AMT,
a.bg_srl_num,
a.effective_date,
a.claim_expiry_date,
a.sol_id bgmsolid,
a.bg_expiry_date ,
(select foracid from tbaadm.gam where acid =a.oper_acid) chrg_ac 
 from  tbaadm.bgm a, tbaadm.tfct b, tbaadm.gam c ,tbaadm.CXL d,tbaadm.bet e,tbaadm.DTD g
 where a.BG_B2KID = b.B2K_ID  
 and b.b2k_id=e.bg_b2kid  
--Commenting below two condtions as these values are not getting insereted in the actual flow ##PAVAN TOL 327416
 --and d.chrg_tran_id  like e.chrg_tran_id  
 --and  g.part_tran_srl_num=d.chrg_part_tran_srl_num  
 and g.tran_id=d.chrg_tran_id
 and  a.bank_id=e.bank_id    
 and a.bank_id=b.bank_id  
 and a.bank_id=c.bank_id   
 and a.bank_id=d.bank_id   
 and a.bank_id=e.bank_id   
 and a.bank_id=g.bank_id  
 --and a.oper_acid=d.chrg_acid
 --and d.target_acid=c.acid
 and d.chrg_acid=c.acid
 and a.oper_acid=d.target_acid
 and c.entity_cre_flg = 'Y'
 and c.del_flg != 'Y'  
 and c.bacid='CNGTE-ISSUE' 
 and a.bg_status not in ('Z','R','K') 
 and (b.PTRAN_BUS_TYPE = '!' OR b.PTRAN_BUS_TYPE = 'COMM')
 and a.effective_date <= '&1'
 and a.bg_expiry_date >= '&1'
 and a.claim_expiry_date > '&1'
 and b.bank_id='&2'
 and c.acct_cls_date is null
 --Adding new conditions for Duplicate records elimination
-- and a.oper_acid=c.acid 
--and a.sol_id=e.TRAN_SOL_ID
--and d.chrg_tran_id=g.tran_id
and e.EVENT_SRL_NUM like b.EVENT_SRL_NUM
and g.acid=c.acid
and b.CHRG_ACID=c.acid
--and   g.TRAN_RMKS like a.bg_srl_num
 --till here Adding new conditions for Duplicate records elimination
and substr(comp_b2kid,1,12) like '%'||a.BG_B2KID||'%'
--and  a.bg_srl_num like '%6156BG00003213%'
--order by a.sol_id 
)
--union all
union
(select b.B2K_ID,
b.B2KID_TYPE,
b.PTRAN_BUS_TYPE,
b.event_srl_num,
b.tfct_key_srl_num,
b.chrg_event_id,
b.EVENT_TYPE,
b.chrg_coll_type UPFRONT_DEF_FLG,
b.CR_DR_IND,
b.CHRG_CRNCY_CODE,
b.TTL_SYS_CALC_CHRG_AMT,
b.TTL_CHRG_TOBE_COLL_AMT,
d.CHRG_TRAN_ID tran_id,
d.CHRG_TRAN_DATE,
--g.TRAN_RMKS,
b.REMARKS_CHARGES TRAN_RMKS,
b.OPER_ACID,
b.OPER_CRNCY_CODE,
b.CHRG_ACID,
b.RATE_CODE,
b.RATE,
b.REFUND_FLG,
b.DR_CONS_FLG,
d.del_flg SUPERSEDE_FLG,
b.TTL_CHRG_DUE_AMT,
b.TTL_CHRG_COLL_AMT,
a.bg_srl_num,
a.effective_date,
a.claim_expiry_date,
a.sol_id bgmsolid,
a.bg_expiry_date ,
(select foracid from tbaadm.gam where acid =a.oper_acid) chrg_ac
 from  tbaadm.bgm a, tbaadm.tfct b, tbaadm.gam c ,tbaadm.CXL d,tbaadm.bet e,tbaadm.HTD g
 where a.BG_B2KID = b.B2K_ID
 and b.b2k_id=e.bg_b2kid
--Commenting below two condtions as these values are not getting insereted in the actual flow ##PAVAN TOL 327416
 --and d.chrg_tran_id  like e.chrg_tran_id
 --and  g.part_tran_srl_num=d.chrg_part_tran_srl_num
 and g.tran_id=d.chrg_tran_id
 and  a.bank_id=e.bank_id
 and a.bank_id=b.bank_id
 and a.bank_id=c.bank_id
 and a.bank_id=d.bank_id
 and a.bank_id=e.bank_id
 and a.bank_id=g.bank_id
 --and a.oper_acid=d.chrg_acid
 --and d.target_acid=c.acid
 and d.chrg_acid=c.acid
 and a.oper_acid=d.target_acid
 and c.entity_cre_flg = 'Y'
 and c.del_flg != 'Y'
 and c.bacid='CNGTE-ISSUE'
 and a.bg_status not in ('Z','R','K')
 and (b.PTRAN_BUS_TYPE = '!' OR b.PTRAN_BUS_TYPE = 'COMM')
 and a.effective_date <= '&1'
 and a.bg_expiry_date >= '&1'
 and a.claim_expiry_date > '&1'
 and b.bank_id='&2'
 and c.acct_cls_date is null
 --Adding new conditions for Duplicate records elimination
-- and a.oper_acid=c.acid
--and a.sol_id=e.TRAN_SOL_ID
--and d.chrg_tran_id=g.tran_id
and e.EVENT_SRL_NUM like b.EVENT_SRL_NUM
and g.acid=c.acid
and b.CHRG_ACID=c.acid
--and   g.TRAN_RMKS like a.bg_srl_num
 --till here Adding new conditions for Duplicate records elimination
and substr(comp_b2kid,1,12) like '%'||a.BG_B2KID||'%'
--and  a.bg_srl_num like '%6156BG00003213%'
--order by a.sol_id
)
order by bgmsolid
;

BEGIN

for fc1 in cursor1
loop

--dbms_output.put_line(fc1.bg_srl_num||'|'||'00');
BEGIN
	select max(due_date) 
	into max_dueDt 	
	from tdcc 	
	where  B2K_ID = fc1.B2K_ID
	and BANK_ID = '&2';
	--and (tdcc.PTRAN_BUS_TYPE = '!' OR tdcc.PTRAN_BUS_TYPE = 'COMM') ;
	EXCEPTION
	when no_data_found then
	max_dueDt := '';
	when others then
	max_dueDt := '';
END;

BEGIN
	select min(due_date) 
	into min_dueDt 
	from tdcc 	
	where  B2K_ID = fc1.B2K_ID
	and BANK_ID = '&2';
	--and (tdcc.PTRAN_BUS_TYPE = '!' OR tdcc.PTRAN_BUS_TYPE = 'COMM');
	EXCEPTION
	when no_data_found then
	min_dueDt := '';
	when others then
	min_dueDt := '';
END;

--dbms_output.put_line(fc1.bg_srl_num||'|'||'11');
BEGIN
	select TRAN_AMT 
	into v_tran_amt 
	from tdcc 
	where  B2K_ID = fc1.B2K_ID
	and BANK_ID = '&2'
	--and (tdcc.PTRAN_BUS_TYPE = '!' OR tdcc.PTRAN_BUS_TYPE = 'COMM')
	and TRAN_ID is not null
	and TRAN_ID = fc1.TRAN_ID;
	EXCEPTION
	when no_data_found then
	v_tran_amt := '';
	when others then
	v_tran_amt := '';
END;
--dbms_output.put_line('v_tran_amt is'||v_tran_amt);
--dbms_output.put_line('fc1.TRAN_ID'||fc1.TRAN_ID||' '||fc1.B2K_ID);

BEGIN
    select  max(TDCC_KEY_SRL_NUM)+1
    into v_srlnum
    from tdcc
    where  B2K_ID = fc1.B2K_ID
    and BANK_ID = '&2'
    --and (tdcc.PTRAN_BUS_TYPE = '!' OR tdcc.PTRAN_BUS_TYPE = 'COMM')
    and TRAN_ID is not null;
    EXCEPTION
    when no_data_found then
    v_srlnum    :='';
    when others then
    v_srlnum    :='';
END;

--dbms_output.put_line(fc1.bg_srl_num||'|'||'22'||'|'||v_tran_amt||'|'||v_srlnum );
BEGIN
	select due_date  
	into next_dueDt 
	from tdcc 
	where  B2K_ID = fc1.B2K_ID
	and BANK_ID = '&2'
	--and (tdcc.PTRAN_BUS_TYPE = '!' OR tdcc.PTRAN_BUS_TYPE = 'COMM')
	and to_number(TDCC_KEY_SRL_NUM) = v_srlnum
	and rownum < 2;
	EXCEPTION
	when no_data_found then
	next_dueDt := '';
	when others then
	next_dueDt := '';
END;

--dbms_output.put_line(fc1.UPFRONT_DEF_FLG||'|'||max_dueDt||'|'||min_dueDt||'|'||v_srlnum||'|'||next_dueDt||'|'||fc1.claim_expiry_date ||'|'|| fc1.effective_date);

--dbms_output.put_line('--bf'||'|'||fc1.TTL_CHRG_TOBE_COLL_AMT||'|'||v_days||'|'||tot_days||'|'||v_tran_amt||'|'||accr_amt);

-- Below Condition changed to check for the value 'I' rather than 'U' --- Ranjith
--if ( fc1.UPFRONT_DEF_FLG = 'U') then
  if ( fc1.UPFRONT_DEF_FLG = 'I') then
	BEGIN
		--dbms_output.put_line('IF');
		select (fc1.claim_expiry_date - fc1.effective_date) + 1, (to_date('&1') - fc1.effective_date) + 1 
		into tot_days,v_days 
		from dual;
		EXCEPTION
		when no_data_found then
		tot_days := '1';
		v_days := '1';
	END;

	accr_amt := (fc1.TTL_CHRG_TOBE_COLL_AMT * v_days)/tot_days;
	v_rbt_amt := fc1.TTL_CHRG_TOBE_COLL_AMT-accr_amt;
-- Below Lines to be removed
--	dbms_output.put_line(fc1.TTL_CHRG_TOBE_COLL_AMT);
	--dbms_output.put_line(v_days);
	--dbms_output.put_line(tot_days);
	--dbms_output.put_line(accr_amt);
	--dbms_output.put_line(v_rbt_amt);
	
else
	BEGIN
   		select  max(TDCC_KEY_SRL_NUM)
		into v_dsrlnum
		from tdcc
		where  B2K_ID = fc1.B2K_ID
		and BANK_ID = '&2'
		--and (tdcc.PTRAN_BUS_TYPE = '!' OR tdcc.PTRAN_BUS_TYPE = 'COMM')
		and TRAN_ID is not null;
		EXCEPTION
		when no_data_found then
		v_dsrlnum    :='';
		when others then
		v_dsrlnum    :='';
	END;

	BEGIN
		select due_date 
		into v_nxtduedate
		from tdcc
		where  B2K_ID = fc1.B2K_ID
		and BANK_ID = '&2'
		--and (tdcc.PTRAN_BUS_TYPE = '!' OR tdcc.PTRAN_BUS_TYPE = 'COMM')
		and to_number(TDCC_KEY_SRL_NUM) = v_dsrlnum
		and TRAN_ID is null;
        EXCEPTION
		when no_data_found then
		v_nxtduedate :='';
		when others then
		v_nxtduedate :='';
	END;

	if v_nxtduedate is not null then
		next_dueDt := v_nxtduedate;
	end if;	


	BEGIN
		--dbms_output.put_line('else'||'|'||next_dueDt||'|'||min_dueDt||'|'||'&1');
		select (next_dueDt - min_dueDt), (to_date('&1') - min_dueDt) +1 
		into tot_days,v_days 
		from dual;
		EXCEPTION
		when no_data_found then
		tot_days := '1';
		v_days := '1';
	END;
	accr_amt := (v_tran_amt * v_days)/tot_days;
	--dbms_output.put_line('printing   '||accr_amt || '  '|| v_days ||' ' || tot_days);
	v_rbt_amt := v_tran_amt-accr_amt;
	--dbms_output.put_line('printing1  '||v_rbt_amt);

	if (v_rbt_amt < 0 ) then
		--dbms_output.put_line('printing5233  ');
		v_rbt_amt := 0;
	end if;

end if;

--dbms_output.put_line('--af'||'|'||fc1.TTL_CHRG_TOBE_COLL_AMT||'|'||v_days||'|'||tot_days||'|'||v_tran_amt||'|'||accr_amt||'|'||fc1.claim_expiry_date ||'|'|| fc1.effective_date);


--dbms_output.put_line('printingr21  '||v_rbt_amt);

dbms_output.put_line(fc1.bg_srl_num||'|'||
					fc1.chrg_ac||'|'||
					fc1.oper_crncy_code||'|'||
					fc1.bgmsolid||'|'||
					fc1.CR_DR_IND||'|'||
					fc1.TRAN_RMKS||'|'||
					v_rbt_amt||'|'||
					fc1.TTL_CHRG_COLL_AMT||'|'||
					fc1.TTL_CHRG_DUE_AMT||'|'||
					fc1.SUPERSEDE_FLG||'|'||
					max_dueDt||'|'||
					min_dueDt||'|'||
					tot_days||'|'||
					v_days);
--dbms_output.put_line(fc1.bg_srl_num||'|'||'99');
v_rbt_amt := '0';
accr_amt := '0';
tot_days := '1';
v_days := '1';
next_dueDt := '';
max_dueDt	 := '';
min_dueDt  := '';
v_tran_amt := '0';
v_srlnum := '0';

end loop;
END;
/
spool off
