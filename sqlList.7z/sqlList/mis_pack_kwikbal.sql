CREATE OR REPLACE PACKAGE ICICI.MIS AS

FUNCTION GetAvgBal(Iacid gam.acid%TYPE,date1 DATE,date2 DATE) RETURN NUMBER;

END;

/

CREATE OR REPLACE PACKAGE BODY ICICI.MIS AS

--==================

FUNCTION GetAvgBal(Iacid gam.acid%TYPE,date1 DATE,date2 DATE) RETURN NUMBER IS

avgbal NUMBER ;

BEGIN

                BEGIN

                SELECT (SUM( value_date_bal *

   (((LEAST(to_date(nvl(end_eod_date,'31-DEC-2099')),date2) - (GREATEST(to_date(eod_date),date1))

)+1)))

 

   / ((date2-date1)+1))

   INTO avgbal

   FROM tbaadm.eab

   WHERE acid = Iacid

   AND ((NVL(end_eod_date,TO_DATE('31-DEC-2099')) >= date1) AND (eod_date <= date2)) ;

   EXCEPTION WHEN NO_DATA_FOUND THEN

   avgbal := 0 ;

                END ;

   RETURN avgbal ;

END;

END;

/
