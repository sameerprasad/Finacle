REM####################################################################
REM File Name   : SPCTC2_REPAY_MOD.sql
REM Description : Suppliers Credit Repayment Info for TC-2
REM Author      : Paresh Maru
REM Date        : 24-04-2011
REM Module	: Trade Credit
REM####################################################################

REM TABLE NAME: SUP_CR_TC2_REPAY_MOD

REM SYNONYM:    SPCTC2_REPAY_MOD

drop table icici.SUP_CR_TC2_REPAY_MOD
/
drop public synonym SPCTC2_REPAY_MOD
/
create table icici.SUP_CR_TC2_REPAY_MOD
(
suppliers_credit_ref_no     VARCHAR2(30 CHAR),
dc_ref_no           VARCHAR2(16 CHAR),
dc_sol_id           VARCHAR2(8 CHAR),
App_Amt             VARCHAR2(30 CHAR),
crncy               VARCHAR2(3 CHAR),
Opening_Bal         VARCHAR2(30 CHAR),
Disb_Amt            VARCHAR2(30 CHAR),
Disb_Date           DATE,
REPAY_Amt           VARCHAR2(30 CHAR),
REPAY_Date          DATE,
Int_Amt             VARCHAR2(30 CHAR),
Int_Date            DATE,
Int_Bill_ref_no     VARCHAR2(16 CHAR),
ENTITY_CRE_FLG      CHAR(1),
DEL_FLG             CHAR(1),
LCHG_USER_ID        VARCHAR2(15 CHAR),
LCHG_TIME           DATE,
RCRE_USER_ID        VARCHAR2(15 CHAR),
RCRE_TIME           DATE,
bill_no				VARCHAR2(15 CHAR),
ship_date           DATE,
fr_date             DATE,
bank_id                 VARCHAR2(8 CHAR)
)
/* STORE_START */
TABLESPACE ICICI_CUST_SMALL
/* STORE_END */
/
create public synonym SPCTC2_REPAY_MOD for icici.SUP_CR_TC2_REPAY_MOD
/
grant select, insert, update, delete on SPCTC2_REPAY_MOD to tbagen
/
grant select on SPCTC2_REPAY_MOD to tbacust
/
grant select on SPCTC2_REPAY_MOD to tbautil
/
grant all on SPCTC2_REPAY_MOD to tbaadm
/
