rem accept solid prompt 'ENTER FOUR DIGIT SOLID OF REPORT BRANCH : '
set echo off 

set termout off
set pause off
set verify off
whenever sqlerror exit sql.sqlcode
set feedback off
set linesize 102
set pagesize 66
set wrap off
set space 1

define all_dashes = '-----------------------------------------------------------------------------'
column today new_value today_date
select to_char(sysdate, 'dd/mm/yyyy') today
from   dual;
column branch new_value br 
select sol_desc branch from sol where sol_id= '&1' and bank_id='&2';
column a heading 'ZONE DATE'
column b heading 'ZONE CODE'
column c heading 'ZONE AMT' format b999,99,99,999.99
break on report
compute sum of c on report
compute sum of b on report
compute sum of a on report

spool &1.clg

ttitle center 'ICICI BANK LIMITED' skip 1 -
center br  skip 2 -
center 'REPORT ON CHEQUES LODGED IN CLEARING BUT NOT RELEASED'  SKIP 1 -
right 'PAGE :   ' format 9999 sql.pno  skip 1 -
right 'DATE :   ' today_date skip 2 -

select sol_id,
       clg_zone_date a,
       clg_zone_code b,
       sum(tot_instrmnt_amt) c
from ozh
where sol_id='&1'
and bank_id='&2'
and clg_zone_date > to_date('29-09-2002','dd-mm-yyyy')
-- and zone_stat='O'
and del_flg = 'N'
and sets_entered >= 1
group by clg_zone_code, clg_zone_date, sol_id
order by a, b 
/
spool off
whenever sqlerror continue
set termout on
undefine all_dashes
set feedback on
set verify on
set heading on
clear breaks 
exit
