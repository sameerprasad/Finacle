REM####################################################################
REM File Name   : ICIACLMT_Common_Alter.sql
REM Description : To Alter tables for Bank_Id
REM Author      : Pragnya Ghosh
REM Date        : 28-05-2012
REM Module      : Anywhere Tran
REM####################################################################


ALTER TABLE ICI_ANYWHERE_AMT ADD BANK_ID VARCHAR2(8 CHAR)
/

ALTER TABLE ICI_ANYWHERE_AMT_MOD ADD BANK_ID VARCHAR2(8 CHAR)
/
