--===================================================================================================================
--  Filename                :   letters_addrchg.sql
--  Description             :
--  Date                    :   05-09-2012
--  Author                  :   Swaroop K Tiruvoipati
--  Menu Option             :
--  Modification History
--    Sl. #           Date           Author                     Modification
--    -----           -----          --------                    ----------------
--    1               05-09-2012     Swaroop K Tiruvoipati      Original Version
--                                                              (Ported from 7.x)
--===================================================================================================================
--   **********************************************************************
--    File     : addrChgLetGen.sql 
--   **********************************************************************
set serveroutput on size 100000
set feedback off
set verify off
set linesize 500
set trims on
DECLARE
--{
OutArr                  basp0099.ArrayType;
solid			CMG.primary_sol_id%type;
startdate		ICICI_PRVADR.verify_date%type;	
enddate			ICICI_PRVADR.verify_date%type;	
loc_cust_id		CMG.CUST_ID%type;
loc_cif_id              CMG.CIF_ID%type;
loc_cust_title_code	CMG.CUST_TITLE_CODE%type;
loc_cust_name		CMG.CUST_NAME%type;
loc_modify_date         ICICI_PRVADR.MODIFY_DATE%type;
loc_verify_date		ICICI_PRVADR.VERIFY_DATE%type;
loc_srl_num		ICICI_PRVADR.SRL_NUM%type;
loc_prv_comu_addr1	ICICI_PRVADR.COMU_ADDR1%type;
loc_prv_comu_addr2	ICICI_PRVADR.COMU_ADDR2%type;
loc_prv_comu_city_code	ICICI_PRVADR.COMU_CITY_CODE%type;
loc_prv_comu_state_code	ICICI_PRVADR.COMU_STATE_CODE%type;
loc_prv_comu_pin_code	ICICI_PRVADR.COMU_PIN_CODE%type;
loc_prv_comu_cntry_code	ICICI_PRVADR.COMU_CNTRY_CODE%type;
loc_prv_comu_phone_num1	ICICI_PRVADR.COMU_PHONE_NUM1%type;
loc_prv_comu_phone_num2	ICICI_PRVADR.COMU_PHONE_NUM2%type;
loc_prv_comu_pager_no	ICICI_PRVADR.COMU_PAGER_NO%type;
loc_prv_comu_email_id	ICICI_PRVADR.COMU_EMAIL_ID%type;
loc_new_comu_addr1	CMG.CUST_COMU_ADDR1%type;
loc_new_comu_addr2	CMG.CUST_COMU_ADDR2%type;
loc_new_comu_city_code	CMG.CUST_COMU_CITY_CODE%type;
loc_new_comu_state_code	CMG.CUST_COMU_STATE_CODE%type;
loc_new_comu_pin_code	CMG.CUST_COMU_PIN_CODE%type;
loc_new_comu_cntry_code	CMG.CUST_COMU_CNTRY_CODE%type;
loc_new_comu_phone_num1	CMG.CUST_COMU_PHONE_NUM_1%type;
loc_new_comu_phone_num2	CMG.CUST_COMU_PHONE_NUM_2%type;
loc_new_comu_email_id	CMG.EMAIL_ID%type;
loc_new_comu_pager_no	CMG.CUST_PAGER_NO%type;


loc_prv_city_desc   	RCT.ref_desc%type; 
loc_new_city_desc   	RCT.ref_desc%type; 
loc_prv_state_desc   	RCT.ref_desc%type; 
loc_new_state_desc   	RCT.ref_desc%type; 
loc_prv_cntry_desc   	RCT.ref_desc%type; 
loc_new_cntry_desc   	RCT.ref_desc%type; 
--loc_dbstatdate          GCT.db_stat_date%type;
loc_dbstatdate          varchar2(20);
loc_bod_date          	varchar2(10);

loc_foracid		GAM.FORACID%type;
loc_schm_type		GAM.SCHM_TYPE%type;
loc_rcre_time		GAM.rcre_time%type;
loc_no_foracid_found 	char(1); 
loc_anydateflag		char(1);

fp                  utl_file.file_type;
------------------
--Define Cursor 1
------------------
CURSOR addrChangedCustDet (in_solid varchar2, in_startdate date, in_enddate date) is 
	SELECT  CMG.CIF_ID cif_id,
		CMG.CUST_TITLE_CODE cust_title_code,
		CMG.CUST_NAME cust_name,
		ICICI_PRVADR.MODIFY_DATE modify_date,
		ICICI_PRVADR.VERIFY_DATE verify_date,
		ICICI_PRVADR.SRL_NUM srl_num,
	ICICI_PRVADR.COMU_ADDR1 prv_comu_addr1,
		ICICI_PRVADR.COMU_ADDR2 prv_comu_addr2,
		ICICI_PRVADR.COMU_CITY_CODE prv_comu_city_code,
		ICICI_PRVADR.COMU_STATE_CODE prv_comu_state_code,
		ICICI_PRVADR.COMU_PIN_CODE prv_comu_pin_code,
		ICICI_PRVADR.COMU_CNTRY_CODE prv_comu_cntry_code,
		ICICI_PRVADR.COMU_PHONE_NUM1 prv_comu_phone_num1,
		ICICI_PRVADR.COMU_PHONE_NUM2 prv_comu_phone_num2,
		ICICI_PRVADR.COMU_PAGER_NO prv_comu_pager_no,
		ICICI_PRVADR.COMU_EMAIL_ID prv_comu_email_id,
--		CMG.CUST_COMU_ADDR1 new_comu_addr1, 
--		CMG.CUST_COMU_ADDR2 new_comu_addr2,
--		CMG.CUST_COMU_CITY_CODE new_comu_city_code, 
--		CMG.CUST_COMU_STATE_CODE new_comu_state_code, 
--		CMG.CUST_COMU_PIN_CODE new_comu_pin_code,
--		CMG.CUST_COMU_CNTRY_CODE new_comu_cntry_code , 
--		CMG.CUST_COMU_PHONE_NUM_1 new_comu_phone_num1, 
--		CMG.CUST_COMU_PHONE_NUM_2 new_comu_phone_num2,
		--CMG.EMAIL_ID new_comu_email_id,
		--CMG.CUST_PAGER_NO new_comu_pager_no,
		--CMG.CUST_STAT_CHG_DATE cust_date
	FROM	ICICI_PRVADR, CMG
		WHERE	ICICI_PRVADR.CIF_ID = CMG.CIF_ID 
		AND	CMG.PRIMARY_SOL_ID in (SELECT SOL_ID FROM SST WHERE SET_ID = in_solid AND BANK_ID = '&1') 
		AND	ICICI_PRVADR.VERIFY_DATE >= in_startdate
		AND	ICICI_PRVADR.VERIFY_DATE <= in_enddate
		AND	ICICI_PRVADR.ENTITY_CRE_FLG = 'Y'
		AND	ICICI_PRVADR.LETTER_GEN_FLG = 'N'
		AND	ICICI_PRVADR.SRL_NUM = 1
                AND     ICICI_PRVADR.BANK_ID = '&1'
                AND     CMG.BANK_ID = '&1';

----------------------------
--Describing  procedure body
----------------------------

BEGIN
--{
	BEGIN
	--{
		SELECT 	to_char(db_stat_date, 'dd-mm-yyyy'), to_char(db_stat_date, 'FMMonth DD, YYYY')
		INTO 	loc_bod_date, loc_dbstatdate
		FROM 	GCT WHERE BANK_ID = '&1';
		EXCEPTION
			WHEN no_data_found THEN
			loc_dbstatdate:='';
	--}
	END;

	solid := 'ALL';

	fp := utl_file.fopen('/tmp', 'letters_addrchg.lst', 'w'); 

	FOR addr_chg_rec in addrChangedCustDet(solid, loc_bod_date, loc_bod_date) 
	LOOP 
	--{

		BEGIN
		--{



		select   address_line1,
       			address_line2,
       			address_line3,
       			city_code,
       			state_code,
       			zip,
       			country_code
       			FROM  CRMUSER.ADDRESS
 			INTO new_comu_addr1,new_comu_addr2,new_comu_addr3,new_comu_city_code,new_comu_state_code,new_comu_pin_code,new_comu_cntry_code
        			where orgkey= addr_chg_rec.cif_id
        			and addresscategory = 'Mailing'
        			AND start_date = (SELECT max(start_date) FROM CRMUSER.ADDRESS
        			WHERE ORGKEY = cifid AND addresscategory = 'Mailing' and bank_id = '$1')
        			and bank_id = '$1');

			select phoneno1,phoneno2,email from CRMUSER.phoneemail
        			INTO  new_comu_phone_num_1,new_comu_phone_num_2,new_comu_email_id
        			WHERE ORGKEY = addr_chg_rec.cif_id and bank_id = '$1';
			
			select custstatuschgdate from CRMUSER.ACCOUNTS INTO
				cust_date WHERE ORGKEY = addr_chg_rec.cif_id and bank_id = '$1';
			
			select pagerno from CRMUSER.DEMOGRAPHIC INTO new_comu_pager_no
				WHERE ORGKEY = addr_chg_rec.cif_id and bank_id = '$1';
			
								
	
			SELECT  ref_desc
			INTO    loc_prv_city_desc
			FROM    RCT
			WHERE   ref_rec_type = '01'
			AND     ref_code = addr_chg_rec.prv_comu_city_code
                        AND     BANK_ID = '&1';
			EXCEPTION
			WHEN no_data_found THEN
				loc_prv_city_desc := '';
		--}
		END;

		BEGIN
		--{
			SELECT  ref_desc
			INTO    loc_new_city_desc
			FROM    RCT
			WHERE   ref_rec_type = '01'
			AND     ref_code = addr_chg_rec.new_comu_city_code
                        AND     BANK_ID = '&1';
			EXCEPTION
			WHEN no_data_found THEN
				loc_new_city_desc := '';
		--}
		END;

		BEGIN
		--{
			SELECT  ref_desc
			INTO    loc_prv_state_desc
			FROM    RCT
			WHERE   ref_rec_type = '02'
			AND     ref_code = addr_chg_rec.prv_comu_state_code
                        AND     BANK_ID = '&1';
			EXCEPTION
			WHEN NO_DATA_FOUND THEN
				loc_prv_state_desc := '';
		--}
		END;


		BEGIN
		--{
			SELECT  ref_desc
			INTO    loc_new_state_desc
			FROM    RCT
			WHERE   ref_rec_type = '02'
			AND     ref_code = addr_chg_rec.new_comu_state_code
                        AND     BANK_ID = '&1';
			EXCEPTION
			WHEN NO_DATA_FOUND THEN
				loc_new_state_desc := '';
		--}
		END;

		BEGIN
		--{
			SELECT  ref_desc
			INTO    loc_prv_cntry_desc
			FROM    RCT
			WHERE   ref_rec_type = '03'
			AND     ref_code = addr_chg_rec.prv_comu_cntry_code
                        AND     BANK_ID = '&1';
			EXCEPTION
			WHEN no_data_found THEN
				loc_prv_cntry_desc := '';
		--}
		END;

		BEGIN
		--{
			SELECT  ref_desc
			INTO    loc_new_cntry_desc
			FROM    RCT
			WHERE   ref_rec_type = '03'
			AND     ref_code = addr_chg_rec.new_comu_cntry_code
                        AND     BANK_ID = '&1';
			EXCEPTION
			WHEN no_data_found THEN
				loc_new_cntry_desc := '';
		--}
		END;

		BEGIN
		--{
			loc_no_foracid_found := 'N';

			SELECT min(FORACID), min(RCRE_TIME)
			INTO	loc_foracid, loc_rcre_time
			FROM	GAM
			WHERE	CIF_ID = addr_chg_rec.cif_id 
			AND	ACCT_CLS_FLG != 'Y'
			AND	DEL_FLG != 'Y'
			AND	ENTITY_CRE_FLG = 'Y'
			AND	ACCT_OWNERSHIP != 'O'
			AND	SCHM_TYPE IN ('SBA', 'CAA', 'ODA')
                        AND     BANK_ID = '&1'
			GROUP BY CIF_ID;
			EXCEPTION
			WHEN no_data_found THEN
				loc_no_foracid_found := 'Y';
		--}
		END;

		IF (loc_no_foracid_found = 'Y') THEN
		--{
			BEGIN
			--{
				SELECT min(FORACID), min(RCRE_TIME)
				INTO	loc_foracid, loc_rcre_time
				FROM	GAM
				WHERE	CIF_ID = addr_chg_rec.cif_id 
				AND	ACCT_CLS_FLG != 'Y'
				AND	DEL_FLG != 'Y'
				AND	ENTITY_CRE_FLG = 'Y'
				AND	ACCT_OWNERSHIP != 'O'
                                AND     BANK_ID = '&1'
				GROUP BY CIF_ID;
				EXCEPTION	
				WHEN no_data_found THEN
				loc_foracid := '';
			--}
			END;
		--}	
		END IF;


		BEGIN
		--{
			SELECT 	schm_type 
			INTO    loc_schm_type
			FROM   	GAM 
			WHERE  	foracid = loc_foracid and BANK_ID = '&1';
			EXCEPTION
			WHEN no_data_found THEN
				loc_schm_type:= '';
		--}
		END;

		utl_file.put_line(fp,addr_chg_rec.cif_id||'|'||	
							addr_chg_rec.cust_title_code||'|'||
							addr_chg_rec.cust_name||'|'||
							loc_foracid||'|'||
							loc_schm_type||'|'||
                        	addr_chg_rec.modify_date||'|'||
                        	addr_chg_rec.verify_date||'|'||
                        	addr_chg_rec.srl_num||'|'||
                        	addr_chg_rec.prv_comu_addr1||'|'||
                        	addr_chg_rec.prv_comu_addr2||'|'||
                        	loc_prv_city_desc||'|'||
                        	loc_prv_state_desc||'|'||
                        	addr_chg_rec.prv_comu_pin_code||'|'||
                        	loc_prv_cntry_desc||'|'||
                        	addr_chg_rec.prv_comu_phone_num1||'|'||
                        	addr_chg_rec.prv_comu_phone_num2||'|'||
                        	addr_chg_rec.prv_comu_pager_no||'|'||
                        	addr_chg_rec.prv_comu_email_id||'|'||
                        	addr_chg_rec.new_comu_addr1||'|'||
                        	addr_chg_rec.new_comu_addr2||'|'||
                        	loc_new_city_desc||'|'||
                        	loc_new_state_desc||'|'||
                        	addr_chg_rec.new_comu_pin_code||'|'||
                        	loc_new_cntry_desc||'|'||
                        	addr_chg_rec.new_comu_phone_num1||'|'||
                        	addr_chg_rec.new_comu_phone_num2||'|'||
                        	addr_chg_rec.new_comu_email_id||'|'||
                        	addr_chg_rec.new_comu_pager_no||'|'||
							loc_dbstatdate||'|'||
							addr_chg_rec.cust_date);

	--}
	END LOOP;
utl_file.fclose(fp);
--}
END;
--}
/
quit
