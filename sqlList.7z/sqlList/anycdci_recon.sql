#--------------------------------------------------------------------------------------------------------------------
#	File	:	anycdci_recon.sql
#	Desc	:	To generate the RECONCILIATION report for ANYWHERE CDCI transactions 
#	Auht	:	Santhosh
#	Date	:	06-07-2007
#--------------------------------------------------------------------------------------------------------------------
set pages 0
set head off
set feedback off
set echo off
set trims on
set verify off
spool &1
select b.foracid||'|'||tran_date||'|'||tran_id||'|'||tran_amt||'|'||part_tran_type||'|'||
	substr(tran_particular,
		(CASE NVL(instr(tran_particular,'/'),0)
			WHEN 4 THEN instr(tran_particular,'/')+1
			WHEN 5 THEN instr(tran_particular,'/')+1
			WHEN 0 THEN (CASE NVL(instr(tran_particular,':'),0) WHEN 0 THEN 17 ELSE instr(tran_particular,':')+2 END)
		ELSE 0 END) ,
		(CASE NVL(instr(tran_particular,'/'),0)
			WHEN 4 THEN instr(tran_particular,'/')+8
			WHEN 5 THEN instr(tran_particular,'/')+7
			WHEN 0 THEN (CASE NVL(instr(tran_particular,':'),0) WHEN 0 THEN 12 ELSE instr(tran_particular,':')+9 END)
		ELSE 0 END))
from dtd a, gam b
where a.acid = b.acid
and b.bacid = 'SL000AWB' 
and a.del_flg = 'N'
and a.pstd_flg = 'Y'
and a.bank_id = '&2'
and b.bank_id = '&2'
order by b.foracid, tran_date, tran_id
/
spool off
exit
