REM 'SCRIPT FOR FINDING ACCOUNT WITH LEDGER NUMBER 211'
REM 'AUTHOR :: Mukesh Kumar Jain""
set pages 60
set lines 80
set echo off
set feedback off
set termout off
set verify off
set numf b99,99,99,99,999.99
col gl format a3
col subgl format a5
col accts format b9999
set newpage 0
define all_dashes = '___________________________________________________________________________'
column today new_value today_date
column bran new_value br
select to_char(sysdate,'dd/mm/yyyy:hh24:mi:ss') today
from dual;
select br_name bran from bct
where sol_id = (select sol_id from sol);

ttitle center  'ICICI BANKING CORPORATION  LTD.' skip 1 -
center ' REPORT of ACCOUNTS AT EXTENSION COUNTER AT ' today_date skip 1 - 
left all_dashes skip 2
break on gl skip 2 on report
compute sum of accts balance on gl report
spool 01ecbal
select substr(gl_sub_head_code,1,2) gl,gl_sub_head_code subgl,
count(*) accts,sum(clr_bal_amt+un_clr_bal_amt) balance
from gam
where sol_id='&1' and ledg_num in ('91','911','912','913','914','915','916','917','918','919')
and acct_cls_flg != 'Y' and bank_id='&2'
group by substr(gl_sub_head_code,1,2),gl_sub_head_code
order by 1,2
/
set feedback on
set verify on
set heading on
clear breaks
clear computes
spool off
set echo on
exit
