rem  SQL to extract data for overdue and unrealised bills.
rem  Input parameters  - Set Id
rem  Tables accessed - BLT, BPM, BRG, SST
rem  Called from - icirsqls.com

---alter session set optimizer_goal = RULE;
set pages 0
set lines 98
set feedback on
set termout on
set verify off
spool  &1.osbills

SELECT  A.sol_id ||'|'||
	A.reg_type ||'|'||
	A.reg_sub_type ||'|'|| 
	bill_id ||'|'||
	(select foracid from gam where acid = oper_acid) ||'|'||
	(select foracid from gam where acid = bp_acid) ||'|'||
	bill_stat ||'|'||
	due_date
FROM  BLT A, BPM B, BRG C  
WHERE sol_id in (select sol_id from sst where set_id = '&1' and bank_id='&3')
and A.reg_type = B.reg_type 
AND A.reg_type = C.reg_type 
AND A.reg_sub_type = B.reg_sub_type 
AND A.del_flg = 'N'  
AND A.reg_type  =  'OCIC'   
AND A.reg_sub_type =  'OCIC'   
and A.bill_stat != 'R'
and due_date < to_date('&2','dd-mm-yyyy')
and A.bank_id='&3' and B.bank_id='&3' and C.bank_id='&3'
ORDER BY  A.sol_id, bill_id

/
spool off
