set serveroutput on size 1000000
set feedback off
set verify   off
set termout   off
set pages 0
set linesize 512
set trims on

alter session set nls_date_format='dd-mm-yyyy';
spool /tmp/&1._mt942
--spool &1._mt942

DECLARE
fora		gam.foracid%type;
--fora1		gam.foracid%type;
tdate		varchar2(12);
trandate	date;
trandate1	date;
trandat2	date;
trandate2	varchar2(12);
trandate3	varchar2(12);
trandate5       varchar2(32);
trandate6       varchar2(22);
trandate4	date;
noDays		NUMBER(10);
opnbal		varchar2(22);
opnbal1		varchar2(22);
clsbal		varchar2(22);
clsbal1		varchar2(22);
--acctname	gam.ACCT_NAME%type;
acctsol		gam.SOL_ID%type;
acctownership	gam.ACCT_OWNERSHIP%type;
custid		gam.CUST_ID%type;
schmcode	gam.SCHM_CODE%type;
acctcrncy	gam.ACCT_CRNCY_CODE%type;
crncycode	gam.CRNCY_CODE%type;
custname	cmg.CUST_NAME%type;
custswiftcode   crmuser.accounts.CUST_SWIFT_CODE_DESC%type;
bankswiftcode   crmuser.accounts.IS_SWIFT_CODE_OF_BANK%type;
swtCode		PPRM.DEFAULT_SENDER_BIC%type;
tranparticular  HTD.TRAN_PARTICULAR%TYPE;
tranremarks     HTD.TRAN_RMKS%TYPE;
refnum          HTD.REF_NUM%TYPE;
tranid          HTD.TRAN_ID%TYPE;
parttransrlnum  HTD.PART_TRAN_SRL_NUM%TYPE;
instnum     	HTD.INSTRMNT_NUM%TYPE;
trantype        HTD.TRAN_TYPE%TYPE;
transubtype     HTD.TRAN_SUB_TYPE%TYPE;
--tranamt       HTD.TRAN_AMT%TYPE;
tranamt         varchar2(22);
valuedate       date;
valuedate1      date;
valuedate2      date;
pstddate        date;
parttrantype    HTD.PART_TRAN_TYPE%TYPE;
rptcode         HTD.RPT_CODE%TYPE;
insttype        HTD.INSTRMNT_TYPE%TYPE;
moduleid        HTD.MODULE_ID%TYPE;
crtot           varchar2(20);
drtot           varchar2(20);
mincr           varchar2(22);
mindr           varchar2(22);
cramt           varchar2(22);
dramt           varchar2(22);
init_sol        varchar2(8);
init_sol_desc   varchar2(50); 
crcount         varchar2(20);
drcount         varchar2(20);
idenfi_code     varchar2(5);
trantime        varchar2(26);
hrs             varchar2(2);
prevhrs         varchar2(2);


CURSOR c1 (fora gam.foracid%type,fromdate varchar2,hrs varchar2,prevhrs varchar2) is
select nvl(replace(TRAN_PARTICULAR,'|','-'),'') ,nvl(substr(TRAN_RMKS,1,32),'') ,nvl(substr(REF_NUM,1,34),'') ,TRAN_ID ,PART_TRAN_SRL_NUM 
,to_char(TRAN_DATE,'dd-mm-yyyy')
,to_char(TRAN_DATE,'ddmmyyyy')
,nvl(trim(INSTRMNT_NUM),'') ,TRAN_TYPE ,TRAN_SUB_TYPE 
,nvl(to_char(VALUE_DATE,'dd-mm-yyyy'),'') 
,nvl(to_char(PSTD_DATE,'dd-mm-yyyy'),'') 
,to_char(TRAN_AMT,'999999999999.99'),PART_TRAN_TYPE ,nvl(RPT_CODE,'') ,nvl(INSTRMNT_TYPE,'') ,nvl(MODULE_ID,''),
to_char(PSTD_DATE,'YYMMDDHH24MISS')
from DTD
where ACID =(select acid from GAM where foracid=fora and del_flg ='N' and acct_cls_flg ='N' and BANK_ID='BM3')  and PSTD_DATE between to_date(fromdate||lpad(hrs,2,'0')||'5959','ddmmyyyyhh24miss')
and to_date(fromdate||lpad(prevhrs,2,'0')||'0000','ddmmyyyyhh24miss') and tran_date=to_char(to_date(fromdate,'DDMMYYYY'),'DD-MM-YYYY') and del_flg ='N' and pstd_flg ='Y' and BANK_ID='BM3'
order by PSTD_DATE;
--and to_date(fromdate||'120000','ddmmyyyyhh24miss') and tran_date=to_date(fromdate,'DDMMYYYY') and del_flg ='N' and pstd_flg ='Y';

BEGIN

fora := '&1';
hrs := lpad('&2',2,'0');
noDays := '&3';


begin
select hrs  into prevhrs from DUAL;
end;

if (hrs = '14') then
begin
select hrs - 3 into hrs from DUAL;
end;
elsif (hrs = '15') then
begin
select hrs - 2 into hrs from DUAL;
end;
elsif (hrs = '06') then
begin
select hrs - 6 into hrs from DUAL;
end;
else
begin
select hrs - 4 into hrs from DUAL;
end;
end if;

begin
select lpad(hrs,2,'0')  into hrs from DUAL;
end;

begin
select lpad(prevhrs,2,'0')  into prevhrs from DUAL;
end;

begin
select to_char(DB_STAT_DATE,'DD-MM-YYYY') into trandate from GCT where BANK_ID='BM3';
--select '26-03-2012' into trandate from DUAL;
end;

begin
select to_char(DB_STAT_DATE,'DDMMYYYY') into tdate from GCT where BANK_ID='BM3';
--select to_char(to_date('26-03-2012','DD-MM-YYYY'),'DDMMYYYY') into tdate from DUAL;
end;

begin
select TO_CHAR(trandate-1,'DD-MM-YYYY') into trandate1 from DUAL;
end;

begin
select TO_CHAR(trandate,'yymmdd') into trandate2 from DUAL;
end;

begin
select TO_CHAR(trandate,'yymmddmmdd') into trandate3 from DUAL;
end;

begin
select to_char(sysdate,'YYMMDDHH24MI')||substr(SESSIONTIMEZONE,1,3)||substr(SESSIONTIMEZONE,5,2) into trandate5 from DUAL;
end;

begin
select to_char(sysdate,'HHMI') into trandate6 from DUAL;
end;

--begin
--select '039305003104' into fora from dual;
--select '123801500877' into fora from dual;
--end;

--Logic of Opening Balance Starts Here

begin
opnbal := 0.00;
select nvl(to_char(tran_date_bal,'999999999999.99'),'0.00') into opnbal from eab where  ACID =(select acid from GAM where foracid=fora and BANK_ID='BM3') and eod_date<=trandate1 and end_eod_date>=trandate1 and BANK_ID='BM3';
exception
 when no_data_found then
 opnbal := 0.00;
end;


begin
dramt := 0.00;
select nvl(to_char(sum(tran_amt),'999999999999.99'),'0.00') into dramt from dtd where acid=(select acid from GAM where foracid=fora and BANK_ID='BM3') and PSTD_DATE between
to_date(tdate||'000000','ddmmyyyyhh24miss') and to_date(tdate||lpad(hrs,2,'0')||'5959','ddmmyyyyhh24miss') and PART_TRAN_TYPE='D'  and DEL_FLG<>'Y' and pstd_flg ='Y' and BANK_ID='BM3';
exception 
 when no_data_found then
  dramt := 0.00;
end;

begin
cramt := 0.00;
select nvl(to_char(sum(tran_amt),'999999999999.99'),'0.00') into cramt from dtd where acid=(select acid from GAM where foracid=fora and BANK_ID='BM3') and PSTD_DATE between
to_date(tdate||'000000','ddmmyyyyhh24miss') and to_date(tdate||lpad(hrs,2,'0')||'5959','ddmmyyyyhh24miss') and PART_TRAN_TYPE='C'  and DEL_FLG<>'Y' and pstd_flg ='Y' and BANK_ID='BM3';
exception
when no_data_found then
  cramt := 0.00;
end;

begin
opnbal1 := 0.00;
select to_char(opnbal - dramt + cramt,'999999999999.99') into opnbal1 from DUAL;
end;


--Logic of Opening Balance Ends Here

--Logic of Closing Balance Starts Here

begin
dramt := 0.00;
select nvl(to_char(sum(tran_amt),'999999999999.99'),'0.00') into dramt from dtd where acid=(select acid from GAM where foracid=fora and BANK_ID='BM3') and PSTD_DATE between
to_date(tdate||lpad(hrs,2,'0')||'5959','ddmmyyyyhh24miss') and to_date(tdate||lpad(prevhrs,2,'0')||'0000','ddmmyyyyhh24miss') and PART_TRAN_TYPE='D' and DEL_FLG<>'Y' and pstd_flg ='Y' and BANK_ID='BM3';
exception
when no_data_found then
dramt := 0.00;
end;

begin
cramt := 0.00;
select nvl(to_char(sum(tran_amt),'999999999999.99'),'0.00') into cramt from dtd where acid=(select acid from GAM where foracid=fora and BANK_ID='BM3') and PSTD_DATE between
to_date(tdate||lpad(hrs,2,'0')||'5959','ddmmyyyyhh24miss') and to_date(tdate||lpad(prevhrs,2,'0')||'0000','ddmmyyyyhh24miss') and PART_TRAN_TYPE='C' and DEL_FLG<>'Y' and pstd_flg ='Y' and BANK_ID='BM3';
exception
when no_data_found then
    cramt := 0.00;
end;

begin
clsbal := 0.00;
select to_char(opnbal1 - dramt + cramt,'999999999999.99') into clsbal from DUAL;
end;



--Logic of Closing Balance Ends here

begin
select nvl(SOL_ID,' ') ,nvl(ACCT_OWNERSHIP,' ') ,nvl(CUST_ID,' ') ,nvl(SCHM_CODE,' ') ,nvl(ACCT_CRNCY_CODE,' ') ,nvl(CRNCY_CODE,' ') into acctsol, acctownership, custid, schmcode,acctcrncy, crncycode 
from GAM where foracid=fora and BANK_ID='BM3';
end;

begin
select CUST_NAME into custname
from CMG where CUST_ID=(select cust_id from gam where foracid=fora and BANK_ID='BM3') and BANK_ID='BM3';
end;

begin
select nvl(CUST_SWIFT_CODE_DESC,'0001'),nvl(IS_SWIFT_CODE_OF_BANK,' ') into custswiftcode, bankswiftcode
from crmuser.accounts where CORE_INTROD_CUST_ID=(select cust_id from gam where foracid=fora and BANK_ID='BM3') and BANK_ID='BM3' and rownum<2;
end;

begin
--SELECT DEFAULT_SENDER_BIC into swtCode FROM PPRM where PAYSYS_ID='SWIFT';
SELECT 'ICICINBB' into swtCode FROM DUAL;
end;


--begin
--SELECT TO_CHAR(TO_DATE(trandate,'DD-MM-YYYY'),'DDD') INTO noDays FROM dual;
--SELECT trim(to_number(to_char(sysdate,'J')) - 2452580) INTO noDays from dual;
--SELECT MT942_NUM_SEQ.nextval INTO noDays from dual;
--end;

begin
select nvl(to_char(min(tran_amt),'999999999999.99'),'0.00') into mincr from dtd where acid=(select acid from GAM where foracid=fora and BANK_ID='BM3') and tran_date=trandate and PART_TRAN_TYPE='C' and DEL_FLG<>'Y' and pstd_flg ='Y' and PSTD_DATE between to_date(tdate||lpad(hrs,2,'0')||'5959','ddmmyyyyhh24miss')  and to_date(tdate||lpad(prevhrs,2,'0')||'0000','ddmmyyyyhh24miss') and BANK_ID='BM3';
exception
 when no_data_found then
 mincr := 0;
end;


begin
select nvl(to_char(min(tran_amt),'999999999999.99'),'0.00') into mindr from dtd where acid=(select acid from GAM where foracid=fora and BANK_ID='BM3') and tran_date=trandate and PART_TRAN_TYPE='D' and DEL_FLG<>'Y' and pstd_flg ='Y' and PSTD_DATE between to_date(tdate||lpad(hrs,2,'0')||'5959','ddmmyyyyhh24miss') and to_date(tdate||lpad(prevhrs,2,'0')||'0000','ddmmyyyyhh24miss') and BANK_ID='BM3';
exception
 when no_data_found then
 mindr := 0;
end;


dbms_output.put_line ('CUMM'||'|'|| fora||'|'||trandate||'|'||trim(replace(opnbal1,'.',','))||'|'||trim(replace(clsbal,'.',','))||'|'||acctsol||'|'|| acctownership||'|'||custid ||'|'|| schmcode ||'|'|| acctcrncy ||'|'|| crncycode||'|'|| custswiftcode||'|'||custname||'|'|| bankswiftcode||'|'|| swtCode||'|'|| noDays||'|'||trandate2||'|'||trim(replace(mincr,'.',','))||'|'||trim(replace(mindr,'.',','))||'|'||trandate5||'|'||trandate6||'||||||');


begin
select nvl(to_char(sum(tran_amt),'999999999999.99'),'0.00') into crtot from dtd where acid=(select acid from GAM where foracid=fora and BANK_ID='BM3') and tran_date=trandate and PART_TRAN_TYPE='C' and DEL_FLG<>'Y' and pstd_flg ='Y' and PSTD_DATE between to_date(tdate||lpad(hrs,2,'0')||'5959','ddmmyyyyhh24miss') and to_date(tdate||lpad(prevhrs,2,'0')||'0000','ddmmyyyyhh24miss') and BANK_ID='BM3';
exception
 when no_data_found then
crtot := 0.00;
end;

begin
select count(*) into crcount from dtd where acid=(select acid from GAM where foracid=fora and BANK_ID='BM3') and tran_date=trandate and PART_TRAN_TYPE='C' and DEL_FLG<>'Y' and pstd_flg ='Y' 
 and PSTD_DATE between to_date(tdate||lpad(hrs,2,'0')||'5959','ddmmyyyyhh24miss') and to_date(tdate||lpad(prevhrs,2,'0')||'0000','ddmmyyyyhh24miss') and BANK_ID='BM3';
exception
 when no_data_found then
crcount := 0;
end;


begin
select nvl(to_char(sum(tran_amt),'999999999999.99'),'0.00') into drtot from dtd where acid=(select acid from GAM where foracid=fora and BANK_ID='BM3') and tran_date=trandate and PART_TRAN_TYPE='D' and DEL_FLG<>'Y' and pstd_flg ='Y' and PSTD_DATE between to_date(tdate||lpad(hrs,2,'0')||'5959','ddmmyyyyhh24miss')  and to_date(tdate||lpad(prevhrs,2,'0')||'0000','ddmmyyyyhh24miss') and BANK_ID='BM3';
exception
 when no_data_found then
 drtot := 0.00;
end;


begin
select count(*) into drcount from dtd where acid=(select acid from GAM where foracid=fora and BANK_ID='BM3') and tran_date=trandate and PART_TRAN_TYPE='D' and DEL_FLG<>'Y' and pstd_flg ='Y' and PSTD_DATE between to_date(tdate||lpad(hrs,2,'0')||'5959','ddmmyyyyhh24miss') and to_date(tdate||lpad(prevhrs,2,'0')||'0000','ddmmyyyyhh24miss') and BANK_ID='BM3';
exception
 when no_data_found then
drcount := 0;
end;


--dbms_output.put_line('FOOTER'||'|'||fora||'|'||trandate||'|'||crtot||'|'||drtot||'|'||mincr||'|'||mindr);

open c1 (fora,tdate,lpad(hrs,2,'0'),lpad(prevhrs,2,'0'));
loop
	fetch c1 into tranparticular,tranremarks,refnum,tranid,parttransrlnum
,trandate4
,trandate1
,instnum,trantype,transubtype
,valuedate
,pstddate
,tranamt,parttrantype,rptcode,insttype,moduleid,trantime;

IF c1%NOTFOUND THEN
    CLOSE c1;
    EXIT;
END IF;
begin
SELECT INIT_SOL_ID into init_sol FROM DTH WHERE TRAN_DATE=trandate AND TRAN_ID=tranid  and BANK_ID='BM3' and rownum<2;
exception
 when no_data_found then
 init_sol := ' ';
end;


begin
SELECT substr(SOL_DESC,1,50) into init_sol_desc FROM SOL WHERE SOL_ID=init_sol and BANK_ID='BM3';
exception
 when no_data_found then
  init_sol_desc := ' ';
end;


-- VD starts here for idenfication code

 if ( (trantype = 'C') and (parttrantype = 'D') and (instnum is not null ) and ( transubtype = 'NP') ) then
--  {
  idenfi_code := 'CHK';
--  }

  elsif ( (trantype = 'C') and (parttrantype = 'C') and (instnum is  null ) and (transubtype = 'NR') ) then
--  {
  idenfi_code := 'COL';
--  }

  elsif ( (trantype = 'L') and (parttrantype = 'D') and (instnum is not null ) and (transubtype= 'I') ) then
--  {
  idenfi_code := 'CHK';
-- }


  elsif ( (trantype = 'L') and (parttrantype = 'C') and (instnum is  null ) and (transubtype='O') ) then
--  {
  idenfi_code := 'CLR';
--  }

  elsif ( (trantype = 'T') and (parttrantype='D') and (instnum is not null ) and (transubtype='CI') ) then
--  {
  idenfi_code := 'CHK';
--  }


  elsif ( (trantype = 'T') and  ( parttrantype = 'C') and (instnum is null ) and ( (transubtype = 'BI')
    or (transubtype = 'CI') or (transubtype='FD') or (transubtype = 'FD')) and (moduleid= 'FEX') ) then
--  {
  idenfi_code := 'FEX';
--  }
  elsif ( (trantype= 'T') and (parttrantype= 'C') and ( instnum is null ) and ((transubtype = 'BI' )
 or (transubtype = 'CI') or (transubtype='FD') or (transubtype='CD') ) and (moduleid= 'BIL') ) then
--  {
  idenfi_code := 'BOE';
--  }

  elsif ( (trantype = 'T') and (parttrantype = 'C') and (instnum is null ) and ( ( transubtype = 'BI')
  or  (transubtype = 'CI') ) and ( (moduleid != 'BIL') or (moduleid != 'FEX') ) ) then
--  {
  idenfi_code := 'COL';
-- }
  elsif ( (trantype = 'T') and (parttrantype = 'D') and (instnum is null) and ( (transubtype = 'IC')
 or (transubtype = 'FD') or (transubtype = 'CD') ) and (moduleid = 'BIL') ) then
--  {
  idenfi_code := 'BOE';
--  }

  elsif ( (trantype = 'T') and (parttrantype = 'D') and (instnum is null ) and ( (transubtype = 'IC')
  or (transubtype = 'FD') or (transubtype = 'CD') ) and (moduleid = 'FEX') ) then
--  {
  idenfi_code := 'FEX';
--  }

  elsif ( (trantype = 'T') and (parttrantype = 'D') and (instnum is null) and (transubtype = 'IC')
 and (moduleid != 'BIL') and (moduleid != 'FEX' ) ) then
--  {
  idenfi_code := 'INT';
--  }

  elsif ( (trantype = 'T') and (parttrantype = 'C') and (instnum is null) and (transubtype = 'IP') ) then
--  {
  idenfi_code := 'INT';
--  }

  elsif ( (trantype = 'T') and (parttrantype = 'D') and (instnum is null) and ( (transubtype = 'SI')
  or (transubtype = 'BS') ) ) then
--  {
  idenfi_code := 'STO';
--  }

  elsif ( (trantype = 'T') and (parttrantype = 'C') and (instnum is null) and ( (transubtype = 'SI')
   or  (transubtype = 'BS') ) ) then
-- {
  idenfi_code := 'STO';
--  }
  else
-- { 
  idenfi_code := 'MSC';
--  }

-- }
end if;

-- VD EnDs here for idenfication code

begin

	dbms_output.put_line('TRAN'||'|'||fora||'|'||trandate||'|'||trim(replace(tranparticular,':',' '))||'|'||tranremarks||'|'||refnum||'|'||tranid||'|'||parttransrlnum||'|'||trandate4||'|'||trandate1||'|'||trandate2||'|'||trandate3||'|'||instnum||'|'||trantype||'|'||transubtype||'|'||valuedate||'|'||valuedate1||'|'||valuedate2||'|'||pstddate||'|'||trim(replace(tranamt,'.',','))||'|'||parttrantype||'|'||rptcode||'|'||insttype||'|'||moduleid||'|'||init_sol_desc||'|'||idenfi_code||'|'||trantime);
end;
end loop;

dbms_output.put_line('FOOTER'||'|'||fora||'|'||trandate||'|'||trim(replace(crtot,'.',','))||'|'||trim(replace(drtot,'.',','))||'|'||trim(replace(mincr,'.',','))||'|'||trim(replace(mindr,'.',','))||'|'||acctownership||'|'||trandate2||'|'||acctcrncy||'|'||trim(replace(clsbal,'.',','))||'|'||crcount||'|'||drcount||'||||||||||||||');



END;
/
spool off
