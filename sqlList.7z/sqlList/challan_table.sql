Rem     This file will create TABLE_FOR_CHALLAN_DETAILS
Rem     with the following characteristics.

Rem TABLE NAME: ICICI.TABLE_FOR_CHALLAN_DETAILS

Rem SYNONYM:  CHALLAN
Rem SYNONYM:  CHALLAN_TBL

drop table TABLE_FOR_CHALLAN_DETAILS
/
drop public synonym CHALLAN
/
drop public synonym CHALLAN_TBL
/
create table TABLE_FOR_CHALLAN_DETAILS
(
  SOL_ID                                             VARCHAR2(8),
  CHALLAN_NO                                         VARCHAR2(7),
  MTH_OF_INT                                         VARCHAR2(12),
  DATE_REMIT                                         DATE,
  PLACE_REMIT                                        VARCHAR2(50),
  BANK_ID                                            VARCHAR2(10)
)
TABLESPACE ICICI_CUST
/

create public synonym CHALLAN
     for TABLE_FOR_CHALLAN_DETAILS
/
create public synonym CHALLAN_TBL
     for TABLE_FOR_CHALLAN_DETAILS
/

create unique index IDX_CHALLAN_TBL
on TABLE_FOR_CHALLAN_DETAILS(SOL_ID,CHALLAN_NO,MTH_OF_INT)
storage ( PCTINCREASE 0 )
TABLESPACE ICICI_CUST
/

grant select, insert, update, delete on TABLE_FOR_CHALLAN_DETAILS to tbagen, tbaadm / grant select on TABLE_FOR_CHALLAN_DETAILS to tbacust / grant select on TABLE_FOR_CHALLAN_DETAILS to tbautil /
