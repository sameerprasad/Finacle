drop sequence tbaadm.PRG_NUM_SEQ_D1;
drop synonym tbaadm.TBA_PRG_NUM_SEQ_D1;
drop synonym tbagen.TBA_PRG_NUM_SEQ_D1;
create sequence tbaadm.PRG_NUM_SEQ_D1
     minvalue 1 maxvalue 9999999 nocycle nocache;
grant select on tbaadm.PRG_NUM_SEQ_D1 to TBAGEN;
create synonym tbaadm.TBA_PRG_NUM_SEQ_D1 for tbaadm.PRG_NUM_SEQ_D1;
create synonym tbagen.TBA_PRG_NUM_SEQ_D1 for tbaadm.PRG_NUM_SEQ_D1;