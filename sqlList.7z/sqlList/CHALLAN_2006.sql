--Rem     This file will create CHALLAN_2006
--Rem     with the following characteristics.

Rem TABLE NAME: TBAUTIL.CHALLAN_2006

drop table CHALLAN_2006
/
create table CHALLAN_2006
(
  SOL_ID                                    NOT NULL VARCHAR2(8),
  CHALLAN_NO                                         NUMBER(5),
  CHALLAN_TYPE                                       VARCHAR2(7),
  MTH_OF_INT                                         VARCHAR2(12),
  DATE_REMIT                                         DATE,
  BSR_CODE_OF_PLACE_REMIT                            VARCHAR2(7),
  BANK_ID                                              VARCHAR2(10)
)

--create index IDX_CHA06
--on CHALLAN_2006(SOL_ID)
--storage ( PCTINCREASE 0 )
/

grant select, insert, update, delete on CHALLAN_2006 to tbagen, tbaadm 
/
grant select on CHALLAN_2006 to tbacust 
/
grant select on CHALLAN_2006 to tbautil 
/


