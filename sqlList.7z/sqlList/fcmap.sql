set echo off
set pause off
set heading off
set feedback off
set termout on
set verify off
set echo off
set lines 98 
set pages  0
clear screen
--------------------------
select '*--<< MATURITYWISE FGN.CRNCY.ASSETS AND LIABILITY FIGURES AS ON A DATE >>--*' from dual;
--------------------------
spool &2.fcmap
--------------------------
select '           [ LIABILITY IN FC AND INR AS ON &1 for &2 - DEPOSITS ]' from dual;
select '-------------------------------------------------------------------------------------' from dual;
select 'SOL | MATURITY  BUCKET    | FC AMT     |CUR|Rupee Amt     |LIAB.TYPE|' from dual;
select '--------------------------------------------------------------------------------------' from dual;
--------------------------
select     substr(g.sol_id,1,4)                                    ||'|'||
           '01. 1 to 14 days     '                                 ||'|'||
           lpad(sum(substr(e.tran_date_bal,1,12)),12,' ')          ||'|'||
           substr(g.acct_crncy_code,1,3)                           ||'|'||
           nvl(lpad(sum(round((e.tran_date_bal*f.var_crncy_units)/
           f.fxd_crncy_units,0)),14,' '),'             0')         ||'|'||
           decode(g.acct_prefix, 53, 'ASSETS   ',
                                 68, 'ASSETS   ',
                                 02, 'RFC  LIAB',
                                 06, 'EEFC LIAB',
                                 12, 'RFC  LIAB',
                                 16, 'EEFC LIAB',
                                 31, 'FCNR LIAB',
                                 'MISC.    ')                      ||'|'
from       tam t, gam g, eab e, rtl f
where      g.sol_id='&2'
and        t.acid = g.acid
and        g.acid = e.acid
and        g.acct_crncy_code=f.fxd_crncy_code
and        f.ratecode='NOR'
and        t.open_effective_date <= to_date('&1','dd-mm-yyyy')
and        (g.acct_cls_flg = 'N' or g.acct_cls_date >= to_date('&1','dd-mm-yyyy'))
and        t.maturity_date > to_date('&1','dd-mm-yyyy')
and        (t.maturity_date - to_date('&1','dd-mm-yyyy')) > 0
and        (t.maturity_date - to_date('&1','dd-mm-yyyy')) <= 14
and        substr(g.foracid,5,2) in ('02','06','12','16','31','68','53')
and        e.eod_date <=to_date('&1','dd-mm-yyyy')
and        e.end_eod_date >=to_date('&1','dd-mm-yyyy')
and        t.bank_id='&3' and g.bank_id='&3' and e.bank_id='&3' and f.bank_id='&3' 
group by   g.sol_id,g.acct_crncy_code,g.acct_prefix
/
select     substr(g.sol_id,1,4)                                    ||'|'||
           '02. 15 to 28 days    '                                 ||'|'||
           lpad(sum(substr(e.tran_date_bal,1,12)),12,' ')          ||'|'||
           substr(g.acct_crncy_code,1,3)                           ||'|'||
           nvl(lpad(sum(round((e.tran_date_bal*f.var_crncy_units)/
           f.fxd_crncy_units,0)),14,' '),'             0')         ||'|'||
           decode(g.acct_prefix, 53, 'ASSETS   ',
                                 68, 'ASSETS   ',
                                 02, 'RFC  LIAB',
                                 06, 'EEFC LIAB',
                                 12, 'RFC  LIAB',
                                 16, 'EEFC LIAB',
                                 31, 'FCNR LIAB',
                                 'MISC.    ')                      ||'|'
from       tam t, gam g, eab e, rtl f
where      g.sol_id='&2'
and        t.acid = g.acid
and        g.acid = e.acid
and        g.acct_crncy_code=f.fxd_crncy_code
and        f.ratecode='NOR'
and        t.open_effective_date <= to_date('&1','dd-mm-yyyy')
and        (g.acct_cls_flg = 'N' or g.acct_cls_date >= to_date('&1','dd-mm-yyyy'))
and        t.maturity_date > to_date('&1','dd-mm-yyyy')
and        (t.maturity_date - to_date('&1','dd-mm-yyyy')) >= 15
and        (t.maturity_date - to_date('&1','dd-mm-yyyy')) <= 28
and        substr(g.foracid,5,2) in ('02','06','12','16','31','68','53')
and        e.eod_date <=to_date('&1','dd-mm-yyyy')
and        e.end_eod_date >=to_date('&1','dd-mm-yyyy')
and        t.bank_id='&3' and g.bank_id='&3' and e.bank_id='&3' and f.bank_id='&3' 
group by   g.sol_id,g.acct_crncy_code,g.acct_prefix
/
select     substr(g.sol_id,1,4)                                    ||'|'||
           '03. 29days to 3 mnths'                                 ||'|'||
           lpad(sum(substr(e.tran_date_bal,1,12)),12,' ')          ||'|'||
           substr(g.acct_crncy_code,1,3)                           ||'|'||
           nvl(lpad(sum(round((e.tran_date_bal*f.var_crncy_units)/
           f.fxd_crncy_units,0)),14,' '),'             0')         ||'|'||
           decode(g.acct_prefix, 53, 'ASSETS   ',
                                 68, 'ASSETS   ',
                                 02, 'RFC  LIAB',
                                 06, 'EEFC LIAB',
                                 12, 'RFC  LIAB',
                                 16, 'EEFC LIAB',
                                 31, 'FCNR LIAB',
                                 'MISC.    ')                      ||'|'
from       tam t, gam g, eab e, rtl f
where      g.sol_id='&2'
and        t.acid = g.acid
and        g.acid = e.acid
and        g.acct_crncy_code=f.fxd_crncy_code
and        f.ratecode='NOR'
and        t.open_effective_date <= to_date('&1','dd-mm-yyyy')
and        (g.acct_cls_flg = 'N' or g.acct_cls_date >= to_date('&1','dd-mm-yyyy'))
and        t.maturity_date > to_date('&1','dd-mm-yyyy')
and        (t.maturity_date - to_date('&1','dd-mm-yyyy')) >= 29
and        (t.maturity_date - to_date('&1','dd-mm-yyyy')) <= 90
and        substr(g.foracid,5,2) in ('02','06','12','16','31','68','53')
and        e.eod_date <=to_date('&1','dd-mm-yyyy')
and        e.end_eod_date >=to_date('&1','dd-mm-yyyy')
and        t.bank_id='&3' and g.bank_id='&3' and e.bank_id='&3' and f.bank_id='&3' 
group by   g.sol_id,g.acct_crncy_code,g.acct_prefix
/
select     substr(g.sol_id,1,4)                                    ||'|'||
           '04. > 3 Mnths <6Mnths'                                 ||'|'||
           lpad(sum(substr(e.tran_date_bal,1,12)),12,' ')          ||'|'||
           substr(g.acct_crncy_code,1,3)                           ||'|'||
           nvl(lpad(sum(round((e.tran_date_bal*f.var_crncy_units)/
           f.fxd_crncy_units,0)),14,' '),'             0')         ||'|'||
           decode(g.acct_prefix, 53, 'ASSETS   ',
                                 68, 'ASSETS   ',
                                 02, 'RFC  LIAB',
                                 06, 'EEFC LIAB',
                                 12, 'RFC  LIAB',
                                 16, 'EEFC LIAB',
                                 31, 'FCNR LIAB',
                                 'MISC.    ')                      ||'|'
from       tam t, gam g, eab e, rtl f
where      g.sol_id='&2'
and        t.acid = g.acid
and        g.acid = e.acid
and        g.acct_crncy_code=f.fxd_crncy_code
and        f.ratecode='NOR'
and        t.open_effective_date <= to_date('&1','dd-mm-yyyy')
and        (g.acct_cls_flg = 'N' or g.acct_cls_date >= to_date('&1','dd-mm-yyyy'))
and        t.maturity_date > to_date('&1','dd-mm-yyyy')
and        (t.maturity_date - to_date('&1','dd-mm-yyyy')) >= 91 
and        (t.maturity_date - to_date('&1','dd-mm-yyyy')) <= 180
and        substr(g.foracid,5,2) in ('02','06','12','16','31','68','53')
and        e.eod_date <=to_date('&1','dd-mm-yyyy')
and        e.end_eod_date >=to_date('&1','dd-mm-yyyy')
and        t.bank_id='&3' and g.bank_id='&3' and e.bank_id='&3' and f.bank_id='&3' 
group by   g.sol_id,g.acct_crncy_code,g.acct_prefix
/
select     substr(g.sol_id,1,4)                                    ||'|'||
           '05. > 6Mnths <=1Year '                                 ||'|'||
           lpad(sum(substr(e.tran_date_bal,1,12)),12,' ')          ||'|'||
           substr(g.acct_crncy_code,1,3)                           ||'|'||
           nvl(lpad(sum(round((e.tran_date_bal*f.var_crncy_units)/
           f.fxd_crncy_units,0)),14,' '),'             0')         ||'|'||
           decode(g.acct_prefix, 53, 'ASSETS   ',
                                 68, 'ASSETS   ',
                                 02, 'RFC  LIAB',
                                 06, 'EEFC LIAB',
                                 12, 'RFC  LIAB',
                                 16, 'EEFC LIAB',
                                 31, 'FCNR LIAB',
                                 'MISC.    ')                      ||'|'
from       tam t, gam g, eab e, rtl f
where      g.sol_id='&2'
and        t.acid = g.acid
and        g.acid = e.acid
and        g.acct_crncy_code=f.fxd_crncy_code
and        f.ratecode='NOR'
and        t.open_effective_date <= to_date('&1','dd-mm-yyyy')
and        (g.acct_cls_flg = 'N' or g.acct_cls_date >= to_date('&1','dd-mm-yyyy'))
and        t.maturity_date > to_date('&1','dd-mm-yyyy')
and        (t.maturity_date - to_date('&1','dd-mm-yyyy')) >= 181 
and        (t.maturity_date - to_date('&1','dd-mm-yyyy')) <= 365
and        substr(g.foracid,5,2) in ('02','06','12','16','31','68','53')
and        e.eod_date <=to_date('&1','dd-mm-yyyy')
and        e.end_eod_date >=to_date('&1','dd-mm-yyyy')
and        t.bank_id='&3' and g.bank_id='&3' and e.bank_id='&3' and f.bank_id='&3' 
group by   g.sol_id,g.acct_crncy_code,g.acct_prefix
/
select     substr(g.sol_id,1,4)                                    ||'|'||
           '06. > 1 year <= 3yrs '                                 ||'|'|| 
           lpad(sum(substr(e.tran_date_bal,1,12)),12,' ')          ||'|'||
           substr(g.acct_crncy_code,1,3)                           ||'|'||
           nvl(lpad(sum(round((e.tran_date_bal*f.var_crncy_units)/
           f.fxd_crncy_units,0)),14,' '),'             0')         ||'|'||
           decode(g.acct_prefix, 53, 'ASSETS   ',
                                 68, 'ASSETS   ',
                                 02, 'RFC  LIAB',
                                 06, 'EEFC LIAB',
                                 12, 'RFC  LIAB',
                                 16, 'EEFC LIAB',
                                 31, 'FCNR LIAB',
                                 'MISC.    ')                      ||'|'
from       tam t, gam g, eab e, rtl f
where      g.sol_id='&2'
and        t.acid = g.acid
and        g.acid = e.acid
and        g.acct_crncy_code=f.fxd_crncy_code
and        f.ratecode='NOR'
and        t.open_effective_date <= to_date('&1','dd-mm-yyyy')
and        (g.acct_cls_flg = 'N' or g.acct_cls_date >= to_date('&1','dd-mm-yyyy'))
and        t.maturity_date > to_date('&1','dd-mm-yyyy')
and        (t.maturity_date - to_date('&1','dd-mm-yyyy')) >= 366
and        (t.maturity_date - to_date('&1','dd-mm-yyyy')) <= 1095
and        substr(g.foracid,5,2) in ('02','06','12','16','31','68','53')
and        e.eod_date <=to_date('&1','dd-mm-yyyy')
and        e.end_eod_date >=to_date('&1','dd-mm-yyyy')
and        t.bank_id='&3' and g.bank_id='&3' and e.bank_id='&3' and f.bank_id='&3' 
group by   g.sol_id,g.acct_crncy_code,g.acct_prefix
/
select     substr(g.sol_id,1,4)                                    ||'|'||
           '07. >3 yrs <= 5 years'                                 ||'|'||
           lpad(sum(substr(e.tran_date_bal,1,12)),12,' ')          ||'|'||
           substr(g.acct_crncy_code,1,3)                           ||'|'||
           nvl(lpad(sum(round((e.tran_date_bal*f.var_crncy_units)/
           f.fxd_crncy_units,0)),14,' '),'             0')         ||'|'||
           decode(g.acct_prefix, 53, 'ASSETS   ',
                                 68, 'ASSETS   ',
                                 02, 'RFC  LIAB',
                                 06, 'EEFC LIAB',
                                 12, 'RFC  LIAB',
                                 16, 'EEFC LIAB',
                                 31, 'FCNR LIAB',
                                 'MISC.    ')                      ||'|'
from       tam t, gam g, eab e, rtl f
where      g.sol_id='&2'
and        t.acid = g.acid
and        g.acid = e.acid
and        g.acct_crncy_code=f.fxd_crncy_code
and        f.ratecode='NOR'
and        t.open_effective_date <= to_date('&1','dd-mm-yyyy')
and        (g.acct_cls_flg = 'N' or g.acct_cls_date >= to_date('&1','dd-mm-yyyy'))
and        t.maturity_date > to_date('&1','dd-mm-yyyy')
and        (t.maturity_date - to_date('&1','dd-mm-yyyy')) >= 1095
and        (t.maturity_date - to_date('&1','dd-mm-yyyy')) <= 1824
and        substr(g.foracid,5,2) in ('02','06','12','16','31','68','53')
and        e.eod_date <=to_date('&1','dd-mm-yyyy')
and        e.end_eod_date >=to_date('&1','dd-mm-yyyy')
and        t.bank_id='&3' and g.bank_id='&3' and e.bank_id='&3' and f.bank_id='&3' 
group by   g.sol_id,g.acct_crncy_code,g.acct_prefix
/
select     substr(g.sol_id,1,4)                                    ||'|'||
           '08. Maturity > 5years'                                 ||'|'||
           lpad(sum(substr(e.tran_date_bal,1,12)),12,' ')          ||'|'||
           substr(g.acct_crncy_code,1,3)                           ||'|'||
           nvl(lpad(sum(round((e.tran_date_bal*f.var_crncy_units)/
           f.fxd_crncy_units,0)),14,' '),'             0')         ||'|'||
           decode(g.acct_prefix, 53, 'ASSETS   ',
                                 68, 'ASSETS   ',
                                 02, 'RFC  LIAB',
                                 06, 'EEFC LIAB',
                                 12, 'RFC  LIAB',
                                 16, 'EEFC LIAB',
                                 31, 'FCNR LIAB',
                                 'MISC.    ')                      ||'|'
from       tam t, gam g, eab e, rtl f
where      g.sol_id='&2'
and        t.acid = g.acid
and        g.acid = e.acid
and        g.acct_crncy_code=f.fxd_crncy_code
and        f.ratecode='NOR'
and        t.open_effective_date <= to_date('&1','dd-mm-yyyy')
and        (g.acct_cls_flg = 'N' or g.acct_cls_date >= to_date('&1','dd-mm-yyyy'))
and        t.maturity_date > to_date('&1','dd-mm-yyyy')
and        (t.maturity_date - to_date('&1','dd-mm-yyyy')) >= 1825
and        substr(g.foracid,5,2) in ('02','06','12','16','31','68','53')
and        e.eod_date <=to_date('&1','dd-mm-yyyy')
and        e.end_eod_date >=to_date('&1','dd-mm-yyyy')
and        t.bank_id='&3' and g.bank_id='&3' and e.bank_id='&3' and f.bank_id='&3' 
group by   g.sol_id,g.acct_crncy_code,g.acct_prefix
/
select '---------------------------------------------------------------------------------------' from dual;
ttitle off
whenever sqlerror continue
spool off
set pause off
set feedback on
set verify on
set heading on
set echo on
clear breaks
exit
