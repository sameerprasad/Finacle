drop table ICICI_BASELII_CUST_MOD
/
drop public synonym ICICI_BASELII_CUST_MOD
/
create table ICICI_BASELII_CUST_MOD(
CUST_ID              VARCHAR2(9),
CTRY_EXPOS           VARCHAR2(5),
PROG_SANC            CHAR(1),
PROG_NAME            VARCHAR2(50),
INDUSTRY_TYPE        VARCHAR2(5),
DIST_CODE            VARCHAR2(15),
BORROWER_CATEGORY    VARCHAR2(5),
POPU_CODE            VARCHAR2(5),
LAST_MODIFIED_DATE   DATE,
LAST_MODIFIED_USER   VARCHAR2(15),
VERIFY_DATE          DATE,
VERIFY_USER          VARCHAR2(15),
ENTITY_CRE_FLG        CHAR(1),
DEL_FLG              CHAR(1),
BANK_ID              VARCHAR2(8 CHAR)
)
/
create public synonym ICICI_BASELII_CUST_MOD for ICICI_BASELII_CUST_MOD
/
grant select, insert, update, delete on ICICI_BASELII_CUST_MOD to tbagen
/
grant select, insert, update, delete on ICICI_BASELII_CUST_MOD to tbautil
/
grant select, insert, update, delete on ICICI_BASELII_CUST_MOD to tbaadm
/
