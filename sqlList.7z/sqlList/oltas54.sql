set serveroutput on size 1000000
set feedback off
set verify off
set linesize 500
set pages 0
set trims on
set termout off
set numformat 999D09
spool &2
select distinct '54^639'||'^0058^'||a.MAJOR_TAX_HEAD||'^'||lpad(count(a.cin_no),6,'0')||'^'||'000000'||'^'||SUM(a.challan_amount)||'^'||''||'^'||to_char(a.PAYOUT_DT,'ddmmyyyy')
from ici_gbm_challan_master a
where a.payout_dt='&1' and a.MAJOR_TAX_HEAD in (select tax_head from ICI_GBM_MAJOR_HEAD where TAX_SCHEME='0005') and a.del_flg='N' and a.entity_creation_flg ='Y' and BSR_CODE != '6390005' group by a.MAJOR_TAX_HEAD,a.payout_dt
/
spool off
