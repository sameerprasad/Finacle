---------------------------------------------------------------------------------
-- Filename         : OUT_NEFT_MSG_TXN_ADT.sql
-- Description      : This sql file creates th trigger OUT_NEFT_MSG_TXN_ADT 
-- Date             : 05-10-2012
-- Author           : Aparna Ashok
-- Menu Option      : HEXECOM
-- Modification History
-- Sl.#       Date           Author         Modification                              
-- -----   ----------   --------------    ----------------                               
--  1.0    05-10-2012   Aparna Ashok    Original Version                          
----------------------------------------------------------------------------------------------

CREATE OR REPLACE TRIGGER "ICNEFT"."OUT_NEFT_MSG_TXN_ADT"
AFTER INSERT OR UPDATE OR DELETE ON INT_OUT_NEFT_MSG_TXN_060312 
FOR EACH ROW
DECLARE
CNTR number;
BEGIN
     BEGIN
           IF INSERTING THEN
          BEGIN
             SELECT COUNT(*) INTO CNTR FROM icneft.INT_OUT_NEFT_MSG_MAS_ADT WHERE IC_ADT_TRANS_SNO = :NEW.IC_TRANS_SNO;
             IF CNTR != 1 THEN
                INSERT INTO icneft.INT_OUT_NEFT_MSG_TXN_ADT VALUES (:NEW.IC_SLNO, :NEW.IC_TRANS_NO, :NEW.IC_FLD_ORD, :NEW.IC_FLD_TAG, :NEW.IC_FLD_FMT_OPT, :NEW.IC_SFLD_ORD,:OLD.IC_SFLD_VAL,:NEW.IC_SFLD_REF_NO,:NEW.IC_FLD_REF_NO,:NEW.IC_FLD_DISP_MA,:NEW.IC_FLD_DISP_CH,:NEW.IC_FLD_REPEAT_NO,:NEW.IC_SFLD_VALID,:NEW.IC_TRANS_SNO, :NEW.IC_SFLD_VAL, :OLD.IC_SFLD_VAL2, :NEW.IC_SFLD_VAL2,:NEW.bank_id); 
END IF;
          END;
          END IF;
          IF UPDATING THEN
             INSERT INTO icneft.INT_OUT_NEFT_MSG_TXN_ADT VALUES (:NEW.IC_SLNO, :NEW.IC_TRANS_NO, :NEW.IC_FLD_ORD, :NEW.IC_FLD_TAG, :NEW.IC_FLD_FMT_OPT, :NEW.IC_SFLD_ORD,:OLD.IC_SFLD_VAL,:NEW.IC_SFLD_REF_NO,:NEW.IC_FLD_REF_NO,:NEW.IC_FLD_DISP_MA,:NEW.IC_FLD_DISP_CH,:NEW.IC_FLD_REPEAT_NO,:NEW.IC_SFLD_VALID,:NEW.IC_TRANS_SNO, :NEW.IC_SFLD_VAL, :OLD.IC_SFLD_VAL2, :NEW.IC_SFLD_VAL2,:NEW.bank_id); 
END IF;
          IF DELETING THEN
          BEGIN
             SELECT COUNT(*) INTO CNTR FROM icneft.INT_OUT_NEFT_MSG_MAS_ADT WHERE IC_ADT_TRANS_SNO = :NEW.IC_TRANS_SNO;IF CNTR != 1 THEN INSERT INTO icneft.INT_OUT_NEFT_MSG_TXN_ADT VALUES (:OLD.IC_SLNO, :OLD.IC_TRANS_NO, :OLD.IC_FLD_ORD, :OLD.IC_FLD_TAG, :OLD.IC_FLD_FMT_OPT, :OLD.IC_SFLD_ORD,:OLD.IC_SFLD_VAL,:OLD.IC_SFLD_REF_NO,:OLD.IC_FLD_REF_NO,:OLD.IC_FLD_DISP_MA,:OLD.IC_FLD_DISP_CH,:OLD.IC_FLD_REPEAT_NO,:OLD.IC_SFLD_VALID,:OLD.IC_TRANS_SNO, :OLD.IC_SFLD_VAL, :OLD.IC_SFLD_VAL2, :OLD.IC_SFLD_VAL2,:OLD.bank_id);
END IF;
          END;
          END IF;
    END;
END;
/
ALTER TRIGGER "ICNEFT"."OUT_NEFT_MSG_TXN_ADT" ENABLE
/
