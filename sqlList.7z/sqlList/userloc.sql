 Name                                                  Null?    Type
 ----------------------------------------------------- -------- ------------------------------------
 USER_ID                                                        VARCHAR2(20)
 LOCATION_CODE                                                  VARCHAR2(10)
 WORK_CLASS                                                     VARCHAR2(3)
 BANK_CODE                                                      VARCHAR2(10)
 BRANCH_CODE                                                    VARCHAR2(10)
 COPY_USR_ID                                                    VARCHAR2(20)
 DEL_FLG                                                        VARCHAR2(3)
 ENTITY_CRE_FLG                                                 VARCHAR2(3)
 LCHG_USER_ID                                                   VARCHAR2(15)
 LCHG_TIME                                                      DATE
 RCRE_USER_ID                                                   VARCHAR2(15)
 RCRE_TIME                                                      DATE
 FREE_TEXT_1                                                    VARCHAR2(60)
 FREE_TEXT_2                                                    VARCHAR2(60)
 FREE_TEXT_3                                                    VARCHAR2(60)

