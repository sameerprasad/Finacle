---------------------------------------------------------------------------------
-- Filename         : OUT_MSG_MAS_ADT.sql
-- Description      : This sql is used to create the trigger OUT_MSG_MAS_ADT 
-- Date             : 10-10-2012
-- Author           : Aparna Ashok
-- Menu Option      : NONE
-- Modification History
-- Sl.#       Date           Author         Modification                              
-- -----   ----------   --------------    ----------------                               
--  1.0    10-10-2012   Aparna Ashok    Original Version                          
----------------------------------------------------------------------------------------------

CREATE OR REPLACE TRIGGER "ICNEFT"."OUT_MSG_MAS_ADT"
AFTER INSERT OR UPDATE OR DELETE OF IC_SENT_ID, IC_RECV_ID, IC_MSG_STRUCTURE ON icneft.INT_OUT_MSG_MAS
FOR EACH ROW
DECLARE
CNTR number;
BEGIN
         BEGIN
                  IF INSERTING THEN
                                BEGIN
                                         SELECT COUNT(*) INTO CNTR FROM icneft.INT_OUT_MSG_MAS_ADT WHERE IC_ADT_TRANS_SNO= :NEW.IC_TRANS_SNO;
                                         IF CNTR > 0 THEN
                                                INSERT INTO icneft.INT_OUT_MSG_MAS_ADT VALUES ( :NEW.IC_TRANS_NO,  :NEW.IC_MSG_TYPE, :NEW.IC_APPL_ID, :NEW.IC_RECV_ID, :NEW.IC_TRANS_SNO, :NEW.IC_INIT_USER, SYSDATE, '', '1', :NEW.bank_id);
                                         ELSE
                                                INSERT INTO icneft.INT_OUT_MSG_MAS_ADT VALUES ( :NEW.IC_TRANS_NO,  :NEW.IC_MSG_TYPE, :NEW.IC_APPL_ID, :NEW.IC_RECV_ID, :NEW.IC_TRANS_SNO, :NEW.IC_INIT_USER, SYSDATE, '', '1', :NEW.bank_id);
                                         END IF;
                                END;
                  END IF;
                  IF UPDATING THEN
                                INSERT INTO icneft. INT_OUT_MSG_MAS_ADT VALUES ( :NEW.IC_TRANS_NO,  :NEW.IC_MSG_TYPE, :NEW.IC_APPL_ID, :NEW.IC_RECV_ID, :NEW.IC_TRANS_SNO, :NEW.IC_INIT_USER, SYSDATE, '', '2', :NEW.bank_id);
                  END IF;
                  IF DELETING THEN
                                INSERT INTO icneft.INT_OUT_MSG_MAS_ADT VALUES ( :OLD.IC_TRANS_NO,  :OLD.IC_MSG_TYPE, :OLD.IC_APPL_ID, :OLD.IC_RECV_ID, :OLD.IC_TRANS_SNO, :OLD.IC_INIT_USER, SYSDATE, '', '3', :OLD.bank_id);
                  END IF;
        END;
END;
/
ALTER TRIGGER "ICNEFT"."OUT_MSG_MAS_ADT" ENABLE
/
