set serveroutput on size 1000000
set feedback off
set verify   off
set termout   off
set pages 0
set linesize 512
set trims on
spool &1-&2-RANGE

DECLARE
custSolId			ICICI_CIFT.HOME_SOL_ID%Type;
beginCustId			ICICI_CIFT.CIF_ID%Type;
endCustId			ICICI_CIFT.Cif_ID%Type;
custCnt				NUMBER(5);
step				NUMBER(5);
idTypeStr			VARCHAR2(200);
--idTypeArr			iciLongArray.arrayType;
idTypeArr                       iciArray.arrayType;
idTypeCnt			NUMBER(5);
endCustFound		NUMBER(5);
curIdTypeCnt		NUMBER(5);
dispMode      		CHAR;
outLine				varchar2(500);
runId				varchar2(10);
custNreFlg			CMG.cust_nre_flg%Type;

custGeo			VARCHAR2(20);

CURSOR ciftCur IS
SELECT HOME_SOL_ID, ICICI_CIFT.CIF_ID,ICICI_CIFT.EMAIL_ID,STMT_REQD,NRE_CNTRY_CODE
FROM ICICI_CIFT,CRMUSER.NCT WHERE
HOME_SOL_ID = custSolId
AND STMT_REQD != 'N'
--AND NCT.CUST_ID = ICICI_CIFT.CUST_ID
AND NCT.CUST_ID in (select cust_id from CMG where CIF_ID in (select CIF_ID from ICICI_CIFT))
AND NRE_CNTRY_CODE in (custGeo)
ORDER BY HOME_SOL_ID, cust_id;

ciftRec ciftCur%ROWTYPE;

BEGIN
	custCnt 	:= 0;
	runId 		:= '&1';
	custSolId 	:= '&2';
	dispMode 	:= '&3';
	custGeo 	:= '&4';
	curIdTypeCnt := 0;
	step := 1;
	idTypeStr := '0|1|2|3|4|5|6|7|8|9|A|B|C|D|E|F|G|H|I|J|K|L|M|N|O|P|Q|R|S|T|U|V|W|X|Y|Z|a|b|c|d|e|f|g|h|i|j|k|l|m|n|o|p|q|r|s|t|u|v|w|x|y|z|-|_|.' ;

	--iciLongArray.construct(idTypeCnt,  idTypeArr);
          iciArray.construct(idTypeStr, '|' , idTypeCnt,  idTypeArr);

	custCnt := 1;
	endCustFound := 0;

	DELETE from ICI_GEO_STAT where HOME_SOL_ID = custSolId and CUST_COMU_CNTRY_CODE = custGeo;
	COMMIT;

	for ciftRec in ciftCur loop
	begin
		step := 2;
		if (custCnt = 1) then
			beginCustId := ciftRec.cif_id;
			endCustFound := 0;
		end if;
		begin
			select cust_nre_flg into custNreFlg from cmg where cif_id = ciftRec.cif_id AND BANK_ID = '&5';
			if(custNreFlg = 'Y') then
		endCustId := ciftRec.cif_id;
		if (custCnt = 4000) then
			endCustFound := 1;
			outLine := 	runId						||
						ciftRec.home_sol_id			|| 
						idTypeArr(curIdTypeCnt)		|| '|' ||
						beginCustId 				|| '|' ||
						endCustId;
			dbms_output.put_line(outLine);
			custCnt := 1;
			curIdTypeCnt := curIdTypeCnt + 1;
			insert into ici_geo_stat values(ciftRec.home_sol_id , ciftRec.cif_id , ciftRec.email_id , ciftRec.stmt_reqd , ciftRec.NRE_CNTRY_CODE,'&5');

		else
			custCnt := custCnt + 1;
			insert into ici_geo_stat values(ciftRec.home_sol_id , ciftRec.cif_id , ciftRec.email_id , ciftRec.stmt_reqd , ciftRec.NRE_CNTRY_CODE,'&5');

		end if;

		end if;

            exception
            when others then null;
       end;

		EXCEPTION
		WHEN OTHERS THEN
			DBMS_OUTPUT.PUT_LINE('<#ORA-ERROR#>');
			DBMS_OUTPUT.PUT_LINE('Cust Id range creation failed at step...'||step);
			DBMS_OUTPUT.PUT_LINE('Cust Id '||beginCustId);
			DBMS_OUTPUT.PUT_LINE('Sql Error Code is        : ' || SQLCODE );
			DBMS_OUTPUT.PUT_LINE('SQL Error Description is : '|| SQLERRM);

	end;
	end loop;

	if (endCustFound = 0) then
		outLine := 	runId						||
					custSolId					||
					idTypeArr(curIdTypeCnt)		|| '|' ||
					beginCustId 				|| '|' ||
					endCustId;
		dbms_output.put_line(outLine);
	end if;
	COMMIT;
END;
/
spool off
