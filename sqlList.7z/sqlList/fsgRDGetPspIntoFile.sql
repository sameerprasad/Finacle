-- No changes reqd for RD stmts
set head off
set pages 0
set trims on
set feedback off
set verify off
set termout off
spool &1-&2-CUST-&3
select  home_sol_id || '|' ||
        entity_id
from    psp_tmp
where   listid like '&1'||'&2'||'&3'||'_C'
and     home_sol_id = '&2'
order by entity_id
/
spool off

spool &1-&2-ACCT-&3
select  b.home_sol_id || '|' ||
        a.cust_id || '|' ||
        b.entity_id
from    gam a, psp_tmp b
where   b.listid like '&1'||'&2'||'&3'||'_A'
and     b.home_sol_id = '&2'
and     b.entity_id = a.foracid
order by entity_id
/
spool off
