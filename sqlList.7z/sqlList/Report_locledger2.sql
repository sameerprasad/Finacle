----------------------------------------------------------------------------------------------------
--   Source Name            : Report_locledger2.sql
--   Description            : Locker Ledger Report.
--   Input Values           : None
--   Output Values          : None
--   Called Script          : N.A
--   Calling Script         : N.A
--   Modification History:
--   Sl No.         Date              Author                     Description
--   --------------------------------------------------------------------------------------
--     01         17-Oct-2012         Priyanka                 Original Version
----------------------------------------------------------------------------------------------------


set serveroutput on size 1000000
set lines 650
set pages 0
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_locledger2.lst

DECLARE
V_TAX_PER         NUMBER(20,4);
V_SER_TAX        NUMBER(10,2);
V_TRAN_DATE        DATE;
V_ID            VARCHAR2(20);
V_PART            VARCHAR2(50);
V_AMT            NUMBER(20,2):=0;
V_RENT            NUMBER(20,2):=0;
V_PREV_BAL        NUMBER(20,2):=0;
V_PREV_STAX_BAL    NUMBER(20,2):=0;
V_PREV_CR        NUMBER(20,2):=0;
V_PREV_DR        NUMBER(20,2):=0;
V_BALANCE        NUMBER(20,2):=0;
V_TYPE            VARCHAR2(2);
V_SOLID            GAM.SOL_ID%TYPE:='&1';
V_LOCKER_NUM        WLCKM.LOCKER_NUM%TYPE:='&2';
DATE1            DATE := TO_DATE('&3', 'DD-MM-YYYY');
DATE2            DATE := TO_DATE('&4', 'DD-MM-YYYY');
DATE3            DATE;
V_BANKID        GAM.BANK_ID%TYPE := '&5';
V_FLG             char(1);
v_cif_id        CLMT.cif_id%type;

CURSOR C1(V_SOLID GAM.SOL_ID%TYPE,V_LOCKER_NUM WLCKM.LOCKER_NUM%TYPE,
DATE1 DATE,
DATE2 DATE,
DATE3 DATE,
v_cif_id CLMT.cif_id%type,V_BANKID GAM.BANK_ID%TYPE) IS
SELECT TRANDATE,ID,PART,AMT,TYPE FROM
(
    SELECT
            APPLICABLE_DATE TRANDATE,
            '' ID,
            PARTICULARS PART,
            AMOUNT AMT,
            PART_TRAN_TYPE TYPE,
            to_char(RCRE_TIME,'dd-mm-yyyy HH24:MI:SS') CRE_TIME
    FROM    CLTLG
    WHERE    LOCKER_NUM = V_LOCKER_NUM
    AND    cif_id    = v_cif_id
    AND     APPLICABLE_DATE BETWEEN DATE1 AND DATE2
    AND     SOL_ID = V_SOLID
    AND     BANK_ID = V_BANKID
    AND     PARTICULARS NOT LIKE '%REVERSAL%'
    AND     DEL_FLG != 'Y'
    UNION ALL
    SELECT
            DISTINCT a.TRAN_DATE TRANDATE,
            a.TRAN_ID ID,
            a.REMARKS PART,
            a.PAID_AMOUNT AMT,
            'C' TYPE,
            to_char(b.RCRE_TIME,'dd-mm-yyyy HH24:MI:SS') CRE_TIME
    FROM
            LCPD a,dctd_acli b
    WHERE        lpad(a.tran_id,9,' ') = b.tran_id
    AND        a.tran_date = b.tran_date
    AND        a.sol_id = b.sol_id
    AND        LOCKER_NUMBER = V_LOCKER_NUM
    AND        a.cif_id    = v_cif_id
    AND            a.TRAN_DATE BETWEEN DATE1 AND DATE2
    AND            a.SOL_ID  = V_SOLID
    AND        a.BANK_ID = V_BANKID
    AND            a.DEL_FLG != 'Y'
    AND        b.del_flg!='Y'
    UNION ALL
    SELECT
            APPLICABLE_DATE TRANDATE,
            SUBSTR(PARTICULARS,INSTR(PARTICULARS,'-')+2) ID,
            SUBSTR(PARTICULARS,1,INSTR(PARTICULARS,'-')-1) PART,
            AMOUNT AMT,
            PART_TRAN_TYPE TYPE,
        to_char(RCRE_TIME,'dd-mm-yyyy HH24:MI:SS') CRE_TIME
    FROM    CLTLG
    WHERE   LOCKER_NUM = V_LOCKER_NUM
    AND     cif_id = v_cif_id
    AND     APPLICABLE_DATE BETWEEN DATE1 AND DATE2
    AND     SOL_ID = V_SOLID
    AND     BANK_ID = V_BANKID
    AND     PARTICULARS LIKE '%REVERSAL%'
    AND     DEL_FLG != 'Y'
    order by 6
);

BEGIN
    BEGIN
        SELECT    PCNT_AMT
        INTO    V_TAX_PER
        FROM ATC
        WHERE amt_tbl_code='SRTAX'
        AND to_number('0') between START_AMT and END_AMT
        AND del_flg!='Y';
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
            V_TAX_PER := 0;
    END;
    BEGIN
        --------------------To fetch the Cust Id for the given locker Num-----------
        SELECT distinct cif_id 
        INTO v_cif_id
        FROM CLMT    
        WHERE sol_id= V_SOLID
        AND BANK_ID = V_BANKID
        AND locker_num = V_LOCKER_NUM
        AND del_flg !='Y';
    EXCEPTION WHEN NO_DATA_FOUND THEN
            v_cif_id := null;
    END;
    

    BEGIN
        SELECT MAX(APPLICABLE_DATE) INTO DATE3 FROM CLTLG WHERE LOCKER_NUM = V_LOCKER_NUM
        AND APPLICABLE_DATE < DATE1 AND PARTICULARS LIKE '%RENT%'
        AND PARTICULARS NOT LIKE '%WAIVE%'
        AND BANK_ID = V_BANKID
        AND cif_id = v_cif_id
        AND del_flg!='Y';
        EXCEPTION WHEN NO_DATA_FOUND THEN
        DATE3 := DATE2;
        END;

    V_PREV_BAL := ICICI.LOCKER_BALANCE(DATE3,DATE1,V_LOCKER_NUM,v_cif_id);
    V_PREV_CR := ICICI.LOCKER_CR_BAL(DATE3,DATE1,V_LOCKER_NUM,v_cif_id);
    V_PREV_DR := ICICI.LOCKER_DR_BAL(DATE3,DATE1,V_LOCKER_NUM,v_cif_id);
    
    DBMS_OUTPUT.PUT_LINE(   ''          ||'|'||
                            ''          ||'|'||
                            ''          ||'|'||
                            V_AMT       ||'|'||
                            ''          ||'|'||
                            V_PREV_BAL  ||'|'||
                            V_PREV_CR   ||'|'||
                            V_PREV_DR   ||'|'||
                            ''
                        );

    FOR I IN C1(V_SOLID,V_LOCKER_NUM,DATE1,DATE2,DATE3,v_cif_id,V_BANKID)
    LOOP
            IF(I.PART LIKE '%RENT%' AND I.TYPE = 'C' AND I.PART NOT LIKE '%WAIVE%') THEN
            --{
                    V_RENT := I.AMT;
                    V_TRAN_DATE := I.TRANDATE;
                    V_SER_TAX := ROUND((V_TAX_PER * I.AMT)/100);
                    V_ID    := I.ID;
                    V_PART  := 'SERVICE TAX';
                    V_AMT   := V_SER_TAX;
                    V_TYPE  := 'D';
                    DBMS_OUTPUT.PUT_LINE(   TO_CHAR(V_TRAN_DATE, 'DD-MM-YYYY')     ||'|'||
                                            V_ID            ||'|'||
                                            V_PART          ||'|'||
                                            V_AMT           ||'|'||
                                            V_TYPE            ||'|'||
                                            V_PREV_BAL        ||'|'||
                                            V_PREV_CR        ||'|'||
                                            V_PREV_DR        ||'|'||
                                            'B'                
                                        );
            --}
            END IF;
            
            IF(I.TYPE = 'C') THEN
            --{
                    V_FLG := 'C';
                    V_BALANCE := V_PREV_BAL + I.AMT;
            --}
            ELSE
            --{
                    V_FLG := 'A';
                    V_BALANCE := V_PREV_BAL - I.AMT;
            --}
            END IF;
            IF(V_RENT != 0) THEN
            --{
                    V_TRAN_DATE := I.TRANDATE;
                    V_ID    := I.ID;
                    V_PART  := I.PART;
                    V_AMT   := I.AMT;
                    V_TYPE  := I.TYPE;
                    DBMS_OUTPUT.PUT_LINE(   V_TRAN_DATE     ||'|'||
                                            V_ID            ||'|'||
                                            V_PART          ||'|'||
                                            V_AMT           ||'|'||
                                            V_TYPE            ||'|'||
                                            V_PREV_BAL        ||'|'||
                                            V_PREV_CR        ||'|'||
                                            V_PREV_DR        ||'|'||
                                            V_FLG    
                                        );
            --}
            --ELSIF(I.TYPE != 'ST') THEN
            ELSE
            --{
                    V_TRAN_DATE := I.TRANDATE;
                    V_ID    := I.ID;
                   V_PART  := I.PART;
                    V_AMT   := I.AMT;
                    V_TYPE  := I.TYPE;
                    DBMS_OUTPUT.PUT_LINE(   V_TRAN_DATE     ||'|'||
                                            V_ID            ||'|'||
                                            V_PART          ||'|'||
                                            V_AMT           ||'|'||
                                            V_TYPE            ||'|'||
                                            V_PREV_BAL        ||'|'||
                                            V_PREV_CR        ||'|'||
                                            V_PREV_DR        ||'|'||
                                            V_FLG
                                        );
            --}
            END IF;
    END LOOP;
END;
/
spool off

