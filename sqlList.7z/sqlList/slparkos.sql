-- Script for generating list of deposit accounts due for TDSCALC run
-- for Interest and Closure trans. (For Finacle Branches)
-- Author : P. Srinivas Rao       Date : 08-Aug-2001
-- Input : sol id 
-- Output : tdsi'solid'.lst

set serveroutput on size 1000000
set verify off
set pages 50
set lines 132
set newpage 0
set feedback off
set numformat "9999999999990D99"
set echo off
set wrap off
set termout off
rem accept solid prompt "Enter Sol_id    "
spool &1.slparkos.lst

DECLARE

cnt		number(10);
solno		sol.sol_id%type;
solname		sol.sol_desc%type; 
accountNo	gam.foracid%type;
intCrAccountNo	gam.foracid%type;
enterer_id	adt.enterer_id%type;
emp_name	get.emp_name%type;
audit_date	adt.audit_date%type;

CURSOR tdsicurint IS SELECT acid, int_to_park_acct,int_credit_acid, park_date from TDSI where int_credit_acid is not null order by park_date,acid;

BEGIN --{

	begin
		select sol_id, sol_desc into solno, solname from sol where sol_id = '&1' and bank_id='&2';
		exception
		when no_data_found then
			dbms_output.put_line('Invalid Sol Id');
			goto endsub;
	end;

	dbms_output.put_line('		ICICI Bank Limited	'||solno||'-'||substr(solname,1,30)); 
	dbms_output.put_line('.');
	dbms_output.put_line('List of Deposit accounts for TDSCALC (for Interest tran)');
	dbms_output.put_line('Account No.       Int Cr Acc No.       Int.to park  Park Date  Enterer ID    Employee Name         Audit Date');
	dbms_output.put_line('-------------------------------------------------------------------------------------------------------------');

	cnt := 0;

	FOR tdsi_rec in tdsicurint
	LOOP --{
	begin
		if tdsicurint%ROWCOUNT = 0 then
			dbms_output.put_line('No records selected');
			EXIT ;
		end if;

		SELECT  foracid    
		INTO 	accountNo 
		FROM 	gam 
       		WHERE   acid = tdsi_rec.acid 
		and     sol_id = '&1'
		and     bank_id = '&2';

		select  foracid 
		into    intCrAccountNo
		from	gam
		where   acid = tdsi_rec.int_credit_acid
		and     sol_id = '&1'
		and     bank_id = '&2';


		begin

		SELECT enterer_id, emp_name, audit_date 
		INTO   enterer_id, emp_name, audit_date 
		FROM   adt,get,upr
		WHERE  adt.acid = tdsi_rec.acid
		and    auth_id ='!'
		and    adt.enterer_id = upr.user_id
		and    upr.user_emp_id = get.emp_id
		and    audit_date = (select max(audit_date) from adt 
				     where adt.acid = tdsi_rec.acid and auth_id ='!')
		and    rownum < 2;

		exception
		when others then
			enterer_id := '';
			emp_name := '';
			audit_date := '';
		end;

		dbms_output.put_line(rpad(accountNo,16)||' '||rpad(intCrAccountNo,16)||' '||to_char(tdsi_rec.int_to_park_acct,'999999999990D99')||' '||tdsi_rec.park_date || '  ' || rpad(enterer_id,15) || ' ' || rpad(substr(emp_name,1,20),20) || to_char(audit_date, 'dd-mm-yyyy'));

		cnt := cnt + 1;

		exception
		when others then
			null;
	end;
	END LOOP;

	if cnt = 0 then
		dbms_output.put_line('No records selected');
	dbms_output.put_line('-------------------------------------------------------------------------------------------------------------');
		dbms_output.put_line('.');
		goto endsub;
	end if;
	dbms_output.put_line('-------------------------------------------------------------------------------------------------------------');
	dbms_output.put_line('.');
	dbms_output.put_line('.');
	<<endsub>>
	null;
END;  
/
set linesize 132
--
-- Repayment Credit Accounts
--
DECLARE

cnt		number(10);
solno		sol.sol_id%type;
solname		sol.sol_desc%type; 
accountNo	gam.foracid%type;
repCrAccountNo	gam.foracid%type;

CURSOR tdsicurint IS SELECT acid, int_to_park_acct,pricipal_to_park_acct,repayment_credit_acid,park_date from TDSI order by park_date,acid;

BEGIN --{

	dbms_output.put_line('.');
	dbms_output.put_line('		List of Deposit accounts for TDSCALC (for Closure tran)');
	dbms_output.put_line('Account No       Repay Cr Acc No       Int to park     Prin to park            Total  Park Date');
	dbms_output.put_line('-----------------------------------------------------------------------------------------------');

	cnt := 0;

	FOR tdsi_rec in tdsicurint
	LOOP --{
	begin
		if tdsicurint%ROWCOUNT = 0 then
			dbms_output.put_line('No records selected');
			EXIT ;
		end if;

		SELECT  foracid    
		INTO 	accountNo 
		FROM 	gam 
        	WHERE   acid = tdsi_rec.acid 
		and     sol_id = '&1'
		and     bank_id = '&2';

		select  foracid 
		into    repCrAccountNo
		from	gam
		where   acid = tdsi_rec.repayment_credit_acid
		and     sol_id = '&1'
		and     bank_id = '&2';
		
		dbms_output.put_line(rpad(accountNo,16)||' '||rpad(repCrAccountNo,16)||' '||to_char(tdsi_rec.int_to_park_acct,'999999999990D99')||' '||to_char(tdsi_rec.pricipal_to_park_acct,'999999999990D99')||' '||to_char(tdsi_rec.int_to_park_acct+tdsi_rec.pricipal_to_park_acct,'999999999990D99')||' '||tdsi_rec.park_date);

		cnt := cnt + 1;
	exception
	when others then
		null;
	end;
	END LOOP;

	if cnt = 0 then
		dbms_output.put_line('No records selected');
		dbms_output.put_line('-----------------------------------------------------------------------------------------------');
		goto endsub;
	end if;

	<<endsub>>
	dbms_output.put_line('-----------------------------------------------------------------------------------------------');
	dbms_output.put_line('The Branch has to run TDS Calc for these accounts without fail.');
	dbms_output.put_line('Whereever Int Cr Acct/Repayment Cr Acct is IBR account,  ');
	dbms_output.put_line('the Branch has to take up with DPC / IT.');
	dbms_output.put_line('This is for Finacle Branches only.');
	dbms_output.put_line('-----------------------------------------------------------------------------------------------');
	null;
END;  
/
spool off
--
-- Reset back number format
--
set numformat "999999999999999"
set feedback on
set verify on
set linesize 80
