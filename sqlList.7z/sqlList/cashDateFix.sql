set head off
set echo off
set trims on
set pagesize 1000
spool salbod
select to_char(to_date(sysdate,'DD-MM-YYYY')-1) FROM dual;
spool off

