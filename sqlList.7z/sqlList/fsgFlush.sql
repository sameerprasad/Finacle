--Aneesh S: 03-01-2013 Bank_id var is changed
--Aneesh S: 09-01-2013 Corrected table name
set serveroutput on size 1000000
set feedback off
set verify   off
set termout   off
set pages 0
set linesize 512
set trims on

spool &1-Flush.log

DECLARE
likeStrAcc          varchar2(25);
likeStrCus          varchar2(25);

BEGIN
	dbms_output.put_line('Flushing the PSP_TMP table for list &1');

	likeStrAcc := '&1'||'A';
	likeStrCus := '&1'||'C';

	DELETE from tbaadm.PSP_TMP WHERE listid = likeStrAcc and bank_id='&4';
	DELETE from tbaadm.PSP_TMP WHERE listid = likeStrCus and bank_id='&4';

COMMIT;
dbms_output.put_line('Flushing the PSP_TMP table for list &1 completed');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('<#ORA-ERROR#>');
        DBMS_OUTPUT.PUT_LINE('Check SQL error,  and try again');
        DBMS_OUTPUT.PUT_LINE('Sql Error Code is        : ' || SQLCODE );
        DBMS_OUTPUT.PUT_LINE('SQL Error Description is : '|| SQLERRM);
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Currenct Chunk rolled back.');
END;
/
spool off
