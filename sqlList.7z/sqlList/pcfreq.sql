-- ###########################################################################################################
-- Package to be created by user ICICI
-- UPDATE HISTORY
-- ----------------------------------------------------------------------------------------------------------
-- Modified by          Date           Purpose of Modification
-- ----------------------------------------------------------------------------------------------------------
-- Arkaja Sachan        03-06-2008     STR: ICI6824 : To capture Mobile number in Chequebook download File
-- Sanjay K Jain        29-07-2008     STR: ICI6669 : For CIB migration 
-- Arkaja Sachan        20-10-2008     STR: ICI7118 : To create an additional field for multiple requests
-- Arkaja Sachan        31-12-2008     STR: ICI7204 : To change number of cheque leaves from 25 to 15 while
--                                     requesting for cheque book for Domestic Savings Accounts
-- Sanjay Kamath        06-12-2012     Branch addresss fetching from BCT
-- Sanjay Kamath        06-12-2012     MICR code and IFSC Code
-- Kumar Gandharv	21-Mar-2013	Added bank_id in queries
-- Kumar Gandharv	10-Apr-2013	Made changes for porting to 10x as per CR id CR-138-28858
-- ###########################################################################################################

set serveroutput on size 1000000
set head off
set pages 0
set linesize 300
set arraysize 1
set trims on
set trimspool on
spool pcfreq
drop public synonym pcfreq
/

create or replace
PACKAGE pcfreq AS
	PROCEDURE getDailyReq(  locRecLine          OUT     VARCHAR2,
				outEndOfFile        IN OUT  NUMBER,
				bankId		    IN	    VARCHAR2
				);
	PROCEDURE getPrevReq(   inReqDate           IN      VARCHAR2,
				locRecLine          OUT     VARCHAR2,
				outEndOfFile        IN OUT  NUMBER,
				bankId		    IN	    VARCHAR2
				);
end pcfreq;
/
CREATE OR REPLACE FUNCTION NUM_CHARS(INSTRING VARCHAR2, INPATTERN VARCHAR2)
RETURN NUMBER
IS
COUNTER NUMBER;
NEXT_INDEX NUMBER;
STRING VARCHAR2(2000);
PATTERN VARCHAR2(2000);
BEGIN
COUNTER := 0;
NEXT_INDEX := 1;
STRING := LOWER(INSTRING);
PATTERN := LOWER(INPATTERN);
FOR I IN 1 .. LENGTH(STRING) LOOP
IF (LENGTH(PATTERN) <= LENGTH(STRING)-NEXT_INDEX+1)
AND (SUBSTR(STRING,NEXT_INDEX,LENGTH(PATTERN)) = PATTERN) THEN
COUNTER := COUNTER+1;
END IF;
NEXT_INDEX := NEXT_INDEX+1;
END LOOP;
RETURN COUNTER;
END;
/

create or replace
PACKAGE BODY pcfreq AS
	glbPrevDate   varchar2(15);
	bankId1	varchar2(8);

	CURSOR 	pcfDailyCur IS
	SELECT	foracid,
		set_id,
		num_of_lvs,
		num_of_chq_bks,
		cb_type,
		rcre_user,
		rcre_time
	FROM	ICICI_CBRQ
	WHERE	status_flg = 'E'
	AND bank_id = bankId1 
	ORDER BY foracid
	FOR	UPDATE;

	CURSOR 	pcfPrevCur IS
	SELECT	foracid,
		set_id,
		num_of_lvs,
		num_of_chq_bks,
		cb_type,
		rcre_user,
		rcre_time
	FROM	ICICI_CBRQ
	WHERE	status_flg = 'S'
	AND bank_id = bankId1 
	AND	to_char(status_date, 'DD-MM-YYYY') = glbPrevDate
	ORDER BY foracid;

	PROCEDURE getDailyReq(	locRecLine	OUT	VARCHAR2,
				outEndOfFile	IN OUT	NUMBER,
				bankId              IN      VARCHAR2
				) IS
		locPatternId		ICICI_CBPT.pattern_id%TYPE;
		locLine1		ICICI_CBPT.line1%TYPE;
		locLine2		ICICI_CBPT.line2%TYPE;
		locLine3		ICICI_CBPT.line3%TYPE;
		locBodDate		tbaadm.GCT.db_stat_date%TYPE;
		locDcAlias		tbaadm.GCT.dc_alias%TYPE;
		locSrlNum		ICICI_LDTT.ser_num%TYPE;
		locForacid		ICICI_CBRQ.foracid%TYPE;
		locSetId		ICICI_CBRQ.set_id%TYPE;
		locCbType		ICICI_CBRQ.cb_type%TYPE;
		locNumOfLvs		ICICI_CBRQ.num_of_lvs%TYPE;
		locNoOfBooks        	ICICI_CBRQ.num_of_chq_bks%TYPE;
		locUser        	    	ICICI_CBRQ.rcre_user%TYPE;
		locDate        	    	ICICI_CBRQ.rcre_time%TYPE;
		locStat			CHAR(1);
		locCardName1        	ICICI_CDTT.card_1_name%TYPE;
		locCardName2        	ICICI_CDTT.card_2_name%TYPE;
		locCardName3        	ICICI_CDTT.card_3_name%TYPE;
		locMothersName      	ICICI_CIFT.mothers_maiden_name%TYPE;
		locEmailId          	ICICI_CIFT.email_id%TYPE;
		locName1Flg         	CHAR(1);
		locName2Flg         	CHAR(1);
		locName3Flg         	CHAR(1);
		locDateOfBirth      	VARCHAR2(15);
		locDateOfBirthFlg   	CHAR(1);
		locNomAvlFlg        	CHAR(1);
		locNomNum           	tbaadm.ANT.nom_reg_num%TYPE;
		locNominee          	tbaadm.ANT.nom_name%TYPE;
		locCabmssign        	VARCHAR2(80);
		locCabmschq         	VARCHAR2(90);
		locGamForacid       	tbaadm.GAM.foracid%TYPE;
		locSchm             	tbaadm.GAM.schm_code%TYPE;
		locModeOfOper       	tbaadm.GAM.mode_of_oper_code%TYPE;
		locGamCustId        	tbaadm.GAM.cif_id%TYPE;
		locOpnDate          	tbaadm.GAM.acct_opn_date%TYPE;			---
		locTitle            	tbaadm.CNMA.cust_title_code%TYPE;
		--locTitle		CRMUSER.ADDRESS.salutation%type;
		--locAddr1            	tbaadm.CNMA.ADDRESS1%TYPE;
		locAddr1            	CNMA.ADDRESS1%TYPE;
		--locAddr1		CRMUSER.ADDRESS.ADDRESS_LINE1%TYPE;			
		--locAddr2            	tbaadm.CNMA.ADDRESS2%TYPE;
		locAddr2            	CNMA.ADDRESS2%TYPE;
		locAddr3		CNMA.ADDRESS3%TYPE;
		--locAddr2            	CRMUSER.ADDRESS.ADDRESS_LINE2%TYPE;
		--locPhone1           	cphone.PHONENO%TYPE;
		locPhone1           	CRMUSER.PHONEEMAIL.PHONENO%TYPE;
		--locPhone2           	cphone.PHONENO%TYPE;
		locPhone2           	CRMUSER.PHONEEMAIL.PHONENO%TYPE;
		locAcid             	tbaadm.GAM.acid%TYPE;
		locAcctCrncyCode    	tbaadm.GAM.acct_crncy_code%TYPE;
		locglsubheadcode    	tbaadm.GAM.gl_sub_head_code%TYPE;
		--locCityCode         	tbaadm.CNMA.CITY_CODE%TYPE;
		locCityCode         	CNMA.CITY_CODE%TYPE;
		--locCityCode         	CRMUSER.ADDRESS.CITY%TYPE;
		--locStateCode        	CRMUSER.ADDRESS.STATE%TYPE;
		--locStateCode        	tbaadm.CNMA.STATE_CODE%TYPE;
		locStateCode        	CNMA.STATE_CODE%TYPE;
		--locCountryCode      	tbaadm.CNMA.CNTRY_CODE%TYPE;
		locCountryCode      	CNMA.CNTRY_CODE%TYPE;
		--locCountryCode      	CRMUSER.ADDRESS.COUNTRY%TYPE;
		--locPin              	tbaadm.CNMA.PIN_CODE%TYPE;
		locPin              	CNMA.PIN_CODE%TYPE;
		--locPin              	CRMUSER.ADDRESS.ZIP%TYPE;
		locStatus           	tbaadm.CMG.cust_stat_code%TYPE;
		locName             	tbaadm.cmg.cust_name%TYPE;
		locNre              	tbaadm.CMG.cust_nre_flg%TYPE;
		locCtype            	tbaadm.CMG.cust_type_code%TYPE;
		locCgroup           	tbaadm.CMG.cust_grp%TYPE;
		locConst            	tbaadm.CMG.cust_const%TYPE;
		locOccp             	tbaadm.CMG.cust_occp_code%TYPE;
		locIntstat          	tbaadm.CMG.cust_introd_stat_code%TYPE;
		locRating           	tbaadm.CMG.cust_rating_code%TYPE;
		locCity             	tbaadm.RCT.ref_desc%TYPE;
		locState            	tbaadm.RCT.ref_desc%TYPE;
		locCountry          	tbaadm.RCT.ref_desc%TYPE;
		locTypes            	varchar2(10);
		locMul              	varchar2(2);
		locNoOfLeaves       	number;
		locNoOfChqs         	number;
		locNomAvailableFlg  	tbaadm.GAM.nom_available_flg%TYPE;
		locDefNoLvs		number;
		locAcctClsFlg  		tbaadm.GAM.acct_cls_flg%TYPE;
		locChqAlwdFlg  		tbaadm.GAM.chq_alwd_flg%TYPE;
		loc_cnt       		number;
		locInfinityFlg      	CHAR(1);
		--locPermAddr1        	tbaadm.CNMA.ADDRESS1%TYPE;
		locPermAddr1        	CNMA.ADDRESS1%TYPE;
		--locPermAddr1        	CRMUSER.ADDRESS.ADDRESS_LINE1%TYPE;
        	--locPermAddr2        	tbaadm.CNMA.ADDRESS2%TYPE;
        	locPermAddr2        	CNMA.ADDRESS2%TYPE;
		locPermAddr3		CNMA.ADDRESS3%TYPE;
        	--locPermAddr2        	CRMUSER.ADDRESS.ADDRESS_LINE2%TYPE;
        	--locPermCityCode     	tbaadm.CNMA.city_code%TYPE;
        	locPermCityCode     	CNMA.city_code%TYPE;
        	--locPermCityCode     	CRMUSER.ADDRESS.city%TYPE;
        	--locPermStateCode    	tbaadm.CNMA.state_code%TYPE;
        	locPermStateCode    	CNMA.state_code%TYPE;
        	--locPermStateCode    	CRMUSER.ADDRESS.state%TYPE;
        	--locPermPinCode      	tbaadm.CNMA.pin_code%TYPE;
        	locPermPinCode      	CNMA.pin_code%TYPE;
        	--locPermPinCode      	CRMUSER.ADDRESS.zip%TYPE;
        	--locPermCntryCode    	tbaadm.CNMA.cntry_code%TYPE;
        	locPermCntryCode    	CNMA.cntry_code%TYPE;
        	--locPermCntryCode    	CRMUSER.ADDRESS.country%TYPE;
        	--locPermPhoneNum     	cphone.phoneno%TYPE;
        	locPermPhoneNum     	CRMUSER.PHONEEMAIL.phoneno%TYPE;
        	--locPermTelexNum     	cphone.phoneno%TYPE;
		locPermTelexNum     	CRMUSER.PHONEEMAIL.phoneno%TYPE;
		locPermCity         	tbaadm.RCT.ref_desc%TYPE;
		locPermState        	tbaadm.RCT.ref_desc%TYPE;
		locPermCountry      	tbaadm.RCT.ref_desc%TYPE;
		--locCustPagerNo		cphone.phoneno%TYPE;
		locCustPagerNo		CRMUSER.PHONEEMAIL.phoneno%TYPE;
		locLedgNum		tbaadm.GAM.ledg_num%TYPE;
		locMobileNum		ICICI_ALERT_REG.MODE_ID%TYPE;
		locRepeatFlg      	CHAR(1);
		locUnusedChq            number;
		locSolId		tbaadm.GAM.sol_id%TYPE;
--		loc_Segment_NUM         ICICI_CUST_SEG.SEGEMENT%TYPE;
		loc_Segment_NUM         VARCHAR2(100);
		locmicrcd               VARCHAR2(9);
                locifccode              VARCHAR2(12);
		lochomesolid            VARCHAR2(8);
		lochomebranchadd1       VARCHAR2(45); 
		lochomebranchadd2       VARCHAR2(45);
		lochomebranchcc		VARCHAR2(5);
		lochomebranchcity	VARCHAR2(50);
		lochomebranchsc		VARCHAR2(5);
		lochomebranchstate	VARCHAR2(50);
		lochomebranchpc		VARCHAR2(15);
		lochomebranchname	VARCHAR2(30);
		corp_id			VARCHAR2(30);
		addrIdc			VARCHAR2(30);
		phoneType1c		VARCHAR2(30);
		phoneType2c		VARCHAR2(30);
		addrIdp			VARCHAR2(30);
		phoneType1p		VARCHAR2(30);
		phoneType2p		VARCHAR2(30);
		loccustid		tbaadm.gam.cust_id%TYPE;


		BEGIN--{
			IF NOT pcfDailyCur%ISOPEN THEN
				bankId1 := bankId;
		   	 	OPEN pcfDailyCur;
	    		END IF;

			locCardName1 := '*';
			locCardName2 := '*';
			locCardName3 := '*';
			locMothersName := '*';
			locEmailId := '*';
			locName1Flg := 'N';
			locName2Flg := 'N';
			locName3Flg := 'N';
			locDateOfBirthFlg := 'N';
			locNomAvlFlg := 'N';
			locNomNum := '*';
			locNominee := '*';
			locCabmssign := '*';
			locCabmschq := '*';

			SELECT	dc_alias, 
				db_stat_date
			INTO	locDcAlias,
				locBodDate
			FROM	tbaadm.GCT
			WHERE   bank_id = bankId;

			FETCH	pcfDailyCur
			INTO	locForacid,
				locSetId,
				locNumOfLvs,
				locNoOfBooks,
				locCbType,
				locUser,
				locDate;

			IF pcfDailyCur%NOTFOUND THEN
				CLOSE pcfDailyCur;

			SELECT	NVL((max(ser_num)+1),1)
			INTO	locSrlNum
			FROM	ICICI_LDTT
			WHERE	dc_alias = locDcAlias
			AND	driver_id = 'PCF' and bank_id = bankId;
			INSERT	INTO	ICICI_LDTT
				VALUES (locDcAlias, 'PCF', '!', locSrlNum, sysdate, '',bankId);
			outEndOfFile := 1;
			RETURN;
			END IF;

			BEGIN --{

				SELECT  acid,
					foracid,
					schm_code,
					mode_of_oper_code,
					cif_id,
					acct_opn_date,
					nom_available_flg,
					acct_cls_flg,
					chq_alwd_flg,
					acct_crncy_code,
					gl_sub_head_code,
					ledg_num,
					sol_id,
					cust_id 
				INTO    locAcid,
					locGamForacid,
					locSchm,
					locModeOfOper,
					locGamCustId,
					locOpnDate,
					locNomAvailableFlg,
					locAcctClsFlg,
					locChqAlwdFlg,
					locAcctCrncyCode,
					locglsubheadcode,
					locLedgNum,
					locSolId,
					loccustid
				FROM    tbaadm.GAM
				WHERE   foracid = locForacid
				AND bank_id = bankId
				AND	entity_cre_flg = 'Y';

				EXCEPTION WHEN NO_DATA_FOUND THEN
						locGamCustId := '#';
			END; --}

			IF (locSchm = 'SBKIT' OR locSchm = 'CAKIT' OR locSchm = 'SKNRE' OR locSchm = 'SBONL' OR locSchm = 'RMCRI') THEN
			--{
				Begin
				--{
				Select cust_opn_date into locOpnDate from tbaadm.cmg where cif_id = locGamCustId AND bank_id = bankId;
				Exception
				when no_data_found  then
					locOpnDate := NULL;
				End;
				--}
			END IF;
			--}

	IF  (locGamCustId != '#') THEN
	--#{
		--#Query to check whether customer is retail or corporate
		BEGIN
		--#{
			SELECT cust_name, NVL(corp_id,'') 
			INTO locName,corp_id
			FROM tbaadm.cmg 
			WHERE cif_id = locGamCustId AND bank_id = bankId;
			EXCEPTION WHEN NO_DATA_FOUND THEN
			locName := '#';
			corp_id := '';
		--#}
		END;
		IF (corp_id != '') THEN
		--{
			addrIdc := 'Mailing';
			phoneType1c := 'COMMPH1';
			phoneType2c := 'COMMPH2';
			addrIdp := 'Registered';
			phoneType1p := 'HOMEPH1';
			phoneType2p := 'HOMEPH2';
		--#}
		ELSE
		--#{
			addrIdc := 'Mailing';
			phoneType1c := 'COMMPH1';
			phoneType2c := 'COMMPH2';
			addrIdp := 'Home';
			phoneType1p := 'HOMEPH1';
			phoneType2p := 'HOMEPH2';
		--#}
		END IF;
		BEGIN
		--#{
			--# Query to fetch customer communication address details
			SELECT	decode(cust_title_code,NULL,' ',cust_title_code),
				decode(address1,NULL,' ',address1),
				decode(address2,NULL,' ',address2), 
				decode(address3,NULL,' ',address3),
				nvl(city_code,'*'),
				nvl(state_code,'*'),
				nvl(cntry_code,'*'),
				decode(pin_code,NULL,' ',pin_code)
			INTO
			locTitle,
			locAddr1,
			locAddr2,
			locAddr3,
			locCityCode,
			locStateCode,
			locCountryCode,
			locPin
			FROM cnma  
			WHERE addr_b2kid = locGamCustId
			AND bank_id	= bankId
			AND addr_id = addrIdc
			AND locBodDate between start_date and end_date; 
			EXCEPTION WHEN NO_DATA_FOUND THEN
			locTitle := '#';
			locName := '#';
			locAddr1 := '#';
			locAddr2 := '#';
			locAddr3 := '#';
			locCityCode := '#';
			locStateCode := '#';
			locCountryCode := '#';
			locPin := '#';
		--#}
		END;
		BEGIN
			--# Query to fetch customer permanent address details
			SELECT	decode(address1,NULL,' ',address1),
				decode(address2,NULL,' ',address2), 
				decode(address3,NULL,' ',address3),
				nvl(city_code,'*'),
				nvl(state_code,'*'),
				nvl(cntry_code,'*'),
				decode(pin_code,NULL,' ',pin_code)
			INTO
			locPermAddr1,
			locPermAddr2,
			locPermAddr3,
			locPermCityCode,
			locPermStateCode,
			locPermCntryCode,
			locPermPinCode
			FROM cnma  
			WHERE addr_b2kid = locGamCustId
			AND bank_id	= bankId
			AND addr_id = addrIdp
			AND locBodDate between start_date and end_date;
			EXCEPTION WHEN NO_DATA_FOUND THEN
			locPermAddr1 := '#';
			locPermAddr2 := '#';
			locPermAddr3 := '#';
			locPermCityCode := '#';
			locPermStateCode := '#';
			locPermCntryCode := '#';
			locPermPinCode := '#';
		END;
		BEGIN
			--#Query to fetch communication telephone details1
			SELECT NVL(phoneno,'*')
			INTO 
			locPhone1
			FROM crmuser.phoneemail   
			WHERE orgkey = locGamCustId 
			AND bank_id = bankId
			AND phoneoremail = 'PHONE' 
			AND phoneemailtype = phoneType1c;
			
			EXCEPTION WHEN NO_DATA_FOUND THEN
			locPhone1 := '#';
		END;
		BEGIN
			--#Query to fetch communication telephone details2
			SELECT NVL(phoneno,'*')
			INTO 
			locPhone2
			FROM crmuser.phoneemail 
			WHERE orgkey = locGamCustId
			AND bank_id = bankId
			AND phoneoremail = 'PHONE' 
			AND phoneemailtype = phoneType2c;
			
			EXCEPTION WHEN NO_DATA_FOUND THEN
			locPhone2 := '#';
		END;
		BEGIN
			--#Query to fetch permanent telephone details
			SELECT NVL(phoneno,'*')
			INTO 
			locPermPhoneNum
			FROM crmuser.phoneemail 
			WHERE orgkey = locGamCustId
			AND bank_id = bankId
			AND phoneoremail = 'PHONE'
			AND phoneemailtype = phoneType1p;
			
			EXCEPTION WHEN NO_DATA_FOUND THEN
			locPermPhoneNum := '#';
		END;
		BEGIN
			--#Query to fetch telex details
			SELECT NVL(phoneno,'*')
			INTO 
			locPermTelexNum
			FROM crmuser.phoneemail 
			WHERE orgkey = locGamCustId
			AND bank_id = bankId
			AND phoneoremail = 'PHONE'
			AND phoneemailtype = 'TELEX';
			--AND UPPER (phoneemailtype) = UPPER ('TELEX');
			
			EXCEPTION WHEN NO_DATA_FOUND THEN
			locPermTelexNum := '#';
		END;
		BEGIN
			--#Query to fetch pager details
			SELECT NVL(phoneno,'*')
			INTO 
			locCustPagerNo
			FROM crmuser.phoneemail 
			WHERE orgkey = locGamCustId
			AND bank_id = bankId
			AND phoneoremail = 'PHONE'
			AND phoneemailtype = 'CELLPH';
			--AND UPPER (phoneemailtype) = UPPER ('PAGER');
			
			EXCEPTION WHEN NO_DATA_FOUND THEN
			locCustPagerNo := '#';
		END;
		BEGIN
			--#Query to fetch other details
			SELECT  cust_stat_code,
				decode(rtrim(cust_stat_code), 'KIDE', 10, 'STUDT' ,10,'CABUS',50, 15),
				decode(cmg.cust_nre_flg,NULL,'N',cmg.cust_nre_flg),
				cust_type_code,
				cust_grp,
				cust_const,
				cust_occp_code,
				cust_introd_stat_code,
				cust_rating_code,
				decode(ltrim(to_char(date_of_birth,'DD-MM-YYYY')),NULL,'00-00-0000',ltrim(to_char(date_of_birth,'DD-MM-YYYY'))),
				decode(ltrim(to_char(date_of_birth,'DD-MM-YYYY')),NULL,'N','Y')
			INTO    locStatus,
				locNoOfChqs,
				locNre,
				locCtype,
				locCgroup,
				locConst,
				locOccp,
				locIntstat,
				locRating,
				locDateOfBirth,
				locDateOfBirthflg
				FROM  tbaadm.cmg
			WHERE   cif_id = locGamCustId AND bank_id = bankId;
			EXCEPTION WHEN NO_DATA_FOUND THEN
			locStatus := '#';
			locNoOfChqs := '#';
			locNre := '#';
			locCtype := '#';
			locCgroup := '#';
			locConst := '#';
			locOccp := '#';
			locIntstat := '#';
			locRating := '#';
			locDateOfBirth := '#';
			locDateOfBirthflg := '#';
		--#}
            END;
--END IF;
/* Added by Manoj Chopra(Infosys) for mandate holders cheque book request */

	if (locCbType = 'X') then
		--#Query to check whether customer is retail or corporate
		BEGIN
		--#{
			SELECT cust_name, NVL(corp_id,'') 
			INTO locName,corp_id
			FROM tbaadm.cmg 
			WHERE cif_id = locGamCustId AND bank_id = bankId;
			EXCEPTION WHEN NO_DATA_FOUND THEN
			locName := '#';
			corp_id := '';
		END;
		IF (corp_id != '') THEN
		--{
			addrIdc := 'Mailing';
			phoneType1c := 'COMMPH1';
			phoneType2c := 'COMMPH2';
			addrIdp := 'Registered';
			phoneType1p := 'HOMEPH1';
			phoneType2p := 'HOMEPH2';
		--#}
		ELSE
		--#{
			addrIdc := 'Mailing';
			phoneType1c := 'COMMPH1';
			phoneType2c := 'COMMPH2';
			addrIdp := 'Home';
			phoneType1p := 'HOMEPH1';
			phoneType2p := 'HOMEPH2';
		--#}
		END IF;
			BEGIN
			--#{
				--# Query to fetch customer communication address details
				SELECT	decode(cust_title_code,NULL,' ',cust_title_code),
					decode(address1,NULL,' ',address1),
					decode(address2,NULL,' ',address2),
					decode(address3,NULL,' ',address3),
					nvl(city_code,'*'),
					nvl(state_code,'*'),
					nvl(cntry_code,'*'),
					decode(pin_code,NULL,' ',pin_code)
				INTO
				locTitle,
				locAddr1,
				locAddr2,
				locAddr3,
				locCityCode,
				locStateCode,
				locCountryCode,
				locPin
				FROM cnma  
				WHERE  bank_id	= bankId
				AND addr_id = addrIdc
				AND addr_b2kid = (SELECT cif_id_mandate_holder from ICICI_MANDATE_HOLDER WHERE foracid_nri=locForacid and del_flg != 'Y' AND bank_id = bankId)
				AND locBodDate between start_date and end_date;
				EXCEPTION WHEN NO_DATA_FOUND THEN
				locTitle := '#';
				locName := '#';
				locAddr1 := '#';
				locAddr2 := '#';
				locAddr3 := '#';
				locCityCode := '#';
				locStateCode := '#';
				locCountryCode := '#';
				locPin := '#';
			--#}
			END;
			BEGIN
			--#{
				--#Query to fetch communication telephone details1
				SELECT NVL(phoneno,'*')
				INTO 
				locPhone1
				FROM crmuser.phoneemail
				WHERE orgkey = (SELECT cif_id_mandate_holder from ICICI_MANDATE_HOLDER WHERE foracid_nri=locForacid and del_flg != 'Y' AND bank_id = bankId) 
				AND bank_id = bankId 
				AND phoneoremail = 'PHONE' 
				AND phoneemailtype = phoneType1c;
				
				
				EXCEPTION WHEN NO_DATA_FOUND THEN
				locPhone1 := '#';
				
			END; --}
			BEGIN
			--#{
				--#Query to fetch communication telephone details2
				SELECT NVL(phoneno,'*')
				INTO
				locPhone2
				FROM crmuser.phoneemail 
				WHERE orgkey = (SELECT cif_id_mandate_holder from ICICI_MANDATE_HOLDER WHERE foracid_nri=locForacid and del_flg != 'Y' AND bank_id = bankId) 
				AND bank_id = bankId 
				AND phoneoremail = 'PHONE'
				AND phoneemailtype = phoneType2c;
				
				EXCEPTION WHEN NO_DATA_FOUND THEN
				locPhone2 := '#';
			END; --}

	END IF;

			BEGIN--{
				SELECT  nvl(ltrim(card_1_name),'*'),
						decode(ltrim(card_1_name),NULL, 'N','Y'),
						nvl(ltrim(card_2_name),'*'),
						decode(ltrim(card_2_name),NULL,'N','Y'),
						nvl(ltrim(card_3_name),'*'),
						decode(ltrim(card_3_name),NULL,'N','Y')
				INTO    locCardName1,
						locName1Flg,
						locCardName2,
						locName2Flg,
						locCardName3,
						locName3Flg
				FROM    ICICI_CDTT
				--WHERE   cif_id = locGamCustId;
				WHERE   cif_id = loccustid;
				EXCEPTION WHEN NO_DATA_FOUND THEN
					locCardName1 := '*';
					locName1Flg := 'N';
					locCardName2 := '*';
					locName2Flg := 'N';
					locCardName3 := '*';
					locName3Flg := 'N';
			END;--}

			BEGIN --{
				SELECT	mothers_maiden_name,
					email_id
				INTO	locMothersName,
					locEmailId
				FROM	ICICI_CIFT
				WHERE	cif_id = locGamCustId AND bank_id = bankId;
				EXCEPTION WHEN NO_DATA_FOUND THEN
					locMothersName := '*';
                    			locEmailId := '*';
			END; --}
--***********************************************ADDED BY PRIYANKA************************************************************
                        BEGIN --{
                                        Select BANK_IDENTIFIER
                                        into locifccode
                                        from tbaadm.BRBIC
                                        where bank_code ='ICI'
										AND bank_id = bankId
                                        and branch_code = (select br_code from tbaadm.sol where sol_id = locSolId AND bank_id = bankId)
                                        and paysys_id ='GROSS' ;
                                        EXCEPTION WHEN NO_DATA_FOUND THEN
                                                locifccode := '*';
                        END; --}

                        BEGIN --{
                                        SELECT MICR_CENTRE_CODE||MICR_BANK_CODE||MICR_BRANCH_CODE,UPPER(br_addr_1),UPPER(br_addr_2),br_city_code,br_state_code,br_pin_code,UPPER(br_name)
                                        INTO locmicrcd,lochomebranchadd1,lochomebranchadd2,lochomebranchcc,lochomebranchsc,lochomebranchpc,lochomebranchname
                                        FROM tbaadm.BCT
                                        where bank_code = 'ICI'
										AND bank_id = bankId
                                          and br_code= (select br_code from tbaadm.sol where sol_id = locSolId AND bank_id = bankId);
                                        EXCEPTION
                                        WHEN NO_DATA_FOUND THEN
                                                locmicrcd := '*';
                                                lochomebranchadd1 := '*';
                                                lochomebranchadd2 := '*';
						lochomebranchcc := '*';
						lochomebranchsc := '*';
						lochomebranchpc := '*';
						lochomebranchname := '*';
                        END; --}

			BEGIN  --{
				SELECT UPPER(REF_DESC)
				  INTO lochomebranchcity
				  FROM tbaadm.RCT
				 WHERE REF_REC_TYPE = '01'
				 AND bank_id = bankId
			           AND REF_CODE = lochomebranchcc;
			EXCEPTION
				WHEN NO_DATA_FOUND THEN
					lochomebranchcity := '*';
			END ;  --}

			BEGIN  --{
				SELECT UPPER(REF_DESC)
				  INTO lochomebranchstate
				  FROM tbaadm.RCT
				 WHERE REF_REC_TYPE = '02'
				 AND bank_id = bankId
			           AND REF_CODE = lochomebranchsc;
			EXCEPTION
				WHEN NO_DATA_FOUND THEN
					lochomebranchstate := '*';
			END ;  --}

			BEGIN --{
				if (locNomAvailableFlg = 'Y') then
					SELECT  'Y',
						nom_reg_num,
						rtrim(nom_name)
				    	INTO    locNomAvlFlg,
   						locNomNum,
  						locNominee
					FROM    tbaadm.ANT 
					WHERE   acid = locAcid AND bank_id = bankId AND rownum = 1;
				else
					locNomAvlFlg := 'N';
					locNomNum := '*';
					locNominee := '*';
				end if;
				EXCEPTION WHEN NO_DATA_FOUND THEN
					locNomNum := '*';
					locNominee := '*';
			END; --}
 
			begin
				SELECT  decode(ref_desc,NULL,' ',ref_desc)
				INTO    locCity
				FROM    tbaadm.RCT
				WHERE   ref_rec_type = '01'
				AND     ref_code = locCityCode AND bank_id = bankId;
			exception
				when no_data_found then
					locCity := '*';
			end;

			begin
				SELECT 	decode(ref_desc,NULL,' ',ref_desc)
				INTO 	locState
				FROM 	tbaadm.RCT
				WHERE 	ref_rec_type = '02'
				AND 	ref_code = locStateCode AND bank_id = bankId;
            		exception
            			when no_data_found then
					locState := '*';
			end;

            		begin
				SELECT  decode(ref_desc,NULL,' ',ref_desc)
				INTO    locCountry
				FROM    tbaadm.RCT
				WHERE   ref_rec_type = '03'
				AND     ref_code = locCountryCode AND bank_id = bankId;
			exception
				when no_data_found then
					locCountry := '*';
			end;

			begin
				SELECT  decode(ref_desc,NULL,' ',ref_desc)
				INTO    locPermCity
				FROM    tbaadm.RCT
				WHERE   ref_rec_type = '01'
				AND     ref_code = locPermCityCode AND bank_id = bankId;
			exception
				when no_data_found then
					locPermCity := '*';
			end;

			begin
				SELECT 	decode(ref_desc,NULL,' ',ref_desc)
				INTO 	locPermState
				FROM 	tbaadm.RCT
				WHERE 	ref_rec_type = '02'
				AND 	ref_code = locPermStateCode AND bank_id = bankId;
			exception
				when no_data_found then
					locPermState := '*';
			end;

			begin
				SELECT  decode(ref_desc,NULL,' ',ref_desc)
				INTO    locPermCountry
				FROM    tbaadm.RCT
				WHERE   ref_rec_type = '03'
				AND     ref_code = locPermCntryCode AND bank_id = bankId;
			exception
				when no_data_found then
					locPermCountry := '*';
			end;
 
			BEGIN--{
				SELECT  substr(locGamForacid,5,2)
				INTO    locMul
				FROM    dual;
				EXCEPTION WHEN NO_DATA_FOUND THEN
				locMul := 'ERROR';
			END;--}

			BEGIN--{
				IF substr(locGamForacid,5,2) = '01' THEN
					locCabmschq:=locName;
				ELSE
					SELECT 'for '||locName
					INTO locCabmschq
					FROM dual;
				END IF;


				SELECT  decode(rtrim(locConst),'1', 'INDIVIDUAL', locCabmssign)
				INTO    locCabmssign
				FROM    dual;

				SELECT  decode(rtrim(locConst),'10','PROPRIETOR',locCabmssign)
				INTO    locCabmssign
				FROM    dual;
				SELECT  decode(rtrim(locConst),'2','PARTNER(S)',locCabmssign)
				INTO    locCabmssign
				FROM    dual;
				SELECT  decode(rtrim(locConst),'3','AUTHORIZED SIGNATORY(IES)',locCabmssign)
				INTO    locCabmssign
				FROM    dual;
				SELECT  decode(rtrim(locConst),'4','AUTHORIZED SIGNATORY(IES)',locCabmssign)
				INTO    locCabmssign
				FROM    dual;
				SELECT  decode(rtrim(locConst),'5','TRUSTEE(S)',locCabmssign)
				INTO    locCabmssign
				FROM    dual;
				SELECT  decode(rtrim(locConst),'6','AUTHORIZED SIGNATORY(IES)',locCabmssign)
				INTO    locCabmssign
				FROM    dual;
				SELECT  decode(rtrim(locConst),'7','AUTHORIZED SIGNATORY(IES)',locCabmssign)
				INTO    locCabmssign
				FROM    dual;
			END;--}

			BEGIN--{
				SELECT	pattern_id,
						line1,
						line2,
						line3
				INTO	locPatternId,
						locLine1,
						locLine2,
						locLine3
				FROM	ICICI_CBPT
				WHERE	foracid = locForacid
				AND	set_id = locSetId AND bank_id = bankId;
				EXCEPTION WHEN NO_DATA_FOUND THEN
					locPatternId := '#';
					locLine1 := '#';
					locLine2 := '#';
					locLine3 := '#';

			END;--}


-- ......................... Added by Arkaja on 03.06.2008 for STR:ICI6824 .........................

			BEGIN --{
				SELECT  MODE_ID
				INTO    locMobileNum
				FROM    ICICI_ALERT_REG
				WHERE   FORACID = locForacid
				AND 	MODE_OF_DELIVERY = '0'
				AND bank_id = bankId
				AND	RCRE_TIME = (	SELECT	MAX(RCRE_TIME)
							FROM	ICICI_ALERT_REG
							WHERE	FORACID = locForacid
							AND	MODE_OF_DELIVERY = '0'
							AND	DEL_FLG = 'N' AND bank_id = bankId)
				AND	DEL_FLG = 'N'
				AND	ROWNUM < 2;
				EXCEPTION WHEN NO_DATA_FOUND THEN
					locMobileNum := '#';
			END; --}


 -- ............................. Added by Amitabh For segment field .............................
              BEGIN --{
                       -- SELECT SEGEMENT
			  SELECT SEGMENTATION_CLASS||'|'||SUBSEGMENT
                                     into   loc_Segment_NUM
                                 --  from   ICICI_CUST_SEG
				     from   CMG
                                      where   cif_id = locGamCustId AND bank_id = bankId;
                      EXCEPTION WHEN NO_DATA_FOUND THEN
                                       loc_Segment_NUM := '';
               END; --}
--..........................................................................................

-- ......................... Added by Arkaja on 20.10.2008 for STR:ICI7118 .........................

			BEGIN --{
				SELECT  decode(count(FORACID),0,'N','Y')
				INTO    locRepeatFlg
				FROM    ICICI_CBRQ
				WHERE   FORACID = locForacid
				AND 	STATUS_FLG = 'S'
				AND bank_id = bankId
				AND	locBodDate - RCRE_TIME <= 7;  -- changed to 7 as per the CR-138-28858 Sanjay Kamath

				EXCEPTION WHEN NO_DATA_FOUND THEN
					locRepeatFlg := 'N';
			END; --}

-- .................................................................................................
---------------------- Added by Vijay to show unused leaves in pcfreq------------------------

                       BEGIN --{
                	SELECT sum(NUM_CHARS(CHQ_LVS_STAT,'P')) into locUnusedChq
                        from tbaadm.cbt,tbaadm.gct
                        where acid = (select acid from tbaadm.gam where foracid = locForacid)
                        and chq_issu_date > add_months(db_stat_date,-6) 
			AND gct.bank_id = cbt.bank_id
			AND gct.bank_id = bankId;
                        EXCEPTION WHEN NO_DATA_FOUND THEN
                                locUnusedChq := 0;
                        END;--}

---------------------- Added by Vijay to show unused leaves in pcfreq------------------------


			BEGIN --{
				locInfinityFlg := 'Y';
				select 'Y' into locInfinityFlg from dual where exists (select '1' from tbaadm.bdt where cust_id = loccustid);
				EXCEPTION WHEN NO_DATA_FOUND THEN
				locInfinityFlg := 'X';
            		END;--}

			--UPDATE	ICICI_CBRQ
			UPDATE ICICI.ICICI_CHQBK_RQST_TABLE
			SET		status_flg = 'S',
					status_date = locBodDate
			WHERE	CURRENT OF pcfDailyCur;

			IF substr(locForacid,5,2) = '01' then

				IF (locStatus = 'KIDE' OR locStatus = 'STUDT') then
					locDefNoLvs := 10;
				ELSE
					locDefNoLvs := 15;
				END IF;
			ELSE
				IF (locStatus = 'KIDE' OR locStatus = 'STUDT') then
					locDefNoLvs := 10;
				ELSE
					locDefNoLvs := 50;
				END IF;
			END IF;


			IF (to_char(locDate, 'dd-mm-yyyy') = to_char(locOpndate, 'dd-mm-yyyy')) THEN
				locStat := 'N';
			ELSE
				locStat := 'R';
			END IF;

			IF (locUser = 'SYSTEM') THEN
				locStat := 'S';
			END IF;

			IF (locNoOfBooks = 0) THEN
				locNoOfBooks := 1;
			END IF;

			IF (locAcctClsFlg = 'Y' OR locChqAlwdFlg != 'Y') THEN
				locNoOfBooks := 0;
			END IF;

			locRecLine := 	locGamForacid||'|'||
					locTitle||'|'||
					locName||'|'||
					locAddr1||'|'||
 					locAddr2||'|'||
					locAddr3||'|'||
					locCity||'|'||
					locState||'|'||
					locCountry||'|'||
					locPin||'|'||
					locSchm ||'|'||
					locNoOfBooks||'|'||
					locDefNoLvs||'|'||
					locStatus||'|'||
					locNre||'|'||
					locModeOfOper||'|'||
					locGamCustId||'|'||
					locConst||'|'||
					locOpndate||'|'||
					locCardname1 ||'|'||
					locName1Flg||'|'||
					locCardName2||'|'||
					locName2Flg||'|'||
					locCardName3||'|'||
					locName3Flg||'|'||
					locEmailId||'|'||
					locPhone1||'|'||
					locPhone2||'|'||
					locNomAvlFlg||'|'||
    	  				locNomNum||'|'||
					locCabmschq||'|'||
					locCabmssign||'|'||
					locStat||'|'||
					locLine1||'|'||
					locLine2||'|'||
					locLine3||'|'||
					locNumOfLvs||'|'||
					locCbType||'|'||
					locAcctCrncyCode||'|'||
					locPermAddr1||'|'||
					locPermAddr2||'|'||
					locPermAddr3||'|'||
					locPermCity||'|'||
					locPermState||'|'||
					locPermPinCode||'|'||
					locPermCountry||'|'||
					locPermPhoneNum||'|'||
					locPermTelexNum||'|'||
					locLedgNum||'|'||
					locMobileNum||'|'||
					locRepeatFlg||'|'||
                                        locUnusedChq||'|'||
					locSolId||'|'||
                                	locifccode||'|'||        ---CR-138-28858
                                	locmicrcd||'|'||         ---CR-138-28858
                                	locSolId||'|'||      ---CR-138-28858
					lochomebranchname||'|'|| --CR-138-28858
                                	lochomebranchadd1||'|'|| ---CR-138-28858
                                	lochomebranchadd2||'|'|| ---CR-138-28858
					lochomebranchcity||'|'|| ---CR-138-28858
					lochomebranchstate||'|'|| ---CR-138-28858
					lochomebranchpc||'|'|| ---CR-138-28858
                                	locUser||'|'||           ---CR-138-28858
                                	locDate||'|'||           ---CR-138-28858
					loc_Segment_NUM;
			outEndOfFile := 0;

	ELSE
			UPDATE	ICICI_CBRQ
			SET		status_flg = 'S',
					status_date = locBodDate
			WHERE	CURRENT OF pcfDailyCur;

			locRecLine := 	locForacid||'|'||
					'#'||'|'||
					'#'||'|'||
					'#'||'|'||
					'#'||'|'||
					'#';
			outEndOfFile := 0;

	END IF;

		--EXCEPTION
			--WHEN OTHERS THEN 
				---raise_application_error(-20998,sqlerrm);
				
	END getDailyReq;

--  **********************************************************************
	PROCEDURE getPrevReq(	inReqDate	IN		VARCHAR2,
				locRecLine	OUT		VARCHAR2,
				outEndOfFile	IN OUT		NUMBER,
				bankId              IN      VARCHAR2
						) IS

		locPatternId		ICICI_CBPT.pattern_id%TYPE;

		locLine1		ICICI_CBPT.line1%TYPE;
		locLine2		ICICI_CBPT.line2%TYPE;
		locLine3		ICICI_CBPT.line3%TYPE;
		locBodDate		tbaadm.GCT.db_stat_date%TYPE;
		locDcAlias		tbaadm.GCT.dc_alias%TYPE;
		locSrlNum		ICICI_LDTT.ser_num%TYPE;
		locForacid		ICICI_CBRQ.foracid%TYPE;
		locSetId		ICICI_CBRQ.set_id%TYPE;
		locCbType		ICICI_CBRQ.cb_type%TYPE;
		locNumOfLvs		ICICI_CBRQ.num_of_lvs%TYPE;
		locNoOfBooks            ICICI_CBRQ.num_of_chq_bks%TYPE;
		locUser        		ICICI_CBRQ.rcre_user%TYPE;
		locDate        		ICICI_CBRQ.rcre_time%TYPE;
		locStat			CHAR(1);
		locCardName1		ICICI_CDTT.card_1_name%TYPE;
		locCardName2		ICICI_CDTT.card_2_name%TYPE;
		locCardName3		ICICI_CDTT.card_3_name%TYPE;
		locMothersName		ICICI_CIFT.mothers_maiden_name%TYPE;
		locEmailId		ICICI_CIFT.email_id%TYPE;
		locName1Flg		CHAR(1);
		locName2Flg		CHAR(1);
		locName3Flg		CHAR(1);
		locDateOfBirth		VARCHAR2(15);
		locDateOfBirthFlg	CHAR(1);
		locNomAvlFlg		CHAR(1);
		locNomNum		tbaadm.ANT.nom_reg_num%TYPE;
		locNominee		tbaadm.ANT.nom_name%TYPE;
		locCabmssign		VARCHAR2(80);
		locCabmschq		VARCHAR2(90);
		locGamForacid		tbaadm.GAM.foracid%TYPE;
		locSchm			tbaadm.GAM.schm_code%TYPE;
		locModeOfOper		tbaadm.GAM.mode_of_oper_code%TYPE;
		locGamCustId		tbaadm.GAM.cif_id%TYPE;
		locOpnDate		tbaadm.GAM.acct_opn_date%TYPE;			--##
		locTitle		cnma.cust_title_code%TYPE;
		locAddr1		cnma.address1%TYPE;
		locAddr2		cnma.address2%TYPE;
		locAddr3		cnma.address3%TYPE;
		--locPhone1		cphone.phoneno%TYPE;
		locPhone1		CRMUSER.PHONEEMAIL.phoneno%TYPE;
		--locPhone2		cphone.phoneno%TYPE;
		locPhone2		CRMUSER.PHONEEMAIL.phoneno%TYPE;
		locAcid			tbaadm.GAM.acid%TYPE;
		locAcctCrncyCode	tbaadm.GAM.acct_crncy_code%TYPE;
		locglsubheadcode	tbaadm.GAM.gl_sub_head_code%TYPE;
		locCityCode		cnma.city_code%TYPE;
		locStateCode		cnma.state_code%TYPE;
		locCountryCode		cnma.cntry_code%TYPE;
		locPin			cnma.pin_code%TYPE;
		locStatus		tbaadm.CMG.cust_stat_code%TYPE;
		locName			tbaadm.CMG.cust_name%TYPE;
		locNre			tbaadm.CMG.cust_nre_flg%TYPE;
		locCtype		tbaadm.CMG.cust_type_code%TYPE;
		locCgroup		tbaadm.CMG.cust_grp%TYPE;
		locConst		tbaadm.CMG.cust_const%TYPE;
		locOccp			tbaadm.CMG.cust_occp_code%TYPE;
		locIntstat		tbaadm.CMG.cust_introd_stat_code%TYPE;
		locRating		tbaadm.CMG.cust_rating_code%TYPE;
		locCity			varchar2(25);
		locState		varchar2(25);
		locCountry		varchar2(25);
		locTypes		varchar2(10);
		locMul			varchar2(2);
		locNoOfLeaves		number;
		locNoOfChqs		number;
		locNomAvailableFlg	tbaadm.GAM.nom_available_flg%TYPE;
		locDefNoLvs		number;
		locAcctClsFlg		tbaadm.GAM.acct_cls_flg%TYPE;
		locChqAlwdFlg		tbaadm.GAM.chq_alwd_flg%TYPE;
		loc_cnt			number;
		locInfinityFlg		CHAR(1);
		locPermAddr1		cnma.address1%TYPE;
		locPermAddr2		cnma.address2%TYPE;
		locPermAddr3		cnma.address3%TYPE;
		locPermCityCode		cnma.city_code%TYPE;
		locPermStateCode	cnma.state_code%TYPE;
		locPermPinCode		cnma.pin_code%TYPE;
		locPermCntryCode	cnma.cntry_code%TYPE;
		--locPermPhoneNum	cphone.phoneno%TYPE;
		locPermPhoneNum     	CRMUSER.PHONEEMAIL.phoneno%TYPE;
		--locPermTelexNum	cphone.phoneno%TYPE;
		locPermTelexNum		CRMUSER.PHONEEMAIL.phoneno%TYPE;
		locPermCity             tbaadm.RCT.ref_desc%TYPE;
		locPermState            tbaadm.RCT.ref_desc%TYPE;
		locPermCountry          tbaadm.RCT.ref_desc%TYPE;
		--locCustPagerNo		cphone.phoneno%TYPE;
		locCustPagerNo		CRMUSER.PHONEEMAIL.phoneno%TYPE;
		locLedgNum		tbaadm.GAM.ledg_num%TYPE;
                locMobileNum            ICICI_ALERT_REG.MODE_ID%TYPE;
		locRepeatFlg		CHAR(1);
		locUnusedChq		number;
		locSolId		tbaadm.GAM.sol_id%TYPE;
--		loc_Segment_NUM         ICICI_CUST_SEG.SEGEMENT%TYPE;
		loc_Segment_NUM         VARCHAR2(100); 
		locmicrcd               VARCHAR2(9);   
                locifccode              VARCHAR2(12);  
                lochomesolid            VARCHAR2(8); 
                lochomebranchadd1       VARCHAR2(45);
                lochomebranchadd2       VARCHAR2(45);
		lochomebranchcc		VARCHAR2(5);
		lochomebranchcity	VARCHAR2(50);
		lochomebranchsc		VARCHAR2(5);
		lochomebranchstate	VARCHAR2(50);
		lochomebranchpc		VARCHAR2(15);
		lochomebranchname	VARCHAR2(15);
		 corp_id                 VARCHAR2(30);
                addrIdc                 VARCHAR2(30);
                phoneType1c             VARCHAR2(30);
                phoneType2c             VARCHAR2(30);
                addrIdp                 VARCHAR2(30);
                phoneType1p             VARCHAR2(30);
                phoneType2p             VARCHAR2(30);
		loccustid		tbaadm.gam.cust_id%TYPE;


	BEGIN--{
		IF NOT pcfPrevCur%ISOPEN THEN
			glbPrevDate := inReqDate;
			bankId1 := bankId;
		     	OPEN pcfPrevCur;
	    	END IF;
 
		locCardName1 := '*';
		locCardName2 := '*';
		locCardName3 := '*';
		locMothersName := '*';
		locEmailId := '*';
		locName1Flg := 'N';
		locName2Flg := 'N';
		locName3Flg := 'N';
		locDateOfBirthFlg := 'N';
		locNomAvlFlg := 'N';
		locNomNum := '*';
		locNominee := '*';
		locCabmssign := '*';
		locCabmschq := '*';
 
		SELECT	dc_alias,
			db_stat_date
		INTO	locDcAlias,
			locBodDate
		FROM	tbaadm.GCT
		WHERE   bank_id = bankId;
 
		FETCH	pcfPrevCur
		INTO	locForacid,
			locSetId,
			locNumOfLvs,
			locNoOfBooks,
			locCbType,
			locUser,
			locDate;
 
		IF pcfPrevCur%NOTFOUND THEN
			CLOSE pcfPrevCur;

			SELECT  nvl((max(ser_num)+1),1)	
			INTO	locSrlNum
			FROM	ICICI_LDTT
 
			WHERE	dc_alias = locDcAlias
			AND		driver_id = 'PCF' AND bank_id = bankId;
 
			INSERT	INTO	ICICI_LDTT
			VALUES (locDcAlias, 'PCF', '!', locSrlNum, sysdate, '',bankId);
			outEndOfFile := 1;
			RETURN;
		END IF;
 
		BEGIN --{
			SELECT  acid,
					foracid,
					schm_code,
					mode_of_oper_code,
					cif_id,
					decode(schm_code,'SBKIT',last_unfrez_date,'CAKIT',last_unfrez_date,acct_opn_date) ,
					nom_available_flg,
					acct_cls_flg,
					chq_alwd_flg,
					acct_crncy_code,
					gl_sub_head_code,
					ledg_num,
					sol_id,
					cust_id
			INTO    locAcid,
					locGamForacid,
					locSchm,
					locModeOfOper,
					locGamCustId,
					locOpnDate,
					locNomAvailableFlg,
					locAcctClsFlg,
					locChqAlwdFlg,
					locAcctCrncyCode,
					locglsubheadcode,
					locLedgNum,
					locSolId,
					loccustid
			FROM	tbaadm.GAM
			WHERE   foracid = locForacid
			AND		entity_cre_flg = 'Y' AND bank_id = bankId;
 
			EXCEPTION WHEN NO_DATA_FOUND THEN
					locGamCustId := '#';
		END; --}

			IF (locSchm = 'SBKIT' OR locSchm = 'CAKIT' OR locSchm = 'SKNRE' OR locSchm = 'SBONL' OR locSchm = 'RMCRI') THEN
                        --{
		        	Begin
	                        --{
	  			Select cust_opn_date into locOpnDate from tbaadm.cmg where cif_id = locGamCustId AND bank_id = bankId;
                                Exception when no_data_found  then
	  				locOpnDate := NULL;
				End;
                                --}
                        END IF;
                        --}
 
	IF (locGamCustId != '#') THEN
	
	--#Query to check whether customer is retail or corporate
			BEGIN
			--#{
				SELECT cust_name, NVL(corp_id,'') 
				INTO locName,corp_id
				FROM tbaadm.cmg 
				WHERE cif_id = locGamCustId AND bank_id = bankId;
				EXCEPTION WHEN NO_DATA_FOUND THEN
				locName := '#';
				corp_id := '';
			--#}
			END;
			IF (corp_id != '') THEN
			--{
				addrIdc := 'Mailing';
				phoneType1c := 'COMMPH1';
				phoneType2c := 'COMMPH2';
				addrIdp := 'Registered';
				phoneType1p := 'HOMEPH1';
				phoneType2p := 'HOMEPH2';
			--#}
			ELSE
			--#{
				addrIdc := 'Mailing';
				phoneType1c := 'COMMPH1';
				phoneType2c := 'COMMPH2';
				addrIdp := 'Home';
				phoneType1p := 'HOMEPH1';
				phoneType2p := 'HOMEPH2';
			--#}
			END IF;
			BEGIN
			--#{
				--# Query to fetch customer communication address details
				SELECT	decode(cust_title_code,NULL,' ',cust_title_code),
					decode(address1,NULL,' ',address1),
					decode(address2,NULL,' ',address2),
					decode(address3,NULL,' ',address3),
					nvl(city_code,'*'),
					nvl(state_code,'*'),
					nvl(cntry_code,'*'),
					decode(pin_code,NULL,' ',pin_code)
				INTO
				locTitle,
				locAddr1,
				locAddr2,
				locAddr3,
				locCityCode,
				locStateCode,
				locCountryCode,
				locPin
				FROM cnma  
				WHERE addr_b2kid = locGamCustId
				AND bank_id	= bankId
				AND addr_id = addrIdc
				AND locBodDate between start_date and end_date;
				EXCEPTION WHEN NO_DATA_FOUND THEN
				locTitle := '#';
				locName := '#';
				locAddr1 := '#';
				locAddr2 := '#';
				locAddr3 := '#';
				locCityCode := '#';
				locStateCode := '#';
				locCountryCode := '#';
				locPin := '#';
			--#}
			END;
			BEGIN
				--# Query to fetch customer permanent address details
				SELECT	decode(address1,NULL,' ',address1),
					decode(address2,NULL,' ',address2), 
					decode(address3,NULL,' ',address3),
					nvl(city_code,'*'),
					nvl(state_code,'*'),
					nvl(cntry_code,'*'),
					decode(pin_code,NULL,' ',pin_code)
				INTO
				locPermAddr1,
				locPermAddr2,
				locpermAddr3,
				locPermCityCode,
				locPermStateCode,
				locPermCntryCode,
				locPermPinCode
				FROM cnma  
				WHERE addr_b2kid = locGamCustId
				AND bank_id	= bankId
				AND addr_id = addrIdp
				AND locBodDate between start_date and end_date;
				EXCEPTION WHEN NO_DATA_FOUND THEN
				locPermAddr1 := '#';
				locPermAddr2 := '#';
				locPermAddr3 := '#';
				locPermCityCode := '#';
				locPermStateCode := '#';
				locPermCntryCode := '#';
				locPermPinCode := '#';
			END;
			BEGIN
				--#Query to fetch communication telephone details1
				SELECT NVL(phoneno,'*')
				INTO 
				locPhone1
				FROM crmuser.phoneemail  
				WHERE orgkey = locGamCustId
				AND bank_id = bankId
				AND phoneoremail = 'PHONE'
				AND phoneemailtype = phoneType1c;
				
				EXCEPTION WHEN NO_DATA_FOUND THEN
				locPhone1 := '#';
			END;
			BEGIN
				--#Query to fetch communication telephone details2
				SELECT NVL(phoneno,'*')
				INTO 
				locPhone2
				FROM crmuser.phoneemail  
				WHERE orgkey = locGamCustId
				AND bank_id = bankId
				AND phoneoremail = 'PHONE'
				AND phoneemailtype = phoneType2c;
				
				EXCEPTION WHEN NO_DATA_FOUND THEN
				locPhone2 := '#';
			END;
			BEGIN
				--#Query to fetch permanent telephone details
				SELECT NVL(phoneno,'*')
				INTO 
				locPermPhoneNum
				FROM crmuser.phoneemail 
				WHERE orgkey = locGamCustId
				AND bank_id = bankId
				AND phoneoremail = 'PHONE'
				AND phoneemailtype = phoneType1p;
				
				EXCEPTION WHEN NO_DATA_FOUND THEN
				locPermPhoneNum := '#';
			END;
			BEGIN
				--#Query to fetch telex details
				SELECT NVL(phoneno,'*')
				INTO 
				locPermTelexNum
				FROM crmuser.phoneemail 
				WHERE orgkey = locGamCustId
				AND bank_id = bankId
				AND phoneoremail = 'PHONE'
				AND phoneemailtype = 'TELEX';
				--AND UPPER (phoneemailtype) = UPPER ('TELEX');
				
				EXCEPTION WHEN NO_DATA_FOUND THEN
				locPermTelexNum := '#';
			END;
			BEGIN
				--#Query to fetch pager details
				SELECT NVL(phoneno,'*')
				INTO 
				locCustPagerNo
				FROM crmuser.phoneemail 
				WHERE orgkey = locGamCustId
				AND bank_id = bankId
				AND phoneoremail = 'PHONE'
				AND phoneemailtype = 'CELLPH';
				--AND UPPER (phoneemailtype) = UPPER ('PAGER');
				
				EXCEPTION WHEN NO_DATA_FOUND THEN
				locCustPagerNo := '#';
			END;
			BEGIN
				--#Query to fetch other details
				SELECT  cust_stat_code,
					decode(rtrim(cust_stat_code), 'KIDE', 10, 'STUDT' ,10,'CABUS',50, 15),
					decode(cmg.cust_nre_flg,NULL,'N',cmg.cust_nre_flg),
					cust_type_code,
					cust_grp,
					cust_const,
					cust_occp_code,
					cust_introd_stat_code,
					cust_rating_code,
					decode(ltrim(to_char(date_of_birth,'DD-MM-YYYY')),NULL,'00-00-0000',ltrim(to_char(date_of_birth,'DD-MM-YYYY'))),
					decode(ltrim(to_char(date_of_birth,'DD-MM-YYYY')),NULL,'N','Y')
				INTO    locStatus,
					locNoOfChqs,
					locNre,
					locCtype,
					locCgroup,
					locConst,
					locOccp,
					locIntstat,
					locRating,
					locDateOfBirth,
					locDateOfBirthflg
					FROM  tbaadm.cmg
				WHERE   cif_id = locGamCustId AND bank_id = bankId;
				EXCEPTION WHEN NO_DATA_FOUND THEN
				locStatus := '#';
				locNoOfChqs := '#';
				locNre := '#';
				locCtype := '#';
				locCgroup := '#';
				locConst := '#';
				locOccp := '#';
				locIntstat := '#';
				locRating := '#';
				locDateOfBirth := '#';
				locDateOfBirthflg := '#';
			--#}
            		END;
      --END IF;
	
 
--/* Added by Manoj Chopra(Infosys) for mandate holders cheque book request */
 
            if (locCbType = 'X') then
	    		--#Query to check whether customer is retail or corporate
	    		BEGIN
	    		--#{
	    			SELECT cust_name, NVL(corp_id,'') 
	    			INTO locName,corp_id
	    			FROM tbaadm.cmg 
	    			WHERE cif_id = locGamCustId AND bank_id = bankId;
	    			EXCEPTION WHEN NO_DATA_FOUND THEN
	    			locName := '#';
	    			corp_id := '';
	    		END;
	    		IF (corp_id != '') THEN
	    		--{
	    			addrIdc := 'Mailing';
	    			phoneType1c := 'COMMPH1';
	    			phoneType2c := 'COMMPH2';
	    			addrIdp := 'Registered';
	    			phoneType1p := 'HOMEPH1';
	    			phoneType2p := 'HOMEPH2';
	    		--#}
	    		ELSE
	    		--#{
	    			addrIdc := 'Mailing';
	    			phoneType1c := 'COMMPH1';
	    			phoneType2c := 'COMMPH2';
	    			addrIdp := 'Home';
	    			phoneType1p := 'HOMEPH1';
	    			phoneType2p := 'HOMEPH2';
	    		--#}
	    		END IF;
	    			BEGIN
	    			--#{
	    				--# Query to fetch customer communication address details
	    				SELECT	decode(cust_title_code,NULL,' ',cust_title_code),
	    					decode(address1,NULL,' ',address1),
	    					decode(address2,NULL,' ',address2), 
						decode(address3,NULL,' ',address3),
	    					nvl(city_code,'*'),
	    					nvl(state_code,'*'),
	    					nvl(cntry_code,'*'),
	    					decode(pin_code,NULL,' ',pin_code)
	    				INTO
	    				locTitle,
	    				locAddr1,
	    				locAddr2,
					locAddr3,
	    				locCityCode,
	    				locStateCode,
	    				locCountryCode,
	    				locPin
	    				FROM cnma  
	    				WHERE  bank_id	= bankId
	    				AND addr_id = addrIdc
	    				AND addr_b2kid = (SELECT cif_id_mandate_holder from ICICI_MANDATE_HOLDER WHERE foracid_nri=locForacid and del_flg != 'Y' AND bank_id = bankId)
					AND locBodDate between start_date and end_date;
	    				
	    				EXCEPTION WHEN NO_DATA_FOUND THEN
	    				locTitle := '#';
	    				locName := '#';
	    				locAddr1 := '#';
	    				locAddr2 := '#';
					locAddr3 := '#';
	    				locCityCode := '#';
	    				locStateCode := '#';
	    				locCountryCode := '#';
	    				locPin := '#';
	    			--#}
	    			END;
	    			BEGIN
	    			--#{
	    				--#Query to fetch communication telephone details1
	    				SELECT NVL(phoneno,'*')
	    				INTO 
	    				locPhone1
	    				FROM crmuser.phoneemail
	    				WHERE orgkey = (SELECT cif_id_mandate_holder from ICICI_MANDATE_HOLDER WHERE foracid_nri=locForacid and del_flg != 'Y' AND bank_id = bankId) 
	    				AND bank_id = bankId
	    				AND phoneoremail = 'PHONE'
	    				AND phoneemailtype = phoneType1c;
	    				
	    		
	    				EXCEPTION WHEN NO_DATA_FOUND THEN
	    				locPhone1 := '#';
	    			END; --}
				BEGIN
	    			--#{
	    				--#Query to fetch communication telephone details2
	    				SELECT NVL(phoneno,'*')
	    				INTO 
	    				locPhone2
	    				FROM crmuser.phoneemail 
	    				WHERE orgkey = (SELECT cif_id_mandate_holder from ICICI_MANDATE_HOLDER WHERE foracid_nri=locForacid and del_flg != 'Y' AND bank_id = bankId) 
	    				AND bank_id = bankId
	    				AND phoneoremail = 'PHONE'
	    				AND phoneemailtype = phoneType2c;
	    		
	    				EXCEPTION WHEN NO_DATA_FOUND THEN
	    				locPhone2 := '#';
	    			END; --}
	    
	END IF;
/**************************************************************************/


		BEGIN--{
			SELECT  nvl(ltrim(card_1_name),'*'),
					decode(ltrim(card_1_name),NULL, 'N','Y'),
					nvl(ltrim(card_2_name),'*'),
					decode(ltrim(card_2_name),NULL,'N','Y'),
					nvl(ltrim(card_3_name),'*'),
					decode(ltrim(card_3_name),NULL,'N','Y')
			INTO    locCardName1,
					locName1Flg,
					locCardName2,
					locName2Flg,
					locCardName3,
					locName3Flg
			FROM    ICICI_CDTT
			WHERE   cif_id = loccustid;
 
			EXCEPTION WHEN NO_DATA_FOUND THEN
					locCardName1 := '*';
					locName1Flg := 'N';
					locCardName2 := '*';
					locName2Flg := 'N';
					locCardName3 := '*';
					locName3Flg := 'N';
		END;--}
 
 
		BEGIN --{
			SELECT	mothers_maiden_name,
				email_id
			INTO	locMothersName,
				locEmailId
			FROM	ICICI_CIFT
			WHERE	cif_id = locGamCustId AND bank_id = bankId;
 
			EXCEPTION WHEN NO_DATA_FOUND THEN
				locMothersName := '*';
				locEmailId := '*';
		END; --}
		
		--########## CR-138-28858 Sanjay Kamath#########################
                        BEGIN --{
                                        Select BANK_IDENTIFIER
                                        into locifccode
                                        from tbaadm.BRBIC
                                        where bank_code ='ICI'
                                        and branch_code = (select br_code from tbaadm.sol where sol_id = locSolId)
                                        and paysys_id ='GROSS' AND bank_id = bankId;
                                        EXCEPTION WHEN NO_DATA_FOUND THEN
                                                locifccode := '*';
                        END; --}

                        BEGIN --{
                                        SELECT MICR_CENTRE_CODE||MICR_BANK_CODE||MICR_BRANCH_CODE,UPPER(br_addr_1),UPPER(br_addr_2),br_city_code,br_state_code,br_pin_code,UPPER(br_name)
                                        INTO locmicrcd,lochomebranchadd1,lochomebranchadd2,lochomebranchcc,lochomebranchsc,lochomebranchpc,lochomebranchname
                                        FROM tbaadm.BCT
                                        where bank_code = 'ICI'
                                          and br_code= (select br_code from tbaadm.sol where sol_id = locSolId AND bank_id = bankId);
                                        EXCEPTION
                                        WHEN NO_DATA_FOUND THEN
                                                locmicrcd := '*';
                                                lochomebranchadd1 := '*';
                                                lochomebranchadd2 := '*';
                                                lochomebranchcc := '*';  
                                        	 lochomebranchsc := '*';
                                                lochomebranchpc := '*';
                                                lochomebranchname := '*';
                        END; --}

                        BEGIN  --{
                                SELECT UPPER(REF_DESC)
                                  INTO lochomebranchcity
                                  FROM tbaadm.RCT
                                 WHERE REF_REC_TYPE = '01'
                                   AND REF_CODE = lochomebranchcc AND bank_id = bankId;
                        EXCEPTION
                                WHEN NO_DATA_FOUND THEN
                                        lochomebranchcity := '*';
                        END ;  --}

                        BEGIN  --{
                                SELECT UPPER(REF_DESC)
                                  INTO lochomebranchstate
                                  FROM tbaadm.RCT
                                 WHERE REF_REC_TYPE = '02'
                                   AND REF_CODE = lochomebranchsc AND bank_id = bankId;
                        EXCEPTION
                                WHEN NO_DATA_FOUND THEN
                                        lochomebranchstate := '*';
                        END ;  --}
                --###########  CR-138-28858  ########################


                BEGIN --{
                        if (locNomAvailableFlg = 'Y') then
                                SELECT  'Y',
                                                nom_reg_num,
                                                rtrim(nom_name)
                                INTO    locNomAvlFlg,
                                                locNomNum,
                                                locNominee
                                FROM    tbaadm.ANT
                                WHERE   acid = locAcid AND bank_id = bankId AND rownum = 1;
                        else
                                locNomAvlFlg := 'N';

                                locNomNum := '*';
                                locNominee := '*';
                        end if;

                        EXCEPTION WHEN NO_DATA_FOUND THEN
				locNomNum := '*';
                                locNominee := '*';
                END; --}

                begin
                        SELECT  decode(ref_desc,NULL,' ',ref_desc)
                        INTO    locCity
                        FROM    tbaadm.RCT
                        WHERE   ref_rec_type = '01'
                        AND     ref_code = locCityCode AND bank_id = bankId;
                exception
                        when no_data_found then
                                locCity := '*';
                end;

                begin
                        SELECT  decode(ref_desc,NULL,' ',ref_desc)
                        INTO    locState
                        FROM    tbaadm.RCT
                        WHERE   ref_rec_type = '02'
                        AND     ref_code = locStateCode AND bank_id = bankId;
                exception
                        when no_data_found then
                                locState := '*';
                end;

                begin
                        SELECT  decode(ref_desc,NULL,' ',ref_desc)
                        INTO    locCountry
                        FROM    tbaadm.RCT
                        WHERE   ref_rec_type = '03'
                        AND     ref_code = locCountryCode AND bank_id = bankId;
                exception
                        when no_data_found then
                                locCountry := '*';
                end;

                begin
                        SELECT  decode(ref_desc,NULL,' ',ref_desc)
                        INTO    locPermCity
                        FROM    tbaadm.RCT
                        WHERE   ref_rec_type = '01'
                        AND     ref_code = locPermCityCode AND bank_id = bankId;
                exception
                        when no_data_found then
                                locPermCity := '*';
                end;

                begin
                        SELECT  decode(ref_desc,NULL,' ',ref_desc)
                        INTO    locPermState
			FROM    tbaadm.RCT
                        WHERE   ref_rec_type = '02'
                        AND     ref_code = locPermStateCode AND bank_id = bankId;
                exception
                        when no_data_found then
                                locPermState := '*';
                end;

                begin
                        SELECT  decode(ref_desc,NULL,' ',ref_desc)
                        INTO    locPermCountry
                        FROM    tbaadm.RCT
                        WHERE   ref_rec_type = '03'
                        AND     ref_code = locPermCntryCode AND bank_id = bankId;
                exception
                        when no_data_found then
                                locPermCountry := '*';
                end;

        BEGIN--{
            SELECT  substr(locGamForacid,5,2)
            INTO    locMul
            FROM    dual;

            EXCEPTION WHEN NO_DATA_FOUND THEN

                locMul := 'ERROR';
        END;--}

        BEGIN--{
            IF substr(locGamForacid,5,2) = '01' then
                locCabmschq:=locName;
            ELSE
                SELECT 'for '||locName
                INTO locCabmschq
                FROM dual;
                END IF;

                SELECT  decode(rtrim(locConst),'1', 'INDIVIDUAL', locCabmssign)
                INTO    locCabmssign
                FROM    dual;

                SELECT  decode(rtrim(locConst),'10','PROPRIETOR',locCabmssign)
                INTO    locCabmssign
                FROM    dual;

                SELECT  decode(rtrim(locConst),'2','PARTNER(S)',locCabmssign)
                INTO    locCabmssign
                FROM    dual;
		
		SELECT  decode(rtrim(locConst),'3','AUTHORIZED SIGNATORY(IES)',locCabmssign)
                INTO    locCabmssign
                FROM    dual;

                SELECT  decode(rtrim(locConst),'4','AUTHORIZED SIGNATORY(IES)',locCabmssign)
                INTO    locCabmssign
                FROM    dual;

                SELECT  decode(rtrim(locConst),'5','TRUSTEE(S)',locCabmssign)
                INTO    locCabmssign
                FROM    dual;

                SELECT  decode(rtrim(locConst),'6','AUTHORIZED SIGNATORY(IES)',locCabmssign)
                INTO    locCabmssign
                FROM    dual;

                SELECT  decode(rtrim(locConst),'7','AUTHORIZED SIGNATORY(IES)',locCabmssign)
                INTO    locCabmssign
                FROM    dual;
        END;--}


        BEGIN--{
            SELECT    pattern_id,
                line1,
                line2,
                line3
            INTO    locPatternId,
                locLine1,
                locLine2,
                locLine3
            FROM    ICICI_CBPT
            WHERE    foracid = locForacid
            AND    set_id = locSetId;

            EXCEPTION WHEN NO_DATA_FOUND THEN
                locPatternId := '#';
                locLine1 := '#';
                locLine2 := '#';
                locLine3 := '#';
            END;--}

-- ......................... Added by Arkaja on 03.06.2008 for STR:ICI6824 .........................

            BEGIN --{
                SELECT  MODE_ID
                INTO    locMobileNum
                FROM    ICICI_ALERT_REG
                WHERE   FORACID = locForacid
                AND     MODE_OF_DELIVERY = '0'
		AND bank_id = bankId 
                AND     RCRE_TIME = (   SELECT  MAX(RCRE_TIME)
                            FROM    ICICI_ALERT_REG
                            WHERE   FORACID = locForacid
                            AND     MODE_OF_DELIVERY = '0'
                            AND     DEL_FLG = 'N' AND bank_id = bankId)
                AND     DEL_FLG = 'N'
                AND     ROWNUM < 2;

                EXCEPTION WHEN NO_DATA_FOUND THEN
                    locMobileNum := '#';
            END; --}

-- ............................. Added by Amitabh For segment field .............................
              BEGIN --{
                       --	SELECT SEGEMENT
                                SELECT SEGMENTATION_CLASS||'|'||SUBSEGMENT 
					into   loc_Segment_NUM
                                 --  from   ICICI_CUST_SEG
				     from   CMG
                                      where   cif_id = locGamCustId AND bank_id = bankId;
                      EXCEPTION WHEN NO_DATA_FOUND THEN
                                       loc_Segment_NUM := '';
               END; --}
--..........................................................................................

-- ......................... Added by Arkaja on 20.10.2008 for STR:ICI7118 .........................

                        BEGIN --{
                                SELECT  decode(count(FORACID),0,'N','Y')
                                INTO    locRepeatFlg
                                FROM    ICICI_CBRQ
                                WHERE   FORACID = locForacid
                                AND     STATUS_FLG = 'S'
                                AND bank_id = bankId
                                AND     locBodDate - RCRE_TIME <= 7 ; --- changed to 7 as per the CR-138-28858 Sanjay Kamath

                                EXCEPTION WHEN NO_DATA_FOUND THEN
                                        locRepeatFlg := 'N';  -- Changed as per
                        END; --}

-- .................................................................................................
---------------------- Added by Vijay to show unused leaves in pcfreq------------------------

                       BEGIN --{
                SELECT sum(NUM_CHARS(CHQ_LVS_STAT,'P')) into locUnusedChq
                        from tbaadm.cbt,tbaadm.gct
                        where acid = (select acid from tbaadm.gam where foracid = locForacid)
                        and chq_issu_date > add_months(db_stat_date,-6) AND gct.bank_id = bankId AND cbt.bank_id = bankId;
                        EXCEPTION WHEN NO_DATA_FOUND THEN
				locUnusedChq := 0;
                        END;--}

---------------------- Added by Vijay to show unused leaves in pcfreq------------------------


        BEGIN --{
                locInfinityFlg := 'Y';
                select 'Y' into locInfinityFlg from dual where exists (select '1' from tbaadm.bdt where cust_id = loccustid AND bdt.bank_id = bankId);
                EXCEPTION WHEN NO_DATA_FOUND THEN
                locInfinityFlg := 'X';

        END;--}

        IF substr(locForacid,5,2) = '01' then
            IF (locStatus = 'KIDE' OR locStatus = 'STUDT') then
                locDefNoLvs := 10;
            ELSE
                locDefNoLvs := 15;
            END IF;
        ELSE
            IF (locStatus = 'KIDE' OR locStatus = 'STUDT') then
                locDefNoLvs := 10;

            ELSE
                locDefNoLvs := 50;
            END IF;
        END IF;

        IF (to_char(locDate, 'dd-mm-yyyy') = to_char(locOpndate, 'dd-mm-yyyy')) THEN
            locStat := 'N';
        ELSE
            locStat := 'R';
        END IF;

        IF (locUser = 'SYSTEM') THEN
            locStat := 'S';
        END IF;

        IF (locNoOfBooks = 0) THEN
            locNoOfBooks := 1;
        END IF;

        IF (locAcctClsFlg = 'Y' OR locChqAlwdFlg != 'Y') THEN
            locNoOfBooks := 0;
        END IF;

	locRecLine :=     locGamForacid||'|'||
                locTitle||'|'||
                locName||'|'||
                locAddr1||'|'||
                locAddr2||'|'||
		locAddr3||'|'||
                locCity||'|'||
                locState||'|'||
                locCountry||'|'||
                locPin||'|'||
                locSchm ||'|'||
                locNoOfBooks||'|'||
                locDefNoLvs||'|'||
                locStatus||'|'||
                locNre||'|'||
                locModeOfOper||'|'||
                locGamCustId||'|'||
                locConst||'|'||
                locOpndate||'|'||
                locCardname1 ||'|'||
                locName1Flg||'|'||
                locCardName2||'|'||
                locName2Flg||'|'||
                locCardName3||'|'||
                locName3Flg||'|'||
                locEmailId||'|'||
                locPhone1||'|'||
                locPhone2||'|'||
                locNomAvlFlg||'|'||
                locNomNum||'|'||
                locCabmschq||'|'||
                locCabmssign||'|'||
                locStat||'|'||
                locLine1||'|'||
                locLine2||'|'||
                locLine3||'|'||
                locNumOfLvs||'|'||
                locCbType||'|'||
                locAcctCrncyCode||'|'||
                locPermAddr1||'|'||
                locPermAddr2||'|'||
		locPermAddr3||'|'||
                locPermCity||'|'||
                locPermState||'|'||
                locPermPinCode||'|'||
                locPermCountry||'|'||
                locPermPhoneNum||'|'||
                locPermTelexNum||'|'||
                locLedgNum||'|'||
                locMobileNum||'|'||
                locRepeatFlg||'|'||
                locUnusedChq||'|'||
		locSolId||'|'||
                locifccode||'|'||     ---CR-138-28858
                locmicrcd||'|'||     ---CR-138-28858
                locSolId||'|'||     ---CR-138-28858
                lochomebranchname||'|'||  --CR-138-28858
                lochomebranchadd1||'|'|| ---CR-138-28858
                lochomebranchadd2||'|'|| ---CR-138-28858
                lochomebranchcity||'|'|| ---CR-138-28858
                lochomebranchstate||'|'|| ---CR-138-28858
                lochomebranchpc||'|'|| ---CR-138-28858
                locUser||'|'||         ---CR-138-28858
                locDate||'|'||         ---CR-138-28858
                loc_Segment_NUM;
        outEndOfFile := 0;
    ELSE
            locRecLine :=     locForacid||'|'||
                    '#'||'|'||
                    '#'||'|'||
                    '#'||'|'||
                    '#'||'|'||
                    '#';

            outEndOfFile := 0;
    END IF;

        EXCEPTION WHEN OTHERS THEN
            raise_application_error(-20999,sqlerrm);
    END getPrevReq;--}

END    pcfreq;--}
/

CREATE PUBLIC SYNONYM PCFREQ FOR ICICI.PCFREQ
/
GRANT EXECUTE ON pcfreq TO PUBLIC
/
GRANT EXECUTE ON icici.num_chars TO PUBLIC
/
show err
/
spool off 
