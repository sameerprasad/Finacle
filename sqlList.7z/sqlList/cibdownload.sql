-----------------------------------------------------------------------------------------------------
-- Filename         : cibdownload.sql
-- Description     : Sql File which spools out account details from GAM table
-- Date                  : 20-09-2012
-- Author       : Neethu Baby
-- Menu Option                : HEXECOM
-- Modification History
-- Sl.#       Date           Author         Modification                              
-- -----   ----------   --------------    ----------------                               
--  1.0    20-09-2012   Aparna Ashok    Original Version                          
----------------------------------------------------------------------------------------------------------


set head off
set verify off
set feedback off
set trimspool on
set pages 0
set termout off
spool cib&1..lst
select
	'|'||
	trim(cif_id)||
	'|'||
	'|'||
	'<GRP>'||
	'|'||
	trim(cif_id)||
	'|'||
	trim(cif_id)||
	'|'||
	'<CUST>'||
	'|'||
	'&3/'||
	trim(cif_id)||
	'|'||
	'<USR>'||
	'|'||
	'USER1'||
	'|'||
	'USER1'||
	'|'||
	'|'||
	'.'||
	'|'
from gam where sol_id= '&1'
and schm_code = 'CAKIT'
and acct_opn_date = '&2'
and acct_name = '* * *'
and del_flg!='Y'
and entity_cre_flg='Y'
and bank_id = '&4'
/
spool off
exit
