----------------------------------------------------------------------------------------------------
--   Source Name            : Report_signmap.sql 
--   Description            : Signature not mapped report.
--   Input Values           : None
--   Output Values          : None
--   Called Script          : N.A
--   Calling Script         : N.A
--   Modification History:
--   Sl No.         Date              Author                     Description
--   --------------------------------------------------------------------------------------
--     01         09-Oct-2012         Priyanka                 Original Version
----------------------------------------------------------------------------------------------------

set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_signmap.lst

DECLARE

lv_solid		 gam.sol_id%type :='&1';
lv_bankid		 clmt.bank_id%type := '&2';
v_cnt			 number(10);
V_CUSTNAME		 varchar2(40);

CURSOR c1 IS

select 	distinct clmt.cif_id,
		clmt.sol_id,
		wlckm.rack_id,
		clmt.LOCKER_TYPE,
		clmt.locker_num,
		'',
		cmg.CUST_NAME Hirer_name,
		clmt.ISSUE_DATE allot_date 
from   clmt,cmg,wlckm
where  clmt.sol_id = lv_solid
and    clmt.cif_id = cmg.cif_id
and    clmt.bank_id = wlckm.bank_id
and    wlckm.bank_id = cmg.bank_id
and    clmt.bank_id = lv_bankid
and    wlckm.LOCKER_NUM=CLMT.LOCKER_NUM
and    clmt.del_flg != 'Y'
and    wlckm.ENTITY_CRE_FLG = 'Y'
and    clmt.sol_id = wlckm.sol_id
order by 8;

cursor c2(V_cif_MH_ID cljh.cif_MH_ID%type,V_LOCK_NO cljh.LOCKER_NUM%type) is
SELECT
		cif_MH_ID,
		cif_JH_ID
FROM
		CLJH,wlckm
WHERE
		wlckm.locker_num = cljh.locker_num
and		wlckm.sol_id = cljh.sol_id
and		cif_MH_ID = V_cif_MH_ID
AND		cljh.LOCKER_NUM = V_LOCK_NO
AND		cljh.SOL_ID = LV_SOLID
AND         	cljh.bank_id = wlckm.bank_id
AND         	cljh.bank_id = lv_bankid
AND		cljh.DEL_FLG != 'Y'
AND		cljh.ENTITY_CRE_FLG = 'Y'
AND		wlckm.DEL_FLG != 'Y'
AND		wlckm.ENTITY_CRE_FLG = 'Y';

BEGIN

for f1 in c1
loop
	begin
	select count(1) into v_cnt from imt where cif_id = f1.cif_id;
	exception when no_data_found then
	v_cnt := 1;
	end;
	if(v_cnt = 0) then
	--{
			dbms_output.put_line( 	f1.sol_id         ||'|'||
									f1.rack_id        ||'|'||	
									f1.LOCKER_TYPE    ||'|'||	
									f1.locker_num     ||'|'||
									f1.cif_id        ||'|'||
									f1.Hirer_name     ||'|'|| 
									f1.allot_Date	 
								); 
	--}
	end if;
	for f2 in c2(f1.cif_id,f1.locker_num)
	loop
		begin
			SELECT COUNT(1) INTO V_CNT FROM IMT WHERE cif_id = F2.cif_JH_ID
			AND DEL_FLG != 'Y' AND ENTITY_CRE_FLG = 'Y';
			exception when no_data_found then
			v_cnt := 1;
		end;

		begin
			SELECT SUBSTR(CUST_NAME,1,40) INTO V_CUSTNAME FROM CMG WHERE cif_id = F2.cif_JH_ID
			AND DEL_FLG != 'Y' AND ENTITY_CRE_FLG = 'Y';
			exception when no_data_found then
			V_CUSTNAME := ' ';
		end;
		if(v_cnt = 0) then
		--{
				dbms_output.put_line(   f1.sol_id         ||'|'||
							f1.rack_id        ||'|'||
							f1.LOCKER_TYPE    ||'|'||
							f1.locker_num     ||'|'||
							f2.cif_JH_ID     ||'|'||
							V_CUSTNAME     	  ||'|'||
							f1.allot_Date
									);
		--}
		end if;
	end loop;
end loop; 
END;
/
spool off

