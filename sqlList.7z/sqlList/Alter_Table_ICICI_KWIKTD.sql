--================================================================================
--   Source Name                        :  icici_kwiktd_alter.sql
--   Date                               :  22-Apr-2012
--   Description                        :  This file includes alter statements to add CREDIT_PRO_ACCT_NUM column for custom table
--   Author                             :   Naveen
--  Modification History                :
--  <Serial No>   <Date>       <Author>    <Description>
--   001         22-Apt-2013    Ganesh     (CR-138-20450)
--================================================================================

ALTER TABLE ICICI_KWIKTD_TABLE ADD (CREDIT_PRO_ACCT_NUM varchar2(16));
