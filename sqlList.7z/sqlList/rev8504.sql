==============================================================================
-- File Name: rev8504.sql
-- Description: This is a custom table CUSTOM.C_NND.sql
-- Start Date: 17-Oct-2012 
-- Author: Ashutosh K Pandey
-- Modification History  :
-- Sl #      Date          Author Name            Description
-- ----  --------   -----------------         --------------
--  1    17-Oct-2012   Ashutosh K Pandey	Original Version
===============================================================================

set pages 0 feedback off trims on echo off verify off head off
spool rev8504date.txt
select to_date(to_date('&1','dd-mm-yyyy')-4,'dd-mm-yyyy') 
from dual
/
-- Guna Added here for CR-138-06902
spool off
spool rev80046date.txt
select to_date(to_date('&1','dd-mm-yyyy')-1,'dd-mm-yyyy') 
from dual 
/
spool off
-- Guna ended here

