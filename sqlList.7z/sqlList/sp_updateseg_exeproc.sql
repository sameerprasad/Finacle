--===================================================================================================================
--      Filename                       : sp_updateseg_exeproc.sql
--      Description                    : This sql script executes the procedure sp_updateseg
--      Date                           : 27-05-2013
--      Author                         : Sameer Ghaie
--      Menu Option                    : CARDS
--      Modification History           :
--      Sl. #            Date                Author             Modification
--      -----            -----              --------           ----------------
--===================================================================================================================
declare
cif_id 		CMG.CIF_ID%TYPE;
segment 	CMG.SEGMENTATION_CLASS%TYPE;
sub_segment 	CMG.SUBSEGMENT%TYPE;
begin
cif_id:='&1';
segment:='&2';
sub_segment:='&3';
CRMUSER.sp_UpdateSegment(cif_id,segment,sub_segment);
END;
/
