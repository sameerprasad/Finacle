set head off
set echo off
set trims on
set feedback off
set verify off
set pagesize 1000
set lin 120
spool alGenCnt
Select 'Alert Generation  Count:'||(select count(*) from icici_alert_info where proc_flg='N')||' Alert Delivery Count :'||(select count(*) from ICICI_ALERT where delv_flg='N')||' As on :'||to_char(sysdate ,'dd-mm-yyyy HH24:MM:SS') from dual;
spool off
