--===================================================================================================================
--      Filename             :  dnc_report.sql
--      Description          :  To fetch the data from dnc/dnc_mod and create report
--      Date                 :  17-Jul-2012
--      Author               :  Apurv Mishra
--      Menu Option          :  DNC
--      Modification History
--    Sl. #           Date             Author             Modification
--    -----            -----          --------         ----------------
--    01              17-Jul-2012    Apurv Mishra     Original Version
--===================================================================================================================


set feedback off
set pages 0
set echo off
set termout off
set trims on
set lines 200
set verify off
set serveroutput on size 1000000
set head off
set trimspool on

spool dncMn001.lst

DECLARE
v_dbStatDate date;
v_bankId  VARCHAR2(8);


CURSOR cursor1 IS
select cif_id,lchg_user_id,DNC_FLG,ELEC_MAT,PHYS_MAT
from dnc
where entity_cre_flg !='Y'
and bank_id = v_bankId
order by lchg_user_id;


CURSOR cursor2 IS
select cif_id,lchg_user_id,DNC_FLG,ELEC_MAT,PHYS_MAT
from dnc_mod
where bank_id = v_bankId
order by lchg_user_id;


BEGIN

v_bankId:='&1';

	select db_stat_date into v_dbStatDate from gct;

    dbms_output.put_line(' 			');
    dbms_output.put_line(' 			');
    dbms_output.put_line('       Unverified New DNC Customer Ids As on '||': '|| v_dbStatDate);
    dbms_output.put_line(' 			');
    dbms_output.put_line('---------'||'|'||'---------'||'|'||'---------'||'|'||'---------'||'|'||'---------'||'|' );
    dbms_output.put_line(' CIF_ID  '||'|'||'User id  '||'|'||'DNC_FLG  '||'|'||'ELEC_MAT '||'|'||'PHYS_MAT '||'|' );
    dbms_output.put_line('---------'||'|'||'---------'||'|'||'---------'||'|'||'---------'||'|'||'---------'||'|' );
for fc1 in cursor1
loop
    dbms_output.put_line( lpad(fc1.cif_id,9) ||'|'||
							lpad(fc1.lchg_user_id,9) ||'|'||
							lpad(fc1.DNC_FLG,9) ||'|'||
							lpad(fc1.ELEC_MAT,9) ||'|'||
							lpad(fc1.PHYS_MAT,9)||'|' );
end loop;


    dbms_output.put_line('---------'||'|'||'---------'||'|'||'---------'||'|'||'---------'||'|'||'---------'||'|' );
    dbms_output.put_line(' 			');
    dbms_output.put_line(' 			');
    dbms_output.put_line('       Modified DNC Customer Ids '||': '|| v_dbStatDate);
    dbms_output.put_line(' 			');
    dbms_output.put_line('---------'||'|'||'---------'||'|'||'---------'||'|'||'---------'||'|'||'---------'||'|' );
    dbms_output.put_line(' CIF_ID  '||'|'||'User id  '||'|'||'DNC_FLG  '||'|'||'ELEC_MAT '||'|'||'PHYS_MAT '||'|' );
    dbms_output.put_line('---------'||'|'||'---------'||'|'||'---------'||'|'||'---------'||'|'||'---------'||'|' );
for fc2 in cursor2
loop
    dbms_output.put_line( lpad(fc2.cif_id,9) ||'|'||
							lpad(fc2.lchg_user_id,9) ||'|'||
							lpad(fc2.DNC_FLG,9) ||'|'||
							lpad(fc2.ELEC_MAT,9) ||'|'||
							lpad(fc2.PHYS_MAT,9)||'|' );
end loop;

    dbms_output.put_line('---------'||'|'||'---------'||'|'||'---------'||'|'||'---------'||'|'||'---------'||'|' );
    dbms_output.put_line('                         ******END OF REPORT******                                     ');
exception when no_data_found then null;


v_dbStatDate := '';
END;
/

spool off

--exit
