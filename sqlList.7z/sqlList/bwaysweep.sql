-- =====================================================================================================================
-- Source Name            :  bwaysweep.sql
-- Description            :  BWAY Sweep Report
-- Input Values           :  None
-- Output Values          :  None
-- Called Scripts         :  None
-- Calling Scripts        :  bwaysweep.com
-- Modification history:
-- Sl. No            Date                 Author                      Description
-- ---------     --------------    ----------------------        ------------------------------
-- 1.0             04-06-2013       Naweed Yusuf Khan                   Ported as per 10.x
-- =====================================================================================================================

set echo off verify off feedback off term off pagesi 0 trims on serveroutput on size 1000000 timing off time off

spool bwaysweep

declare

cursor AcctList is
select foracid,clr_bal_amt,decode(sign(clr_bal_amt),-1,'C','D') parttran,sol_id from gam where sol_id = '0018' 
and bacid in ( 
'SLBWYTR0',
'SLBWYTR1',
'SLBWYTR2',
'SLBWYTR3',
'SLBWYTR4',
'SLBWYTR5',
'SLBWYTR6',
'SLBWYTR7',
'SLBWYTR8',
'SLBWYTR9',
'SLBWAYTR')   and acct_crncy_code = 'INR' 
and acct_cls_flg = 'N'
AND bank_id = '&1';

contratran varchar2(1) := 'D';

begin

for i in AcctList
loop


	dbms_output.put_line(i.foracid||'|'||'INR'||'|'||i.sol_id||'|'||i.parttran||'|'||abs(i.clr_bal_amt)||'|'||
							'DAY END BALANCE TRF');

	if ( i.parttran = 'C' )
	then
		contratran := 'D';
	else
		contratran := 'C';
	end if;

	dbms_output.put_line('0103SLBWAYCL'||'|'||'INR'||'|'||'0103'||'|'||contratran||'|'||abs(i.clr_bal_amt)||'|'||
							'DAY END BALANCE TRF');

end loop;
end;
/
--start{--------------------------------------------------------------------------------------------------
declare

cursor AcctList is
select foracid,clr_bal_amt,decode(sign(clr_bal_amt),-1,'C','D') parttran,sol_id from gam where sol_id = '0104'
and bacid in (
'SLAUTDR0',
'SLAUTDR1',
'SLAUTDR2',
'SLAUTDR3',
'SLAUTDR4',
'SLAUTDR5',
'SLAUTDR6',
'SLAUTDR7',
'SLAUTDR8',
'SLAUTDR9')   and acct_crncy_code = 'INR'
and acct_cls_flg = 'N'
AND bank_id = '&1';

contratran varchar2(1) := 'D';

begin

for i in AcctList
loop


    dbms_output.put_line(i.foracid||'|'||'INR'||'|'||i.sol_id||'|'||i.parttran||'|'||abs(i.clr_bal_amt)||'|'||
                            'DAY END BALANCE TRF');

    if ( i.parttran = 'C' )
    then
        contratran := 'D';
    else
        contratran := 'C';
    end if;

    dbms_output.put_line('0104SLAUPOOL'||'|'||'INR'||'|'||'0104'||'|'||contratran||'|'||abs(i.clr_bal_amt)||'|'||
                            'DAY END BALANCE TRF');

end loop;
end;
/

--end}-------------------------------------------------------------------------------------------------

declare

cursor AcctList_1 is
select foracid,clr_bal_amt,decode(sign(clr_bal_amt),-1,'C','D') parttran,sol_id from gam where sol_id = '0018' 
and bacid in ( 
'SLECMTR0',
'SLECMTR1',
'SLECMTR2',
'SLECMTR3',
'SLECMTR4',
'SLECMTR5',
'SLECMTR6',
'SLECMTR7',
'SLECMTR8',
'SLECMTR9',
'SLECOMTR')   and acct_crncy_code = 'INR' 
and acct_cls_flg = 'N'
AND bank_id = '&1';

contratran varchar2(1) := 'D';

begin

for i in AcctList_1
loop


	dbms_output.put_line(i.foracid||'|'||'INR'||'|'||i.sol_id||'|'||i.parttran||'|'||abs(i.clr_bal_amt)||'|'||
							'DAY END BALANCE TRF');

	if ( i.parttran = 'C' )
	then
		contratran := 'D';
	else
		contratran := 'C';
	end if;

	dbms_output.put_line('0103SLECOMCL'||'|'||'INR'||'|'||'0103'||'|'||contratran||'|'||abs(i.clr_bal_amt)||'|'||
							'DAY END BALANCE TRF');

end loop;
end;
/
declare

cursor AcctList_1 is
select foracid,clr_bal_amt,decode(sign(clr_bal_amt),-1,'C','D') parttran,sol_id from gam where sol_id = '0018' 
and bacid in ( 
'SLUBPTR0',
'SLUBPTR1',
'SLUBPTR2',
'SLUBPTR3',
'SLUBPTR4',
'SLUBPTR5',
'SLUBPTR6',
'SLUBPTR7',
'SLUBPTR8',
'SLUBPTR9',
'SLUBPSTR')   and acct_crncy_code = 'INR' 
and acct_cls_flg = 'N'
AND bank_id = '&1';

contratran varchar2(1) := 'D';

begin

for i in AcctList_1
loop


	dbms_output.put_line(i.foracid||'|'||'INR'||'|'||i.sol_id||'|'||i.parttran||'|'||abs(i.clr_bal_amt)||'|'||
							'DAY END BALANCE TRF');

	if ( i.parttran = 'C' )
	then
		contratran := 'D';
	else
		contratran := 'C';
	end if;

	dbms_output.put_line('0103SLUBPSTR'||'|'||'INR'||'|'||'0103'||'|'||contratran||'|'||abs(i.clr_bal_amt)||'|'||
							'DAY END BALANCE TRF');

end loop;
end ;
/

declare

cursor AcctList is
select foracid,clr_bal_amt,decode(sign(clr_bal_amt),-1,'C','D') parttran,sol_id from gam where sol_id = '0018'
and bacid in (
'SLNFSWD0',
'SLNFSWD1',
'SLNFSWD2',
'SLNFSWD3',
'SLNFSWD4',
'SLNFSWD5',
'SLNFSWD6',
'SLNFSWD7',
'SLNFSWD8',
'SLNFSWD9',
'SLNFSWDL')   and acct_crncy_code = 'INR'
and acct_cls_flg = 'N'
AND bank_id = '&1';

contratran varchar2(1) := 'D';

begin

for i in AcctList
loop


    dbms_output.put_line(i.foracid||'|'||'INR'||'|'||i.sol_id||'|'||i.parttran||'|'||abs(i.clr_bal_amt)||'|'||
                            'DAY END BALANCE TRF');

    if ( i.parttran = 'C' )
    then
        contratran := 'D';
    else
        contratran := 'C';
    end if;

    dbms_output.put_line('0103SLNFSWTL'||'|'||'INR'||'|'||'0103'||'|'||contratran||'|'||abs(i.clr_bal_amt)||'|'||
                            'DAY END BALANCE TRF');

end loop;
end;
/
 
declare

cursor AcctList is
select foracid,clr_bal_amt,decode(sign(clr_bal_amt),-1,'C','D') parttran,sol_id from gam where sol_id = '0018'
and bacid in (
'SLIPSWD0',
'SLIPSWD1',
'SLIPSWD2',
'SLIPSWD3',
'SLIPSWD4',
'SLIPSWD5',
'SLIPSWD6',
'SLIPSWD7',
'SLIPSWD8',
'SLIPSWD9',
'SLIPSWDL')   and acct_crncy_code = 'INR'
and acct_cls_flg = 'N'
AND bank_id = '&1';

contratran varchar2(1) := 'D';

begin

for i in AcctList
loop


    dbms_output.put_line(i.foracid||'|'||'INR'||'|'||i.sol_id||'|'||i.parttran||'|'||abs(i.clr_bal_amt)||'|'||
                            'DAY END BALANCE TRF');

    if ( i.parttran = 'C' )
    then
        contratran := 'D';
    else
        contratran := 'C';
    end if;

    dbms_output.put_line('0103SLIPSWDL'||'|'||'INR'||'|'||'0103'||'|'||contratran||'|'||abs(i.clr_bal_amt)||'|'||
                            'DAY END BALANCE TRF');

end loop;
end;
/

declare

cursor AcctList is
select foracid,clr_bal_amt,decode(sign(clr_bal_amt),-1,'C','D') parttran,sol_id from gam where sol_id = '0018'
and bacid in (
'SLVPSWD0',
'SLVPSWD1',
'SLVPSWD2',
'SLVPSWD3',
'SLVPSWD4',
'SLVPSWD5',
'SLVPSWD6',
'SLVPSWD7',
'SLVPSWD8',
'SLVPSWD9',
'SLVPSWDL')   and acct_crncy_code = 'INR'
and acct_cls_flg = 'N'
AND bank_id = '&1';

contratran varchar2(1) := 'D';

begin

for i in AcctList
loop


    dbms_output.put_line(i.foracid||'|'||'INR'||'|'||i.sol_id||'|'||i.parttran||'|'||abs(i.clr_bal_amt)||'|'||
                            'DAY END BALANCE TRF');

    if ( i.parttran = 'C' )
    then
        contratran := 'D';
    else
        contratran := 'C';
    end if;

    dbms_output.put_line('0103SLVPSWDL'||'|'||'INR'||'|'||'0103'||'|'||contratran||'|'||abs(i.clr_bal_amt)||'|'||
                            'DAY END BALANCE TRF');

end loop;
end;
/

declare

cursor AcctList is
select foracid,clr_bal_amt,decode(sign(clr_bal_amt),-1,'C','D') parttran,sol_id from gam where sol_id = '0018'
and bacid in (
'CNASPNF0',
'CNASPNF1',
'CNASPNF2',
'CNASPNF3',
'CNASPNF4',
'CNASPNF5',
'CNASPNF6',
'CNASPNF7',
'CNASPNF8',
'CNASPNF9')   and acct_crncy_code = 'INR'
and acct_cls_flg = 'N'
AND bank_id = '&1';

contratran varchar2(1) := 'D';

begin

for i in AcctList
loop


    dbms_output.put_line(i.foracid||'|'||'INR'||'|'||i.sol_id||'|'||i.parttran||'|'||abs(i.clr_bal_amt)||'|'||
                            'DAY END BALANCE TRF');

    if ( i.parttran = 'C' )
    then
        contratran := 'D';
    else
        contratran := 'C';
    end if;

    dbms_output.put_line('0018CNASPNFS'||'|'||'INR'||'|'||'0018'||'|'||contratran||'|'||abs(i.clr_bal_amt)||'|'||
                            'DAY END BALANCE TRF');

end loop;
end;
/

declare

cursor AcctList is
select foracid,clr_bal_amt,decode(sign(clr_bal_amt),-1,'C','D') parttran,sol_id from gam where sol_id = '0018'
and bacid in (
'SLATMST0',
'SLATMST1',
'SLATMST2',
'SLATMST3',
'SLATMST4',
'SLATMST5',
'SLATMST6',
'SLATMST7',
'SLATMST8',
'SLATMST9')   and acct_crncy_code = 'INR'
and acct_cls_flg = 'N'
AND bank_id = '&1';

contratran varchar2(1) := 'D';

begin

for i in AcctList
loop


    dbms_output.put_line(i.foracid||'|'||'INR'||'|'||i.sol_id||'|'||i.parttran||'|'||abs(i.clr_bal_amt)||'|'||
                            'DAY END BALANCE TRF');

    if ( i.parttran = 'C' )
    then
        contratran := 'D';
    else
        contratran := 'C';
    end if;

    dbms_output.put_line('0018SLATMSTX'||'|'||'INR'||'|'||'0018'||'|'||contratran||'|'||abs(i.clr_bal_amt)||'|'||
                            'DAY END BALANCE TRF');

end loop;
end;
/

declare

cursor AcctList is
select foracid,clr_bal_amt,decode(sign(clr_bal_amt),-1,'C','D') parttran,sol_id from gam where sol_id = '0018'
and bacid in (
'SLCMS2F0',
'SLCMS2F1',
'SLCMS2F2',
'SLCMS2F3',
'SLCMS2F4',
'SLCMS2F5',
'SLCMS2F6',
'SLCMS2F7',
'SLCMS2F8',
'SLCMS2F9')   and acct_crncy_code = 'INR'
and acct_cls_flg = 'N'
AND bank_id = '&1';

contratran varchar2(1) := 'D';

begin

for i in AcctList
loop


    dbms_output.put_line(i.foracid||'|'||'INR'||'|'||i.sol_id||'|'||i.parttran||'|'||abs(i.clr_bal_amt)||'|'||
                            'DAY END BALANCE TRF');

    if ( i.parttran = 'C' )
    then
        contratran := 'D';
    else
        contratran := 'C';
    end if;

    dbms_output.put_line('0018SLCMPOOL'||'|'||'INR'||'|'||'0018'||'|'||contratran||'|'||abs(i.clr_bal_amt)||'|'||
                            'DAY END BALANCE TRF');

end loop;
end;
/
declare

cursor AcctList is
select foracid,clr_bal_amt,decode(sign(clr_bal_amt),-1,'C','D') parttran,sol_id from gam where sol_id = '0103'
and bacid in (
'SLINTST',
'SLINTST1',
'SLINTST2',
'SLINTST3',
'SLINTST4',
'SLINTST5',
'SLINTST6',
'SLINTST7',
'SLINTST8',
'SLINTST9')   and acct_crncy_code = 'INR'
and acct_cls_flg = 'N'
AND bank_id = '&1';

contratran varchar2(1) := 'D';

begin

for i in AcctList
loop


    dbms_output.put_line(i.foracid||'|'||'INR'||'|'||i.sol_id||'|'||i.parttran||'|'||abs(i.clr_bal_amt)||'|'||
                            'DAY END BALANCE TRF');

    if ( i.parttran = 'C' )
    then
        contratran := 'D';
    else
        contratran := 'C';
    end if;

    dbms_output.put_line('0103SLINTSTX'||'|'||'INR'||'|'||'0018'||'|'||contratran||'|'||abs(i.clr_bal_amt)||'|'||
                            'DAY END BALANCE TRF');

end loop;
end;
/
declare

cursor AcctList is
select foracid,clr_bal_amt,decode(sign(clr_bal_amt),-1,'C','D') parttran,sol_id from gam where sol_id = '0103'
and bacid in (
'CN0UBPS',
'CN0UBPS1',
'CN0UBPS2',
'CN0UBPS3',
'CN0UBPS4',
'CN0UBPS5',
'CN0UBPS6',
'CN0UBPS7',
'CN0UBPS8',
'CN0UBPS9')   and acct_crncy_code = 'INR'
and acct_cls_flg = 'N'
AND bank_id = '&1';

contratran varchar2(1) := 'D';

begin

for i in AcctList
loop


    dbms_output.put_line(i.foracid||'|'||'INR'||'|'||i.sol_id||'|'||i.parttran||'|'||abs(i.clr_bal_amt)||'|'||
                            'DAY END BALANCE TRF');

    if ( i.parttran = 'C' )
    then
        contratran := 'D';
    else
        contratran := 'C';
    end if;

    dbms_output.put_line('0103CN00UBPS'||'|'||'INR'||'|'||'0018'||'|'||contratran||'|'||abs(i.clr_bal_amt)||'|'||
                            'DAY END BALANCE TRF');

end loop;
end;
/
declare

cursor AcctList is
select foracid,clr_bal_amt,decode(sign(clr_bal_amt),-1,'C','D') parttran,sol_id from gam where sol_id = '0018'
and bacid in (
'SLIRCTC0',
'SLIRCTC1',
'SLIRCTC2',
'SLIRCTC3',
'SLIRCTC4',
'SLIRCTC5',
'SLIRCTC6',
'SLIRCTC7',
'SLIRCTC8',
'SLIRCTC9')   and acct_crncy_code = 'INR'
and acct_cls_flg = 'N'
AND bank_id = '&1';

contratran varchar2(1) := 'D';

begin

for i in AcctList
loop


    dbms_output.put_line(i.foracid||'|'||'INR'||'|'||i.sol_id||'|'||i.parttran||'|'||abs(i.clr_bal_amt)||'|'||
                            'DAY END BALANCE TRF');

    if ( i.parttran = 'C' )
    then
        contratran := 'D';
    else
        contratran := 'C';
    end if;

    dbms_output.put_line('000705004422'||'|'||'INR'||'|'||'0007'||'|'||contratran||'|'||abs(i.clr_bal_amt)||'|'||
                            'DAY END BALANCE TRF');

end loop;
end;
/
declare

cursor AcctList_1 is
select foracid,clr_bal_amt,decode(sign(clr_bal_amt),-1,'C','D') parttran,sol_id from gam where sol_id in ( '0018'  ) 
and bacid in ( 
'SLVATWDL',
'SLEUROTR',
'SLMPSWDL',
'SLMATWDL',
'SLGLDPOOL',
'SLEBORPY',
'SAIMPSIN',
'SLIMPSOU' )   and acct_crncy_code = 'INR' 

and acct_cls_flg = 'N'
AND bank_id = '&1';


contratran varchar2(1) := 'D';

begin

for i in AcctList_1
loop

if ( i.foracid = '0018SLEUROTR' )
then
	dbms_output.put_line(i.foracid||'|'||'INR'||'|'||i.sol_id||'|'||i.parttran||'|'||abs(i.clr_bal_amt)||'|'||
							'DAY END BALANCE TRF');

	if ( i.parttran = 'C' )
	then
		contratran := 'D';
	else
		contratran := 'C';
	end if;

	dbms_output.put_line('0103SLEUROTR'||'|'||'INR'||'|'||'0103'||'|'||contratran||'|'||abs(i.clr_bal_amt)||'|'||
							'DAY END BALANCE TRF');
end if ; 
if ( i.foracid = '0018SLVATWDL' )
then
	dbms_output.put_line(i.foracid||'|'||'INR'||'|'||i.sol_id||'|'||i.parttran||'|'||abs(i.clr_bal_amt)||'|'||
							'DAY END BALANCE TRF');

	if ( i.parttran = 'C' )
	then
		contratran := 'D';
	else
		contratran := 'C';
	end if;

	dbms_output.put_line('0103SLVATWDL'||'|'||'INR'||'|'||'0103'||'|'||contratran||'|'||abs(i.clr_bal_amt)||'|'||
							'DAY END BALANCE TRF');
end if ; 
if ( i.foracid = '0018SLMATWDL' )
then
	dbms_output.put_line(i.foracid||'|'||'INR'||'|'||i.sol_id||'|'||i.parttran||'|'||abs(i.clr_bal_amt)||'|'||
							'DAY END BALANCE TRF');

	if ( i.parttran = 'C' )
	then
		contratran := 'D';
	else
		contratran := 'C';
	end if;

	dbms_output.put_line('0103SLMATWDL'||'|'||'INR'||'|'||'0103'||'|'||contratran||'|'||abs(i.clr_bal_amt)||'|'||
							'DAY END BALANCE TRF');
end if ; 
if ( i.foracid = '0018SLGLDPOOL' )
then
	dbms_output.put_line(i.foracid||'|'||'INR'||'|'||i.sol_id||'|'||i.parttran||'|'||abs(i.clr_bal_amt)||'|'||
							'DAY END BALANCE TRF');

	if ( i.parttran = 'C' )
	then
		contratran := 'D';
	else
		contratran := 'C';
	end if;

	dbms_output.put_line('0103SLCOINCR'||'|'||'INR'||'|'||'0103'||'|'||contratran||'|'||abs(i.clr_bal_amt)||'|'||

							'DAY END BALANCE TRF');
end if ; 
if ( i.foracid = '0018SLIMPSOU' )
then
	dbms_output.put_line(i.foracid||'|'||'INR'||'|'||i.sol_id||'|'||i.parttran||'|'||abs(i.clr_bal_amt)||'|'||
							'DAY END BALANCE TRF');

	if ( i.parttran = 'C' )
	then
		contratran := 'D';
	else
		contratran := 'C';
	end if;

	dbms_output.put_line('0103SLIMPSOU'||'|'||'INR'||'|'||'0103'||'|'||contratran||'|'||abs(i.clr_bal_amt)||'|'||

							'DAY END BALANCE TRF');
end if ;
if ( i.foracid = '0018SAIMPSIN' )

then
	dbms_output.put_line(i.foracid||'|'||'INR'||'|'||i.sol_id||'|'||i.parttran||'|'||abs(i.clr_bal_amt)||'|'||
							'DAY END BALANCE TRF');

	if ( i.parttran = 'C' )
	then
		contratran := 'D';
	else
		contratran := 'C';
	end if;

	dbms_output.put_line('0103SAIMPSIN'||'|'||'INR'||'|'||'0103'||'|'||contratran||'|'||abs(i.clr_bal_amt)||'|'||

							'DAY END BALANCE TRF');
end if ;
if ( i.foracid = '0018SLEBORPY' )
then
	dbms_output.put_line(i.foracid||'|'||'INR'||'|'||i.sol_id||'|'||i.parttran||'|'||abs(i.clr_bal_amt)||'|'||
							'DAY END BALANCE TRF');

	if ( i.parttran = 'C' )
	then
		contratran := 'D';
	else
		contratran := 'C';
	end if;

	dbms_output.put_line('0103SLEBORPY'||'|'||'INR'||'|'||'0103'||'|'||contratran||'|'||abs(i.clr_bal_amt)||'|'||
							'DAY END BALANCE TRF');
end if ; 
if ( i.foracid = '0018SLMPSWDL' )
then
	dbms_output.put_line(i.foracid||'|'||'INR'||'|'||i.sol_id||'|'||i.parttran||'|'||abs(i.clr_bal_amt)||'|'||
							'DAY END BALANCE TRF');

	if ( i.parttran = 'C' )
	then
		contratran := 'D';
	else
		contratran := 'C';
	end if;

	dbms_output.put_line('0103SLMPSWDL'||'|'||'INR'||'|'||'0103'||'|'||contratran||'|'||abs(i.clr_bal_amt)||'|'||
							'DAY END BALANCE TRF');
end if ; 
end loop;
end ;
/
spool off
