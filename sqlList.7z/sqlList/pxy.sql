
##############################################################################
# Source Name      :   pxy.sql
# Description      :   This sql file spools out the details of proxy accounts 
#                       with a finite balance amount.           
# Menu Option      :   proxy.com
# Modification Log :
#
# Date        Modified by                    Version  Remarks
# ----------- ------------------------------ -------- ------------------------
# 13-09-2012  Aparna Ashok                                    Original
##############################################################################

set pages 1000
 set colsep |
spool pxy.lst
select sol_id, foracid, clr_bal_amt from gam where bacid ='PROXY' and clr_bal_amt != 0 order by sol_id
/
spool off
