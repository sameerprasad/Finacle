set head off
set verify off
spool fsgTdsIdx

select 'Creating cust_id,tran_date index on TDS table' from DUAL;
drop index idx_tds_custid_trandate
/
create index idx_tds_custid_trandate
on TDS(cust_id,tran_date)
tablespace IDX_LOG_HISTORY
/
grant select, insert, update, delete on PSP_TEMP_TABLE to tbautil
/
spool off
quit
