--===================================================================================================================
--  Filename                :   letters_brlst.sql
--  Description             :
--  Date                    :   06-09-2012
--  Author                  :   Swaroop K Tiruvoipati
--  Menu Option             :
--  Modification History
--    Sl. #           Date           Author                     Modification
--    -----           -----          --------                    ----------------
--    1               06-09-2012     Swaroop K Tiruvoipati      Original Version
--                                                              (Ported from 7.x)
--===================================================================================================================
set head off
set feedback off
set verify off
set pages 0
spool br
select sol_id from sol order by sol_id where BANK_ID = '&1';
exit

