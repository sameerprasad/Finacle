--===================================================================================================================
--Filename             :  gctvalue.sql
--Date                 :  04-04-2013
--Author               :  Vaibhav
--Menu Option          :  Cron Job
--Modification History
--    Sl. #             Date             Author             Modification
--    -----            -----            --------           ----------------
--    01              04-04-2013       Vaibhav         Added Bank Id condition
--===================================================================================================================
set head off
set verify off
set feedback off
set trimspool on
set pages 0
set termout off
spool gctvalue.lst
SELECT dc_alias||'|'||to_char(db_stat_date-1,'dd-mm-yyyy') FROM gct WHERE bank_id='&1'
/
spool off
exit
