--*************************************************************************
--    Filename  : tdPendRpt.sql
--    Description      : To find the pending records in ICI_ADH_REQ_CHANGE table
--    Date              : 21-Jun-2012
--    Author    : Jithu Teresa Joseph
--    Menu Option       : ICIFDSTP
--    Modification History
--    Sl. #             Date            Author                  Modification
--    -----             -----           --------                        ----------------                            
--    1.0               21-Jun-2012     Jithu Teresa Joseph             Original Version. Migrated to 10.x.         
--*************************************************************************
set pages 0
set trims on
set echo off
set trims on
set feedback off
set linesize 200
spool tdPndRpt.lst
        select SR_NO,FORACID,REASON from ICI_ADH_REQ_CHANGE where PROC_FLG = 'E' and REQ_FLG = 'FD';
spool off
