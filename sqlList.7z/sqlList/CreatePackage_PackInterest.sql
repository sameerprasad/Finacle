CREATE OR REPLACE PACKAGE packInterest AS

    ----************************************************************
    --  *   PROCEDURE getIntTblCode                                *
    --  *      This Procedure returns the interest table code      *
    --  *        for an A/c as on a particular date.                *
    --  *        If no record is found for the A/c,                 *
    --  *        then value of out_foundFlg is set to 0             *
    --  *        Otherwise the value of out_foundFlg is set to 1    *
    ---*************************************************************
    PROCEDURE getIntTblCode (
            inp_asOnDate          IN OUT  VARCHAR2,
            inp_changeUpToDate    IN    VARCHAR2,
            inp_acid            IN  VARCHAR2,
            inp_bankId            IN    VARCHAR2,
            out_intTblCode        OUT VARCHAR2,
            out_custCrPrefPcnt    OUT VARCHAR2,
            out_custDrPrefPcnt    OUT VARCHAR2,
            out_idCrPrefPcnt    OUT VARCHAR2,
            out_idDrPrefPcnt    OUT VARCHAR2,
            out_foundFlg        OUT NUMBER,
            --***************************************
            out_min_int_pcnt_cr OUT VARCHAR2,
            out_min_int_pcnt_dr OUT VARCHAR2,
            out_max_int_pcnt_cr OUT VARCHAR2,
            out_max_int_pcnt_dr OUT VARCHAR2,
            out_pegged_flg          OUT CHAR
            --***************************************
        );

    ----************************************************************
    --  *   PROCEDURE getIntTblVersion                             *
    --  *      This Procedure returns the interest table Version   *
    --  *        for an Interest Table Codeas on a particular date. *
    --  *        If no record is found for the Table Code,          *
    --  *        then value of out_foundFlg is set to 1403          *
    --  *        Otherwise the value of out_foundFlg is set to 0    *
    ---*************************************************************
    PROCEDURE getIntTblVersion (
            inp_crncyCode        IN  VARCHAR2,
            inp_asOnDate          IN  VARCHAR2,
            inp_changeUpToDate    IN    VARCHAR2,
            inp_intTblCode        IN  VARCHAR2,
            inp_bankId            IN    VARCHAR2,
            out_intTblVersion    OUT VARCHAR2,
            out_basePcntCr        OUT VARCHAR2,
            out_basePcntDr        OUT VARCHAR2,
            out_foundFlg        OUT NUMBER
        );

    ----************************************************************
    --  *   PROCEDURE getIntVersionSlabAll                         *
    --  *    This Procedure returns the Interest Rate for a        *
    --  *       Version for the Balance Amt.                       *
    --  *    Returns all the 5 rates.                              *
    --  *        If no record is found for the Version Slab,        *
    --  *        then value of out_foundFlg is set to 1403          *
    --  *        Otherwise the value of out_foundFlg is set to 0    *
    ---*************************************************************
    PROCEDURE getIntVersionSlabAll (
                inp_crncyCode       IN      VARCHAR2,
                inp_intTblCode        IN        VARCHAR2,
                inp_intTblVersion    IN      VARCHAR2,
                inp_slabDrCrflg        IN      CHAR,
                inp_slabAmt            IN        VARCHAR2,
                inp_bankId            IN        VARCHAR2,
                out_normalRate        OUT     VARCHAR2,
                out_normalRateInd    OUT     VARCHAR2,
                out_penalRate        OUT     VARCHAR2,
                out_penalRateInd    OUT     VARCHAR2,
                out_cleanRate        OUT     VARCHAR2,
                out_cleanRateInd    OUT     VARCHAR2,
                out_choreRate        OUT     VARCHAR2,
                out_choreRateInd    OUT     VARCHAR2,
                out_qisRate            OUT     VARCHAR2,
                out_qisRateInd        OUT     VARCHAR2,
                out_beginSlabAmt    OUT         VARCHAR2,
                out_foundFlg        OUT     NUMBER
    );

    ----************************************************************
    --  *   PROCEDURE getIntVersionSlab                            *
    --  *    This Procedure returns the Interest Rate for a        *
    --  *       Version for the Balance Amt                        *
    --  *        If no record is found for the Version Slab,        *
    --  *        then value of out_foundFlg is set to 1403          *
    --  *        Otherwise the value of out_foundFlg is set to 0    *
    ---*************************************************************
    PROCEDURE getIntVersionSlab (
                inp_crncyCode        IN  VARCHAR2,
                inp_intTblCode        IN    VARCHAR2,
                inp_intTblVersion    IN  VARCHAR2,
                inp_slabDrCrflg        IN  CHAR,
                inp_slabAmt            IN    VARCHAR2,
                inp_rateType        IN  CHAR,
                inp_bankId            IN  VARCHAR2,
                out_intRate            OUT VARCHAR2,
                out_indType            OUT VARCHAR2,
                out_beginSlabAmt    OUT VARCHAR2,
                out_foundFlg        OUT NUMBER
            ) ;
    ----************************************************************
    --  *   PROCEDURE getIntVersionSlab                            *
    --  *    This Procedure returns the Interest Rate for a        *
    --  *       Version for the Balance Amt  for a TD A/c          *
    --  *        If no record is found for the Version Slab,        *
    --  *        then value of out_foundFlg is set to 1403          *
    --  *        Otherwise the value of out_foundFlg is set to 0    *
    ---*************************************************************

    PROCEDURE getTdIntVersionSlab (
                    inp_crncyCode                IN  VARCHAR2,
                    inp_intTblCode                IN    VARCHAR2,
                    inp_intTblVersion            IN  VARCHAR2,
                    inp_slabDrCrflg                IN  CHAR,
                    inp_slabAmt                    IN    VARCHAR2,
                    inp_rateType                IN     CHAR,
                    inp_deposit_period_mths        IN    VARCHAR2,
                    inp_deposit_period_days        IN    VARCHAR2,
                    inp_dep_period_in_days_only    IN    VARCHAR2,
                    inp_bankId                    IN    VARCHAR2,
                    out_intRate                 OUT    VARCHAR2,
                    out_indType                    OUT    VARCHAR2,
                    out_beginSlabAmt            OUT VARCHAR2,
                    out_foundFlg                OUT NUMBER
            );

    ----************************************************************
    --  *   PROCEDURE getLAIntVersionSlab                          *
    --  *    This Procedure returns the Interest Rate for a        *
    --  *       Version for the Balance Amt  for a LOAN A/c        *
    --  *           If no record is found for the Version Slab,    *
    --  *           then value of out_foundFlg is set to 1403      *
    --  *           Otherwise the value of out_foundFlg is set to 0*
    ---*************************************************************

    PROCEDURE getLAIntVersionSlab (
                    inp_crncyCode               IN  VARCHAR2,
                    inp_intTblCode              IN  VARCHAR2,
                    inp_intTblVersion           IN  VARCHAR2,
                    inp_slabDrCrflg             IN  CHAR,
                    inp_slabAmt                 IN  VARCHAR2,
                    inp_rateType                IN  CHAR,
                    inp_loan_period_mths        IN  VARCHAR2,
                    inp_loan_period_days        IN  VARCHAR2,
                    inp_bankId                  IN  VARCHAR2,
                    out_intRate                 OUT VARCHAR2,
                    out_indType                 OUT VARCHAR2,
                    out_beginSlabAmt            OUT VARCHAR2,
                    out_foundFlg                OUT NUMBER
            );

    ----************************************************************
    --  *   PROCEDURE getIntVersionSlabAll                         *
    --  *    This Procedure returns the Interest Rate for a        *
    --  *       Version for the Balance Amt  for a TD A/c          *
    --  *    Returns all the 3 rates.                              *
    --  *        If no record is found for the Version Slab,        *
    --  *        then value of out_foundFlg is set to 1403          *
    --  *        Otherwise the value of out_foundFlg is set to 0    *
    ---*************************************************************

    PROCEDURE getTdIntVersionSlabAll (
                    inp_crncyCode               IN  VARCHAR2,
                    inp_intTblCode                IN    VARCHAR2,
                    inp_intTblVersion            IN  VARCHAR2,
                    inp_slabDrCrflg                IN  CHAR,
                    inp_slabAmt                    IN    VARCHAR2,
                    inp_deposit_period_mths        IN    VARCHAR2,
                    inp_deposit_period_days        IN    VARCHAR2,
                    inp_dep_period_in_days_only    IN    VARCHAR2,
                    inp_bankId                    IN    VARCHAR2,
                    out_normalRate                 OUT    VARCHAR2,
                    out_penalRate                 OUT    VARCHAR2,
                    out_extnRate                 OUT    VARCHAR2,
                    out_indType                    OUT    VARCHAR2,
                    out_beginSlabAmt            OUT VARCHAR2,
                    out_foundFlg                OUT NUMBER
            );

    ----************************************************************
    --  *   PROCEDURE getLAIntVersionSlabAll                       *
    --  *    This Procedure returns the Interest Rate for a        *
    --  *       Version for the Balance Amt  for a TD A/c          *
    --  *    Returns all the 3 rates.                              *
    --  *           If no record is found for the Version Slab,    *
    --  *           then value of out_foundFlg is set to 1403      *
    --  *           Otherwise the value of out_foundFlg is set to 0*
    ---*************************************************************

    PROCEDURE getLAIntVersionSlabAll (
                    inp_crncyCode               IN  VARCHAR2,
                    inp_intTblCode              IN  VARCHAR2,
                    inp_intTblVersion           IN  VARCHAR2,
                    inp_slabDrCrflg             IN  CHAR,
                    inp_slabAmt                 IN  VARCHAR2,
                    inp_loan_period_mths        IN  VARCHAR2,
                    inp_loan_period_days        IN  VARCHAR2,
                    inp_bankId                  IN  VARCHAR2,
                    out_normalRate              OUT VARCHAR2,
                    out_penalRate               OUT VARCHAR2,
                    out_indType                 OUT VARCHAR2,
                    out_beginSlabAmt            OUT VARCHAR2,
                    out_foundFlg                OUT NUMBER
            );

    ----************************************************************
    --  *   PROCEDURE getIntRate                                   *
    --  *    This Procedure returns the Normal Interest Rate       *
    --  *         for an A/c as on a particular date, with respect *
    --  *         to change_upto_date                              *
    ---*************************************************************
    PROCEDURE getIntRate    (
                inp_asOnDate          IN  VARCHAR2,
                inp_acid            IN  VARCHAR2,
                inp_slabAmt            IN    VARCHAR2,
                inp_slabDrCrFlg        IN    CHAR,
                inp_rateType        IN  CHAR,
                inp_bankId            IN    VARCHAR2,
                out_intRate            OUT    VARCHAR2,
                out_indType            OUT VARCHAR2,
                out_beginSlabAmt    OUT VARCHAR2,
                out_foundFlg        OUT NUMBER
     );
    ----************************************************************
    --  *   PROCEDURE getEffectiveROI                             *
    --  *   This Procedure returns the effective rate of interest *
    --  *    considering BASE, DIFFERENTIAL and PREFERENTIALS      *
    ---*************************************************************
    PROCEDURE getEffectiveROI (
                inp_rateType        IN  CHAR,
                inp_slabDrCrFlg        IN    CHAR,
                inp_schemeType      IN VARCHAR2,
                inp_custCrPrefPcnt    IN VARCHAR2,
                inp_custDrPrefPcnt    IN VARCHAR2,
                inp_idCrPrefPcnt    IN VARCHAR2,
                inp_idDrPrefPcnt    IN VARCHAR2,
                inp_basePcntCr        IN VARCHAR2,
                inp_basePcntDr        IN VARCHAR2,
                inp_diffIntRate        IN VARCHAR2,
--*****************************************************
                inp_min_int_pcnt_cr IN VARCHAR2,
                inp_min_int_pcnt_dr IN VARCHAR2,
                inp_max_int_pcnt_cr IN VARCHAR2,
                inp_max_int_pcnt_dr IN VARCHAR2,
                inp_pegged_flg      IN CHAR,
--*****************************************************
                out_intRate            OUT    VARCHAR2
        );

end packInterest;
/
CREATE OR REPLACE PACKAGE BODY packInterest AS
--------------------------------------------------------------------------
    PROCEDURE getIntRate    (
            inp_asOnDate          IN VARCHAR2,
            inp_acid            IN  VARCHAR2,
            inp_slabAmt            IN    VARCHAR2,
            inp_slabDrCrFlg        IN    CHAR,
            inp_rateType        IN  CHAR,
            inp_bankId            IN  VARCHAR2,
            out_intRate            OUT    VARCHAR2,
            out_indType            OUT VARCHAR2,
            out_beginSlabAmt    OUT VARCHAR2,
            out_foundFlg        OUT NUMBER
        ) IS  -- {

    loc_asOnDate                VARCHAR2(19);
    loc_intTblCode                 ITC.int_tbl_code%TYPE;
    loc_intTblVersion             ICV.int_version%TYPE;
    loc_schmType                 GSP.schm_type%TYPE;
    loc_openDate                 VARCHAR2(19);
    loc_maturity_date             VARCHAR2(19);
    loc_foundFlg                 NUMBER;
    loc_beginSlabAmt            VARCHAR2(50);
    loc_deposit_period_mths    TAM.deposit_period_mths%TYPE;
    loc_deposit_period_days TAM.deposit_period_days%TYPE;
    loc_dep_period_in_days_only    VARCHAR2(50);
    loc_loan_period_mths    LAM.rep_perd_mths%TYPE;
    loc_loan_period_days    LAM.rep_perd_days%TYPE;
    loc_cust_cr_pref_pcnt        VARCHAR2(50);
    loc_cust_dr_pref_pcnt        VARCHAR2(50);
    loc_id_cr_pref_pcnt            VARCHAR2(50);
    loc_id_dr_pref_pcnt            VARCHAR2(50);
    loc_base_pcnt_cr            VARCHAR2(50);
    loc_base_pcnt_dr            VARCHAR2(50);
    loc_int_rate                VARCHAR2(50);
    loc_crncyCode                 GAM.acct_crncy_code%TYPE;
    --********************************************
    loc_min_int_pcnt_cr         VARCHAR2(50);
    loc_min_int_pcnt_dr         VARCHAR2(50);
    loc_max_int_pcnt_cr         VARCHAR2(50);
    loc_max_int_pcnt_dr         VARCHAR2(50);
    loc_pegged_flg              CHAR(1);
    --********************************************

    BEGIN    -- {
        -- dbms_output.put_line ('Entering getIntRate') ;

        --DBMS_OUTPUT.put_line (inp_acid);
        loc_asOnDate     :=     inp_asOnDate ;

        BEGIN -- {
            SELECT     GSP.schm_type
            INTO    loc_schmType
            FROM GSP, GAM
            WHERE     GSP.BANK_ID         = inp_bankId
            AND        GAM.BANK_ID            = inp_bankId
            AND        GAM.acid             = inp_acid
            AND        GSP.schm_code         = GAM.schm_code
            AND        NVL(GAM.del_flg,'N')        != 'Y'
            AND        GAM.entity_cre_flg     = 'Y' ;

        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                DBMS_OUTPUT.PUT_LINE ('NO DATA FOUND IN GSP / GAM');
                DBMS_OUTPUT.PUT_LINE ('acid is '|| inp_acid );

            WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE ('DATA ERROR IN GSP / GAM');
                DBMS_OUTPUT.PUT_LINE ('acid is '|| inp_acid);

        END; -- }

        IF (loc_schmType = 'TDA' or loc_schmType = 'TUA') THEN -- {
        BEGIN -- {
            DBMS_OUTPUT.PUT_LINE ('TD A/c . acid is '|| inp_acid);
            SELECT     TAM.deposit_period_mths,
                    TAM.deposit_period_days,
                    (to_date(TAM.maturity_date) - to_date(TAM.open_effective_date)),
                    TO_CHAR (TAM.open_effective_date, 'DD-MM-YYYY HH24:MI:SS'),
                    TO_CHAR (maturity_date, 'DD-MM-YYYY HH24:MI:SS')
            INTO    loc_deposit_period_mths,
                    loc_deposit_period_days,
                    loc_dep_period_in_days_only,
                    loc_asOnDate,
                    loc_maturity_date
            FROM
                TAM, GAM
            WHERE
                    TAM.BANK_ID = inp_bankId
                AND GAM.BANK_ID = inp_bankId
                AND TAM.acid = inp_acid
                AND GAM.acid = TAM.acid
                AND GAM.entity_cre_flg = 'Y'
                AND NVL(GAM.del_flg,'N') != 'Y';

        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                DBMS_OUTPUT.PUT_LINE ('NO DATA FOUND IN TAM');
                DBMS_OUTPUT.PUT_LINE ('acid is '||inp_acid);

            WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE ('DATA ERROR IN TAM');
                DBMS_OUTPUT.PUT_LINE ('acid is '|| inp_acid);

        END; -- }
        END IF; --   }

        IF (loc_schmType = 'LAA' or loc_schmType = 'CLA') THEN -- {
        BEGIN -- {
            DBMS_OUTPUT.PUT_LINE ('LAA/CLA A/c . acid is '|| inp_acid);
            SELECT  LAM.rep_perd_mths,
                    LAM.rep_perd_days
            INTO    loc_loan_period_mths,
                    loc_loan_period_days
            FROM    LAM, GAM
            WHERE   LAM.BANK_ID = inp_bankId
            AND     GAM.BANK_ID = inp_bankId
            AND     LAM.acid = inp_acid
            AND     GAM.acid = LAM.acid
            AND     GAM.entity_cre_flg = 'Y'
            AND     GAM.del_flg != 'Y';

        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                DBMS_OUTPUT.PUT_LINE ('NO DATA FOUND IN LAM');
                DBMS_OUTPUT.PUT_LINE ('acid is '||inp_acid);

            WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE ('DATA ERROR IN LAM');
                DBMS_OUTPUT.PUT_LINE ('acid is '|| inp_acid);

        END; -- }
        END IF; --   }

        -- This is added to get the currency code of the account
        -- so that, interest versions and corresponding slabs of
        -- the same currency can be selected.
        BEGIN -- {
            SELECT     acct_crncy_code
            INTO    loc_crncyCode
            FROM     GAM
            WHERE     GAM.BANK_ID         = inp_bankId
            AND        GAM.acid             = inp_acid
            AND        NVL(GAM.del_flg,'N')        != 'Y'
            AND        GAM.entity_cre_flg     = 'Y' ;

        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                DBMS_OUTPUT.PUT_LINE ('NO DATA FOUND IN GAM');
                DBMS_OUTPUT.PUT_LINE ('acid is '|| inp_acid );

            WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE ('DATA ERROR IN GAM');
                DBMS_OUTPUT.PUT_LINE ('acid is '|| inp_acid);

        END; -- }

        --DBMS_OUTPUT.put_line (loc_asOnDate);
        --DBMS_OUTPUT.put_line (inp_acid);
        packInterest.getIntTblCode (loc_asOnDate, '31-12-2099 00:00:00',
                                    inp_acid, inp_bankId, loc_intTblCode,
                                    loc_cust_cr_pref_pcnt,
                                    loc_cust_dr_pref_pcnt,
                                    loc_id_cr_pref_pcnt,
                                    loc_id_dr_pref_pcnt,
                                    loc_foundFlg,
                                    --**************************************
                                    loc_min_int_pcnt_cr ,
                                    loc_min_int_pcnt_dr ,
                                    loc_max_int_pcnt_cr ,
                                    loc_max_int_pcnt_dr ,
                                    loc_pegged_flg) ;
                                    --**************************************

        ----dbms_output.put_line ('FoundFlg from getIntTblCode :' || loc_foundFlg) ;
        IF (loc_foundFlg != 0) THEN
            out_foundFlg := loc_foundFlg;
            --dbms_output.put_line ('returning from getIntTblCode ') ;
            RETURN ;
        END IF;

        packInterest.getIntTblVersion (loc_crncyCode, loc_asOnDate,
                                       '31-12-2099 00:00:00',
                                       loc_intTblCode, inp_bankId, loc_intTblVersion,
                                       loc_base_pcnt_cr, loc_base_pcnt_dr,
                                       loc_foundFlg) ;

        IF (loc_foundFlg != 0) THEN
            out_foundFlg := loc_foundFlg;
            --dbms_output.put_line ('returning from getIntTblVersion') ;
            RETURN ;
        END IF;

        IF (loc_schmType = 'LAA' or loc_schmType = 'CLA') THEN -- {
        --  For Scheme type LAA OR CLA
        --  Getting interest rates from LAVS
        packInterest.getLAIntVersionSlab(loc_crncyCode,
                        loc_intTblCode, loc_intTblVersion,
                        inp_slabDrCrFlg, inp_slabAmt,
                        inp_rateType ,loc_loan_period_mths,
                        loc_loan_period_days,inp_bankId,
                        loc_int_rate, out_indType, out_beginSlabAmt, out_foundFlg ) ;

        ELSIF (loc_schmType = 'TDA' or loc_schmType = 'TUA') THEN -- {
        --  For Scheme type TDA
        --  Getting interest rates from TVS
            packInterest.getTdIntVersionSlab (loc_crncyCode,
                    loc_intTblCode, loc_intTblVersion,
                    inp_slabDrCrFlg, inp_slabAmt,
                    inp_rateType, loc_deposit_period_mths,
                    loc_deposit_period_days,
                    loc_dep_period_in_days_only,inp_bankId,
                    loc_int_rate, out_indType, out_beginSlabAmt, out_foundFlg ) ;
        ELSE -- {
        --  For all other scheme types than TDA
        --  Getting interest rates from IVS
            DBMS_OUTPUT.PUT_LINE ('Non -  TD A/c . acid is '|| inp_acid);
            packInterest.getIntVersionSlab (loc_crncyCode,
                    loc_intTblCode, loc_intTblVersion,
                    inp_slabDrCrFlg, inp_slabAmt, inp_rateType,
                    inp_bankId,loc_int_rate, out_indType,
                    out_beginSlabAmt, out_foundFlg ) ;

        END IF; --   } }

        -- To get the effective ROI for different rate types and
        -- different Dr Cr flag.
        packInterest.getEffectiveROI ( inp_rateType,
                                       inp_slabDrCrFlg,
                                       loc_schmType,
                                       loc_cust_cr_pref_pcnt,
                                       loc_cust_dr_pref_pcnt,
                                       loc_id_cr_pref_pcnt,
                                       loc_id_dr_pref_pcnt,
                                       loc_base_pcnt_cr,
                                       loc_base_pcnt_dr,
                                       loc_int_rate,
--*****************************************************
                                       loc_min_int_pcnt_cr,
                                       loc_min_int_pcnt_dr,
                                       loc_max_int_pcnt_cr,
                                       loc_max_int_pcnt_dr,
                                       loc_pegged_flg,
--*****************************************************
                                       out_intRate);
    -- DBMS_OUTPUT.put_line(loc_int_rate);
    -- DBMS_OUTPUT.put_line(loc_min_int_pcnt_cr);
    -- DBMS_OUTPUT.put_line(loc_min_int_pcnt_dr);
    -- DBMS_OUTPUT.put_line(loc_max_int_pcnt_cr);
    -- DBMS_OUTPUT.put_line(loc_max_int_pcnt_dr);
    -- DBMS_OUTPUT.put_line(loc_pegged_flg);
    -- DBMS_OUTPUT.put_line(out_intRate);

    RETURN ;

END getIntRate ; -- }

-- ***********************************************************
    PROCEDURE getIntTblCode(
            inp_asOnDate          IN OUT VARCHAR2,
            inp_changeUpToDate    IN    VARCHAR2,
            inp_acid            IN  VARCHAR2,
            inp_bankId            IN  VARCHAR2,
            out_intTblCode        OUT VARCHAR2,
            out_custCrPrefPcnt    OUT VARCHAR2,
            out_custDrPrefPcnt    OUT VARCHAR2,
            out_idCrPrefPcnt    OUT VARCHAR2,
            out_idDrPrefPcnt    OUT VARCHAR2,
            out_foundFlg        OUT NUMBER,
            --***************************************
            out_min_int_pcnt_cr OUT VARCHAR2,
            out_min_int_pcnt_dr OUT VARCHAR2,
            out_max_int_pcnt_cr OUT VARCHAR2,
            out_max_int_pcnt_dr OUT VARCHAR2,
            out_pegged_flg          OUT CHAR
            --***************************************

            ) IS  -- {

    loc_asOnDate        DATE ;
    loc_start_date        VARCHAR2(19);
    loc_pegged_flg         CHAR(1);
    loc_intTblCode         ITC.int_tbl_code%TYPE;
    loc_changeUpToDate     DATE ;
    loc_cust_cr_pref_pcnt        VARCHAR2(50);
    loc_cust_dr_pref_pcnt        VARCHAR2(50);
    loc_id_cr_pref_pcnt            VARCHAR2(50);
    loc_id_dr_pref_pcnt            VARCHAR2(50);
            --***************************************
    loc_min_int_pcnt_cr         VARCHAR2(50);
    loc_min_int_pcnt_dr         VARCHAR2(50);
    loc_max_int_pcnt_cr         VARCHAR2(50);
    loc_max_int_pcnt_dr         VARCHAR2(50);
            --***************************************

    BEGIN
--        dbms_output.put_line ('Entering Procedure getIntTblCode') ;
        loc_asOnDate     :=     TO_DATE (inp_asOnDate, 'DD-MM-YYYY HH24:MI:SS') ;
        loc_changeUpToDate     :=
                        TO_DATE (inp_changeUpToDate,'DD-MM-YYYY HH24:MI:SS');

--        dbms_output.put_line ('Before Select Statement') ;

        SELECT int_tbl_code, TO_CHAR(start_date, 'DD-MM-YYYY HH24:MI:SS'),
                            pegged_flg,
                            TO_CHAR(cust_cr_pref_pcnt),
                            TO_CHAR(cust_dr_pref_pcnt),
                            TO_CHAR(id_cr_pref_pcnt),
                            TO_CHAR(id_dr_pref_pcnt),
                            TO_CHAR(min_int_pcnt_cr),
                            TO_CHAR(min_int_pcnt_dr),
                            TO_CHAR(max_int_pcnt_cr),
                            TO_CHAR(max_int_pcnt_dr)
        INTO loc_intTblCode, loc_start_date, loc_pegged_flg,
                            loc_cust_cr_pref_pcnt,
                            loc_cust_dr_pref_pcnt,
                            loc_id_cr_pref_pcnt,
                            loc_id_dr_pref_pcnt,
                            loc_min_int_pcnt_cr,
                            loc_min_int_pcnt_dr,
                            loc_max_int_pcnt_cr,
                            loc_max_int_pcnt_dr
            FROM ITC a
            WHERE
                a.BANK_ID         = inp_bankId AND
                a.entity_id      = inp_acid AND
                a.entity_type        =   'ACCNT'   AND
                a.start_date        <=    loc_asOnDate AND
                a.end_date            >=    loc_asOnDate AND
                NVL(a.del_flg,'N')            !=    'Y' AND
                a.entity_cre_flg    =    'Y' AND
                a.lchg_time =
                    (SELECT max(lchg_time) from ITC b
                        WHERE
                            b.BANK_ID           =  inp_bankId AND
                            b.entity_id         =  inp_acid AND
                            b.entity_type       =   'ACCNT'   AND
                            NVL(b.del_flg,'N')            !=    'Y' AND
                            b.entity_cre_flg    =    'Y' AND
                            b.lchg_time            <=    loc_changeUpToDate AND
                            b.start_date        <=    loc_asOnDate AND
                            b.end_date            >=    loc_asOnDate )
                AND ROWNUM = 1    ;
-- More than one row should not be getting selected; but to be safe

        out_foundFlg := 0;
        out_intTblCode := loc_intTblCode ;
        out_custCrPrefPcnt := loc_cust_cr_pref_pcnt;
        out_custDrPrefPcnt := loc_cust_dr_pref_pcnt;
        out_idCrPrefPcnt := loc_id_cr_pref_pcnt;
        out_idDrPrefPcnt := loc_id_dr_pref_pcnt;
        --********************************************
        out_min_int_pcnt_cr := loc_min_int_pcnt_cr;
        out_min_int_pcnt_dr := loc_min_int_pcnt_dr;
        out_max_int_pcnt_cr := loc_max_int_pcnt_cr;
        out_max_int_pcnt_dr := loc_max_int_pcnt_dr;
        out_pegged_flg          := loc_pegged_flg;
        --********************************************
        -- For pegged accounts int version should be of peg start date
        IF (loc_pegged_flg = 'Y') THEN
            inp_asOnDate := loc_start_date;
          END IF;

        EXCEPTION WHEN NO_DATA_FOUND THEN
        BEGIN
            --dbms_output.put_line ('No ITC record found ') ;
            out_foundFlg := 1403 ;
            out_intTblCode := '';
        END ;
    END getIntTblCode; -- }

--   *********************************************************** --

    PROCEDURE getIntTblVersion (
            inp_crncyCode        IN  VARCHAR2,
            inp_asOnDate          IN  VARCHAR2,
            inp_changeUpToDate    IN  VARCHAR2,
            inp_intTblCode        IN  VARCHAR2,
            inp_bankId            IN  VARCHAR2,
            out_intTblVersion    OUT VARCHAR2,
            out_basePcntCr        OUT VARCHAR2,
            out_basePcntDr        OUT VARCHAR2,
            out_foundFlg        OUT NUMBER
        ) IS -- {

    loc_asOnDate        DATE ;
    loc_changeUpToDate    DATE ;
    loc_intTblVersion     ICV.int_version%TYPE;
    loc_base_pcnt_cr    VARCHAR2(50);
    loc_base_pcnt_dr    VARCHAR2(50);

    BEGIN
        loc_asOnDate     :=     TO_DATE (inp_asOnDate, 'DD-MM-YYYY HH24:MI:SS') ;
        loc_changeUpToDate :=
                    TO_DATE (inp_changeUpToDate, 'DD-MM-YYYY HH24:MI:SS') ;


        DECLARE CURSOR icvCur IS
        SELECT int_version, TO_CHAR(base_pcnt_cr), TO_CHAR(base_pcnt_dr)
            FROM ICV
            WHERE
                ICV.BANK_ID      =  inp_bankId AND
                NVL(del_flg,'N')            !=    'Y' AND
                entity_cre_flg    =    'Y' AND
                int_tbl_code    =    inp_intTblCode AND
                start_date      <=    loc_asOnDate AND
                end_date          >=    loc_asOnDate AND
                NVL(base_ind,'N')         !=  'Y' AND
                crncy_code         =     inp_crncyCode
            ORDER BY lchg_time desc, start_date desc;

        BEGIN
            OPEN icvCur;
        FETCH icvCur INTO loc_intTblVersion, loc_base_pcnt_cr, loc_base_pcnt_dr;
            CLOSE icvCur;
        END;
-- More than one row should not be getting selected; but to be safe

        out_foundFlg := 0;
        out_intTblVersion := loc_intTblVersion ;
        out_basePcntCr := loc_base_pcnt_cr ;
        out_basePcntDr := loc_base_pcnt_dr ;

        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                --dbms_output.put_line ('No ICV record found ') ;
                out_foundFlg := 1403 ;
                out_intTblVersion := '';

    END getIntTblVersion; -- }

--   *********************************************************** --

    PROCEDURE getIntVersionSlabAll (
                inp_crncyCode       IN      VARCHAR2,
                inp_intTblCode        IN        VARCHAR2,
                inp_intTblVersion    IN      VARCHAR2,
                inp_slabDrCrflg        IN      CHAR,
                inp_slabAmt            IN        VARCHAR2,
                inp_bankId          IN      VARCHAR2,
                out_normalRate        OUT     VARCHAR2,
                out_normalRateInd    OUT     VARCHAR2,
                out_penalRate        OUT     VARCHAR2,
                out_penalRateInd    OUT     VARCHAR2,
                out_cleanRate        OUT     VARCHAR2,
                out_cleanRateInd    OUT     VARCHAR2,
                out_choreRate        OUT     VARCHAR2,
                out_choreRateInd    OUT     VARCHAR2,
                out_qisRate            OUT     VARCHAR2,
                out_qisRateInd        OUT     VARCHAR2,
                out_beginSlabAmt    OUT         VARCHAR2,
                out_foundFlg        OUT     NUMBER
    ) IS  -- {

    loc_inpslabamt        NUMBER(20,4);
    BEGIN

        loc_inpslabamt :=  TO_NUMBER(inp_slabAmt);
        if (loc_inpslabamt < 0)
        then
            loc_inpslabamt := - loc_inpslabamt;
        end if;

        SELECT     nrml_portion_ind,     TO_CHAR(nrml_int_pcnt),
                penal_portion_ind,     TO_CHAR(penal_int_pcnt),
                clean_portion_ind,     TO_CHAR(clean_int_pcnt),
                chore_portion_ind,     TO_CHAR(chore_int_pcnt),
                qis_portion_ind,     TO_CHAR(qis_int_pcnt),
                formatAmount(begin_slab_amt, crncy_code,inp_bankId)
            INTO
                out_normalRateInd, out_normalRate,
                out_penalRateInd,    out_penalRate,
                out_cleanRateInd,    out_cleanRate,
                out_choreRateInd,    out_choreRate,
                out_qisRateInd,    out_qisRate,
                out_beginSlabAmt
            FROM IVS
            WHERE
                IVS.BANK_ID         =   inp_bankId     AND
                int_tbl_code        =    inp_intTblCode AND
                int_tbl_ver_num        =    inp_intTblVersion AND
                int_slab_dr_cr_flg    =    inp_slabDrCrFlg AND
                NVL(del_flg,'N')                !=    'Y' AND
                entity_cre_flg        =    'Y' AND
                crncy_code          =   inp_crncyCode AND
                begin_slab_amt        <=    loc_inpslabamt AND
                loc_inpslabamt        <=    end_slab_amt ;

        out_foundFlg := 0 ;

        EXCEPTION
            WHEN NO_DATA_FOUND THEN
        BEGIN
            --dbms_output.put_line ('No IVS record found ') ;
            out_foundFlg := 1403 ;
            out_beginSlabAmt := 0;
        END ;

    END getIntVersionSlabAll ; -- }
--------------------------------------------------------------------------------
    PROCEDURE getIntVersionSlab (
            inp_crncyCode        IN  VARCHAR2,
            inp_intTblCode        IN    VARCHAR2,
            inp_intTblVersion    IN  VARCHAR2,
            inp_slabDrCrFlg        IN  CHAR,
            inp_slabAmt            IN    VARCHAR2,
            inp_rateType        IN  CHAR,
            inp_bankId            IN  VARCHAR2,
            out_intRate            OUT VARCHAR2,
            out_indType            OUT VARCHAR2,
            out_beginSlabAmt    OUT VARCHAR2,
            out_foundFlg        OUT NUMBER
        ) IS -- {
    --------------------------------------------------------------
    -- Output variables are set according to value of inp_rateType
    --
    --  Valid Values for inp_rateType are
    --			'N'		for Normal rate
	--			'P'		for Penal rate
	--			'C'		for Clean rate
	--			'H'		for Chore rate
	--			'Q'		for Qis rate
	-------------------------------------------------------------
	loc_normalRate		VARCHAR2(50);
	loc_normalRateInd	VARCHAR2(1);
	loc_penalRate		VARCHAR2(50);
	loc_penalRateInd	VARCHAR2(1);
	loc_cleanRate		VARCHAR2(50);
	loc_cleanRateInd	VARCHAR2(1);
	loc_choreRate		VARCHAR2(50);
	loc_choreRateInd	VARCHAR2(1);
	loc_qisRate			VARCHAR2(50);
	loc_qisRateInd		VARCHAR2(1);
	loc_beginSlabAmt	VARCHAR2(50);
	loc_foundFlg       	NUMBER;

	BEGIN
    	getIntVersionSlabAll (
				inp_crncyCode,
				inp_intTblCode,
				inp_intTblVersion,
				inp_slabDrCrflg,
				inp_slabAmt,
				inp_bankId,
				loc_normalRate,
				loc_normalRateInd,
				loc_penalRate,
				loc_penalRateInd,
				loc_cleanRate,
				loc_cleanRateInd,
				loc_choreRate,
				loc_choreRateInd,
				loc_qisRate,
				loc_qisRateInd,
				loc_beginSlabAmt,
				loc_foundFlg);

		out_foundFlg := loc_foundFlg;

		IF (loc_foundFlg != 0) THEN
			RETURN;
		END IF;

		out_beginSlabAmt := loc_beginSlabAmt;

		IF inp_rateType = 'N' THEN
			out_intRate :=  loc_normalRate;
			out_indType :=  loc_normalRateInd;
		ELSIF inp_rateType = 'P' THEN
			out_intRate :=  loc_penalRate;
			out_indType :=  loc_penalRateInd;
		ELSIF inp_rateType = 'C' THEN
			out_intRate :=  loc_cleanRate;
			out_indType :=  loc_cleanRateInd;
		ELSIF inp_rateType = 'H' THEN
			out_intRate :=  loc_choreRate;
			out_indType :=  loc_choreRateInd;
		ELSIF inp_rateType = 'Q' THEN
			out_intRate :=  loc_qisRate;
			out_indType :=  loc_qisRateInd;
		END IF ;

END getIntVersionSlab ; -- }
-------------------------------------------------------------------------------

PROCEDURE getTdIntVersionSlabAll (
			inp_crncyCode       		IN  VARCHAR2,
			inp_intTblCode				IN	VARCHAR2,
			inp_intTblVersion			IN  VARCHAR2,
			inp_slabDrCrFlg				IN  CHAR,
			inp_slabAmt					IN	VARCHAR2,
			inp_deposit_period_mths		IN	VARCHAR2,
			inp_deposit_period_days		IN	VARCHAR2,
			inp_dep_period_in_days_only	IN	VARCHAR2,
			inp_bankId					IN	VARCHAR2,
			out_normalRate 				OUT	VARCHAR2,
			out_penalRate 				OUT	VARCHAR2,
			out_extnRate 				OUT	VARCHAR2,
			out_indType					OUT	VARCHAR2,
			out_beginSlabAmt			OUT VARCHAR2,
			out_foundFlg				OUT NUMBER
	) IS -- {

BEGIN

--		dbms_output.put_line ('Entering Procedure getTdIntVersionSlabAll') ;
		--dbms_output.put_line ('Balance is ' || inp_slabAmt) ;

		SELECT 	TO_CHAR(nrml_int_pcnt),
				TO_CHAR(penal_pcnt),
				TO_CHAR(extn_pcnt),
				formatAmount(begin_slab_amount, crncy_code,inp_bankId),
				slab_amount_ind
		INTO
				out_normalRate,
				out_penalRate,
				out_extnRate,
				out_beginSlabAmt,
				out_indType

		FROM TVS
		WHERE
				TVS.BANK_ID         =   inp_bankId     AND
				int_tbl_code		=	inp_intTblCode AND
				int_tbl_ver_num		=	inp_intTblVersion AND
				int_slab_dr_cr_flg	=	inp_slabDrCrFlg AND
				begin_slab_amount	<=	TO_NUMBER(inp_slabAmt) AND
				TO_NUMBER(inp_slabAmt)	<=	max_slab_amount AND

				((	MAX_CONTRACTED_MTHS != 0 AND
					(31 * MAX_CONTRACTED_MTHS + decode(max_contracted_days,999,30,max_contracted_days))
						>= (31 * inp_deposit_period_mths + inp_deposit_period_days) AND
					(31 * MAX_PERIOD_RUN_MTHS + decode(MAX_PERIOD_RUN_DAYS,999,30,MAX_PERIOD_RUN_DAYS))
						>= (31 * inp_deposit_period_mths + inp_deposit_period_days)
				)
				OR
				(	MAX_CONTRACTED_MTHS = 0 AND
					MAX_CONTRACTED_DAYS >= inp_dep_period_in_days_only AND
					(31 * MAX_PERIOD_RUN_MTHS + MAX_PERIOD_RUN_DAYS) >=
					(31 * inp_deposit_period_mths + inp_deposit_period_days)
				)) AND

				NVL(del_flg,'N')				!=	'Y' AND
				crncy_code      	=   inp_crncyCode AND
				entity_cre_flg		=	'Y'

				AND ROWNUM = 1;

		--dbms_output.put_line ('TVS record Found ') ;
		out_foundFlg := 0 ;

		EXCEPTION
			WHEN NO_DATA_FOUND THEN
			--dbms_output.put_line ('No TVS record found ') ;
			out_foundFlg := 1403 ;
			out_beginSlabAmt := 0;

END getTdIntVersionSlabAll; -- }
--------------------------------------------------------------------------------
PROCEDURE getLAIntVersionSlabAll (
            inp_crncyCode                   IN  VARCHAR2,
            inp_intTblCode                  IN  VARCHAR2,
            inp_intTblVersion               IN  VARCHAR2,
            inp_slabDrCrFlg                 IN  CHAR,
            inp_slabAmt                     IN  VARCHAR2,
            inp_loan_period_mths            IN  VARCHAR2,
            inp_loan_period_days            IN  VARCHAR2,
            inp_bankId                      IN  VARCHAR2,
            out_normalRate                  OUT VARCHAR2,
            out_penalRate                   OUT VARCHAR2,
            out_indType                     OUT VARCHAR2,
            out_beginSlabAmt                OUT VARCHAR2,
            out_foundFlg                    OUT NUMBER
    ) IS -- {
BEGIN
    --dbms_output.put_line ('Entering Procedure getLAIntVersionSlabAll') ;
    --dbms_output.put_line ('Balance is ' || inp_slabAmt) ;

    SELECT  TO_CHAR(nrml_int_pcnt),
            TO_CHAR(penal_int_pcnt),
            formatAmount(begin_slab_amount, crncy_code,inp_bankId),
            loan_tenor_ind
    INTO
            out_normalRate,
            out_penalRate,
            out_beginSlabAmt,
            out_indType
    FROM LAVS
    WHERE
            LAVS.BANK_ID            =       inp_bankId     AND
            int_tbl_code            =       inp_intTblCode AND
            int_tbl_ver_num         =       inp_intTblVersion AND
            int_slab_dr_cr_flg      =       inp_slabDrCrFlg AND
            (loan_tenor_mths   != 0 AND
                (31 * loan_tenor_mths + decode(loan_tenor_days,999,30,loan_tenor_days))
                    >= (31 * inp_loan_period_mths + inp_loan_period_days)
            ) AND
            begin_slab_amount       <=      TO_NUMBER(inp_slabAmt) AND
            TO_NUMBER(inp_slabAmt)  <=      end_slab_amount AND
            del_flg                 !=      'Y' AND
            crncy_code              =       inp_crncyCode AND
            entity_cre_flg          =       'Y' AND
            ROWNUM = 1;

    --dbms_output.put_line ('LAVS record Found ') ;
    out_foundFlg := 0 ;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
        --dbms_output.put_line ('No LAVS record found ') ;
        out_foundFlg := 1403 ;
        out_beginSlabAmt := 0;

END getLAIntVersionSlabAll; -- }
-------------------------------------------------------------------------------
PROCEDURE getTdIntVersionSlab (
		inp_crncyCode       		IN  VARCHAR2,
		inp_intTblCode				IN	VARCHAR2,
		inp_intTblVersion			IN  VARCHAR2,
		inp_slabDrCrflg				IN  CHAR,
		inp_slabAmt					IN	VARCHAR2,
		inp_rateType				IN 	CHAR,
		inp_deposit_period_mths		IN	VARCHAR2,
		inp_deposit_period_days		IN	VARCHAR2,
		inp_dep_period_in_days_only	IN	VARCHAR2,
		inp_bankId					IN  VARCHAR2,
		out_intRate 				OUT	VARCHAR2,
		out_indType					OUT	VARCHAR2,
		out_beginSlabAmt			OUT VARCHAR2,
		out_foundFlg				OUT NUMBER
	) IS -- {

	loc_normalRate		VARCHAR2(50);
	loc_penalRate		VARCHAR2(50);
	loc_extnRate		VARCHAR2(50);
	loc_indtype			VARCHAR2(1);
	loc_beginSlabAmt	VARCHAR2(50);
	loc_foundFlg		NUMBER;

BEGIN
	getTdIntVersionSlabAll (
			inp_crncyCode,
			inp_intTblCode,
			inp_intTblVersion,
			inp_slabDrCrflg,
			inp_slabAmt,
			inp_deposit_period_mths,
			inp_deposit_period_days,
			inp_dep_period_in_days_only,
            inp_bankId,
			loc_normalRate,
			loc_penalRate,
			loc_extnRate,
			loc_indType,
			loc_beginSlabAmt,
			loc_foundFlg );

		out_foundFlg := loc_foundFlg;

		IF (loc_foundFlg != 0) THEN
			RETURN;
		END IF;

		out_beginSlabAmt := loc_beginSlabAmt;
		out_indType :=  loc_indType;

		IF inp_rateType = 'N' THEN
			out_intRate :=  loc_normalRate;
		ELSIF inp_rateType = 'P' THEN
			out_intRate :=  loc_penalRate;
		ELSIF inp_rateType = 'C' THEN
			out_intRate :=  loc_extnRate;
		END IF ;

END getTdIntVersionSlab; -- }
--------------------------------------------------------------------------------
PROCEDURE getLAIntVersionSlab (
        inp_crncyCode                   IN  VARCHAR2,
        inp_intTblCode                  IN  VARCHAR2,
        inp_intTblVersion               IN  VARCHAR2,
        inp_slabDrCrflg                 IN  CHAR,
        inp_slabAmt                     IN  VARCHAR2,
        inp_rateType                    IN  CHAR,
        inp_loan_period_mths            IN  VARCHAR2,
        inp_loan_period_days            IN  VARCHAR2,
        inp_bankId                      IN  VARCHAR2,
        out_intRate                     OUT VARCHAR2,
        out_indType                     OUT VARCHAR2,
        out_beginSlabAmt                OUT VARCHAR2,
        out_foundFlg                    OUT NUMBER
    ) IS -- {

    loc_normalRate          VARCHAR2(50);
    loc_penalRate           VARCHAR2(50);
    loc_indtype             VARCHAR2(1);
    loc_beginSlabAmt        VARCHAR2(50);
    loc_foundFlg            NUMBER;

BEGIN
    getLAIntVersionSlabAll (
                inp_crncyCode,
                inp_intTblCode,
                inp_intTblVersion,
                inp_slabDrCrflg,
                inp_slabAmt,
                inp_loan_period_mths,
                inp_loan_period_days,
                inp_bankId,
                loc_normalRate,
                loc_penalRate,
                loc_indType,
                loc_beginSlabAmt,
                loc_foundFlg );

    out_foundFlg := loc_foundFlg;

    IF (loc_foundFlg != 0) THEN
        RETURN;
    END IF;

    out_beginSlabAmt := loc_beginSlabAmt;
    out_indType :=  loc_indType;

    IF inp_rateType = 'N' THEN
        out_intRate :=  loc_normalRate;
    ELSIF inp_rateType = 'P' THEN
        out_intRate :=  loc_penalRate;
    END IF ;

END getLAIntVersionSlab; -- }
--------------------------------------------------------------------------------
    PROCEDURE getEffectiveROI (
				inp_rateType		IN  CHAR,
				inp_slabDrCrFlg		IN	CHAR,
				inp_schemeType      IN VARCHAR2,
				inp_custCrPrefPcnt	IN VARCHAR2,
				inp_custDrPrefPcnt	IN VARCHAR2,
				inp_idCrPrefPcnt	IN VARCHAR2,
				inp_idDrPrefPcnt	IN VARCHAR2,
				inp_basePcntCr		IN VARCHAR2,
				inp_basePcntDr		IN VARCHAR2,
				inp_diffIntRate		IN VARCHAR2,
--*****************************************************
				inp_min_int_pcnt_cr IN VARCHAR2,
                inp_min_int_pcnt_dr IN VARCHAR2,
                inp_max_int_pcnt_cr IN VARCHAR2,
                inp_max_int_pcnt_dr IN VARCHAR2,
                inp_pegged_flg      IN CHAR,
--*****************************************************
				out_intRate			OUT	VARCHAR2
	) IS -- {

	BEGIN
		-- For TD accounts, for all the three types NORMAL, PENAL and
		-- EXTENSION, preferentials will be considered.
		IF (inp_schemeType = 'TDA' or inp_schemeType = 'TUA') THEN
			out_intRate :=  TO_CHAR(TO_NUMBER(inp_basePcntCr)+
									TO_NUMBER(inp_diffIntRate)+
									TO_NUMBER(inp_custCrPrefPcnt)+
									TO_NUMBER(inp_idCrPrefPcnt)) ;
			--*************************************************
            IF (inp_pegged_flg = 'N' AND inp_rateType = 'N') THEN
			IF ((TO_NUMBER(inp_max_int_pcnt_cr) != 0) AND (TO_NUMBER(out_intRate) > TO_NUMBER(inp_max_int_pcnt_cr))) THEN
                    out_intRate := inp_max_int_pcnt_cr;
			ELSIF ((TO_NUMBER(inp_min_int_pcnt_cr) != 0) AND (TO_NUMBER(out_intRate) < TO_NUMBER(inp_min_int_pcnt_cr))) THEN
                    out_intRate := inp_min_int_pcnt_cr;
                END IF ;
            END IF;
            --*************************************************
		ELSE
			IF (inp_rateType = 'N') THEN
				IF(inp_slabDrCrFlg = 'C')THEN
					out_intRate :=  TO_CHAR(TO_NUMBER(inp_basePcntCr)+
											TO_NUMBER(inp_diffIntRate)+
											TO_NUMBER(inp_custCrPrefPcnt)+
											TO_NUMBER(inp_idCrPrefPcnt)) ;
			 --*************************************************
                    IF (inp_pegged_flg = 'N') THEN
						IF ((TO_NUMBER(inp_max_int_pcnt_cr) != 0) AND (TO_NUMBER(out_intRate) > TO_NUMBER(inp_max_int_pcnt_cr))) THEN
                            out_intRate := inp_max_int_pcnt_cr;
					ELSIF ((TO_NUMBER(inp_min_int_pcnt_cr) != 0) AND (TO_NUMBER(out_intRate) < TO_NUMBER(inp_min_int_pcnt_cr))) THEN
                            out_intRate := inp_min_int_pcnt_cr;
                        END IF ;
                    END IF ;
            --************************************************
				ELSIF(inp_slabDrCrFlg = 'D') THEN
					out_intRate :=  TO_CHAR(TO_NUMBER(inp_basePcntDr)+
											TO_NUMBER(inp_diffIntRate)+
											TO_NUMBER(inp_custDrPrefPcnt)+
											TO_NUMBER(inp_idDrPrefPcnt)) ;
            --************************************************
				 IF (inp_pegged_flg = 'N') THEN
					IF ((TO_NUMBER(inp_max_int_pcnt_dr) != 0)) AND (TO_NUMBER(out_intRate) > TO_NUMBER(inp_max_int_pcnt_dr)) THEN
                            out_intRate := inp_max_int_pcnt_dr;
					ELSIF ((TO_NUMBER(inp_min_int_pcnt_dr) != 0) AND (TO_NUMBER(out_intRate) < TO_NUMBER(inp_min_int_pcnt_dr))) THEN
                            out_intRate := inp_min_int_pcnt_dr;
                        END IF ;
                    END IF ;
            --************************************************
				END IF ;

			ELSE
				IF(inp_slabDrCrFlg = 'C')THEN
					out_intRate :=  TO_CHAR(TO_NUMBER(inp_basePcntCr)+
										TO_NUMBER(inp_diffIntRate));
				ELSIF(inp_slabDrCrFlg = 'D') THEN
					out_intRate :=  TO_CHAR(TO_NUMBER(inp_basePcntDr)+
										TO_NUMBER(inp_diffIntRate));
				END IF ;
			END IF ;
		END IF ;

	END getEffectiveROI; -- }
END packInterest;
/
