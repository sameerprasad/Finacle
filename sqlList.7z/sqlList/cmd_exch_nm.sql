set head off echo off trims on feed off verify off pages 0
spool cmd_&1.
select EXCHANGE_NAME from cmd_exch_master where EXCHANGE_CODE='&1';
spool off
