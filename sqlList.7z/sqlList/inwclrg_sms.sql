--------------------------------------------------------------------------------------------------#
--Source Name           :inwclrg_sms.sql
--Description           :gets called called from hmicz_clgVal1.com 
--Author                : 
-- S.No          Date            Author                 Description
--  1.0         05-04-2013    Ganesh Sawant(ICI)      CR-138-29100:SMS alert to be sent to customers on
--                                                  firing of validation through MICZ option 
-------------------------------------------------------------------------------------------------#

set serveroutput on size 1000000
set lines 152 pages 0 feedback off trim off echo off verify off termout off
alter session set cursor_sharing = 'EXACT';  
spool &4
declare
-- V_SEGEMENT icici_cust_seg.segement%type;
V_SEGEMENT CMG.SEGMENTATION_CLASS%type;
V_MODEID icici_alert_reg.mode_id%type;

cursor seldata is
select b.cust_id,foracid,CUST_COMU_PHONE_NUM_1,acct_crncy_code,a.acid acid,INST_NUM,INST_TYPE,INST_DATE,INST_AMT,b.sol_id,
cust_stat_code,cust_const,schm_type,zone_code,zone_date
from ici a, gam b,cmg c where a.acid = b.acid 
and schm_type='SBA' 
And b.cust_id = c.cust_id
and  zone_code='&1' and to_char(zone_date,'DDMMYYYY')='&2' and a.sol_id = '&3';
begin
for rec in seldata
loop
	begin
	--       select SEGEMENT into V_SEGEMENT from icici_cust_seg where cust_id =lpad(rec.cust_id, 9); 
		 select SEGMENTATION_CLASS into V_SEGEMENT from cmg where cust_id =lpad(rec.cust_id, 9);
		exception when no_data_found then
			V_SEGEMENT :='XX';
	end;
	if (V_SEGEMENT !='XX') then
		begin
			select mode_id into V_MODEID from icici_alert_reg where foracid = rec.foracid and MODE_OF_DELIVERY = '0'
			and RCRE_TIME = (   SELECT  MAX(RCRE_TIME) FROM    ICICI_ALERT_REG where foracid = rec.foracid
			AND     MODE_OF_DELIVERY = '0' AND     DEL_FLG = 'N') AND     DEL_FLG = 'N' AND     ROWNUM < 2;
			exception when no_data_found then
			 V_MODEID := '9999ZZZZ';
		end;
		if ( V_MODEID !='9999ZZZZ') then
		dbms_output.put_line(rec.foracid||'|'||rec.acct_crncy_code||'|'||rec.acid||'|'||rec.INST_NUM||'|'||rec.INST_TYPE||'|'||rec.INST_DATE||'|'||ltrim(to_char(rec.inst_amt,'9999999999990.09'))||'|'||rec.sol_id||'|'||rec.cust_stat_code||'|'||rec.cust_stat_code||'|'||rec.cust_const||'|'||rec.cust_const||'|'||rec.CUST_COMU_PHONE_NUM_1||'|'||V_MODEID||'|'||V_SEGEMENT||'|'||rec.schm_type||'|'||rec.zone_code||'|'||rec.zone_date);
		end if;
	end if;
end loop;
end;
/
spool off
