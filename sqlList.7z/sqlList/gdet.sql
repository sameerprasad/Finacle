-- GDET Details- Accounts 
-- Opened Accounts And Matured Accounts Between given date range
-- For given cust id for given period
-- Output file spooled in the same directory
-- Tables   : GAM, CMG, TAM
-- Module   : GBO
-- Author   : GowriSankarKK On 28-09-2004
-- Request  : Anindya
-- Modified Version of gdet_mtnl.sql

set echo off termout off verify off feedback off trims off lines 132 pages 0 
set serveroutput on size 1000000

HOST umask 000; 

spool gdet

DECLARE
d_int_rate number;

CURSOR det_cur IS
select gam.foracid,
       gam.acid,
	   cmg.cust_name,
	   open_effective_date,
	   (clr_bal_amt+un_clr_bal_amt) balance,
	   deposit_period_mths,
	   deposit_period_days,
	   maturity_date,
	   maturity_amount,
	   original_maturity_amount,
	   original_deposit_amount,
	   deposit_amount
  from gam,cmg,tam
 where gam.acid=tam.acid
   and gam.cust_id=lpad(trim('&&1'),9,' ')
   and gam.cust_id=cmg.cust_id
and ((tam.open_effective_date between to_date('&2','dd-mm-yyyy') and to_date('&3','dd-mm-yyyy')) OR (maturity_date between to_date('&2','dd-mm-yyyy') and to_date('&3','dd-mm-yyyy')))
   and gam.entity_cre_flg ='Y'
   and gam.del_flg <> 'Y'
   and cmg.entity_cre_flg ='Y'
   and cmg.del_flg <> 'Y'
   and gam.bank_id='&4' and cmg.bank_id='&4' and tam.bank_id='&4'
 order by open_effective_date;

BEGIN

FOR D in det_cur
LOOP

    BEGIN
    select  int_pcnt
    into    d_int_rate
    from    tdt
    where   acid = D.acid
    and     flow_code in ('II','IO')
    and     srl_num =(select max(srl_num) 
                        from tdt 
                       where acid=D.acid 
                         and flow_code in ('II','IO') 
			 and bank_id='&4'
                         and int_pcnt<>0);
    exception
    when    no_data_found then
    d_int_rate := NULL;
    END;

    dbms_output.put_line( D.foracid             ||'|'||
				  		  D.cust_name           ||'|'||
		  				  D.open_effective_date ||'|'||
		  				  D.balance             ||'|'||
		  				  D.deposit_period_mths ||'|'||
		  				  D.deposit_period_days ||'|'||
		  				  d_int_rate            ||'|'||
		  				  D.maturity_date       ||'|'||
		  				  D.maturity_amount     ||'|'||
		  				  D.deposit_amount );
END LOOP;
END;
/
spool off
