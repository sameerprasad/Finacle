set serveroutput on size 1000000
set verify   off
set termout   off
set head off
set pages 0
set trims on
set feedback off
set echo off
set linesize 250
spool anyPend

DECLARE
CURSOR curStatus IS
SELECT  req_id, to_char(REQ_TIME,'DD-MM-YYYY') reqtime,
        REMOTE_FORACID, LOCAL_FORACID, AMOUNT, CHEQUE_NO,
        USERID, substr(REMARK,1,15) remark, decode(REC_STATUS,'A','E','V') status
FROM    ICI_ANY_TRAN_DETAIL
WHERE    USERID in (select user_id  from upr where sol_id='&2' and del_flg <>'Y' and virtual_flg<>'Y')
-- substr(LOCAL_FORACID,1,4) = '&2'
AND     to_char(REQ_TIME,'DD-MM-YYYY') = '&1'
AND     REC_STATUS in ('A','V')
ORDER 	by req_id,REC_STATUS;

BEGIN
	FOR statRec in curStatus
	LOOP
		EXIT WHEN curStatus%NOTFOUND;
		BEGIN
			dbms_output.put_line(statRec.req_id ||'|'|| statRec.reqtime ||'|'|| 
			statRec.REMOTE_FORACID ||'|'|| statRec.LOCAL_FORACID ||'|'|| statRec.AMOUNT ||'|'|| 
			statRec.CHEQUE_NO ||'|'|| statRec.USERID ||'|'|| statRec.remark ||'|'|| statRec.status);
		END;
	END LOOP;

EXCEPTION
	when others then
		dbms_output.put_line('No record found||||||||');
END;
/
spool off
