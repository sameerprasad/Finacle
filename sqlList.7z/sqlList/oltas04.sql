set serveroutput on size 1000000
set feedback off
set verify off
set linesize 500
set pages 0
set trims on
set termout off
set numformat 999D09
spool &2
select   distinct '04^639'||'^'||substr(b.BSR_CODE,length(b.bsr_code)-3,4)||'^'||a.MAJOR_TAX_HEAD||'^^'||lpad(count(a.cin_no),5,'0')||'^^^^'||lpad(SUM(a.challan_amount),14,'0')||'^'||'023'||'^'||to_char(a.payout_dt,'ddmmyy')||'^'
from ici_gbm_challan_master a,ici_gbm_bsrcode b
where a.payout_dt='&1' and b.sol_id in (select distinct parent_sol_id from ici_gbm_nodal_master where scheme_code='0004' and sol_id in (select distinct parent_sol_id from ici_gbm_terminal_master where scheme_code='0004' and sol_id=a.sol_id)) and a.MAJOR_TAX_HEAD in (select tax_head from ICI_GBM_MAJOR_HEAD where TAX_SCHEME='0004') and a.del_flg='N' and a.entity_creation_flg='Y' and b.BSR_CODE != '6390005'
group by b.BSR_CODE,a.MAJOR_TAX_HEAD,a.payout_dt
/
spool off
/
