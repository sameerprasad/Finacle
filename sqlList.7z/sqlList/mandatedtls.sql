Rem ScriptName: mandatedtls.sql
Rem SQL called from ICIRSQLS to display details of mandate details for particular date
Rem Author : Soundaram - ICI6150
-- Modification : Tejinder Jain - 14/11/2012 - Added Bank Id
set serveroutput on size 1000000
set feedback off
set verify off
set linesize 500
set trims on
set termout off

spool mandatedtls

declare

   date1 icici_mandate_holder.lchg_time%type;

   cursor mandate is
          select imh.FORACID_NRI,
                 g.CIF_ID,
                 g.ACCT_NAME,
                 imh.CIF_ID_MANDATE_HOLDER,
                 c.CUST_NAME,
                 imh.RCRE_USER,
                 imh.RCRE_TIME,
                 imh.MANDATE_TYPE,
                 cift.EMAIL_ID
          from  icici_mandate_holder imh,gam g,tbaadm.cmg c,icici_cift cift
          where to_char(imh.lchg_time)= to_date('&1','dd-mm-yyyy') and
                imh.foracid_nri=g.foracid and
                imh.cif_id_mandate_holder=c.cif_id and
                g.cif_id=cift.cif_id and
                g.bank_id=c.bank_id and
                cift.bank_id=g.bank_id and
                g.bank_id ='&2'; 

begin


     for i in mandate
     loop


       dbms_output.put_line(i.FORACID_NRI||'|'||i.CIF_ID||'|'||i.ACCT_NAME||'|'||i.CIF_ID_MANDATE_HOLDER||'|'||
                            i.CUST_NAME||'|'||i.RCRE_USER||'|'||i.RCRE_TIME||'|'||i.MANDATE_TYPE||'|'||
                            i.EMAIL_ID);
     end loop;
end;
/
spool off
set feedback on
set verify on
