--Annesh S: 03-01-2013 Removed LPAD from custId
--Aneesh S: 10-01-2013 Table name corrected
set head off
set trims on
set pages 0
set feedback off
set verify off
set termout off
spool Flush.log

SELECT 'Flushing the PSP_TMP table ...' FROM DUAL;

DELETE	tbaadm.PSP_TMP
WHERE	listid LIKE '&1'||'%'  and bank_id ='&7';

UPDATE	ICICI_LDTT
SET	remarks = 'F'
WHERE	dc_alias = (select dc_alias from gct where bank_id ='&7')
AND	driver_id = 'FSG'
AND	sol_id = substr('&1', 4, 4)
AND	ser_num = substr('&1', 9, 1);

INSERT INTO ICI_STMT_LOG values ('&2','&3','&4','&5','&6',sysdate,'&7');

COMMIT;

spool off
