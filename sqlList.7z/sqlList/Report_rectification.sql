----------------------------------------------------------------------------------------------------
--   Source Name            : Report_rectification.sql 
--   Description            : Rectification Entries Passed report .
--   Input Values           : None
--   Output Values          : None
--   Called Script          : N.A
--   Calling Script         : N.A
--   Modification History:
--   Sl No.         Date              Author                     Description
--   --------------------------------------------------------------------------------------
--     01         10-Oct-2012         Priyanka                 Original Version
----------------------------------------------------------------------------------------------------

set serveroutput on size 1000000
set head off
set pau off
set echo off
set lines 250
set pages 0
set termout off
set verify off
set feedback off
spool Report_rectification.lst 

DECLARE

	v_solid            	wlckm.sol_id%type :='&1';
	v_frmdt			varchar2(25)      := '&2';
	v_todt			varchar2(25)      := '&3';
	v_bankid		clmt.bank_id%type := '&4';
	v_RACK_ID          	wlckm.RACK_ID%type;
	v_LOCKER_NUM       	clnd.LOCKER_NUM%type;
	v_locker_type           wlckm.locker_type%type;	
	v_REV_TRAN_ID           clrt.REV_TRAN_ID%type;
	v_REV_TRAN_DATE         clrt.REV_TRAN_DATE%type;
	v_cif_id                clmt.cif_id%type;
	v_tran_amt 	 	dctd_acli.tran_amt%type;
	v_part_tran_type 	dctd_acli.part_tran_type%type;
	v_entry_user_id  	dctd_acli.entry_user_id%type;
	v_TRAN_RMKS1     	dctd_acli.TRAN_RMKS%type;
	v_VFD_USER_ID    	dctd_acli.VFD_USER_ID%type;
	v_TRAN_RMKS2     	dctd_acli.TRAN_RMKS%type;
	v_PSTD_DATE      	dctd_acli.PSTD_DATE%type;

 
cursor c1(v_solid varchar2,v_frmdt varchar2,v_todt varchar2,v_bankid varchar2) is 
select
        clrt.REV_TRAN_DATE RevTranDate,
        clrt.cif_id CifId,
        clrt.locker_num LockNum,
        wlckm.rack_id RackId,
        wlckm.locker_type LockType,
        clrt.REV_TRAN_ID RevTranId
from clrt,wlckm,clmt
where clrt.LOCKER_NUM = wlckm.LOCKER_NUM
and clmt.locker_num = clrt.locker_num
and clrt.sol_id = wlckm.sol_id
and clrt.cif_id = clmt.cif_id
and clrt.sol_id = v_solid
and clrt.bank_id = wlckm.bank_id
and wlckm.bank_id = clmt.bank_id
and clmt.bank_id = v_bankid
and clrt.ENTITY_CRE_FLG = 'Y'
and clrt.REV_TRAN_DATE between to_date(v_frmdt,'dd-mm-yyyy') and to_date(v_todt,'dd-mm-yyyy')
and clrt.del_flg !='Y'
and clmt.del_flg!='Y'
and wlckm.del_flg!='Y'
order by 1,6,3; 

cursor c2(v_solid varchar2,v_REV_TRAN_ID varchar2,v_REV_TRAN_DATE varchar2,v_bankid varchar2) is
select  tran_amt TranAmt,
        part_tran_type PartTranType,
        entry_user_id EntryUserId,
        TRAN_RMKS TranRmks1,
        VFD_USER_ID VfdUserId,
        TRAN_RMKS TranRmks2,
        PSTD_DATE PstdDate
from    dctd_acli
where   tran_id = lpad(v_REV_TRAN_ID,9,' ')
and     tran_DATE = to_date (v_REV_TRAN_DATE,'DD-MM-YYYY')
and     dctd_acli.sol_id = v_solid
and     dctd_acli.bank_id = v_bankid
and    del_flg!='Y';
      
BEGIN
    for i in c1(v_solid,v_frmdt,v_todt,v_bankid)
    LOOP
	--dbms_output.put_line (v_solid);
	--dbms_output.put_line (i.RevTranId);
	--dbms_output.put_line (i.RevTranDate);
	--dbms_output.put_line (v_bankid);
        for j in c2(v_solid,i.RevTranId,i.RevTranDate,v_bankid)
        LOOP
        dbms_output.enable(buffer_size => NULL);
        dbms_output.put_line (
                                        i.RevTranDate      ||'|'||
                                        i.CifId             ||'|'||
                                        i.LockNum         ||'|'||
                                        i.RackId            ||'|'||
                                        i.LockType        ||'|'||
                                        i.RevTranId        ||'|'||
                                        j.TranAmt            ||'|'||
                                        j.PartTranType     ||'|'||
                                        j.EntryUserId      ||'|'||
                                        j.TranRmks1         ||'|'||
                                        j.VfdUserId        ||'|'||
                                        j.TranRmks2         ||'|'||
                                        j.PstdDate
                                );
        END LOOP;
    end loop;
END;                   
/
spool off

