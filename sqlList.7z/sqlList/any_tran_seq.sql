-- Sequence creation code for ANYTAN menu written by Lavanya Ramachandran 

drop sequence icici.seq_any_tranid;
--drop synonym icici.tba_seq_any_tranid;
--drop synonym tbagen.tba_seq_any_tranid;
create sequence icici.seq_any_tranid
start with 1
minvalue 1 maxvalue 9999999 nocycle nocache;
grant select on icici.seq_any_tranid to tbaadm,tbagen,tbautil;

