###############################################################################
# Source Name                   : cre_oth_eba_tbl.sql
# Author                        :
# Version                       : 1.0
# Called by                     :
# Date                          : 21-06-2013
#   Modification History
#   <Srl. No>     <Date>         <Author>          <Description>
#    1.1        23-08-2012    Kumar Vishal      Coding Standard Changes
#    1.2        21-06-2013    Priyanka Garg     Modified version
###################################################################################
declare
   v_count number;
   v_bankId VARCHAR2(9) := '&1';
 begin
 loop
 delete from OTH_EBA_ALT_TBL where bank_id = v_bankId and rownum <= 300;
 SELECT count(*) INTO v_count from OTH_EBA_ALT_TBL where bank_id = v_bankId;
exit when v_count = 0;
end loop;  
   INSERT INTO OTH_EBA_ALT_TBL SELECT * from alt where bank_id = v_bankId;
commit;
 end;
/

