set feedback off
set verify off
set echo off
set pages 60
set lines 500
set head off
set trims on
spool prtFundDeposits.lst
--Naweed : TOL 346759 - Aligned the header and the data
select 'SolId   			   Acct Id		 	                                  User Id			 	                     A/c Open Date      Deposit Amt    Funded Amt     Funded Status       Verified status' from dual
/
select gam.sol_id, foracid ,gam.rcre_user_id,gam.rcre_time,
tam.deposit_amount,gam.clr_bal_amt,decode(gam.clr_bal_amt,0,'           Zero Funded','           Part Funded')
, decode(gam.entity_cre_flg,'Y','         Verified','         Not - Verified') from TAM,GAM
where tam.acid = gam.acid 
and tam.sol_id=gam.sol_id
and gam.clr_bal_amt < tam.deposit_amount 
and gam.sol_id = '&1' 
and gam.acct_cls_flg != 'Y' 
and gam.schm_type = 'TDA' 
and gam.acct_opn_date = (select db_stat_date from gct)
/
spool off
