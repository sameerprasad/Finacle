set serveroutput on size 1000000
set feedback off
set verify off
set linesize 500
set pages 0
set trims on
set termout off
set numformat 999D09
spool &1
select rownum||'^'||s1||'^'||to_char(to_date('&1','DD-MM-YYYY'),'DDMMYYYY')||'^'||s2||'^'||s4||'^'||s3||'^'||0 from
(select  s1,s2,sum(s4) s4,sum(s3) s3,&1
from
(select d.ZAO_CODE s1,a.MAJOR_TAX_HEAD s2,case when e.TAX_TRAN_TYPE='I' then sum(a.Challan_amount) else 0 end s3,case when e.TAX_TRAN_TYPE!='I' then SUM(a.Challan_amount) else 0 end s4
from ici_gbm_challan_master a,ici_gbm_bsrcode b,ICI_GBM_SOL_SCOLL_HISTORY c,icici_gbm_trn_hdr e,ici_gbm_territory f,ICI_GBM_SOL_SCOLL_HISTORY g,ici_gbm_nodal_master d
where c.SCR_DATE=a.realisation_date and c.sol_id=e.sol_id and b.sol_id=e.sol_id and e.tax_tran_id=a.tax_tran_id and e.tax_tran_date = a.tax_tran_date and (e.tax_type='C' or e.tax_type='c')and a.realisation_date ='&1' and a.del_flg='N' and f.STATE_NAME= a.STATE and c.COMMI_CODE='000' and g.SCR_DATE=a.realisation_date and g.sol_id in (select parent_sol_id from ici_gbm_terminal_master where sol_id=a.sol_id and scheme_code='0004') and g.COMMI_CODE='101' and d.sol_id in (select parent_sol_id from ici_gbm_terminal_master where sol_id=a.sol_id and scheme_code='0004') and  d.scheme_code='0004' group by d.ZAO_CODE,a.MAJOR_TAX_HEAD,e.TAX_TRAN_TYPE)
group by s1,s2,&1)
/
spool off
