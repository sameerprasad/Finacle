--==============================================================================
-- File Name: GBM-6301.sql
-- Description: Sql file for spooling into com file
-- Start Date: 09-09-2012 
-- Author: Ashutosh K Pandey
-- Modification History  :
-- Sl #      Date          Author Name            Description
-- ----  --------   -----------------         --------------
--  1    9-09-2012     Ashutosh K Pandey	Original Version
--===============================================================================

set pages 0
set linesize 300
spool GBM_&1 
select TAX_TRAN_DATE||'|'||SOL_ID||'|'||TAX_TRAN_ID||'|'||TRAN_DATE||'|'||TRAN_ID||'|'||NAME||'|'||CITY||'|'||STATE||'|'||PAN_TAN_NO||'|'||CHALLAN_AMOUNT||'|'||CIN_NO||'|'||MAJOR_TAX_HEAD||'|'||MINOR_TAX_HEAD||'|'||ASSESSMENT_YEAR||'|'||DEL_FLG from ici_gbm_challan_master where sol_id='6301' and TAX_TRAN_DATE=to_date('$1','dd-mm-yyyy')
and BANK_ID='$2'
/
spool off
 
