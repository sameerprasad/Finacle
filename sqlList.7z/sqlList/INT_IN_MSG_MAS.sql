Rem     This file will create INT_IN_MSG_MAS
Rem     with the following characteristics.

Rem TABLE NAME: ICNEFT.INT_IN_MSG_MAS

drop table CUSTOM.INT_IN_MSG_MAS
/
create table CUSTOM.INT_IN_MSG_MAS
(
 IC_TRANS_NO                                        VARCHAR2(16),
 IC_SENDER_INFO                                     VARCHAR2(11),
 IC_SENDER_LT                                       VARCHAR2(1),
 IC_SENDER_BRANCH                                   VARCHAR2(15),
 IC_MSG_TYPE                                        VARCHAR2(3),
 IC_APPL_ID                                         VARCHAR2(6),
 IC_SENT_DT                                         VARCHAR2(8),
 IC_SENT_TM                                         VARCHAR2(8),
 IC_RECV_DT                                         VARCHAR2(8),
 IC_RECV_TM                                         VARCHAR2(8),
 IC_SENT_FLAG                                       CHAR(5),
 IC_REF_NO                                          NUMBER,
 IC_MIR                                             VARCHAR2(100),
 IC_STATUS                                          VARCHAR2(5),
 IC_PRIORITY                                        VARCHAR2(2),
 IC_HEADER_DETAILS                                  VARCHAR2(300),
 IC_FILE_NAME                                       VARCHAR2(30),
 IC_DIR_PATH                                        VARCHAR2(100),
 IC_RECV_INFO                                       VARCHAR2(11),
 IC_RECV_LT                                         VARCHAR2(1),
 IC_RECV_BRANCH                                     VARCHAR2(15),
 IC_OMH_TRANS_NO                                    VARCHAR2(16),
 IC_FUNCTION                                        VARCHAR2(50),
 IC_MOD_NO                                          NUMBER(38),
 IC_BR_CODE                                         VARCHAR2(8),
 IC_INIT_USER                                       VARCHAR2(16),
 IC_AUTH_USER                                       VARCHAR2(16),
 IC_DUPLICATE                                       CHAR(1),
 IC_PREV_TRANS_NO                                   VARCHAR2(32),
 IC_MOR                                             VARCHAR2(100),
 IC_TRAILER                                         VARCHAR2(2000),
 IC_P_FLG                                           CHAR(1),
 IC_P_DT                                            DATE,
 IC_PRINT                                           VARCHAR2(1),
 IC_MOD_USER                                        VARCHAR2(16),
 IC_CONV_APPL_ID                                    VARCHAR2(6),
 IC_CONV_MSGTYPE                                    VARCHAR2(3),
 IC_OUT_TRANS_NO                                    VARCHAR2(16),
 IC_CONV_STATUS                                     VARCHAR2(3),
 IC_RETURN_FLG                                      VARCHAR2(2),
 IC_REA_CODE                                        VARCHAR2(4),
 IC_REA_DESC                                        VARCHAR2(50),
 IC_RETURN_REF_NO                                   NUMBER
)
/

create index IC_IDX_IN_MSG_MAS_1
on CUSTOM.INT_IN_MSG_MAS(IC_TRANS_NO,IC_SENDER_BRANCH,IC_MSG_TYPE,IC_APPL_ID,IC_REF_NO,IC_PREV_TRANS_NO)
storage ( PCTINCREASE 0 )
/

create index IC_IDX_IN_MSG_MAS_2
on CUSTOM.INT_IN_MSG_MAS(IC_TRANS_NO,IC_SENDER_BRANCH,IC_SENT_DT,IC_SENT_TM,IC_RECV_DT,IC_RECV_TM,IC_REF_NO,IC_RECV_BRANCH,IC_PREV_TRANS_NO)
storage ( PCTINCREASE 0 )
/

create index IC_IDX_IN_MSG_MAS_3
on CUSTOM.INT_IN_MSG_MAS(IC_TRANS_NO,IC_MSG_TYPE,IC_REF_NO,IC_PREV_TRANS_NO)
storage ( PCTINCREASE 0 )
/

grant select, insert, update, delete on CUSTOM.INT_IN_MSG_MAS to tbagen, tbaadm
/
grant select on CUSTOM.INT_IN_MSG_MAS to tbacust
/
grant select on CUSTOM.INT_IN_MSG_MAS to tbautil
/
