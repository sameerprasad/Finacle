---------------------------------------------------------------------------------
-- Filename         : IN_RTGS_MSG_TXN_ADT.sql
-- Description      : This sql is used to create the trigger IN_RTGS_MSG_TXN_ADT 
-- Date             : 19-11-2012
-- Author           : Aparna Ashok
-- Menu Option      : NONE
-- Modification History
-- Sl.#       Date           Author         Modification                              
-- -----   ----------   --------------    ----------------                               
--  1.0    19-11-2012   Aparna Ashok    Original Version                          
----------------------------------------------------------------------------------------------



CREATE OR REPLACE TRIGGER "ICRTGS"."IN_RTGS_MSG_TXN_ADT"
AFTER INSERT OR UPDATE OR DELETE OF IC_TRANS_NO,IC_FLD_TAG,IC_SFLD_ORD,IC_SFLD_VAL ON INT_IN_RTGS_MSG_TXN 
FOR EACH ROW
DECLARE
CNTR number;
BEGIN
     BEGIN
           IF INSERTING THEN
          BEGIN
             SELECT COUNT(*) INTO CNTR FROM INT_IN_RTGS_MSG_MAS_ADT WHERE IC_ADT_TRANS_NO = :NEW.IC_TRANS_NO AND BANK_ID=:NEW.BANK_ID;
 IF CNTR != 1 THEN
                INSERT INTO INT_IN_RTGS_MSG_TXN_ADT(IC_ADT_SLNO,IC_ADT_TRANS_NO,IC_ADT_FLD_TAG,IC_ADT_FLD_FMT_OPT,IC_ADT_SFLD_ORD,IC_ADT_SFLD_VAL_NEW)VALUES(:NEW.IC_SLNO,:NEW.IC_TRANS_NO,:NEW.IC_FLD_TAG,:NEW.IC_FLD_FMT_OPT,:NEW.IC_SFLD_ORD,:NEW.IC_SFLD_VAL);
             END IF;
          END;
          END IF;
          IF UPDATING THEN
                INSERT INTO INT_IN_RTGS_MSG_TXN_ADT(IC_ADT_SLNO,IC_ADT_TRANS_NO,IC_ADT_FLD_TAG,IC_ADT_FLD_FMT_OPT,IC_ADT_SFLD_ORD,IC_ADT_SFLD_VAL_OLD,IC_ADT_SFLD_VAL_NEW)VALUES(:NEW.IC_SLNO,:NEW.IC_TRANS_NO,:NEW.IC_FLD_TAG,:NEW.IC_FLD_FMT_OPT,:NEW.IC_SFLD_ORD,:OLD.IC_SFLD_VAL,:NEW.IC_SFLD_VAL);
          END IF;
          IF DELETING THEN
          BEGIN
             SELECT COUNT(*) INTO CNTR FROM INT_IN_RTGS_MSG_MAS_ADT WHERE IC_ADT_TRANS_NO = :NEW.IC_TRANS_NO AND BANK_ID=:NEW.BANK_ID;
             IF CNTR != 1 THEN
           INSERT INTO INT_IN_RTGS_MSG_TXN_ADT(IC_ADT_SLNO,IC_ADT_TRANS_NO,IC_ADT_FLD_TAG,IC_ADT_FLD_FMT_OPT,IC_ADT_SFLD_ORD,IC_ADT_SFLD_VAL_NEW) VALUES (:OLD.IC_SLNO,:OLD.IC_TRANS_NO,:OLD.IC_FLD_TAG, :OLD.IC_FLD_FMT_OPT, :OLD.IC_SFLD_ORD,:OLD.IC_SFLD_VAL);
END IF;
          END;
          END IF;
    END;
END;
/
ALTER TRIGGER "ICRTGS"."IN_RTGS_MSG_TXN_ADT" ENABLE
/
