-- #---------------------------------------------------------------------------------------------#
-- # File Name		: ppfcfgInsert.sql
-- # Author Name		: Sudarshan Choudhury 
-- # Module 		: PPFCFG 
-- # Date			: 18-12-2012
-- # Description		: This sql will allow user to make entry in PPFCFG table.
-- # Referenced Sqls	: NA
-- #
-- #	<Serial No.>	<Date>	<Author Name>			<Description>      
-- #		01	18-12-2012		Sudarshan Choudhury			Original Version 
-- #---------------------------------------------------------------------------------------------#

SET verify off
SET head off
SET trims on
SET echo on
SET feedback on
SET pages 0

ACCEPT bank_id CHAR PROMPT 'Enter the Bank Id :'

SELECT * FROM PPFCFG WHERE bank_id = UPPER(TRIM('&bank_id'));

INSERT INTO ppfcfg( SELECT 100000,12,500,3,6,7,2,50,60, 1,1,5,25,
'SBPPF','DLPPF',9,'PPFCOLLN',50,'PPFPAYBL','SYS1',
to_date('11-02-2012' , 'dd-mm-yyyy'),'SYS1',
to_date('11-02-2012','dd-mm-yyyy'),
UPPER(TRIM('&bank_id')) FROM dual
WHERE NOT EXISTS (SELECT * FROM ppfcfg WHERE bank_id = UPPER(TRIM('&bank_id'))));

SELECT * FROM PPFCFG WHERE bank_id = UPPER(TRIM('&bank_id'));

commit;
