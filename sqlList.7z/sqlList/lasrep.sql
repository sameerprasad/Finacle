set heading off
set verify off
set feedback off
set line 300 pages 0
set trims on colsep '|'
spool &1
SELECT  schm_code, trim(foracid), sysdate, trim(DRWNG_POWER) FROM    GAM WHERE   schm_code in ('CALAS','CARLB')and acct_cls_flg='N' and bank_id='&2'
/
spool off
