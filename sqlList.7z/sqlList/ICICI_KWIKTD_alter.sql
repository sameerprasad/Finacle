REM####################################################################
REM File Name   : ICICI_KWIKTD_alter.sql
REM Description : To Alter table ICICI_KWIKTD for CREDIT_PRO_ACCT_NUM
REM Author      : Pragnya Ghosh
REM Date        : 27-02-2013
REM Module      : KWIKTD
REM####################################################################

ALTER TABLE TBAADM.ICICI_KWIKTD_TABLE ADD CREDIT_PRO_ACCT_NUM VARCHAR2(16)
/
