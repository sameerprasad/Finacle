Rem     This file will create C_SQLQRY
Rem     with the following characteristics.

Rem TABLE NAME: ICICI.C_SQLQRY

Rem SYNONYM:  C_SQLQRY

drop table C_SQLQRY
/
drop public synonym C_SQLQRY
/
create table C_SQLQRY
(
	 TABLE_NAME                                         VARCHAR2(16),
 	 OPER_DESC                                          VARCHAR2(50),
	 STATUS                                             CHAR(1),
	 FREE_TEXT_1                                        VARCHAR2(40),
	 FREE_TEXT_2                                        VARCHAR2(40),
	 LCHG_USER_ID                                       VARCHAR2(15),
	 LCHG_TIME                                          DATE,
	 RCRE_USER_ID                                       VARCHAR2(15),
	 RCRE_TIME                                          DATE
)
TABLESPACE ICICI_CUST
/

create public synonym C_SQLQRY
    for C_SQLQRY
/

create unique index C_SQLQRY_IDX
on C_SQLQRY(TABLE_NAME)
storage ( PCTINCREASE 0 )
TABLESPACE ICICI_CUST
/

grant select, insert, update, delete on C_SQLQRY to tbagen, tbaadm
/
grant select on C_SQLQRY to tbacust
/
grant select on C_SQLQRY to tbautil
/
