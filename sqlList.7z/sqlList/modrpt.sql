--  --  ---------------------------------------------------------------------------------
--  Filename          :  modrpt.sql
--  Description       :  Sql to retrieve data for report generation called from com file
--  Date              :  16/6/2012
--  Author            :  Naveen
-- Called from    : modrpt.com
--  Modification History
--  Sl. #           Date                Author             Modification
--  -----           -----		--------          ----------------
--   01            16/6/2012             Naveen        Original Version
--  --  ---------------------------------------------------------------------------------


set verify off
set pages 0
set lines 700
set echo off feedback off verify off
set serveroutput on size 999999
set term off
spool &1


declare
vstr_forAcid 		gam.foracid%TYPE;
vstr_acid               gam.acid%TYPE;
vstr_schmType           gam.schm_type%TYPE;
vstr_schmCode           gam.schm_code%TYPE;
vstr_clrBal             gam.clr_bal_amt%TYPE;
vstr_crncyCode          gam.crncy_code%TYPE;
vstr_acctOpnDate	gam.acct_opn_date%TYPE;
vstr_mopCode		gam.mode_of_oper_code%TYPE;
vstr_cxtBankId		gam.bank_id%TYPE;
vstr_cifId		gam.cif_id%TYPE;

vstr_nomRegNum		ANT.nom_reg_num%TYPE;
vstr_nomname            ant.nom_name%type;
vstr_mopCodeDesc	RCT.REF_DESC%TYPE;
vstr_date               date;
vstr_flowCodeInd        number;

vstr_solId              TAM.sol_id%TYPE;
vstr_solId1             GAM.sol_id%TYPE;
vstr_depPerdMths        TAM.deposit_period_mths%TYPE;
vstr_depPerdDays        TAM.deposit_period_days%TYPE;
vstr_openEffDate        TAM.open_effective_date%TYPE;
vstr_matDate            TAM.maturity_date%TYPE;
vstr_depAmt             TAM.deposit_amount%TYPE;
vstr_matAmt             TAM.maturity_amount%TYPE;
vstr_cumPrincipal       TAM.cumulative_principal%TYPE;
vstr_orgDepAmt          TAM.original_deposit_amount%TYPE;
vstr_orgMatAmt          TAM.original_maturity_amount%TYPE;
vstr_autorenewflg	TAM.auto_renewal_flg%type;
vstr_autocloseflg       TAM.close_on_maturity_flg%type;
vstr_nomprintflg	TAM.nominee_print_flg%type;

vstr_solDesc            SOL.sol_desc%TYPE;
vstr_bankCode           SOL.bank_code%TYPE;
vstr_brCode             SOL.br_code%TYPE;
vstr_brAdd1             SOL.addr_1%TYPE;
vstr_brAdd2             SOL.addr_2%TYPE;
vstr_brCityCode         SOL.city_code%TYPE;
vstr_brStateCode        SOL.state_code%TYPE;
vstr_brPinCode          SOL.pin_code%TYPE;



BEGIN
--ind:=1;
vstr_forAcid := to_char('&2');
vstr_cxtBankId := to_char('&3');

                BEGIN
                --{
                        SELECT sol_id,cif_id,acid,schm_type,schm_code,clr_bal_amt,
			crncy_code,acct_opn_date,mode_of_oper_code
                        INTO vstr_solId1,vstr_cifId,vstr_acid,vstr_schmType,vstr_schmCode,vstr_clrBal,
			vstr_crncyCode,vstr_acctOpnDate,vstr_mopCode
                        FROM GAM WHERE del_flg!='Y' and FORACID= vstr_forAcid
			and bank_id = vstr_cxtBankId;
                        EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                        vstr_acid := ' ';
                        vstr_schmCode := ' ';
                        vstr_clrBal := ' ';
                        vstr_crncyCode := ' ';
			vstr_mopCode := ' ';
			vstr_acctOpnDate := ' ';
			vstr_solId1 := ' ';
                --}
                END;

                BEGIN
                --{
                        SELECT nom_reg_num, nom_name into vstr_nomRegNum, vstr_nomname
			FROM ant where acid=vstr_acid and nom_reg_num=(select max(nom_reg_num) 
			from ANT where acid=vstr_acid and bank_id = vstr_cxtBankId );
			EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                        vstr_nomRegNum := ' ';
			vstr_nomname := ' ';
                --}
                END;



                BEGIN
                --{
                        SELECT count(1)
                        INTO vstr_flowCodeInd
                        from tdt where acid=vstr_acid and flow_code='II' and bank_id = vstr_cxtBankId;
                        EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                        vstr_flowCodeInd := ' ';
                --}
                END;

                 BEGIN
                --{
                        SELECT sol_id,deposit_period_mths,deposit_period_days,open_effective_date,
                        maturity_date,deposit_amount,maturity_amount,cumulative_principal,
                        original_deposit_amount,original_maturity_amount,auto_renewal_flg,close_on_maturity_flg,
			nominee_print_flg
                        INTO vstr_solId,vstr_depPerdMths,vstr_depPerdDays,vstr_openEffDate,
                        vstr_matDate,vstr_depAmt,vstr_matAmt,vstr_cumPrincipal,
                        vstr_orgDepAmt,vstr_orgMatAmt,vstr_autorenewflg,vstr_autocloseflg,vstr_nomprintflg
                        FROM TAM WHERE ACID= vstr_acid and bank_id = vstr_cxtBankId;
                        EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                        vstr_depPerdMths := '1';
                        vstr_depPerdDays := '1';
                        vstr_openEffDate := '01-JAN-2000';
                        vstr_matDate := '01-JAN-2000';
                        vstr_depAmt := '0';
                        vstr_matAmt := '0';
                        vstr_cumPrincipal := '0';
                        vstr_orgDepAmt := '0';
                        vstr_orgMatAmt := '0';
                        vstr_autorenewflg := ' ';
                        vstr_autocloseflg := ' ';
			vstr_nomprintflg := ' ';
                        vstr_solId := ' ';
                --}
                END;

                 BEGIN
                 --{
                        SELECT sol_desc,bank_code,br_code,addr_1,addr_2,city_code,state_code,pin_code
                        INTO vstr_solDesc,vstr_bankCode,vstr_brCode,vstr_brAdd1,vstr_brAdd2,
                        vstr_brCityCode,vstr_brStateCode,vstr_brPinCode
                        FROM SOL WHERE sol_id=vstr_solId1 and bank_id = vstr_cxtBankId;
                        EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                        vstr_solDesc :=' ';
                        vstr_bankCode :=' ';
                        vstr_brCode :=' ';
                        vstr_brAdd1 :=' ';
                        vstr_brAdd2 :=' ';
                        vstr_brStateCode :=' ';
                        vstr_brPinCode :=' ';

                 --}
                END;



                 BEGIN
                 --{
                        SELECT ref_desc INTO vstr_mopCodeDesc
                        FROM RCT WHERE ref_rec_type='27' 
			and ref_code=vstr_mopCode and bank_id = vstr_cxtBankId;

                        EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                        vstr_mopCodeDesc := ' ';

                 --}
                END;

vstr_cifId := trim(vstr_cifId);


dbms_output.put_line(vstr_flowCodeInd        ||'|'||
						vstr_solDesc		||'|'||
                                                vstr_cifId             ||'|'||
                                                vstr_schmType           ||'|'||
                                                vstr_forAcid            ||'|'||
                                                vstr_acid            	||'|'||
						vstr_acctOpnDate	||'|'||
                                                vstr_openEffDate        ||'|'||
                                                vstr_depAmt             ||'|'||
                                                vstr_depPerdMths        ||'|'||
                                                vstr_depPerdDays        ||'|'||
                                                vstr_matAmt             ||'|'||
                                                vstr_matDate            ||'|'||
                                                vstr_nomRegNum          ||'|'||
                                                vstr_mopCodeDesc        ||'|'||
						vstr_crncyCode 		||'|'||
			                        vstr_autorenewflg       ||'|'||
                       				vstr_autocloseflg       ||'|'||
						vstr_nomprintflg        ||'|'||
						vstr_nomname


						
 		);

 
--dbms_output.put_line(lv_Rpt_Date date);

End;
/
spool off 
