--===================================================================================================================
--  Filename                :   letters_bradvc_rpc.sql
--  Description             :
--  Date                    :   06-09-2012
--  Author                  :   Swaroop K Tiruvoipati
--  Menu Option             :
--  Modification History
--    Sl. #           Date           Author                     Modification
--    -----           -----          --------                    ----------------
--    1               06-09-2012     Swaroop K Tiruvoipati      Original Version
--                                                              (Ported from 7.x)
--===================================================================================================================

/*
	MODIFICATION DONE TO PREVENT REPLICATION OF ADDRESSES WRONGLY
	... ADDRESS RELATED VARIABLES HAVE BEEN INITIALISED AFTER CURSOR
		IS OPENED
		ALSO INDENTATION WAS IMPROPER.. 
	---------M V VIDYASAGAR 18-04-2005
*/

declare
	acid1 gam.foracid%type;
	acid2 gam.foracid%type;
	acid gam.foracid%type;
        gcifid gam.cif_id%type;
	gacctname gam.acct_name%type;
	dtrandate dtd.tran_date%type;
	dtrantype dtd.tran_type%type;
	dtransubtype dtd.tran_sub_type%type;
	dparttrantype dtd.part_tran_type%type;
	dvaluedate dtd.value_date%type;
	dtranamt dtd.tran_amt%type;
	dtranparticular dtd.tran_particular%type;
	dtranrmks dtd.tran_rmks%type;
	drefnum dtd.ref_num%type;
	drate dtd.rate%type;
	dratecode dtd.rate_code%type;
	dfxtranamt dtd.fx_tran_amt%type;
	dtranid dtd.tran_id%type;
	dparttransrlnum dtd.part_tran_srl_num%type;
	ccusttitlecode cmg.cust_title_code%type;
	ccustcomuaddr1 cmg.cust_comu_addr1%type;
	ccustcomuaddr2 cmg.cust_comu_addr2%type;
	ccustcomupincode cmg.cust_comu_pin_code%type;
	ccustcomucitycode cmg.cust_comu_city_code%type;
	ccustcomustatecode cmg.cust_comu_state_code%type;
	saddr1 sol.addr_1%type;
	saddr2 sol.addr_2%type;
	scitycode sol.city_code%type;
	sstatecode sol.state_code%type;
	sbrcode sol.br_code%type;
	rcity rct.ref_desc%type;
	rstate rct.ref_desc%type;
	scity rct.ref_desc%type;
	sstate rct.ref_desc%type;
	bbrname sol.sol_desc%type;
	bbrcode sol.br_code%type;
	loc_fp                          utl_file.file_type;
	loc_filename                    varchar2(200);
	loc_filepath                    varchar2(100);
	loc_filemode                    varchar(10);
	cursor gamcur is
	select gam.foracid,substr(gam.foracid,5,2),substr(gam.foracid,7,6),
	gam.cust_id,gam.acct_name,dtd.tran_date,dtd.tran_type,dtd.tran_sub_type,dtd.part_tran_type,
	dtd.value_date, to_char(dtd.tran_amt,'99999999999.99'),dtd.tran_particular,dtd.
	tran_rmks,dtd.ref_num,dtd.rate,dtd.rate_code,dtd.fx_tran_amt,
	dtd.tran_id,dtd.part_tran_srl_num,sol.br_code,sol.sol_desc from gam ,dtd,sol
	where substr(gam.foracid,5,2) not in ('31','02','12','06')
	and gam.acct_cls_flg = 'N'
	and gam.acct_ownership ='C'
	and gam.acid=dtd.acid
	and dtd.pstd_flg='Y'
	and dtd.del_flg='N'
	and ((dtd.part_tran_type='D' and dtd.prnt_advc_ind in ('B'))
	     or dtd.tran_particular like '%MICR CHEQUES CHARGES%'
	     or dtd.tran_rmks like 'ECGC premium%')
	and sol.sol_id=substr(foracid,1,4)
        and gam.BANK_ID = '&3'
        and dtd.BANK_ID = '&3'
        and sol.BANK_ID = '&3';
	
begin --{
	open gamcur;
	loc_filepath := '&1';
--	loc_filename := 'bradvc.txt';
	loc_filename := '&2';
	loc_filemode := 'w';
	loc_fp := utl_file.fopen(loc_filepath, loc_filename, loc_filemode);
	loop --{
	fetch gamcur into 
		acid,acid1,acid2,gcifid,gacctname,dtrandate,dtrantype,
		dtransubtype,dparttrantype,dvaluedate, dtranamt,dtranparticular,
		dtranrmks,drefnum,drate,dratecode,dfxtranamt,dtranid,dparttransrlnum,bbrcode,bbrname;
		exit when gamcur%notfound;

		begin --{

			begin --{
				ccusttitlecode:=''; --(ADDED)START MODIFICATIONS BY MVV
				ccustcomuaddr1:='';
				ccustcomuaddr2:='';
				ccustcomupincode:='';
				ccustcomucitycode:='';
				ccustcomustatecode:='';
				saddr1:='';
				saddr2:='';
				scitycode:='';
				sstatecode:='';
				sbrcode:=''; 		--END MODIFICATIONS BY MVV
				select cmg.cust_title_code,cmg.cust_comu_addr1,cmg.cust_comu_addr2,
				cmg.cust_comu_pin_code,nvl(cmg.cust_comu_city_code,'*'),
				nvl(cmg.cust_comu_state_code,'*'), sol.addr_1,sol.addr_2,
				nvl(sol.city_code,'*'),nvl(sol.state_code,'*'),br_code into 
				ccusttitlecode,ccustcomuaddr1,ccustcomuaddr2,ccustcomupincode,
				ccustcomucitycode,ccustcomustatecode,saddr1,saddr2,scitycode,
				sstatecode,sbrcode
				from cmg ,sol where cust_id=gcifid
				and substr(acid,1,4)=sol.sol_id
                                and cmg.BANK_ID = '&3'
                                and sol.BANK_ID = '&3';
--				and substr(acid,3,2)=sol.br_code; ( Modified Since wrong address getting picked up )
				exception when no_data_found then
					null;
			end; --}

			begin --{
				rcity:=''; 			--(ADDED) MODIFICATION BY MVV
				select ref_desc into rcity
				from rct
				where ref_rec_type='01'
				and ref_code=ccustcomucitycode
				and del_flg='N'
                                and BANK_ID = '&3';
				exception when no_data_found then
					rcity:='*';
			end; --}

			begin --{
				rstate:=''; 		--(ADDED) MODIFICATION BY MVV
				select ref_desc into rstate
				from rct
				where ref_rec_type='02'
				and ref_code=ccustcomustatecode
				and del_flg='N'
                                and BANK_ID = '&3';
				exception when no_data_found then
					rstate:='*';
			end; --}

			begin --{
				scity:='';			--(ADDED) MODIFICATION BY MVV
				select ref_desc into scity
				from rct
				where ref_rec_type='01'
				and ref_code=scitycode
				and del_flg='N'
                                and BANK_ID = '&3';
				exception when no_data_found then
					scity:='*';
			end; --}

			begin --{
				sstate:='';			--(ADDED) MODIFICATION BY MVV
				select ref_desc into sstate
				from rct
				where ref_rec_type='02'
				and ref_code=sstatecode
				and del_flg='N'
                                and BANK_ID = '&3';
				exception when no_data_found then
					sstate:='*';
			end; --}
			-- begin --{
			-- select br_name into brname
			-- from bct
			-- where br_code=sbrcode and BANK_ID = '&3';
			-- exception
			-- when no_data_found then
			-- brname:='*';
			-- end; --}
			utl_file.put_line (loc_fp,dtrandate||'|'||acid1||'|'||acid2||'|'||acid||'|'||
			gcifid||'|'||dtrantype||'|'||dtransubtype||'|'||dparttrantype||'|'||
			dvaluedate||'|'||dtranamt||'|'||dtranparticular||'|'||
			dtranrmks||'|'||drefnum||'|'||drate||'|'||dratecode||'|'||
			dfxtranamt||'|'||ccusttitlecode||'|'||gacctname||'|'||ccustcomuaddr1||'|'||
			ccustcomuaddr2||'|'||rcity||'|'||rstate||'|'||
			ccustcomupincode||'|'||bbrname||'|'||saddr1||'|'|| 
			saddr2||'|'||scity||'|'||sstate||'|'||dtranid||'|'||dparttransrlnum);
		end; --}
	end loop; --}
	utl_file.fclose(loc_fp);
end; --}
/
