Rem ScriptName: lien_history.sql
Rem SQL called from ICIRSQLS to display details of Lien history date-wise in descending order
Rem Author : Rahul Nimkar

set pages 22
set lines 120 
set feedback off
set verify off
set trims on
set termout off

col b2k_type heading 'Lien Type' justify left format A5
col foracid heading 'Account No.' justify left format A12
col acct_crncy_code heading 'Curr.' justify left format A5
col sol_id heading 'SOL ID' justify right format A6
col lien_amt heading 'O/s Lien' justify right format B99,99,99,99,999.99
col event_lien_amt heading 'Event Amt.' justify right format B99,99,99,99,999.99
col event heading 'Event' justify right format A5
col modify_bod_date heading 'Date' justify right format A10
col rcre_time heading 'Time' justify right format A8

spool lien_hist.lst
select 	h.b2k_type b2k_type,
	g.foracid foracid,
	g.acct_crncy_code acct_crncy_code, 
	g.sol_id sol_id, 
	h.lien_amt lien_amt, 
	h.event_lien_amt event_lien_amt, 
	(case when h.event_lien_amt = 0 then 'G' when h.event_lien_amt > 0 then 'M' else 'R' end) event, 
	h.modify_bod_date modify_bod_date, 
	to_char(h.rcre_time,'HH24:MI:SS') rcre_time 
from alh h, gam g 
where h.acid = g.acid 
and g.foracid = '&1' 
and h.bank_id = g.bank_id 
and g.bank_id = '&2'
order by h.rcre_time desc
/
