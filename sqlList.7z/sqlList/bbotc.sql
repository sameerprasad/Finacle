-- =====================================================================================================================
-- Source Name            :  bbotc.sql
-- Description            :  PACKAGE bbotc. To avoid FTS on PST table, sol_id criteria is added
-- Input Values           :  None
-- Output Values          :  None
-- Called Scripts         :  None
-- Calling Scripts        :  None
-- Modification history:
-- Sl. No            Date                 Author                      Description
-- ---------     --------------    ----------------------        ------------------------------
-- 1.0             23-03-2013             Gauri                   Ported as per 10.x
-- =====================================================================================================================	
--	Date:	30-10-2007
--	Auth:	Eldo
--	desc:	To avoid FTS on PST table, sol_id criteria is added
--
set serveroutput on size 100000
	
	CREATE or REPLACE PACKAGE bbotc AS
		
		PROCEDURE getcrncy(inp_string IN VARCHAR2,
						   out_endOfFile OUT  NUMBER,     
						   out_string    OUT  VARCHAR2);
	
	END bbotc;
/

-- ***********************************************************  
CREATE or REPLACE PACKAGE BODY  bbotc AS

	CURSOR BOTCCursor(bankId varchar2) IS
		SELECT DISTINCT sol_id, crncy_purchsd,crncy_sold FROM PST 
		WHERE ho_tran_id is  null 
		AND ho_tran_date is  null
		AND entity_cre_flg='Y' 
		AND CRNCY_PURCHSD != CRNCY_SOLD
		AND pst_date = ( SELECT db_stat_date FROM GCT WHERE bank_id = bankId) 
		AND sol_id IN (SELECT sol_id FROM SST WHERE set_id = 'ALL' AND bank_id = bankId)
		AND bank_id = bankId;

--  --------------------------------------------------------------------------- 
--
--  --------------------------------------------------------------------------- 

	PROCEDURE getcrncy(inp_string IN VARCHAR2,  
					    out_endOfFile OUT  NUMBER,
						out_string    OUT  VARCHAR2) IS

	inpArr      basp0099.ArrayType;
	botc_rec	BOTCCursor%ROWTYPE;
	pl_hol_pur		GAM.BACID%TYPE;
	pl_hol_sale		GAM.BACID%TYPE;
	v_bankId	GAM.BANK_ID%TYPE;
	startdate   gct.db_stat_date%type;

	BEGIN
		basp0099.formInputArr (inp_string, inpArr);  
		v_bankId := inpArr(0);
		SELECT (db_stat_date -3 ) INTO startdate FROM GCT WHERE bank_id = bankId;	
		out_endOfFile := 1;
		out_string := '';    

		IF NOT BOTCCursor%ISOPEN THEN
			Open BOTCCursor(v_bankId);
		END IF;


		FETCH BOTCCursor into botc_rec;

		IF BOTCCursor%NOTFOUND THEN
			CLOSE BOTCCursor;
			out_endOfFile := 1403;  -- When All Records have been Fetched.  
			RETURN;
		ELSE
			SELECT DECODE(botc_rec.CRNCY_PURCHSD,'INR','IBFX-SALE','FS201') INTO pl_hol_pur FROM DUAL;
			SELECT DECODE(botc_rec.CRNCY_SOLD,'INR','IBIBIT','FS201') INTO pl_hol_sale FROM DUAL;

			out_string := botc_rec.sol_id||'|'||botc_rec.crncy_purchsd||'|'||botc_rec.crncy_sold||'|'||pl_hol_pur||'|'||pl_hol_sale||'|'||'E'||'|'||startdate;
			out_endOfFile := 0; 
		END IF;

	EXCEPTION 
		WHEN OTHERS THEN 
			IF BOTCCursor%ISOPEN THEN
				CLOSE BOTCCursor;
			END IF;
		out_endOfFile := 1;   

	END getcrncy;

END bbotc;
--********************************************************************** 
/
GRANT EXECUTE ON bbotc TO TBAGEN, TBAUTIL, TBACUST   
/
DROP PUBLIC SYNONYM bbotc
/
CREATE PUBLIC SYNONYM bbotc FOR bbotc
/
-------------------------  END OF SOURCE    ---------------------------- 
