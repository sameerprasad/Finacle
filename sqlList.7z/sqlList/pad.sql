REM Script to find out the particulars of an inward clearing cheque passed in an account.
REM Author - K. Ramakrishnan
REM Date - February 28, 2007

set verify off
set feedback off
set lines 100
set pages 22
set trims on
set termout off

--accept inst_num prompt 'ENTER INSTRUMENT NUMBER :  '
--accept foracid prompt 'ENTER ACCOUNT NUMBER:  '


column inst heading 'INST NUM' format B99999999
column inst_amt heading 'AMOUNT' format B99,99,99,999.99
column foracid heading 'ACCT NUM' format A16
column sol_id heading 'SOL' format B9999
column zone_code heading 'ZONE' format B999
column tran_id heading 'TRAN ID' 
column part_tran_srl_num heading 'PTRAN' format B9999

spool pad.lst 
select ltrim(i.inst_num) inst, 
       g.foracid,
       i.zone_date,
       h.init_sol_id,
       h.tran_id,
       i.zone_code,
       p.part_tran_srl_num,
       i.inst_amt
from ici i, gam g, hth h, icp p
where ltrim(inst_num)='&2'
and g.foracid='&1'
and i.zone_date=p.zone_date
and i.zone_code=p.zone_code
and i.acid=p.acid
and i.acid=g.acid
and p.acid=g.acid
--and i.acid=p.acid
and i.zone_date=h.tran_date
and p.zone_date=h.tran_date
and p.tran_id=h.tran_id
and i.bank_id='&3' and g.bank_id='&3' and h.bank_id='&3' and p.bank_id='&3'
-- and p.part_tran_srl_num=h.part_tran_srl_num
/
spool off
exit

