set heading off

select '                     THIS OPTION IS DISABLED' from dual
/
exit
