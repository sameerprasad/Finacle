DROP VIEW CRMUSER.CMG_ICICI;

/* Formatted on 2013/05/13 12:44 (Formatter Plus v4.8.8) */
CREATE OR REPLACE FORCE VIEW crmuser.CMG_ICICI (cust_id,
                                          bank_id,
                                          cif_id,
                                          gcif_id,
                                          entity_cre_flg,
                                          del_flg,
                                          cust_short_name,
                                          alt1_cust_short_name,
                                          cust_title_code,
                                          cust_name,
                                          alt1_cust_name,
                                          cust_sex,
                                          cust_grp,
                                          cust_occp_code,
                                          cust_commu_code,
                                          cust_sector_code,
                                          cust_sub_sector_code,
                                          cust_rating_code,
                                          cust_rating_date,
                                          cust_mgr_opin,
                                          cust_introd_cust_id,
                                          introd_title_code,
                                          cust_introd_name,
                                          alt1_cust_introd_name,
                                          cust_introd_stat_code,
                                          cust_type_code,
                                          cust_emp_id,
                                          cust_stat_code,
                                          cust_stat_chg_date,
                                          cust_const,
                                          cust_minor_flg,
                                          cust_nre_flg,
                                          cust_hlth_code,
                                          cust_card_hold_flg,
                                          lchg_user_id,
                                          lchg_time,
                                          rcre_user_id,
                                          rcre_time,
                                          tds_tbl_code,
                                          tds_cust_id,
                                          nat_id_card_num,
                                          date_of_birth,
                                          pan_gir_num,
                                          psprt_num,
                                          psprt_issu_date,
                                          psprt_det,
                                          psprt_exp_date,
                                          purge_allowed_flg,
                                          purge_text,
                                          cust_pref_till_date,
                                          acct_mgr_user_id,
                                          crncy_code,
                                          party_flg,
                                          native_lang_name,
                                          nat_lang_title_code,
                                          lang_code,
                                          primary_sol_id,
                                          address_type,
                                          dsa_id,
                                          offline_cum_debit_limit,
                                          cust_opn_date,
                                          cust_employee_no,
                                          cust_creation_mode,
                                          pref_code,
                                          tot_mod_times,
                                          segmentation_class,
                                          corp_id,
                                          phone,
                                          email,
                                          risk_profile_score,
                                          risk_profile_expiry_date,
                                          cust_first_name,
                                          cust_middle_name,
                                          cust_last_name,
                                          alt1_cust_first_name,
                                          alt1_cust_middle_name,
                                          alt1_cust_last_name,
                                          strfield14,
                                          strfield15,
                                          subsegment,
                                          asset_classification,
                                          customer_level_provisioning,
                                          islamic_banking_customer,
                                          preferential_cal_base,
                                          zakat_deduction,
                                          staff_flag,
                                          is_dummy,
                                          charge_level_code,
                                          secondaryrm_id,
                                          tertiaryrm_id,
                                          short_name_native,
                                          country_of_birth
                                         )
AS
   SELECT accounts.core_cust_id cust_id, accounts.bank_id bank_id,
          accounts.orgkey cif_id, accounts.gcifid gcif_id,
          accounts.entity_cre_flag entity_cre_flg, accounts.suspended del_flg,
          accounts.short_name cust_short_name,
          accounts.short_name_alt1 alt1_cust_short_name,
          SUBSTR (accounts.salutation, 1, 5) cust_title_code,
          accounts.NAME cust_name, accounts.name_alt1 alt1_cust_name,
          SUBSTR (accounts.gender, 1, 1) cust_sex,
          accounts.groupid_code cust_grp,
          SUBSTR (accounts.occupation, 1, 5) cust_occp_code,
          SUBSTR (accounts.cust_community, 1, 5) cust_commu_code,
          SUBSTR (accounts.sector, 1, 5) cust_sector_code,
          SUBSTR (accounts.subsector, 1, 5) cust_sub_sector_code,
          SUBSTR (accounts.rating, 1, 5) cust_rating_code,
          accounts.ratingdate cust_rating_date,
          accounts.manageropinion cust_mgr_opin,
          accounts.core_introd_cust_id cust_introd_cust_id,
          SUBSTR (accounts.introducersalutation, 1, 5) introd_title_code,
          accounts.introducername cust_introd_name,
          accounts.introducername_alt1 alt1_cust_introd_name,
          SUBSTR (accounts.introd_status, 1, 5) cust_introd_stat_code,
          SUBSTR (accounts.cust_type, 1, 5) cust_type_code,
          accounts.staffemployeeid cust_emp_id,
          SUBSTR (accounts.status, 1, 5) cust_stat_code,
          accounts.custstatuschgdate cust_stat_chg_date,
          SUBSTR (accounts.constitution_code, 1, 5) cust_const,
          accounts.customerminor cust_minor_flg,
          accounts.customernreflg cust_nre_flg,
          SUBSTR (accounts.cust_hlth, 1, 5) cust_hlth_code,
          accounts.card_holder cust_card_hold_flg,
          NVL (TO_CHAR (accounts.bomodifiedby),
               TO_CHAR (accounts.bocreatedby)
              ) lchg_user_id,
          NVL (accounts.bodatemodified, accounts.bodatecreated) lchg_time,
          TO_CHAR (accounts.bocreatedby) rcre_user_id,
          accounts.bodatecreated rcre_time,
          SUBSTR (accounts.tds_tbl, 1, 5) tds_tbl_code,
          accounts.tds_cust_id tds_cust_id,
          accounts.nat_id_card_num nat_id_card_num,
          TRUNC (accounts.cust_dob) date_of_birth, accounts.pan pan_gir_num,
          SUBSTR (accounts.passportno, 1, 12) psprt_num,
          accounts.psprt_issue_date psprt_issu_date,
          accounts.psprt_det psprt_det,
          accounts.psprt_exp_date psprt_exp_date,
          accounts.purgeflag purge_allowed_flg,
          accounts.purgeremarks purge_text,
          accounts.cust_pref_till_date cust_pref_till_date,
          SUBSTR (accounts.manager, 1, 15) acct_mgr_user_id,
          accounts.crncy_code crncy_code, accounts.tfpartyflag party_flg,
          accounts.nativelangname native_lang_name,
          accounts.nativelangtitle nat_lang_title_code,
          accounts.nativelangcode lang_code,
          accounts.primary_sol_id primary_sol_id,
          SUBSTR (accounts.defaultaddresstype, 1, 12) address_type,
          accounts.dsa_id dsa_id,
          accounts.offline_cum_debit_limit offline_cum_debit_limit,
          accounts.relationshipopeningdate cust_opn_date,
          accounts.strfield7 cust_employee_no,
          accounts.custcreationmode cust_creation_mode,
          accounts.pref_code pref_code, accounts.intfield5 tot_mod_times,
          accounts.segmentation_class segmentation_class,
          accounts.corp_id corp_id, accounts.phone phone,
          accounts.email email,
          accounts.risk_profile_score risk_profile_score,
          accounts.risk_profile_expiry_date risk_profile_expiry_date,
          accounts.cust_first_name cust_first_name,
          accounts.cust_middle_name cust_middle_name,
          accounts.cust_last_name cust_last_name,
          accounts.cust_first_name_alt1 alt1_cust_first_name,
          accounts.cust_middle_name_alt1 alt1_cust_middle_name,
          accounts.cust_last_name_alt1 alt1_cust_last_name,
          accounts.strfield14 strfield14, accounts.strfield15 strfield15,
          accounts.subsegment subsegment,
          accounts.asset_classification asset_classification,
          accounts.customer_level_provisioning customer_level_provisioning,
          accounts.islamic_banking_customer islamic_banking_customer,
          accounts.preferredcalendar preferential_cal_base,
          accounts.zakat_deduction zakat_deduction,
          accounts.staffflag staff_flag, accounts.isdummy is_dummy,
          SUBSTR (accounts.chargelevelcode, 1, 5) charge_level_code,
          accounts.secondaryrm_id secondaryrm_id,
          accounts.tertiaryrm_id tertiaryrm_id,
          accounts.short_name_native short_name_native,
          accounts.countryofbirth country_of_birth
     FROM accounts, (select * from entitydocument where doccode in ('PANGR' , 'PAN') and IDENTIFICATIONTYPE ='PAN') b
     where accounts.orgkey= b.orgkey (+);


DROP SYNONYM CRMBATCHUSER.CMG_ICICI;

CREATE SYNONYM CRMBATCHUSER.CMG_ICICI FOR CRMUSER.CMG_ICICI;


DROP SYNONYM ICICI.CMG_ICICI;

CREATE SYNONYM ICICI.CMG_ICICI FOR CRMUSER.CMG_ICICI;


DROP SYNONYM TBAADM.CMG_ICICI;

CREATE SYNONYM TBAADM.CMG_ICICI FOR CRMUSER.CMG_ICICI;


DROP SYNONYM TBAGEN.CMG_ICICI;

CREATE SYNONYM TBAGEN.CMG_ICICI FOR CRMUSER.CMG_ICICI;


DROP SYNONYM TBAUTIL.CMG_ICICI;

CREATE SYNONYM TBAUTIL.CMG_ICICI FOR CRMUSER.CMG_ICICI;


DROP PUBLIC SYNONYM CMG_ICICI;

CREATE PUBLIC SYNONYM CMG_ICICI FOR CRMUSER.CMG_ICICI;


GRANT DELETE, INSERT, SELECT, UPDATE ON CRMUSER.CMG_ICICI TO ICICI;

GRANT SELECT ON CRMUSER.CMG_ICICI TO ICNEFT;

GRANT SELECT ON CRMUSER.CMG_ICICI TO ICRTGS;

GRANT SELECT ON CRMUSER.CMG_ICICI TO ICSFMS;

GRANT SELECT ON CRMUSER.CMG_ICICI TO ICSWIFT;

GRANT SELECT ON CRMUSER.CMG_ICICI TO TBAADM WITH GRANT OPTION;
GRANT DELETE, INSERT, REFERENCES, UPDATE, ON COMMIT REFRESH, QUERY REWRITE, DEBUG, FLASHBACK ON CRMUSER.CMG_ICICI TO TBAADM;

GRANT SELECT ON CRMUSER.CMG_ICICI TO TBAGEN WITH GRANT OPTION;
GRANT DELETE, INSERT, UPDATE ON CRMUSER.CMG_ICICI TO TBAGEN;

GRANT SELECT ON CRMUSER.CMG_ICICI TO TBAUTIL WITH GRANT OPTION;
