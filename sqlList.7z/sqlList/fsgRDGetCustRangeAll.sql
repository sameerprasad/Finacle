-- Changes for RD.
-- Range of each list increased to 10000 since actual no of cust ids
-- selected would be very few.
set serveroutput on size 1000000
set feedback off
set verify   off
set termout   off
set pages 0
set linesize 512
set trims on
spool &1-&2-RANGE

DECLARE
custSolId			ICICI_CIFT.HOME_SOL_ID%Type;
beginCustId			ICICI_CIFT.CUST_ID%Type;
endCustId			ICICI_CIFT.CUST_ID%Type;
custCnt				NUMBER(9);
step				NUMBER(9);
idTypeStr			VARCHAR2(200);
idTypeArr			iciArray.arrayType;
idTypeCnt			NUMBER(9);
endCustFound		NUMBER(9);
curIdTypeCnt		NUMBER(9) := 0;
dispMode      		CHAR;
outLine				varchar2(500);
runId				varchar2(10);

-- Below regular expression added by Sunil for CR31801637 to exclude Cust ids which have only special characs

CURSOR ciftCur IS
SELECT	
	HOME_SOL_ID,
	CUST_ID
FROM	
	ICICI_CIFT
WHERE	
	HOME_SOL_ID = custSolId
AND	STMT_REQD != 'N'
AND REGEXP_LIKE(CUST_ID,'[0-9]')
ORDER BY HOME_SOL_ID, cust_id;

ciftRec ciftCur%ROWTYPE;

BEGIN
	custCnt := 0;
	runId := '&1';
	custSolId := '&2';
	dispMode := '&3';

	step := 1;
	idTypeStr := '0|1|2|3|4|5|6|7|8|9|A|B|C|D|E|F|G|H|I|J|K|L|M|N|O|P|Q|R|S|T|U|V|W|X|Y|Z|a|b|c|d|e|f|g|h|i|j|k|l|m|n|o|p|q|r|s|t|u|v|w|x|y|z|-|_|.' ;

	iciArray.construct(idTypeStr, '|' , idTypeCnt,  idTypeArr);

	custCnt := 1;
	endCustFound := 0;

	for ciftRec in ciftCur loop
	begin
		step := 2;
		if (custCnt = 1) then
			beginCustId := ciftRec.cust_id;
			endCustFound := 0;
		end if;

		endCustId := ciftRec.cust_id;
		if (custCnt = 500000) then
			endCustFound := 1;
			outLine := 	runId						||
						ciftRec.home_sol_id			|| 
						idTypeArr(curIdTypeCnt)		|| '|' ||
						beginCustId 				|| '|' ||
						endCustId;
			dbms_output.put_line(outLine);
			custCnt := 1;
			curIdTypeCnt := curIdTypeCnt + 1;
		else
			custCnt := custCnt + 1;
		end if;

		EXCEPTION
		WHEN OTHERS THEN
			DBMS_OUTPUT.PUT_LINE('<#ORA-ERROR#>');
			DBMS_OUTPUT.PUT_LINE('Cust Id range creation failed at step...'||step);
			DBMS_OUTPUT.PUT_LINE('Cust Id '||beginCustId);
			DBMS_OUTPUT.PUT_LINE('Sql Error Code is        : ' || SQLCODE );
			DBMS_OUTPUT.PUT_LINE('SQL Error Description is : '|| SQLERRM);
	end;
	end loop;

	if (endCustFound = 0) then
		outLine := 	runId						||
					custSolId					||
					idTypeArr(curIdTypeCnt)		|| '|' ||
					beginCustId 				|| '|' ||
					endCustId;
		dbms_output.put_line(outLine);
	end if;
END;
/
spool off
