REM####################################################################
REM File Name   : SPCTC1.sql
REM Description : Suppliers Credit Info for TC-1
REM Author      : Paresh Maru
REM Date        : 17-01-2011
REM Module  : Supplier Credit
REM####################################################################

REM TABLE NAME: SUP_CR_TC1

REM SYNONYM:    SPCTC1

drop table icici.SUP_CR_TC1
/
drop public synonym SPCTC1
/
create table icici.SUP_CR_TC1
(
suppliers_credit_ref_no		VARCHAR2(30 CHAR),
dc_ref_no			VARCHAR2(16 CHAR),
dc_sol_id			VARCHAR2(8 CHAR),
Date_of_approval		DATE,
Name_of_lender			VARCHAR2(50 CHAR),
Country_of_lender		VARCHAR2(50 CHAR),
Amount				number(20,4),
Currency			VARCHAR2(4 CHAR),
Rate_of_Interest		VARCHAR2(30 CHAR),
Other_chrg_usd			number(20,4),
All_in_Cost			number(20,4),
Period_of_Credit		number(20,4),
Unit_of_time_period		VARCHAR2(4 CHAR),
Type_of_Credit1			VARCHAR2(4 CHAR),
Type_of_Credit2			VARCHAR2(4 CHAR),
Description			VARCHAR2(100 CHAR),
Category			VARCHAR2(16 CHAR),
ENTITY_CRE_FLG			CHAR(1),
DEL_FLG				CHAR(1),
LCHG_USER_ID			VARCHAR2(15 CHAR),
LCHG_TIME			DATE,
RCRE_USER_ID			VARCHAR2(15 CHAR),
RCRE_TIME			DATE,
conv_rate           number(21,10),
equi_usd_amt        number(21,10),
bill_no				VARCHAR2(15 CHAR),
bank_id 		VARCHAR2(8 CHAR)
)
/
create public synonym SPCTC1 for icici.SUP_CR_TC1
/
grant select, insert, update, delete on SPCTC1 to tbagen
/
grant select on SPCTC1 to tbacust
/
grant select on SPCTC1 to tbautil
/
grant all on SPCTC1 to tbaadm
/
create unique index IDX_SPCTC1 on SPCTC1(bank_id,suppliers_credit_ref_no,dc_ref_no,dc_sol_id)
/

