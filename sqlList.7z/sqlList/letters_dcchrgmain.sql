--===================================================================================================================
--  Filename                :   letters_dcchrgmain.sql
--  Description             :   
--  Date                    :   05-09-2012
--  Author                  :   Swaroop K Tiruvoipati
--  Menu Option             :
--  Modification History
--    Sl. #           Date           Author                     Modification
--    -----           -----          --------                    ----------------
--    1               05-09-2012     Swaroop K Tiruvoipati      Original Version
--                                                              (Ported from 7.x)
--===================================================================================================================

set head off verify off termout off feedback off pages 0
declare
loc_fp                          utl_file.file_type;
loc_filename                    varchar2(200);
loc_filepath                    varchar2(100);
loc_filemode                    varchar(10);
other_party varchar2(80);
rundate date;

cursor candidate is
select sol_id,dc_ref_num,dc_reg_type, dcem.event_type,dc_chrg_code, dcem.crncy_code, dcem.event_amt, actl_crncy_code, dcmm.open_value,dcmm.ratecode, dcmm.expiry_date, dcmm.rate, event_Date,dcmm.dc_b2kid ,issu_party_code, benef_party_code from dcmm,dcem where dcmm.dc_b2kid=dcem.dc_b2kid and event_date=rundate and dcmm.del_flg!='Y' and dcmm.entity_cre_flg!='N' and dcem.entity_cre_flg!='N' and dcmm.BANK_ID = '&1' and dcem.BANK_ID = '&1' and dc_chrg_tran_id is not null ;

cursor otherdetails(dcb2kid dcmm.dc_b2kid%type) is
select service_sol_id, ltrim(rtrim(substr(comp_b2kid,1,12))),comp_b2kid_type ,CHRg_tran_id, chrg_tran_date, chrg_part_tran_srl_num, event_type, event_id, target_acid, system_calc_amt, actual_amt_coll, coll_crncy_code, cif_id, rate_1, rate_2, amt_without_discount ,tran_particular,tran_rmks from cxl where ltrim(rtrim(substr(comp_b2kid,1,12))) = dcb2kid and chrg_tran_Date=rundate and comp_b2kid_type='DOCCR' and BANK_ID = '&1';

#cursor custdetails(cifid cmg.cif_id%type) is
#select cust_title_code, cust_name, addr_1, addr_2,addr_3,  cust_comu_city_code, cust_comu_state_code,cust_comu_pin_code, cust_comu_cntry_code, cust_comu_phone_num_1, cust_comu_phone_num_2, cust_Rating_code, cust_Stat_code, icici_cift.email_id,icici_cift.stmt_reqd from cmg,fpc, icici_cift where cmg.cif_id=cifid and cmg.cif_id=icici_cift.cif_id and cmg.cif_id=fpc.party_code and cmg.del_flg!='Y' and fpc.del_flg!='Y' and cmg.BANK_ID = '&1' and fpc.BANK_ID = '&1' and icici_cift.BANK_ID = '&1'; 

cursor custdetails(cifid cmg.cif_id%type) is
select cust_title_code, cust_name,icici_cift.email_id,icici_cift.stmt_reqd from cmg,fpc, icici_cift where cmg.cif_id=cifid and cmg.cif_id=icici_cift.cif_id and cmg.cif_id=fpc.party_code and cmg.del_flg!='Y' and fpc.del_flg!='Y' and cmg.BANK_ID = '&1' and fpc.BANK_ID = '&1' and icici_cift.BANK_ID = '&1';



callrec cmg.cif_id%type;
dcvalue number(21,10);
ccity varchar2(50);
cstate varchar2(50);
ccntry varchar2(50);
acctnum gam.foracid%type;
acctname gam.acct_name%type;
acctcrncy gam.acct_crncy_code%type;
brname bct.br_name%type;
braddr1 varchar2(50);
braddr2 varchar2(50);
brc bct.br_city_code%type;
brs bct.br_state_code%type;
brpin bct.br_pin_code%type;
brcity varchar2(50);
brstate varchar2(50);
msg1srlnum number (5);
msg2srlnum number (5);
msg3srlnum number (5);
msg4srlnum number (5);
msg5srlnum number (5);
msg1 varchar2(80);
msg2 varchar2(80);
msg3 varchar2(80);
msg4 varchar2(80);
msg5 varchar2(80);
emlid icici_cift.email_id%type;
begin
select (db_stat_date) into rundate from gct where BANK_ID = '&1';
 loc_filepath := '/tmp';
        loc_filename := 'dcchrg.lst';
        loc_filemode := 'w';
        loc_fp := utl_file.fopen(loc_filepath, loc_filename, loc_filemode);

for candrec in candidate loop
begin 

begin
select round( (nvl(dcmm.current_value,0)+(nvl(dcmm.current_value,0)* nvl(dcmm.actl_tolerance_pcnt,0))/100) + (nvl(dcmm.interest_addtnl_amt,0)+nvl(dcmm.dc_reinst_amt,0))) into dcvalue from dcmm where dc_ref_num=candrec.dc_ref_num and BANK_ID = '&1';
exception when no_data_found then
dcvalue:=0;
end;

for otherrec in otherdetails(candrec.dc_b2kid) loop

begin
select foracid, acct_crncy_code, acct_name into acctnum, acctcrncy, acctname from gam where acid=otherrec.target_acid and BANK_ID = '&1';
callrec:=candrec.issu_party_code;
if (candrec.dc_reg_type = 'INWIN' or candrec.dc_reg_type='INWFR') then
callrec:=candrec.benef_party_code;
if (candrec.benef_party_code is NULL) then
callrec:='XXXXXXXXX';
end if;
end if;
for custrec in custdetails(callrec) loop
begin
begin

select   address_line1,
         address_line2,
         address_line3,
	 city_code,
         state_code,
         zip,
         country_code
        FROM  CRMUSER.ADDRESS
        INTO addr_1,addr_2,addr_3,ccity,cstate,cpin,ccntry
        where orgkey=cifid
        and addresscategory = 'Mailing'
        AND start_date = (SELECT max(start_date) FROM CRMUSER.ADDRESS
        WHERE ORGKEY = cifid AND addresscategory = 'Mailing' and bank_id = '$1')
        and bank_id = '$1');

select phoneno1,phoneno2 from CRMUSER.phoneemail
	INTO  phone_num_1,phone_num_2
	WHERE ORGKEY = cifid and bank_id = '$1';

select status_code,rating_code from CRMUSER.ACCOUNTS
	INTO stat_code,rating_code 
	WHERE ORGKEY = cifid and bank_id = '$1'; 

select decode(ref_desc,NULL,' ',ref_desc) into city
from rct
    where ref_rec_type = '01'
    and ref_code = city
    and BANK_ID = '&1';
EXCEPTION
WHEN no_data_found then
ccity := '';
END;

BEGIN
select decode(ref_desc,NULL,' ',ref_desc) into state
from rct
where ref_rec_type = '02'
and ref_code = state
and BANK_ID = '&1';
EXCEPTION
WHEN no_data_found then
cstate := '';
END;


BEGIN
select decode(ref_desc,NULL,' ',ref_desc) into counntry
from rct  where ref_rec_type = '03' and ref_code = country  and BANK_ID = '&1';
EXCEPTION
WHEN no_data_found then
ccity := '';
END;
select br_name, br_addr_1, br_addr_2, br_city_code, br_state_code, br_pin_code into brname, braddr1, braddr2, brc, brs, brpin from bct where br_code=(select br_code from sol where sol_id=otherrec.service_sol_id and BANK_ID = '&1') and bank_code='ICI' and BANK_ID = '&1';
begin
select decode(ref_desc,NULL,' ',ref_desc) into brcity
from rct
    where ref_rec_type = '01'
    and ref_code = brc
    and BANK_ID = '&1';
EXCEPTION
WHEN no_data_found then
brcity := '';
END;

BEGIN
select decode(ref_desc,NULL,' ',ref_desc) into brstate
from rct
where ref_rec_type = '02'
and ref_code = brs
and BANK_ID = '&1';
EXCEPTION
WHEN no_data_found then
brstate := '';
END;

begin
select message, msg_srl_num into msg1, msg1srlnum from msg where b2kid=candrec.dc_b2kid and msg_date=rundate and rownum < 2 order by msg_srl_num and BANK_ID = '&1';
exception when no_data_found then
msg1:='';
msg1srlnum:='999';
end;

begin
select message, msg_srl_num into msg2, msg2srlnum from msg where b2kid=candrec.dc_b2kid and msg_date=rundate and msg_srl_num!=msg1srlnum and rownum < 2 and BANK_ID = '&1' order by msg_srl_num;
exception when no_data_found then
msg2:='';
msg2srlnum:='999';
end;

begin
select message, msg_srl_num into msg3, msg3srlnum from msg where b2kid=candrec.dc_b2kid and msg_date=rundate and msg_srl_num!=msg1srlnum and msg_srl_num!=msg2srlnum and BANK_ID = '&1' and rownum < 2 order by msg_srl_num;
exception when no_data_found then
msg3:='';
msg3srlnum:='999';
end;

begin
select message, msg_srl_num into msg4, msg4srlnum from msg where b2kid=candrec.dc_b2kid and msg_date=rundate and msg_srl_num!=msg1srlnum and msg_srl_num!=msg2srlnum and msg_srl_num!=msg3srlnum and BANK_ID = '&1' and rownum < 2 order by msg_srl_num;
exception when no_data_found then
msg4:='';
msg4srlnum:='999';
end;

begin
select message, msg_srl_num into msg5, msg5srlnum from msg where b2kid=candrec.dc_b2kid and msg_date=rundate and msg_srl_num!=msg1srlnum and msg_srl_num!=msg2srlnum and msg_srl_num!=msg3srlnum and msg_srl_num!=msg4srlnum and BANK_ID = '&1' and rownum < 2 order by msg_srl_num;
exception when no_data_found then
msg5:='';
msg5srlnum:='999';
end;

select name into other_party from nma where addr_id='DCOTPY' and addr_b2kid=candrec.dc_b2kid and BANK_ID = '&1' and rownum<2 and del_flg!='Y';
select decode(custrec.stmt_reqd, 'Y',nvl(custrec.email_id,'ctsu@icicibank.com'),'ctsu@icicibank.com') into emlid from dual;

utl_file.put_line(loc_fp, 'D'||'|'||otherrec.chrg_Tran_id||'|'||otherrec.chrg_tran_date||'|'||otherrec.tran_particular||'|'||candrec.dc_ref_num||'|'||acctnum||'|'||acctname||'|'||otherrec.coll_crncy_code||'|'||candrec.event_type||'|'||otherrec.actual_amt_coll||'|'||custrec.cust_name||'|'||addr_1||'|'||addr_2||'|'||addr_3||'|'||ccntry||'|'||ccity||'|'||cstate||'|'||cpin||'|'||otherrec.service_sol_id||'|'||otherrec.system_calc_amt||'|'||otherrec.tran_rmks||'|'||candrec.dc_chrg_code||'|'||otherrec.event_type||'|'||candrec.actl_crncy_code||'|'||dcvalue||'|'||candrec.rate||'|'||otherrec.chrg_part_tran_srl_num||'|'||otherrec.amt_without_discount||'|'||custrec.cust_title_code||'|'||phone_num_1||'|'||phone_num_2||'|'||emlid||'|'||brname||'|'||braddr1||'|'||braddr2||'|'||brcity||'|'||brstate||'|'||brpin||'|'||msg1||'|'||msg2||'|'||msg3||'|'||msg4||'|'||msg5||'|'||other_party||'|'||candrec.crncy_code||'|'||candrec.event_amt||'|'||candrec.expiry_date||'|'||candrec.open_value||'|'||callrec);


end;
end loop;



end;
end loop;

end;
end loop;
end;
/
exit
