--Rem     This file will create INT_IN_RTGS_MSG_MAS_ADT
--Rem     with the following characteristics.

--Rem TABLE NAME: ICRTGS.INT_IN_RTGS_MSG_MAS_ADT

drop table INT_IN_RTGS_MSG_MAS_ADT
/
create table INT_IN_RTGS_MSG_MAS_ADT
(
 IC_ADT_TRANS_NO                            VARCHAR2(25)NOT NULL ,
 IC_BANK_ID					VARCHAR2(8) NOT NULL,
 IC_ADT_SENDER_INFO                                 VARCHAR2(11),
 IC_ADT_SENDER_LT                                   VARCHAR2(1),
 IC_ADT_SENDER_BRANCH                               VARCHAR2(15),
 IC_ADT_MSG_TYPE                                    VARCHAR2(3),
 IC_ADT_APPL_ID                                     VARCHAR2(6),
 IC_ADT_SENT_DT                                     VARCHAR2(8),
 IC_ADT_SENT_TM                                     VARCHAR2(8),
 IC_ADT_RECV_DT                                     VARCHAR2(8),
 IC_ADT_RECV_TM                                     VARCHAR2(8),
 IC_ADT_SENT_FLAG                                   CHAR(5),
 IC_ADT_REF_NO                                      VARCHAR2(25),
 IC_ADT_MIR                                         VARCHAR2(100),
 IC_ADT_STATUS                                      VARCHAR2(5),
 IC_ADT_PRIORITY                                    VARCHAR2(2),
 IC_ADT_HEADER_DETAILS                              VARCHAR2(300),
 IC_ADT_FILE_NAME                                   VARCHAR2(30),
 IC_ADT_DIR_PATH                                    VARCHAR2(100),
 IC_ADT_RECV_INFO                                   VARCHAR2(11),
 IC_ADT_RECV_LT                                     VARCHAR2(1),
 IC_ADT_RECV_BRANCH                                 VARCHAR2(15),
 IC_ADT_OMH_TRANS_NO                                VARCHAR2(25),
 IC_ADT_FUNCTION                                    VARCHAR2(50),
 IC_ADT_MOD_NO                                      NUMBER(38),
 IC_ADT_BR_CODE                                     VARCHAR2(8),
 IC_ADT_INIT_USER                                   VARCHAR2(16),
 IC_ADT_AUTH_USER                                   VARCHAR2(16),
 IC_ADT_DUPLICATE                                   CHAR(1),
 IC_ADT_PREV_TRANS_NO                               VARCHAR2(32),
 IC_ADT_MOR                                         VARCHAR2(100),
 IC_ADT_TRAILER                                     VARCHAR2(2000),
 IC_ADT_P_FLG                                       CHAR(1),
 IC_ADT_P_DT                                        DATE,
 IC_ADT_PRINT                                       VARCHAR2(1),
 IC_ADT_MOD_USER                                    VARCHAR2(16),
 IC_ADT_CONV_APPL_ID                                VARCHAR2(6),
 IC_ADT_CONV_MSGTYPE                                VARCHAR2(3),
 IC_ADT_OUT_TRANS_NO                                VARCHAR2(16),
 IC_ADT_CONV_STATUS                                 VARCHAR2(3),
 IC_ADT_RETURN_FLG                                  VARCHAR2(2),
 IC_ADT_REASON_CODE                                 VARCHAR2(4),
 IC_ADT_REASON_DESC                                 VARCHAR2(500),
 IC_ADT_RETURN_REF_NO                               VARCHAR2(20),
 IC_ADT_TRAN_ID                                     VARCHAR2(9),
 IC_ADT_PART_TRAN_SRL_NUM                           VARCHAR2(4),
 IC_ADT_RCRE_TIME                                   DATE,
 IC_ADT_LCHG_USER_ID                                VARCHAR2(20),
 IC_ADT_LCHG_TIME                                   DATE,
 IC_ADT_AUTH_TIME                                   DATE,
 IC_ADT_VFD_USER_ID                                 VARCHAR2(20),
 IC_ADT_VFD_DT                                      DATE,
 IC_ADT_RETURN_RMK                                  VARCHAR2(200),
 IC_ADT_FILE_ID                                     VARCHAR2(25),
 IC_ADT_CBS_BENE_NAME                               VARCHAR2(100)
)
/

create index IN_RTGS_MSG_MAS_ADT_01
on INT_IN_RTGS_MSG_MAS_ADT(IC_ADT_TRANS_NO,IC_BANK_ID)
storage ( PCTINCREASE 0 )
/

grant select, insert, update, delete on INT_IN_RTGS_MSG_MAS_ADT to tbagen, tbaadm
/
grant select on INT_IN_RTGS_MSG_MAS_ADT to tbacust
/
grant select on INT_IN_RTGS_MSG_MAS_ADT to tbautil
/
