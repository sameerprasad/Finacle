--===================================================================================================================
--  Filename                :   letters_gradupgrade.sql
--  Description             :   To generate dump of the details of kit accounts that have
--                              been activated for graded customers on a daily basis.
--  Date                    :   04-09-2012
--  Author                  :   Swaroop K Tiruvoipati
--  Menu Option             :
--  Modification History
--    Sl. #           Date           Author                     Modification
--    -----           -----          --------                    ----------------
--    1               29-08-2012     Swaroop K Tiruvoipati      Original Version
--                                                              (Ported from 7.x)
--===================================================================================================================
--  Source          :   letters_gradupgrade.com
--  STR No          :   ICI6140
--  Author          :   Abhilash RB
--  Date            :   27/03/2007
--  Description     :   To generate dump of the details of kit accounts that have
--                      been activated for graded customers on a daily basis.
--  Input           :   letters_gradupgrade.com
--  Output          :   /mistmp1/Letters/gradupgrade.txt

DECLARE
	loc_foracid					gam.foracid%type;
	loc_cust_name				cmg.cust_name%type;
	loc_cust_comu_addr1			cmg.cust_comu_addr1%type;
	loc_cust_comu_addr2			cmg.cust_comu_addr2%type;
	loc_cust_comu_city_code 	cmg.cust_comu_city_code%type;    
	loc_cust_comu_state_code 	cmg.cust_comu_state_code%type;
	loc_cust_comu_pin_code		cmg.cust_comu_pin_code%type;    
	loc_cust_comu_cntry_code	cmg.cust_comu_cntry_code%type;
	loc_cust_stat_code			cmg.cust_stat_code%type;
	loc_cust_comu_phone_num_1	cmg.cust_comu_phone_num_1%type;
	loc_cust_comu_phone_num_2	cmg.cust_comu_phone_num_2%type;

	loc_city_desc         		varchar2(50);
	loc_state_desc      		varchar2(50);
	loc_cntry_desc     			varchar2(50);

	loc_fp               		utl_file.file_type;
	loc_filename         		varchar2(200);
	loc_filemode         		varchar(10);
	loc_filepath         		varchar2(100);

	outpt           			varchar2(1000);
	download					char(1);

CURSOR gradcur IS
SELECT
	c.cif_id
FROM
	ICI_CUST_MOD,cmg c,CRMUSER.ACCOUNTS a
WHERE
	--to_date (UPDATE_DATE, 'DD-MM-YYYY') = (select db_stat_date from gct) --N
	to_date (UPDATE_DATE, 'DD-MM-YYYY') = '&3' 
	AND
	c.cif_id=ICI_CUST_MOD.cif_id 
	and
        ICI_CUST_MOD.BANK_ID = '&4'
        AND
        C.BANK_ID = '&4'
        AND
	a.status_code=NEW_STAT
AND
	NEW_STAT in ('HH1', 'HH2', 'SRC1', 'SRC2', 'HH3', 'SRC3', 'HBRK1', 'HBRK2', 'HBRK3', 'EASY1', 'EASY2', 'EASY3', 'WMN1', 'WMN2', 'WMN3', 'ALSA1', 'ALSA2', 'ALSA3', '1RDA1', '1RDA2', '1RDA3', '1RDA4', '1RDB1', '1RDB2', '1RDB3', '1RDB4', '1RDC1', '1RDC2', '1RDC3', '1RDC4', '1RDD1', '1RDD2', '1RDD3', '1RDD4', '1RDE1', '1RDE2', '1RDE3', '1RDE4', '1RDF1', '1RDF2', '1RDF3', '1RDF4', '2RDA1', '2RDA2', '2RDA3', '2RDA4', '2RDB1', '2RDB2', '2RDB3', '2RDB4', '2RDC1', '2RDC2', '2RDC3', '2RDC4', '2RDD1', '2RDD2' ,'2RDD3', '2RDD4', '2RDE1' ,'2RDE2', '2RDE3', '2RDE4', '2RDF1', '2RDF2', '2RDF3', '2RDF4', '3RDA1', 'HRTD1', 'HANG1', 'HKAR1', 'HRTD2', 'HSHR1', 'HSHR2', 'HKAR2', 'HIDR1', 'HIDR2', 'HUTI1', 'HUTI2', 'HIND1', 'ALS21','ALSP1','HANG2', 'HIND2', 'ALS22', 'ALSP2');
gradrec gradcur%rowtype;

CURSOR cmgcur IS
SELECT
				g.foracid foracid,
				g.cust_name cust_name,
				a.address_line1 cust_comu_addr1,
         			a.address_line2 cust_comu_addr2,
         			a.city_code loc_city_desc,
         			a.state_code loc_state_desc,
         			a.zip cust_comu_pin_code,
         			a.country_code loc_cntry_desc,
				p.phoneno1 cust_comu_phone_num_1,
				p.phoneno2 cust_comu_phone_num_2,
				ac.status_code cust_stat_code	 	
			FROM
				CMG c, GAM g,CRMUSER.ADDRESS a,CRMUSER.ACCOUNTS ac,CRMUSER.phoneemail p
			WHERE
				c.cif_id = gradrec.cif_id
			AND
				c.cif_id = g.cif_id
			AND
				acct_cls_flg <> 'Y' and rownum<2
                        AND
                                c.BANK_ID = '&4'
                        AND 
                                g.BANK_ID = '&4';
cmgrec cmgcur%rowtype;

BEGIN
	loc_filepath := '&1';
	loc_filename := '&2';
	loc_filemode := 'w';
	loc_fp := utl_file.fopen(loc_filepath, loc_filename, loc_filemode);

	open gradcur;
	LOOP
	fetch gradcur into gradrec;
	exit when gradcur%notfound;

		download :=  'Y';
		open cmgcur;
		LOOP
		fetch cmgcur into cmgrec;
		exit when cmgcur%notfound;

		if (download = 'Y') then
			BEGIN
				SELECT
					ref_desc
				INTO
					loc_city_desc
				FROM
					RCT
				WHERE
					 ref_rec_type = '01'
				AND
					ref_code = cmgrec.cust_comu_city_code 
                                AND
                                        RCT.BANK_ID = '&4';
			 EXCEPTION
				when others then
					loc_city_desc := '';
			END;

			BEGIN
				SELECT
					ref_desc
				INTO
					loc_state_desc
				FROM
					rct
				WHERE
					ref_rec_type = '02'
				AND
					ref_code = cmgrec.cust_comu_city_code 
                                AND
                                        RCT.BANK_ID = '&4';
			EXCEPTION
				when others then
					loc_state_desc := '';
			END;

			BEGIN
				SELECT
					ref_desc
				INTO
					loc_cntry_desc
				FROM
					rct
				WHERE
					ref_rec_type = '03'
				AND
					ref_code = cmgrec.cust_comu_cntry_code 
                                AND
                                        RCT.BANK_ID = '&4';
			EXCEPTION
				when others then
					loc_cntry_desc := '';
			END;

			outpt  := cmgrec.foracid                || '|' ||
                      cmgrec.cust_name              || '|' ||
                      cmgrec.cust_comu_addr1        || '|' ||
                      cmgrec.cust_comu_addr2        || '|' ||
                      loc_city_desc              || '|' ||
                      cmgrec.cust_comu_pin_code     || '|' ||
                      loc_state_desc             || '|' ||
                      loc_cntry_desc             || '|' ||
                      cmgrec.cust_comu_phone_num_1  || '|' ||
                      cmgrec.cust_comu_phone_num_2  || '|' ||
                      gradrec.cif_id                || '|' ||
                     cmgrec.cust_stat_code; 

			utl_file.put_line(loc_fp, outpt);
		 END IF;
		END LOOP;
		close cmgcur;
	END LOOP;
		close gradcur;
   utl_file.fclose(loc_fp);    
END;
/
