set verify off
set feedback off
set echo off
set lines 132
set pages 80
set numformat b99,99,99,99,999.99
---------------------------------
rem accept solid prompt 'PLEASE ENTER FOUR DIGIT SOL ID OF REPORT BRANCH : '
rem accept dt1   prompt 'ENTER THE DATE AS ON WHICH THE REPORT IS REQUIRD: '
break on reg_type  on report
compute sum of VALUE on report
set heading off
---------------------------------
set termout off
column br new_value bran
select substr(sol_desc,1,20) br from sol where sol_id = '&1' and bank_id='&3'
--select br_name br from bct where
--br_code = (select br_code from sol
--where sol_id = '&1' );
--------------------------------
spool &1.bills

ttitle on
ttitle center ' ICICI BANKING CORPORATION LTD ' skip 1 -
center bran   ' BRANCH' skip 1 -
center        'SUMMARY OF INLAND BILLS SENT/RECD ON COLLECTION AS ON &2' 

set heading on
select  blt.sol_id,
        blt.reg_type,
        blt.reg_sub_type,
        sum(blt.bill_amt) VALUE
from    blt
where   blt.sol_id='&1'
and     blt.lodg_date <=to_date('&2','dd-mm-yyyy')
and     blt.bill_stat='G'
and     (blt.cls_flg ='N')
and     blt.reg_type in ('IBC','OCC','OBC')
and     blt.sol_id = '&1'
and     bank_id='&3'
group   by blt.sol_id,blt.reg_type,blt.reg_sub_type
/
ttitle  off
break   on reg_type  on report
compute sum of VALUE on report
set     heading off
ttitle  on
ttitle  center ' ICICI BANKING CORPORATION LTD ' skip 1 -
center  bran ' BRANCH' skip 1 -
center  'LIABILITY OF INLAND BILLS RECD ON COLLECTION FROM OUR BRANCHES AS ON  &2' skip 1 -

set     heading on
select  lpad(blt.lodg_coll_br_code,4,'0') BR_CODE,
        sum(blt.bill_amt) VALUE
from    blt,bct
where   blt.sol_id='&1'
and     blt.lodg_date <=to_date('&2','dd-mm-yyyy')
and     blt.bill_stat='G'
and     (blt.cls_flg ='N')
and     blt.reg_type ='IBC'
and     blt.lodg_coll_br_code = bct.br_code
and     bct.bank_code = (select bank_code from bkc
                         where bank_code='ICI' and bank_id='&3')
and     blt.sol_id = '&1'
and     blt.bank_id='&3' 
and     bct.bank_id='&3'
group   by blt.lodg_coll_br_code
/
ttitle  off
break   on reg_type on reg_sub_type on report
compute sum of VALUE on report
set     heading off
ttitle  on
ttitle  center ' ICICI BANKING CORPORATION LTD ' skip 1 -
center  bran ' BRANCH' skip 1 -
center  'LIABILITY OF INLAND BILLS SENT ON COLLECTION TO OUR BRANCHES AS ON &2' skip 1 - 

set heading on
select  lpad(blt.lodg_coll_br_code,4,'0') BR_CODE,
        sum(blt.bill_amt) VALUE
from    blt,bct
where   blt.sol_id='&1'
and     blt.lodg_date <=to_date('&2','dd-mm-yyyy')
and     blt.bill_stat='G'
and     (blt.cls_flg ='N')
and     blt.reg_type in ( 'OCC','OBC')
and     blt.lodg_coll_br_code = bct.br_code
and     bct.bank_code = (select bank_code from bkc
                         where bank_code='ICI' and bank_id='&3')
and     blt.sol_id = '&1'
and     blt.bank_id='&3'
and     bct.bank_id='&3'
group   by blt.lodg_coll_br_code
/
spool off
exit
