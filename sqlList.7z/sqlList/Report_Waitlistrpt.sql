----------------------------------------------------------------------------------------------------
--   Source Name            : Report_Waitlistrpt.sql 
--   Description            : Locker Wait List Report 
--   Input Values           : sol_id,bank_id
--   Output Values          : None
--   Called Script          : N.A
--   Calling Script         : N.A
--   Modification History:
--   Sl No.         Date              Author                     Description
--   --------------------------------------------------------------------------------------
--     01         15-Apr-2013         Khalid                 Original Version
----------------------------------------------------------------------------------------------------

set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_Waitlistrpt.lst

DECLARE

lv_solid         tbaadm.gam.sol_id%type :='&1';
--lv_solid          VARCHAR2(50):='&1';
--lv_bank_id        VARCHAR2(50):= '&2';
lv_bank_id       tbaadm.gam.bank_id%type := '&2';

CURSOR c1 IS
SELECT
        sol_id,substr(cust_name,1,20) cust_name,
        WAITLIST_NO,cif_id,DECODE(PRIOR_FLG,'1','1-HIGHEST','2','2-HIGH','3','3-MEDIUM','4','4-LOW') PRIOR_FLG,
	    LOCKER_TYPE,LOCKWAIT_DATE 
FROM
        CLWT 
WHERE
        SOL_ID = lv_solid
AND     status is null   
AND     DEL_FLG != 'Y'
AND     ENTITY_CRE_FLG = 'Y'
AND     BANK_ID = lv_bank_id
--AND     LOCKWAIT_DATE >= sysdate
order by waitlist_no,Locker_type,prior_flg,lockwait_date; 


BEGIN

    for f1 in c1
    loop

        dbms_output.put_line(   f1.sol_id               ||'|'||
                                f1.cif_id       	    ||'|'||
                                f1.cust_name       		||'|'||
                                f1.WAITLIST_NO          ||'|'||
                                f1.PRIOR_FLG            ||'|'||
                                f1.LOCKER_TYPE	        ||'|'||
								f1.LOCKWAIT_DATE
                            );
        end loop;
--	EXCEPTION WHEN NO_DATA_FOUND THEN

END;
/
spool off

