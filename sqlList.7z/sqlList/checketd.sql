--===================================================================================================================
--	Filename	        :	checketd.sql
--      Description             :       checketd.sql       
--      Date                    :       05-SEP-2012
--      Author                  : 	Tulasi
--      Menu Option          	: 	interface/CMS Download
--	Modification History
--    Sl. #           Date             Author             Modification                              
--    -----           -----            --------	       ----------------                               
--    01              05-09-2012       Tulasi	      Original Version                          
--===================================================================================================================

set verify off feedback off pages 0 lines 200 trims on
spool /icicicust/custlog/avrk/cmsstmt/etd
select count(1) from etd where bank_id='&1';
spool off

