--------------------------------------------
--File Name   : Report_excepacc.sql
--Description : Exceptional Access report
--Author      : Priyanka
--Date        : 06-10-2012
--------------------------------------------
set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_excepacc.lst

DECLARE

V_SOLID                    CLMT.SOL_ID%TYPE := '&1';
V_FRMDT                    varchar2(25) := '&2';
V_TODT                     varchar2(25) := '&3';
V_BANKID                CLMT.BANK_ID%TYPE :='&4';
V_PRE_DATE_ACCESS       NUMBER:=0;
V_SIGN                  NUMBER:=0;
V_OVERDUE               NUMBER:=0;
V_REASON                VARCHAR2(20):='';
V_LOCK_NO               VARCHAR2(12):='';
V_LOCKER_NO             VARCHAR2(12):='';
v_checktime                varchar2(20):='';

CURSOR C1 IS
select  lcops.sol_id,
        wlckm.RACK_ID,
        clmt.CIF_ID custid,
        lcops.CIF_ID,
        lcops.LOCKER_no,
        lcops.check_date,
        lcops.CHECK_IN_TIME,
        JH_ID_1,
        JH_ID_2,
        JH_ID_3,
        JH_ID_4,
        JH_ID_5,
        JH_ID_6,
        LOA_ID_1,
        LOA_ID_2,
        LOA_ID_3,
        LOA_ID_4,
        LOA_ID_5,
        LOA_ID_6,
        substr(CUST_NAME,1,40) cust_name,
        substr(JH_NAME_1,1,40) JH_NAME_1,
        substr(JH_NAME_2,1,40) JH_NAME_2,
        substr(JH_NAME_3,1,40) JH_NAME_3,
        substr(JH_NAME_4,1,40) JH_NAME_4,
        substr(JH_NAME_5,1,40) JH_NAME_5,
        substr(JH_NAME_6,1,40) JH_NAME_6,
        substr(LOA_NAME_1,1,40) LOA_NAME_1,
        substr(LOA_NAME_2,1,40) LOA_NAME_2,
        substr(LOA_NAME_3,1,40) LOA_NAME_3,
        substr(LOA_NAME_4,1,40) LOA_NAME_4,
        substr(LOA_NAME_5,1,40) LOA_NAME_5,
        substr(LOA_NAME_6,1,40) LOA_NAME_6
from    lcops,wlckm,clmt
where   wlckm.LOCKER_NUM = lcops.LOCKER_NO
and     wlckm.LOCKER_NUM = clmt.LOCKER_NUM
and     clmt.LOCKER_NUM = lcops.LOCKER_NO
and     wlckm.sol_id = lcops.sol_id
and     wlckm.sol_id = clmt.sol_id
and     lcops.sol_id = v_solid
and     clmt.bank_id = wlckm.bank_id
and     lcops.bank_id = clmt.bank_id
and     clmt.bank_id = v_bankid
and      lcops.check_date between to_date(v_frmdt,'dd-mm-yyyy') and to_date(v_todt,'dd-mm-yyyy')
and     wlckm.del_flg!='Y'
and     lcops.del_flg!='Y'
and     clmt.del_flg!='Y'
order by 6,7;

BEGIN

FOR F1 IN C1
LOOP

    v_locker_no := f1.locker_no;
    v_checktime := f1.check_date||'/'||f1.check_in_time;

    BEGIN
    --{
            SELECT 
                    COUNT(1) 
            INTO     
                    V_PRE_DATE_ACCESS 
            FROM 
                    LCOPS 
            WHERE 
                    (LCOPS.REASON !='' OR LCOPS.REASON !=' ') 
            AND     LOCKER_NO = V_LOCKER_NO
            AND     SOL_ID = F1.SOL_ID
            AND        CHECK_DATE = F1.check_date
            AND        check_in_time = F1.check_in_time
            AND        DEL_FLG != 'Y';
            EXCEPTION WHEN NO_DATA_FOUND THEN
            V_PRE_DATE_ACCESS := null;
    --}
    END;

    IF(V_PRE_DATE_ACCESS > '0') THEN
    --{
            V_REASON := 'PRE DATED ACCESS';

            IF((F1.CIF_ID != '') OR (F1.CIF_ID != ' ')) THEN
            --{
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.CIF_ID      ||'|'||
                                            'HIRER'            ||'|'||
                                            F1.CUST_NAME    ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;

            IF((F1.JH_ID_1 != '') OR (F1.JH_ID_1 != ' ')) THEN
            --{
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.JH_ID_1      ||'|'||
                                            'HIRER'            ||'|'||
                                            F1.JH_NAME_1    ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;

            IF((F1.JH_ID_2 != '') OR (F1.JH_ID_2 != ' ')) THEN
            --{
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.JH_ID_2      ||'|'||
                                            'HIRER'            ||'|'||
                                            F1.JH_NAME_2    ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;

            IF((F1.JH_ID_3 != '') OR (F1.JH_ID_3 != ' ')) THEN
            --{
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.JH_ID_3      ||'|'||
                                            'HIRER'            ||'|'||
                                            F1.JH_NAME_3    ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;

            IF((F1.JH_ID_4 != '') OR (F1.JH_ID_4 != ' ')) THEN
            --{
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.JH_ID_4      ||'|'||
                                            'HIRER'            ||'|'||
                                            F1.JH_NAME_4    ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;

            IF((F1.JH_ID_5 != '') OR (F1.JH_ID_5 != ' ')) THEN
            --{
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.JH_ID_5      ||'|'||
                                            'HIRER'            ||'|'||
                                            F1.JH_NAME_5    ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;

            IF((F1.JH_ID_6 != '') OR (F1.JH_ID_6 != ' ')) THEN
            --{
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.JH_ID_6      ||'|'||
                                            'HIRER'            ||'|'||
                                            F1.JH_NAME_6    ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;

            IF((F1.LOA_ID_1 != '') OR (F1.LOA_ID_1 != ' ')) THEN
            --{
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.LOA_ID_1     ||'|'||
                                            'POA'            ||'|'||
                                            F1.LOA_NAME_1   ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;

            IF((F1.LOA_ID_2 != '') OR (F1.LOA_ID_2 != ' ')) THEN
            --{
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.LOA_ID_2     ||'|'||
                                            'POA'            ||'|'||
                                            F1.LOA_NAME_2   ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;

            IF((F1.LOA_ID_3 != '') OR (F1.LOA_ID_3 != ' ')) THEN
            --{
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.LOA_ID_3     ||'|'||
                                            'POA'            ||'|'||
                                            F1.LOA_NAME_3   ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;

            IF((F1.LOA_ID_4 != '') OR (F1.LOA_ID_4 != ' ')) THEN
            --{
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.LOA_ID_4     ||'|'||
                                            'POA'            ||'|'||
                                            F1.LOA_NAME_4   ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;

            IF((F1.LOA_ID_5 != '') OR (F1.LOA_ID_5 != ' ')) THEN
            --{
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.LOA_ID_5     ||'|'||
                                            'POA'            ||'|'||
                                            F1.LOA_NAME_5   ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;

            IF((F1.LOA_ID_6 != '') OR (F1.LOA_ID_6 != ' ')) THEN
            --{
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.LOA_ID_6     ||'|'||
                                            'POA'            ||'|'||
                                            F1.LOA_NAME_6   ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;
    --}
    END IF;


    IF((F1.CIF_ID != '') OR (F1.CIF_ID != ' ')) THEN
    --{
            BEGIN
            --{
                    SELECT 
                            COUNT(1) 
                    INTO 
                            V_SIGN 
                    FROM 
                            IMT 
                    WHERE 
                            IMT.CIF_ID = LPAD(F1.CIF_ID,9,' ') 
                    AND     DEL_FLG != 'Y'
                    AND     ENTITY_CRE_FLG = 'Y';
                    EXCEPTION WHEN NO_DATA_FOUND THEN
                    V_SIGN := null;
            --}
            END;

            IF(V_SIGN < '1') THEN
            --{
                    V_REASON := 'SIGNATURE NOT MAPPED';
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.CIF_ID      ||'|'||
                                            'HIRER'            ||'|'||
                                            F1.CUST_NAME    ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;
    --}
    END IF;

    IF((F1.JH_ID_1 != '') OR (F1.JH_ID_1 != ' ')) THEN
    --{
            BEGIN
            --{
                    SELECT
                            COUNT(1)
                    INTO
                            V_SIGN
                    FROM
                            IMT
                    WHERE
                            IMT.CIF_ID = LPAD(F1.JH_ID_1,9,' ')
                    AND     DEL_FLG != 'Y'
                    AND     ENTITY_CRE_FLG = 'Y';
                    EXCEPTION WHEN NO_DATA_FOUND THEN
                    V_SIGN := null;
            --}
            END;

            IF(V_SIGN < '1') THEN
            --{
                    V_REASON := 'SIGNATURE NOT MAPPED';
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.JH_ID_1      ||'|'||
                                            'HIRER'            ||'|'||
                                            F1.JH_NAME_1    ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;
    --}
    END IF;

    IF((F1.JH_ID_2 != '') OR (F1.JH_ID_2 != ' ')) THEN
    --{
            BEGIN
            --{
                    SELECT
                            COUNT(1)
                    INTO
                            V_SIGN
                    FROM
                            IMT
                    WHERE
                            IMT.CIF_ID = LPAD(F1.JH_ID_2,9,' ')
                    AND     DEL_FLG != 'Y'
                    AND     ENTITY_CRE_FLG = 'Y';
                    EXCEPTION WHEN NO_DATA_FOUND THEN
                    V_SIGN := null;
            --}
            END;

            IF(V_SIGN < '1') THEN
            --{
                    V_REASON := 'SIGNATURE NOT MAPPED';
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.JH_ID_2      ||'|'||
                                            'HIRER'            ||'|'||
                                            F1.JH_NAME_2    ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;
    --}
    END IF;

    IF((F1.JH_ID_3 != '') OR (F1.JH_ID_3 != ' ')) THEN
    --{
            BEGIN
            --{
                    SELECT
                            COUNT(1)
                    INTO
                            V_SIGN
                    FROM
                            IMT
                    WHERE
                            IMT.CIF_ID = LPAD(F1.JH_ID_3,9,' ')
                    AND     DEL_FLG != 'Y'
                    AND     ENTITY_CRE_FLG = 'Y';
                    EXCEPTION WHEN NO_DATA_FOUND THEN
                    V_SIGN := null;
            --}
            END;

            IF(V_SIGN < '1') THEN
            --{
                    V_REASON := 'SIGNATURE NOT MAPPED';
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.JH_ID_3      ||'|'||
                                            'HIRER'            ||'|'||
                                            F1.JH_NAME_3    ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;
    --}
    END IF;

    IF((F1.JH_ID_4 != '') OR (F1.JH_ID_4 != ' ')) THEN
    --{
            BEGIN
            --{
                    SELECT
                            COUNT(1)
                    INTO
                            V_SIGN
                    FROM
                            IMT
                    WHERE
                            IMT.CIF_ID = LPAD(F1.JH_ID_4,9,' ')
                    AND     DEL_FLG != 'Y'
                    AND     ENTITY_CRE_FLG = 'Y';
                    EXCEPTION WHEN NO_DATA_FOUND THEN
                    V_SIGN := null;
            --}
            END;

            IF(V_SIGN < '1') THEN
            --{
                    V_REASON := 'SIGNATURE NOT MAPPED';
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.JH_ID_4      ||'|'||
                                            'HIRER'            ||'|'||
                                            F1.JH_NAME_4    ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;
    --}
    END IF;

    IF((F1.JH_ID_5 != '') OR (F1.JH_ID_5 != ' ')) THEN
    --{
            BEGIN
            --{
                    SELECT
                            COUNT(1)
                    INTO
                            V_SIGN
                    FROM
                            IMT
                    WHERE
                            IMT.CIF_ID = LPAD(F1.JH_ID_5,9,' ')
                    AND     DEL_FLG != 'Y'
                    AND     ENTITY_CRE_FLG = 'Y';
                    EXCEPTION WHEN NO_DATA_FOUND THEN
                    V_SIGN := null;
            --}
            END;

            IF(V_SIGN < '1') THEN
            --{
                    V_REASON := 'SIGNATURE NOT MAPPED';
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.JH_ID_5      ||'|'||
                                            'HIRER'            ||'|'||
                                            F1.JH_NAME_5    ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;
    --}
    END IF;

    IF((F1.JH_ID_6 != '') OR (F1.JH_ID_6 != ' ')) THEN
    --{
            BEGIN
            --{
                    SELECT
                            COUNT(1)
                    INTO
                            V_SIGN
                    FROM
                            IMT
                    WHERE
                            IMT.CIF_ID = LPAD(F1.JH_ID_6,9,' ')
                    AND     DEL_FLG != 'Y'
                    AND     ENTITY_CRE_FLG = 'Y';
                    EXCEPTION WHEN NO_DATA_FOUND THEN
                    V_SIGN := null;
            --}
            END;

            IF(V_SIGN < '1') THEN
            --{
                    V_REASON := 'SIGNATURE NOT MAPPED';
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.JH_ID_6      ||'|'||
                                            'HIRER'            ||'|'||
                                            F1.JH_NAME_6    ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;
    --}
    END IF;

    IF((F1.LOA_ID_1 != '') OR (F1.LOA_ID_1 != ' ')) THEN
    --{
            BEGIN
            --{
                    SELECT
                            COUNT(1)
                    INTO
                            V_SIGN
                    FROM
                            IMT
                    WHERE
                            IMT.CIF_ID = LPAD(F1.LOA_ID_1,9,' ')
                    AND     DEL_FLG != 'Y'
                    AND     ENTITY_CRE_FLG = 'Y';
                    EXCEPTION WHEN NO_DATA_FOUND THEN
                    V_SIGN := null;
            --}
            END;

            IF(V_SIGN < '1') THEN
            --{
                    V_REASON := 'SIGNATURE NOT MAPPED';
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.LOA_ID_1     ||'|'||
                                            'POA'            ||'|'||
                                            F1.LOA_NAME_1   ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;
    --}
    END IF;

    IF((F1.LOA_ID_2 != '') OR (F1.LOA_ID_2 != ' ')) THEN
    --{
            BEGIN
            --{
                    SELECT
                            COUNT(1)
                    INTO
                            V_SIGN
                    FROM
                            IMT
                    WHERE
                            IMT.CIF_ID = LPAD(F1.LOA_ID_2,9,' ')
                    AND     DEL_FLG != 'Y'
                    AND     ENTITY_CRE_FLG = 'Y';
                    EXCEPTION WHEN NO_DATA_FOUND THEN
                    V_SIGN := null;
            --}
            END;

            IF(V_SIGN < '1') THEN
            --{
                    V_REASON := 'SIGNATURE NOT MAPPED';
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.LOA_ID_2     ||'|'||
                                            'POA'            ||'|'||
                                            F1.LOA_NAME_2   ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;
    --}
    END IF;

    IF((F1.LOA_ID_3 != '') OR (F1.LOA_ID_3 != ' ')) THEN
    --{
            BEGIN
            --{
                    SELECT
                            COUNT(1)
                    INTO
                            V_SIGN
                    FROM
                            IMT
                    WHERE
                            IMT.CIF_ID = LPAD(F1.LOA_ID_3,9,' ')
                    AND     DEL_FLG != 'Y'
                    AND     ENTITY_CRE_FLG = 'Y';
                    EXCEPTION WHEN NO_DATA_FOUND THEN
                    V_SIGN := null;
            --}
            END;

            IF(V_SIGN < '1') THEN
            --{
                    V_REASON := 'SIGNATURE NOT MAPPED';
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.LOA_ID_3     ||'|'||
                                            'POA'            ||'|'||
                                            F1.LOA_NAME_3   ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;
    --}
    END IF;

    IF((F1.LOA_ID_4 != '') OR (F1.LOA_ID_4 != ' ')) THEN
    --{
            BEGIN
            --{
                    SELECT
                            COUNT(1)
                    INTO
                            V_SIGN
                    FROM
                            IMT
                    WHERE
                            IMT.CIF_ID = LPAD(F1.LOA_ID_4,9,' ')
                    AND     DEL_FLG != 'Y'
                    AND     ENTITY_CRE_FLG = 'Y';
                    EXCEPTION WHEN NO_DATA_FOUND THEN
                    V_SIGN := null;
            --}
            END;

            IF(V_SIGN < '1') THEN
            --{
                    V_REASON := 'SIGNATURE NOT MAPPED';
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.LOA_ID_4     ||'|'||
                                            'POA'            ||'|'||
                                            F1.LOA_NAME_4   ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;
    --}
    END IF;

    IF((F1.LOA_ID_5 != '') OR (F1.LOA_ID_5 != ' ')) THEN
    --{
            BEGIN
            --{
                    SELECT
                            COUNT(1)
                    INTO
                            V_SIGN
                    FROM
                            IMT
                    WHERE
                            IMT.CIF_ID = LPAD(F1.LOA_ID_5,9,' ')
                    AND     DEL_FLG != 'Y'
                    AND     ENTITY_CRE_FLG = 'Y';
                    EXCEPTION WHEN NO_DATA_FOUND THEN
                    V_SIGN := null;
            --}
            END;

            IF(V_SIGN < '1') THEN
            --{
                    V_REASON := 'SIGNATURE NOT MAPPED';
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.LOA_ID_5     ||'|'||
                                            'POA'            ||'|'||
                                            F1.LOA_NAME_5   ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;
    --}
    END IF;

    IF((F1.LOA_ID_6 != '') OR (F1.LOA_ID_6 != ' ')) THEN
    --{
            BEGIN
            --{
                    SELECT
                            COUNT(1)
                    INTO
                            V_SIGN
                    FROM
                            IMT
                    WHERE
                            IMT.CIF_ID = LPAD(F1.LOA_ID_6,9,' ')
                    AND     DEL_FLG != 'Y'
                    AND     ENTITY_CRE_FLG = 'Y';
                    EXCEPTION WHEN NO_DATA_FOUND THEN
                    V_SIGN := null;
            --}
            END;

            IF(V_SIGN < '1') THEN
            --{
                    V_REASON := 'SIGNATURE NOT MAPPED';
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.LOA_ID_6     ||'|'||
                                            'POA'            ||'|'||
                                            F1.LOA_NAME_6   ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;
    --}
    END IF;


    BEGIN
    --{
            SELECT 
                    COUNT(1)
            INTO 
                    V_OVERDUE
            FROM 
                    LCPP
            WHERE 
                    (LCPP.RENT_PAYABLE_AMOUNT - LCPP.RENT_PAID_AMOUNT) > 0 
            AND     LOCKER_NUMBER = V_LOCKER_NO
            AND        CIF_ID = F1.custid
            AND        SOL_ID = F1.SOL_ID
            AND     DEL_FLG != 'Y';
            EXCEPTION WHEN NO_DATA_FOUND THEN
            V_OVERDUE := null;
    --}
    END;

    IF(V_OVERDUE > '0') THEN
    --{
               V_REASON := 'OVERDUE LOCKER';

            IF((F1.CIF_ID != '') OR (F1.CIF_ID != ' ')) THEN
            --{
                       DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                               F1.SOL_ID       ||'|'||
                                               F1.RACK_ID      ||'|'||
                                               F1.CIF_ID      ||'|'||
                                            'HIRER'            ||'|'||
                                               F1.CUST_NAME    ||'|'||
                                               v_checktime  ||'|'||
                                               V_REASON
                                        );
            --}
            END IF;

            IF((F1.JH_ID_1 != '') OR (F1.JH_ID_1 != ' ')) THEN
            --{
                       DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.JH_ID_1      ||'|'||
                                            'HIRER'            ||'|'||
                                            F1.JH_NAME_1    ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;

            IF((F1.JH_ID_2 != '') OR (F1.JH_ID_2 != ' ')) THEN
            --{
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.JH_ID_2      ||'|'||
                                            'HIRER'            ||'|'||
                                            F1.JH_NAME_2    ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;

            IF((F1.JH_ID_3 != '') OR (F1.JH_ID_3 != ' ')) THEN
            --{
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.JH_ID_3      ||'|'||
                                            'HIRER'            ||'|'||
                                            F1.JH_NAME_3    ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;

            IF((F1.JH_ID_4 != '') OR (F1.JH_ID_4 != ' ')) THEN
            --{
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.JH_ID_4      ||'|'||
                                            'HIRER'            ||'|'||
                                            F1.JH_NAME_4    ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;

            IF((F1.JH_ID_5 != '') OR (F1.JH_ID_5 != ' ')) THEN
            --{
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.JH_ID_5      ||'|'||
                                            'HIRER'            ||'|'||
                                            F1.JH_NAME_5    ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;


            IF((F1.JH_ID_6 != '') OR (F1.JH_ID_6 != ' ')) THEN
            --{
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.JH_ID_6      ||'|'||
                                            'HIRER'            ||'|'||
                                            F1.JH_NAME_6    ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;

            IF((F1.LOA_ID_1 != '') OR (F1.LOA_ID_1 != ' ')) THEN
            --{
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                               F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.LOA_ID_1     ||'|'||
                                            'POA'            ||'|'||
                                            F1.LOA_NAME_1   ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;

            IF((F1.LOA_ID_2 != '') OR (F1.LOA_ID_2 != ' ')) THEN
            --{
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.LOA_ID_2     ||'|'||
                                            'POA'            ||'|'||
                                            F1.LOA_NAME_2   ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;


            IF((F1.LOA_ID_3 != '') OR (F1.LOA_ID_3 != ' ')) THEN
            --{
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.LOA_ID_3     ||'|'||
                                            'POA'            ||'|'||
                                            F1.LOA_NAME_3   ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;

            IF((F1.LOA_ID_4 != '') OR (F1.LOA_ID_4 != ' ')) THEN
            --{
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.LOA_ID_4     ||'|'||
                                            'POA'            ||'|'||
                                            F1.LOA_NAME_4   ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;

            IF((F1.LOA_ID_5 != '') OR (F1.LOA_ID_5 != ' ')) THEN
            --{
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.LOA_ID_5     ||'|'||
                                            'POA'            ||'|'||
                                            F1.LOA_NAME_5   ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;

            IF((F1.LOA_ID_6 != '') OR (F1.LOA_ID_6 != ' ')) THEN
            --{
                    DBMS_OUTPUT.PUT_LINE(   V_LOCKER_NO     ||'|'||
                                            F1.SOL_ID       ||'|'||
                                            F1.RACK_ID      ||'|'||
                                            F1.LOA_ID_6     ||'|'||
                                            'POA'            ||'|'||
                                            F1.LOA_NAME_6   ||'|'||
                                            v_checktime  ||'|'||
                                            V_REASON
                                        );
            --}
            END IF;

    --}
    END IF;

END LOOP;
END;
/
spool off

