set serveroutput on size 1000000
set feedback off
set verify off
set linesize 500
set trims on
set echo off
set termout off
set numformat 999D09
spool dbDate.dat

DECLARE
dbDate                        ICI.zone_date%TYPE;
l_bank_id		     VARCHAR2(8) := '&1';

BEGIN--{

		select to_date(db_stat_date,'DD-MM-YYYY') into dbDate from gct where bank_id = l_bank_id;
			dbms_output.put_line(dbDate);
END;--}
/
spool off
set termout on
