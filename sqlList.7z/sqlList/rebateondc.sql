set serveroutput on size 100000
set feedback off
set echo off
set termout off
set verify off 
set linesi 132
rem clear scr
rem accept sol_id prompt " ENTER VALUE FOR SOL_ID :"
rem accept date prompt  " ENTER THE DATE OF REPORT :"
spool &1.rebateondc
DECLARE
dc_type 		dcrm.inw_out_dc_ind%type;
dc_num			dcmm.dc_ref_num%type;
cur_amt			dcmm.current_value%type;
bill_lodg_amt	dcmm.bill_lodg_amt%type;
charges 		dcmm.bill_lodg_amt%type;
char_charges	varchar(20);
char_rebate		varchar(20);
char_chrg_sum	varchar(20);
char_rebate_sum	varchar(20);
chrg_sum 		dcmm.bill_lodg_amt%type;
rebate  		dcmm.bill_lodg_amt%type;
rebate_sum  	dcmm.bill_lodg_amt%type;
avail_amt		dcmm.current_value%type;
avail_amt1		dcmm.current_value%type;
last_neg_date	dcmm.last_ship_date%type;
cntry_code		rct.ref_code%type;
cntry_desc 		RCT.ref_desc%type;
all_details		varchar(800);
tmp_cnt1		number(2);
step			number(2);
output_flg		varchar(2);
CURSOR dcmmcur is
SELECT
dc_ref_num,dc_b2kid,dc_reg_type,
expiry_date,date_opnd,open_value
actl_tolerance_pcnt,dc_nobill_util_amt,
dc_nobill_fruct_amt,interest_addtnl_amt,
advance_value,current_value,dc_reinst_amt,confirmed_flg
FROM DCMM
where  ( date_clsd > to_date('&2','dd-mm-yyyy') or date_clsd is null)
and date_opnd < to_date('&2','dd-mm-yyyy')
and sol_id ='&1'
and bank_id= '&3'
and current_value > '0'
and ( expiry_date > to_date('&2','dd-mm-yyyy'));
BEGIN
chrg_sum:=0;
rebate_sum:=0;

dbms_output.put_line('.'||'                                      ICICI BANK LIMITED          ');
dbms_output.put_line(' SOL_ID:=  '||'&1');
dbms_output.put_line('****************************************************************************************');
dbms_output.put_line(' DC_REF_NUM        OPEN DATE     EXPIRY DATE             CHARGES                 REBATE');
dbms_output.put_line('****************************************************************************************');


for dcmmcur_rec in DCMMCUR LOOP --{
if (dcmmcur%notfound)
then
exit;
end if;
output_flg:=null;
tmp_cnt1:=0;
dcmmcur_rec.dc_nobill_util_amt:= nvl(dcmmcur_rec.dc_nobill_util_amt,0);
dcmmcur_rec.dc_nobill_fruct_amt:=nvl(dcmmcur_rec.dc_nobill_fruct_amt,0);
dcmmcur_rec.advance_value:=nvl(dcmmcur_rec.advance_value,0);
dcmmcur_rec.dc_reinst_amt:=nvl(dcmmcur_rec.dc_reinst_amt,0);
dcmmcur_rec.interest_addtnl_amt:= nvl(dcmmcur_rec.interest_addtnl_amt,0);
dc_num:=dcmmcur_rec.dc_ref_num;
select inw_out_dc_ind
        into dc_type
        from DCRM
        where reg_type=dcmmcur_rec.dc_reg_type;
if(dc_type ='I') --{
then
	if (dcmmcur_rec.confirmed_flg='Y') --{
	then
		output_flg:='Y';
	end if; --}
end if;--}
if (dc_type='O')
then
output_flg:='Y';
end if;
if (output_flg is not null)
then
SELECT
nvl(sum(event_amt),0)
into bill_lodg_amt
from DCEM
where dc_b2kid=dcmmcur_rec.dc_b2kid
and event_type='G'
and event_date < to_date('&2','dd-mm-yyyy')
and bank_id = '&3';
cur_amt:= dcmmcur_rec.current_value * ( 1 + dcmmcur_rec.actl_tolerance_pcnt/100);
SELECT ceil(cur_amt)
into cur_amt
from dual;
avail_amt:=cur_amt - dcmmcur_rec.dc_nobill_util_amt - dcmmcur_rec.dc_nobill_fruct_amt
	  		- dcmmcur_rec.advance_value  + dcmmcur_rec.dc_reinst_amt  +
           dcmmcur_rec.interest_addtnl_amt - bill_lodg_amt;
avail_amt:=floor(avail_amt);
avail_amt1:=avail_amt + bill_lodg_amt;
avail_amt1:=floor(avail_amt1);
step:=2;
SELECT
nvl(sum(actual_amt_coll),0)
into charges
from cxl
where comp_b2kid_type  = 'DOCCR'
and substr(comp_b2kid,1,12) like '%'||dcmmcur_rec.dc_b2kid||'%'
and chrg_acid in (select acid from gam where bacid in ('CNFLC','CNLC-ISSUE'))
and  chrg_tran_date < to_date('&2','dd-mm-yyyy')
and bank_id = '&3';
rebate:=avail_amt/avail_amt1;
rebate:=rebate * charges * (dcmmcur_rec.expiry_date - to_date('&2','dd-mm-yyyy') ) /( dcmmcur_rec.expiry_date -dcmmcur_rec.date_opnd);
rebate:=ceil(rebate);
charges:=ceil(charges);
char_charges:=lpad(to_char(charges,'999G99G990D99','NLS_NUMERIC_CHARACTERS = ''.,'''),15);
char_rebate:=lpad(to_char(rebate,'999G99G990D99','NLS_NUMERIC_CHARACTERS = ''.,'''),15);
all_details:= dcmmcur_rec.dc_ref_num||'	'||dcmmcur_rec.date_opnd||'	'||dcmmcur_rec.expiry_date||'	'||char_charges||'		'||char_rebate;
dbms_output.put_line(all_details);
chrg_sum:= chrg_sum + charges;
rebate_sum:= rebate_sum + rebate;
end if;
end loop;--}
char_chrg_sum:=lpad(to_char(chrg_sum,'9999G99G990D99','NLS_NUMERIC_CHARACTERS = ''.,'''),15);
char_rebate_sum:=lpad(to_char(rebate_sum,'9999G99G990D99','NLS_NUMERIC_CHARACTERS = ''.,'''),15);


dbms_output.put_line('****************************************************************************************');
dbms_output.put_line('SUM                                             '||char_chrg_sum||'         '||char_rebate_sum);
dbms_output.put_line('****************************************************************************************');

EXCEPTION WHEN NO_DATA_FOUND
              THEN
             DBMS_OUTPUT.PUT_LINE('NO DATA FOUND at step   '||step);
        WHEN OTHERS THEN
               DBMS_OUTPUT.PUT_LINE('!!!! CHECK SQL ERROR, AND TRY AGAIN !!!'||dc_num);
              DBMS_OUTPUT.PUT_LINE('SQL ERROR CODE IS        : ' || SQLCODE );
             DBMS_OUTPUT.PUT_LINE('SQL ERROR DESCRIPTION IS : '|| SQLERRM);
end;
/
spool off
exit;
