---------------------------------------------------------------------------------
-- Filename         :pbkRunDate.sql
-- Description      : Sql File to get date for statement generation from gct table 
-- Date             : 27-11-2012
-- Author           : Aparna Ashok
-- Menu Option      : pbkDailyRun.com
-- Modification History
-- Sl.#       Date           Author         Modification                              
-- -----   ----------   --------------    ----------------                               
--  1.0    21-11-2012   Aparna Ashok    Original Version                          
----------------------------------------------------------------------------------------------







set head off
set echo off
set trims on
set pagesize 1000
spool pbkRun
select to_char(DB_STAT_DATE-1,'DD-MM-YYYY') FROM GCT;
spool off
