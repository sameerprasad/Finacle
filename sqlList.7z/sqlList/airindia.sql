----------------------------------------------------------------------------------------------------------------------------
--       Script Name                    : airindia.sql
--       Description                     : spools out the data from the icici_alert_reg table to airindia.lst file
--       Author                              : Khalid Sabeeh
--       Date                                   : 06-11-2012 
--       Input Values                    :    -
--       Output Values                :    -
--       Called Scripts                  :    -
--       Calling Scripts                 :    airindia.com
--       Reference                        :    -
--       Modification History
--       S.No            Date            	Author          	Description
--       ----            ------                  	------          		-----------
--       1.00            06-11-2012         Khalid Sabeeh          	Changes made for 10X
-----------------------------------------------------------------------------------------------------------------------------


set pagesize 0
set trimspool on
set head off
set feedback off
set termout off
set verify off
spool airindia
select * from icici_alert_reg where foracid='000405025237'
and del_flg = 'Y'
/
spool off
