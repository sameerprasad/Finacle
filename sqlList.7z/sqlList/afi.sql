-- date 29-07-2008  Eldo  STR 6669 CIB Migration
set head off echo off feedback off termout off verify off pause off
set pages 0 lines 80

spool &1
select substr(RMKS,1,20),AUDIT_DATE,TABLE_NAME,ENTERER_ID,AUTH_ID,MODIFIED_FIELDS_DATA
from adt where bank_id='&2' and acid =
(select acid from gam where foracid='&1' and bank_id='&2')
and (rmks is null or rmks not in ('ACCOUNT AUTHORIZED AND NEW NUMBER ASSIGNED IS &1',
                 'RECORD CANCELLED',
					  'Record Cancelled'))
order by audit_date
/
select substr(RMKS,1,20),AUDIT_DATE,TABLE_NAME,ENTERER_ID,AUTH_ID,MODIFIED_FIELDS_DATA
from adt where bank_id='&2' and table_name = 'CMG' and table_key=(select cust_id from gam where foracid='&1' and bank_id='&2')
order by audit_date
/
select substr(RMKS,1,20),AUDIT_DATE,TABLE_NAME,ENTERER_ID,AUTH_ID,MODIFIED_FIELDS_DATA
from adt where bank_id='&2' and table_name = 'BDT' and table_key=(select cust_id from gam where foracid='&1' and bank_id='&2')
order by audit_date
/
spool off
