set echo off
set trims on
set head off
set pages 0
set lines 200
set verify off
spool suspected_anytran.txt
select to_char(REQ_TIME,'dd-mm-yy HH24:MI'),
REQ_ID,
SUC_FAIL_FLG,
 PROCESS_FLG,
 TRAN_ID,
amount ,
 RESCODE,
 REC_STATUS,
USERID,
 VERIFYUID,
 POSTUID,
 LOC_FIRST,
LOCAL_FORACID,
REMOTE_FORACID,
SUBSTR ( RESPONSE, 3 , 3 )
from ICI_ANY_TRAN_DETAIL
where
REQ_TIME >= ( select db_stat_date from gct where bank_id ='&1')
and rec_status  = 'S'
and
((substr  ( response , 3, 3 ) = '000' and tran_id is  null ) or
 (substr  ( response , 3, 3 ) is null   and tran_id is not null ) or
(substr  ( response , 3, 3 )!= '000' and  tran_id is not null) )
and not exists (select 'x' from dtd
                where acid = ( select acid from gam where foracid = LOCAL_FORACID and bank_id = '&1')
               and tran_amt = amount
and tran_particular like '%'||to_char(to_number(req_id))||'%'
              and del_flg != 'Y' and bank_id ='&1')
and BANK_ID = '&1'
/
exit
