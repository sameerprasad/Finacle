--===================================================================================================================
--Filename             :  ecomtr.sql
--Description          :  This is the sql for menu BJSTM21.             
--Date                 :  20-09-2012
--Author               :  Vaibhav Bansal
--Menu Option          :  BJSTM21
--Modification History
--    Sl. #             Date             Author             Modification                              
--    -----            -----            --------           ---------------- 
--    01              20-09-2012       Vaibhav Bansal       Coding Standard Changes                          
--===================================================================================================================
set head off
set pages 64
set lines 132
set wrap off
set newpage 0
set space 0
set feedback on
rem set termout off
set pause off
column suffix new_value suffix
column dc new_value dc
column today new_value dt
column branch new_value br
break on SOL.sol_id on TYPE skip 2 on report
compute sum of AMT on TYPE
compute sum of AMT on SOL.sol_id
compute sum of AMT on report
SELECT to_char(db_stat_date,'ddmmyyyy') suffix FROM tbaadm.GCT WHERE bank_id = '&1';
SELECT to_char(db_stat_date,'dd/mm/yyyy') today FROM tbaadm.GCT WHERE bank_id = '&1';
SELECT br_name branch FROM tbaadm.BCT WHERE br_code IN (SELECT br_code FROM tbaadm.SOL WHERE bank_id = '&1') AND bank_id = '&1';
SELECT dc_alias dc FROM tbaadm.GCT WHERE bank_id = '&1';
set head on
spool EBACRDR&dc&suffix
ttitle center 'ICICI BANK LTD.' skip 1 -
center br skip 1 -
center  'Details of Transactions for DCC : E-Broking Centre on :' dt skip 1 
column AMT heading 'AMT   ' format 99,99,99,99,999.00
column TYPE heading 'Dr/Cr ' format a6
column VD heading Value_Dt format a11
SELECT SOL.sol_id,tran_date ,value_date ,tran_id,tran_amt AMT,part_tran_type TYPE, substr(tran_particular,1,26) DETAILS,substr(ref_num,1,15) REF_NUM,vfd_user_id AUTHORISER,GAM.foracid FROM tbaadm.DTD,tbaadm.GAM,tbaadm.SOL
WHERE DTD.del_flg!='Y' AND DTD.acid=GAM.aCid
AND dtd.tran_id IN (SELECT distinct tran_id FROM tbaadm.DTD WHERE acid = (SELECT distinct acid FROM tbaadm.GAM WHERE foracid LIKE '00%SLECMTR%' AND bank_id = '&1')
AND bank_id = '&1')
AND GAM.foracid NOT LIKE '00%SLECMTR%' AND GAM.bank_id = 'ICICI01' AND GAM.bank_id = DTD.bank_id AND GAM.bank_id = SOL.bank_id
ORDER BY 1,2,6
/
spool off
exit
