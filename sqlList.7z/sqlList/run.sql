@CreateMenu_CMRPT.sql
@CreateMenu_CSCRLINQ.sql
@CreateMenu_FWCADVP.sql
@CreateMenu_HEXCHQ.sql
@CreateMenu_CMGMOD_new.sql
