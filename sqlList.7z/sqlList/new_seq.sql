drop sequence icici.FI_UBUS_SRL_ID;

create sequence icici.FI_UBUS_SRL_ID
start with 11111
maxvalue 999999999999999999
minvalue 1
nocycle
nocache
noorder;

grant alter, select on icici.FI_UBUS_SRL_ID  to tbaadm;

grant alter, select on icici.FI_UBUS_SRL_ID  to tbagen;

grant alter, select on icici.FI_UBUS_SRL_ID  to tbautil;
