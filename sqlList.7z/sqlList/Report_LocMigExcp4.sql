----------------------------------------------------------------------------------------------------
--   Source Name            : Report_LocMigExcp4.sql 
--   Description            : Locker Migration Exceptions Report.
--   Input Values           : None
--   Output Values          : None
--   Called Script          : N.A
--   Calling Script         : N.A
--   Modification History:
--   Sl No.         Date              Author                     Description
--   --------------------------------------------------------------------------------------
--     01         18-Oct-2012         Priyanka                 Original Version
----------------------------------------------------------------------------------------------------

set serveroutput on size 1000000
set lines 2000
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_LocMigExcp4.lst

Declare

v_sol_id            wlckm.sol_id%type:='&1';
v_bank_id        wlckm.bank_id%type := '&2';
v_solid             wlckm.sol_id%type;
v_rack_id           lcmig.rack_id%type;
v_locker_number     lcmig.locker_number%type;
v_key_number        lcmig.key_number%type;
v_locker_type       lcmig.locker_type%type;
v_issue_date        lcmig.issue_date%type;
v_due_date          lcmig.due_date%type;
v_renewal_date      lcmig.renewal_date%type;
v_arrear_rent       lcmig.arrear_rent%type; 
v_rent_amt          lcmig.rent_amt%type;
v_disc_rent_amt     lcmig.disc_rent_amt%type;
v_discount_amount   lcmig.discount_amount%type;
v_dperiod_from      lcmig.dperiod_from %type;
v_dperiod_to        lcmig.dperiod_to%type;
v_last_access_date  lcmig.last_access_date%type;
v_iss_month          number;
v_due_month            number;
v_ren_month          number;

cursor Loc1 is
   SELECT distinct SOL_ID,LOCKER_NUMBER 
   FROM LCMIG 
   WHERE SOL_ID = v_sol_id
   and bank_id = v_bank_id
   and del_flg ='N';

cursor Loc2(v_sol_id varchar2,v_locker_number number) is
    SELECT sol_id,rack_id,locker_number,key_number,locker_type,issue_date,due_date,renewal_date,arrear_rent,
    rent_amt,disc_rent_amt,discount_amount,dperiod_from,dperiod_to,last_access_date
    FROM lcmig
    WHERE SOL_ID = v_sol_id 
    and LOCKER_NUMBER = v_locker_number
    and bank_id = v_bank_id
    and del_flg ='N';    
   

begin
for i in Loc1
loop
--{
    open Loc2(i.SOL_ID,i.LOCKER_NUMBER);
    loop
    --{
        fetch Loc2 into v_solid,v_rack_id,v_locker_number,v_key_number,v_locker_type,v_issue_date,v_due_date,v_renewal_date,v_arrear_rent,
        v_rent_amt,v_disc_rent_amt,v_discount_amount,v_dperiod_from,v_dperiod_to,v_last_access_date;

        if Loc2%NOTFOUND then
        --{
            close Loc2;
            exit;
        --}
        end if;
                
                select substr(to_char(v_issue_date,'dd-mm-yyyy'),4,2),substr(to_char(v_due_date,'dd-mm-yyyy'),4,2),substr(to_char(v_renewal_date,'dd-mm-yyyy'),4,2) into v_iss_month,
                v_due_month,v_ren_month from dual; 
    
            if(v_iss_month != v_due_month or v_iss_month != v_ren_month or v_due_month != v_ren_month)then
                
                dbms_output.enable(buffer_size => NULL);
                dbms_output.put_line(v_solid              ||'|'||
                                     v_rack_id            ||'|'||  
                                     v_locker_number      ||'|'||
                                     v_key_number         ||'|'||
                                     v_locker_type        ||'|'||
                                     v_issue_date         ||'|'||
                                     v_due_date           ||'|'||
                                     v_renewal_date       ||'|'||
                                     v_arrear_rent        ||'|'|| 
                                     v_rent_amt           ||'|'||
                                     v_disc_rent_amt      ||'|'||
                                     v_discount_amount    ||'|'||
                                     v_dperiod_from       ||'|'||
                                     v_dperiod_to         ||'|'||
                                     v_last_access_date);                    
           end if;         
    --}
    end loop;
--}
end loop;
end;
/
spool off

