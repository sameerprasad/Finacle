set head off
set pages 0
set termout off
set feedback off
--set echo off
set linesize 300
set pagesize 300
set verify off
spool  &1..soltest.dat
--spool test.txt
--select rtrim(sol_id)||'|'||br_name||'|'||br_addr_1||'|'||br_addr_2||'|'||a.ref_desc ||'|'||b.ref_desc ||'|' from tbaadm.sol,tbaadm.bct,tbaadm.rct a, tbaadm.rct b where sol.del_flg !='Y' and sol.bank_code = bct.bank_code  and sol.br_code=bct.br_code and a.ref_rec_type='01' and a.ref_code = bct.br_city_code and b.ref_rec_type='02' and b.ref_code = bct.br_state_code;

--select rtrim(sol_id)||'|'||br_name||'|'||br_addr_1||'|'||br_addr_2||'|'||a.ref_desc ||'|'||b.ref_desc ||'|' from tbaadm.sol,tbaadm.bct,tbaadm.rct a,tbaadm.rct b  where sol.del_flg !='Y' and sol.bank_code = bct.bank_code  and sol.br_code=bct.br_code and a.ref_rec_type='01' and a.ref_code = bct.br_city_code and b.ref_rec_type='02' and b.ref_code = bct.br_state_code;	

select rtrim(sol_id)||'|'||br_name||'|'||br_addr_1||'|'||br_addr_2||'|'||a.ref_desc ||'|'||b.ref_desc ||'|'
from tbaadm.sol,tbaadm.bct,rct a, rct b where sol.del_flg !='Y' and sol.bank_code = bct.bank_code  
and sol.br_code=bct.br_code and a.ref_rec_type='01' 
and a.ref_code = bct.br_city_code and b.ref_rec_type='02' 
and b.ref_code = bct.br_state_code;
/
spool off
