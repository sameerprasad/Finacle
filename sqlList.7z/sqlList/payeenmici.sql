/* Formatted on 2012/09/13 17:08 (Formatter Plus v4.8.8) */
SET serveroutput on size 1000000
SET feedback off
SET verify off
SET linesize 500
SET trims on
SET termout off
SET numformat 999D09
spool &1-&2-&3-&7..dat


DECLARE
   particular    TBAADM.ctd.tran_particular%TYPE;
   loc_acid      gam.foracid%TYPE;
   custstat      CRMUSER.cmg.cust_stat_code%TYPE;
   INSTR         TBAADM.ctd.instrmnt_num%TYPE;
   dummy         NUMBER;
   solid         ici.sol_id%TYPE;
   trandate      ici.zone_date%TYPE;
   zoneid        ici.zone_code%TYPE;
   recnotfound   NUMBER;
   recfnd        NUMBER;
   dtdfound      NUMBER;
   dbdate        ici.zone_date%TYPE;
   l_bank_id     VARCHAR2(8) := '&8';

   

   CURSOR cur_zone
   IS
      SELECT zone_code, zone_date, acid, zone_srl_num, tran_particulars,
             inst_num, inst_amt, tran_rmks
        FROM ici
       WHERE sol_id = solid AND zone_code = zoneid AND zone_date = trandate and ici.bank_id = l_bank_id;
BEGIN                                                                      --{
   solid := '&5';
   
   trandate := '&4';
   zoneid := '&6';
   dtdfound := 0;
   recfnd := 0;

--              select to_char(db_stat_date,'DD-MM-YYYY') into dbDate from gct ;
   FOR cur_zone_rec IN cur_zone
   LOOP                                                                   --{
      recnotfound := 0;
      loc_acid := '';

      IF (recfnd = 0)
      THEN
         DBMS_OUTPUT.put_line ('PNM');
--              dbms_output.put_line('Sol '||'|'||'ZoneCode'||'|'||'Zone Date'||'|'||'|'||'Srl No.'||'|'||'Acid'||'|'||'Foracid'||'|'||'Number'||'|'||'Amount'||'|'||'Payee Name'||'|'||'Customer Status');
      END IF;

      recfnd := recfnd + 1;

      BEGIN                                                                --{
         SELECT gam.foracid, cmg.cust_stat_code
           INTO loc_acid, custstat
           FROM gam, CRMUSER.cmg
          WHERE gam.acid = cur_zone_rec.acid
            AND gam.acct_ownership != 'O'
            AND gam.cust_id = cmg.cust_id and gam.bank_id = l_bank_id and cmg.bank_id = l_bank_id;
            
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            recnotfound := 1;
      END;                                                                      --}

      IF (recnotfound = 0)
      THEN
         DBMS_OUTPUT.put_line (   solid
                               || '|'
                               || cur_zone_rec.zone_code
                               || '|'
                               || cur_zone_rec.zone_date
                               || '|'
                               || cur_zone_rec.zone_srl_num
                               || '|'
                               || cur_zone_rec.acid
                               || '|'
                               || loc_acid
                               || '|'
                               || cur_zone_rec.inst_num
                               || '|'
                               || TO_CHAR (cur_zone_rec.inst_amt,
                                           '99999999999.99'
                                          )
                               || '|'
                               || cur_zone_rec.tran_particulars
                               || '|'
                               || custstat
                              );
      END IF;

      recnotfound := 0;
   END LOOP;                                                               --}
END;                                                                       --}
/

spool off
SET termout on


