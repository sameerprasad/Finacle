set serveroutput on
set pages 0
set verify off
set feedback off
set termout off
set lines 200
set trimspool on
spool '&1..csv'

DECLARE

party_acct_no varchar(100);
ccil_acct_no varchar(100);
ccil_remain_amt  number(20,2);
effAmtCcil number(20,2);
sftCnt number(5,2);
serialNo varchar(10);
loc_tran_type	varchar(1);
loc_dr_cr	varchar(1);
mnemonic varchar(10);
segment varchar(10);
sfamt number(20,2);
visited char(1):='N';
seq integer :=0;

cursor alert is
select 
tran_date,CCIL_FORACID,to_char(TRAN_DATE,'dd-mm-yyyy~hh24:mi:ss') tran_date_hhmiss, BENF_FORACID,tran_type,nvl(TRAN_PARTICULAR,' ') TRAN_PARTICULAR,OBLIG_AMT,FILE_SEQ,TRAN_SEQ,MNEMONIC,SEGMENT,FILE_NAME from ICI_CCIL_REP where GEN_FLG='N' order by to_char(TRAN_DATE,'dd-mm-yyyy~hh24:mi:ss');


begin


for i in alert
loop
---{
if (visited = 'N') then

 select count(1) into seq from ICI_CCIL_REP where GEN_FLG='Y' and tran_date=i.TRAN_DATE;
select EFFECTIVE_AVIL_BAL into effAmtCcil from ici_ccil where upper(file_name) = upper(i.FILE_NAME) and CUST_NAME like 'CCIL%';	
visited :='Y';

        if (i.tran_type ='C') then

                effAmtCcil := effAmtCcil + i.OBLIG_AMT;
        else
                effAmtCcil := effAmtCcil - i.OBLIG_AMT;
        end if;
else
	if (i.tran_type ='C') then

		effAmtCcil := effAmtCcil + i.OBLIG_AMT;
	else
		effAmtCcil := effAmtCcil - i.OBLIG_AMT;
	end if;
end if;
SEQ := SEQ +1;

if (effAmtCcil < 0 ) then

        effAmtCcil := 0;
end if;

dbms_output.put_line(i.tran_date  ||','||
                     trim(i.CCIL_FORACID) ||','||
                     i.tran_date_hhmiss  ||','||
                     i.BENF_FORACID ||','||
                     i.tran_type ||','||
		     trim(to_char(i.OBLIG_AMT,99999999999999999990.99)) || ',' ||
		     trim(to_char(effAmtCcil,99999999999999999990.99))|| ',' ||
		     i.mnemonic || ',' ||
		     i.TRAN_PARTICULAR|| ',' ||to_char(i.tran_date,'YYYYMMDD')||'_'||lpad(to_char(i.TRAN_SEQ),5,'0')||','||i.segment);

update ICI_CCIL_REP set GEN_FLG='Y' where TRAN_SEQ=i.TRAN_SEQ AND BANK_ID = '&2';
commit;

---}
end loop;
end;
/
spool off
