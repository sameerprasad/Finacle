--------------------------------------------
--File Name   : Report_nomcancel.sql 
--Description : Nomination cancellation report 
--Author      : Priyanka
--Date        : 09-10-2012
------------------------------------------

set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_nomcancel.lst

DECLARE

lv_solid         gam.sol_id%type :='&1';
lv_bankid        clmt.bank_id%type := '&2';

CURSOR c1 IS
select distinct clnd.sol_id,
clnd.nominee_no,
clnd.cif_id,
cmg.cust_name,
clnd.locker_num,
wlckm.rack_id,
clmt.LOCKER_TYPE,
clnd.nominee_name,
clnd.nominee_add1,
clnd.nominee_add2,
clnd.nominee_stat_code,
clnd.nominee_city_code,
clnd.nominee_cntry_code,
clnd.nominee_pin_code,
clnd.date_of_birth,
clnd.nominee_relation,
clnd.DATE_OF_NOMINATION Nomination_date,
substr(clnd.LCHG_TIME,1,10) Cancellation_date
from    clnd, wlckm, cmg, clmt
where   wlckm.locker_num = clnd.locker_num
and	clmt.locker_num = wlckm.locker_num
and     clmt.locker_num = clnd.locker_num
and     cmg.cif_id = clnd.cif_id
and	clmt.sol_id = clnd.sol_id
and	clnd.sol_id = wlckm.sol_id
and     clnd.sol_id = lv_solid
and     clmt.bank_id = clnd.bank_id
and     clnd.bank_id = wlckm.bank_id
and     clnd.bank_id = lv_bankid
and     clnd.del_flg!='N'
and     clmt.del_flg!='Y'
union
select distinct clnd.sol_id,
clnd.nominee_no,
clnd.cif_id,
cmg.cust_name,
clnd.locker_num,
wlckm.rack_id,
clmt.LOCKER_TYPE,
clnd.nominee_name,
clnd.nominee_add1,
clnd.nominee_add2,
clnd.nominee_stat_code,
clnd.nominee_city_code,
clnd.nominee_cntry_code,
clnd.nominee_pin_code,
clnd.date_of_birth,
clnd.nominee_relation,
clnd.DATE_OF_NOMINATION Nomination_date,
substr(clnd.LCHG_TIME,1,10) Cancellation_date
from    clnd, wlckm, cmg, clmt,cljh
where    wlckm.locker_num = clnd.locker_num
and      clmt.locker_num = wlckm.locker_num
and      clmt.locker_num = clnd.locker_num
and      clmt.locker_num = cljh.locker_num
and      clmt.cif_id = cljh.cif_mh_id
and      cljh.cif_jh_id = clnd.cif_id
and      cmg.cif_id = clnd.cif_id
and      clmt.sol_id = clnd.sol_id
and      clnd.sol_id = wlckm.sol_id
and      clmt.sol_id = cljh.sol_id
and      clnd.sol_id = lv_solid
and      clmt.bank_id = clnd.bank_id
and      clnd.bank_id = wlckm.bank_id
and      clmt.bank_id = cljh.bank_id
and      clnd.bank_id = lv_bankid
and      clnd.del_flg!='N'
and      cljh.del_flg!='Y'
and      clmt.del_flg!='Y'
order by 2,4;

BEGIN

    for f1 in c1
    loop
        dbms_output.enable(buffer_size => NULL);
        dbms_output.put_line(f1.sol_id             ||'|'||
                             f1.nominee_no         ||'|'||
                             f1.cif_id             ||'|'||
			     f1.cust_name          ||'|'||
			     f1.locker_num         ||'|'||
			     f1.rack_id            ||'|'||
			     f1.locker_type        ||'|'||
			     f1.nominee_name       ||'|'||
			     f1.nominee_add1       ||'|'||
			     f1.NOMINEE_ADD2       ||'|'||
			     f1.NOMINEE_STAT_CODE  ||'|'||
			     f1.NOMINEE_CITY_CODE  ||'|'||
			     f1.NOMINEE_CNTRY_CODE ||'|'||
			     f1.NOMINEE_PIN_CODE   ||'|'||
			     f1.DATE_OF_BIRTH      ||'|'||
			     f1.NOMINEE_RELATION   ||'|'||
                             f1.Nomination_date    ||'|'||
                             f1.Cancellation_date);    
   end loop; 
END;
/
spool off

