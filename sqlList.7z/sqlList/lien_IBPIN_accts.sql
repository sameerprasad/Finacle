
set serveroutput on  size 1000000
set head off feedback off verify off echo off 
set linesize 132

spool lien_IBPIN

select 'Cust id | Account no. | Name of customer  | Lien code | Effective balance|Lien amount | User id ' from dual
/



DECLARE
eff_avail_bal			eab.tran_date_bal%type;
testop				varchar2(20000);


CURSOR lien_cur IS
SELECT distinct	alt.acid,
		alt.lien_amt,
		alt.lien_reason_code,
		alt.b2k_type,
		alt.rcre_user_id,
		alt.lien_expiry_date
  FROM ALT
 WHERE lien_reason_code = 'IBPIN'
   AND ALT.ENTITY_CRE_FLG ='Y'
   AND ALT.del_flg <> 'Y'
   AND bank_id='&2';

CURSOR gam_cur (facid gam.acid%type) IS
SELECT	gam.clr_bal_amt,
		gam.lien_amt,
		gam.cust_id,
		gam.foracid,
		gam.acct_name
  FROM GAM
 WHERE acid = facid and bank_id='&2';

BEGIN

FOR A IN lien_cur
LOOP
	FOR B IN gam_cur(A.acid)
	LOOP

		eff_avail_bal := B.clr_bal_amt - B.lien_amt ;

		IF eff_avail_bal  >=  0 THEN
			testop :=
						B.cust_id		||'|'||
					    B.foracid		||'|'||
						B.acct_name		||'|'||
						A.lien_reason_code	||'|'||
						eff_avail_bal	||'|'||
						A.lien_amt		||'|'||
					trim(A.rcre_user_id)
					;
		dbms_output.put_line(testop);
		END IF;
	END LOOP;
		testop :='';
END LOOP;
END;
/
spool off
