set verify off
set feedback off
set termout off
set serveroutput on size 100000
set pagesize 60
set linesize 80

spool oaeod.txt
DECLARE

	v_amt gam.clr_bal_amt%TYPE;
	v_excp varchar2(3);
	v_mesg1 varchar2(19);
	v_mesg2 varchar2(19);
	v_cnt1 number(3) := 0;
	v_cnt2 number(3) := 0;

cursor c1 is 
select foracid,sol_id,clr_bal_amt BAL_AMT from gam where SCHM_CODE='OAEOD' and sol_id='&1'
and clr_bal_amt <> 0 and bank_id = '&2';

	c1_rec c1%ROWTYPE;

BEGIN
	DBMS_OUTPUT.PUT_LINE('.                                                        ');
	DBMS_OUTPUT.PUT_LINE('            Report of EOD Account Exceptions in &1      ');
	DBMS_OUTPUT.PUT_LINE('.                                                        ');
	DBMS_OUTPUT.PUT_LINE('-----------------------------------------------------------------');  
	DBMS_OUTPUT.PUT_LINE('Account Name | Sol id | Exception Code             |    BAL AMT  ');  
	DBMS_OUTPUT.PUT_LINE('-----------------------------------------------------------------');
	OPEN c1;
	LOOP
	FETCH c1 INTO c1_rec;
	EXIT WHEN c1%NOTFOUND;
	IF c1_rec.bal_amt > 0 THEN
		v_excp:='672';
		v_mesg1:='ACT BAL > MIN BAL';
		v_cnt1:=v_cnt1 + 1;
		DBMS_OUTPUT.PUT_LINE(c1_rec.foracid||' |  '||c1_rec.sol_id||'  |  '||v_excp||' |  '||v_mesg1||'  |  '||c1_rec.bal_amt);
    ELSIF c1_rec.bal_amt < 0 THEN
		v_excp:='662';
		v_mesg2:='ACT BAL < MIN BAL';
		v_cnt2:=v_cnt2 + 1;
		DBMS_OUTPUT.PUT_LINE(c1_rec.foracid||' |  '||c1_rec.sol_id||'  |  '||v_excp||' |  '||v_mesg2||'  |  '||c1_rec.bal_amt);
    END IF;
	END LOOP;
	v_excp:=NULL;
	CLOSE c1;
	DBMS_OUTPUT.PUT_LINE('-----------------------------------------------------------------');
	DBMS_OUTPUT.PUT_LINE('Total No. of Accounts with the exception code 662 :  '||v_cnt2);
	DBMS_OUTPUT.PUT_LINE('Total No. of Accounts with the exception code 672 :  '||v_cnt1);
	DBMS_OUTPUT.PUT_LINE('-----------------------------------------------------------------');
	EXCEPTION
		WHEN NO_DATA_FOUND THEN
		DBMS_OUTPUT.PUT_LINE('Exception ');
END;
/
spool off
