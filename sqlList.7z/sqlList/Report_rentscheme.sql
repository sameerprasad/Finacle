--------------------------------------------
--File Name   : Report_rentscheme.sql
--Description : Locker Rent Scheme Report
--Author      : Priyanka
--Date        : 04-10-2012
------------------------------------------

set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_rentscheme.lst

DECLARE

lv_solid         gam.sol_id%type :='&1';
lv_date          varchar2(30) :='&2';
lv_bank_id       varchar2(30) :='&3';

CURSOR c1 IS

SELECT
        WLPM.SOL_ID,
        WLCKM.RACK_ID,
        WLPM.LOCKER_TYPE,
        WLPM.LOCKER_NUM,
        WLPM.CIF_ID,
        substr(CMG.CUST_NAME,1,25) CUST_NAME,
        WLPM.SCHM_TYPE,
        CLMT.RENT_AMT,
        (SELECT COALESCE(DISC_METHOD1,DISC_METHOD2,DISC_METHOD3) FROM WLSM WHERE SCHEME_NAME = WLPM.SCHM_TYPE) METHOD,
        WLPM.DISC_AMT,
        WLPM.SREASON,
        WLPM.SREMARKS
FROM
        CLMT,WLPM,WLCKM,CMG
WHERE
        CLMT.LOCKER_NUM = WLPM.LOCKER_NUM
AND     CLMT.LOCKER_NUM = WLCKM.LOCKER_NUM
AND     CLMT.SOL_ID = WLPM.SOL_ID
AND     WLPM.CIF_ID = CLMT.CIF_ID
AND     CMG.CIF_ID  = WLPM.CIF_ID
AND     CLMT.BANK_ID = WLPM.BANK_ID
AND     WLCKM.BANK_ID = WLPM.BANK_ID
AND     CMG.BANK_ID = CLMT.BANK_ID
AND     CLMT.BANK_ID = lv_bank_id
AND     WLPM.SOL_ID= lv_solid
AND     WLPM.SCHM_TYPE IS NOT NULL
AND     to_date(lv_date,'dd-mm-yyyy') BETWEEN SPERIOD_FROM AND SPERIOD_TO
AND     CLMT.DEL_FLG != 'Y'
AND     WLPM.DEL_FLG != 'Y'
AND     WLCKM.DEL_FLG != 'Y'
AND     CLMT.ENTITY_CRE_FLG = 'Y'
AND     WLPM.ENTITY_CRE_FLG = 'Y'
AND     WLCKM.ENTITY_CRE_FLG = 'Y'
ORDER BY LOCKER_NUM;

BEGIN

    for f1 in c1

    loop
    dbms_output.enable(buffer_size => NULL);
    dbms_output.put_line(    f1.sol_id         ||'|'||
                              f1.rack_id        ||'|'||
                              f1.locker_type    ||'|'||
                              f1.locker_num     ||'|'||
                              f1.cif_id        ||'|'||
                              f1.cust_name      ||'|'||
                              f1.SCHM_TYPE      ||'|'||
                              f1.RENT_AMT       ||'|'||
                              f1.METHOD          ||'|'||
                              f1.DISC_AMT       ||'|'||
                              f1.SREASON        ||'|'||
                              f1.SREMARKS
                        );
                    
       end loop; 
END;
/
spool off

