set serveroutput on size 1000000
set feedback off
set verify off
set linesize 500
set pages 0
set trims on
set termout off
set numformat 999D09
spool &2
select distinct '01^639'||'^'||substr(b.BSR_CODE,length(b.bsr_code)-3,4)||'^'||to_char(a.cheque_dep_date,'yy^mm^dd')||'^'||'C'||'^'||substr(a.cin_no,length(a.cin_no)-4,5)||'^'||substr(a.ASSESSMENT_YEAR,0,4)||'^'||a.MAJOR_TAX_HEAD||'^'||a.MINOR_TAX_HEAD||'^'||decode(a.pan_tan_flg,'P','^'||a.pan_tan_no,a.pan_tan_no||'^')||'^'||a.name||'^'||a.ADDRESS1||'^'||a.ADDRESS2||'^'||a.ADDRESS3||'^'||a.ADDRESS4||'^'||a.city||'^'||f.STATE_CODE||'^'||a.pin||'^'||a.NATURE_OF_PAYMENT||'^'||decode(a.BASE_AMOUNT,'0','',a.BASE_AMOUNT)||'^'||decode(a.SURCHARGE,'0','',a.SURCHARGE)||'^'||decode(a.EDUCATION_CESS,'0','',a.EDUCATION_CESS)||'^'||decode(a.INTEREST_AMOUNT,'0','^','INTE^'||a.INTEREST_AMOUNT)||'^'||a.PENALTY_CODE||'^'||decode(a.PENALTY_AMOUNT,'0','',a.PENALTY_AMOUNT)||'^'||decode(a.OTHERS,'0','^','OTHR^'||a.OTHERS)||'^'||a.ADDITIONAL_CODE_FIELD||'^'||decode(a.ADDITIONAL_AMOUNT_FIELD,'0','',a.ADDITIONAL_AMOUNT_FIELD)||''||'^'||a.CHALLAN_AMOUNT||'^'||decode(a.MAJOR_TAX_HEAD,'0020','C','0021','I','0023','H','0024','N','0028','O','0031','E','0032','W','0033','G','0026','F','0036','B','0034','S',' ')||c.CBDT_SCROLL||'^'||decode(e.tax_tran_type,'L','G',e.tax_tran_type)||'^'||to_char(a.realisation_date,'ddmmyy')||'^'||to_char(a.realisation_date,'ddmmyy')||'^722'||d.ZAO_CODE||'^'||decode(a.MAJOR_TAX_HEAD,'0020','C','0021','I','0023','H','0024','N','0028','O','0031','E','0032','W','0033','G','0026','F','0036','B','0034','S')||g.CBDT_SCROLL||'^'||to_char(a.realisation_date,'ddmmyy')
from ici_gbm_challan_master a,ici_gbm_bsrcode b,ICI_GBM_SOL_SCOLL_HISTORY c,icici_gbm_trn_hdr e,ici_gbm_territory f,ICI_GBM_SOL_SCOLL_HISTORY g,ici_gbm_nodal_master d
where c.SCR_DATE=a.realisation_date and c.sol_id=e.sol_id and b.sol_id=e.sol_id and e.tax_tran_id=a.tax_tran_id and e.tax_tran_date = a.tax_tran_date and (e.tax_type='C' or e.tax_type='c')and a.realisation_date ='&1' and a.del_flg='N' and f.STATE_NAME= a.STATE and c.COMMI_CODE='000' and g.SCR_DATE=a.realisation_date and g.sol_id in (select parent_sol_id from ici_gbm_terminal_master where sol_id=a.sol_id and scheme_code='0004') and g.COMMI_CODE='101' and d.sol_id in (select parent_sol_id from ici_gbm_terminal_master where sol_id=a.sol_id and scheme_code='0004') and  d.scheme_code='0004'
/
spool off
