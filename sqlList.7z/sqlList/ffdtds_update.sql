#===============================================================================
#Source Name            :  ffdtds_update.sql
#Description            :  SQL to update mod table
#Input Values           :  None
#Output Values          :  None
#Called Scripts         :  None
#Calling Scripts        :  None
#Modification history:
#    Sl. No       Date        Author            Description
#    ------   ----------   -----------   ------------------------------
#      1      15-10-2012    Divya           SQL to update mod table
#===============================================================================
set define off;

UPDATE tbaadm.mod
SET
MOP_TYPE = 'U',
EXE_NAME='_https://$W/$A/',
INPUT_FILENAME = 'tdswps/tdswps_ctrl.jsp?sessionid=$S', ADDITIONAL_PARAMS='&sectok=$T&finsessionid=$S&fabsessionid=$C&mo=HTDSWPS&mtype=F' WHERE MOP_ID='FFDTDS'
/

commit

/

