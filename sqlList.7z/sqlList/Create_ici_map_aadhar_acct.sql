---Rem     This file will create ici_map_aadhar_acct 
---Rem     with the following characteristics.

---Rem TABLE NAME: ICICI.ici_map_aadhar_acct_tbl

---Rem SYNONYM: ici_map_aadhar_acct

drop table ICICI.ici_map_aadhar_acct_tbl
/
drop public synonym ici_map_aadhar_acct
/
create table ICICI.ici_map_aadhar_acct_tbl
(
FORACID			VARCHAR2(16),
CIF_ID			VARCHAR2(9),
AADHAR_NO		VARCHAR2(12),
LCHG_TIME		DATE,
LCHG_USER_ID		VARCHAR2(15),
RCRE_TIME		DATE,
RCRE_USER_ID		VARCHAR2(15),
BANK_ID			VARCHAR2(9)
)
/

create public synonym ici_map_aadhar_acct
	for ICICI.ici_map_aadhar_acct_tbl
/

grant select, insert, update, delete on ICICI.ici_map_aadhar_acct_tbl to tbagen
/
grant select, insert, update, delete on ICICI.ici_map_aadhar_acct_tbl to tbautil
/
grant select, insert, update, delete on ICICI.ici_map_aadhar_acct_tbl to tbaadm
/
