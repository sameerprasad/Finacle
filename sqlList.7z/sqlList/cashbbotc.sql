-- =====================================================================================================================
-- Source Name            :  cashbbotc.sql
-- Description            :  PACKAGE cashbbotc. To avoid FTS on PST table, sol_id criteria is added
-- Input Values           :  None
-- Output Values          :  None
-- Called Scripts         :  None
-- Calling Scripts        :  None
-- Modification history:
-- Sl. No            Date                 Author                      Description
-- ---------     --------------    ----------------------        ------------------------------
-- 1.0             23-03-2013             Gauri                   Ported as per 10.x
-- =====================================================================================================================	
--      Date:   30-10-2007
--      Auth:   Eldo
--      desc:   To avoid FTS on PST table, sol_id criteria is added
--
set serveroutput on size 100000
	
CREATE or REPLACE PACKAGE cashbbotc AS
	PROCEDURE cashgetcrncy(inp_string IN VARCHAR2,
						   out_endOfFile OUT  NUMBER,     
						   out_string    OUT  VARCHAR2);
END cashbbotc;
/

-- ***********************************************************  
CREATE or REPLACE PACKAGE BODY  cashbbotc AS

	CURSOR cashBOTCCursor(bankId VARCHAR2) is
		SELECT DISTINCT sol_id, crncy_purchsd,crncy_sold FROM PST 
		WHERE ho_tran_id is  null 
		AND ho_tran_date is  null
		AND entity_cre_flg='Y' 
		AND CRNCY_PURCHSD != CRNCY_SOLD
		AND pst_date >= ( SELECT db_stat_date - 3 FROM GCT WHERE bank_id = bankId) 
		AND sol_id IN (SELECT sol_id FROM SST WHERE set_id = 'ALL' AND bank_id = bankId)
		AND bank_id = bankId;

	CURSOR pstrec(solid pst.sol_id%type, purch pst.crncy_purchsd%type, sold pst.crncy_sold%type,bankId VARCHAR2)  is
		SELECT DISTINCT tran_id,tran_date FROM PST 
		WHERE sol_id=solid AND crncy_purchsd=purch 
		AND crncy_sold=sold AND del_flg!='Y' 
		AND entity_cre_flg!='N' 
		AND pst_date=( SELECT db_stat_date FROM GCT WHERE bank_id = bankId)
		AND bank_id = bankId;
--{
--  --------------------------------------------------------------------------- 
--
--  --------------------------------------------------------------------------- 

	PROCEDURE cashgetcrncy(inp_string IN VARCHAR2,  
					    out_endOfFile OUT  NUMBER,
						out_string    OUT  VARCHAR2) IS

		inpArr			basp0099.ArrayType;
		cashbotc_rec	cashBOTCCursor%ROWTYPE;
		pl_hol_pur		GAM.BACID%TYPE;
		pl_hol_sale		GAM.BACID%TYPE;
		trantype		DTD.tran_type%TYPE;
		cashreqd		NUMBER(1);
		startdate		GCT.db_stat_date%TYPE;
		v_bankId		GAM.bank_id%TYPE
		--{
		BEGIN
			basp0099.formInputArr (inp_string, inpArr);  
			va_bankId := inpArr(0);
			out_endOfFile := 1;
			out_string := '';    
			SELECT (db_Stat_date -3 ) into startdate FROM GCT WHERE bank_id = bankId;
			IF NOT cashBOTCCursor%ISOPEN THEN
				Open cashBOTCCursor(v_bankId);
			END IF;


			FETCH cashBOTCCursor into cashbotc_rec;

			IF cashBOTCCursor%NOTFOUND THEN
				CLOSE cashBOTCCursor;
				out_endOfFile := 1403;  -- When All Records have been Fetched.  
				RETURN;
			ELSE
				cashreqd:=0;
				trantype:='T';
				FOR pstdata in pstrec(cashbotc_rec.sol_id, cashbotc_rec.crncy_purchsd, cashbotc_rec.crncy_sold)

				LOOP

					IF (pstrec%NOTFOUND) THEN
						EXIT;
					END IF;
					BEGIN
						SELECT NVL(tran_type,'T') into trantype FROM DTH WHERE tran_id=pstdata.tran_id AND tran_date=pstdata.tran_date AND del_flg!='Y' AND bank_id = v_bankId;
						EXCEPTION WHEN no_data_found THEN
							trantype:='T';
					END;


					IF (trantype = 'C') THEN
					cashreqd:=1;
					END IF;

				END LOOP;

				SELECT DECODE(cashbotc_rec.CRNCY_PURCHSD,'INR','IBFX-SALE','FS201') into pl_hol_pur FROM DUAL;
				SELECT DECODE(cashbotc_rec.CRNCY_SOLD,'INR','IBIBIT','FS201') into pl_hol_sale FROM DUAL;

				IF (cashreqd = 1) THEN
					BEGIN
					out_string := cashbotc_rec.sol_id||'|'||cashbotc_rec.crncy_purchsd||'|'||cashbotc_rec.crncy_sold||'|'||pl_hol_pur||'|'||pl_hol_sale||'|'||'O'||'|'||startdate;
					END;
				END IF;
				out_endOfFile := 0; 
			END IF;

	EXCEPTION 
		WHEN OTHERS THEN 
			IF cashBOTCCursor%ISOPEN THEN
				CLOSE cashBOTCCursor;
			END IF;
		out_endOfFile := 1;   
	--}
	END cashgetcrncy;
--}
END cashbbotc;
--********************************************************************** 
/
GRANT EXECUTE ON cashbbotc TO TBAGEN, TBAUTIL, TBACUST   
/
DROP PUBLIC SYNONYM cashbbotc
/
CREATE PUBLIC SYNONYM cashbbotc FOR cashbbotc
/
-------------------------  END OF SOURCE    ---------------------------- 
