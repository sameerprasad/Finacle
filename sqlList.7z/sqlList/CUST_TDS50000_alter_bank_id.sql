--REM####################################################################
--REM File Name   : CUST_TDS50000_alter_bank_id.sql
--REM Description : To Alter table CUST_TDS50000 for BANK_ID
--REM Author      : Pragnya Ghosh
--REM Date        : 08-04-2013
--REM####################################################################

ALTER TABLE TBAADM.CUST_TDS50000_TBL ADD BANK_ID VARCHAR2(8)
/