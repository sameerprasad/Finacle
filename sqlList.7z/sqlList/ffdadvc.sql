--===================================================================================================================
--Filename             :  ffdadvc.sql
--Description          :  This script identifies all the Trem Deposits which are linked to the 
--						  Operative account of the customer.
--						  This lists the cust-id,operative account and linked Quantum Fixed Deposits
-- 						  along with the Deposit amount, Balance.
--Date                 :  18-09-2012
--Author               :  Vaibhav Bansal
--Menu Option          :  BJSTM22
--Modification History
--    Sl. #             Date             Author             Modification                              
--    -----            -----            --------           ---------------- 
--    01              14-05-1997        V.V.Sundar       	Original Version 
--    02        	  5-11-1997	Modified to generate a consolidated advice to customers 
--					about the Quantum Optima Accounts
--    03              4-12-1997               	Modified to take interest percentage from tdt 
--	  04			  19-2-1998    Modified to Include Unclear Balance In the Balance shown for Operative a/c
--    05              18-09-2012       Vaibhav Bansal       Coding Standard Changes                          
--===================================================================================================================
rem set pause off
set pages 0
set space 0
rem set pages 60
set linesi 290
set verify off
rem set numformat B9999,99,99,99,999.00
rem set heading on
set feedback off
set echo off
set verify off
set termout off
rem center  ' LIST OF TERM DEPOSIT ACCOUNTS LINKED TO THE OPERATIVE ACCOUNT 'skip 1-
rem left  ' Date : ' todate 
spool ffdadvc.dat
SELECT m.cust_id||
'|'||SUBSTR(g.foracid,5,2) ||
'|'||SUBSTR(g.foracid,7,6) ||
'|'||(g.foracid) ||
'|'||m.acct_name||
'|'||SUBSTR(m.foracid,5,2) ||
'|'||SUBSTR(m.foracid,7,6) ||
'|'||m.foracid ||
'|'||deposit_amount ||
'|'||m.clr_bal_amt ||
'|'||g.lien_amt||
'|'||n.cust_title_code||
'|'|| n.ADDRESS1||
'|'|| n.ADDRESS2||
'|'|| x.ref_desc||
'|'|| y.ref_desc||
'|'|| n.pin_code|| 
'|'||g.clr_bal_amt ||
'|'||g.un_clr_bal_amt||
'|'||to_char(t.open_effective_date,'DD-MON-YYYY')||
'|'||to_char(t.maturity_date,'DD-MON-YYYY')||
'|'||ltrim(to_char(d.int_pcnt,'990.99'))
FROM gam g,gam m,rct x,rct y,tam t,tdt d,ffl f,nma n
--where f.acid = g.acid
WHERE t.link_oper_account = g.acid
AND g.bank_id = '&1'
AND g.bank_id = c.bank_id
AND x.bank_id = c.bank_id
AND g.bank_id = x.bank_id
AND g.bank_id = y.bank_id
AND g.bank_id = t.bank_id
AND g.bank_id = d.bank_id
AND g.bank_id = f.bank_id
--and f.ffd_acid=t.acid
--and f.ffd_acid=m.acid
AND t.acid=m.acid
AND d.acid=t.acid
AND d.acid=m.acid
AND n.ADDR_B2KID=m.cif_id
--and f.del_flg!='Y'
-- (no equivalent col in fin 7) and regul_tod_in_oper_acct_flg='Y'
AND d.srl_num = (SELECT MAX(z.srl_num) FROM tdt z
                        WHERE z.acid = t.acid
                        AND z.flow_code IN('II','IO'))
AND x.ref_rec_type = '01'
AND NVL(n.city_code,'*') = x.ref_code
AND y.ref_rec_type = '02'
AND NVL(n.state_code,'*') = y.ref_code
AND m.acct_cls_flg!='Y'
ORDER BY g.cust_id,g.acid,m.acid
/
spool off
exit
