--==================================================================================*
-- Source Name       : Alter_INDEX_FSG_CFG.sql
-- Author            : Shabnam_S 
-- Date              : 25 Apr 2012 
-- Description       : sql to alter table FSG_CFG table  
-- Calling Script    : NA
-- Modification History
--    Sl. --            Date              Author                Modification
--    -----         -----------     ---------------          ----------------
--    01            25-Apr-2012          Shabnam_S         Added bank id column
--*==================================================================================*


drop index ICICI.IDX_ICICI_FSG_CFG;

CREATE UNIQUE INDEX ICICI.IDX_ICICI_FSG_CFG ON ICICI.ICICI_FSG_CFG
(PRG_TYPE, KEY_TYPE, KEY_VALUE,BANK_ID)
LOGGING
TABLESPACE ICICI_CUST
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

COMMIT;
/
