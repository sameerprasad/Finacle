set verify off
set feedback off
set head off
set echo off
set trims on
set pagesize 1000
spool stmtbod
select to_char(db_stat_date,'ddmmyyyy') from gct where bank_id = '&1';
spool off