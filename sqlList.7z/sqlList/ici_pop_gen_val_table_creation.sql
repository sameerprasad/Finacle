set Heading off
spool ICI_POP_GEN_VAL.log

Rem     This file will create ICI_POP_GEN_VAL
Rem     with the following characteristics.

Rem TABLE NAME: ICI_POP_GEN_VAL

Rem SYNONYM:    ICI_POP_GEN_VAL

drop table ICICI.ICI_POP_GEN_VAL
/
drop public synonym ICI_POP_GEN_VAL
/
drop public synonym ICI_POP_GEN
/
create table ICICI.ICI_POP_GEN_VAL
(
        FORACID                         VARCHAR2(16),
        FORM_TITLE                      VARCHAR2(25),
        TOT_NO_FLD                      NUMBER(2),
        FLD_NAME_1                      VARCHAR2(25),
        FLD_NAME_2                      VARCHAR2(25),
        FLD_NAME_3                      VARCHAR2(25),
        FLD_NAME_4                      VARCHAR2(25),
        FLD_NAME_5                      VARCHAR2(25),
        FLD_NAME_6                      VARCHAR2(25),
        FLD_NAME_7                      VARCHAR2(25),
        FLD_NAME_8                      VARCHAR2(25),
        FLD_NAME_9                      VARCHAR2(25),
        FLD_NAME_10                     VARCHAR2(25),
        FLD_LEN_1                       NUMBER(2),
        FLD_LEN_2                       NUMBER(2),
        FLD_LEN_3                       NUMBER(2),
        FLD_LEN_4                       NUMBER(2),
        FLD_LEN_5                       NUMBER(2),
        FLD_LEN_6                       NUMBER(2),
        FLD_LEN_7                       NUMBER(2),
        FLD_LEN_8                       NUMBER(2),
        FLD_LEN_9                       NUMBER(2),
        FLD_LEN_10                      NUMBER(2),
        FLD_TYPE_1                                              VARCHAR2(1),
        FLD_TYPE_2                                              VARCHAR2(1),
        FLD_TYPE_3                                              VARCHAR2(1),
        FLD_TYPE_4                                              VARCHAR2(1),
 	    FLD_TYPE_5                                              VARCHAR2(1),
        FLD_TYPE_6                                              VARCHAR2(1),
        FLD_TYPE_7                                              VARCHAR2(1),
        FLD_TYPE_8                                              VARCHAR2(1),
        FLD_TYPE_9                                              VARCHAR2(1),
        FLD_TYPE_10                                             VARCHAR2(1),
        FLD_MAN_CHQ_REQ_1               VARCHAR2(1),
        FLD_MAN_CHQ_REQ_2               VARCHAR2(1),
        FLD_MAN_CHQ_REQ_3               VARCHAR2(1),
        FLD_MAN_CHQ_REQ_4               VARCHAR2(1),
        FLD_MAN_CHQ_REQ_5               VARCHAR2(1),
        FLD_MAN_CHQ_REQ_6               VARCHAR2(1),
        FLD_MAN_CHQ_REQ_7               VARCHAR2(1),
        FLD_MAN_CHQ_REQ_8               VARCHAR2(1),
        FLD_MAN_CHQ_REQ_9               VARCHAR2(1),
        FLD_MAN_CHQ_REQ_10              VARCHAR2(1),
        FLD_LEN_MAN_CHK_1               NUMBER(2),
        FLD_LEN_MAN_CHK_2               NUMBER(2),
        FLD_LEN_MAN_CHK_3               NUMBER(2),
        FLD_LEN_MAN_CHK_4               NUMBER(2),
        FLD_LEN_MAN_CHK_5               NUMBER(2),
        FLD_LEN_MAN_CHK_6               NUMBER(2),
        FLD_LEN_MAN_CHK_7               NUMBER(2),
        FLD_LEN_MAN_CHK_8               NUMBER(2),
        FLD_LEN_MAN_CHK_9               NUMBER(2),
        FLD_LEN_MAN_CHK_10              NUMBER(2),
        FLD_ALP_NUM_CHK_1                               VARCHAR2(1),
        FLD_ALP_NUM_CHK_2                               VARCHAR2(1),
        FLD_ALP_NUM_CHK_3                               VARCHAR2(1),
        FLD_ALP_NUM_CHK_4                               VARCHAR2(1),
        FLD_ALP_NUM_CHK_5                               VARCHAR2(1),
        FLD_ALP_NUM_CHK_6                               VARCHAR2(1),
        FLD_ALP_NUM_CHK_7                               VARCHAR2(1),
        FLD_ALP_NUM_CHK_8                               VARCHAR2(1),
        FLD_ALP_NUM_CHK_9                               VARCHAR2(1),
        FLD_ALP_NUM_CHK_10                              VARCHAR2(1),
        FLD_MAPPING_1                                   VARCHAR2(1),
        FLD_MAPPING_2                                   VARCHAR2(1),
        FLD_MAPPING_3                                   VARCHAR2(1),
        FLD_MAPPING_4                                   VARCHAR2(1),
        FLD_MAPPING_5                                   VARCHAR2(1),
        FLD_MAPPING_6                                   VARCHAR2(1),
        FLD_MAPPING_7                                   VARCHAR2(1),
        FLD_MAPPING_8                                   VARCHAR2(1),
        FLD_MAPPING_9                                   VARCHAR2(1),
        FLD_MAPPING_10                                  VARCHAR2(1),
        FLD_DELIM                                       VARCHAR2(1),
        DEL_FLG                                         VARCHAR2(1),
        RCRE_USER_ID                   					VARCHAR2(15),
        RCRE_TIME                      					DATE,
        LCHG_USER_ID                    				VARCHAR2(15),
        LCHG_TIME                       				DATE,
		BANK_ID                         				VARCHAR2(8 CHAR)
)
/

create public synonym ICI_POP_GEN_VAL
    for ICICI.ICI_POP_GEN_VAL
/
create public synonym ICI_POP_GEN
    for ICICI.ICI_POP_GEN
/
create unique index IDX_ICI_POP_GEN_VAL
    on ICI_POP_GEN_VAL( FORACID )
/
grant select, insert, update, delete on ICICI.ICI_POP_GEN_VAL to tbagen,tbaadm
/
grant select on ICI_POP_GEN_VAL to tbautil
/
spool off
