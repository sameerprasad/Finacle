----------------------------------------------------------------------------------------------------
--   Source Name            : Report_delhirer.sql 
--   Description            : Deleted Hirer Report.
--   Input Values           : None
--   Output Values          : None
--   Called Script          : N.A
--   Calling Script         : N.A
--   Modification History:
--   Sl No.         Date              Author                     Description
--   --------------------------------------------------------------------------------------
--     01         09-Oct-2012         Priyanka                 Original Version
----------------------------------------------------------------------------------------------------

set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_delhirer.lst

DECLARE

lv_solid         gam.sol_id%type :='&1';
date1             varchar2(25) := '&2';
date2             varchar2(25) := '&3';
lv_bankid           clmt.bank_id%type := '&4';
MH_HIRER_NAME     cmg.cust_name%type;

CURSOR c1 IS
select cljh.sol_id,
       wlckm.rack_id,
       wlckm.LOCKER_TYPE,
       cljh.locker_num,
       cljh.CIF_JH_ID ,
       substr(cmg.CUST_NAME,'1','40') Hirer_name,
       cljh.LKR_JH_SRL_NO Hirer_Number,
       cljh.CIF_MH_ID,
       cljh.LCHG_TIME Deletion_Date
from    cmg,wlckm,cljh,clmt
where    wlckm.LOCKER_NUM=cljh.LOCKER_NUM
and    clmt.LOCKER_NUM=cljh.LOCKER_NUM
and    clmt.LOCKER_NUM= wlckm.LOCKER_NUM
and    cljh.sol_id=clmt.sol_id
and clmt.sol_id = wlckm.sol_id
and    clmt.cif_id = cljh.cif_mh_id
and    cljh.sol_id = lv_solid
and    cljh.bank_id = clmt.bank_id
and    clmt.bank_id = wlckm.bank_id
and    cljh.bank_id = lv_bankid
and    cljh.CIF_JH_ID = cmg.cif_id
and    cljh.del_flg = 'Y'
and    clmt.del_flg != 'Y'
and    wlckm.del_flg != 'Y'
and    wlckm.ENTITY_CRE_FLG != 'N'
and    cljh.LCHG_TIME between to_date(date1,'DD-MM-YYYY') and to_date(date2,'DD-MM-YYYY')
order by 6,4;

BEGIN

    for f1 in c1
    loop
        BEGIN
            select substr(CUST_NAME,'1','40') into  MH_HIRER_NAME from cmg where cif_id=f1.CIF_MH_ID;
        END;
dbms_output.enable(buffer_size => NULL);
dbms_output.put_line( f1.sol_id         ||'|'||
		      f1.rack_id        ||'|'||    
		      f1.LOCKER_TYPE    ||'|'||    
		      f1.locker_num     ||'|'||
                      f1.cif_jh_id      ||'|'||
                      f1.Hirer_name     ||'|'|| 
                      f1.Hirer_Number   ||'|'||
                      f1.CIF_MH_ID      ||'|'||
                      MH_HIRER_NAME     ||'|'||
                      f1.Deletion_Date     
                    ); 
   end loop; 
END;
/
spool off

