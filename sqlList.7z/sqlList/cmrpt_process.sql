--===================================================================================================================
--Filename                     :cmrpt_process.sql
--Description                  :Ths sql is to fetch the values from custom table ICI_DENOM and to generate report
--Date                         :20-03-2012
--Author                       :Anju Sathyanarayanan
--Menu Option                  :CMRPT
--Modification History
--    Sl. #         Date             Author             Modification
-- -----            -----           --------           ----------------
--    1           20-03-2012    Anju Sathyanarayanan   
--    2           02-03-2012    Anju Sathyanarayanan   Modified to add Bank_ID in the where clause of select query
--===================================================================================================================

set serveroutput on size 1000000
set lines 2000
set feedback off
set trims on
set pages 0
set echo off
set verify off
set head off
spool cashmMn001.lst


declare

cursor cursor1 is 
select
decode(TRAN_IDENTIFIER,'A','Vault to Teller AC',
						'B','Teller to Process Cash',
						'C','Teller to Unprocess Cash',
						'D','Unprocess to Process',
						'E','Process to unprocess',
						'F','Unprocess Cash To Teller') TRAN_IDENTIFIER,
SOL_ID,
TRAN_AMT,
TRAN_DATE,
FROM_FORACID,
TO_FORACID,
COUNTRS1000,
COUNTRS500,
COUNTRS100,
COUNTRS50,
COUNTRS20,
COUNTRS10,
COUNTRS5,
COUNTRS2,      
COUNTRS1,
COUNT50PS,
COUNT25PS,
LCHG_USER_ID,
LCHG_TIME,
RCRE_USER_ID,
RCRE_TIME,
TS_CNT
from ICI_DENOM
where SOL_ID in ( select sol_id from sst where sol_id = '&1')
and TRAN_DATE = '&2'
and BANK_ID = '&3'
order by sol_id,TRAN_DATE,BANK_ID;


BEGIN

for fc1 in cursor1
loop

dbms_output.put_line( fc1.TRAN_IDENTIFIER||'|'||
fc1.SOL_ID||'|'||
fc1.TRAN_AMT||'|'||
fc1.TRAN_DATE||'|'||
fc1.FROM_FORACID||'|'||
fc1.TO_FORACID||'|'||
fc1.COUNTRS1000||'|'||
fc1.COUNTRS500||'|'||
fc1.COUNTRS100||'|'||
fc1.COUNTRS50||'|'||
fc1.COUNTRS20||'|'||
fc1.COUNTRS10||'|'||
fc1.COUNTRS5||'|'||
fc1.COUNTRS2||'|'||      
fc1.COUNTRS1||'|'||
fc1.COUNT50PS||'|'||
fc1.COUNT25PS||'|'||
fc1.LCHG_USER_ID);

end loop;
END;
/
spool off
