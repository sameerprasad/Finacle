----------------------------------------------------------------------------------------------------
--   Source Name            : Report_oveduerem.sql
--   Description            : Overdue Reminders  Report.
--   Input Values           : None
--   Output Values          : None
--   Called Script          : N.A
--   Calling Script         : rpt23_submit.scr
--   Modification History:
--   Sl No.         Date              Author                     Description
--   --------------------------------------------------------------------------------------
--     01         11-Oct-2012         Priyanka                 Original Version
----------------------------------------------------------------------------------------------------
set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_oveduerem.lst

DECLARE

lv_solid         gam.sol_id%type :='&1';
v_LOCKER_NUM     clmt.LOCKER_NUM%type:= '&2';
v_bankid         clmt.bank_id%type := '&3';
inp_addrType     VARCHAR2(10);
out_cust_name    cmg.CUST_NAME%type;
out_addr1             cnma.address1%type;
out_addr2             cnma.address2%type;
out_city_code         cnma.city_code%type;
out_state_code        cnma.state_code%type;
out_cntry_code        cnma.cntry_code%type;
out_pincode          cnma.pin_code%type;
out_phoneno1          crmuser.phoneemail.phoneno%type;
out_phoneno2          crmuser.phoneemail.phoneno%type; 
out_city              rct.ref_desc%type;
out_state             rct.ref_desc%type;
out_country           rct.ref_desc%type;   
out_retcode         number; 


CURSOR c1 IS
select  clmt.sol_id,
        clmt.locker_num,
        clmt.due_date,
        clmt.DISC_RENT_AMT,
        clmt.cif_id,
        substr(cmg.CUST_NAME,1,40) CUST_NAME,
        clmt.OPER_ACNT,
        (lcpp.RENT_PAYABLE_AMOUNT-lcpp.RENT_PAID_AMOUNT) arrear
from    clmt,cmg,lcpp
where   lcpp.LOCKER_NUMBER=CLMT.LOCKER_NUM
and     clmt.cif_id = lcpp.cif_id
and     clmt.cif_id = cmg.cif_id
and     lcpp.cif_id = cmg.cif_id
and     lcpp.bank_id = clmt.bank_id
and     clmt.bank_id = v_bankid
and     floor(ABS((due_date - decode(renewal_date,'',(due_date+1),renewal_date))/365)) > 0
and     clmt.sol_id=lcpp.sol_id
and     clmt.del_flg!='Y'
and     lcpp.del_flg!='Y'
and    (lcpp.RENT_PAYABLE_AMOUNT-lcpp.RENT_PAID_AMOUNT) > 0
and     clmt.sol_id = lv_solid
and     clmt.LOCKER_NUM  like decode (v_LOCKER_NUM,null,'%',v_LOCKER_NUM)
UNION
select  clmt.sol_id,
        clmt.locker_num,
        clmt.due_date,
        clmt.DISC_RENT_AMT,
        clmt.cif_id,
        substr(cmg.CUST_NAME,1,40) CUST_NAME,
         clmt.OPER_ACNT,
        (lcpp.RENT_PAYABLE_AMOUNT-lcpp.RENT_PAID_AMOUNT) arrear
from    clmt,cmg,lcpp
where   lcpp.LOCKER_NUMBER=CLMT.LOCKER_NUM
and     clmt.cif_id = lcpp.cif_id
and     clmt.cif_id = cmg.cif_id
and     lcpp.cif_id = cmg.cif_id
and     lcpp.bank_id = clmt.bank_id
and     clmt.bank_id = v_bankid
and     floor(ABS((due_date - decode(renewal_date,'',(due_date+1),renewal_date))/365)) = 0
and     clmt.sol_id=lcpp.sol_id
and     clmt.del_flg!='Y'
and     lcpp.del_flg!='Y'
and    (lcpp.RENT_PAYABLE_AMOUNT-lcpp.RENT_PAID_AMOUNT) > 0
and     clmt.sol_id = lv_solid
and     clmt.LOCKER_NUM  like decode (v_LOCKER_NUM,null,'%',v_LOCKER_NUM)
order by 3,2;

BEGIN

    
    for f1 in c1
    loop
   
        inp_addrType := 'PERM';
                
        custaddr_pack.custaddr_proc (f1.cif_id,inp_addrType,v_bankid,out_retcode,out_cust_name,out_addr1,out_addr2,
        out_city_code,out_state_code,out_cntry_code,out_city,out_state,out_country,out_pincode,out_phoneno1,out_phoneno2);
                                 
        IF(out_addr1 = '') THEN
        --{

            inp_addrType := 'COMU';
            custaddr_pack.custaddr_proc (f1.cif_id,inp_addrType,v_bankid,out_retcode,out_cust_name,out_addr1,out_addr2,
            out_city_code,out_state_code,out_cntry_code,out_city,out_state,out_country,out_pincode,out_phoneno1,out_phoneno2);
            
        --}
        END IF;
        
        dbms_output.enable(buffer_size => NULL);
        dbms_output.put_line(   f1.cif_id            ||'|'||
                        	f1.arrear    	     ||'|'||
                        	out_cust_name        ||'|'||
                        	out_addr1            ||'|'||
                        	out_addr2            ||'|'||
                        	out_pincode          ||'|'||
                        	f1.locker_num        ||'|'||
                        	f1.OPER_ACNT   
                     ); 
        
   end loop; 
   
END;
/
spool off
 
