--===================================================================================================================
--  Filename                :   letters_bod_date.sql
--  Description             :
--  Date                    :   05-09-2012
--  Author                  :   Swaroop K Tiruvoipati
--  Menu Option             :
--  Modification History
--    Sl. #           Date           Author                     Modification
--    -----           -----          --------                    ----------------
--    1               05-09-2012     Swaroop K Tiruvoipati      Original Version
--                                                              (Ported from 7.x)
--===================================================================================================================
set head off
set verify off
set feedback off
set trimspool on
set pages 0
set termout off
spool bod_date.lst
select to_char(db_stat_date,'ddmmyyyy') from gct where BANK_ID = '&1'
/
spool off
