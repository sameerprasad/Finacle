
--  Filename                :   letters_duenewRD.sql
--  Description             :   
--  Date                    :   05-09-2012
--  Author                  :   Swaroop K Tiruvoipati
--  Menu Option             :
--  Modification History
--    Sl. #           Date           Author                     Modification
--    -----           -----          --------                    ----------------
--    1               05-09-2012     Swaroop K Tiruvoipati      Original Version
--                                                              (Ported from 7.x)
--	  2				  08-04-2013	 Vaibhav B and Supreeth		Changes made for CR-138-29400
--===================================================================================================================

set serveroutput on size 1000000
SET HEAD OFF
SET VERIFY OFF
SET FEEDBACK OFf
DECLARE

gctdate gct.db_stat_date%type;
gctday VARCHAR2(3) ;
gctday1 VARCHAR2(25) ;
matdate1 VARCHAR2(25) ;
stlim NUMBER := 20 ;
enlim NUMBER ;
tacid tam.acid%type;
depprdmths tam.deposit_period_mths%type;
depprddays tam.deposit_period_days%type;
valuedate tam.open_Effective_date%type;
matdate VARCHAR2(25) ;
principal tam.deposit_amount%type;
matamt tam.maturity_amount%type;
safecust tam.safe_custody_flg%type;
autoren tam.auto_renewal_flg%type;
autoclose tam.close_on_maturity_flg%type;
acctnum gam.foracid%type;
acctclsflg gam.acct_cls_flg%type;
gcustid gam.cif_id%type;
gcifid gam.cif_id%type;
opndate gam.acct_opn_date%type;
clrbal gam.clr_bal_amt%type;
schm gam.schm_code%type;
crncy gam.acct_crncy_code%type;
solid gam.sol_id%type;
title cmg.cust_title_code%type;
--name cmg.cust_name%type;
name CMG.cust_name%type;
--addr1 cmg.cust_comu_addr1%type;
--addr2 cmg.cust_comu_addr2%type;

addr1 CRMUSER.ADDRESS.address_line1%type;
addr2 CRMUSER.ADDRESS.address_line2%type;
addr3 CRMUSER.ADDRESS.address_line3%type;

--citycode cmg.cust_comu_city_code%type;
--statecode cmg.cust_comu_state_code%type;
--pin cmg.cust_comu_pin_code%type;
--cntrycode cmg.cust_comu_cntry_code%type;

citycode	CRMUSER.ADDRESS.city_code%type;
statecode	CRMUSER.ADDRESS.state_code%type;
pin		CRMUSER.ADDRESS.zip%type;
cntrycode	CRMUSER.ADDRESS.country_code%type;

city rct.ref_desc%TYPE;
state rct.ref_desc%TYPE;
country rct.ref_desc%TYPE;
soldesc sol.sol_Desc%type;
soladdr1 sol.addr_1%type;
soladdr2 sol.addr_2%type;
solstate sol.state_code%type;
solcity sol.city_code%type;
solpin sol.pin_code%type;
solstatedesc rct.ref_desc%TYPE;
solcitydesc rct.ref_desc%TYPE;
mob_num         ICICI_ALERT_REG.MODE_ID%TYPE;
--e_mail          CMG.EMAIL_ID%TYPE;
--cust_const      CRMUSER.ACCOUNTS.cust_const%type;
cust_const      CMG.cust_const%type;

e_mail  CRMUSER.phoneemail.email%type;

prn_flg	varchar2(1);

loc_fp utl_file.file_type;
loc_filename                    varchar2(200);
loc_filepath                    varchar2(100);
loc_filemode                    varchar(10);

-- initialized the cursor for CR-138-29400
cursor gctcur is
select db_stat_date, TO_CHAR(db_stat_date,'DY'),to_char(db_stat_date,'Monthdd,yyyy') from gct where BANK_ID = '&1';


cursor tamcur is
select acid, DEPOSIT_PERIOD_MTHS,DEPOSIT_PERIOD_DAYS, OPEN_EFFECTIVE_DATE, to_char(MATURITY_DATE,'Monthdd,yyyy'), DEPOSIT_AMOUNT,  
MATURITY_AMOUNT, SAFE_CUSTODY_FLG,  AUTO_RENEWAL_FLG, CLOSE_ON_MATURITY_FLG
from tam
where (maturity_date >= (gctdate + stlim) and maturity_date <= (gctdate + enlim))
and deposit_type ='R'
and BANK_ID = '&1'
--and safe_custody_flg='N' and printing_flg='Y' and auto_renewal_flg='N' 
order by maturity_date;

cursor gamcur is
select sol_id,foracid , cif_id,clr_bal_amt, acct_opn_date, acct_cls_flg,schm_code, acct_crncy_code from gam where gam.acid=tacid and gam.BANK_ID = '&1';

cursor solcur is
select sol_desc,addr_1, addr_2,city_code, state_code, pin_code from sol where sol.sol_id=solid and sol.BANK_ID = '&1';

--cursor cmgcur is
--select cust_title_code,cust_name,CUST_COMU_ADDR1,CUST_COMU_ADDR2,CUST_COMU_CITY_CODE,CUST_COMU_STATE_CODE,CUST_COMU_PIN_CODE,CUST_COMU_CNTRY_CODE,EMAIL_ID,cust_const from cmg where cmg.cif_id=gcifid and cmg.BANK_ID = '&1';

cursor cmgcur is 
select cust_title_code,cust_name,cust_const from cmg where cmg.cif_id=gcifid and cmg.BANK_ID = '&1';

cursor cmgcur1 is
select address_line1,address_line2,address_line3,city_code,state_code,zip,country_code from CRMUSER.ADDRESS a where a.orgkey=gcifid and a.BANK_ID = '&1' AND a.addresscategory = 'Mailing'
AND a.start_date = (SELECT max(start_date) FROM CRMUSER.ADDRESS
WHERE ORGKEY = a.orgkey AND addresscategory = 'Mailing' and bank_id = '&1');


cursor cmgcur2 is
--select EMAIL from CRMUSER.phoneemail a where a.cif_id=gcifid and a.phoneemailtype='COMMEML' and a.bank_id = '&1';
select EMAIL from CRMUSER.phoneemail a where a.orgkey=gcifid and a.phoneemailtype='COMMEML' and a.bank_id = '&1';

--cursor cmgcur3 is 
--select Constitution_Code from CRMUSER.ACCOUNTS a where a.orgkey=gcifid and a.bank_id = '&1';

cursor  icialert is
select MODE_ID  FROM ICICI_ALERT_REG where FORACID = acctnum AND  MODE_OF_DELIVERY = '0' AND BANK_ID = '&1';

BEGIN

begin
-- Changes made for CR-138-29400 starts
open gctcur;
fetch gctcur into gctdate, gctday,gctday1;
close gctcur;
--gctdate := '&1';
--select TO_CHAR(to_date(gctdate),'DY'),to_char(to_date(gctdate),'Monthdd,yyyy')
--into gctday,gctday1
--from dual;
-- Changes made for CR-138-29400 ends
end;

IF gctday = 'SAT' THEN
	enlim := 21 ;
ELSE
	enlim := 20 ;
END IF ;

	--loc_filepath := '/mistmp1/Letters';
	loc_filepath := '/mistmp/Letters';
        loc_filename := 'duenewRD.lst';
        loc_filemode := 'w';
        loc_fp := utl_file.fopen(loc_filepath, loc_filename, loc_filemode);

open tamcur;
begin
loop
fetch tamcur into tacid,depprdmths, depprddays, valuedate, matdate, principal, matamt,safecust, autoren, autoclose;
exit when tamcur%notfound;

begin
open gamcur;
fetch gamcur into solid,acctnum, gcifid, clrbal,opndate,acctclsflg,schm, crncy;
close gamcur;
end;

begin
open solcur;
fetch solcur into soldesc, soladdr1,soladdr2, solcity, solstate, solpin;
close solcur;
end;
begin
--open cmgcur;
--fetch cmgcur into title, name, addr1, addr2,citycode, statecode, pin, cntrycode, e_mail,cust_const;
--close cmgcur;

open cmgcur;
fetch cmgcur into title, name,cust_const;
close cmgcur;
end;

begin
open cmgcur1;
fetch cmgcur1 into addr1, addr2,addr3,citycode, statecode, pin, cntrycode;
close cmgcur1;
end;
begin
open cmgcur2;
fetch cmgcur2 into e_mail;
close cmgcur2;
end;

--begin
--open cmgcur3;
--fetch cmgcur3 into cust_const;
--close cmgcur3;
--end;



open icialert;
fetch icialert into mob_num;
close icialert;

BEGIN
select decode(ref_desc,NULL,' ',ref_desc) into city
from rct
    where ref_rec_type = '01'
    and ref_code = citycode
    and BANK_ID = '&1';
EXCEPTION
WHEN no_data_found then
city := 'city ERROR';
END;

BEGIN
select decode(ref_desc,NULL,' ',ref_desc) into state
from rct
where ref_rec_type = '02'
and ref_code = statecode
and BANK_ID = '&1';
EXCEPTION
WHEN no_data_found then
    state := 'state ERROR';
END;

BEGIN
select decode(ref_desc,NULL,' ',ref_desc) into solcitydesc
from rct
    where ref_rec_type = '01'
    and ref_code = solcity
    and BANK_ID = '&1';
EXCEPTION
WHEN no_data_found then
solcitydesc := 'city ERROR';
END;

BEGIN
select decode(ref_desc,NULL,' ',ref_desc) into solstatedesc
from rct
where ref_rec_type = '02'
and ref_code = solstate
and BANK_ID = '&1';
EXCEPTION
WHEN no_data_found then
solstatedesc:= 'state ERROR';
END;
BEGIN
select decode(ref_desc,NULL,' ',ref_desc) into country
from rct  where ref_rec_type = '03' and ref_code = cntrycode and BANK_ID = '&1';
EXCEPTION
WHEN no_data_found then
state := 'country ERROR';
END;
if (acctclsflg !='Y') then 
	UTL_FILE.PUT_LINE(loc_fp,solid||'|'||acctnum||'|'||gcifid||'|'||name||'|'||depprdmths||'/'||depprddays||'|'||valuedate||'|'||matdate||'|'||opndate||'|'||principal||'|'||matamt||'|'||safecust||'|'||autoren||'|'||autoclose||'|'||clrbal||'|'||schm||'|'||crncy||'|'||title||'|'||addr1||'|'||addr2||'|'||addr3||'|'||city||'|'||pin||'|'||state||'|'||country||'|'||gctday1||'|'||soldesc||'|'||soladdr1||'|'||soladdr2||'|'||solcitydesc||'|'||solstatedesc||'|'||solpin);
end if;
end loop;
end;
close tamcur;
END;
/
