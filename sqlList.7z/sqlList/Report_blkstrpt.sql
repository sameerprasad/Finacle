----------------------------------------------------------------------------------------------------
--   Source Name            : Report_blkstrpt.sql 
--   Description            : Blocked Status Report 
--   Input Values           : None
--   Output Values          : None
--   Called Script          : N.A
--   Calling Script         : N.A
--   Modification History:
--   Sl No.         Date              Author                     Description
--   --------------------------------------------------------------------------------------
--     01         12-Oct-2012         Priyanka                 Original Version
----------------------------------------------------------------------------------------------------


set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_blkstrpt.lst

DECLARE

lv_solid        gam.sol_id%type :='&1';
date1             wlclck.LOCK_DATE%type := to_date('&2','dd-mm-yyyy');
date2            wlclck.LOCK_DATE%type := to_date('&3','dd-mm-yyyy');
lv_bankid        wlclck.bank_id%type := '&4';

CURSOR c1 IS
select  distinct wlclck.sol_id,
                wlckm.rack_id,
                clmt.locker_type,
                wlclck.locker_num,
        clmt.cif_id,
                cmg.cust_name,
                wlclck.LOCK_DATE,
                wlclck.LOCK_REASON,
                wlclck.advice
from    wlclck,wlckm,clmt,cmg
where   clmt.locker_num = wlclck.locker_num
and     wlckm.locker_num = clmt.locker_num
and    wlclck.locker_num = wlckm.locker_num
and     wlckm.sol_id = clmt.sol_id
and     wlclck.sol_id = wlckm.sol_id
and     cmg.cif_id=clmt.cif_id
and     wlclck.del_flg!='Y'
and     wlckm.del_flg!='Y'
and     clmt.del_flg!='Y'
and     wlclck.sol_id = lv_solid
and     wlclck.bank_id = wlckm.bank_id
and    clmt.bank_id = wlckm.bank_id
and    clmt.bank_id = lv_bankid
and     wlckm.status = 'F'
and     wlclck.status = 'F'
and     wlclck.LOCK_DATE between date1 and date2
ORDER by 6,4;

BEGIN

    for f1 in c1
    loop
dbms_output.enable(buffer_size => NULL);
dbms_output.put_line(   f1.sol_id       ||'|'||
                        f1.rack_id      ||'|'||
                        f1.locker_type  ||'|'||
                        f1.locker_num   ||'|'||
                        f1.cif_id       ||'|'||
                        f1.cust_name    ||'|'|| 
                        f1.lock_date    ||'|'||
                        f1.lock_reason  ||'|'||
                        f1.advice);
   end loop; 
END;
/
spool off

