--===================================================================================================================
--             Filename                :                ebadata.sql
--             Description             :                to get EBA lien linked to an account
--             Date                    :                23-08-2012
--             Menu Option	       :		EBA Lien download
--             Modification History
--		Sl. #           Date             Author             Modification                              
--		-----           -----           --------          ----------------                               
--		                          
--===================================================================================================================
column dc new_value dc
column today new_value today

set serveroutput on size 1000000
set linesize 132
set trims on
set head off
set pages 0
set numformat 9999999999.99
set feedback off
set verify off

select dc_alias dc from gct where bank_id = '&2';
select to_char(sysdate,'DDMMYYYYHH24MISS') today from gct where bank_id = '&2';

spool &1/NEWEBA&dc&today

select  /* +PARALLEL (GAM,30) */
'ALT'||'|'||
gam.foracid||'|'||
'EBA'||'|'||
lien_reason_code||'|'||
OTH_EBA_ALT_TBL.ts_cnt||'|'||
OTH_EBA_ALT_TBL.lien_amt||'|'
from ICICI.OTH_EBA_ALT_TBL OTH_EBA_ALT_TBL, gam
where OTH_EBA_ALT_TBL.b2k_type='ULIEN' 
and substr(OTH_EBA_ALT_TBL.b2k_id,1,3)= 'EBA'
and  gam.acid = OTH_EBA_ALT_TBL.acid
AND OTH_EBA_ALT_TBL.BANK_ID = '&2'
and gam.bank_id ='&2'
/

spool off

exit
