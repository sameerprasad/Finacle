
declare
        readline                                        varchar2(2000);

        loc_fp1                          utl_file.file_type;
        loc_filename1                    varchar2(200);
        loc_filemode1                    varchar(10);
        loc_filepath1                    varchar2(100);

        loc_fp2                          utl_file.file_type;
        loc_filename2                    varchar2(200);
        loc_filemode2                    varchar(10);
        loc_filepath2                    varchar2(100);

        loc_fp3                          utl_file.file_type;
        loc_filename3                    varchar2(200);
        loc_filemode3                    varchar(10);
        loc_filepath3                    varchar2(100);

        loc_fp4                          utl_file.file_type;
        loc_filename4                    varchar2(200);
        loc_filemode4                    varchar(10);
        loc_filepath4                    varchar2(100);

        l_foracid                       gam.foracid%type;
        l_clr_bal_amt                   gam.clr_bal_amt%type;
        l_frez_code                     gam.FREZ_CODE%type;     
        l_acct_cls_flg                  gam.acct_cls_flg%type;
        l_schm_code                     gam.schm_code%type;
        l_acct_crncy_code               gam.acct_crncy_code%type;
        l_pool_id                       gam.pool_id%type;
        l_sol_id                       gam.sol_id%type;
        l_mode_id                      icici_alert_reg.mode_id%type;
        l_cust_name                     cmg.cust_name%type;
        pool_bal                        number:=0;
        pool_active                     varchar2(1);
        l_amt           varchar2(20);
        l_trdate        varchar2(20);
        l_tempstr       varchar2(200);
        l_tranpart      varchar2(50);
        l_drcr          char(1);
        l_deli          char(1);
        l_userid        upr.user_id%type;
        l_usdsolid      upr.user_id%type;
        l_schm_type     varchar2(3);
        l_upl_limit             number;
        l_cust_stat_code        cmg.cust_stat_code%type;
        not_fou                         varchar2(100);
        filnum                          number:=1;
        contrasum                       number:=0;
        contratype                      char(1);
        contrafora                      gam.foracid%type;

        drsum                           number:= 0;
        crsum                           number := 0;
        drcnt                           number:= 0;
        crcnt                           number := 0;

        fdrsum                          number:= 0;
        fcrsum                          number := 0;
        fdrcnt                          number:= 0;
        fcrcnt                          number := 0;

        totdrsum                                number:= 0;
        totcrsum                                number := 0;
        totdrcnt                                number:= 0;
        totcrcnt                                number := 0;

        trancnt                         number:=0;
        tranamt                         number:=0;
        inputstr                        varchar2(200);

        failcnt                         number:=0;
        failbal                         number:=0;

        FUNCTION get_poolbal (poolid in gam.POOL_ID%type,inforacid in gam.foracid%type) return number is
        l_bal   number:=0;
        begin
        select sum((gam.CLEAN_ADHOC_LIM+gam.CLEAN_EMER_ADVN+gam.system_gen_lim+gam.clr_bal_amt+gam.sanct_lim+gam.clean_single_tran_lim+FFD_CONTRIB_TO_ACCT) - (gam.system_reserved_amt+gam.lien_amt))
        into l_bal
        from gam
        where pool_id = poolid
        and allow_sweeps = 'Y'
        and foracid <> inforacid;
        return l_bal;
        END get_poolbal;


        procedure proc_summary(pv_status IN char, pv_tramt IN number, pv_drcr IN char) is
        begin
                if (pv_drcr = 'D') then
                        totdrsum := totdrsum + nvl(pv_tramt,0);
                        totdrcnt := totdrcnt + 1;
                else
                        totcrsum := totcrsum + nvl(pv_tramt,0);
                        totcrcnt := totcrcnt + 1;
                end if;
                if (pv_status = 'S') then
                        if (pv_drcr = 'D') then
                                drsum := drsum + nvl(pv_tramt,0);
                                drcnt := drcnt + 1;
                        else
                                crsum := crsum + nvl(pv_tramt,0);
                                crcnt := crcnt + 1;
                        end if;
                else
                        if (pv_drcr = 'D') then
                                fdrsum := fdrsum + nvl(pv_tramt,0);
                                fdrcnt := fdrcnt + 1;
                        else
                                fcrsum := fcrsum + nvl(pv_tramt,0);
                                fcrcnt := fcrcnt + 1;
                        end if;
                end if;
        end proc_summary;

begin

	dbms_output.put_line('Hi..Inside begin');
 
	contrafora:='10299784100101';
 
	l_deli:='P';
 
	l_userid:='E152218';
        select max_upload_rec into l_upl_limit from gct;

        if (contrafora = 'ABCDEF' ) then l_upl_limit:=l_upl_limit+1; end if;
 
		loc_filepath1 := '/users2/e152218/WTEST/com/';
 
		loc_filename1 := '/users2/e152218/WTEST/com/.tran.txt..'||lpad(filnum,3,'0');
                loc_filemode1 := 'w';
                loc_fp1 := utl_file.fopen(loc_filepath1, loc_filename1, loc_filemode1);

                loc_filepath2 := '/users2/e152218/WTEST/com/';
                loc_filename2 := '/users2/e152218/WTEST/com/.tran.txt.FAI';
                loc_filemode2 := 'w';
                loc_fp2 := utl_file.fopen(loc_filepath2, loc_filename2, loc_filemode2);

                loc_filepath3 := '/users2/e152218/WTEST/com/';
                loc_filename3 := 'tran.txt';
                loc_filemode3 :='r';

                loc_fp3 := utl_file.fopen(loc_filepath3, loc_filename3, loc_filemode3);

                loc_filepath4 := '/users2/e152218/WTEST/com/';
                loc_filename4 := '/users2/e152218/WTEST/com/.tran.txt.MIS';
                loc_filemode4 :='w';

                loc_fp4 := utl_file.fopen(loc_filepath4, loc_filename4, loc_filemode4);

                -- Heading in MIS
                utl_file.put_line(loc_fp4,'Type|'||rpad('Filename',30)||'| DRs|      Dr Sum| CRs|      Cr Sum');

                loop
                        utl_file.get_line(loc_fp3,readline);
                        not_fou:= null;
                        l_tempstr := readline;
                        --dbms_output.put_line(readline);

                        l_foracid := substr(l_tempstr,1,instr(l_tempstr,l_deli,1)-1);
                        l_tempstr := substr(l_tempstr, instr(l_tempstr,l_deli,1)+1);

                        l_drcr := substr(l_tempstr,1,instr(l_tempstr,l_deli,1)-1);
                        l_tempstr := substr(l_tempstr, instr(l_tempstr,l_deli,1)+1);
                        l_amt := substr(l_tempstr,1,instr(l_tempstr,l_deli,1)-1);
                        l_tempstr := substr(l_tempstr, instr(l_tempstr,l_deli,1)+1);
                        tranamt := to_number(l_amt);

                        l_tranpart := substr(substr(l_tempstr,1,instr(l_tempstr,l_deli,1)-1),1,30);

                        begin
                                select ((gam.CLEAN_ADHOC_LIM+gam.CLEAN_EMER_ADVN+gam.system_gen_lim+gam.clr_bal_amt+gam.sanct_lim+gam.clean_single_tran_lim+FFD_CONTRIB_TO_ACCT) - (gam.system_reserved_amt+gam.lien_amt))clr_bal_amt,                                        nvl(FREZ_CODE,'Z') frez_code,acct_cls_flg,schm_code,acct_crncy_code, schm_type,POOL_ID,sol_id
                                into l_clr_bal_amt ,l_frez_code,l_acct_cls_flg,l_schm_code,l_acct_crncy_code, l_schm_type,l_pool_id,l_sol_id
                                from gam where foracid=l_foracid ;
                        exception
                                when no_data_found then
                                        not_fou:='INVALID ACCOUNT';
                        end;
                    
                        if ( not_fou is null and l_pool_id is not null ) then
                        select SUSPEND_FLG into pool_active from pft where POOL_ID = l_pool_id ;
                                if ( pool_active <> 'Y' ) then
                                        pool_bal:=get_poolbal(l_pool_id,l_foracid);
                                        l_clr_bal_amt:=l_clr_bal_amt+pool_bal;
                                end if;
                                pool_bal:=0;
                        end if;

                        if (not_fou ='INVALID ACCOUNT' ) then
                                utl_file.put_line(loc_fp2,readline|| l_deli ||not_fou);
                                not_fou:=NULL;
                                proc_summary('F',tranamt,l_drcr);
                                --failcnt:=failcnt+1;
                                --failbal:=failbal+tranamt;
                        elsif(l_acct_cls_flg='Y') then
                                utl_file.put_line(loc_fp2,readline|| l_deli ||' Account Closed');
                                proc_summary('F',tranamt,l_drcr);
                                --failcnt:=failcnt+1;
                                --failbal:=failbal+decode(l_drcr,'D',-1*tranamt,tranamt);
                        elsif((l_drcr = 'D' and l_frez_code ='D') or (l_drcr = 'C' and l_frez_code ='C') or l_frez_code = 'T'  ) then
                                utl_file.put_line(loc_fp2,readline|| l_deli ||' Account Freezed');
                                proc_summary('F',tranamt,l_drcr);
                                --failcnt:=failcnt+1;
                                --failbal:=failbal+tranamt;
                        elsif((l_clr_bal_amt <  to_number(l_amt)) and (l_drcr = 'D') and (l_schm_type not in ('OAB','OAP','HOC','DDA','BAT'))) then
                                begin 
                                select cust_stat_code into l_cust_stat_code from cmg where cust_id in (
                                        select cust_id from gam where foracid = l_foracid);
                                        exception
                                        when no_data_found then l_cust_stat_code := NULL;
                                end;
--           GSR added here for CR-138-06848----------------------------------

                        begin
                        select mode_id into l_mode_id from icici_alert_reg where foracid=l_foracid and rownum<2;
                         exception
                                        when no_data_found then l_mode_id := '*';
                        end;
                        begin
                        select cust_name into l_cust_name from cmg where cust_id =
                          (select cust_id from gam where foracid=l_foracid); 
                        exception
                                        when no_data_found then l_cust_name := '*';
                         end;
                        begin
                         select sol_id into l_usdsolid  from upr where user_id=l_userid;
                          exception
                                when no_data_found then l_usdsolid :=NULL;
                         end;

                                utl_file.put_line(loc_fp2,readline|| l_deli ||' Insufficient Balance         '|| l_deli ||to_char(l_clr_bal_amt,'99999999999.90') || l_deli || l_cust_stat_code || l_deli || l_cust_name || l_deli || l_mode_id || l_deli ||l_usdsolid || l_deli || l_sol_id);

--    GSR  end here ----------------------------------------------------

                                proc_summary('F',tranamt,l_drcr);
                                --failcnt:=failcnt+1;
                                --failbal:=failbal+tranamt;
                        else
                                trancnt := trancnt + 1;
                                if ((l_schm_code='SBNRE') or (l_schm_code='CANRE') or (l_schm_code='SBNRO')or (l_schm_code='CAVOS') or (l_schm_code='CAVFD')or (l_schm_code='SKNRE') or (l_schm_code='CADFC')or (l_schm_code='CANUE') or (l_schm_code='RMCRD')or (l_schm_code='CANUO') or (l_schm_code='SBFNO')or (l_schm_code='ODNRI') or (l_schm_code='ACUCA') or (l_schm_code='CANRO')or (l_schm_code='CAFUS') or (l_schm_code='CAFGB')or (l_schm_code='CAFDM') or (l_schm_code='CAFJY')or (l_schm_code='CAFII')or (l_schm_code='DLNRI') or (l_schm_code='CANRS')or (l_schm_code='SBNRS') or (l_schm_code='SBNRF')) then                                        
inputstr:=rpad(l_foracid,16,' ')||l_acct_crncy_code||rpad(l_sol_id,8,' ')||l_drcr||to_char(tranamt,'99999999999.90')||rpad(rpad(l_tranpart,30,' ')||'LOCAL',85,' ');
                                elsif((l_schm_code='SBFCR') or (l_schm_code='CAFCR')) then
                                        inputstr:=rpad(l_foracid,16,' ')||l_acct_crncy_code||rpad(l_sol_id,8,' ')||l_drcr||to_char(tranamt,'99999999999.90')||rpad(rpad(l_tranpart,30,' ')||'DFCRA',85,' ');
                                else
                                        inputstr:=rpad(l_foracid,16,' ')||l_acct_crncy_code||rpad(l_sol_id,8,' ')||l_drcr||to_char(tranamt,'99999999999.90')||rpad(rpad(l_tranpart,30,' '),85,' ');
                                end if;

                                inputstr := replace(inputstr,'"',' ');
                                utl_file.put_line(loc_fp1,inputstr);
                                proc_summary('S',tranamt,l_drcr);
                                tranamt:=0;
                        end if; 

                        if ( trancnt = l_upl_limit-1 ) then
                                if(drsum>crsum) then
                                        contratype:='C';
                                        contrasum:=drsum-crsum;
                                end if;
                                if(drsum<crsum) then
                                        contratype:='D';
                                        contrasum:=crsum-drsum;
                                end if;
                                if((drsum<>crsum) and (contrafora<>'ABCDEF')) then
                                        inputstr:=rpad(contrafora,16,' ')||'INR'||rpad(substr(contrafora,1,4),8,' ')||contratype||to_char(contrasum,'99999999999.90')||rpad(rpad(loc_filename1,30,' '),85,' ');
                                        utl_file.put_line(loc_fp1,inputstr);
                                end if;
                                contrasum:=0;

                                utl_file.fclose(loc_fp1);
                                utl_file.put_line(loc_fp4,'TTUM|'||rpad(loc_filename1,30)||'|'||lpad(to_char(drcnt),6)||'|'||to_char(drsum,'999999999990.99')||'|'||lpad(to_char(crcnt),6)||'|'||to_char(crsum,'999999999990.99'));
                                filnum:=filnum+1;
                                loc_filename1 := '/users2/e152218/WTEST/com/.tran.txt..'||lpad(filnum,3,'0');
                                loc_fp1 := utl_file.fopen(loc_filepath1, loc_filename1, loc_filemode1);
                                trancnt:=0;
                                drsum := 0;
                                crsum := 0;
                                drcnt := 0;
                                crcnt := 0;
                        end if;

                end loop;
        exception when no_data_found then null;
        if(drsum>crsum) then
                contratype:='C';
                contrasum:=drsum-crsum;
        end if;
        if(drsum<crsum) then
                contratype:='D';
                contrasum:=crsum-drsum;
        end if;
        if((drsum<>crsum) and (contrafora<>'ABCDEF')) then
                inputstr:=rpad(contrafora,16,' ')||'INR'||rpad(substr(contrafora,1,4),8,' ')||contratype||to_char(contrasum,'99999999999.90')||rpad(rpad(loc_filename1,30,' '),85,' ');
                utl_file.put_line(loc_fp1,inputstr);
        end if;
        utl_file.put_line(loc_fp4,'TTUM|'||rpad(loc_filename1,30)||'|'||lpad(to_char(drcnt),6)||'|'||to_char(drsum,'999999999990.99')||'|'||lpad(to_char(crcnt),6)||'|'||to_char(crsum,'999999999990.99'));
        utl_file.put_line(loc_fp4,'FAIL|'||rpad(loc_filename2,30)||'|'||lpad(to_char(fdrcnt),6)||'|'||to_char(fdrsum,'999999999990.99')||'|'||lpad(to_char(fcrcnt),6)||'|'||to_char(fcrsum,'999999999990.99'));
        utl_file.put_line(loc_fp4,'TOT |'||rpad(' ',30)||'|'||lpad(to_char(totdrcnt),6)||'|'||to_char(totdrsum,'999999999990.99')||'|'||lpad(to_char(totcrcnt),6)||'|'||to_char(totcrsum,'999999999990.99'));
        utl_file.fclose(loc_fp1);       
        utl_file.fclose(loc_fp2);       
        utl_file.fclose(loc_fp3);       
        utl_file.fclose(loc_fp4);       
end;
/

exit
