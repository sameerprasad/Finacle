--------------------------------------------
--File Name   : Report_rentduerpt.sql
--Description : Rent Due Report for future date
--Author      : Priyanka
--Date        : 04-10-2012
------------------------------------------
set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_rentduerpt.lst

DECLARE
loc_sol_id              clmt.sol_id%type := '&1';
loc_from_date           varchar2(25) := '&2';
loc_to_date             varchar2(25) := '&3';
loc_bank_id             varchar2(30) := '&4';
loc_renewal_date        date;
loc_cif_id              clmt.cif_id%type;
loc_HIRER_NAME          cmg.cust_name%type;
loc_RACK_ID             wlckm.rack_id%type;
loc_locker_type         wlckm.locker_type%type;
loc_locker_num          clmt.locker_num%type;
loc_Rent_amt            lclrm.RENT_AMT%type;
loc_rntfrmPrd           date;
loc_rntToPrd            date;
loc_set_id              sst.set_id%type;
loc_overDueAmt          number;

CURSOR c1(loc_sol_id CLMT.sol_id%type,loc_from_date varchar2,loc_to_date varchar2,loc_bank_id varchar2)
IS
select clmt.sol_id,
clmt.renewal_date,
clmt.cif_id,
substr(cmg.cust_name,1,40) HIRER_NAME,
wlckm.RACK_ID,
clmt.LOCKER_TYPE,
clmt.LOCKER_NUM,
clmt.renewal_date,
(add_months(clmt.renewal_date,12) -1),
(RENT_PAYABLE_AMOUNT - RENT_PAID_AMOUNT) loc_overDueAmt
from    clmt,wlckm,lcpp,cmg
where   wlckm.LOCKER_NUM = clmt.LOCKER_NUM
and     lcpp.LOCKER_NUMBER=CLMT.LOCKER_NUM
and     wlckm.sol_id = clmt.sol_id
and     clmt.sol_id = lcpp.sol_id
and     wlckm.bank_id = clmt.bank_id
and     clmt.bank_id = lcpp.bank_id
and     clmt.cif_id = lcpp.cif_id
and     clmt.sol_id = loc_sol_id
and     clmt.bank_id = loc_bank_id
and     clmt.renewal_date between to_date(loc_from_date,'dd-mm-yyyy') and to_date(loc_to_date,'dd-mm-yyyy')
and     lcpp.cif_id = cmg.cif_id
and     clmt.del_flg!='Y'
and     lcpp.del_flg!='Y'
and     wlckm.del_flg!='Y'
order by 2,7;

BEGIN
         OPEN C1(loc_sol_id,loc_from_date,loc_to_date,loc_bank_id);
         loop
        --{
                if (C1%ISOPEN) then
                --{
                        FETCH C1
                        INTO
                        loc_sol_id,
                        loc_renewal_date,
                        loc_cif_id,
                        loc_HIRER_NAME,
                        loc_RACK_ID,
                        loc_locker_type,
                        loc_locker_num,
                        loc_rntfrmPrd,
                        loc_rntToPrd,
                        loc_overDueAmt;
                        IF (C1%NOTFOUND) THEN
                                CLOSE C1;
                                EXIT;
                        END IF;
                --}
                END IF;
                --To Arrive Rent from CLRM Table based on Renewal Date---
                BEGIN
                --{
                        SELECT set_id
                        INTO loc_set_id
                        from sst
                        where sol_id = loc_sol_id
                        and set_id like 'LOC%';
                EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                        loc_set_id := null;
                --}
                END;
                 BEGIN
                --{
                        select a.rent_amt
                        INTO loc_Rent_amt
                        from lclrm a
                        WHERE a.sol_id = loc_set_id and
                        a.location_code = loc_set_id and
                        a.locker_type = loc_locker_type and
                        a.RENT_PERIOD = '1' and
                        a.Rent_Version_Code = (select max(b.Rent_Version_Code)
                        from lclrm b
                        where a.location_code = b.location_code and
                        a.locker_type=b.locker_type and
                        a.RENT_PERIOD=b.RENT_PERIOD and
                        a.sol_id = b.sol_id and
                        b.rent_effective_date <= to_date(loc_renewal_date,'dd-mm-yyyy')) and
                        a.del_flg != 'Y' and
                        a.entity_cre_flg != 'N';
                EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                        loc_Rent_amt := 0;
                --}
                END;
                BEGIN
                --{
                        IF (loc_overDueAmt > 0) THEN
                        --{
                                loc_overDueAmt := loc_overDueAmt;
                        --}
                        ELSIF(loc_overDueAmt <= 0) THEN
                        --{
                                loc_overDueAmt := 0;
                        --}
                        END IF;
                --}
                END;
                 dbms_output.enable(buffer_size => NULL);
                dbms_output.put_line( loc_sol_id        ||'|'||
                                        loc_renewal_date    ||'|'||
                                        loc_cif_id             ||'|'||
                                        loc_HIRER_NAME          ||'|'||
                                        loc_RACK_ID             ||'|'||
                                        loc_locker_type         ||'|'||
                                        loc_locker_num          ||'|'||
                                        loc_Rent_amt            ||'|'||
                                        loc_overDueAmt          ||'|'||
                                        loc_rntfrmPrd           ||'|'||
                                        loc_rntToPrd);
        --}
        end loop;
END;
/
spool off



