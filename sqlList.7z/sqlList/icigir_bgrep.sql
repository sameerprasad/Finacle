-- SQL script written by Rahul Nimkar to fetch details of Bank Guarantees issued across all SOLs for a given date range
-- CRCTF33375 for Quick BG. Called from icigir_report.com
-- =====================================================================================================================
-- Source Name            :  icigir_bgrep.sql
-- Description            :  To fetch the record for bg report
-- Input Values           :  None    
-- Output Values          :  None
-- Called Scripts         :  None   
-- Calling Scripts        :  icigir_submit.scr
-- Modification history:
-- Sl. No            Date                 Author                      Description
-- ---------     --------------    ----------------------        ------------------------------
-- 1.0		22-02-2006		Rahul Nimkar			Original Version
-- 2.0		09-03-2012		Gauri				Modified the queries to include bank id
-- 3.0          15-10-2012              Ripal Patel                     Modified the query since the bg_b2kid was appended   --                                                                      with few more values from tfct table TOL 314759         
-- =====================================================================================================================

set serverout on size 1000000 lines 1000 verify off feedback off pages 0
var frm_iss_date varchar2(10); 
var to_iss_date varchar2(10);
var bankId varchar2(8);
	begin
		:frm_iss_date := '&1';
		:to_iss_date := '&2';
		:bankId := '&3';
	end;
/
spool icigir_rep.lst
declare
city_nm RCT.ref_desc%type;
state_nm RCT.ref_desc%type;
cntry_nm RCT.ref_desc%type;
solid01 SOL.sol_id%type;
syschrg CXL.SYSTEM_CALC_AMT%type;
actchrg CXL.ACTUAL_AMT_COLL%type;
margamt GMMT.COLLECT_AMT%type;
Bgb2kid CXL.COMP_B2KID%TYPE;

cursor s1 is select sol_id from sst where set_id = 'ALL' and bank_id = :bankId and del_flg = 'N' and entity_cre_flg = 'Y' order by 1;

cursor b1(solid03 SOL.sol_id%type) is 
select bgm.sol_id,bgm.cust_id,substr(cmg.cust_name,1,60) cus_name,bgm.bg_srl_num,bgm.issue_date,bgm.bg_class,
bgm.beneficiary_type, bgm.beneficiary_name,bgm.beneficiary_addr_1,bgm.beneficiary_addr_2,bgm.city_code,bgm.state_code,
bgm.cntry_code,bgm.pin_code, bgm.amend_rmks,bgm.purpose_of_bg,bgm.counter_bg_dtls,bgm.bg_b2kid,bgm.limit_pcnt
from bgm,cmg where cmg.cust_id = bgm.cust_id 
and bgm.sol_id = solid03
and bgm.bank_id = cmg.bank_id
and bgm.bank_id = :bankId 
and BGM.ISSUE_DATE >= TO_DATE(:frm_iss_date,'DD-MM-YYYY') 
and BGM.ISSUE_DATE <= TO_DATE(:to_iss_date,'DD-MM-YYYY') 
ORDER BY 1,2; 

cursor c1(bgb2kid CXL.comp_b2kid%type) is
select SYSTEM_CALC_AMT,ACTUAL_AMT_COLL from cxl where COMP_B2KID_TYPE = 'BNKGR' and  trim(comp_b2kid) = bgb2kid and bank_id = :bankId and del_flg = 'N' and entity_cre_flg = 'Y';

cursor d1(Bgb2kid BGM.bg_b2kid%type) is 
select b2k_id||b2kid_type||event_type||event_srl_num||tfct_key_srl_num as new_Bgb2kid  from tfct where b2k_id = bgb2kid and bank_id =:bankId and del_flg = 'N' and entity_cre_flg = 'Y';
 
a s1%ROWTYPE;
b b1%ROWTYPE;
c c1%ROWTYPE;
d d1%ROWTYPE;

begin
for a in s1
loop
	for b in b1(a.sol_id)
	loop
	begin
		select ref_desc into city_nm from rct where ref_rec_type = '01' and ref_code = b.city_code and bank_id = :bankId;
		exception 
			when no_data_found then
			city_nm := '';
	end;
	begin
		select ref_desc into state_nm from rct where ref_rec_type = '02' and ref_code = b.state_code and bank_id = :bankId;
		exception
                        when no_data_found then
                        state_nm := '';
	end;
	begin
		select ref_desc into cntry_nm from rct where ref_rec_type = '03' and ref_code = b.cntry_code and bank_id = :bankId;
		exception
                        when no_data_found then
                        cntry_nm := '';
	end;
        begin
                select sum(COLLECT_AMT) into margamt from gmmt where b2kid_type = 'BNKGR' and b2kid = b.bg_b2kid and
                entity_cre_flg = 'Y' and bank_id = :bankId;
                exception
                        when no_data_found then
                        margamt := 0.0;
        end;

	syschrg := 0;
	actchrg := 0;
	for d in d1 (b.bg_b2kid)
        loop	
	begin
		for c in c1(d.new_Bgb2kid)
		loop
		begin
			syschrg := syschrg + c.SYSTEM_CALC_AMT;
			actchrg := actchrg + c.ACTUAL_AMT_COLL;
		end;
		end loop;
	end;
	end loop;
	
		dbms_output.put_line(b.sol_id||'|'||b.cust_id||'|'||b.cus_name||'|'||b.bg_srl_num||'|'||b.issue_date||'|'||b.bg_class||'|'||b.beneficiary_type||'|'||b.beneficiary_name||'|'||b.beneficiary_addr_1||'|'||b.beneficiary_addr_2||'|'||city_nm||'|'||state_nm||'|'||cntry_nm||'|'||b.pin_code||'|'||b.amend_rmks||'|'||b.purpose_of_bg||'|'||b.counter_bg_dtls||'|'||syschrg||'|'||actchrg||'|'||margamt||'|'||b.limit_pcnt);


        syschrg := 0;
        actchrg := 0;

	end loop;
end loop;

exception
	when no_data_found then dbms_output.put_line('No Record Found||||||||||||||||||||');
	when others then dbms_output.put_line('No Record Found||||||||||||||||||||');

end;
/
spool off
