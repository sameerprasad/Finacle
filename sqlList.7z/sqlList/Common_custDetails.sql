----------------------------------------------------------------------------------------------------
--   Source Name            : Common_custDetails.sql 
--   Description            : Stored procedure to retrive customer details.
--   Input Values           : None
--   Output Values          : None
--   Called Script          : N.A
--   Calling Script         : N.A
--   Modification History:
--   Sl No.         Date              Author                     Description
--   --------------------------------------------------------------------------------------
--     01         25-Oct-2012         Priyanka                 Original Version
----------------------------------------------------------------------------------------------------

CREATE OR REPLACE PACKAGE custaddr_pack AS

    PROCEDURE custaddr_proc (
                inp_cifId IN varchar2,
                inp_addrType IN varchar2,
                inp_bankid   IN varchar2,
                out_retcode OUT number,
                out_cust_name  OUT varchar2,
                out_addr1 OUT varchar2,
                out_addr2 OUT varchar2,
                out_city_code  OUT varchar2,
                out_state_code  OUT varchar2,
                out_cntry_code  OUT varchar2,
                out_city OUT varchar2,
                out_state OUT varchar2,
                out_country  OUT varchar2,
                out_pincode OUT varchar2,
                out_phoneno1 OUT varchar2,
                out_phoneno2    OUT varchar2
                );

        END custaddr_pack;
/

CREATE OR REPLACE PACKAGE BODY custaddr_pack AS

v_cif_id            cmg.cif_id%type;
v_address_type      cmg.address_type%type;
v_bankid            cmg.bank_id%type;
v_cust_name         cmg.cust_name%type;
v_corp_id           cmg.corp_id%type;
v_addrId            cnma.addr_id%type;
v_phoneType1        cnma.phone_num1%type;
v_phoneType2        cnma.phone_num2%type;
v_date              date;
v_addr1             cnma.address1%type;
v_addr2             cnma.address2%type;
v_city_code         cnma.city_code%type;
v_state_code        cnma.state_code%type;
v_cntry_code        cnma.cntry_code%type;
v_pin_code          cnma.pin_code%type;
v_phoneno1          crmuser.phoneemail.phoneno%type;
v_phoneno2          crmuser.phoneemail.phoneno%type; 
v_city              rct.ref_desc%type;
v_state             rct.ref_desc%type;
v_country           rct.ref_desc%type;

OutArr  basp0099.ArrayType;



        PROCEDURE custaddr_proc
        (
                inp_cifId IN varchar2,
                inp_addrType IN varchar2,
                inp_bankid   IN varchar2,
                out_retcode OUT number,
                out_cust_name  OUT varchar2,
                out_addr1 OUT varchar2,
                out_addr2 OUT varchar2,
                out_city_code  OUT varchar2,
                out_state_code  OUT varchar2,
                out_cntry_code  OUT varchar2,
                out_city OUT varchar2,
                out_state OUT varchar2,
                out_country  OUT varchar2,
                out_pincode OUT varchar2,
                out_phoneno1 OUT varchar2,
                out_phoneno2 OUT varchar2
        ) AS

BEGIN
--{
        out_retcode := 0;
        
        
        v_cif_id := inp_cifId;
        v_address_type := inp_addrType;
        v_bankid := inp_bankid;
        
        v_cust_name     := null;
        v_corp_id       := null;
        v_addr1         := null;
        v_addr2         := null;
        v_city_code     := null;
        v_state_code    := null;
        v_cntry_code    := null;
        v_pin_code      := null;
        v_phoneno1      := null;
        v_phoneno2      := null; 
        v_city          := null;
        v_state         := null;
        v_country       := null;      
        
        IF(v_address_type != 'EMP' AND v_address_type != 'COMU' AND v_address_type != 'PERM' AND v_address_type != 'PREF') THEN
         --{
               return;
         --}
        END IF;
        
        BEGIN
        --{   
            SELECT db_stat_date 
            into v_date
            FROM gct
            WHERE bank_id = v_bankid;
            
            EXCEPTION WHEN NO_DATA_FOUND THEN
            return;
            
        --}
        END;
        
                        
        BEGIN 
        --{   
           
            SELECT cust_name, NVL(corp_id,'') 
            into v_cust_name, v_corp_id
            FROM cmg 
            WHERE cif_id = v_cif_id
            AND bank_id = v_bankid;
            
            EXCEPTION WHEN NO_DATA_FOUND THEN 
            out_retcode := 1;
            
        --}            
        END;
        
        IF(v_corp_id != '') THEN
        --{    
        
            IF(v_address_type = 'EMP')THEN
            --{
                v_addrId := 'Head Office';        
                v_phoneType1  := 'WORKPH1';
                v_phoneType2  := 'WORKPH2';
            --}
            ELSE
            --{
                IF(v_address_type = 'COMU')THEN
                --{
                    v_addrId := 'Mailing' ;       
                    v_phoneType1  := 'COMMPH1';
                    v_phoneType2  := 'COMMPH2';
                --}
            
                ELSE
                --{
                    IF(v_address_type = 'PERM')THEN
                    --{
                        v_addrId      := 'Registered' ;       
                        v_phoneType1  := 'HOMEPH1';
                        v_phoneType2  := 'HOMEPH2';
                    --}
                    END IF;
                 --}
                END IF;
             --}
            END IF;
         --}
         
        ELSE
        --{
            
            IF(v_address_type = 'EMP')THEN
            --{
            
                v_addrId := 'Work';        
                v_phoneType1  := 'WORKPH1';
                v_phoneType2  := 'WORKPH2';
            --}
            ELSE
            --{
                IF(v_address_type = 'COMU')THEN
                --{
                    v_addrId := 'Mailing' ;       
                    v_phoneType1  := 'COMMPH1';
                    v_phoneType2  := 'COMMPH2';
                --}
            
                ELSE
                --{
                    IF(v_address_type = 'PERM')THEN
                    --{
                        v_addrId      := 'Home' ;       
                        v_phoneType1  := 'HOMEPH1';
                        v_phoneType2  := 'HOMEPH2';
                    --}
                    END IF;
                 --}
                END IF;
             --}
            END IF;
              
            
         --}   
         END IF;      
                                
                      
         IF(v_address_type = 'EMP' OR v_address_type = 'COMU' OR v_address_type = 'PERM') THEN
         --{
                
                BEGIN
                --{
                
                     SELECT address1, address2, city_code, state_code, cntry_code, pin_code
                     into v_addr1, v_addr2, v_city_code, v_state_code, v_cntry_code, v_pin_code 
                     FROM cnma  
                     WHERE addr_b2kid = v_cif_id
                     AND bank_id  = v_bankid
                     AND start_date <= v_date
                     AND end_date       >= v_date
                     AND addr_id =  v_addrId;
                     
                    
                 EXCEPTION WHEN NO_DATA_FOUND THEN
                 out_retcode := 1;
                 
                --}
                END;
          --}
          ELSE
          --{   
                BEGIN
                 SELECT address1, address2, city_code, state_code, cntry_code, pin_code 
                 into v_addr1, v_addr2, v_city_code, v_state_code, v_cntry_code, v_pin_code
                 FROM cnma  
                 WHERE addr_b2kid = v_cif_id
                 AND bank_id  = v_bankid
                 AND start_date <= v_date
                 AND end_date       >= v_date
                 AND preferredaddress  = 'Y';
                 
                 
                 EXCEPTION WHEN NO_DATA_FOUND THEN
                 out_retcode := 1;
                                
                END;
          --}
          
          END IF;
        
              
        IF(v_address_type = 'EMP' OR v_address_type = 'COMU' OR v_address_type = 'PERM') THEN
        --{
        
               
                BEGIN
                --{
                     SELECT NVL(a.phoneno,''), NVL(b.phoneno,'')
                     into v_phoneno1, v_phoneno2
                     FROM crmuser.phoneemail a , crmuser.phoneemail b  
                     WHERE a.orgkey = v_cif_id 
                     AND a.orgkey = b.orgkey 
                     AND a.bank_id = v_bankid
                     AND a.bank_id = b.bank_id 
                     AND a.phoneoremail = 'PHONE'
                     AND a.phoneoremail = b.phoneoremail
                     AND a.phoneemailtype = v_phoneType1 
                     AND b.phoneemailtype = v_phoneType2; 
                 
                 EXCEPTION WHEN NO_DATA_FOUND THEN
                  out_retcode := 1;
                  
                --}                 
                END;
          --}
          ELSE
          --{   
                BEGIN
                --{
                     SELECT NVL(a.phoneno,''), NVL(b.phoneno,'')
                     into v_phoneno1, v_phoneno2
                     FROM crmuser.phoneemail a , crmuser.phoneemail b  
                     WHERE a.orgkey = v_cif_id 
                     AND a.orgkey = b.orgkey 
                     AND a.bank_id = v_bankid
                     AND a.bank_id = b.bank_id 
                     AND a.phoneoremail = 'PHONE'
                     AND a.phoneoremail = b.phoneoremail
                     AND a.preferredflag = 'Y'
                     AND b.preferredflag = 'Y';
                     
                 
                 EXCEPTION WHEN NO_DATA_FOUND THEN
                 out_retcode := 1;
                 
               --}                 
               END;
          --}
          
          END IF;      
        
        
        BEGIN
        --{
                SELECT a.ref_desc, b.ref_desc, c.ref_desc 
                into v_city, v_state, v_country
                FROM rct a, rct b, rct c 
                WHERE a.bank_id = v_bankid
                AND b.bank_id = v_bankid 
                AND c.bank_id = v_bankid
                AND a.ref_code = v_city_code 
                AND b.ref_code = v_state_code 
                AND c.ref_code = v_cntry_code 
                AND a.ref_rec_type = '01'
                AND b.ref_rec_type = '02' 
                AND c.ref_rec_type = '03'; 
                                            
               EXCEPTION WHEN NO_DATA_FOUND THEN
               out_retcode := 1;
        --}      
        END;
        
        out_cust_name   := v_cust_name;
        out_addr1       := v_addr1;
        out_addr2       := v_addr2;
        out_city_code   := v_city_code;
        out_state_code  := v_state_code;
        out_cntry_code  := v_cntry_code;
        out_city        := v_city;
        out_state       := v_state;
        out_country     := v_country;
        out_pincode     := v_pin_code;
        out_phoneno1    := v_phoneno1;
        out_phoneno2    := v_phoneno2;
        
                           
   EXCEPTION WHEN NO_DATA_FOUND THEN
   
   out_retcode := 1;
   
--}
end custaddr_proc;
end custaddr_pack;
/
drop public synonym custaddr_pack
/
create public synonym custaddr_pack for custaddr_pack
/
grant execute on custaddr_pack to tbautil,tbagen,tbaadm
/


