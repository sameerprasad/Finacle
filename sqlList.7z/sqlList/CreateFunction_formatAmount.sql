CREATE OR REPLACE FUNCTION formatAmount(  inpAmt IN NUMBER, inpCrncyCode IN VARCHAR2,bankId IN VARCHAR2) RETURN VARCHAR2 AS
	locAmount       VARCHAR2(35);
	format          VARCHAR2(35);
	precision       NUMBER(2);
	floatDecFlg VARCHAR2(1);
BEGIN
	BEGIN
	SELECT NUM_OF_DEC_POINTS INTO precision
	FROM CNC
	WHERE CRNCY_CODE = inpCrncyCode AND bank_id = bankId;

	EXCEPTION
		WHEN NO_DATA_FOUND THEN
		precision := 0;
	END;
	SELECT DIFF_DECIMAL_FOR_DIFF_CRNCY INTO floatDecFlg
	FROM GCT WHERE bank_id = bankId;

	IF (floatDecFlg IS NULL OR floatDecFlg = 'N') THEN
		format := '9999999999999999990D99';
	ELSE
		IF precision = 0 THEN
			format := '9999999999999999990';
		ELSIF precision = 1 THEN
			format := '9999999999999999990D9';
		ELSIF precision = 2 THEN
			format := '9999999999999999990D99';
		ELSIF precision = 3 THEN
			format := '9999999999999999990D999';
		ELSIF precision = 4 THEN
			format := '9999999999999999990D9999';
		END IF;
	END IF;

	SELECT (LTRIM(TO_CHAR(inpAmt, format))) INTO locAmount
	FROM DUAL;

	RETURN (locAmount);

END formatAmount;
/
Create public synonym formatamount for ICICI.formatamount;
