set serveroutput on size 1000000
set verify off
set feedback off
set head off
set termout on

declare
	tds_sol_id				TDS.sol_id%Type;
	tds_cust_id				TDS.cust_id%Type;
	prev_tds_cust_id		TDS.cust_id%Type;
	tds_tran_date		    TDS.value_date%Type;
	var_tds_tran_date		TDS.value_date%Type;
	tds_int_amt				TDS.int_amt%Type;
	totintamt				TDS.int_amt%Type;
    -------------------------------------------------------->  Added by K.Shankar
    income_tax  			tds.int_amt%type;
    surcharge      			tds.int_amt%type;
    cess_amt    			tds.int_amt%type;

    tot_int_amt     		tds.int_amt%type;
    tot_tds_amt     		tds.int_amt%type;
	-----------------------------------------------------------------------------
	tds_tds_amt				TDS.recommended_tds_amt%Type;
	tottdsamt				TDS.recommended_tds_amt%Type;
	tds_cert_num			TDS.tds_cert_num%Type;
	tds_tds_rate			TDS.tds_rate%Type;
	tds_rmks			    TDS.tds_rmks%Type;
	tds_print_count			TDS.print_count%Type;
	tds_acid				TDS.acid%Type;
	prev_tds_acid			TDS.acid%Type;
	tds_flg					TDS.tds_flg%Type;
	tds_tran_id				TDS.tran_id%Type;
	tds_part_tran_srl_num	TDS.part_tran_srl_num%Type;
	tds_rcre_time			TDS.rcre_time%Type;
	tph_rcre_time			TPH.rcre_time%Type;
	time_diff				number;
	cmg_cust_id				CMG.cust_id%Type;
	cmg_cust_title_code		CMG.cust_title_code%Type;
	cmg_cust_name			CMG.cust_name%Type;
	cmg_cust_commu_addr1	CMG.cust_comu_addr1%Type;
	cmg_cust_commu_addr2	CMG.cust_comu_addr2%Type;
	cmg_city_code			CMG.cust_comu_city_code%Type;
	cmg_tds_tbl_code		CMG.tds_tbl_code%Type;
	atc_pcnt_amt			ATC.pcnt_amt%Type;
	cust_city_desc			RCT.ref_desc%Type;
	cust_state_desc			RCT.ref_desc%Type;
	cust_cntry_desc			RCT.ref_desc%Type;
	cust_pin_code			CMG.pan_gir_num%Type;
	gam_foracid				GAM.foracid%Type;
	cmg_pan_gir_num			CMG.pan_gir_num%Type;
	sol_tds_circle_name		SOL.tds_circle_name%Type;
	sol_tax_dedn_details	SOL.tax_dedn_details%Type;
	fromdate				date;
	todate					date;
	locSolId				varchar(4);
	custId					varchar(9);
	locCustPre				varchar(4);
	endOfTdsCursor			number;
	cnt_tph					number;
	cnt_tdt					number;
	cnt_gam_cls				number;
	tds_tran_date_flg		varchar(2);
	--var_challan_no			challan.challan_no%Type;
	var_challan_no			varchar(28);
	var_mth_of_int			challan.mth_of_int%Type;
	var_date_remit			challan.date_remit%Type;
	var_place_remit			challan.place_remit%Type;
	fp						utl_file.file_type;
	m_date_remit            challan.date_remit%Type;
	m_bsr_code              varchar(7);
	m_chqno                 number;
	m_challan				number;
	tds_issued_cnt			number;
	m_challanType	        varchar(7);


	Cursor tds_sel is
		SELECT
				TDS.sol_id,
				TDS.cust_id,
				Nvl(TDS.value_date,tran_date),
				TDS.int_amt,
				(TDS_FROM_ORG_ACCT + TDS_FROM_OP_ACCT + TDS_FROM_SUSPENSE_ACCT) tds_amt,
        		TDS.tds_cert_num,
				TDS.tds_rate,
				TDS.print_count,
				TDS.acid,
				TDS.tds_flg,
				TDS.tran_id,
				TDS.part_tran_srl_num,
				TDS.rcre_time
		FROM
				TDS
		WHERE   
				TDS.sol_id = locSolId  
		  and   ((TDS.value_date between fromdate and todate)
				   or ((TDS.value_date is NULL and int_amt != 0
                                and   (TDS.tran_date between fromdate and todate))))
		ORDER by TDS.sol_id, TDS.cust_id,print_count  desc, 3, int_amt , TDS.acid;



        --and    substr(TDS.TDS_CERT_NUM,1,11) != 'TDSCESSCORR'
		--ORDER by TDS.sol_id, TDS.cust_id, TDS.value_date, int_amt ,print_count  desc, TDS.acid;


	PROCEDURE processTdsCursor( dummy Number ) IS
	BEGIN
	--{
		fetch 
			tds_sel
		INTO
			tds_sol_id,
			tds_cust_id,
			tds_tran_date,
			tds_int_amt,
			tds_tds_amt,
			tds_cert_num,
			tds_tds_rate,
			tds_print_count,
			tds_acid,
			tds_flg,
			tds_tran_id,
			tds_part_tran_srl_num,
			tds_rcre_time;

		if (tds_sel%notfound)
		then
			endOfTdsCursor := 1;
			RETURN;
		end if;

		if( tds_flg != 'Y' )
		then
			RETURN;
		end if;

		cmg_cust_name 		:= '';
		cmg_city_code 		:= '';
		cmg_cust_commu_addr1 	:= '';
                cmg_cust_commu_addr2	:= '';
		cust_pin_code 		:= '';

		var_tds_tran_date := tds_tran_date;
		if( tds_cust_id != prev_tds_cust_id )
		then
		BEGIN
			SELECT sum(TDS_FROM_ORG_ACCT + TDS_FROM_OP_ACCT + TDS_FROM_SUSPENSE_ACCT), sum(int_amt)
 			  INTO tottdsamt, totintamt
			  FROM TDS
			 where cust_id = tds_cust_id 
			   and value_date between fromdate and todate
               --and substr(TDS.TDS_CERT_NUM,1,11) != 'TDSCESSCORR'
			   and sol_id = locSolId and TDS.bank_id = :bank_id;

			Begin
			   SELECT count(*) into tds_issued_cnt
			     FROM TDS
			    where cust_id = tds_cust_id 
		          and ((TDS.value_date between fromdate and todate)
				            or ((TDS.value_date is NULL and int_amt != 0
                                and   (TDS.tran_date between fromdate and todate))))
			      and print_count > 0
			      and sol_id = locSolId and bank_id = :bank_id;
			Exception
				WHEN NO_DATA_FOUND then
				     tds_issued_cnt:=0;
			End;
			cmg_cust_id := tds_cust_id;

			BEGIN
				SELECT cust_title_code ,cust_name ,cust_comu_city_code ,cust_comu_addr1 ,cust_comu_addr2
					   ,cust_comu_pin_code ,Nvl(pan_gir_num,'N.A.') ,tds_tbl_code
				  INTO cmg_cust_title_code ,cmg_cust_name ,cmg_city_code ,cmg_cust_commu_addr1 ,
                       cmg_cust_commu_addr2 ,cust_pin_code ,cmg_pan_gir_num ,cmg_tds_tbl_code
				  FROM CMG
				 WHERE cust_id = cmg_cust_id and del_flg != 'Y' and  bank_id = :bank_id;
		    EXCEPTION
				WHEN NO_DATA_FOUND then
					 dbms_output.put_line('No Data Found in CMG for Cust ID '||cmg_cust_id);
			END;

			if (cmg_tds_tbl_code = 'TDCSF') 
			then
				atc_pcnt_amt := 10.45;
			end if;

			if (cmg_tds_tbl_code = 'TDTST') 
			then
				atc_pcnt_amt := 11.22;
			end if;

			if (cmg_tds_tbl_code = 'TDSC') 
			then
				atc_pcnt_amt := 22.44;
			end if;

			if (cmg_tds_tbl_code = 'TDOCT') 
			then
				atc_pcnt_amt := 41.82;
			end if;

			if (cmg_tds_tbl_code = 'TDS0') 
			then
				atc_pcnt_amt := 0.00;
			end if;

			if (cmg_tds_tbl_code = 'TDSI') 
			then
				--if (totintamt < 850000)
				if (totintamt < 1000000)
				then
					atc_pcnt_amt := 10.20;
				else
					atc_pcnt_amt := 11.22;
				end if;
			end if;

			BEGIN
				SELECT ref_desc INTO cust_city_desc FROM RCT 
                 WHERE ref_rec_type = '01' and ref_code = cmg_city_code and bank_id = :bank_id;
			EXCEPTION
			    WHEN NO_DATA_FOUND then
					 dbms_output.put_line('No Data Found in RCT for city code '||cmg_city_code);
			END;
		END;
		end if;

		if( tds_acid != prev_tds_acid )
		then
		BEGIN
			SELECT foracid INTO gam_foracid FROM gam WHERE acid = tds_acid and  bank_id = :bank_id;
		EXCEPTION
			WHEN NO_DATA_FOUND then
				dbms_output.put_line('No Data Found in GAM for acid '||tds_acid);
		END;
		end if; 
        ----------------------------------------------------------  K.Shankar  --------------
        income_tax  := 0;
        surcharge   := 0;
        cess_amt    := 0;

        if (tds_tds_amt > 0) Then
           IF (cmg_tds_tbl_code= 'TDSI') THEN
              --IF (totintamt > 850000) THEN
              IF (totintamt > 1000000) THEN
                 income_tax    := Round(((tds_tds_amt/ 11.22) * 10),0);
                 surcharge     := Round(((tds_tds_amt/ 11.22) * 1),0);
                 cess_amt      := tds_tds_amt - (income_tax + surcharge);
              ELSE
                 --DBMS_OUTPUT.PUT_LINE (c1rec.tds_tbl_code || '|' || c2rec.intamt);
                 income_tax    := Round(((tds_tds_amt/ 10.2) * 10),0);
                 surcharge     := Round(((tds_tds_amt/ 10.2) * 0),0);
                 cess_amt      := tds_tds_amt - (income_tax + surcharge);
              END IF;
           ELSIF (cmg_tds_tbl_code = 'TDTST') THEN
              income_tax      := Round(((tds_tds_amt/ 11.22) * 10),0);
              surcharge       := Round(((tds_tds_amt/ 11.22) * 1),0);
              cess_amt        := tds_tds_amt - (income_tax + surcharge);
           ELSIF (cmg_tds_tbl_code = 'TDCSF') THEN
              income_tax      := Round(((tds_tds_amt/ 10.455) * 10),0);
              surcharge       := Round(((tds_tds_amt/ 10.455) * 0.25),0);
              cess_amt        := tds_tds_amt - (income_tax + surcharge);
           ELSIF (cmg_tds_tbl_code = 'TDSC') THEN
              --income_tax      := Round(((tds_tds_amt/ 20.91) * 20),0);
              --surcharge       := Round(((tds_tds_amt/ 20.91) * 0.5),0);
              income_tax      := Round(((tds_tds_amt/ 22.44) * 20),0);
              surcharge       := Round(((tds_tds_amt/ 22.44) * 2),0);
              cess_amt        := tds_tds_amt - (income_tax + surcharge);
           END IF;
        End if;
        -------------------------------------------------------------------------------------
		prev_tds_cust_id := tds_cust_id;
		prev_tds_acid    := tds_acid;
		
		if (cmg_tds_tbl_code = 'TDSC') 
		then
			var_challan_no := 'ITNS269/281 (as applicable)';
        else
			var_challan_no := 'ITNS271/281 (as applicable)';
		end if;

		--if ((tds_tran_date >= '27-03-2005') and (tds_tran_date <= '31-03-2005'))
		if (tds_tran_date = '31-03-2006')
		then
			tds_tran_date_flg := 'Y';
		else
			tds_tran_date_flg := 'N';
		end if;

		BEGIN
			select
				mth_of_int, date_remit, place_remit
			into
				var_mth_of_int, var_date_remit, var_place_remit
			from
				challan
			where
				sol_id = '&3'
				and mth_of_int = to_char(substr(tds_tran_date,4,7)) and  bank_id = :bank_id;
		EXCEPTION
			when OTHERS then
			var_mth_of_int := 'NA';
			var_date_remit := '01-01-2099';
			var_place_remit := 'NA';
		END;

	    if (cmg_tds_tbl_code = 'TDSC') 
		then
           m_challanType := 'CORP';
		else
           m_challanType := 'NONCORP';
		End if;
		
		BEGIN
			  select Date_Remit, Bsr_code_of_Place_Remit ,CHALLAN_NO
			    into m_date_remit,m_bsr_code,m_challan
			    from CHALLAN_2006
			   where sol_id = '&3'
		      and Trim(challan_type) = m_challanType
			     and mth_of_int = to_char(substr(tds_tran_date,4,7)) and  bank_id = :bank_id;
		EXCEPTION
			   when OTHERS then
		            m_date_remit := '01-01-2099';
			        m_bsr_code   := '';
			        m_chqno      := '';
		END;

		--m_date_remit := '01-01-2099';
		--m_bsr_code   := '-';
		--m_chqno      := '';

        if (tottdsamt> 0) Then
			
		   utl_file.put_line(fp, ltrim(tds_cust_id)||'|'||
		     				tds_tran_date||'|'||
		     				tds_int_amt||'|'||
		     				tds_tds_amt||'|'||
							income_tax||'|'||
    						surcharge||'|'||
    						cess_amt||'|'||
		     				ltrim(tds_cert_num)||'|'||
		     				tds_tds_rate||'|'||
		     				tds_print_count||'|'||
		     				cmg_cust_title_code||'|'||
		     				cmg_cust_name||'|'||
		     				cmg_cust_commu_addr1||'|'||
		     				cmg_cust_commu_addr2||'|'||
	             			cust_city_desc||'|'||
	             			cust_state_desc||'|'||
	             			cust_cntry_desc||'|'||
	             			cust_pin_code||'|'||
		     				gam_foracid||'|'||
		     				cmg_pan_gir_num||'|'||
		     				sol_tds_circle_name||'|'||
		     				sol_tax_dedn_details||'|'||
		     				fromdate||'|'||
		     				todate||'|'||
		     				tottdsamt||'|'||
		     				tds_tran_date_flg||'|'||
		     				var_challan_no||'|'||
		     				var_mth_of_int||'|'||
		     				var_date_remit||'|'||
	             			var_place_remit||'|'||
							atc_pcnt_amt||'|'||
							m_chqno||'|'||
							m_date_remit||'|'||
						    m_bsr_code||'|'||
							m_challan||'|'||tds_issued_cnt);
		End if;
	--}
	END;	

BEGIN

	fromdate     := '&1';
	todate       := '&2';
	locSolId     := '&3';
	bank_id      := '&4';
	locCustPre   := ' ';

	prev_tds_cust_id := ' ';
	prev_tds_acid    := ' '; 

	fp           := utl_file.fopen('/tmp',locSolId || '.constds.dat','w');

	BEGIN
		SELECT tds_circle_name ,tax_dedn_details
		  INTO sol_tds_circle_name ,sol_tax_dedn_details
		  FROM SOL
		 WHERE sol_id = locSolId
		   and extn_cntr_code = '00' and  bank_id = :bank_id;

    EXCEPTION
			WHEN NO_DATA_FOUND then
				dbms_output.put_line('No Data Found in SOL for '||locSolId);
	END;

	open tds_sel;
	endOfTdsCursor := 0;
	while endOfTdsCursor = 0 loop
		processTdsCursor(0);
	end loop;

	close tds_sel;
	
exception	
		when NO_DATA_FOUND then
			dbms_output.put_line('NO DATA FOUND ');
		when OTHERS then
			dbms_output.put_line('CHECK SQLERROR AND TRY AGAIN');
			dbms_output.put_line('SQL ERROR CODE IS '||sqlcode);
			dbms_output.put_line('SQL ERROR DESCRIPTION IS '||SQLERRM);
end;
/
set head on
set verify on
set feedback on
set termout on
