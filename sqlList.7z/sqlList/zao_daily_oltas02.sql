set serveroutput on size 1000000
set feedback off
set verify off
set linesize 500
set pages 0
set trims on
set termout off
set numformat 999D09
spool &3
select distinct '02^639'||'^'||substr(BSR_CODE,length(bsr_code)-3,4)||'^'||'0000'||'^'||'00000'||'^'||lpad('',5)||'^'||lpad('',5)||'^'||lpad('',5)||'^'||lpad('',13)||'^'||lpad('',13)||'^'||to_char(to_date('&1'),'ddmmyy')||'^'||lpad('',5)||'^'||lpad('',5)||'^'||lpad('',6)||'^'||lpad('',6)||'^'||lpad('',5)||'^'||lpad('',6)
from ici_gbm_bsrcode
where sol_id not in (select distinct b.sol_id from ici_gbm_challan_master a,icici_gbm_trn_hdr b where a.tax_tran_id = b.tax_tran_id and a.tax_tran_Date = b.tax_tran_date and a.realisation_date='&2' and a.del_flg='N' and a.major_tax_head in (select tax_head from ICI_GBM_MAJOR_HEAD where TAX_SCHEME='0004'))
/
spool off
