----------------------------------------------------------------------------------------------------
--   Source Name            : Report_lastacc.sql 
--   Description            : Last Access Report.
--   Input Values           : None
--   Output Values          : None
--   Called Script          : N.A
--   Calling Script         : N.A
--   Modification History:
--   Sl No.         Date              Author                     Description
--   --------------------------------------------------------------------------------------
--     01         11-Oct-2012         Priyanka                 Original Version
--	   02		  09-Mar-2013		  Kumar Gandharv		   Modified as per CR
----------------------------------------------------------------------------------------------------

set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_lastacc.lst

DECLARE

lv_solid    gam.sol_id%type :='&1';
date1       lcops.CHECK_DATE%type :='&2';
date2       lcops.CHECK_DATE%type :='&3';
lv_bankid   clmt.bank_id%type := '&4';

v_cifid        gam.cif_id%type;
v_jh1            lcops.JH_ID_1%type;
v_jh2            lcops.JH_ID_2%type;
v_jh3            lcops.JH_ID_3%type;
v_jh4            lcops.JH_ID_4%type;
v_jh5            lcops.JH_ID_5%type;
v_jh6            lcops.JH_ID_6%type;
v_poa1            lcops.LOA_ID_1%type;
v_poa2            lcops.LOA_ID_2%type;
v_poa3            lcops.LOA_ID_3%type;
v_poa4            lcops.LOA_ID_4%type;
v_poa5            lcops.LOA_ID_5%type;
v_poa6            lcops.LOA_ID_6%type;
v_custname        cmg.cust_name%type;
v_jhname1        lcops.JH_NAME_1%type;
v_jhname2        lcops.JH_NAME_2%type;
v_jhname3        lcops.JH_NAME_3%type;
v_jhname4        lcops.JH_NAME_4%type;
v_jhname5        lcops.JH_NAME_5%type;
v_jhname6        lcops.JH_NAME_6%type;
v_poaname1      lcops.LOA_NAME_1%type;
v_poaname2      lcops.LOA_NAME_2%type;
v_poaname3      lcops.LOA_NAME_3%type;
v_poaname4      lcops.LOA_NAME_4%type;
v_poaname5      lcops.LOA_NAME_5%type;
v_poaname6      lcops.LOA_NAME_6%type;
v_maxtime        lcops.check_in_time%type;
v_maxdatetime    lcops.check_in_time%type;

CURSOR c1 IS
select          
    a.sol_id,
    wlckm.RACK_ID,
    clmt.cif_id,
    wlckm.LOCKER_TYPE,
    wlckm.LOCKER_NUM,
    max(CHECK_DATE) check_date
from    
    lcops a,wlckm,clmt
where   
    wlckm.LOCKER_NUM = a.LOCKER_NO
and    wlckm.locker_num = clmt.locker_num
and    clmt.locker_num = a.locker_no
and    clmt.cif_id = a.cif_id
and    wlckm.sol_id = a.sol_id
and    a.sol_id = lv_solid
and    clmt.bank_id = a.bank_id
and    wlckm.bank_id = a.bank_id
and    a.bank_id = lv_bankid  
and    a.CHECK_DATE between to_date(date1) and to_date(date2)
and    wlckm.del_flg!='Y'
and    a.del_flg!='Y'
group by a.sol_id,wlckm.RACK_ID,clmt.cif_id,wlckm.LOCKER_TYPE,wlckm.LOCKER_NUM
union
select
	a.sol_id,
	wlckm.RACK_ID,
	clmt.cif_id,
	wlckm.LOCKER_TYPE,
	wlckm.LOCKER_NUM,
	max(CHECK_DATE) check_date
from 
	lcops a,wlckm,clmt
where
	wlckm.LOCKER_NUM = a.LOCKER_NO
and     wlckm.locker_num = clmt.locker_num
and     clmt.locker_num = a.locker_no
and     a.cif_id = ' '
and 	a.JH_ID_1 is not null 
and wlckm.sol_id = a.sol_id
and a.sol_id = lv_solid
and    a.bank_id = lv_bankid  
and a.CHECK_DATE between to_date(date1) and to_date(date2) 
and     wlckm.del_flg!='Y'
and     a.del_flg!='Y'
group by a.sol_id,wlckm.RACK_ID,clmt.cif_id,wlckm.LOCKER_TYPE,wlckm.LOCKER_NUM
order by check_date;

BEGIN

    for f1 in c1

    loop
        begin
        select max(check_in_time) into v_maxtime from lcops where locker_no = f1.locker_num
        and sol_id = f1.sol_id
        and check_date = f1.check_date
        and del_flg != 'Y';
        exception 
        when no_data_found then
        v_maxtime := '';
        end;

        begin
               SELECT distinct  
		 		nvl(cif_id,' '),
				nvl(JH_ID_1,' '),
				nvl(JH_ID_2,' '),
				nvl(JH_ID_3,' '),
				nvl(JH_ID_4,' '),
				nvl(JH_ID_5,' '),
				nvl(JH_ID_6,' '),
				nvl(LOA_ID_1,' '),
				nvl(LOA_ID_2,' '),
				nvl(LOA_ID_3,' '),
				nvl(LOA_ID_4,' '),
				nvl(LOA_ID_5,' '),
				nvl(LOA_ID_6,' '),
				nvl(substr(cust_name,1,40),' '),
				nvl(substr(JH_NAME_1,1,40),' '),
				nvl(substr(JH_NAME_2,1,40),' '),
				nvl(substr(JH_NAME_3,1,40),' '),
				nvl(substr(JH_NAME_4,1,40),' '),
				nvl(substr(JH_NAME_5,1,40),' '),
				nvl(substr(JH_NAME_6,1,40),' '),
				nvl(substr(LOA_NAME_1,1,40),' '),
				nvl(substr(LOA_NAME_2,1,40),' '),
				nvl(substr(LOA_NAME_3,1,40),' '),
				nvl(substr(LOA_NAME_4,1,40),' '),
				nvl(substr(LOA_NAME_5,1,40),' '),
				nvl(substr(LOA_NAME_6,1,40),' ')
        into    
                v_cifid,v_jh1,v_jh2,v_jh3,v_jh4,v_jh5,v_jh6,
                v_poa1,v_poa2,v_poa3,v_poa4,v_poa5,v_poa6,
                v_custname,v_jhname1,v_jhname2,v_jhname3,v_jhname4,v_jhname5,v_jhname6,
                v_poaname1,v_poaname2,v_poaname3,v_poaname4,v_poaname5,v_poaname6
        from
                lcops
        where
                sol_id = F1.SOL_ID
        and        locker_no = f1.LOCKER_NUM
        and     check_date = f1.check_date
        and     check_in_time = v_maxtime
        and        del_flg!='Y';
        exception 
        when no_data_found then
        v_cifid := '';
        v_jh1 := '';
        v_jh2 := '';
        v_jh3 := '';
        v_jh4 := '';
        v_jh5 := '';
        v_jh6 := '';
        v_poa1 := '';
        v_poa2 := '';
        v_poa3 := '';
        v_poa4 := '';
        v_poa5 := '';
        v_poa6 := '';
        v_custname := '';
        v_jhname1 := '';
        v_jhname2 := '';
        v_jhname3 := '';
        v_jhname4 := '';
        v_jhname5 := '';
        v_jhname6 := '';
        v_poaname1 := '';
        v_poaname2 := '';
        v_poaname3 := '';
        v_poaname4 := '';
        v_poaname5 := '';
        v_poaname6 := '';
        end;
        
        v_maxdatetime := f1.check_date ||'/'||v_maxtime;
    
         dbms_output.enable(buffer_size => NULL); 
        dbms_output.put_line(   f1.sol_id             ||'|'||
                                f1.rack_id            ||'|'||
                                v_cifid               ||'|'||
                                f1.locker_type        ||'|'||
                                f1.locker_num         ||'|'||
                                v_jh1                 ||'|'||
                                v_jh2                 ||'|'||
                                v_jh3                 ||'|'||
                                v_jh4                 ||'|'||
                                v_jh5                 ||'|'||
                                v_jh6                 ||'|'||
                                v_poa1                ||'|'||
                                v_poa2                ||'|'||
                                v_poa3                ||'|'||
                                v_poa4                ||'|'||
                                v_poa5                ||'|'||
                                v_poa6                ||'|'||
                                v_custname            ||'|'||
                                v_jhname1             ||'|'||
                                v_jhname2             ||'|'||
                                v_jhname3             ||'|'||
                                v_jhname4             ||'|'||
                                v_jhname5             ||'|'||
                                v_jhname6             ||'|'||
                                v_poaname1            ||'|'||
                                v_poaname2            ||'|'||
                                v_poaname3            ||'|'||
                                v_poaname4            ||'|'||
                                v_poaname5            ||'|'||
                                v_poaname6            ||'|'||
                                v_maxdatetime
                            ); 
   end loop; 
END;
/
spool off
