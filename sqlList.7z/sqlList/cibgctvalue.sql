---------------------------------------------------------------------------------
-- Filename         : cibgctvalue.sql
-- Description      : This sql file spools out specific details from gct table
--                    in specific format
-- Date             : 20-09-2012
-- Author           : Aparna Ashok
-- Menu Option      : HEXECOM
-- Modification History
-- Sl.#       Date           Author         Modification                              
-- -----   ----------   --------------    ----------------                               
--  1.0    20-09-2012   Aparna Ashok    Original Version                          
----------------------------------------------------------------------------------------------



set head off
set verify off
set feedback off
set trimspool on
set pages 0
set termout off
spool gctvalue.lst
select dc_alias||'|'||to_char(db_stat_date,'dd-mm-yyyy') from gct
where bank_id = '&1'
/
spool off
exit
