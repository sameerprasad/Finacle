column suffix new_value suffix
column dc new_value dc
column today new_value dt
column branch new_value br
break on SOL_ID skip page on part_tran_type skip 2
compute sum of tran_amt on part_tran_type
select to_char(db_stat_date,'ddmmyyyy') suffix from gct where bank_id = '&1';
select dc_alias dc from gct where bank_id = '&1';
/
set serveroutput on size 1000000
set linesize 132
set trims on
set escape /
set head off
set pages 0
set numformat 9999999999.99
set feedback off
set verify off
spool NEWEBA${CDCI_DC_ALIAS}&suffix
---alter session set optimizer_goal=rule
---/
select 'ALT'||'|'||
gam.foracid||'|'||
substr(lien_reason_code,1,3)||'|'||
substr(lien_remarks,4,5)||'|'||
alt.ts_cnt||'|'||
alt.lien_amt||'|'
from alt, gam
where foracid like '6156%' 
--where alt.b2k_type='ULIEN' 
--and alt.lien_reason_code in (select fin_reason_code from icici_rcmt where dcc_id='EBA' and bank_id = '&1')
and  gam.acid = alt.acid and alt.bank_id = '&1' and gam.bank_id = '&1'
order by gam.foracid
/
DECLARE
srl_num                             alh.srl_num%TYPE;
lien_remarks                        alh.lien_remarks%TYPE;
event_lien_amt                      alh.event_lien_amt%TYPE;
lien_amt                            alh.lien_amt%TYPE;
rcre_time                           alh.rcre_time%TYPE;
acid                                alh.acid%TYPE;
foracd                              varchar2(16);
srlnum                              varchar2(12);
datetime                            varchar2(20);
flg                                 integer;
CURSOR tst_alh IS SELECT  acid,srl_num,lien_remarks,event_lien_amt,lien_amt,rcre_time  from alh
   where b2k_type='ULIEN' and lien_reason_code in  (select fin_reason_code from icici_rcmt where dcc_id='EBA' and bank_id = '&1') and rcre_time >= (select db_stat_date from gct where bank_id = '&1');

BEGIN --{
	FOR tst_alh_rec in tst_alh 
	LOOP --{
            flg:=0;
        BEGIN
			SELECT  foracid    
			INTO 	foracd 
			FROM 	gam 
            WHERE   acid = tst_alh_rec.acid and bank_id = '&1';
			EXCEPTION
				WHEN OTHERS THEN
                    flg:=1;
                    goto avr;
        END;
		BEGIN
			SELECT 	ser_num,to_char(date_time,'DD-MM-YYYY HH24:MI:SS')
            INTO    srlnum,datetime
			FROM    icici_udmt
			WHERE command='USTR' and sub_command = substr(tst_alh_rec.lien_remarks,1,2) and date_time >= tst_alh_rec.rcre_time and dcc_id = 'EBA' and b2k_ser_num = tst_alh_rec.srl_num and bank_id = '&1';
			EXCEPTION
				WHEN OTHERS THEN
--                    flg:=1;
	                goto avr;	
		END;
<<avr>>
IF (flg <> 1) THEN
		dbms_output.put_line('ALH'||'|'||tst_alh_rec.srl_num||'|'||srlnum||'|'||foracd||'|'||substr(tst_alh_rec.lien_remarks,4,5)||'|'||tst_alh_rec.event_lien_amt||'|'||tst_alh_rec.lien_amt||'|'||substr(tst_alh_rec.lien_remarks,8,50)||'|'||datetime||'|'||substr(tst_alh_rec.lien_remarks,1,2)||'|');
END IF ;
flg:=0;
END LOOP; 
END;  
/
spool off

quit

