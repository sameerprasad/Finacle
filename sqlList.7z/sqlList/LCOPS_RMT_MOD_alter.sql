--================================================================================
--Source Name	:LCOPS_RMT_MOD_alter.sql
--Date			:12-Mar-2013
--Description	:This file includes alter statements to update CIF_ID length column for LCOPS_RMT_MOD table and adds bank_id
--Author		:Kumar Gandharv
--Modification History	:
--<Serial No>     <Date>        <Author>            <Description>
--================================================================================
ALTER TABLE icici.LOCKER_OPER_MAIN_RMT_MOD RENAME COLUMN CUST_ID TO CIF_ID;
ALTER TABLE icici.LOCKER_OPER_MAIN_RMT_MOD MODIFY CIF_ID VARCHAR2(50 CHAR);
update  icici.LOCKER_OPER_MAIN_RMT_MOD set CIF_ID=TRIM(CIF_ID); 
ALTER TABLE icici.LOCKER_OPER_MAIN_RMT_MOD ADD BANK_ID VARCHAR2(8);
