set serveroutput on size 1000000
set lines 200
set trimspool on
set termout off
set verify off
set echo off
set feedback off
spool shrofCashRpt.dat

declare

	cursor c1(cacid varchar2, cpstduser dtd.pstd_user_id%TYPE) is 
	SELECT 
	DTD.tran_date,
	DTD.tran_id,
	DTD.part_tran_srl_num, 
	DTD.acid, 
	DTD.sol_id, 
	DTD.pstd_flg, 
	DTD.tran_amt, 
	DTD.tran_crncy_code, 
	DTD.ref_amt, 
	DTD.ref_crncy_code, 
	DTD.rate_code, 
	DTD.rate, 
	DTD.entry_user_id, 
	DTD.pstd_user_id, 
	DTD.vfd_user_id, 
	DTD.del_flg, 
	DTD.part_tran_type 
	FROM  DTD 
	WHERE 
	DTD.acid = cacid AND DTD.tran_type = 'C' AND
	DTD.tran_crncy_code = 'INR' and
	DTD.pstd_user_id =  cpstduser and
        DTD.bank_id = '&3' and 
	((DTD.restrict_modify_ind != 'T') OR (DTD.restrict_modify_ind is null ));

	cursor c2(ctranid dtd.tran_id%type, ctrandate date, loc_cash_ptran_num dtd.part_tran_srl_num%type) is
	SELECT tran_id,
	TO_CHAR(DTD.TRAN_DATE, 'DD-MM-YYYY HH24:MI:SS'),
	DTD.part_tran_srl_num,
	DTD.acid,
	GAM.foracid,
	DTD.sol_id,
	pstd_flg,
	DTD.tran_amt,
	DTD.tran_crncy_code,
	DTD.ref_amt,
	DTD.ref_crncy_code,
	DTD.rate_code,
	DTD.rate,
	DTD.entry_user_id,
	DTD.pstd_user_id,
	DTD.vfd_user_id,
	DTD.instrmnt_num,
	DTD.tran_particular,
	DTD.del_flg,
	DTD.part_tran_type,
	GAM.acct_crncy_code
	FROM  DTD, GAM
	WHERE
	DTD.acid = GAM.acid AND DTD.part_tran_srl_num != loc_cash_ptran_num AND
	DTD.tran_id = ctranid AND
	DTD.tran_date = ctrandate and
	DTD.tran_type = 'C' AND
	nvl(DTD.tran_particular_code,' ') = 'TBLPC' and
	DTD.ref_crncy_code = 'INR' and
        DTD.bank_id = GAM.bank_id and 
        DTD.bank_id = '&3' and
	((DTD.restrict_modify_ind != 'T') OR (DTD.restrict_modify_ind is NULL) )
	ORDER BY GAM.FORACID;


	loc_gam_acid	GAM.acid%TYPE;
	loc_cash_foracid GAM.foracid%TYPE;
	loc_pstd_user  DTD.pstd_user_id%TYPE;

BEGIN --{

loc_cash_foracid := upper('&1');
loc_pstd_user := upper('&2');

select distinct gam.acid into loc_gam_acid
	from GAM, GEC where
	GAM.FORACID = loc_cash_foracid and
	GEC.emp_id = (select user_emp_id from upr where user_id = loc_pstd_user) and
	GEC.crncy_code = 'INR' and
	GEC.sol_id = (select sol_id from upr where user_id = loc_pstd_user) AND
	GAM.bacid = GEC.emp_cash_acct AND
	GEC.del_flg !=  'Y' AND
	GAM.acct_crncy_code = GEC.crncy_code AND
	GAM.sol_id = GEC.sol_id AND
	GAM.acct_cls_flg != 'Y' AND GAM.del_flg != 'Y' AND GEC.bank_id = GAM.bank_id AND GAM.bank_id = '&3';

	for carec in c1(loc_gam_acid, loc_pstd_user)
	loop --{

		begin --{

			for corec in c2(carec.tran_id, carec.tran_date, carec.part_tran_srl_num)
			loop --{

				begin --{

					dbms_output.put_line('0'||'|'||loc_cash_foracid||'|'||carec.tran_crncy_code||'|'||carec.sol_id||'|'||carec.part_tran_type||'|'||carec.tran_id||'|'||carec.tran_date||'|'||carec.part_tran_srl_num||'|'||carec.part_tran_srl_num||'|'||loc_cash_foracid||'|'||'|'||carec.tran_crncy_code||'|'||carec.sol_id||'|'||carec.part_tran_type||'|'||carec.tran_amt||'|'||carec.ref_crncy_code||'|'||carec.ref_amt||'|'||'0.00'||'|'||carec.rate_code||'|'||carec.rate||'|'||carec.entry_user_id||'|'||carec.pstd_flg||'|'||carec.pstd_user_id||'|'||carec.vfd_user_id||'|'||'|'||'|'||carec.del_flg||'|'||carec.part_tran_type);

					dbms_output.put_line('1'||'|'||loc_cash_foracid||'|'||carec.tran_crncy_code||'|'||carec.sol_id||'|'||carec.part_tran_type||'|'||carec.tran_id||'|'||carec.tran_date||'|'||carec.part_tran_srl_num||'|'||corec.part_tran_srl_num||'|'||corec.foracid||'|'||'|'||corec.tran_crncy_code||'|'||corec.sol_id||'|'||corec.part_tran_type||'|'||corec.tran_amt||'|'||corec.ref_crncy_code||'|'||corec.ref_amt||'|'||'0.00'||'|'||corec.rate_code||'|'||corec.rate||'|'||corec.entry_user_id||'|'||corec.pstd_flg||'|'||corec.pstd_user_id||'|'||corec.vfd_user_id||'|'||corec.instrmnt_num||'|'||corec.tran_particular||'|'||corec.del_flg||'|'||corec.part_tran_type);
				end; --}
				
			end loop; --}

		end; --}


	end loop; --}

exception
when no_data_found then dbms_output.put_line('User Id do not match with Teller Account');

when others then dbms_output.put_line('SQL error: '||sqlcode||' '||sqlerrm);

end; --}

/

spool off
