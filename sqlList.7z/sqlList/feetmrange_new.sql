host \rm -f FEETMNEW*lst 2>/dev/null
set pagesize 80
set feedback off
column DC new_value dcalias
select dc_alias DC from gct;
column D new_value dt
define sep = :
select db_stat_date D from gct;
spool feetmnew1
set head off
set numformat 99,99,99,999.99
set linesize 500
set trims on
set verify off
break on report skip 1
select 'DATE:SOL_ID:TRAN_ID:AMT:CR_OR_DR:INST_CODE:ROLL NO:CLASS:REF NO:STUDENT NAME:COURSE' from dual;
--compute SUM of AMT on report
select 
	htd.tran_date, '&sep',
	htd.sol_id, '&sep',
	htd.tran_id, '&sep',
	htd.tran_amt AMT, '&sep',
	htd.part_tran_type, '&sep',
	htd.tran_particular, '&sep',
	' ' , '&sep',
	htd.tran_rmks, '&sep', 
	htd.instrmnt_num, '&sep', 
	'ICICI BANK LIMITED'
from gam,htd,ott
where gam.acid=htd.acid
and ott.acid=htd.acid
and htd.del_flg!='Y'
and gam.foracid = '0036SLFCSCOL'
and htd.tran_date between to_date('&1','dd-mm-yyyy') and to_date('&2','dd-mm-yyyy')
and VFD_DATE is not null
and htd.tran_type !='L'
--and.ott.part_tran_type='C'
and htd.tran_id=ott.tran_id
and htd.tran_date=ott.tran_date
and htd.part_tran_srl_num=ott.part_tran_srl_num
and ott.del_flg!='Y'
and ott.org_tran_amt<>ott.total_offset_amt
and ott.bank_id = htd.bank_id
and htd.bank_id = gam.bank_id
and gam.bank_id = '&3'
/
spool off
host chmod 777 feetmnew1.lst
host cp feetmnew1.lst FEETMNEWR&dcalias&dt..lst 2>/dev/null
host cp feetmnew1.lst feetmrange_new.lst
host chmod 777 FEETMNEW*.lst
host mailx -s FEETMNEWR&dcalias&dt..lst -s "Fee Coll TM-Range for &dcalias " feecollection@icicibank.com < /dev/null
host mailx -s FEETMNEWR&dcalias&dt..lst -s "Fee Coll TM-Range for &dcalias " feecollection@icicibank.com < /dev/null
host mailx -s FEETMNEWR&dcalias&dt..lst -s "Fee Coll TM-Range for &dcalias " ctu@icicibank.com < /dev/null
host mailx -s  FEETMNEWR&dcalias&dt..lst -s "Fee Coll TM-Range for &dcalias " ctu@icicibank.com < /dev/null
