--================================================================================================
--Filename		:icidca.sql
--Description		:SQL for generating report
--Date			:22-6-2012
--Author		:Supreeth Vasudeva Murthy
--Menu Option		:ICIDCA
--Modification History	:
--Sl. #		Date		Author				Modification                              
--------	----------	------------			------------                               
--1		22-6-2012	Supreeth Vasudeva Murthy	SQL for generating report                         
--================================================================================================

SET PAGES 0 LINE 400 FEED OFF TERM OFF VERI OFF ECHO OFF HEAD OFF
SET SERVEROUTPUT ON
SET TRIMSPOOL ON
SPOOL icidca.list
DECLARE

vstr_CUST_COMU_STATE_CODE	VARCHAR2(100);
vstr_CUST_COMU_CNTRY_CODE	VARCHAR2(100);
vstr_CUST_COMU_CITY_CODE	VARCHAR2(100);
vstr_CUST_COMU_CITY		VARCHAR2(100);
vstr_CUST_COMU_STATE		VARCHAR2(100);
vstr_CUST_COMU_CNTRY		VARCHAR2(100);
vstr_MODE_OF_OPER		VARCHAR2(100);
vstr_PhoneNo2			VARCHAR2(100);
v_recCnt			NUMBER(9);

CURSOR getData IS
SELECT cmg.cif_id,foracid,acct_crncy_code,deposit_amount,
maturity_amount,open_effective_date,maturity_date,
deposit_period_mths,deposit_period_days,schm_code,
mode_of_oper_code,cust_title_code,name as cust_name,address_line1 as cust_comu_addr1,
address_line2 as cust_comu_addr2,city as cust_comu_city_code,COUNTRY as cust_comu_cntry_code,
state as cust_comu_state_code,zip as cust_comu_pin_code,phoneno
FROM tbaadm.gam,tbaadm.tam,tbaadm.cmg ,tbaadm.cphone,crmuser.accounts
WHERE gam.acid=tam.acid
AND gam.cif_id=cphone.phone_b2kid
AND gam.cif_id = cmg.cif_id
and crmuser.accounts.orgkey=gam.cif_id
AND gam.foracid = '&1'
AND cphone.PREFERREDFLAG='Y';

BEGIN
	v_recCnt:=0;
    FOR A IN getData
    LOOP
    --begin
	v_recCnt:=v_recCnt+1;
	BEGIN
	--{
		SELECT REF_DESC 
		INTO vstr_CUST_COMU_CITY
		FROM tbaadm.RCT
		WHERE REF_CODE = A.cust_comu_city_code
		AND ref_rec_type = '01'
		AND del_flg   = 'N'	
		AND ROWNUM < 2;

		EXCEPTION
		WHEN NO_DATA_FOUND THEN
		vstr_CUST_COMU_CITY := '';
	--}    
	END;

	BEGIN
	--{
		SELECT REF_DESC 
		INTO vstr_CUST_COMU_STATE
		FROM tbaadm.RCT
		WHERE REF_CODE = A.cust_comu_state_code
		AND ref_rec_type = '02'
		AND del_flg   = 'N'	
		AND ROWNUM < 2;

		EXCEPTION
		WHEN NO_DATA_FOUND THEN
		vstr_CUST_COMU_STATE := '';
	--}    
	END;
	BEGIN
	--{
		SELECT REF_DESC
		INTO vstr_MODE_OF_OPER
		FROM tbaadm.RCT
		WHERE REF_CODE = A.mode_of_oper_code
		AND del_flg   = 'N' 
		AND ref_rec_type = '27'
                AND ROWNUM < 2;                

		EXCEPTION
		WHEN NO_DATA_FOUND THEN
		vstr_CUST_COMU_CNTRY := '';
	--}
	END; 
        

	BEGIN
	--{
		SELECT REF_DESC 
		INTO vstr_CUST_COMU_CNTRY
	        FROM tbaadm.RCT	
                WHERE REF_CODE = A.cust_comu_cntry_code
		AND ref_rec_type = '03'
		AND del_flg   = 'N'
		AND ROWNUM < 2;

		EXCEPTION
		WHEN NO_DATA_FOUND THEN
		vstr_CUST_COMU_CNTRY := '';
	--}	
	END;
DBMS_OUTPUT.PUT_LINE(A.cif_id||'|'||A.foracid||'|'||A.acct_crncy_code||'|'||A.deposit_amount||'|'||A.maturity_amount||'|'||A.open_effective_date||'|'||A.maturity_date||'|'||A.deposit_period_mths||'|'||A.deposit_period_days||'|'||A.schm_code||'|'||vstr_MODE_OF_OPER||'|'||A.cust_title_code||'|'||A.cust_name||'|'||A.cust_comu_addr1||'|'||A.cust_comu_addr2||'|'||vstr_CUST_COMU_CITY||'|'||vstr_CUST_COMU_STATE||'|'||A.cust_comu_pin_code||'|'||vstr_CUST_COMU_CNTRY||'|'||A.phoneno||'|'||vstr_PhoneNo2);
       END LOOP;
	IF(v_recCnt = 0)THEN
		DBMS_OUTPUT.PUT_LINE('No records found||||||||||||||||||||');
	END IF;
END;
/
SPOOL OFF
