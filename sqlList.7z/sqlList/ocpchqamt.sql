set pages 80
set feedback off
set verify off
set term off
set lines 132
spool /tmp/ocpchqamt
select substr(gam.foracid,1,12) ACCT,substr(acct_name,1,15) NAME,ocp.clg_zone_date ZNDT,
substr(ocp.clg_zone_code,1,2) CD, instrmnt_amt AMOUNT, ocp.set_num SET_NUM,oci.bank_code BNK,
oci.br_code BR,ocp.tran_id TRN_ID, substr(ocp.entry_user_id,1,9) ENTD,
substr(ocs.vfd_user_id,1,9) VFD,ocp.status_flg STS, ocp.sol_id SOL
from gam,ocp,oci,ocs
where ocp.sol_id='&1'
and ocp.clg_zone_date between (to_date('&2','dd-mm-yyyy')) and to_date(to_date('&2','dd-mm-yyyy'))+7
and instrmnt_amt||NULL=&3
and oci.sol_id=ocp.sol_id
and oci.sol_id=ocs.sol_id
and ocp.sol_id=ocs.sol_id
and oci.clg_zone_date=ocp.clg_zone_date
and oci.clg_zone_date=ocs.clg_zone_date
and ocp.clg_zone_date=ocs.clg_zone_date
and oci.clg_zone_code=ocp.clg_zone_code
and oci.clg_zone_code=ocs.clg_zone_code
and ocp.clg_zone_code=ocs.clg_zone_code
and oci.set_num=ocp.set_num
and oci.set_num=ocs.set_num
and ocp.set_num=ocs.set_num
and ocp.acid=gam.acid
and ocp.del_flg='N'
and gam.bank_id = '&4' 
and oci.bank_id = '&4' 
and oci.bank_id = ocp.bank_id
and oci.bank_id = ocs.bank_id
and ocp.bank_id = ocs.bank_id
/
spool off
