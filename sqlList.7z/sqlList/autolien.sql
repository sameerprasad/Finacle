set pages 22
set lines 120
set feedback off
set verify off
set trims on
set termout off

spool autolien.lst

set echo off head off pagesi 60 verify off feedback off serveroutput on size 1000000 linesi 180
select foracid from gam where schm_type='TDA' and schm_code='CFSEC' and acct_opn_date=to_date('&2','dd-mm-yyyy') and bank_id='&3' and sol_id in (select sol_id from sst where set_id='&1' and bank_id='&3') and acid not in (select acid from alt where b2k_type='ULIEN' and bank_id='&3')
/
spool off
exit
