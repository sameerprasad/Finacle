-- #############################################################
-- #	Source Name: lnrecble.sql				   		       #
-- #	Description: This script is used to get the required   #
-- #				 details for ROD receivables			   #
-- #				 history details						   #
-- #				 in ~ seperated format.                    #
-- #############################################################

Set ServerOutPut On Size 1000000
--Set Verify Off
--Set FeedBack off
--set line 80
set trims on

--Spool lnrecble.txt

DECLARE

inpDate				varchar2(25);

-- Temporary variables.
lnrecble			UTL_FILE.FILE_TYPE;
tmpAcid				GAM.acid%type;
acnum				GAM.foracid%type;
duedate				ROBT.payment_due_date%type;
amtdue				ROBT.min_amt_due%type; 
amtbilled			ROBT.bill_amt%type;
latefee				ROBT.late_fee_amt%type;
seqnumb				number(4) := 1;
typ					number(1) := 5;
dueChar				varchar2(10);
det_line1			varchar2(1000) := '';
l_bank_id			VARCHAR2(8) := '&1';

CURSOR 	RSP_CURSOR IS 
	SELECT 	gam.acid,foracid,clr_bal_amt
	FROM 	gam,gac
	WHERE 	gam.acid = gac.acid
	AND		gam.schm_code in (	select 	distinct schm_code 
								from 	RSP 
								where 	entity_cre_flg = 'Y'
								and 	del_flg != 'Y')
	AND		gac.dpd_cntr >= 1
--	AND		gam.acct_cls_flg != 'Y'
	AND		gam.entity_cre_flg = 'Y'
	AND		gam.del_flg != 'Y'
	AND	        gam.bank_id = l_bank_id
	AND	        gac.bank_id = l_bank_id
	ORDER BY acid;


BEGIN
--{
	lnrecble	:= UTL_FILE.FOPEN('/tmp','ex_lnrecble.csv','w');

	OPEN RSP_CURSOR;

	LOOP
	--{
		acnum := NULL;
	
		FETCH RSP_CURSOR into 	tmpAcid,acnum,amtdue;

		EXIT WHEN RSP_CURSOR%NOTFOUND;
		
		IF (acnum is NOT NULL) THEN
		--{
			duedate := NULL;
			amtbilled := 0;
			
			BEGIN
			--{
				SELECT 	payment_due_date,nvl(bill_amt,0),nvl(late_fee_amt,0)
				INTO 	duedate,amtbilled,latefee
				FROM 	ROBT
				WHERE	acid = tmpAcid
				AND		stmt_end_date =(select	max(stmt_end_date)
										from	robt
										where 	acid = tmpAcid
										AND	bank_id = l_bank_id)
				AND	bank_id = l_bank_id;

			EXCEPTION WHEN OTHERS THEN
				duedate := NULL;
				amtbilled := 0;
				latefee := 0;
			--}
			END;
			
			amtdue := amtbilled;
			typ := 5;

--***		Clarify typ

-- 			if (latefee != 0) then
--				typ := 2;
--			else
--				typ := 5;
--			end if;
				
			begin
			--{
				select	to_char(duedate,'mm-dd-yyyy')
				into	dueChar
				from	DUAL;
			exception
				WHEN OTHERS THEN NULL;
			--}
			end;

			det_line1 := acnum||'~'||dueChar||'~'||seqnumb||'~'||typ||'~'||abs(amtdue)||'~0~'||abs(amtbilled);
			UTL_FILE.PUT_LINE(lnrecble,det_line1);
--			seqnumb := seqnumb + 1;
		--}
		END IF;
	--}
	END LOOP;

	UTL_FILE.FCLOSE(lnrecble);
	CLOSE RSP_CURSOR;
--}
END;
/
--exit
--spool off
