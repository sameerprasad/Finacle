-- ----------------------------------------------------------------------------------------------------------
-- Source Name		geoPspTmpCust.sql
-- Description		Logic to fetch customer details and insert record in PSP_TMP
-- Author
-- Date
-- Modification History
-- ----------------------------------------------------------------------------------------------------------
-- Modified by          Date           Purpose of Modification
-- ----------------------------------------------------------------------------------------------------------
-- Gauri		08-05-2013	Changed cmg fields of address to cnma and 
--					added the logic to fetch phone number from phoneemail
-- ----------------------------------------------------------------------------------------------------------
set serveroutput on size 1000000 
set feedback off
set verify   off
set termout   off
set head off
set pages 0
set linesize 512
set trims on
spool &1-&2-&3-&4

DECLARE
cnt			number;
firstAcc		GAM.FORACID%Type;
runId			varchar2(20);
custId			ICICI_CIFT.CIF_ID%Type;
solId			ICICI_CIFT.HOME_SOL_ID%Type;
ciftCustId		ICICI_CIFT.CIF_ID%Type;
ciftStmtReqd            ICICI_CIFT.stmt_reqd%TYPE;
dispMode            ICICI_CIFT.stmt_reqd%TYPE;
gamForacid		GAM.FORACID%Type;
custRecType		VARCHAR(3);
custSubRecType	VARCHAR(3);
pspCustListId	PSP_TMP.LISTID%Type;
pspAcctListId	PSP_TMP.LISTID%Type;
endOfGamCursor	NUMBER;
step			NUMBER(5);
likeStr			varchar2(25);
ciftEmailId		ICICI_CIFT.EMAIL_ID%Type;
cmgTitleName	varchar2(100);
cmgAddr1		CNMA.ADDRESS1%TYPE;
cmgAddr2		CNMA.ADDRESS2%TYPE;
cmgCityCode		CNMA.city_code%TYPE;
cmgStateCode	CNMA.state_code%TYPE;
cmgCntryCode	CNMA.cntry_code%TYPE;
cmgCustStatCode CMG.cust_stat_code%TYPE;
cmgPinCode		CNMA.pin_code%TYPE;
cmgPhone1		CRMUSER.PHONEEMAIL.phoneno%TYPE;	
cmgPhone2		CRMUSER.PHONEEMAIL.phoneno%TYPE;	
idType			char(2);
idTypeOld			char(1);
-- Changes for custnreflg
cmgCustNreFlag	cmg.cust_nre_flg%type;
cmgConst		cmg.cust_const%type;
tmpConst		cmg.cust_const%type;
wbgCust			char(1);

cityDesc		RCT.ref_desc%TYPE;
stateDesc		RCT.ref_desc%TYPE;
cntryDesc		RCT.ref_desc%TYPE;

carRec          varchar2(500);
	
CURSOR gamCur IS 
SELECT	
	FORACID
FROM	
	GAM
WHERE	
	CIF_ID = custId
AND	(SCHM_TYPE = 'SBA' OR ACCT_PREFIX = '05' or ACCT_PREFIX = '51')
AND	((ACCT_CLS_FLG = 'N' AND ACCT_OPN_DATE <= to_date('&7','dd-mm-yyyy')) OR
	 (ACCT_CLS_FLG = 'Y' AND ACCT_CLS_DATE > to_date('&7','dd-mm-yyyy')))
AND	ENTITY_CRE_FLG = 'Y'  AND BANK_ID = '&9' order by foracid ;


PROCEDURE insertPspTmp( pspListId VARCHAR2,
		                pspEntityId VARCHAR2,
		                pspEntityType CHAR,
						pspHomeSolId VARCHAR2) IS
BEGIN
	step := 5;
	INSERT INTO
	PSP_TMP
		(LISTID
		,ENTITY_ID
		,ID_TYPE
		,HOME_SOL_ID
                ,BANK_ID)
	VALUES
		(pspListId
		,pspEntityId
		,pspEntityType
		,pspHomeSolId
                ,'&9');
END insertPspTmp;


PROCEDURE processGamCursor( dummy NUMBER) IS
BEGIN
	step := 4;
	FETCH gamCur
	INTO gamForacid;

	IF( gamCur%NOTFOUND ) then 
		endOfGamCursor := 1; 
		RETURN; 
	END IF; 

	if(cnt = 0) then
		firstAcc := gamForacid;
		cnt := 1;
	end if;

        if (substr(gamForacid,5,2) != '51') then
                insertPspTmp(pspAcctListId, gamForacid, idTypeOld, solId);
        else
           if (dispMode = 'E') then
                insertPspTmp(pspAcctListId, gamForacid, idTypeOld, solId);
           end if;
        end if;

END processGamCursor;
		

BEGIN
	custRecType		:= '01';
	custSubRecType	:= '0';
	cnt		:= 0;
	runId			:= '&1';
	solId			:= '&2';
	idType			:= substr('&4',1,2);
	idTypeOld		:= substr('&4',1,1);
	--custId			:= lpad('&5', 9);
        custId                  := '&5';
	dispMode                := '&8';
	pspCustListId	:= runId||solId||idType||'C';
	pspAcctListId	:= runId||solId||idType||'A';

	OPEN gamCur;
	endOfGamCursor := 0;

	firstAcc := '';
	WHILE (endOfGamCursor = 0) LOOP
		processGamCursor(0);
	END LOOP;

	CLOSE gamCur;

	SELECT	cust_title_code || '.' || cust_name,
		--	cust_comu_addr1,
	--		cust_comu_addr2,
	--		cust_comu_city_code,
	--		cust_comu_state_code,
	--		cust_comu_cntry_code,
	--		cust_comu_pin_code,
			--cust_comu_phone_num_1,
                        --cust_comu_phone_num_2,
	--		phone,
			cust_stat_code,
			cust_nre_flg,
			cust_const
	INTO	cmgTitleName,
	--		cmgAddr1,
	--		cmgAddr2,
	--		cmgCityCode,
	--		cmgStateCode,
	--		cmgCntryCode,
	--		cmgPinCode,
			--cmgPhone1,
			--cmgPhone2, 
         --               cmgPhone,
			cmgCustStatCode, 
			cmgCustNreFlag,
			cmgConst
	FROM	CMG
	WHERE	CIF_ID = custId  AND BANK_ID = '&9';

	if(cmgCustNreFlag = 'Y') then
		cmgCustStatCode := 'NRI';
	end if;

	if(substr(cmgCustStatCode,1,3) = 'HNI') then
		cmgCustStatCode := 'HNI';
	end if;

	BEGIN
		SELECT address1,
		address2,
		city_code,
		state_code,
		cntry_code,
		pin_code
		INTO
			cmgAddr1,
			cmgAddr2,
			cmgCityCode,
			cmgStateCode,
			cmgCntryCode,
			cmgPinCode
		FROM CNMA
		WHERE ADDR_B2KID = custId
		AND ADDR_ID = 'Mailing' 
		AND BANK_ID = '&9';

	EXCEPTION
	WHEN OTHERS THEN
		cmgAddr1:= ' ';
		cmgAddr2:= ' ';
		cmgCityCode:= ' ';
		cmgStateCode:=' ';
		cmgCntryCode:=' ';
		cmgPinCode:=' ';
	END;
	
	BEGIN
		SELECT NVL(a.phoneno,'*'), NVL(b.phoneno,'*')
                        INTO
                        cmgPhone1,
                        cmgPhone2
                        FROM crmuser.phoneemail a , crmuser.phoneemail b
                        WHERE a.orgkey = custId 
                        AND a.orgkey = b.orgkey
                        AND a.bank_id = '&9'
                        AND a.bank_id = b.bank_id
                        AND a.phoneoremail = 'PHONE'
                        AND a.phoneoremail = b.phoneoremail
                        AND a.phoneemailtype = 'COMMPH1' 
                        AND b.phoneemailtype = 'COMMPH2';
	EXCEPTION
        WHEN OTHERS THEN
		cmgPhone1:= ' ';
		cmgPhone2:= ' ';
	END;	
	SELECT  cif_id,
		email_id,
		stmt_reqd
	INTO
		ciftCustId,
		ciftEmailId,
		ciftStmtReqd
	FROM ICICI_CIFT
 	WHERE   CIF_ID = custId  AND BANK_ID = '&9';

	if (cmgCityCode is not null) then
		BEGIN
		SELECT	ref_desc
		INTO	cityDesc
		FROM	RCT
		WHERE	ref_rec_type = '01'
		AND		ref_code = cmgCityCode
                AND BANK_ID = '&9';
		EXCEPTION WHEN OTHERS THEN NULL;
		END;
	else
		cityDesc := '';
	end if;

	if (cmgStateCode is not null) then
		BEGIN
		SELECT	ref_desc
		INTO	stateDesc
		FROM	RCT
		WHERE	ref_rec_type = '02'
		AND		ref_code = cmgStateCode AND BANK_ID = '&9';
		EXCEPTION WHEN OTHERS THEN NULL;
		END;
	else
		stateDesc := '';
	end if;

	if (cmgCntryCode is not null) then
		BEGIN
		SELECT	ref_desc
		INTO	cntryDesc
		FROM	RCT
		WHERE	ref_rec_type = '03'
		AND		ref_code = cmgCntryCode  AND BANK_ID = '&9';
		EXCEPTION WHEN OTHERS THEN NULL;
		END;
	else
		cntryDesc := '';
	end if;

	-- Check if cust const is one of WBG const codes

	wbgCust := 'N';
	tmpConst := '';

	BEGIN
		select key_value into tmpConst from fsg_cfg where key_type = 99 and
		key_value = cmgConst  AND BANK_ID = '&9';	

		if(tmpConst = cmgConst) then
			wbgCust := 'Y';
		end if;

		exception
			when others then null;
--                         when no_data_found then null;
	END;

	if(wbgCust = 'N') then
		tmpConst := '';
	end if;

	if ( cnt > 0 ) then
		insertPspTmp(pspCustListId, custId, idTypeOld, solId);

	if ( dispMode = 'E' ) then
               dbms_output.put_line(    solId               || '|' ||
                                ciftCustId              || '|01|0|' ||
                                ciftEmailId             || '|' ||
                                ltrim(rtrim(cmgTitleName))    || '|' ||
                                ltrim(rtrim(cmgAddr1))                || '|' ||
                                ciftCustId               || '|' ||
                                ltrim(rtrim(cityDesc))              || '|' ||
                                ltrim(rtrim(stateDesc)) || '|' ||
                                ltrim(rtrim(cntryDesc)) || ' - ' ||
                                ltrim(rtrim(cmgPinCode)) || '|' ||
 				cmgCustStatCode || '|' ||
                                dispMode ||'|'||firstAcc||'||'||tmpConst);
			else
				if(wbgCust = 'Y') then
					carRec:= solId||'|'||ciftCustId||'|01|0|'||ltrim(rtrim(ciftEmailId))||'|'||
					ltrim(rtrim(cmgTitleName))||'|'||ltrim(rtrim(cmgAddr1))||'|'||
					ltrim(rtrim(cmgAddr2))||'|'||ltrim(rtrim(cityDesc))||'|'||
					ltrim(rtrim(stateDesc))||'|'||ltrim(rtrim(cntryDesc))||' - '||
					ltrim(rtrim(cmgPinCode))||'|'||cmgCustStatCode||'|'||'Y'||'|'||
					firstAcc||'||'||tmpConst;
					dbms_output.put_line(carRec);
				else
					carRec:= solId||'|'||ciftCustId||'|01|0|'||ltrim(rtrim(ciftEmailId))||'|'||
					ltrim(rtrim(cmgTitleName))||'|'||ltrim(rtrim(cmgAddr1))||'|'||
					ltrim(rtrim(cmgAddr2))|| '|' ||ltrim(rtrim(cityDesc))||'|'||
					ltrim(rtrim(stateDesc))||'|'||ltrim(rtrim(cntryDesc))||' - '||
					ltrim(rtrim(cmgPinCode))||'|'||cmgCustStatCode||'|'||'Y'||'|'||
					ltrim(rtrim(cmgPhone1))||' - '||ltrim(rtrim(cmgPhone2)) || '||'||tmpConst;
                                        --ltrim(rtrim(cmgPhone)) || '||'||tmpConst;

					if(length(carRec) > 255) then
						carRec :=  solId||'|'||ciftCustId||'|01|0|'||'|'||
						ltrim(rtrim(cmgTitleName))||'|'||ltrim(rtrim(cmgAddr1))||'|'||
						ltrim(rtrim(cmgAddr2))|| '|' ||ltrim(rtrim(cityDesc))||'|'||
						ltrim(rtrim(stateDesc))||'|'||ltrim(rtrim(cntryDesc))||' - '||
						ltrim(rtrim(cmgPinCode))||'|'||cmgCustStatCode||'|'||'Y'||'|'||
						ltrim(rtrim(cmgPhone1))||' - '||ltrim(rtrim(cmgPhone2)) || '||'||tmpConst;
                                                --ltrim(rtrim(cmgPhone)) || '||'||tmpConst;

						if(length(carRec) > 255) then
							carRec :=  solId||'|'||ciftCustId||'|01|0|'||'|'||
							ltrim(rtrim(cmgTitleName))||'|'||ltrim(rtrim(cmgAddr1))||'|'||
							ltrim(rtrim(cmgAddr2))|| '|' ||ltrim(rtrim(cityDesc))||'|'||
							ltrim(rtrim(stateDesc))||'|'||ltrim(rtrim(cntryDesc))||' - '||
							ltrim(rtrim(cmgPinCode))||'|'||cmgCustStatCode||'|'||'Y'||'|'||
							'||'||tmpConst;
							dbms_output.put_line(carRec);
						else
							dbms_output.put_line(carRec);
						end if;
					else
						dbms_output.put_line(carRec);
					end if;
			 	end if; -- (if WBGCust = Y)
			end if; -- (If dispMode = E)
	end if; -- (If cnt > 0)
	EXCEPTION
	WHEN OTHERS THEN
        --WHEN NO_DATA_FOUND THEN 
		DBMS_OUTPUT.PUT_LINE('<#ORA-ERROR#>');
		DBMS_OUTPUT.PUT_LINE('Cust Id/Account Id list creation failed at step...'||step);
		DBMS_OUTPUT.PUT_LINE('Cust Id '||custId);
		DBMS_OUTPUT.PUT_LINE('Check SQL error,  and try again');
		DBMS_OUTPUT.PUT_LINE('Sql Error Code is        : ' || SQLCODE );
		DBMS_OUTPUT.PUT_LINE('SQL Error Description is : '|| SQLERRM);
		ROLLBACK;
		DBMS_OUTPUT.PUT_LINE('Currenct Chunk rolled back.');
END;
/
spool off
