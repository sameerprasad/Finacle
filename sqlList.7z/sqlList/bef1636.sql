--generates details of entries where BEF not received.
set verify off
rem accept solid prompt 'ENTER THE SOL_ID OF YOUR BRANCH : '
rem accept dt1   prompt 'Enter report date[ DD-MM-YYYY ] : '
set newpage 0
set linesi 130 
set pagesi 60
set numformat '9999999999.99'
col a new_value b
col c new_value d
select to_char(sysdate,'dd-mm-yyyy') a from dual ;
select ltrim(rtrim(sol_desc)) c from sol where sol_id = '&1' and bank_id='&3';
----
col BILL_ID heading 'BILL_ID' format a15
col REALSD_DATE heading 'REALISED|DATE' format a10
col NAME heading 'PARTY NAME' format a25
col AMT heading 'BILL AMOUNT' format 9999,99,99,999.99
col CUR heading 'CURRENCY' format a8
col ONAME heading 'OTHER PARTY|NAME' format a25
col INV heading 'INVOICE NUMBER' format a15
----
ttitle center 'ICICI BANK LTD.' skip 1 -
center d ' BRANCH' skip 2 -
center 'LIST OF REALISED BILLS WHERE BEF IS NOT RECEIVED ' skip 1 -
left 'Date : ' b -
right 'Page :  ' format 999 sql.pno skip 2
----
spool  &1.bef1636 
select distinct fbh.vfd_bod_date as Rimtdate,'|',
       substr(fbm.bill_id,1,12) as Impbill,'|',
       substr(fbm.party_name,1,28) as importer,'|',
       fbm.bill_crncy_code as Fcur,'|',
       bill_amt as Impbillamt,'|',
       substr(fbm.other_party_name,1,28) as Drawer,'|',
       substr(fei.invoice_num,1,13) as Invoicenum,'|'
from   fbm, fbh, fbi, fei
where  fbm.sol_id = '&1'
and    fbm.sol_id = fbh.sol_id
and    fbh.sol_id = fei.sol_id 
and    fei.sol_id = fbi.sol_id
and    fbi.sol_id = fbm.sol_id
and    fbm.bill_id= fbh.bill_id
and    fbh.bill_id= fei.bill_id
and    fei.bill_id= fbi.bill_id
and    fbi.bill_id= fbm.bill_id
and    fbm.reg_type in ('ABLC', 'FIBC', 'FDIC')
and    fbm.bill_stat  in ('R','O','P','K')
and    fbm.bank_id='&3' and fbh.bank_id='&3' and fbi.bank_id='&3' and fei.bank_id='&3'
and    fbh.vfd_bod_date = (select max(vfd_bod_date) from fbh a
                           where  a.sol_id = '&1' 
                           and    a.bill_id = fbh.bill_id
                           and    a.vfd_bod_date <= to_date('&2','dd-mm-yyyy')
                           and    a.del_flg = 'N'
			   and    a.bank_id='&3')
and    fbi.bill_of_entry is null
and    fbi.bill_of_entry_submit_date is null
order  by substr(fbm.party_name,1,28),fbh.vfd_bod_date 
/
spool off
set verify on
clear columns
ttitle off
exit
