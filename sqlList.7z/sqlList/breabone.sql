set serveroutput on size unlimited
rem accept sol prompt 'Enter sol_id :: '
rem accept lowsubgl prompt 'Enter Low GL Sub Head Code :: '
rem accept highsubgl prompt 'Enter high GL Sub Head Code :: '
rem accept dt prompt 'Enter Balance Date (DD-MM-YYYY) : '
set pages 0
set verify off
set feedback off
set termout off
set lines 200
set trimspool on
spool br.dat
DECLARE
glsubheadcode   gam.gl_sub_head_code%type;
facid           gam.foracid%type;
name            gam.acct_name%type;
bal             gam.clr_bal_amt%type;
inrdatebal              gam.clr_bal_amt%type;
fxdatebal               gam.clr_bal_amt%type;
crncy           gam.crncy_code%type;
glcrncy         gam.crncy_code%type;
fxbal           gam.fx_clr_bal_amt%type;
sol             varchar2(4);
gacid           gam.acid%type;
subgldr         gst.tot_dr_bal%type;
subglcr         gst.tot_cr_bal%type;
conv_rate number(10);
loc_fp                          utl_file.file_type;
loc_filename                    varchar2(200);
loc_filepath                    varchar2(100);
loc_filemode                    varchar(10);
CURSOR GAMMAIN is
select  gam.gl_sub_head_code,
        gam.foracid,gam.acct_name,
        gam.clr_bal_amt+gam.un_clr_bal_amt,
        nvl(gam.acct_crncy_code,'INR'),
        gam.fx_clr_bal_amt,gam.acid
from gam
        where sol_id = '&1'
	and bank_id = 'BM3'
        and gl_sub_head_code between '&2' and '&3'
        and (acct_cls_flg='N' or acct_cls_date > '&4')
        order by 1,2;
Begin  --{
open gammain;--{
begin --{
loop  --{
fetch gammain into glsubheadcode,facid,name,bal,crncy,fxbal,gacid;
exit when gammain%notfound;

BEGIN --{
inrdatebal := 0;
fxdatebal := 0;

begin --{
select tran_date_bal into inrdatebal
from eab
where acid = gacid
and bank_id = 'BM3'
and eod_date <='&4'
and end_eod_date >='&4';
exception when no_data_found
then
inrdatebal := 0;
end; --}

begin --{
select nvl(var_crncy_units/fxd_crncy_units,1) into conv_rate from rth
        where ratecode='NOR'
	and bank_id = 'BM3'
        and var_crncy_code='INR'
        and fxd_crncy_code=crncy
        and rtlist_date =
                (select max(rtlist_date) from rth
                        where fxd_crncy_code=crncy
				and bank_id = 'BM3'
                                and var_crncy_code='INR'
                                and ratecode='NOR'
                                and rtlist_date<='&4')
        and rtlist_num=
                (select max(rtlist_num) from rth
                        where fxd_crncy_code=crncy
				and bank_id = 'BM3'
                                and var_crncy_code='INR'
                                and ratecode='NOR'  and rtlist_date=
                                        (select max(rtlist_date) from rth
                                                where fxd_crncy_code= crncy
                                                and var_crncy_code='INR'
						and bank_id = 'BM3'
                                                and ratecode='NOR'
                                                and rtlist_date<='&4')) ;
exception
when no_data_found
then
conv_Rate:=1;
end; --}
inrdatebal:= inrdatebal*conv_rate;

end; --}

If crncy != 'INR' Then
BEGIN --{
select tran_date_bal into fxdatebal
from fab
where acid = gacid
and bank_id = 'BM3'
and eod_date = (select max(eod_date)
                from fab
                where acid = gacid
		and bank_id = 'BM3'
                and eod_date <= '&4');
exception when no_data_found
then
fxdatebal := 0;
end; --}
end if;

begin --{
select crncy_code,
        tot_dr_bal,tot_cr_bal into glcrncy,subgldr,subglcr
from gst
where  sol_id = '&1'
and bank_id = 'BM3'	
and tran_date = '&4'
and crncy_code=crncy
and gl_sub_head_code = glsubheadcode;
exception
when no_data_found then
glcrncy :=0;
subgldr :=0;
subglcr:=0;
end; --}

begin --{
select nvl(var_crncy_units/fxd_crncy_units,1) into conv_rate from rth
        where ratecode='NOR'
	and bank_id = 'BM3'
        and var_crncy_code='INR'
        and fxd_crncy_code=glcrncy
        and rtlist_date =
                (select max(rtlist_date) from rth
                        where fxd_crncy_code=glcrncy
				and bank_id = 'BM3'
                                and var_crncy_code='INR'
                                and ratecode='NOR'
                                and rtlist_date<='&4')
        and rtlist_num=
                (select max(rtlist_num) from rth
                        where fxd_crncy_code=glcrncy
				and bank_id = 'BM3'
                                and var_crncy_code='INR'
                                and ratecode='NOR'  and rtlist_date=
                                        (select max(rtlist_date) from rth
                                                where fxd_crncy_code= glcrncy
						and bank_id = 'BM3'
                                                and var_crncy_code='INR'
						and bank_id = 'BM3'
                                                and ratecode='NOR'
                                                and rtlist_date<='&4')) ;
exception
when no_data_found
then
conv_Rate:=1;
end; --}
subgldr:=subgldr*conv_rate;
subglcr:=subglcr*conv_rate;

DBMS_OUTPUT.PUT_LINE('&1'
        ||'|'||'&4'
        ||'|'||glsubheadcode
        ||'|'||facid
        ||'|'||rpad(Name,40)
        ||'|'||crncy
        ||'|'||inrdatebal
        ||'|'||fxdatebal
        ||'|'||'GST'
        ||'|'||glcrncy
        ||'|'||subgldr
        ||'|'||subglcr);
end loop; --}
end; --}
close gammain; --}
end; --}
/
spool off
