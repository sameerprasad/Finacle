rem accept solid prompt 'ENTER FOUR DIGIT SOL ID OF REPORT BRANCH : '
set termout off 
set echo off
set pause off
set verify off
set wrap off
set linesize 132
set newpage 0
set pagesize 60
set space 1
column int_tbl_code heading INT_CODE format  a15
column schm_code heading SCHEME format a15
column  start_date  heading START_DATE format a20
column  end_date  heading  END_DATE  format a20
column  name  heading  NAME format a40
 
define all_dashes = '------------------------------------------------------------------------------------------------------------------------------------'

ttitle 'LIST OF ACCOUNTS AND THE ASSOCIATED INT CODES -  TO BE CHECKED-
BEFORE INTEREST RUN' skip 2
btitle skip 3 right 'SIGNATURE'
break on schm_code skip 3 
spool &1.nonstdint
select  gam.schm_code, gam.foracid acct_no, gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date, 
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid   =itc.entity_id 
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('SBGEN','SBPRU')
and   int_tbl_code not in ('SBGEN')
and gam.sol_id = '&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date, 
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid   =itc.entity_id 
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('SBSTF')
and   int_tbl_code not in ('SBSTF')
and gam.sol_id = '&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date, 
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where  gam.acid   =itc.entity_id 
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('SBNRE')
and   int_tbl_code not in ('SBNRE')
and gam.sol_id = '&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date, 
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid   =itc.entity_id 
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('SBNRO','SBNRS')
and   int_tbl_code not in ('SBNRO')
and gam.sol_id = '&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date, 
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid   =itc.entity_id 
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('EDMSB','RDMSB')
and   int_tbl_code not in ('ESBDM')
and gam.sol_id = '&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date,
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid   =itc.entity_id
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('EEUSB','REUSB')
and   int_tbl_code not in ('ESBEU')
and gam.sol_id = '&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date, 
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid   =itc.entity_id 
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('EGBSB','RGBSB')
and   int_tbl_code not in ('ESBGB')
and gam.sol_id = '&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date, 
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid   =itc.entity_id 
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('EUSSB','RUSSB')
and   int_tbl_code not in ('ESBUS')
and gam.sol_id = '&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date, 
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid   =itc.entity_id 
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('EJYSB','RJYSB')
and   int_tbl_code not in ('ESBJY')
and gam.sol_id = '&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date, 
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid   =itc.entity_id 
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('RDMSB')
and   int_tbl_code not in ('RSBDM')
and gam.sol_id = '&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date, 
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid   =itc.entity_id 
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('RUSSB')
and   int_tbl_code not in ('RSBUS')
and gam.sol_id = '&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date, 
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid   =itc.entity_id 
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('RGBSB')
and   int_tbl_code not in ('RSBGB')
and gam.sol_id = '&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date, 
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid   =itc.entity_id 
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('RJYSB')
and   int_tbl_code not in ('RJYGB')
and gam.sol_id = '&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date, 
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid   =itc.entity_id 
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('CFDUS','FDHUS')
and   int_tbl_code not in ('USD')
and gam.sol_id = '&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date, 
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid   =itc.entity_id 
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('CFDDM','FDHDM')
and   int_tbl_code not in ('DEM')
and gam.sol_id = '&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date, 
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid      =itc.entity_id
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('CFDGB','FDHGB')
and   int_tbl_code not in ('GBP')
and gam.sol_id = '&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date,
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid      =itc.entity_id
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('CFDEU','FDHEU')
and   int_tbl_code not in ('EUR')
and gam.sol_id = '&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date, 
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid   =itc.entity_id 
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('CFDJY','FDHJY')
and   int_tbl_code not in ('JPY')
and gam.sol_id = '&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date,
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid   =itc.entity_id
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('CFDMC','FDHMC')
and   int_tbl_code not in ('AUD','CAD','GBP')
and gam.sol_id = '&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date, 
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid   =itc.entity_id 
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('FD90O','FDQTR','FDISC','FDRBL','FDRPI','RDGEN','FDQTO','FDISO','RDNRO','CFDEP','CFDEO','RDNRS','CFDES','FDISS','FD90S','FDQRS','CD')
and   int_tbl_code not in ('TDSTF','TDGEN')
and gam.sol_id = '&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date, 
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid   =itc.entity_id 
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('FDISE','FDQTE','CFDEE','RDNRE')
and   int_tbl_code not in ('TDNRE')
and gam.sol_id = '&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date, 
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid   =itc.entity_id 
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('FDQNR','CFDNR')
and   int_tbl_code not in ('TNRNR')
and   sol_id='&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date,
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid   =itc.entity_id
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('RFDMD','EFDMH','EFDMD','CFEDM','CFRDM','RFDMH')
and   int_tbl_code not in ('EFDMH')
and   sol_id='&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date,
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid   =itc.entity_id
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('EFEUD','CFREU','EFEUH','RFEUD','CFEEU','RFEUH')
and   int_tbl_code not in ('EFEUH')
and   sol_id='&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date,
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid   =itc.entity_id
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('RFGBD','RFGBH','CFEGB','CFRGB','EFGBH','EFGBD')
and   int_tbl_code not in ('EFGBH')
and   sol_id='&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date,
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid   =itc.entity_id
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('RFJYD','EFJYD','CFEJY','CFRJY','EFJYH','RFJYH')
and   int_tbl_code not in ('EFJYH')
and   sol_id='&1'
and gam.bank_id='&2' and itc.bank_id='&2'
union all
select  gam.schm_code, gam.foracid acct_no,
gam.acct_name name,
int_tbl_code, to_char(start_date,'dd-mm-yyyy') start_date,
to_char(end_date, 'dd-mm-yyyy') end_date
FROM Gam, itc
where   gam.acid   =itc.entity_id
and   gam.acct_cls_flg !='Y'
and   gam.schm_code in ('RFUSD','EFUSH','RFUSH','CFEUS','EFUSD','CFRUS')
and   int_tbl_code not in ('EFUSH')
and   sol_id='&1'
and gam.bank_id='&2' and itc.bank_id='&2'
order by  1,2
/
ttitle off
btitle off
spool off
undefine all_dashes
set termout on
set feedback on
set verify on
set heading on
set wrap on
clear breaks
set echo on
exit
