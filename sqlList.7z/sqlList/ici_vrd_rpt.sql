set serveroutput on size 1000000
set feedback off
set verify   off
set termout   off
set pages 1000
set linesize 512
set trims on

---spool /mistmp/vrdstprep&1..txt
spool /tmp/vrdstprep&1..txt

declare
cursor vrdrpt is
select REF_ID,DR_FORACID,VRD_FORACID,GOAL_AMT,INITIAL_DR_AMT,VRD_TENURE,TRAN_ID,STATUS_CODE,ERROR_DESC,ENTITY_CRE_FLG,DEL_FLG,RCRE_TIME from ici_vrd_stp where to_date(RCRE_TIME,'DD-MM-YYYY') = (select to_date(sysdate-1,'DD-MM-YYYY') from dual) AND BANK_ID = &2;

begin

dbms_output.put_line('REF_ID,DR_FORACID,VRD_FORACID,GOAL_AMT,INITIAL_DR_AMT,VRD_TENURE,TRAN_ID,STATUS_CODE,ERROR_DESC,ENTITY_CRE_FLG,DEL_FLG,RCRE_TIME');

for i in vrdrpt
loop
---{

dbms_output.put_line(i.REF_ID  ||','|| i.DR_FORACID ||','|| i.VRD_FORACID  ||','|| i.GOAL_AMT ||','|| i.INITIAL_DR_AMT ||','|| i.VRD_TENURE || ',' || i.TRAN_ID|| ',' || i.STATUS_CODE||','||i.ERROR_DESC||','||i.ENTITY_CRE_FLG||','||i.DEL_FLG||','||i.RCRE_TIME);

---}
end loop;
end;
/
spool off
