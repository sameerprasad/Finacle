rem accept sol prompt "ENTER FOUR DIGIT SOL-ID ::"
rem set termout off 
rem :SQL script listing TDS rate specified in the accounts
rem :To be run whenever  interest run for SB, TD are being 
rem :done in half yearly, yearly closing time. 
set echo off
rem set pause off
set verify off
rem set wrap off
set termout off
rem set linesize 80
rem set newpage 0
set pagesize 60
set space 1
column acct_name heading ACCOUNT_NAME format a40   
--column int_tbl_code heading INT_CODE format  a15
--column schm_code heading SCHEME format a15
column wtax_pcnt heading TAX_PCNT 
column foracid heading ACCOUNT_NO format a12
--column  start_date  heading START_DATE format a20
--column  end_date  heading  END_DATE  format a20
 
define all_dashes = '------------------------------------------------------------------------------------------------------------------------------------'

-- ttitle 'SOL-ID: &1 LIST OF NON-NRO ACCTS WITH TDS % SPECIFIED  WRONGLY' 
-- skip 2
-- btitle 'This list should not have any entries. Corrections required -
-- before ' skip  1 'running interest.' skip 2 -
-- right 'SIGNATURE'
-- break on schm_code skip 3 
spool &1.actds  
-- select gam.foracid,gam.acct_name,cmc.wtax_pcnt 
-- from gam, cmc 
-- where   gam.cust_id   =cmc.cust_id
-- and   gam.schm_code   not like '%NRO'
-- and   gam.sol_id = '&1'
-- and   cmc.wtax_pcnt     >  0
--and   gam.sol_id = '&1'
/ 
ttitle "SOL-ID: &1 LIST OF NRO ACCOUNTS WITH TDS %  NOT GIVEN AS 31.5 % WRONGLY"
select gam.foracid,gam.acct_name, cmc.wtax_pcnt
from gam, cmc 
where   gam.schm_code like '%NRO'
and   gam.cust_id   =cmc.cust_id
and gam.sol_id = '&1'
and   cmc.wtax_pcnt     != 31.5
and cmc.crncy_code='INR'
and gam.acct_cls_flg='N'
and gam.bank_id='&2' and cmc.bank_id='&2'
--and gam.sol_id = '&1'
/
ttitle "SOL-ID: &1 LIST OF NRO ACCOUNTS WITH TDS %  (QA22 Ac/s)"
select gam.foracid,gam.acct_name, cmc.wtax_pcnt
from gam, cmc 
where   gam.cust_id   =cmc.cust_id
and gam.sol_id = '&1'
and   gam.acct_name like '%QA22'
and acct_cls_flg='N'
and gam.bank_id='&2' and cmc.bank_id='&2'
--and gam.sol_id = '&1'
/
ttitle off
btitle off
spool off
undefine all_dashes
set feedback on
set verify on
set heading on
set wrap on
clear breaks
set echo on
exit
