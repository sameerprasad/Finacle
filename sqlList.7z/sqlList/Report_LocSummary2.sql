-------------------------------------------------------------------------
--Author    :    Khalid Sabeeh
--Date      :    15-Apr-2013
--Desc      :  	 Locker Status Report  
--File Name :    Report_LocSummary2.sql 
--------------------------------------------------------------------------
set serveroutput on size 1000000
set lines 2000 
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_LocSummary2.lst 

Declare
v_sol_id    	wlckm.sol_id%type:='&1';
v_bank_id       wlckm.bank_id%type:='&2';
v_rack_id       varchar2(15);	
v_locker_type   wlckm.locker_type%type;
v_locker_count  number;
v_Used_count    number; 
v_Surr_count    number;
v_Avail_count   number; 
v_Frozen_count  number;
v_BrkOpn_count  number;
v_ClmAdv_count  number;
v_lost_count    number;
v_Dormncy_count number;



cursor t2 is
			select a.rack_id,a.locker_type,count(1)
			from wlckm a
			where a.sol_id = v_sol_id
			and a.bank_id= v_bank_id
			and a.del_flg = 'N'
			group by a.rack_id,a.locker_type order by a.rack_id,a.locker_type;
begin
open t2;
loop
--{
    fetch t2 into v_rack_id,v_locker_type,v_locker_count;
	if t2%NOTFOUND then
	--{
    	close t2;
    	exit;
	--}
	end if;
	begin 
		select count(1) into v_Used_count 
		from wlckm where sol_id = v_sol_id and status = 'U' and rack_id = v_rack_id 
		and locker_type = v_locker_type and del_flg = 'N' and bank_id= v_bank_id;	 
	end;
	begin 
		select count(1) into v_Surr_count 
		from wlckm where sol_id = v_sol_id and status = 'S' and rack_id = v_rack_id 
		and locker_type = v_locker_type and del_flg = 'N' and bank_id= v_bank_id;	 
	end;
	begin 
		select count(1) into v_Avail_count 
		from wlckm where sol_id = v_sol_id and status = 'A' and rack_id = v_rack_id 
		and locker_type = v_locker_type and del_flg = 'N' and bank_id= v_bank_id;	 
	end;
	begin 
		select count(1) into v_Frozen_count 
		from wlckm where sol_id = v_sol_id and status = 'F' and rack_id = v_rack_id 
		and locker_type = v_locker_type and del_flg = 'N' and bank_id= v_bank_id;	 
	end;
	begin 
		select count(1) into v_BrkOpn_count 
		from wlckm where sol_id = v_sol_id and status = 'L' and rack_id = v_rack_id 
		and locker_type = v_locker_type and del_flg = 'N' and bank_id= v_bank_id
		and EXISTS(select 1 from lcbrkop where lcbrkop.LOCK_NO = wlckm.Locker_Num and lcbrkop.bank_id= wlckm.bank_id); 
	end;
	begin 
		select count(1) into v_ClmAdv_count 
		from wlckm where sol_id = v_sol_id and status = 'C' and rack_id = v_rack_id 
		and locker_type = v_locker_type and del_flg = 'N' and bank_id= v_bank_id;	 
	end;
	begin 
		select count(1) into v_lost_count 
		from wlckm where sol_id = v_sol_id and status = 'L' and rack_id = v_rack_id 
		and locker_type = v_locker_type and del_flg = 'N' and bank_id= v_bank_id and
		EXISTS(select 1 from lclost where lclost.Locker_Num = wlckm.Locker_Num and lclost.bank_id=wlckm.bank_id);	 
	end;
	begin 
		select count(1) into v_Dormncy_count 
		from wlckm where sol_id = v_sol_id and status = 'D' and rack_id = v_rack_id 
		and locker_type = v_locker_type and del_flg = 'N' and bank_id= v_bank_id;	 
	end;


			dbms_output.enable(buffer_size => NULL);
			dbms_output.put_line(v_rack_id      ||'|'||
                     		 v_locker_type      ||'|'||
							 v_Used_count       ||'|'||
							 v_Surr_count       ||'|'||
							 v_Avail_count      ||'|'||
							 v_Frozen_count     ||'|'||
							 v_BrkOpn_count     ||'|'||
							 v_ClmAdv_count     ||'|'||
							 v_lost_count       ||'|'||
							 v_Dormncy_count    ||'|'||
                     		 v_locker_count);    

--}
end loop;
end;
/
spool off


