Rem     This file will create C_ATMCHGS
Rem     with the following characteristics.

Rem TABLE NAME: ICICI.C_ATMCHGS

Rem SYNONYM:  CATMCHGS
Rem SYNONYM:  C_ATMCHGS

drop table C_ATMCHGS
/
drop public synonym CATMCHGS
/
drop public synonym C_ATMCHGS
/
create table C_ATMCHGS
(
 FORACID                                            VARCHAR2(16),
 BEGIN_DATE                                         DATE,
 TRAN_TYPE                                          VARCHAR2(50),
 SCHM_TYPE                                          VARCHAR2(3),
 FREE_TRAN_COUNT                                    NUMBER(9),
 FREE_TRAN_LIST                                     VARCHAR2(999),
 TOTAL_TRAN_COUNT                                   NUMBER(9),
 US_ON_US_IND                                       CHAR(1)
)
TABLESPACE ICICI_CUST
/

create public synonym CATMCHGS
    for C_ATMCHGS
/
create public synonym C_ATMCHGS
    for C_ATMCHGS
/

create unique index IDX_C_ATMCHGS
on C_ATMCHGS(FORACID,BEGIN_DATE)
storage ( PCTINCREASE 0 )
TABLESPACE ICICI_CUST
/

grant select, insert, update, delete on C_ATMCHGS to tbagen, tbaadm
/
grant select on C_ATMCHGS to tbacust
/
grant select on C_ATMCHGS to tbautil
/
