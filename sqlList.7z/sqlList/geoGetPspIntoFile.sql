set head off
set pages 0
set trims on
set feedback off
set verify off
set termout off
spool &1-&2-CUST-&3
select  home_sol_id || '|' ||
        entity_id
from    psp_tmp
where   listid like '&1'||'&2'||'&3'||'C'
and     home_sol_id = '&2' and bank_id = '&4'
order by entity_id
/
spool off

spool &1-&2-ACCT-&3
select  b.home_sol_id || '|' ||
--        a.cust_id || '|' ||
        a.cif_id || '|' ||
        b.entity_id
from    gam a, psp_tmp b
where   b.listid like '&1'||'&2'||'&3'||'A'
and     b.home_sol_id = '&2'
--and     b.entity_id = a.foracid
and     b.entity_id = a.cif_id
and     a.bank_id = b.bank_id 
and     a.bank_id = '&4'
order by entity_id
/
spool off
