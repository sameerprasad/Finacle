Rem     This file will create ICI_VRD_STP
Rem     with the following characteristics.

Rem TABLE NAME: ICICI.ICI_VRD_STP_TBL

Rem SYNONYM: ICI_VRD_STP

drop table ICICI.ICI_VRD_STP_TBL
/
drop public synonym ICI_VRD_STP
/
create table ICICI.ICI_VRD_STP_TBL
(
ref_id                   VARCHAR2(15),
dr_foracid               VARCHAR2(16),
vrd_foracid              VARCHAR2(16),
goal_amt                 NUMBER(20,4),
initial_dr_amt           NUMBER(20,4),
vrd_tenure               NUMBER(3),
tran_id                  VARCHAR2(9),
status_code              VARCHAR2(3),
error_desc               VARCHAR2(200),
ENTITY_CRE_FLG           CHAR(1),
DEL_FLG                  CHAR(1),
LCHG_USER_ID             VARCHAR2(15),
LCHG_TIME                DATE,
RCRE_USER_ID             VARCHAR2(15),
RCRE_TIME                DATE,
BANK_ID			 VARCHAR2(8)
)
/

create public synonym ICI_VRD_STP
    for ICICI.ICI_VRD_STP_TBL
/

grant select, insert, update, delete on ICICI.ICI_VRD_STP_TBL to tbagen
/
grant select, insert, update, delete on ICICI.ICI_VRD_STP_TBL to tbautil
/
grant select, insert, update, delete on ICICI.ICI_VRD_STP_TBL to tbaadm
/
