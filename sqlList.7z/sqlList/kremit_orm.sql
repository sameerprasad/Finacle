drop table ICICI.kremit_orm
/
drop public synonym KREMIT_ORM_TBL
/
create table ICICI.kremit_orm
(
 SOL_ID                                             VARCHAR2(8 CHAR),
 CRNCY_CODE                                         VARCHAR2(3 CHAR),
 FORACID                                            VARCHAR2(16 CHAR),
 REG_TYPE                                           VARCHAR2(5 CHAR),
 REG_SUB_TYPE                                       VARCHAR2(5 CHAR),
 BILL_AMT                                           NUMBER(20,4),
 CNTRY_CODE                                         VARCHAR2(5 CHAR),
 PURPOSE_REMIT                                      VARCHAR2(5 CHAR),
 BASE_RATE                                          NUMBER(21,10),
 TRES_RATE                                          NUMBER(21,10),
 TRES_REF                                           VARCHAR2(16 CHAR),
 PSPRT_NUM                                          VARCHAR2(16 CHAR),
 UNIQ_REF_NUM                                       VARCHAR2(12 CHAR),
 RECORD_STATUS                                      VARCHAR2(1 CHAR),
 REMIT_OPT                                          VARCHAR2(1 CHAR),
 FC_TRAN_SER_TAX_FLG                                VARCHAR2(1 CHAR),
 CHARGE_AMT                                         NUMBER(20,4),
 ENTITY_CRE_FLG                                     VARCHAR2(1 CHAR),
 DEL_FLG                                            VARCHAR2(1 CHAR),
 REF_EMP_ID                                         VARCHAR2(10 CHAR),
 RCRE_USER_ID                                       VARCHAR2(10 CHAR),
 RCRE_TIME                                          DATE,
 LCHG_USER_ID                                       VARCHAR2(10 CHAR),
 LCHG_TIME                                          DATE,
 BILL_ID                                            VARCHAR2(15 CHAR),
 REMARKS                                            VARCHAR2(80 CHAR),
 BANK_ID                                            VARCHAR2(8 CHAR)
)
/

create public synonym kremit_orm_tbl
    for icici.kremit_orm
/

create unique index IDX_uniq_ref_num
on icici.kremit_orm(uniq_ref_num)
/

grant select, insert, update, delete on icici.kremit_orm to tbagen , tbaadm
/
grant select on icici.kremit_orm to tbautil
/

create sequence icici.kremit_num
start with 1  increment by 1   maxvalue 9999999999
nocycle
cache 20
/ 

create public synonym kremit_num for icici.kremit_num
/

grant all on icici.kremit_num to public
/
