--**********************************************************************************************
--  Filename                    : fwcadvp.sql
--  Description                 : This sql generates a report file for  FWC advice
--  Date                        : 28-02-2007
--  Author                      : Sanjay Kumar Jain
--  Inputs                      : solid,date,fwc function,reg type,fwc no,partycode
--  Outputs                     : fwcadvp.lst
--  Called scripts              : NONE
--  Calling scripts		: NONE
--  Package name		: fwcadvp_pack
--  Procedures			: fwcadvp_proc
--
--      Modification History
--    Sl. #            Date              Author                Modification
--    -----         -----------     ---------------          ----------------
--    01            28-02-2007       Sanjay Kumar Jain       Generates a report file for  FWC advice
--    02            26-03-2012        P.suhasini             Modified Version	
--*********************************************************************************************

-------------------------------------------------------------------------
-- Declaration of the package and the procedure
-------------------------------------------------------------------------


CREATE OR REPLACE PACKAGE fwcadvp_pack AS
PROCEDURE fwcadvp_proc ( inp_str IN VARCHAR2,
                        out_retCode OUT NUMBER,
                        out_rec OUT VARCHAR2 );
END  fwcadvp_pack;
/

---------------------------------------------
-- Actual body of the package
---------------------------------------------

CREATE OR REPLACE PACKAGE BODY fwcadvp_pack AS

out_retCode             number(2) := 1;
outArr                  basp0099.ArrayType;

v_solid		VARCHAR2(8);
v_frmDate	VARCHAR2(15);
v_toDate	VARCHAR2(15);
v_regtype	VARCHAR2(15);
v_fwcfunc	VARCHAR2(15);
v_sfwcno	VARCHAR2(15);
v_efwcno	VARCHAR2(15);
v_party		VARCHAR2(30);
v_bankId        VARCHAR2(8);

loc_sol_id		   VARCHAR2(8);				
loc_frwrd_cntrct_num	   TBAADM.FCM.frwrd_cntrct_num%TYPE;	
loc_tranid		   TBAADM.FCH.CHARGE_TRAN_ID%TYPE;		
loc_custid		   CRMUSER.ACCOUNTS.core_cust_id%TYPE;			
loc_emailid		   CRMUSER.ACCOUNTS.EMAIL%TYPE;			
loc_cust_name		   CRMUSER.ACCOUNTS.NAME%TYPE;		
loc_CUST_COMU_ADDR1	   CRMUSER.ACCOUNTS.address_line1%TYPE;			
loc_CUST_COMU_ADDR2        CRMUSER.ACCOUNTS.address_line2%TYPE;	           
loc_CUST_COMU_CITY_CODE    CRMUSER.ACCOUNTS.CITY%TYPE;	          
loc_CUST_COMU_STATE_CODE   CRMUSER.ACCOUNTS.STATE%TYPE;	          
loc_CUST_COMU_PIN_CODE     CRMUSER.ACCOUNTS.ZIP%TYPE;	          
loc_CUST_COMU_CNTRY_CODE   CRMUSER.ACCOUNTS.COUNTRY%TYPE;			
loc_foracid                TBAADM.GAM.foracid%TYPE;					
loc_regtype		   TBAADM.FCM.REG_TYPE%TYPE;
loc_VALID_TO_DATE	   TBAADM.FCM.VALID_TO_DATE%TYPE;		
loc_FROM_CRNCY_CODE	   TBAADM.FCM.FROM_CRNCY_CODE%TYPE;		
loc_TO_CRNCY_CODE	   TBAADM.FCM.TO_CRNCY_CODE%TYPE;		
loc_RATE		   TBAADM.FCM.RATE%TYPE;		
loc_RATECODE		   TBAADM.FCM.RATECODE%TYPE;		
loc_action_date		   DATE;	
loc_actioncode		   VARCHAR2(30);	
loc_AMT_CNCLD		   NUMBER(20,4);
loc_amt			   NUMBER(20,4);
loc_rmks                   VARCHAR2(30);


	
--------------------------------------------------------------------------------------
-- DECLARATION OF CURSOR fdrstrfdr_cur_1
--------------------------------------------------------------------------------------

CURSOR fwcadvp_cur(v_solid VARCHAR2,v_frmDate VARCHAR2,v_toDate VARCHAR2 ,v_regtype VARCHAR2,v_fwcfunc VARCHAR2,v_sfwcno VARCHAR2,v_efwcno VARCHAR2,v_party VARCHAR2,v_bankId VARCHAR2) IS
--{

	SELECT  m.sol_id,
                m.frwrd_cntrct_num,
                h.charge_tran_id,
                TRIM(a.core_cust_id),
                a.email,
                a.name,
                a.address_line1,
                a.address_line2,
                a.city,
                a.state,
                a.zip,
                a.country,
                g.foracid,
                m.reg_type,
                m.valid_to_date,
                m.from_crncy_code,
                m.to_crncy_code,
                decode(h.action_code,'A',m.rate,'L',h.cncl_tr_settlement_rate),
                m.ratecode,
                h.action_date,
                h.action_code,
                --h.amt_cncld,
                h.cont_liab_amt,
                x.actual_amt_coll,
                x.tran_rmks
        FROM    fcm m, fch h, cxl x,crmuser.accounts a,gam g
        
        WHERE   h.sol_id = m.sol_id
        AND     m.bank_id=v_bankId
        AND     m.bank_id=h.bank_id
        AND     h.bank_id=x.bank_id
        AND     a.core_cust_id = m.party_code
        AND    g.acid=m.acid
        AND    h.frwrd_cntrct_num = m.frwrd_cntrct_num
        AND    x.chrg_tran_date = h.action_date 
        AND     x.chrg_tran_id = h.charge_tran_id
        AND    x.part_tran_type ='C'
        AND     event_id=h.charge_code
        AND     (m.sol_id = v_solid)
        AND     ((h.action_date BETWEEN TO_DATE(v_frmDate,'dd-mm-yyyy') AND TO_DATE(v_toDate,'dd-mm-yyyy')) OR (m.frwrd_cntrct_num BETWEEN v_sfwcno AND v_efwcno))
        AND     (m.REG_TYPE = v_regtype OR v_regtype ='ALL')
        AND     (h.action_code = v_fwcfunc OR v_fwcfunc = 'B')
        AND     (m.PARTY_CODE = lpad(v_party,9) OR v_party = 'ALL');
	
--}

-------------------------------------------------------
-- PROCEDURE IS DEFINED HERE
-------------------------------------------------------

PROCEDURE fwcadvp_proc (inp_str IN VARCHAR2,
                        out_retCode OUT NUMBER,
                        out_rec OUT VARCHAR2) AS

BEGIN
--{
        out_rec:=NULL;
        out_retCode:=0;

	BEGIN
	--{
        	basp0099.formInputArr (inp_str,OutArr);
		v_solid    := outArr(0);
		v_frmDate  := outArr(1);
		v_toDate   := outArr(2);
		v_regtype  := outArr(3);
		v_fwcfunc  := outArr(4);
		v_sfwcno   := outArr(5);
		v_efwcno   := outArr(6);
		v_party    := outArr(7);     	
		v_bankId   := outArr(8);
	--}
	END;

	IF(NOT fwcadvp_cur%ISOPEN) THEN
	--{
		OPEN fwcadvp_cur(v_solid,v_frmDate ,v_toDate,v_regtype,v_fwcfunc,v_sfwcno,v_efwcno,v_party,v_bankId);
        --}
        END IF;

	---------------------------------------------------------------------
	-- Fetching data from the cursor fwcadvp_cur
	---------------------------------------------------------------------

	IF(fwcadvp_cur%ISOPEN) THEN
	--{
		FETCH	fwcadvp_cur
		INTO	loc_sol_id,				
			loc_frwrd_cntrct_num,		
			loc_tranid,			
			loc_custid,				
			loc_emailid,				
			loc_cust_name,			
			loc_CUST_COMU_ADDR1,			
			loc_CUST_COMU_ADDR2 ,                
			loc_CUST_COMU_CITY_CODE,             
			loc_CUST_COMU_STATE_CODE,            
			loc_CUST_COMU_PIN_CODE,              
			loc_CUST_COMU_CNTRY_CODE,		
			loc_foracid,				
			loc_regtype,				
			loc_VALID_TO_DATE,			
			loc_FROM_CRNCY_CODE,			
			loc_TO_CRNCY_CODE,			
			loc_RATE,				
			loc_RATECODE,			
			loc_action_date,			
			loc_actioncode,			
			loc_AMT_CNCLD,			
			loc_amt	,			
			loc_rmks;

		

			out_rec:=       loc_sol_id||'|'||				
					loc_frwrd_cntrct_num||'|'||		
					loc_tranid||'|'||			
					loc_custid||'|'||				
					loc_emailid||'|'||				
					loc_cust_name||'|'||			
					loc_CUST_COMU_ADDR1||'|'||			
					loc_CUST_COMU_ADDR2 ||'|'||                
					loc_CUST_COMU_CITY_CODE||'|'||             
					loc_CUST_COMU_STATE_CODE||'|'||            
					loc_CUST_COMU_PIN_CODE||'|'||              
					loc_CUST_COMU_CNTRY_CODE||'|'||		
					loc_foracid||'|'||				
					loc_regtype||'|'||				
					loc_VALID_TO_DATE||'|'||			
					loc_FROM_CRNCY_CODE||'|'||			
					loc_TO_CRNCY_CODE||'|'||			
					loc_RATE||'|'||				
					loc_RATECODE||'|'||			
					loc_action_date||'|'||			
					loc_actioncode||'|'||			
					loc_AMT_CNCLD||'|'||			
					loc_amt	||'|'||			
					loc_rmks;		
		
	
	--}
	END IF;

	IF (fwcadvp_cur%NOTFOUND) THEN
    --{
    	CLOSE fwcadvp_cur;
        out_retCode := 1;
    --}
    END IF;

--}
END fwcadvp_proc;

--}
END fwcadvp_pack;

------------------------------------------------------------------------------------------------------------------
-- GRANTING EXECUTE PREVILAGE TO VARIOUS USERS ON PACKAGE
------------------------------------------------------------------------------------------------------------------
/
DROP PUBLIC SYNONYM fwcadvp_pack
/
CREATE PUBLIC SYNONYM fwcadvp_pack FOR fwcadvp_pack
/
GRANT EXECUTE ON fwcadvp_pack TO PUBLIC,TBAGEN, TBAUTIL,TBACUST
/

