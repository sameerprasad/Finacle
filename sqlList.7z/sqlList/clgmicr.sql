rem accept br1 prompt "ENTER YOUR BRANCH CODE::"
rem accept cd prompt "ENTER ZONE CODE::::"
rem accept dt prompt "ENTER ZONE DATE::::"
set head off
set verify off
set echo off
set pages 0
set lines 43
set space 0
set termout off
set feedback off
rem column A format a9
rem column D format b999999 
rem column E format a9
rem column G format b99
rem column H format b999999999.99
set numformat 9999999999.99
col bkcd new_value nbkcd
col br new_value brn
col ndt new_value ndt1
alter session set nls_date_format='DD-MM-YYYY';
select to_char(to_Date('&3'),'DDMM') ndt from dual;
select br_code br from sol where br_code = '&1' and bank_id = '&4';
select micr_centre_code||micr_bank_code||micr_branch_code bkcd  from bct
where br_code  = (select br_code from sol where br_code = '&1') and bank_id = '&4';
spool clgmicr 
select '&nbkcd'||to_char(instrmnt_id,'099999')||sort_code||to_char(tran_code,'099')||to_char((instrmnt_amt*100),'0999999999999') from oci
where clg_zone_code = '&2'
and clg_zone_date = to_date('&3','dd-mm-yyyy')
and del_flg !='Y'
and sol_id = (select sol_id from sol where br_code = '&1' and bank_id = '&4') and bank_id = '&4'
/
spool off
exit
