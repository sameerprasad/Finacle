--Aneesh S: 03-01-2013 - Changed name of table from cmg to cnma for fields changed


--===================================================================================================================
--Source Name            :  fsgPspTmpCust.sql

--Input Values           :  None	   
--Output Values          :  Validation
--Called Scripts         :  None
--Calling Scripts        :  None
--Modification history   :
--Instance               :  BBY
--Menu			:  ICIFSTMT
--Sl. No            Date                 Author                       Description
-- ---------     --------------    ----------------------        ------------------------------
--   1.0    	     26-04-2013       Supreeth V              Changes made for 10.x for CR-138-30632
--   2.0    	     02-05-2013       Seemantini Dora         Bugfixes while CR testing 
--=====================================================================================================================


set serveroutput on size 1000000 
set feedback off
set verify   off
set termout   off
set head off
set pages 0
set linesize 512
set trims on
spool &1-&2-&3-&4

DECLARE
cnt			number;
firstAcc		GAM.FORACID%Type;
runId			varchar2(20);
-- custId			ICICI_CIFT.CIF_ID%Type;
custId			ICICI_CIFT.CIF_ID%Type;
solId			ICICI_CIFT.HOME_SOL_ID%Type;
-- ciftCustId		ICICI_CIFT.CIF_ID%Type;
ciftCustId		ICICI_CIFT.CIF_ID%Type;
ciftStmtReqd            ICICI_CIFT.stmt_reqd%TYPE;
dispMode            ICICI_CIFT.stmt_reqd%TYPE;
gamForacid		GAM.FORACID%Type;
custRecType		VARCHAR(3);
custSubRecType	VARCHAR(3);
pspCustListId	TBAADM.PSP_TMP.LISTID%Type;
pspAcctListId	TBAADM.PSP_TMP.LISTID%Type;
endOfGamCursor	NUMBER;
step			NUMBER(5);
likeStr			varchar2(25);
ciftEmailId		ICICI_CIFT.EMAIL_ID%Type;
cmgTitleName	varchar2(100);
--cmgAddr1		CMG.cust_comu_addr1%TYPE;
cmgAddr1		CNMA.ADDRESS1%TYPE;
--cmgAddr2		CMG.cust_comu_addr2%TYPE;
cmgAddr2		CNMA.ADDRESS2%TYPE;
--cmgCityCode		CMG.cust_comu_city_code%TYPE;
cmgCityCode		CNMA.CITY_CODE%TYPE;
--cmgStateCode	CMG.cust_comu_state_code%TYPE;
cmgStateCode	CNMA.STATE_CODE%TYPE;
--cmgCntryCode	CMG.cust_comu_cntry_code%TYPE;
cmgCntryCode	CNMA.CNTRY_CODE%TYPE;
cmgCustStatCode CMG.cust_stat_code%TYPE;
--cmgPinCode		CMG.cust_comu_pin_code%TYPE;
cmgPinCode		CNMA.PIN_CODE%TYPE;
--cmgPhone1		CMG.cust_comu_phone_num_1%TYPE;
cmgPhone1		CNMA.phone_num1%TYPE;
--cmgPhone2		CMG.cust_comu_phone_num_2%TYPE;
cmgPhone2		CNMA.phone_num2%TYPE;
idType			char(2);
idTypeOld			char(1);
-- Changes for custnreflg
cmgCustNreFlag	cmg.cust_nre_flg%type;
cmgConst		cmg.cust_const%type;
tmpConst		cmg.cust_const%type;
wbgCust			char(1);

cityDesc		RCT.ref_desc%TYPE;
stateDesc		RCT.ref_desc%TYPE;
cntryDesc		RCT.ref_desc%TYPE;

carRec          varchar2(500);

--VD Starts Here changes For RMCSM

rmname            varchar2(50);
rmemail           varchar2(70);
rmmob             varchar2(12);
csmname            varchar2(50);
csmemail           varchar2(70);
csmmob             varchar2(12);
cnt1                number;
--VD Ends Here changes For RMCSM
	
CURSOR gamCur IS 
SELECT	
	FORACID
FROM	
	GAM
WHERE	
--	CIF_ID = custId
	CIF_ID = custId
--AND	(SCHM_TYPE = 'SBA' OR ACCT_PREFIX = '05' or ACCT_PREFIX = '51')
--Changed for CR-138-30078
AND	( (SCHM_TYPE = 'SBA') OR (ACCT_PREFIX = '05') or (ACCT_PREFIX = '51')  OR ( SCHM_CODE = 'RIDFC' OR SCHM_CODE = 'REUSB' OR SCHM_CODE = 'RGBSB' OR SCHM_CODE = 'RUSSB') )
AND	((ACCT_CLS_FLG = 'N' AND ACCT_OPN_DATE <= TO_DATE('&7','DD-MM-YYYY')) OR
	 (ACCT_CLS_FLG = 'Y' AND ACCT_CLS_DATE > TO_DATE('&7','DD-MM-YYYY')))
--Added for CR-138-30078

AND	ACCT_PREFIX != '18'
AND	ENTITY_CRE_FLG = 'Y' AND BANK_ID='&9' order by foracid ;


PROCEDURE insertPspTmp( pspListId VARCHAR2,
		                pspEntityId VARCHAR2,
		                pspEntityType CHAR,
						pspHomeSolId VARCHAR2) IS
BEGIN
	step := 5;
	--dbms_output.put_line(pspListId||':'||pspEntityId||':'||pspEntityType||':'||pspHomeSolId);
	INSERT INTO
	TBAADM.PSP_TMP
		(LISTID
		,ENTITY_ID
		,ID_TYPE
		,HOME_SOL_ID,BANK_ID)
	VALUES
		(pspListId
		,pspEntityId
		,pspEntityType
		,pspHomeSolId,'&9');
	commit;
EXCEPTION
	WHEN DUP_VAL_ON_INDEX  THEN
	--dbms_output.put_line('Dup val on index');
	NULL;
	WHEN OTHERS THEN
	--dbms_output.put_line(sqlerrm);
	NULL;
END insertPspTmp;


PROCEDURE processGamCursor( dummy NUMBER) IS
BEGIN
	--dbms_output.put_line('Inside processGamCursor');
	step := 4;
	FETCH gamCur
	INTO gamForacid;
	--dbms_output.put_line('Inside processGamCursor1');
	IF( gamCur%NOTFOUND ) then 
		endOfGamCursor := 1; 
		RETURN; 
	END IF; 
--dbms_output.put_line('Inside processGamCursor2');
	if(cnt = 0) then
		firstAcc := gamForacid;
		cnt := 1;
	end if;
--dbms_output.put_line('gamForacid:'||gamForacid);
--        if (substr(gamForacid,5,2) != '51') then
	if (NVL(substr(gamForacid,5,2),'X') != '51') then
                insertPspTmp(pspAcctListId, gamForacid, idTypeOld, solId);
        else
           if (dispMode = 'E') then
                insertPspTmp(pspAcctListId, gamForacid, idTypeOld, solId);
           end if;
        end if;
--dbms_output.put_line('Inside processGamCursor4');
END processGamCursor;
		

BEGIN
	custRecType		:= '01';
	custSubRecType	:= '0';
	cnt		:= 0;
	runId			:= '&1';
	solId			:= '&2';
	idType			:= substr('&4',1,2);
	idTypeOld		:= substr('&4',1,1);
--	custId			:= lpad('&5', 9);
	custId			:= '&5';
	dispMode                := '&8';
	pspCustListId	:= runId||solId||idType||'C';
	pspAcctListId	:= runId||solId||idType||'A';

	--dbms_output.put_line('runId: '||runId);
	--dbms_output.put_line('solId: '||solId);
	--dbms_output.put_line('idType: '||idType);
	--dbms_output.put_line('idTypeOld: '||idTypeOld);
	--dbms_output.put_line('custId: '||custId);
	--dbms_output.put_line('dispMode: '||dispMode);
	--dbms_output.put_line('pspCustListId: '||pspCustListId);
	--dbms_output.put_line('pspAcctListId: '||pspAcctListId);
	--dbms_output.put_line('Hi Here..');

	OPEN gamCur;
--	dbms_output.put_line('Hi Here..1');
	endOfGamCursor := 0;
--	dbms_output.put_line('Hi Here..2');
	firstAcc := '';
--		dbms_output.put_line('Hi Here..3');
	WHILE (endOfGamCursor = 0) LOOP
		processGamCursor(0);
	END LOOP;
--	dbms_output.put_line('Hi Here..4');
	CLOSE gamCur;
--dbms_output.put_line('test100');
	SELECT	cmg.cust_title_code || '.' || cmg.cust_name,
		cnma.ADDRESS1,
		cnma.ADDRESS2,
		cnma.CITY_CODE,
		cnma.STATE_CODE,
		cnma.CNTRY_CODE,
		cnma.PIN_CODE,
--			cust_comu_phone_num_1,
--			cust_comu_phone_num_2,
	        phone_num1,
		phone_num2,
		cmg.cust_stat_code,
		cmg.cust_nre_flg,
		cmg.cust_const
	INTO	cmgTitleName,
		cmgAddr1,
		cmgAddr2,
		cmgCityCode,
		cmgStateCode,
		cmgCntryCode,
		cmgPinCode,
		cmgPhone1,
		cmgPhone2,
		cmgCustStatCode,
		cmgCustNreFlag,
		cmgConst
--	FROM	CMG
  	FROM	CRMUSER.CMG,crmuser.cnma
--	WHERE	CIF_ID = custId;
	WHERE	CIF_ID = '&5' 
	AND cnma.ADDR_B2KID=cmg.CIF_ID
	AND cnma.ADDR_ID = cmg.ADDRESS_TYPE 
	AND CMG.BANK_ID='&9' 
	AND cnma.BANK_ID = '&9';

	if(cmgCustNreFlag = 'Y') then
		cmgCustStatCode := 'NRI';
	end if;
--dbms_output.put_line('test101');
-- JD added for sending GPC cover page for HNIPB, HNIPT,  HNIPS, HNIS and HNIM status codes.

         if((cmgCustStatCode != 'HNIPB') and (cmgCustStatCode != 'HNIPT') and (cmgCustStatCode != 'HNIPS') and (cmgCustStatCode != 'HNIS') and (cmgCustStatCode != 'HNIM')) then
            if(substr(cmgCustStatCode,1,3) = 'HNI') then
                cmgCustStatCode := 'HNI';
            end if;
        else
            if(cmgCustStatCode = 'HNIPB') then
                cmgCustStatCode := 'HNB';
            end if;
            if(cmgCustStatCode = 'HNIPT') then
                cmgCustStatCode := 'HNT';
            end if;
            if((cmgCustStatCode = 'HNIPS') or (cmgCustStatCode = 'HNIS')) then
                cmgCustStatCode := 'HNS';
            end if;
            if(cmgCustStatCode = 'HNIM') then
                cmgCustStatCode := 'HNM';
            end if;
        end if;

--dbms_output.put_line('test102');
--	SELECT  cif_id,
	SELECT  cif_id,
		email_id,
		stmt_reqd
	INTO
		ciftCustId,
		ciftEmailId,
		ciftStmtReqd
	FROM ICICI_CIFT
-- 	WHERE   CIF_ID = custId;
	WHERE   CIF_ID = custId AND BANK_ID='&9';

	if (cmgCityCode is not null) then
		BEGIN
		SELECT	ref_desc
		INTO	cityDesc
		FROM	RCT
		WHERE	ref_rec_type = '01'
		AND		ref_code = cmgCityCode  AND BANK_ID='&9';
		EXCEPTION WHEN OTHERS THEN NULL;
		END;
	else
		cityDesc := '';
	end if;

	if (cmgStateCode is not null) then
		BEGIN
		SELECT	ref_desc
		INTO	stateDesc
		FROM	RCT
		WHERE	ref_rec_type = '02'
		AND		ref_code = cmgStateCode AND BANK_ID='&9';
		EXCEPTION WHEN OTHERS THEN NULL;
		END;
	else
		stateDesc := '';
	end if;
--dbms_output.put_line('test103');
	if (cmgCntryCode is not null) then
		BEGIN
		SELECT	ref_desc
		INTO	cntryDesc
		FROM	RCT
		WHERE	ref_rec_type = '03'
		AND		ref_code = cmgCntryCode  AND BANK_ID='&9';
		EXCEPTION WHEN OTHERS THEN NULL;
		END;
	else
		cntryDesc := '';
	end if;
--dbms_output.put_line('test104');
	-- Check if cust const is one of WBG const codes

	wbgCust := 'N';
	tmpConst := '';

	BEGIN
		select key_value into tmpConst from fsg_cfg where
        key_value = cmgConst and (key_type = 99 or key_type = 100)  AND BANK_ID='&9';

		if(tmpConst = cmgConst) then
			wbgCust := 'Y';
		end if;

		exception
			when others then null;
	END;
--dbms_output.put_line('test105');
	if(wbgCust = 'N') then
		tmpConst := '';
	end if;

	if ( cnt > 0 ) then
		insertPspTmp(pspCustListId, custId, idTypeOld, solId);

	if ( dispMode = 'E' ) then
               dbms_output.put_line(    solId               || '|' ||
                                ciftCustId              || '|01|0|' ||
                                ciftEmailId             || '|' ||
                                ltrim(rtrim(cmgTitleName))    || '|' ||
                                ltrim(rtrim(cmgAddr1))                || '|' ||
                                ltrim(rtrim(cmgAddr2))                || '|' ||
                                ltrim(rtrim(cityDesc))              || '|' ||
                                ltrim(rtrim(stateDesc)) || '|' ||
                                ltrim(rtrim(cntryDesc)) || ' - ' ||
                                ltrim(rtrim(cmgPinCode)) || '|' ||
 				cmgCustStatCode || '|' ||
                                dispMode ||'|'||firstAcc||'||'||tmpConst);
			else
				if(wbgCust = 'Y') then
					dbms_output.put_line('Test');
					carRec:= solId||'|'||ciftCustId||'|01|0|'||ltrim(rtrim(ciftEmailId))||'|'||
					ltrim(rtrim(cmgTitleName))||'|'||ltrim(rtrim(cmgAddr1))||'|'||
					ltrim(rtrim(cmgAddr2))||'|'||ltrim(rtrim(cityDesc))||'|'||
					ltrim(rtrim(stateDesc))||'|'||ltrim(rtrim(cntryDesc))||' - '||
					ltrim(rtrim(cmgPinCode))||'|'||cmgCustStatCode||'|'||'Y'||'|'||
					firstAcc||'||'||tmpConst;
					--dbms_output.put_line('Test1');
					dbms_output.put_line(carRec);
				else
					--dbms_output.put_line('Test2');
					carRec:= solId||'|'||ciftCustId||'|01|0|'||ltrim(rtrim(ciftEmailId))||'|'||
					ltrim(rtrim(cmgTitleName))||'|'||ltrim(rtrim(cmgAddr1))||'|'||
					ltrim(rtrim(cmgAddr2))|| '|' ||ltrim(rtrim(cityDesc))||'|'||
					ltrim(rtrim(stateDesc))||'|'||ltrim(rtrim(cntryDesc))||' - '||
					ltrim(rtrim(cmgPinCode))||'|'||cmgCustStatCode||'|'||'Y'||'|'||
					ltrim(rtrim(cmgPhone1))||' - '||ltrim(rtrim(cmgPhone2)) || '||'||tmpConst;
					--dbms_output.put_line('Test3');
					if(length(carRec) > 255) then
						--dbms_output.put_line('Test4');
						carRec :=  solId||'|'||ciftCustId||'|01|0|'||'|'||
						ltrim(rtrim(cmgTitleName))||'|'||ltrim(rtrim(cmgAddr1))||'|'||
						ltrim(rtrim(cmgAddr2))|| '|' ||ltrim(rtrim(cityDesc))||'|'||
						ltrim(rtrim(stateDesc))||'|'||ltrim(rtrim(cntryDesc))||' - '||
						ltrim(rtrim(cmgPinCode))||'|'||cmgCustStatCode||'|'||'Y'||'|'||
						ltrim(rtrim(cmgPhone1))||' - '||ltrim(rtrim(cmgPhone2)) || '||'||tmpConst;
						--dbms_output.put_line('Test5');
						if(length(carRec) > 255) then
							--dbms_output.put_line('Test6');
							carRec :=  solId||'|'||ciftCustId||'|01|0|'||'|'||
							ltrim(rtrim(cmgTitleName))||'|'||ltrim(rtrim(cmgAddr1))||'|'||
							ltrim(rtrim(cmgAddr2))|| '|' ||ltrim(rtrim(cityDesc))||'|'||
							ltrim(rtrim(stateDesc))||'|'||ltrim(rtrim(cntryDesc))||' - '||
							ltrim(rtrim(cmgPinCode))||'|'||cmgCustStatCode||'|'||'Y'||'|'||
							'||'||tmpConst;
							--dbms_output.put_line('Test7');
							dbms_output.put_line(carRec);
						else
							--dbms_output.put_line('Test8');
							dbms_output.put_line(carRec);
						end if;
					else
						--dbms_output.put_line('Test9');
						dbms_output.put_line(carRec);
					end if;
			 	end if; -- (if WBGCust = Y)
			end if; -- (If dispMode = E)

--VD Starts Herechanges for RMCSM
	--dbms_output.put_line('Test10');
--          if ( (cmgCustStatCode = 'HNI') or (cmgCustStatCode = 'HNM')) then
--Changed for  CR-138-30078 starts
          if ( ( cmgCustStatCode = 'HNI' or cmgCustStatCode = 'HNM' ) and wbgCust != 'Y' ) then
--Changed for  CR-138-30078 ends


                	 begin
               		select rm_name,rm_email,rm_mobile,csm_name,csm_email,csm_mobile into rmname,rmemail,rmmob,csmname,csmemail,csmmob from ici_wm_map 
			--where cif_id=ciftCustId;
			where cif_id=ciftCustId  AND BANK_ID='&9';
              Exception 
              When no_data_found Then
              rmname := 'NA';
              rmemail := 'NA';
              rmmob := 'NA';
              csmname := 'NA';
              csmemail := 'NA';
              csmmob := 'NA';
             		 end; 

                      begin 
                      select count(1) into cnt1 from ici_wm_map 
--		      where cif_id=ciftCustId;
	              where cif_id=ciftCustId AND BANK_ID='&9';
					  end;
--            if (cnt1 > 0) then
              if (cnt1 = 1) then
		--dbms_output.put_line('Test11');
              carRec := SolId||'|'||ciftCustId||'|01|1|'||ltrim(rtrim(rmname))||'|'||
              ltrim(rtrim(rmemail))||'|'||ltrim(rtrim(rmmob))||'|'||ltrim(rtrim(csmname))
                ||'|'||ltrim(rtrim(csmemail))||'|'||ltrim(rtrim(csmmob))||' | | | | | |';

		--dbms_output.put_line('Test12');
           dbms_output.put_line(carRec);
  end if; 
      end if;
-- VD ends Here changes for RMCSM

	end if;
COMMIT;	
	-- (If cnt > 0)
	EXCEPTION
	WHEN DUP_VAL_ON_INDEX THEN
	NULL;
	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('<#ORA-ERROR#>');
		DBMS_OUTPUT.PUT_LINE('Cust Id/Account Id list creation failed at step...'||step);
		DBMS_OUTPUT.PUT_LINE('Cust Id '||custId);
		DBMS_OUTPUT.PUT_LINE('Check SQL error,  and try again');
		DBMS_OUTPUT.PUT_LINE('Sql Error Code is        : ' || SQLCODE );
		DBMS_OUTPUT.PUT_LINE('SQL Error Description is : '|| SQLERRM);
		ROLLBACK;
		DBMS_OUTPUT.PUT_LINE('Current Chunk rolled back.');
END;
/
spool off
