set head off
set feedback off
set verify off
set linesize 5
set pagesi 0
spool ALL.list
select sol_id from sol where bank_id = '&1'
/
spool off
exit
