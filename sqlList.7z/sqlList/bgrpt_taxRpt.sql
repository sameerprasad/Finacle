--=======================================================
-- Author : SUBHASISH PARAMANIK
-- Date   :
-- Module : Menu option for generating report date wise for BG Tax collection
-- Menu   : BGSTAT
-- [Author]         [Date]          [Line]      [Desc]
--=======================================================
CREATE OR REPLACE PACKAGE ICICI.BG_BATCH_STAT AS
PROCEDURE BG_BATCH_STATProc(  inp_str         IN VARCHAR2,
                out_retCode         OUT NUMBER,
                out_rec         OUT VARCHAR2) ;
g_mode        Char(1):= 'S';
END BG_BATCH_STAT;
/

CREATE OR REPLACE PACKAGE BODY ICICI.BG_BATCH_STAT AS--{
------------------------------------------------------------------------------
TYPE rec_output IS RECORD(record_output  VARCHAR2(2000));
TYPE output_type IS TABLE OF rec_output INDEX BY BINARY_INTEGER;
output_table                            OUTPUT_TYPE;
g_number                                NUMBER;
g_current_row                           BINARY_INTEGER;
v_insert_row                            BINARY_INTEGER;
g_rowcount                              NUMBER;
------------------------------------------------------------------------------
-- GLOBAL VARIABLE
Input_From_Date                         VARCHAR2(10);
Input_BG_num                            varchar(16);
Input_Bank_Id				varchar(8);
issue_date                            DATE;
party_code                              varchar(5);
custid                               	varchar(9);
bg_class                        	varchar(8);
------------------------------------------------------------------------------
--In the below query we are selecting  all the upfornt and deffered records
------------------------------------------------------------------------------
CURSOR Cur_bg1(Input_From_Date date,Input_Bank_Id VARCHAR2) IS 
select b.bg_srl_num,t.b2k_id,t.b2kid_type,t.EVENT_TYPE,t.ptran_bus_type ,b.sol_id,replace(b.cust_id,b.cust_Id,'') tran_id ,
b.issue_date tran_date ,t.ttl_chrg_tobe_coll_amt tran_amt, t.chrg_Coll_type up_def_flg,t.tfct_key_srl_num ect_key_srl_num,
b.bg_class bg_class,b.cust_id custid,NULL party_code,to_date(b.issue_date,'dd-mm-yyyy') issue_date,t.EVENT_SRL_NUM,'1' comp_b2kId
--from tbaadm.bgm b,tbaadm.tfct t,tbaadm.CXL c
from tbaadm.bgm b,tbaadm.tfct t
where b.BG_B2KID = t.b2k_id
--and t.ptran_bus_type is not null
--and substr(c.comp_b2kid,1,12) like '%'||t.b2k_id||'%'
--and c.CHRG_PART_TRAN_SRL_NUM > 0
and b.BG_B2KID in (select distinct bg_b2kid from bet where event_date =Input_From_Date)
and t.ttl_chrg_tobe_coll_amt != '0'
and t.chrg_Coll_type = 'I'
and b.bank_id = Input_Bank_Id
and b.bank_id = t.bank_id
and b.entity_cre_flg != 'N'
and t.b2kid_type='BNKGR'
union all
select BG_SRL_NUM,b2k_Id,b2kid_type,d.EVENT_TYPE,c.ptran_bus_type,b.sol_Id,c.chrg_tran_id tran_id,c.chrg_tran_date tran_date,tran_amt, 'D' up_def_flg,
tfct_srl_num ect_key_srl_num,b.bg_class bg_class,b.cust_id custid,NULL party_code,to_date(b.issue_date,'dd-mm-yyyy') issue_date,d.EVENT_SRL_NUM,c.comp_b2kId comp_b2kId
from tbaadm.tdcc d, tbaadm.bgm b,tbaadm.cxl c
where d.b2k_id = b.bg_b2kid
and trim(chrg_tran_id) in(Select trim(chrg_tran_id) from cxl where substr(cxl.comp_b2kid,1,12) like '%'||d.b2k_id||'%' and chrg_tran_date=Input_From_Date and chrg_tran_date=d.due_date)
and chrg_tran_date=Input_From_Date
and due_date =Input_From_Date
and d.b2kid_type='BNKGR'
and b.bank_id = Input_Bank_Id
and d.tran_date is not null
and b.entity_cre_flg != 'N'
and b.bank_id = d.bank_id;

PROCEDURE BG_BATCH_STATProc(  inp_str         IN VARCHAR2,
                out_RetCode         OUT NUMBER,
                out_rec         OUT VARCHAR2)
IS
OutArr                      basp0099.ArrayType;
v_record_output             VARCHAR2(2000);
-------------------------------------------------------------------
-- Local Variable
v_tran_stat             VARCHAR2(8);
v_pstd_flg_cnt          NUMBER(5);
v_tax_tran_stat         VARCHAR2(8);
v_tax_pstd_flg_cnt      NUMBER(5);

v_dcc_pstd_flg_cnt      NUMBER(5);
v_dcc_tran_stat         VARCHAR2(8);

v_bg_srl_num        tbaadm.BGM.BG_SRL_NUM%TYPE;
v_sol_id            tbaadm.BGM.SOL_ID%TYPE;
v_oper_acid         tbaadm.BGM.OPER_ACID%TYPE;
v_foracid           tbaadm.GAM.FORACID%TYPE;
v_actual_amt_coll   tbaadm.cxl.actual_amt_coll%TYPE;
v_chrg_tran_id      tbaadm.cxl.chrg_tran_id %TYPE;
v_chrg_tran_date    tbaadm.cxl.chrg_tran_date%TYPE;
v_def_Id	    tbaadm.cxl.chrg_tran_id %TYPE;
v_def_date	    tbaadm.cxl.chrg_tran_date%TYPE;
v_event_type        tbaadm.cxl.event_type%TYPE;
v_event_id          tbaadm.cxl.event_id%TYPE;

v_TAX_TRAN_ID       tbaadm.cxl.chrg_tran_id%TYPE;
v_TAX_AMT           tbaadm.cxl.actual_amt_coll%TYPE;

lc_actual_amt_coll  tbaadm.cxl.actual_amt_coll%TYPE;
lc_tran_id          tbaadm.cxl.chrg_tran_id%TYPE;
lc_tran_date        tbaadm.cxl.chrg_tran_date%TYPE;

v_ttl_tobe_coll_amt tbaadm.cxl.actual_amt_coll%TYPE;
v_ttl_due_amt       tbaadm.cxl.actual_amt_coll%TYPE;
v_ttl_coll_amt      tbaadm.cxl.actual_amt_coll%TYPE;

v_temp_tran_id      tbaadm.cxl.chrg_tran_id%TYPE;
v_temp_tran_amt     tbaadm.cxl.actual_amt_coll%TYPE;
v_max		    tbaadm.cht.CHT_KEY_SRL_NUM%TYPE;
v_def_bustype	    tbaadm.cxl.PTRAN_BUS_TYPE%TYPE;	
------------------------------------------------------------------
BEGIN --{
        out_retCode := 0;
        out_rec := '';

        IF g_mode = 'S'  THEN --{
        basp0099.formInputArr(inp_str,OutArr);

        Input_From_Date     :=      to_char(to_date(OutArr(0),'DD-MM-YYYY'),'DD-MM-YYYY');
        dbms_output.put_line('FROM_DATE'||Input_From_Date);
	-- Below Line Added - Ranjith
	Input_Bank_Id     := OutArr(1);
------------------------------------------------------------------------------
        v_insert_row := 0;
       -- For Cur_bg IN Cur_bg1(Input_From_Date)
       For Cur_bg IN Cur_bg1(Input_From_Date,Input_Bank_Id)
        LOOP                --{
            -------------------------------------------------------
            --  select sol_id and operative acid
            -------------------------------------------------------
            BEGIN
                SELECT      BG_SRL_NUM, SOL_ID, OPER_ACID
                INTO        v_bg_srl_num, v_sol_id, v_oper_acid
                FROM        BGM
                WHERE       BG_B2KID = Cur_bg.b2k_id
		and         bgm.bank_id = Input_Bank_Id;
            EXCEPTION WHEN NO_DATA_FOUND THEN
                v_bg_srl_num := '';
                v_sol_id := '';
                v_oper_acid := '';
            END;

            IF(v_oper_acid is not null)then
                BEGIN
                    SELECT      FORACID
                    INTO        v_foracid
                    FROM        GAM
                    WHERE       ACID = v_oper_acid
		    and         gam.bank_id = Input_Bank_Id;
                EXCEPTION WHEN NO_DATA_FOUND THEN
                    v_foracid := '';
                END;
            END IF;

		IF(Cur_bg.up_def_flg = 'I') THEN
			Cur_bg.up_def_flg := 'U';
		ELSE
			Cur_bg.up_def_flg := 'D';
		END IF;
                dbms_output.put_line(Cur_bg.BG_SRL_NUM||'----------------');
                dbms_output.put_line(Cur_bg.BG_SRL_NUM||'|'||Cur_bg.tran_id||'|'||Cur_bg.tran_amt);
		 -------------------------------------------------------
            --  Get event_id , event_type from ect
            -------------------------------------------------------
            BEGIN
                select chrg_event_id , chrg_event_type
                into    v_event_id,v_event_type
	--       from ect
		from tbaadm.tfct
                where tfct.b2k_id = Cur_bg.b2k_id
                and tfct.b2kid_type = Cur_bg.b2kid_type
               -- and ((tfct.ptran_bus_type = Cur_bg.ptran_bus_type) or (tfct.ptran_bus_type is null))
                and tfct.tfct_key_srl_num = Cur_bg.ect_key_srl_num
		and tfct.EVENT_TYPE = Cur_bg.EVENT_TYPE
		and tfct.EVENT_SRL_NUM = Cur_bg.EVENT_SRL_NUM
		and bank_id = Input_Bank_Id;
		--and rownum <2;
            EXCEPTION WHEN NO_DATA_FOUND THEN
                v_event_type := '';
                v_event_id := '';
            END;

if (v_event_id is null) then
            BEGIN
                dbms_output.put_line('------'||'|'||Cur_bg.b2k_id||'|'||Cur_bg.b2kid_type||'|'||Cur_bg.ptran_bus_type||'|'||Cur_bg.ect_key_srl_num||'|'||Cur_bg.tran_id||'|'||Cur_bg.tran_date);
		select event_id , event_type
                into    v_event_id,v_event_type
                from cht
                where b2k_id = Cur_bg.b2k_id
                and b2kid_type = Cur_bg.b2kid_type
                and ptran_bus_type = Cur_bg.ptran_bus_type
                and ect_srl_num = Cur_bg.ect_key_srl_num
                and tran_id = lpad(Cur_bg.tran_id,9,' ')
                and tran_date = Cur_bg.tran_date
                and rownum < 2;
            EXCEPTION WHEN NO_DATA_FOUND THEN
                v_event_type := '';
                v_event_id := '';
            END;
                dbms_output.put_line('------'||'|'||v_event_id||'|'||v_event_type);
end if;


                dbms_output.put_line('CXL--event'||Cur_bg.b2k_id||'|'||Cur_bg.b2kid_type||'|'||Input_From_Date||'|'||Cur_bg.ptran_bus_type||'|'||Cur_bg.ect_key_srl_num||'|'||v_event_type||'|'||v_event_id||'|'||Cur_bg.tran_amt);
		if (Cur_bg.up_def_flg = 'U') then
            -------------------------------------------------------
            --  From CXL deffered and upfront charge amount collected along with tran id and tran date
	    -------------------------------------------------------
            BEGIN
                SELECT      actual_amt_coll,chrg_tran_id,chrg_tran_date
                INTO        v_actual_amt_coll, v_chrg_tran_id, v_chrg_tran_date
                FROM        cxl
             --   WHERE       comp_b2kid = Cur_bg.b2k_id
	     WHERE		substr(cxl.comp_b2kid,1,12) like '%'||Cur_bg.b2k_id||'%'
                and         CHRG_TRAN_DATE =Input_From_Date
                and         COMP_B2KID_TYPE='BNKGR'
--              and         ptran_bus_type is null
--              and         ptran_bus_type = Cur_bg.ptran_bus_type
                and         ((ptran_bus_type = Cur_bg.ptran_bus_type) OR ( ptran_bus_type is null))
--		and         ptran_bus_type = Cur_bg.ptran_bus_type
                and         event_type = v_event_type
                and         event_id = v_event_id
                and         actual_amt_coll = Cur_bg.tran_amt
                and         entity_cre_flg ='Y'
                and         del_flg != 'Y'
--		and	    trim(CHRG_PART_TRAN_SRL_NUM) is null
		and	    bank_id = Input_Bank_Id;
	--	and rownum <2;
            EXCEPTION WHEN NO_DATA_FOUND THEN
                v_actual_amt_coll := '';
                v_chrg_tran_id := '';
                v_chrg_tran_date := '';
                WHEN OTHERS THEN
                v_actual_amt_coll := '';
                v_chrg_tran_id := '';
                v_chrg_tran_date := '';
            END;
        else
                v_chrg_tran_date := Input_From_Date;
        end if;

            dbms_output.put_line('CXL--after'||Cur_bg.b2k_id||'|'||v_actual_amt_coll||'|'||v_chrg_tran_id||'|'||v_chrg_tran_date);
	     -------------------------------------------------------
            --  If above CXL query fails then fetch the details from CHT
            -------------------------------------------------------
            ---- Ranjith --- if (v_actual_amt_coll != '') then
	    if (v_actual_amt_coll = '') then
            BEGIN
                select ttl_chrg_coll_amt,tran_id , tran_date
                into    v_actual_amt_coll, v_chrg_tran_id, v_chrg_tran_date
                from CHT
                where b2k_id = Cur_bg.b2k_id
                and b2kid_type = Cur_bg.b2kid_type
                and ptran_bus_type = Cur_bg.ptran_bus_type
                and ect_srl_num = Cur_bg.ect_key_srl_num;
            EXCEPTION WHEN NO_DATA_FOUND THEN
                v_actual_amt_coll := '';
                v_chrg_tran_id := '';
                v_chrg_tran_date := '';
            END;
            end if;


IF ( Cur_bg.up_def_flg = 'U' ) then
    v_temp_tran_id := v_chrg_tran_id;
    v_temp_tran_amt := v_actual_amt_coll ;
else
    v_temp_tran_id := Cur_bg.tran_id ;
    v_temp_tran_amt := Cur_bg.tran_amt;
end if;

            dbms_output.put_line('temp--'||Cur_bg.b2k_id||'|'||v_actual_amt_coll||'|'||v_chrg_tran_id||'|'||v_chrg_tran_date||'|'||Cur_bg.tran_id||'|'||Cur_bg.tran_amt||'|'||v_temp_tran_id||'|'||v_temp_tran_amt);
	    dbms_output.put_line('t-t-'||Cur_bg.b2k_id||'|'||Cur_bg.ptran_bus_type||'|'||v_event_type||'|'||cur_bg.ect_key_srl_num||'|'||v_chrg_tran_date);
	    -------------------------------------------------------
            --  From ICICI_BTX get service tax colletec for the deffered or Upfonrt transaction
	     -------------------------------------------------------
            BEGIN
                select  tax_tran_id, tax_amt
                into    v_tax_tran_id, v_tax_amt
                from    icici_btx
                where   sol_id = cur_bg.sol_id
       --         and     ptran_bus_type = Cur_bg.ptran_bus_type
		and	((ptran_bus_type = Cur_bg.ptran_bus_type) OR (ptran_bus_type is null) OR (ptran_bus_type='!'))
                and     bg_srl_num = cur_bg.bg_srl_num
                and     event_type = v_event_type
                and     ect_srl_num =cur_bg.ect_key_srl_num
                --and     tran_id = lpad(v_temp_tran_id,9,' ')
		and     trim(tran_id) = trim(v_temp_tran_id)
                and     tran_date = v_chrg_tran_date
                and     tran_amt =v_temp_tran_amt
		and bank_id = Input_Bank_Id
		and rownum <2;
                exception when no_data_found then
                    v_tax_tran_id := '';
                    v_tax_amt := '';
            END;
            dbms_output.put_line('iciciBTX--'||Cur_bg.b2k_id||'|'||v_tax_tran_id||'|'||v_tax_amt);
	    -------------------------------------------------------
            --  From UPFRONT charge tran id exits then chk for posted ot not
            -------------------------------------------------------
            if(v_chrg_tran_id is not null)then
                BEGIN
                    select sum(pstd_flg_cnt) INTO        v_pstd_flg_cnt FROM (
                    SELECT      COUNT(*)    pstd_flg_cnt FROM     DTD
                    WHERE       TRAN_ID   = lpad(v_chrg_tran_id,'9',' ')
                    AND         TRAN_DATE = Input_From_Date
                    AND         PSTD_FLG !='Y'
                    and         ACID = (select acid from gam where foracid =v_foracid)
		    and bank_id = Input_Bank_Id
                    union all
                    SELECT      COUNT(*)    pstd_flg_cnt FROM     HTD
                    WHERE       TRAN_ID   = lpad(v_chrg_tran_id,'9',' ')
                    AND         TRAN_DATE = Input_From_Date
                    AND         PSTD_FLG !='Y'
                    and         ACID = (select acid from gam where foracid =v_foracid) 
		    and bank_id = Input_Bank_Id);
                EXCEPTION WHEN NO_DATA_FOUND THEN
                    v_pstd_flg_cnt := '';
                END;
                if(v_pstd_flg_cnt > 0)then
                    v_tran_stat := 'Failure';
                else
                    v_tran_stat := 'Success';
                end if;
            end if;

            -------------------------------------------------------
            --  From DEFFERED charge tran id exits then chk for posted ot not
            -------------------------------------------------------
            if(Cur_bg.tran_Id is not null)then
                BEGIN
                    select sum(dcc_pstd_flg_cnt) INTO        v_dcc_pstd_flg_cnt FROM(
                    SELECT      COUNT(*)    dcc_pstd_flg_cnt FROM     DTD
                    WHERE       TRAN_ID   = lpad(Cur_bg.tran_Id,'9',' ')
                    AND         TRAN_DATE = Input_From_Date
                    AND         PSTD_FLG !='Y'
                    and         ACID = (select acid from gam where foracid =v_foracid)
		    and bank_id = Input_Bank_Id
                    union all
                    SELECT      COUNT(*)    dcc_pstd_flg_cnt FROM     HTD
                    WHERE       TRAN_ID   = lpad(Cur_bg.tran_Id,'9',' ')
                    AND         TRAN_DATE = Input_From_Date
                    AND         PSTD_FLG !='Y'
                    and         ACID = (select acid from gam where foracid =v_foracid)
		    and bank_id = Input_Bank_Id);
                EXCEPTION WHEN NO_DATA_FOUND THEN
                    v_dcc_pstd_flg_cnt := '';
                END;
                if(v_dcc_pstd_flg_cnt > 0)then
                    v_dcc_tran_stat := 'Failure';
                else
                    v_dcc_tran_stat := 'Success';
                end if;
            end if;

            -------------------------------------------------------
            --  From SERVICE TAX tran id exits then chk for posted or not
            -------------------------------------------------------
            if(v_TAX_TRAN_ID is not null)then
               BEGIN
                    select sum(tax_pstd_flg_cnt) INTO        v_tax_pstd_flg_cnt FROM(
                    SELECT      COUNT(*)    tax_pstd_flg_cnt FROM     DTD
                    WHERE       TRAN_ID   = lpad(v_TAX_TRAN_ID,'9',' ')
                    AND         TRAN_DATE = Input_From_Date
                    AND         PSTD_FLG !='Y'
                    and         ACID = (select acid from gam where foracid =v_foracid)
		    and bank_id = Input_Bank_Id
                    union all
                    SELECT      COUNT(*)    tax_pstd_flg_cnt FROM     HTD
                    WHERE       TRAN_ID   = lpad(v_TAX_TRAN_ID,'9',' ')
                    AND         TRAN_DATE = Input_From_Date
                    AND         PSTD_FLG !='Y'
                    and         ACID = (select acid from gam where foracid =v_foracid)
		    and bank_id = Input_Bank_Id);
                EXCEPTION WHEN NO_DATA_FOUND THEN
                    v_tax_pstd_flg_cnt := '';
                END;
                if(v_tax_pstd_flg_cnt > 0)then
                    v_tax_tran_stat := 'Failure';
                else
                    v_tax_tran_stat := 'Success';
                end if;
            else
                    v_tax_tran_stat := 'Failure';
            end if;
            if(Cur_bg.up_def_flg ='D')then
            BEGIN
                v_actual_amt_coll := Cur_bg.tran_amt;
                v_chrg_tran_id := Cur_bg.tran_id;
                v_chrg_tran_date := Cur_bg.tran_date;
            END;

            -------------------------------------------------------
            --  If deffered then find out total collected / total pending etc from ect.
            -------------------------------------------------------

			BEGIN
                --select      max(cht_key_srl_num) 
		select      max(tdcc_key_srl_num) 
        into        v_max
             --   from        cht
	     from        tdcc
--                where       upfront_def_flg ='D'
                where         b2kid_type ='BNKGR'
                and         b2k_id = Cur_bg.b2k_id
                and         ptran_bus_type = Cur_bg.ptran_bus_type
                and         event_type = v_event_type
                and         tfct_srl_num =Cur_bg.ect_key_srl_num
		and	    event_srl_num =Cur_bg.event_srl_num
		and bank_id = Input_Bank_Id;
                EXCEPTION WHEN NO_DATA_FOUND THEN
                v_max :='0';
                END;

            BEGIN
                select      ttl_chrg_tobe_coll_amt,ttl_chrg_due_amt,ttl_chrg_coll_amt
		into        v_ttl_tobe_coll_amt,v_ttl_due_amt,v_ttl_coll_amt
                --from        cht
		from        tfct
                where       chrg_Coll_type !='I'
                and         b2kid_type ='BNKGR'
                and         b2k_id = Cur_bg.b2k_id
                and         ptran_bus_type = Cur_bg.ptran_bus_type
                and         event_type = v_event_type
                and         event_srl_num =Cur_bg.ect_key_srl_num
		and	    tfct_key_srl_num = v_max
		and bank_id = Input_Bank_Id
		and rownum <2;
                EXCEPTION WHEN NO_DATA_FOUND THEN
                v_ttl_tobe_coll_amt :='0';
                v_ttl_due_amt       :='0';
                v_ttl_coll_amt      :='0';
                END;
            end if;

			BEGIN
				v_ttl_due_amt := v_ttl_tobe_coll_amt - v_ttl_coll_amt;
			END;


       if (Cur_bg.up_def_flg ='D') then

		BEGIN
		IF(Cur_bg.TRAN_ID is NULL)THEN
			BEGIN
				Select CHRG_TRAN_ID,CHRG_TRAN_DATE,PTRAN_BUS_TYPE
				into v_def_Id,v_def_date,v_def_bustype
				from CXL
				where substr(cxl.comp_b2kid,1,12) like '%'||Cur_bg.b2k_id||'%'
				and         CHRG_TRAN_DATE =Input_From_Date
				and         COMP_B2KID_TYPE='BNKGR'
				and         actual_amt_coll = Cur_bg.tran_amt
				and         entity_cre_flg ='Y'
				and         del_flg != 'Y'
				and	    bank_id = Input_Bank_Id;
				EXCEPTION WHEN NO_DATA_FOUND THEN
				v_def_Id:='';
				v_def_date:='';
				v_def_bustype:='';
				WHEN OTHERS THEN
				v_def_Id:='';
				v_def_date:='';
				v_def_bustype:='';
			END;

			BEGIN
				Cur_bg.TRAN_ID:=v_def_Id;
				Cur_bg.TRAN_DATE:=v_def_date;
				v_dcc_tran_stat:='Success';
				Cur_bg.ptran_bus_type:=v_def_bustype;
			END;
		END IF;
		END;

	end if;




---------------------------------------------------------------------------
     v_insert_row:=v_insert_row+1;
---------------------------------------------------------------------------
       if (Cur_bg.up_def_flg ='U') then
        --if (Cur_bg.up_def_flg ='N') then

         v_record_output:=  v_bg_srl_num                ||'|'||
                            v_sol_id            ||'|'||
                            Cur_bg.ptran_bus_type        ||'|'||
                            v_actual_amt_coll       ||'|'||
                            v_chrg_tran_id          ||'|'||
                            v_CHRG_TRAN_DATE        ||'|'||
                            v_foracid               ||'|'||
                            v_tran_stat             ||'|'||
                            v_TAX_TRAN_ID                   ||'|'||
                            v_TAX_AMT                   ||'|'||
                            v_tax_tran_stat||'|'||
                            '0'||'|'||
                            '0'||'|'||
                            '0'||'|'||
                            Cur_bg.up_def_flg||'|'||
			    --'U'||'|'||
			    Cur_bg.custid||'|'||
			    Cur_bg.party_code||'|'||
			    Cur_bg.issue_date||'|'||
		  	    Cur_bg.bg_class;

        else
         v_record_output:=  v_bg_srl_num                ||'|'||
                            v_sol_id            ||'|'||
                            Cur_bg.ptran_bus_type        ||'|'||
                            Cur_bg.tran_amt       ||'|'||
                            Cur_bg.TRAN_ID          ||'|'||
                            Cur_bg.TRAN_DATE        ||'|'||
                            v_foracid               ||'|'||
                            v_dcc_tran_stat             ||'|'||
                            v_TAX_TRAN_ID                   ||'|'||
                            v_TAX_AMT                   ||'|'||
                            v_tax_tran_stat         ||'|'||
                            v_ttl_tobe_coll_amt     ||'|'||
                            v_ttl_due_amt           ||'|'||
                            v_ttl_coll_amt||'|'||
		  	    Cur_bg.up_def_flg||'|'||
			    --'D'||'|'||
                            Cur_bg.custid||'|'||
                            Cur_bg.party_code||'|'||
                            Cur_bg.issue_date||'|'||
			    Cur_bg.bg_class;
        end if;

---------------------------------------------------------------------------
        output_table(v_insert_row).Record_output:=v_record_output;
---------------------------------------------------------------------------
                v_actual_amt_coll   := '0';
                v_chrg_tran_id      := '';
                v_CHRG_TRAN_DATE    := '';
                v_tran_stat         := '';
                v_foracid           := '';
                v_dcc_tran_stat     :='';
                v_TAX_TRAN_ID       :='';
                v_TAX_AMT           :='0';
                v_tax_tran_stat     :='';
                v_ttl_tobe_coll_amt :='0';
                v_ttl_due_amt       :='0';
                v_ttl_coll_amt      :='0';
        END LOOP;           --}

-------------------------------------------------------------------------

                g_mode := 'G';
                g_rowcount := output_table.Count;
                g_current_row := 0;

                ELSIF g_mode = 'G' THEN --}{
                        g_current_row := g_current_row + 1;
                        IF g_current_row > g_rowcount
                        THEN
                                output_table.delete ;
                                g_current_row := 0;
                                g_rowcount := 0;
                                out_retcode := 1;
                                g_mode := 'S' ;
                                Return ;
                        END IF;
                        out_rec := output_table(g_current_row).record_output;
        END IF; --}
-------------------------------------------------------------------------
END BG_BATCH_STATProc; --}
END BG_BATCH_STAT; --}
/
DROP PUBLIC SYNONYM  BG_BATCH_STAT
/
CREATE PUBLIC SYNONYM  BG_BATCH_STAT FOR  ICICI.BG_BATCH_STAT
/
GRANT EXECUTE ON  ICICI.BG_BATCH_STAT TO TBAGEN, TBAUTIL
/
COMMIT
/
