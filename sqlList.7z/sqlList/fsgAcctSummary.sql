--Aneesh S: Added exception handling (09-01-2013)

--===================================================================================================================
--Source Name            :  fsgAcctSummary.sql

--Input Values           :  None
--Output Values          :  Validation
--Called Scripts         :  None
--Calling Scripts        :  None
--Modification history   :
--Instance               :  BBY
--Menu                  :  ICIFSTMT
--Sl. No            Date                 Author                       Description
-- ---------     --------------    ----------------------        ------------------------------
--   1.0             26-04-2013       Supreeth V              Changes made for 10.x for CR-138-30632
--   2.0             02-05-2013       Seemantini DOra         Budfixes while CR testing
--   3.0             14-06-2013       Amruta Sonpatki         Changes made for Cr-138-37838
--   4.0             17-06-2013       Priyanka Shinde         Changes made for CR-138-38546

--=====================================================================================================================




set serveroutput on size 1000000
set head off
set linesize 512
set trims on
set pages 0
set feedback off
set verify off
set termout off
spool &1-&2-&3-&4

DECLARE

stmtReqd			ICICI_CIFT.stmt_reqd%type;
locListId			PSP_TMP.listid%TYPE;
locSolId			PSP_TMP.home_sol_id%TYPE;
locFrDate			date;
locToDate			date;
locLinkedFlg		char(1);
locTranDateBal		EAB.tran_date_bal%TYPE;
locCrncyCode		GAM.crncy_code%TYPE;
locCustId			PSP_TMP.entity_id%TYPE;
--locIdType			PSP_TMP.id_type%TYPE;
locIdType			varchar2(2);
locRunId			varchar2(10);
tdtOperAcid			gam.foracid%type;
tdtAcid				TDT.acid%TYPE;
fflAcid				FFL.acid%TYPE;
locOutRec			varchar2(500);
tdtDeposit			TDT.flow_amt%type;
tdtOpenDate			TDT.flow_date%type;
tdtDepMths			tdt.dep_period_mths%type;
tdtDepDays			tdt.dep_period_days%type;
tdtRate				tdt.actual_int_pcnt%type;
tdtRate2			tdt.actual_int_pcnt%type;
tdtMatDate			tdt.flow_date%type;
tdtMatAmt			tdt.flow_amt%type;
gamTxn				number;
fflTxn				number;
numIIflows			number;
fdbal               number;
flag				varchar2(5);
emailFlg			varchar2(2);
dispMode1			varchar2(2);
nomffdflg			varchar2(2);
nomsumflg			varchar2(2);
opr_bal             varchar2(25);
emailFmt			number;
smtflg				number;
micrbankcode        VARCHAR2(9);
ifccode             VARCHAR2(12);
locsolid1           varchar2(8);
locsolid2	    varchar2(8);
nom_name        varchar2(40);

CURSOR	custCursor IS
SELECT	entity_id,home_sol_id
FROM	PSP_TMP
WHERE	listid = locListId
AND		home_sol_id = locSolId AND     BANK_ID = '&10';

cursor fdrec(fd_acid GAM.acid%TYPE,locToDate DATE) is select deposit_amount,t.acid from tam t,gam g where link_oper_account = fd_acid AND ((acct_cls_flg = 'N' AND acct_opn_date <= locToDate) OR (acct_cls_flg = 'Y' AND acct_cls_date > locToDate)) and t.acid=g.acid and g.acct_cls_flg='N' and del_flg='N';
 -- VD Starts Here for multicurrency stmts

CURSOR	acctCursor IS
SELECT	acid,
		foracid,
		decode(substr(foracid, 5, 2), 
		'01', '1',
		'02', '1',
		'05', '2',
		'06', '2',
		'10', '3',
		'12', '3',
		'14', '3',
		'15', '3',
		'16', '3',
		'18', '3',
		'24', '3',
		'25', '3',
		'40', '3',
		'51', '4',
		'52', '4',
		'53', '4',
		'55', '4',
		'60', '4',
		'5') subRecType,
		decode(substr(foracid, 5, 2), 
		'01', 'Savings',
		'02', 'Savings',
		'05', 'Current',
		'06', 'Current',
		'10', 'Deposit',
		'12', 'Deposit',
		'14', 'Deposit',
		'15', 'Deposit',
		'16', 'Deposit',
		'24', 'VR',
		'25', 'Deposit',
                '31', 'Deposit',
		'40', 'Deposit',
		'51', 'Advance',
		'52', 'Advance',
		'53', 'Advance',
		'55', 'Advance',
		'60', 'Advance',
		'Other') acctType,
		 acct_cls_flg ,
		 acct_cls_date ,
		 acct_crncy_code 
FROM	GAM 
WHERE	cust_id = locCustId
AND	((acct_cls_flg = 'N' AND acct_opn_date <= locToDate)
	OR		
	(acct_cls_flg = 'Y' AND acct_cls_date > locToDate))
AND	acct_crncy_code is not null
AND     ( (SCHM_CODE in ('RIDFC','REUSB','RGBSB','RUSSB')) OR (SCHM_TYPE = 'SBA')  OR (ACCT_PREFIX = '05') OR (ACCT_PREFIX = '51') OR (SCHM_TYPE = 'TDA') OR (SCHM_CODE in ('CFDFC', 'CFREU','CFRGB','CFRJY','CFRUS','RFDIS','RFEUD','RFEUH','RFEUH','RFGBH','RFJYD','RFUSD','RFUSH')) ) 
--Changes done for CR-138-38546
AND     ACCT_PREFIX != '18'
--end CR-138-38546
AND	del_flg != 'Y' 
AND	acct_ownership != 'O' 
AND	entity_cre_flg = 'Y';

-- VD ends Here



cursor tdtcur is
	select flow_code,flow_date,flow_amt,actual_int_pcnt,dep_period_mths,dep_period_days from tdt
	where acid = tdtAcid; 

BEGIN
	locRunId := '&1';
	locSolId := '&2';
	locIdType := '&4';
	locFrDate := '&5';
	locToDate := '&6';
	locCrncyCode := '&7';
	emailFlg     := '&8';
	dispMode1     := '&9';
	locListId := locRunId||locSolId||locIdType||'C';

	IF custCursor%ISOPEN THEN
		CLOSE custCursor;
	END IF;

	FOR custRec in custCursor 
	LOOP
	BEGIN
		locCustId := custRec.entity_id;
		IF acctCursor%ISOPEN THEN
			CLOSE acctCursor;
		END IF;
		emailFmt := 0;
		if ( emailFlg = 'R' ) then
			select stmt_reqd into stmtReqd from icici_cift where cif_id = locCustId;
		else
			if ( emailFlg = 'E') then
				stmtReqd := 'E';
		   	end if;
		end if;
		if ( stmtReqd = 'E' ) then
			emailFmt := 1;
		end if;
		FOR acctRec in acctCursor 
		LOOP
		BEGIN
			SELECT	tran_date_bal
			INTO	locTranDateBal
			FROM	EAB
			WHERE	acid = acctRec.acid
			AND		eod_date <= locToDate
			AND		end_eod_date >= locToDate;

			begin
			select sol_id into locsolid1 from gam where foracid = acctRec.foracid;
			EXCEPTION
			WHEN NO_DATA_FOUND THEN
			NULL;
			end;
			begin
			select MICR_CENTRE_CODE||MICR_BANK_CODE||MICR_BRANCH_CODE into micrbankcode from sol where sol_id = locsolid1;
			EXCEPTION
			WHEN NO_DATA_FOUND THEN
			NULL;
			end;

-- code for IFSC code starts

                        select ROUND(locsolid1) into locsolid2 from dual;

                        if( length(locsolid2) = 1 ) then
                                locsolid2 := '0'||locsolid2;
                        end if;


			begin
			Select BANK_IDENTIFIER into ifccode from BRBIC where branch_code = locsolid2 and PAYSYS_ID='GROSS' and bank_code='ICI' and rownum=1;
			EXCEPTION
			WHEN NO_DATA_FOUND THEN
			ifccode :='';
			end;

			locLinkedFlg := 'N';
			IF (acctRec.acctType = 'Deposit') THEN
				-- SELECT	decode(count(*), 0, 'N', 'Y')
				-- INTO	locLinkedFlg
				-- FROM	FFL
				-- WHERE	ffd_acid = acctRec.acid;

				SELECT  decode(link_oper_account,null, 'N', 'Y')
				INTO    locLinkedFlg
				FROM	TAM
				WHERE	acid = acctRec.acid;
				tdtAcid := acctRec.acid;
			end if;
			if (acctRec.acctType = 'Deposit' or acctRec.acctType = 'VR') then
				numIIflows := 0;
					if(acctRec.acctType = 'VR') then
						begin
					select INST_AMT,VALUE_DATE,MATURITY_DATE,RD_PERIOD_MNTHS,RD_VALUE,RATE_INT into tdtDeposit,tdtOpenDate,tdtMatDate,tdtDepMths,tdtMatAmt,tdtRate from ici_vrd where foracid = acctRec.foracid  and DEL_FLG = 'N' and ENTITY_CRE_FLG = 'Y';
					 exception
                        WHEN NO_DATA_FOUND THEN
                        NULL ;
                    end;
							 flag := 'N';
                    tdtOperAcid := null;				
					tdtDepDays := '0';
					begin 
						 select sum(tran_date_bal) into opr_bal from EAB where acid in  (select acid FROM GAM WHERE cust_id = locCustId AND  substr(foracid, 5, 2)  not  in ('10','12','14','15','16','25','31','40','18') AND  ((acct_cls_flg = 'N' AND acct_opn_date <= locToDate) OR (acct_cls_flg = 'Y' AND acct_cls_date > locToDate)) AND  ((crncy_code is null AND acct_crncy_code = acctRec.acct_crncy_code) OR (crncy_code is not null and crncy_code = acctRec.acct_crncy_code)) AND             del_flg != 'Y' AND             acct_ownership != 'O' AND             entity_cre_flg = 'Y' AND             ACCT_PREFIX != '18') AND             eod_date <= locToDate AND             end_eod_date >= locToDate;
						
					exception
						WHEN NO_DATA_FOUND THEN
						opr_bal := null;
					end;

					begin
						SELECT  tran_date_bal INTO    locTranDateBal FROM    EAB WHERE   acid = acctRec.acid AND     eod_date <= locToDate AND     end_eod_date >= locToDate;
					exception
						WHEN NO_DATA_FOUND THEN
						locTranDateBal := null;
					end;
					select NOM_AVAILABLE_FLG into nomffdflg from gam where foracid=acctRec.foracid;
		
							locOutRec := custRec.home_sol_id||'|'||custRec.entity_id||'|04|'||'0'||'|'||flag||'|'||tdtOperAcid||'??'||opr_bal||'|'||acctRec.foracid ||'|' ||acctRec.acct_crncy_code||'??'||locTranDateBal||'|'||tdtOpenDate||'|'||tdtDeposit||'|'||tdtRate||'|'||tdtDepMths||'|'|| tdtDepDays||'|'|| tdtMatAmt||'|'|| tdtMatDate ||'|'|| nomffdflg;
					end if;


					if(acctRec.acctType = 'Deposit') then
					begin
					select deposit_amount,open_effective_date,maturity_date,deposit_period_mths,deposit_period_days  into tdtDeposit,tdtOpenDate,tdtMatDate,tdtDepMths,tdtDepDays from tam where acid = acctRec.acid;
					EXCEPTION
						WHEN NO_DATA_FOUND THEN
						NULL ;
				end;
				
				for tdtRec in tdtCur
				loop
				begin
					if (tdtRec.flow_code = 'PI') then
						tdtDeposit := tdtRec.flow_amt;
						tdtOpenDate := tdtRec.flow_date;
						tdtDepMths := tdtRec.dep_period_mths;
						tdtDepDays := tdtRec.dep_period_days;
					end if;

					if (tdtRec.flow_code = 'II' or tdtRec.flow_code = 'IO') then
						tdtRate2 := tdtRate;
						tdtRate := tdtRec.actual_int_pcnt;
						numIIflows := numIIflows + 1;
					end if;

					if (tdtRec.flow_code = 'TO' or tdtRec.flow_code = 'PO') then
						tdtMatDate := tdtRec.flow_date;
						tdtMatAmt := tdtRec.flow_amt;
					end if;
				end;
				end loop;

				if ( locLinkedFlg = 'Y' ) THEN
					fflTxn := 1;
					begin
						--select acid into fflAcid from ffl where ffd_acid=tdtAcid and rownum = 1;
						select link_oper_account into fflAcid from TAM where acid=tdtAcid and rownum = 1;
						EXCEPTION
							WHEN NO_DATA_FOUND THEN
							fflTxn:=0;
					end;
					if ( fflTxn > 0 ) then
					begin
						select foracid into tdtOperAcid from gam where acid = fflAcid;
						EXCEPTION
							WHEN NO_DATA_FOUND THEN
							tdtOperAcid := '';
					end;
					else
						tdtOperAcid := '';
					end if;

					begin
						SELECT 1 INTO gamTxn FROM DUAL
                			WHERE EXISTS( SELECT  * FROM CTD
											WHERE   acid=tdtAcid
											AND     tran_date >= locFrDate
											AND     tran_date <= locToDate);
						EXCEPTION
							WHEN NO_DATA_FOUND THEN
							gamTxn := 0;
					end;

					if (gamTxn > 0) then
						flag := 'F';
					else 
						flag := 'B';
					end if ;
				else
					flag := 'N';
					tdtOperAcid := null;
				end if;

				if(tdtRate != tdtRate2) then
					if(numIIflows > 1) then
						tdtRate := tdtRate2;
					end if;
				end if;


--VD Starts Here For Multicurrency
--CR-138-38546
 select sum(tran_date_bal) into opr_bal from EAB where acid in  (select acid FROM GAM WHERE cust_id = locCustId
   			AND  substr(foracid, 5, 2)  not  in ('10','12','14','15','16','25','31','40','18')
--End
 
            AND  ((acct_cls_flg = 'N' AND acct_opn_date <= locToDate)
	        OR
			     (acct_cls_flg = 'Y' AND acct_cls_date > locToDate))
		    AND  ((crncy_code is null AND acct_crncy_code = acctRec.acct_crncy_code)
		    OR
		         (crncy_code is not null and crncy_code = acctRec.acct_crncy_code))
		    AND             del_flg != 'Y'
		    AND             acct_ownership != 'O'
		    AND             entity_cre_flg = 'Y'
			AND     		ACCT_PREFIX != '18')
		    AND             eod_date <= locToDate
		    AND             end_eod_date >= locToDate;

				
-- JD added for addition of nomination field 
-- VD Starts Here for multicurrency stmts (addition of Acct Currancy code)

				select NOM_AVAILABLE_FLG into nomffdflg from gam where foracid=acctRec.foracid;

                locOutRec := custRec.home_sol_id||'|'||custRec.entity_id||'|04|'
					     ||'0'||'|'||flag||'|'||tdtOperAcid||'??'||opr_bal||'|'||acctRec.foracid ||'|' ||
					     acctRec.acct_crncy_code||'??'||locTranDateBal||'|'||tdtOpenDate||'|'||tdtDeposit||'|'||tdtRate||'|'||
					     tdtDepMths||'|'|| tdtDepDays||'|'|| tdtMatAmt||'|'|| tdtMatDate ||'|'|| nomffdflg;
--				locOutRec := custRec.home_sol_id||'|'||custRec.entity_id||'|04|'
--						||'0'||'|'||flag||'|'||tdtOperAcid ||'|'||acctRec.foracid ||'|' ||
--						locTranDateBal||'|'||tdtOpenDate||'|'||tdtDeposit||'|'||tdtRate||'|'||
--						tdtDepMths||'|'|| tdtDepDays||'|'|| tdtMatAmt||'|'|| tdtMatDate ;
-- VD ends Here
--}
			end if;
			else
				smtflg := 0;
				begin
				
					select count(acid) into smtflg from smt where acid = acctRec.acid and acct_status = 'D';
				exception
					when others then
						smtflg := 0;
				end;

-- JD commented for addition of nomination field and one pipe at end
-- VD Starts Here for multicurrency stmts (addition of Acct Currancy code)
				select NOM_AVAILABLE_FLG into nomsumflg from gam where foracid=acctRec.foracid;
				fdbal:=0;
--				open fdrec(acctRec.acid);

                for tdtfd in fdrec(acctRec.acid,locToDate)
                loop
                begin
--				           locOutRec := 'beforefdbal|'||acctRec.acid||'|04|';
--						                DBMS_OUTPUT.PUT_LINE(locOutRec);

                        SELECT 1 INTO gamTxn FROM DUAL
                            WHERE EXISTS( SELECT  * FROM CTD
                                            WHERE   acid=tdtfd.acid
                                            AND     tran_date >= locFrDate
                                            AND     tran_date <= locToDate);
                        EXCEPTION
                            WHEN NO_DATA_FOUND THEN
                            gamTxn := 0;
                    end;
--					locOutRec := 'beforefdbal|'||gamTxn||'|04|';
--					                                        DBMS_OUTPUT.PUT_LINE(locOutRec);
                    if (gamTxn > 0) then
                        flag := 'F';
                    else
                        flag := 'B';
--                         locOutRec := 'beforefdbal|'||fdbal||'|04|';
--            DBMS_OUTPUT.PUT_LINE(locOutRec);
                        fdbal := fdbal+tdtfd.deposit_amount;

--                         locOutRec := 'afterfdbal|'||fdbal||'|04|';
--             DBMS_OUTPUT.PUT_LINE(locOutRec);
                    end if ;
                        end loop;

                locOutRec := custRec.home_sol_id||'|'||custRec.entity_id||'|02|'||
				            '2'||'|'||acctRec.foracid||'|'||acctRec.acct_crncy_code||'??'||locTranDateBal|| '|' ||
						     acctRec.acctType|| '|' || locLinkedFlg ||'|'|| smtflg ||'|'|| nomsumflg ||'|'|| micrbankcode ||'|'|| ifccode ||'| | | |'||fdbal;

--				locOutRec := custRec.home_sol_id||'|'||custRec.entity_id||'|02|'||	
--							acctRec.subRecType||'|'||acctRec.acctType||'|'||acctRec.foracid||'|'||
--							locTranDateBal|| '|' || locLinkedFlg ||'|'|| smtflg ||'| | | | | |';
-- VD ends Here
			END IF;
			DBMS_OUTPUT.PUT_LINE(locOutRec);
			if ( acctRec.acctType = 'Savings' ) THEN
			
			
--			begin
--			select NOM_NAME into nom_name from ant a, gam g, nom_name_prnt n where n.FORACID=g.foracid and a.acid=g.acid and NOM_PRINT_FLAG='Y' and n.foracid=acctRec.foracid;
--			 exception
--			 WHEN NO_DATA_FOUND THEN
			 nom_name := '';
--			 end;

			 
			 locOutRec := custRec.home_sol_id||'|'||custRec.entity_id||'|66|'||'2'||'|'||acctRec.foracid||'|'||acctRec.acctType||'|'|| micrbankcode ||'|'|| ifccode ||'|'||nom_name||' | | |||||';
			 DBMS_OUTPUT.PUT_LINE(locOutRec);
			end if;
			EXCEPTION
				WHEN NO_DATA_FOUND THEN 
				NULL;
		END;
		END LOOP;

		EXCEPTION
		WHEN OTHERS THEN
			DBMS_OUTPUT.PUT_LINE('<#ORA-ERROR#>');
			DBMS_OUTPUT.PUT_LINE('Cust Id '||locCustId);
			DBMS_OUTPUT.PUT_LINE('Check SQL error,  and try again');
			DBMS_OUTPUT.PUT_LINE('Sql Error Code is        : ' || SQLCODE );
			DBMS_OUTPUT.PUT_LINE('SQL Error Description is : '|| SQLERRM);
	END;	
	END LOOP;
END;
/
spool off
