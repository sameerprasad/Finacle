--===================================================================================================================
--	Filename	               : ServiceTaxReport.sql
--      Description		       : This sql script dumps Transaction details of account number given from the tables
--					 CXL, FAE, DTH & DTD, HTH & CTD, GCT
--      Date			       : 25.02.2009 
--      Author                         : Sanjay Kumar
--      Menu Option                    : ICISTC
--	Modification History           :
--	Sl. #            Date                Author             Modification                              
--	-----            -----              --------	       ----------------                               
--	1.              19/03/2012	    Ranjith	       	Included a new parameter(V_BANK_ID) for use in queries.
--	2.		28/01/2013	Shivraj Dhumal		Modifications done for the TOL 131488
--===================================================================================================================

Set serveroutput ON size 1000000
Set numformat 999999999990
set echo off
set feedback off
set termout off
set verify off
set trims on
set linesize 500
col tax_amt format 9999990
spool service_tax.lst

DECLARE
loc_solid 		GAM.SOL_ID%TYPE;
loc_acct_crncy_code	GAM.ACCT_CRNCY_CODE%TYPE;
v_acid 			GAM.ACID%TYPE;
V_FORACID		GAM.FORACID%TYPE;
sls_acid		GAM.ACID%TYPE;
V_CIF_ID		GAM.CIF_ID%TYPE;
V_GEN_DTLS		VARCHAR2 (30);
V_BANK_ID		VARCHAR2 (16);
V_FROM_DATE		DTD.TRAN_DATE%TYPE;
V_TO_DATE		DTD.TRAN_DATE%TYPE;
V_TRAN_AMT		DTD.TRAN_AMT%TYPE;
LOC_DATE_DIFF	NUMBER (10);
LOC_DB_STAT_DATE  GCT.DB_STAT_DATE%TYPE;
loc_acid          GAM.ACID%TYPE;
loc_bank_id	  VARCHAR2 (16);

-- Changes done for TOL 131488 Shivraj --
V_TRAN_DATE_DIFF	NUMBER(20);
V_TRAN_PARTICULAR	VARCHAR (50);
-- Changes done for TOL 131488 Shivraj --
------------------------------------------------------------------------------------------------------------------
-- CXL transactions are from GCHRG.
-- Assumptions :  Charge collected from customer account is the total of 
--               commission + service tax
------------------------------------------------------------------------------------------------------------------
	
	CURSOR CXL_MIS9 (loc_acid GAM.acid%Type,loc_bank_id VARCHAR2) is
		SELECT
			A.CHRG_TRAN_DATE,
			A.CHRG_TRAN_ID,
			TO_CHAR (-1 * (TO_DATE ('01-JAN-1900') - TO_DATE (A.CHRG_TRAN_DATE))) TRAN_DATE_DIFF,
			A.TRAN_PARTICULAR,
			sum(A.ACTUAL_AMT_COLL) TAX_AMT
			--A.ACTUAL_AMT_COLL TAX_AMT
		FROM CXL A
		WHERE A.TARGET_ACID = loc_acid
			AND A.ENTITY_CRE_FLG = 'Y'
			AND A.DEL_FLG != 'Y' 
			AND A.CHRG_TRAN_DATE >= V_FROM_DATE  
			AND A.CHRG_TRAN_DATE <= V_TO_DATE     
			AND A.SERVICE_SOL_ID in ( select sol_id  from sol where bank_id = loc_bank_id)
--			AND A.PTRAN_BUS_TYPE='MIS9'
			AND A.CHRG_ACID in (select acid from gam where bacid = 'SLSTAX' and bank_id = loc_bank_id  and ACCT_CRNCY_CODE = loc_acct_crncy_code)
			AND A.ACTUAL_AMT_COLL > 0
			AND A.BANK_ID = loc_bank_id
			--changes done by Shivraj for TOL 331488 - Begin 
			AND A.TRAN_PARTICULAR IS NOT NULL
			--changes done by Shivraj for TOL 331488 - Ends
		GROUP BY A.CHRG_TRAN_DATE,A.CHRG_TRAN_ID,A.TRAN_PARTICULAR;
------------------------------------------------------------------------------------------------------------------
-- TTUM upload for charges can be picked from dtd and htd.
-- Assumptions :  Charge debitted from customer account is the total of
--               commission + service tax
-- Calculation : Customer account debit amount is 100% commission + 10.2% service tax (total 110.2%)
--               Service tax is (tran_amt * 10.2 / 110.2) 
------------------------------------------------------------------------------------------------------------------
CURSOR DTH_SERTAX (loc_acid GAM.acid%Type,loc_bank_id VARCHAR2) is
	SELECT
		DISTINCT A.TRAN_DATE,
		TO_CHAR (-1 * (TO_DATE ('01-JAN-1900') - TO_DATE (A.TRAN_DATE))) TRAN_DATE_DIFF,
		A.TRAN_ID,
		B.TRAN_PARTICULAR,
		B.TRAN_AMT TOT_AMT,
		ROUND ((B.TRAN_AMT * 10.2/110.2), 0) TAX_AMT
	FROM DTH A, DTD B
	WHERE A.INIT_SOL_ID in ( select sol_id  from sol where bank_id = loc_bank_id)
	AND B.ACID = loc_acid
	AND B.PART_TRAN_TYPE = 'D'
	AND A.DEL_FLG != 'Y'
	AND B.DEL_FLG != 'Y'
	AND B.PSTD_FLG = 'Y'
	AND A.TRAN_ID = B.TRAN_ID
	AND A.TRAN_DATE >= V_FROM_DATE
	AND A.TRAN_DATE <= V_TO_DATE
	AND A.TRAN_DATE = B.TRAN_DATE
	AND A.TRAN_SUB_TYPE = 'SC' 
	AND A.REMARKS ='SERTAX'
	AND NOT EXISTS (SELECT
						ACID
					FROM
						DTD C
					WHERE
						C.TRAN_DATE = A.TRAN_DATE AND
						C.TRAN_ID = A.TRAN_ID AND
						C.ACID  in ( select acid from gam where bacid = 'SLSTAX'  and ACCT_CRNCY_CODE = loc_acct_crncy_code and bank_id = loc_bank_id) AND
						C.DEL_FLG != 'Y' AND
						C.PSTD_FLG = 'Y')
	AND A.BANK_ID = B.BANK_ID 
	AND A.BANK_ID = loc_bank_id 
	ORDER BY A.TRAN_DATE;

CURSOR HTH_SERTAX (loc_acid GAM.acid%Type,loc_bank_id VARCHAR2) is
	SELECT
		DISTINCT A.TRAN_DATE,
		TO_CHAR (-1 * (TO_DATE ('01-JAN-1900') - TO_DATE (A.TRAN_DATE))) TRAN_DATE_DIFF,
		A.TRAN_ID,
		B.TRAN_PARTICULAR,
		B.TRAN_AMT TOT_AMT,
		ROUND ((B.TRAN_AMT * 10.2/110.2), 0) TAX_AMT
	FROM HTH A, HTD B
	WHERE A.INIT_SOL_ID in ( select sol_id  from sol where bank_id = loc_bank_id)
	AND B.ACID = loc_acid
	AND B.PART_TRAN_TYPE = 'D'
	AND A.DEL_FLG != 'Y'
	AND B.DEL_FLG != 'Y'
	AND B.PSTD_FLG = 'Y'
	AND A.TRAN_ID = B.TRAN_ID
	AND A.TRAN_DATE >= V_FROM_DATE
	AND A.TRAN_DATE <= V_TO_DATE
	AND A.TRAN_DATE = B.TRAN_DATE
	AND A.TRAN_SUB_TYPE = 'SC'
	AND A.REMARKS ='SERTAX'
	AND NOT EXISTS (SELECT
						ACID
					FROM
						DTD C
					WHERE
						C.TRAN_DATE = A.TRAN_DATE AND
						C.TRAN_ID = A.TRAN_ID AND
						C.ACID  in ( select acid from gam where bacid = 'SLSTAX'  and ACCT_CRNCY_CODE = loc_acct_crncy_code and bank_id = loc_bank_id) AND
						C.DEL_FLG != 'Y' AND
						C.PSTD_FLG = 'Y')
	AND A.BANK_ID = B.BANK_ID 
	AND A.BANK_ID = loc_bank_id 
	ORDER BY A.TRAN_DATE;	

------------------------------------------------------------------------------------------------------------------
-- Foreign bill charge collection goes into FAE table.
-- Assumptions :  Charge debitted from customer account is the total of
--               commission + service tax
-- Calculation : Customer account debit amount is 100% commission + 10.2% service tax (total 110.2%)
--               Service tax is (tran_amt * 10.2 / 110.2) 
------------------------------------------------------------------------------------------------------------------
CURSOR FAE_SERTAX (loc_acid GAM.acid%Type,loc_bank_id VARCHAR2) is 
	SELECT
        DISTINCT TRAN_DATE,
        TRAN_ID,
		sum(TRAN_AMT) TOT_AMT
    FROM FAE
    WHERE ACID = loc_acid
    AND SOL_ID in ( select sol_id  from sol where bank_id = loc_bank_id)
    AND TRAN_DATE >= V_FROM_DATE
    AND TRAN_DATE <= V_TO_DATE
    AND PART_TRAN_TYPE = 'D'
    AND DEL_FLG != 'Y'
    AND BANK_ID = loc_bank_id 
	group by tran_id,tran_date
    ORDER BY TRAN_DATE;

CURSOR DCTD_ACLI_SERTAX (loc_tranID DTD.tran_id%TYPE, loc_tran_date DTD.tran_date%TYPE,loc_bank_id VARCHAR2) is
	SELECT
		DISTINCT TRAN_DATE,
		TRAN_ID,
		TO_CHAR (-1 * (TO_DATE ('01-JAN-1900') - TO_DATE (TRAN_DATE))) TRAN_DATE_DIFF,
		TRAN_PARTICULAR,
		TRAN_AMT TAX_AMT 
	FROM DCTD_ACLI
	WHERE SOL_ID in ( select sol_id  from sol where bank_id = loc_bank_id)
	AND TRAN_ID = loc_tranID
	AND TRAN_DATE = loc_tran_date
	AND PART_TRAN_TYPE = 'C'    
	AND PSTD_FLG = 'Y'
	AND DEL_FLG != 'Y'
	and not exists (select 'x' from cxl where cxl.CHRG_TRAN_DATE = DCTD_ACLI.TRAN_DATE
	                        and cxl.CHRG_TRAN_ID = DCTD_ACLI.TRAN_ID
	                        and cxl.CHRG_PART_TRAN_SRL_NUM = DCTD_ACLI.PART_TRAN_SRL_NUM and bank_id = loc_bank_id)
	AND ACID in (SELECT ACID FROM GAM WHERE BACID = 'SLSTAX'  and ACCT_CRNCY_CODE = loc_acct_crncy_code and bank_id = loc_bank_id) 
	AND BANK_ID = loc_bank_id; 
							

------------------------------------------------------------------------------------------------------------------
-- Reversal for service tax is done through TTUM upload.  The amount is credited into customer account.
-- Assumptions :  Charge credited to customer account is the total of
--               commission + service tax
-- Calculation : Customer account debit amount is 100% commission + 10.2% service tax (total 110.2%)
--               Service tax is (tran_amt * 10.2 / 110.2) 
------------------------------------------------------------------------------------------------------------------
CURSOR DTH_REV_SERTAX (loc_acid GAM.acid%Type,loc_bank_id VARCHAR2) is
	SELECT
		DISTINCT A.TRAN_DATE,
--		A.TRAN_DATE,
		TO_CHAR (-1 * (TO_DATE ('01-JAN-1900') - TO_DATE (A.TRAN_DATE))) TRAN_DATE_DIFF,
		A.TRAN_ID,
		B.TRAN_PARTICULAR,
		(-1 * B.TRAN_AMT) TOT_AMT,
		ROUND ((-1 * (B.TRAN_AMT * 10.2 / 110.2)), 0) TAX_AMT
	FROM DTH A, DTD B, DTD C, DTD D
	WHERE A.INIT_SOL_ID in ( select sol_id  from sol where bank_id = loc_bank_id)
	AND B.ACID = loc_acid
	AND C.ACID in ( select acid from gam where bacid = 'SLSTAX' and ACCT_CRNCY_CODE = loc_acct_crncy_code and bank_id = loc_bank_id)
	AND (D.GL_SUB_HEAD_CODE IN ('40030', '40020') OR
	     D.ACID IN (SELECT ACID FROM GAM WHERE BACID = 'CHWAIVER' and ACCT_CRNCY_CODE = loc_acct_crncy_code and bank_id = loc_bank_id))
	AND B.PART_TRAN_TYPE = 'C'
	AND C.PART_TRAN_TYPE = 'D'
	AND D.PART_TRAN_TYPE = 'D'
	AND A.DEL_FLG != 'Y'
	AND B.DEL_FLG != 'Y'
	AND C.DEL_FLG != 'Y'
	AND D.DEL_FLG != 'Y'
	AND B.PSTD_FLG = 'Y'
	AND C.PSTD_FLG = 'Y'
	AND D.PSTD_FLG = 'Y'
	AND A.TRAN_ID = B.TRAN_ID
	AND C.TRAN_ID = B.TRAN_ID
	AND D.TRAN_ID = B.TRAN_ID
	AND A.TRAN_DATE >= V_FROM_DATE
	AND A.TRAN_DATE <= V_TO_DATE
	AND A.TRAN_DATE = B.TRAN_DATE
	AND C.TRAN_DATE = B.TRAN_DATE
	AND D.TRAN_DATE = B.TRAN_DATE
	AND A.BANK_ID = B.BANK_ID 
	AND A.BANK_ID = loc_bank_id 
	ORDER BY A.TRAN_DATE;

CURSOR HTH_REV_SERTAX (loc_acid GAM.acid%Type,loc_bank_id VARCHAR2) is
	SELECT
		DISTINCT A.TRAN_DATE,
--		A.TRAN_DATE,
		TO_CHAR (-1 * (TO_DATE ('01-JAN-1900') - TO_DATE (A.TRAN_DATE))) TRAN_DATE_DIFF,
		A.TRAN_ID,
		B.TRAN_PARTICULAR,
		(-1 * B.TRAN_AMT) TOT_AMT,
		ROUND ((-1 * (B.TRAN_AMT * 10.2 / 110.2)), 0) TAX_AMT
	FROM HTH A, HTD B, HTD C, HTD D
	WHERE A.INIT_SOL_ID in ( select sol_id  from sol where bank_id = loc_bank_id)
	AND B.ACID = loc_acid
	AND C.ACID in ( select acid from gam where bacid = 'SLSTAX'  and ACCT_CRNCY_CODE = loc_acct_crncy_code and bank_id = loc_bank_id)
	AND (D.GL_SUB_HEAD_CODE IN ('40030', '40020') OR
	     D.ACID IN (SELECT ACID FROM GAM WHERE BACID = 'CHWAIVER'  and ACCT_CRNCY_CODE = loc_acct_crncy_code and bank_id = loc_bank_id))
	AND B.PART_TRAN_TYPE = 'C'
	AND C.PART_TRAN_TYPE = 'D'
	AND D.PART_TRAN_TYPE = 'D'
	AND A.DEL_FLG != 'Y'
	AND B.DEL_FLG != 'Y'
	AND C.DEL_FLG != 'Y'
	AND D.DEL_FLG != 'Y'
	AND B.PSTD_FLG = 'Y'
	AND C.PSTD_FLG = 'Y'
	AND D.PSTD_FLG = 'Y'
	AND A.TRAN_ID = B.TRAN_ID
	AND C.TRAN_ID = B.TRAN_ID
	AND D.TRAN_ID = B.TRAN_ID
	AND A.TRAN_DATE >= V_FROM_DATE
	AND A.TRAN_DATE <= V_TO_DATE
	AND A.TRAN_DATE = B.TRAN_DATE
	AND C.TRAN_DATE = B.TRAN_DATE
	AND D.TRAN_DATE = B.TRAN_DATE
	AND A.BANK_ID = B.BANK_ID 
	AND A.BANK_ID = loc_bank_id 
	ORDER BY A.TRAN_DATE;

------------------------------------------------------------------------------------------------------------------
-- Credit to SLSTAX account. Transaction involving only two accounts viz customer account and SLSTAX account.
-- Tables         : HTD, GAM
-- Assumption     : None
-- Calaculation   : None
------------------------------------------------------------------------------------------------------------------
CURSOR HTD_SERTAX (loc_acid GAM.acid%Type,loc_bank_id VARCHAR2) is
SELECT
   ACID,
	TRAN_DATE,
	TO_CHAR (-1 * (TO_DATE ('01-JAN-1900') - TO_DATE (TRAN_DATE))) TRAN_DATE_DIFF,
	TRAN_ID,
	PART_TRAN_TYPE,
	TRAN_PARTICULAR,
	TRAN_AMT TOT_AMT,
	TRAN_AMT TAX_AMT
FROM  HTD A
WHERE ACID = LOC_ACID
	AND TRAN_TYPE = 'T'
	AND PSTD_FLG = 'Y'
	AND DEL_FLG != 'Y'
	AND TRAN_DATE >= V_FROM_DATE
	AND TRAN_DATE <= V_TO_DATE
	AND 'SLSTAX' IN
		( SELECT BACID FROM GAM WHERE ACID IN
		   (  SELECT  ACID FROM HTD B
		      WHERE B.TRAN_DATE = A.TRAN_DATE
			  AND B.TRAN_ID = A.TRAN_ID
			  AND B.TRAN_TYPE = 'T'
		      AND B.PART_TRAN_TYPE = 'C'
			  AND B.SOL_ID = A.SOL_ID and bank_id = loc_bank_id))
	AND  2 = (  SELECT COUNT(DISTINCT ACID) FROM HTD C WHERE A.TRAN_ID = C.TRAN_ID
               AND A.TRAN_dATE = C.TRAN_DATE and bank_id = loc_bank_id)
	AND A.BANK_ID = loc_bank_id 
ORDER BY TRAN_DATE;
------------------------------------------------------------------------------------------------------------------
-- Credit to SLSTAX account. Transaction involving only two accounts viz customer account and SLSTAX account.
-- Tables         : DTD, GAM (This cursor is used only when upto date is same as DB_STAT_DATE
-- Assumption     : None
-- Calaculation   : None
------------------------------------------------------------------------------------------------------------------
CURSOR DTD_SERTAX (loc_acid GAM.acid%Type,loc_bank_id VARCHAR2) is
SELECT
ACID,
   TRAN_DATE,
	TO_CHAR (-1 * (TO_DATE ('01-JAN-1900') - TO_DATE (TRAN_DATE))) TRAN_DATE_DIFF,
	TRAN_ID,
	PART_TRAN_TYPE,
	TRAN_PARTICULAR,
	TRAN_AMT TOT_AMT,
	TRAN_AMT TAX_AMT
FROM
	   DTD A
WHERE  ACID = loc_acid
	AND TRAN_TYPE = 'T'
	AND PSTD_FLG = 'Y'
	AND DEL_FLG != 'Y'
	AND TRAN_DATE >= V_FROM_DATE
	AND TRAN_DATE <= V_TO_DATE
	AND 'SLSTAX' IN
		( SELECT BACID FROM GAM WHERE ACID IN
        ( SELECT  ACID FROM DTD B
          WHERE B.TRAN_DATE = A.TRAN_DATE
		  AND B.TRAN_ID = A.TRAN_ID
		  AND B.TRAN_TYPE = 'T' 
          AND B.PART_TRAN_TYPE = 'C'
		  AND B.SOL_ID = A.SOL_ID and bank_id = loc_bank_id))
  AND  2 = ( SELECT COUNT(DISTINCT ACID) FROM DTD C WHERE A.TRAN_ID = C.TRAN_ID
            AND A.TRAN_DATE = C.TRAN_DATE and bank_id = loc_bank_id)
AND A.BANK_ID = loc_bank_id 
ORDER BY TRAN_DATE;

------------------------------------------------------------------------------------------------------------------
-- Credit to SLSTAX account through SI for LC/BG commission. Transaction involving two or more accounts one of which is SLSTAX account.
-- Tables         : DTD, GAM (This cursor is used only when upto date is same as DB_STAT_DATE
-- Assumption     : None
-- Calaculation   : None
-- ICR            : ICI7197
------------------------------------------------------------------------------------------------------------------
CURSOR DTD_SERTAX_1 (loc_acid GAM.acid%Type,loc_bank_id VARCHAR2) is
SELECT
A.ACID,
   A.TRAN_DATE,
        TO_CHAR (-1 * (TO_DATE ('01-JAN-1900') - TO_DATE (A.TRAN_DATE))) TRAN_DATE_DIFF,
        A.TRAN_ID,
        A.PART_TRAN_TYPE,
        A.TRAN_PARTICULAR,
        A.TRAN_AMT TOT_AMT,
        B.TRAN_AMT TAX_AMT
FROM
           DTD A, DTD B, GAM G
WHERE  A.ACID = loc_acid
        AND A.TRAN_TYPE = 'T'
        AND A.PSTD_FLG = 'Y'
        AND A.DEL_FLG != 'Y'
        AND A.TRAN_DATE >= V_FROM_DATE
        AND A.TRAN_DATE <= V_TO_DATE
	AND G.BACID = 'SLSTAX' 
	AND G.ACID = B.ACID 
	AND A.TRAN_SUB_TYPE = 'SI' 
	AND B.TRAN_ID = A.TRAN_ID 
	AND B.TRAN_DATE = A.TRAN_DATE
	AND A.PART_TRAN_TYPE = 'D'
	AND B.PART_TRAN_TYPE = 'C'
	AND B.PSTD_FLG = 'Y'
	AND B.DEL_FLG !='Y'
	AND B.BANK_ID = G.BANK_ID 
	AND B.BANK_ID = loc_bank_id 
ORDER BY TRAN_DATE;

------------------------------------------------------------------------------------------------------------------
-- Credit to SLSTAX account through SI for LC/BG commission. Transaction involving two or more accounts one of which is SLSTAX account.
-- Tables         : HTD, GAM (This cursor is used only when upto date is same as DB_STAT_DATE
-- Assumption     : None
-- Calaculation   : None
-- ICR            : ICI7197
------------------------------------------------------------------------------------------------------------------
CURSOR HTD_SERTAX_1 (loc_acid GAM.acid%Type,loc_bank_id VARCHAR2) is
SELECT
A.ACID,
   A.TRAN_DATE,
        TO_CHAR (-1 * (TO_DATE ('01-JAN-1900') - TO_DATE (A.TRAN_DATE))) TRAN_DATE_DIFF,
        A.TRAN_ID,
        A.PART_TRAN_TYPE,
        A.TRAN_PARTICULAR,
        A.TRAN_AMT TOT_AMT,
        B.TRAN_AMT TAX_AMT
FROM
           HTD A, HTD B, GAM G
WHERE  A.ACID = loc_acid
        AND A.TRAN_TYPE = 'T'
        AND A.PSTD_FLG = 'Y'
        AND A.DEL_FLG != 'Y'
        AND A.TRAN_DATE >= V_FROM_DATE
        AND A.TRAN_DATE <= V_TO_DATE
        AND G.BACID = 'SLSTAX'
        AND G.ACID = B.ACID
        AND A.TRAN_SUB_TYPE = 'SI'
        AND B.TRAN_ID = A.TRAN_ID
        AND B.TRAN_DATE = A.TRAN_DATE
        AND A.PART_TRAN_TYPE = 'D'
        AND B.PART_TRAN_TYPE = 'C'
        AND B.PSTD_FLG = 'Y'
        AND B.DEL_FLG !='Y'
	AND B.BANK_ID = G.BANK_ID 
	AND B.BANK_ID = loc_bank_id 
ORDER BY TRAN_DATE;


----------------------------------------------------------------------------------------------------------------
--END OF DECLARATION PART
----------------------------------------------------------------------------------------------------------------

        function gettax_amt (chrg_amt in number , chrg_date in date, loc_bank_id in varchar2) return number is
        l_tax_amt                number:=0;
        l_tax_rate              number:=0;
        begin
              --  if (chrg_date < '25-02-2009' ) then
		if (chrg_date < '25-FEB-2009' ) then
                        l_tax_rate:=12.36;
                else
				BEGIN
                        select PCNT_AMT into l_tax_rate from ATC where amt_tbl_code='SRTAX'
                        and bank_id=loc_bank_id and chrg_amt between START_AMT and END_AMT    ;
				EXCEPTION                
				WHEN NO_DATA_FOUND Then  
				l_tax_rate:=0;           
				end;                     
                end if;
                        l_tax_amt:=round((chrg_amt*l_tax_rate )/(l_tax_rate+100));
                return l_tax_amt;
        end gettax_amt;

BEGIN
--{    
	V_FORACID := TRIM ('&1');
	V_FROM_DATE := TRIM ('&2');
	V_TO_DATE := TRIM ('&3');
	V_BANK_ID := TRIM('&4');
	--V_TRAN_DATE_HC := '05-07-2012';

	IF (V_FROM_DATE <= V_TO_DATE) THEN
	--{
		select sol_id, acid, CIF_ID, ACCT_CRNCY_CODE into loc_solid, v_acid, V_CIF_ID, loc_acct_crncy_code from gam where foracid = V_FORACID and bank_id = V_BANK_ID;
		
		select acid into sls_acid from gam where bacid = 'SLSTAX' and sol_id = loc_solid and bank_id = V_BANK_ID and ACCT_CRNCY_CODE = loc_acct_crncy_code;  

		select db_stat_date into LOC_DB_STAT_DATE from gct where bank_id=V_BANK_ID;

		V_GEN_DTLS := V_FORACID || '|' || V_CIF_ID;

		FOR C1 in CXL_MIS9(v_acid,V_BANK_ID) 
		Loop
		--{
			SELECT SUM (DECODE (PART_TRAN_TYPE, 'D', 1, 1) * TRAN_AMT) INTO V_TRAN_AMT FROM
			   (
				select PART_TRAN_TYPE, TRAN_AMT from HTD
				WHERE TRAN_ID = C1.CHRG_TRAN_ID
				AND TRAN_DATE = C1.CHRG_TRAN_DATE
				AND ACID = v_acid
				AND BANK_ID = V_BANK_ID 
				union all
				select PART_TRAN_TYPE, TRAN_AMT from DTD	
				WHERE TRAN_ID = C1.CHRG_TRAN_ID
				AND TRAN_DATE = C1.CHRG_TRAN_DATE 
				AND BANK_ID = V_BANK_ID 
                		AND ACID = v_acid
				);
			
			if V_TRAN_AMT is not null then
			DBMS_OUTPUT.PUT_LINE (V_GEN_DTLS||'|'||
								  C1.CHRG_TRAN_ID||'|'||
								  C1.CHRG_TRAN_DATE||'|'||
								  C1.TRAN_DATE_DIFF||'|'||
								  C1.TRAN_PARTICULAR||'|'||
								  V_TRAN_AMT||'|'||
								  C1.TAX_AMT);
			end if;
		--} End C1
		End Loop;
		--DBMS_OUTPUT.PUT_LINE ('END OF CXL');


		FOR C2 in DTH_SERTAX(v_acid,V_BANK_ID) 
		Loop
		--{
			C2.TAX_AMT:=gettax_amt(C2.TOT_AMT,C2.TRAN_DATE,V_BANK_ID);

			DBMS_OUTPUT.PUT_LINE (V_GEN_DTLS||'|'||
								  C2.TRAN_ID||'|'||
								  C2.TRAN_DATE||'|'||
								  C2.TRAN_DATE_DIFF||'|'||
								  C2.TRAN_PARTICULAR||'|'||
								  C2.TOT_AMT||'|'||
								  C2.TAX_AMT);
		--} End C2
		End Loop;
		--DBMS_OUTPUT.PUT_LINE ('END OF DTH');

		FOR C3 in HTH_SERTAX(v_acid,V_BANK_ID) 
		Loop
		--{
			C3.TAX_AMT:=gettax_amt(C3.TOT_AMT,C3.TRAN_DATE,V_BANK_ID);
			DBMS_OUTPUT.PUT_LINE (V_GEN_DTLS||'|'||
								  C3.TRAN_ID||'|'||
								  C3.TRAN_DATE||'|'||
								  C3.TRAN_DATE_DIFF||'|'||
								  C3.TRAN_PARTICULAR||'|'||
								  C3.TOT_AMT||'|'||
								  C3.TAX_AMT);
		--} End C3
		End Loop;
		--DBMS_OUTPUT.PUT_LINE ('END OF HTH');

--		FOR C4 in CR_TO_SLTAX(v_acid)
--		Loop
--		--{
--			DBMS_OUTPUT.PUT_LINE (V_GEN_DTLS||'|'||
--								  C4.TRAN_ID||'|'||
--								  C4.TRAN_DATE||'|'||
--								  C4.TRAN_DATE_DIFF||'|'||
--								  C4.TRAN_PARTICULAR||'|'||
--								  C4.TOT_AMT||'|'||
--								  C4.TAX_AMT);
--		--} End C4
--		End Loop;
		--DBMS_OUTPUT.PUT_LINE ('END OF TTUM REV');

		FOR C5 in FAE_SERTAX (v_acid,V_BANK_ID)
		Loop
		--{
			FOR C8 in DCTD_ACLI_SERTAX (C5.TRAN_ID, C5.TRAN_DATE,V_BANK_ID)
			Loop
			--{
				
				DBMS_OUTPUT.PUT_LINE (V_GEN_DTLS||'|'||
									  C8.TRAN_ID||'|'||
									  C8.TRAN_DATE||'|'||
									  C8.TRAN_DATE_DIFF||'|'||
									  C8.TRAN_PARTICULAR||'|'||
									  C5.TOT_AMT||'|'||
									  C8.TAX_AMT);
			--}
			End Loop;
		--}
		End Loop;
		--DBMS_OUTPUT.PUT_LINE ('END OF FAE');

		FOR C6 in DTH_REV_SERTAX(v_acid,V_BANK_ID) 
		Loop
		--{
			C6.TAX_AMT:= -1 * gettax_amt(-1*C6.TOT_AMT,C6.TRAN_DATE,V_BANK_ID);
			DBMS_OUTPUT.PUT_LINE (V_GEN_DTLS||'|'||
								  C6.TRAN_ID||'|'||
								  C6.TRAN_DATE||'|'||
								  C6.TRAN_DATE_DIFF||'|'||
								  C6.TRAN_PARTICULAR||'|'||
								  C6.TOT_AMT||'|'||
								  C6.TAX_AMT);
		--} End C6
		End Loop;
		--DBMS_OUTPUT.PUT_LINE ('END OF DTH REVERSAL');

		FOR C7 in HTH_REV_SERTAX(v_acid,V_BANK_ID) 
		Loop
		--{
			C7.TAX_AMT:= -1 * gettax_amt(-1*C7.TOT_AMT,C7.TRAN_DATE,V_BANK_ID);
			DBMS_OUTPUT.PUT_LINE (V_GEN_DTLS||'|'||
								  C7.TRAN_ID||'|'||
								  C7.TRAN_DATE||'|'||
								  C7.TRAN_DATE_DIFF||'|'||
								  C7.TRAN_PARTICULAR||'|'||
								  C7.TOT_AMT||'|'||
								  C7.TAX_AMT);
		--} End C7
		End Loop;
		--DBMS_OUTPUT.PUT_LINE ('END OF DTH REVERSAL');

		FOR C8 in HTD_SERTAX(v_acid,V_BANK_ID)
		loop
		--{ 

			DBMS_OUTPUT.PUT_LINE (V_GEN_DTLS||'|'||
									C8.TRAN_ID||'|'||
									C8.TRAN_DATE||'|'||
									C8.TRAN_DATE_DIFF||'|'||  
									C8.TRAN_PARTICULAR||'|'||  
									C8.TOT_AMT||'|'||  
									C8.TAX_AMT); 
		--} End C8 
		End Loop;  
		--DBMS_OUTPUT.PUT_LINE ('END OF HTD SERVICE TAX INVLOVING ONLY 2 ACCOUNTS');

		--Records need tobe selected from DTD if and only if TO_DATE is todays's BOD date 
		
		IF ( V_TO_DATE >= LOC_DB_STAT_DATE ) THEN 
		--{  
			FOR C9 in DTD_SERTAX(v_acid,V_BANK_ID)   
			loop 
			--{    
				
				DBMS_OUTPUT.PUT_LINE (V_GEN_DTLS||'|'||    
									C9.TRAN_ID||'|'||
									C9.TRAN_DATE||'|'|| 
									C9.TRAN_DATE_DIFF||'|'||    
									C9.TRAN_PARTICULAR||'|'||        
									C9.TOT_AMT||'|'|| 
									C9.TAX_AMT);
			--} End C9   
			End Loop;  
			--DBMS_OUTPUT.PUT_LINE ('END OF DTD SERVICE TAX INVLOVING ONLY 2 ACCOUNTS') ; 
		--}   
		END IF; 
		
		FOR C10 IN DTD_SERTAX_1(v_acid,V_BANK_ID)
		loop
		--{
			DBMS_OUTPUT.PUT_LINE (V_GEN_DTLS||'|'||
                                                                        C10.TRAN_ID||'|'||
                                                                        C10.TRAN_DATE||'|'||
                                                                        C10.TRAN_DATE_DIFF||'|'||
                                                                        C10.TRAN_PARTICULAR||'|'||
                                                                        C10.TOT_AMT||'|'||
                                                                        C10.TAX_AMT);
                --} End C10
                End Loop;
		--DBMS_OUTPUT.PUT_LINE ('END OF DTD SERVICE TAX THROUGH SI')

		FOR C11 IN HTD_SERTAX_1(v_acid,V_BANK_ID)
                loop
                --{
                        DBMS_OUTPUT.PUT_LINE (V_GEN_DTLS||'|'||
                                                                        C11.TRAN_ID||'|'||
                                                                        C11.TRAN_DATE||'|'||
                                                                        C11.TRAN_DATE_DIFF||'|'||
                                                                        C11.TRAN_PARTICULAR||'|'||
                                                                        C11.TOT_AMT||'|'||
                                                                        C11.TAX_AMT);
                --} End C11
                End Loop;
                --DBMS_OUTPUT.PUT_LINE ('END OF HTD SERVICE TAX THROUGH SI')

	--}
	END IF;
--}
EXCEPTION
--{
	WHEN NO_DATA_FOUND Then NULL;
--}
END;
/
spool off
set serveroutput off
set echo on
set verify on
