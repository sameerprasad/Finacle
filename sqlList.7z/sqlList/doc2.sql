set heading off
SET verify off
set feedback off
set line 300
set trims on
set serveroutput on SIZE 1000000
spool &1.fd_doc2.lst

DECLARE

l_month                 VARCHAR(4);
l_closuredate   VARCHAR(10);
l_recCount          NUMBER;
l_fromDate       VARCHAR2(15) := to_date('01-'||'&1');
l_bank_id       VARCHAR2(8) := '&2';

CURSOR C1 is
SELECT  distinct GAM.acid tdacid, GAM.foracid tdforacid , clr_bal_amt , acct_cls_date
FROM GAM,TPH
WHERE GAM.acid = TPH.acid
AND GAM.schm_code IN ('CFDOC')
AND GAM.acct_cls_date is NULL
AND TPH.part_close_date >=  l_fromDate
AND TPH.part_close_date < (SELECT add_months(l_fromDate,1) from dual)
AND GAM.del_flg!='Y'
AND GAM.entity_cre_flg='Y'
AND GAM.acct_cls_flg='N'
AND GAM.bank_id = l_bank_id
AND TPH.bank_id = l_bank_id
UNION
SELECT  GAM.acid tdacid, GAM.foracid tdforacid , clr_bal_amt , acct_cls_date
FROM GAM
WHERE GAM.schm_code IN ('CFDOC')
AND GAM.acct_cls_date is NOT NULL
AND acct_cls_date >= l_fromDate
AND acct_cls_date < ( SELECT add_months(l_fromDate,1) from dual )
AND GAM.del_flg!='Y'
AND GAM.entity_cre_flg='Y'
AND GAM.acct_cls_flg='Y'
AND GAM.bank_id = l_bank_id;


BEGIN

--dbms_output.put_line(l_fromDate);
        For rec in C1
        LOOP --{

                l_recCount:=0;

                SELECT count(1) into l_recCount
                FROM TPH
                WHERE acid = rec.tdacid
                AND part_close_date < l_fromDate
        AND TPH.bank_id = l_bank_id;
--              AND del_flg <> 'Y' ;

                IF (l_recCount = 0 ) THEN

                        IF rec.acct_cls_date is null THEN
                                SELECT max(part_close_date) into l_closuredate
                                FROM TPH
                                WHERE acid = rec.tdacid
                                AND part_close_date >=  l_fromDate 
                AND TPH.bank_id = l_bank_id
                                AND part_close_date < (SELECT add_months(l_fromDate,1) from dual);
                        ELSE
                                l_closuredate := rec.acct_cls_date;
                        END IF;

                        dbms_output.put_line(
                                                rec.tdforacid                   ||'|'||
                                                l_closuredate                   ||'|'||
                                                rec.clr_bal_amt
                                                );
                END IF;
        END LOOP; --}
        NULL;

END;
/
spool off

