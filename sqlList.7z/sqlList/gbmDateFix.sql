==============================================================================
-- File Name: gbmDateFix.sql
-- Description: spooling gbmDate
-- Start Date: 17-Oct-2012 
-- Author: Ashutosh K Pandey
-- Modification History  :
-- Sl #      Date          Author Name            Description
-- ----  --------   -----------------         --------------
--  1    18-Oct-2012   Ashutosh K Pandey	Original Version
===============================================================================

set head off
set echo off
set trims on
set pagesize 1000
spool gbmDate
select to_char(to_date(sysdate,'DD-MM-YYYY')) FROM dual;
spool off

