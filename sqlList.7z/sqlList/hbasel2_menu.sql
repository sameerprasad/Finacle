set define off; 
variable mopNum varchar2(5); 
begin 
select nvl(to_char(max(to_number(mop_num))+1), '1') into :mopNum from tbaadm.mno where menu_id = 'CUSTVAL'; 
exception when no_data_found then 
	:mopNum := 1; 
end; 
/ 
drop table tbaadm.tmp_mod 
/ 
create table tbaadm.tmp_mod as  
	(select * from tbaadm.mod  
	where mop_id = 'HACM' and bank_id ='BM3') 
/ 
update tbaadm.tmp_mod  
	set MOP_ID = 'HBASEL2', 
	MOP_TYPE = 'U', 
	EXE_NAME='https://$W/finbranch',  
	INPUT_FILENAME = 'Customize/Customize_ctrl.jsp?sessionid=$S', ADDITIONAL_PARAMS='&HBASEL2=$THBASEL2=$SHBASEL2=$CHBASEL2=$' 
/ 
commit 
/ 
delete from tbaadm.mod where MOP_ID='HBASEL2' 
/ 
insert into tbaadm.mod select * from tbaadm.tmp_mod 
/ 
commit 
/ 
drop table tbaadm.tmp_mod 
/ 
create table tbaadm.tmp_mod as  
	(select * from tbaadm.mod_txt  
	where MOP_ID = 'HACM' and bank_id ='BM3') 
/ 
update tbaadm.tmp_mod  
	set MOP_ID = 'HBASEL2' ,  
	USER_MOP_ID = 'HBASEL2',  
	MOP_TEXT = 'PAYMENT OF MATURITY PROCEEDS' 
/ 
commit 
/ 
delete from tbaadm.mod_txt where MOP_ID='HBASEL2' 
/ 
insert into tbaadm.mod_txt select * from tbaadm.tmp_mod 
/ 
commit 
/ 
drop table tbaadm.tmp_mod 
/ 
delete from tbaadm.oat where MOP_ID='HBASEL2' 
/ 
insert into tbaadm.oat values('HBASEL2','GU','TBAADM',sysdate,'TBAADM',sysdate,1,'BM3') 
/ 
commit 
/ 
create table tbaadm.tmp_mod as 	 
	(select * from tbaadm.mno where MOP_ID = 'HACM' and bank_id ='BM3') 
/ 
update tbaadm.tmp_mod  
	set MOP_ID = 'HBASEL2', 
	MOP_NUM=:mopNum,  
	menu_id = 'CUSTVAL' 
/ 
commit 
/ 
delete from tbaadm.mno where MOP_ID='HBASEL2' 
/ 
insert into tbaadm.mno select * from tbaadm.tmp_mod 
/ 
commit 
/ 



