----------------------------------------------------------------------------------------------------
--   Source Name            : Report_locledger.sql
--   Description            : Locker Ledger Report.
--   Input Values           : None
--   Output Values          : None
--   Called Script          : N.A
--   Calling Script         : N.A
--   Modification History:
--   Sl No.         Date              Author                     Description
--   --------------------------------------------------------------------------------------
--     01         17-Oct-2012         Priyanka                 Original Version
----------------------------------------------------------------------------------------------------


set serveroutput on size 1000000
set head off
set pau off
set echo off
set lines 250
set pages 0
set termout off
set verify off
set feedback off
spool Report_locledger.lst 
spool Report_locledger1.lst 
spool Report_locledger2.lst 

DECLARE
		v_locrefno		 clmt.cif_id%type;
		v_hirer_name		 cmg.cust_name%type;
		v_loc_status             wlckm.status%type;
		v_allot_date             clmt.issue_date%type;
		v_actual_rent		 clmt.rent_amt%type;
		v_discount		 clmt.disc_rent_amt%type;
		v_NEXT_PAYMENT_DATE      clmt.due_date%type;
		v_net_rent		 clmt.rent_amt%type;
		v_key_num		 wlckm.KEY_NUM%type;
		v_surstat		 lcsm.SURRENDER_DATE%type;
		v_tran_id  		 lcpd.TRAN_ID%type;
		v_tran_date              lcpd.TRAN_DATE%type;
		v_srl_no		 dctd_acli.PART_TRAN_SRL_NUM%type;
		v_TRAN_PARTICULAR        dctd_acli.TRAN_PARTICULAR%type;
		v_TRAN_TYPE		 dctd_acli.TRAN_TYPE%type;
		v_PART_TRAN_TYPE 	 dctd_acli.PART_TRAN_TYPE%type;
		v_TRAN_AMT		 dctd_acli.TRAN_AMT%type;
		v_solid                  clmt.sol_id%type:='&1';
		v_locker_num             clmt.locker_num%type:='&2';
		v_mode	 		 clmt.operation_mode%type;
		v_height                 number;
		v_depth                  number;
		v_width                  number;
		date1                    varchar2(30):='&3';
		date2                    varchar2(30):='&4';
		v_rack                   wlckm.rack_id%type; 
		v_type                   wlckm.locker_type%type;
	        v_rent_revision_date     lcpd.TRAN_DATE%type;	
		v_bankid		 clmt.bank_id%type := '&5';

cursor c1(v_solid varchar2,v_locker_num varchar2,v_bankid varchar2) is 

select  distinct clmt.cif_id, 
	cmg.cust_name,
        wlckm.status,
	clmt.issue_date,
	clmt.rent_amt,
        (clmt.rent_amt - clmt.disc_rent_amt),
	clmt.due_date, 
	clmt.disc_rent_amt, 
	clmt.operation_mode, 
	'' rent_revision_date,
	clmt.locker_num,
	wlckm.rack_id,
	clmt.locker_type,
	substr(wlckm.SIZE_OF_LOCKER,1,3),
	substr(wlckm.SIZE_OF_LOCKER,5,3),
	substr(wlckm.SIZE_OF_LOCKER,9,3),
	wlckm.KEY_NUM
from    clmt,cmg,wlckm
where   clmt.cif_id = cmg.cif_id
and     clmt.locker_num = wlckm.locker_num
and     clmt.locker_num = v_locker_num
and     clmt.sol_id = v_solid
and     clmt.bank_id = wlckm.bank_id
and	clmt.bank_id = v_bankid
and 	clmt.ENTITY_CRE_FLG = 'Y'
and 	clmt.del_flg !='Y';
      
BEGIN
	OPEN c1(v_solid,v_locker_num,v_bankid);
	LOOP
		FETCH c1 INTO	v_locrefno,
				v_hirer_name,
				v_loc_status,
				v_allot_date,
				v_actual_rent,
				v_discount,
				v_NEXT_PAYMENT_DATE,
				v_net_rent,
				v_mode,
			        v_rent_revision_date,	
				v_locker_num,
				v_rack,
				v_type,
				v_height,
				v_depth,
				v_width,
				v_key_num;
			
		IF c1%NOTFOUND THEN
			CLOSE c1;
			EXIT;
		END IF;
			
			BEGIN
				select lcsm.SURRENDER_DATE into v_surstat
				from   lcsm 
				where  LOCK_NO = v_locker_num
				and    BANK_ID = v_bankid; 

			exception when no_data_found then
        			v_surstat     := '';

			END;

			BEGIN
				select TRAN_ID,
				       TRAN_DATE
       				into   v_tran_id,
				       v_tran_date
				from   lcpd 
				where  locker_number = v_locker_num
				and    TRAN_DATE between to_date(date1,'dd-mm-yyyy') and to_date(date2,'dd-mm-yyyy')
				and    BANK_ID = v_bankid;

			exception when no_data_found then
				v_tran_id   := '';
        			v_tran_date := '';
			END;
			
			BEGIN
				select PART_TRAN_SRL_NUM into v_srl_no 
				from   dctd_acli
				where  trim(TRAN_ID)=trim(v_tran_id)
				and    tran_date = v_tran_date
				and    BANK_ID = v_bankid;

			exception when no_data_found then
				v_srl_no := '';				

			END;
			
			BEGIN
				select  TRAN_PARTICULAR,
					TRAN_TYPE,
					PART_TRAN_TYPE ,
					TRAN_AMT
				into    v_TRAN_PARTICULAR,
					v_TRAN_TYPE,
					v_PART_TRAN_TYPE ,
					v_TRAN_AMT
				from    dctd_acli
				where   trim(TRAN_ID)=trim(v_tran_id)
				and     tran_date = tran_date
				and     PART_TRAN_SRL_NUM = v_srl_no 
				and     tran_date = v_tran_date
				and    BANK_ID = v_bankid;
				
			exception when no_data_found then
				v_TRAN_PARTICULAR	:= '';
				v_TRAN_TYPE		:= '';
				v_PART_TRAN_TYPE 	:= '';
				v_TRAN_AMT		:= '';
				
			END;
		
	  dbms_output.put_line (v_locrefno		||'|'|| 
				v_hirer_name		||'|'|| 
				v_loc_status            ||'|'|| 
				v_allot_date            ||'|'|| 
				v_actual_rent		||'|'|| 
				v_surstat               ||'|'||
				v_discount		||'|'|| 
				v_NEXT_PAYMENT_DATE     ||'|'|| 
				v_net_rent		||'|'|| 
				v_mode			||'|'|| 
				v_rent_revision_date    ||'|'||
				v_locker_num            ||'|'|| 
				v_rack			||'|'|| 
			        v_type			||'|'|| 
			        v_height		||'|'|| 
				v_depth			||'|'||
				v_width			||'|'||
				v_key_num		||'|'||
				v_tran_date             ||'|'||
				--v_srl_no		||'|'||
				v_TRAN_PARTICULAR       ||'|'||
			        v_PART_TRAN_TYPE        ||'|'||	
				v_tran_id  		||'|'||
				v_TRAN_AMT);		
	
			
END LOOP;
END;	   			
/
spool off

