--===================================================================================================================
--  Filename                :   letters_etottdslet.sql
--  Description             :   
--  Date                    :   05-09-2012
--  Author                  :   Swaroop K Tiruvoipati
--  Menu Option             :
--  Modification History
--    Sl. #           Date           Author                     Modification
--    -----           -----          --------                    ----------------
--    1               05-09-2012     Swaroop K Tiruvoipati      Original Version
--                                                              (Ported from 7.x)
--===================================================================================================================
set serveroutput on size 1000000
set term on
DECLARE
	loc_fp                          utl_file.file_type;
	loc_filename                    varchar2(200);
	loc_filepath                    varchar2(100);
	loc_filemode                    varchar(10);
	GENREP                          number;
	REPDT                           date;
	REPDTPrnt                       varchar2(30);
	REPDD                           number;
	REPMMYYYY                       char(6);
	HLDY                            char(1);
	CITY_DESC                       varchar2(50);
	STATE_DESC                      varchar2(50);
	recline                         varchar2(500);

	LOC_CUST_TITLE_CODE             cmg.cust_title_code%type ;
	LOC_CUST_NAME                   cmg.cust_name%type;
	LOC_CUST_COMU_ADDR1             CRMUSER.ADDRESS.address_line1%type;
	LOC_CUST_COMU_ADDR2             CRMUSER.ADDRESS.address_line2%type;
	LOC_CUST_COMU_CITY_CODE         CRMUSER.ADDRESS.city_code%type;
	LOC_CUST_COMU_STATE_CODE        CRMUSER.ADDRESS.state_code%type;
	LOC_CUST_COMU_PIN_CODE          CRMUSER.ADDRESS.zip%type;
	LOC_CUST_COMU_PHONE_NUM_1       CRMUSER.phoneemail.phoneno1%type;
	LOC_CUST_COMU_PHONE_NUM_2       CRMUSER.phoneemail.phoneno2%type;
	LOC_WTAX_FLG                    gam.wtax_flg%type;
	LOC_OPN_DATE                    varchar2(50);
	LOC_DEP_AMT                     tam.deposit_amount%type;

CURSOR TDSREC1 (DT IN DATE) IS
	SELECT	distinct CIF_ID, TDA_FORACID, TDA_ACID
	FROM	CUST_TDS50000
	WHERE	UPDATE_FLAG='Y'
    AND	trunc(lchg_time) = '26-08-2008'
    AND BANK_ID = '&2';

   -- and cif_id='506309352';

BEGIN
	loc_filepath := '/mistmp1/Letters';
	loc_filename := 'etottds1.lst';
	loc_filemode := 'w';
	loc_fp := utl_file.fopen(loc_filepath, loc_filename, loc_filemode);

--	SELECT	DB_STAT_DATE --N
--	INTO	REPDT 
--	FROM	GCT
--      WHERE BANK_ID = '&2';
    REPDT := '&1';

--	SELECT  TO_CHAR(DB_STAT_DATE, 'Month DD, YYYY') --N
--	INTO    REPDTPrnt
--	FROM    GCT
--      WHERE BANK_ID = '&2';
    SELECT TO_CHAR(REPDT, 'Month DD, YYYY')
	INTO REPDTPrnt
	FROM DUAL;


	GENREP := 1;
	WHILE (GENREP = 1)
	LOOP
		FOR REC IN TDSREC1(REPDT)
		LOOP
			dbms_output.put_line(REC.TDA_FORACID);
			BEGIN
				SELECT	NVL(WTAX_FLG,'N'), 
				        TO_CHAR(ACCT_OPN_DATE,'Month DD, YYYY')	
				INTO	LOC_WTAX_FLG, 
					LOC_OPN_DATE
				FROM	GAM
				WHERE	GAM.FORACID = REC.TDA_FORACID
                                AND     GAM.BANK_ID = '&2';
			EXCEPTION
				WHEN OTHERS THEN
					LOC_WTAX_FLG := 'N';
					LOC_OPN_DATE := 'January 01, 1900'; 
			END;

			dbms_output.put_line(LOC_WTAX_FLG||'|'||LOC_OPN_DATE);

			IF (LOC_WTAX_FLG = 'T') THEN
			BEGIN
				SELECT	c.CUST_TITLE_CODE,
					c.CUST_NAME,
					a.address_line1 CUST_COMU_ADDR1,
					a.address_line2 CUST_COMU_ADDR2,
					a.city_code     CUST_COMU_CITY_CODE,
					a.state_code    CUST_COMU_STATE_CODE,
					a.zip           CUST_COMU_PIN_CODE,
					p.phoneno1      CUST_COMU_PHONE_NUM_1,
					p.phoneno2      CUST_COMU_PHONE_NUM_2
				INTO	LOC_CUST_TITLE_CODE,
					LOC_CUST_NAME,
					LOC_CUST_COMU_ADDR1,
					LOC_CUST_COMU_ADDR2,
					LOC_CUST_COMU_CITY_CODE,
					LOC_CUST_COMU_STATE_CODE,
					LOC_CUST_COMU_PIN_CODE,
					LOC_CUST_COMU_PHONE_NUM_1,
					LOC_CUST_COMU_PHONE_NUM_2
				FROM	CMG c,CRMUSER.ADDRESS a,CRMUSER.phoneemail p
				WHERE 	c.CIF_ID = rec.CIF_ID
				AND	a.orgkey = rec.CIF_ID
				AND	p.orgkey = rec.CIF_ID
				AND 	a.orgkey = c.CIF_ID
				AND 	p.orgkey = c.CIF_ID
				AND	a.BANK_ID = '&2'
				AND	p.BANK_ID = '&2' 
                                AND     c.BANK_ID = '&2';
			EXCEPTION
				WHEN OTHERS THEN
					LOC_CUST_TITLE_CODE  := '';
			END;
			dbms_output.put_line(LOC_CUST_TITLE_CODE);
					
			BEGIN
				SELECT	REF_DESC 
				INTO	CITY_DESC 
				FROM	RCT 
				WHERE	REF_REC_TYPE = '01' 
				AND	REF_CODE = LOC_CUST_COMU_CITY_CODE
                                AND     BANK_ID = '&2';
			EXCEPTION
				WHEN OTHERS THEN
					CITY_DESC := '';
			END;

			dbms_output.put_line(CITY_DESC);
			BEGIN
				SELECT	REF_DESC 
				INTO	STATE_DESC 
				FROM	RCT 
				WHERE	REF_REC_TYPE = '02' 
				AND		REF_CODE = LOC_CUST_COMU_CITY_CODE
                                AND     BANK_ID = '&2';
			EXCEPTION
				WHEN OTHERS THEN
					STATE_DESC := '';
			END;

			BEGIN
				SELECT	DEPOSIT_AMOUNT 
				INTO	LOC_DEP_AMT 
				FROM	TAM 
				WHERE	TAM.ACID = REC.TDA_ACID
                                AND     TAM.BANK_ID = '&2';;
			EXCEPTION
				WHEN OTHERS THEN
					LOC_DEP_AMT := '';
			END;


			recline :=	REC.CIF_ID			||'|'||
					REC.TDA_FORACID			||'|'||
					LOC_CUST_TITLE_CODE		||'|'||
					LOC_CUST_NAME			||'|'||
					LOC_CUST_COMU_ADDR1		||'|'||
					LOC_CUST_COMU_ADDR2		||'|'||
					CITY_DESC			||'|'||
					STATE_DESC			||'|'||
					LOC_CUST_COMU_PIN_CODE		||'|'||
					LOC_CUST_COMU_PHONE_NUM_1 	||'|'||
					LOC_CUST_COMU_PHONE_NUM_2 	||'|'||
					LOC_OPN_DATE			||'|'||
					LOC_DEP_AMT			||'|'||				
					REPDTPrnt;

			utl_file.put_line(loc_fp, recline);
			END IF;

		END LOOP;


		REPDT := REPDT - 1;
		REPDD := to_number(to_char(REPDT, 'dd'));
		REPMMYYYY := to_char(REPDT, 'mmyyyy');

		SELECT	SUBSTR(HLDY_STR,REPDD,1) 
		INTO	HLDY
		FROM	HOL 
		WHERE	cal_b2k_type = 'DC' 
		AND	mmyyyy = REPMMYYYY 
                AND     BANK_ID = '&2';

		IF (HLDY = 'Y') THEN
			GENREP := 1;
		ELSE
			GENREP := 0;
		END IF;

	END LOOP;
	utl_file.fclose(loc_fp);
				
END;
/
