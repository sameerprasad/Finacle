--=======================================================
-- Author :  Paresh Maru
-- Date   :
-- [Author]         [Date]          [Line]      [Desc]
--=======================================================
--==================================================================================*
-- Source Name       : TradeCreditReport.sql 
-- Author            : Paresh Maru
-- Date              : 
-- Description       : package body tc1_info   
-- Calling Script    : TradeCreditReport3.com
-- Modification History
--    Sl. --            Date              Author                Modification
--    -----         -----------     ---------------          ----------------
--    01            28-Mar-2012       Swapna Gholap         Added bank id as input
--*==================================================================================*


CREATE OR REPLACE PACKAGE tc1_info AS
PROCEDURE tc1_infoProc(  inp_str         IN VARCHAR2,
                out_retCode         OUT NUMBER,
                out_rec         OUT VARCHAR2) ;
g_mode        Char(1):= 'S';
END tc1_info;
/
CREATE OR REPLACE PACKAGE BODY tc1_info AS--{
------------------------------------------------------------------------------
TYPE rec_output IS RECORD(record_output  VARCHAR2(2000));
TYPE output_type IS TABLE OF rec_output INDEX BY BINARY_INTEGER;
output_table                            OUTPUT_TYPE;
g_number                                NUMBER;
g_current_row                           BINARY_INTEGER;
v_insert_row                            BINARY_INTEGER;
g_rowcount                              NUMBER;
------------------------------------------------------------------------------
-- GLOBAL VARIABLE
Input_tcno                              VARCHAR2(10);
Input_From_Date                         VARCHAR2(15);
Input_To_Date                           VARCHAR2(15);
Input_Bank_Id				VARCHAR2(8);
------------------------------------------------------------------------------
CURSOR Cur_tc1(Input_tcno number,Input_From_Date VARCHAR2,Input_To_Date VARCHAR2,Input_Bank_Id VARCHAR2)
    IS
SELECT
	SUPPLIERS_CREDIT_REF_NO,
	DC_REF_NO,              
	DC_SOL_ID,              
	DATE_OF_APPROVAL,       
	NAME_OF_LENDER,         
	COUNTRY_OF_LENDER,      
	AMOUNT,                 
	CURRENCY,               
	RATE_OF_INTEREST,       
	OTHER_CHRG_USD,         
	ALL_IN_COST,            
	PERIOD_OF_CREDIT,       
	UNIT_OF_TIME_PERIOD,    
	TYPE_OF_CREDIT1,        
	TYPE_OF_CREDIT2,        
	DESCRIPTION,            
	CATEGORY,               
	CONV_RATE,
	EQUI_USD_AMT,  
	BILL_NO
FROM	spctc1
where	DATE_OF_APPROVAL between to_date(Input_From_Date,'dd-mm-yyyy') AND to_date(Input_To_Date,'dd-mm-yyyy')
AND bank_id =	Input_Bank_Id 
order by to_number(trim(substr(SUPPLIERS_CREDIT_REF_NO,23,9)));

PROCEDURE tc1_infoProc(  inp_str         IN VARCHAR2,
			    out_RetCode         OUT NUMBER,
			    out_rec         OUT VARCHAR2)
IS
OutArr                      basp0099.ArrayType;
v_record_output             VARCHAR2(2000);
-------------------------------------------------------------------
-- Local Variable
loc_srno	VARCHAR2(10);
loc_CUST_CONST	VARCHAR2(5);
loc_bor_cat	VARCHAR2(50 CHAR);
dbdate	DATE;
loc_conv_rate	NUMBER(21,10);
loc_equi_usd_amt	NUMBER(21,10);
------------------------------------------------------------------
BEGIN --{
        out_retCode := 0;
        out_rec := '';

        IF g_mode = 'S'  THEN --{
        basp0099.formInputArr(inp_str,OutArr);

            Input_tcno            :=      OutArr(0);
		commit;
            Input_From_Date     :=      OutArr(1);
            Input_To_Date       :=      OutArr(2);
            Input_Bank_Id       :=      OutArr(3);
------------------------------------------------------------------------------

        v_insert_row := 0;

	loc_srno := 0;
	loc_bor_cat := 'PVT';

	For Rec_Cur    IN Cur_tc1(Input_tcno,Input_From_Date,Input_To_Date,Input_Bank_Id)
        LOOP                --{

		if(Rec_Cur.DC_REF_NO is not null) then
		BEGIN
		SELECT
			CUST_CONST
		INTO
			loc_CUST_CONST
		from cmg where cif_id = (select cif_id from gam where acid = (select OUR_PARTY_ACID from dcmm where DC_REF_NUM = trim(Rec_Cur.DC_REF_NO)));
		EXCEPTION
		when others then
			loc_CUST_CONST := '';
		END; 
		else
		BEGIN
		SELECT
			CUST_CONST
        INTO
            loc_CUST_CONST
        from cmg where cif_id = (select cif_id from gam where acid = (select OPER_ACID from fbm where bill_id = trim(Rec_Cur.BILL_NO))); 
		EXCEPTION
        when others then
            loc_CUST_CONST := '';
        END;
		end if;

		BEGIN
		SELECT
			REF_DESC
		INTO
			loc_bor_cat
		FROM
			RCT
		WHERE	
			REF_CODE = trim(loc_CUST_CONST);
		EXCEPTION
		when others then
			loc_bor_cat := 'PVT';
		END;

	    BEGIN
        SELECT
            DB_STAT_DATE
        INTO
            dbdate
        FROM
            GCT;
        EXCEPTION
        when others then
            dbdate:= '';
    	END;

	if(Rec_Cur.CONV_RATE is null) then
		BEGIN
		SELECT
	   		nvl(var_crncy_units/fxd_crncy_units,1)
		INTO
	   		loc_conv_rate
		FROM
	   		RTH
		WHERE
			ratecode='CCR' and ((var_crncy_code='USD' and fxd_crncy_code = Rec_Cur.CURRENCY) or (var_crncy_code=Rec_Cur.CURRENCY and fxd_crncy_code = 'USD')) and rtlist_date = (select max(rtlist_date) from rth where ((var_crncy_code='USD' and fxd_crncy_code = Rec_Cur.CURRENCY) or (var_crncy_code=Rec_Cur.CURRENCY and fxd_crncy_code = 'USD')) and ratecode='CCR' and rtlist_date<= last_day(Input_To_Date)) and rtlist_num= (select max(rtlist_num) from rth where ((var_crncy_code='USD' and fxd_crncy_code = Rec_Cur.CURRENCY) or (var_crncy_code=Rec_Cur.CURRENCY and fxd_crncy_code = 'USD')) and ratecode='CCR' and rtlist_date= (select max(rtlist_date) from rth where ((var_crncy_code='USD' and fxd_crncy_code = Rec_Cur.CURRENCY) or (var_crncy_code=Rec_Cur.CURRENCY and fxd_crncy_code = 'USD')) and ratecode='CCR' and rtlist_date<= last_day(Input_To_Date)));
		exception
			when no_data_found then loc_conv_Rate:=1;
		END;

	else
		loc_conv_rate := Rec_Cur.CONV_RATE;
	end if;


	BEGIN
		if (Rec_Cur.currency = 'JPY' ) then
			loc_equi_usd_amt := round((TO_NUMBER(TO_CHAR(Rec_Cur.AMOUNT)) / TO_NUMBER(TO_CHAR(loc_conv_rate))),2);
		else
			loc_equi_usd_amt := round((TO_NUMBER(TO_CHAR(Rec_Cur.AMOUNT)) * TO_NUMBER(TO_CHAR(loc_conv_rate))),2); 
		end if;
	END;

		BEGIN
			update
				spctc1	
			set
				CONV_RATE = loc_conv_rate,
				EQUI_USD_AMT = loc_equi_usd_amt 
			where
				SUPPLIERS_CREDIT_REF_NO = Rec_Cur.SUPPLIERS_CREDIT_REF_NO;
			commit;
		END;


	loc_srno := loc_srno + 1;

----------------------------------------------------------------------
     v_insert_row:=v_insert_row+1;
---------------------------------------------------------------------------
         v_record_output:=	loc_srno			||'|'||
				Rec_Cur.DATE_OF_APPROVAL	||'|'||
				Rec_Cur.SUPPLIERS_CREDIT_REF_NO	||'|'||
				loc_bor_cat			||'|'||
				Rec_Cur.NAME_OF_LENDER		||'|'||
				Rec_Cur.COUNTRY_OF_LENDER	||'|'||
				Rec_Cur.CURRENCY		||'|'||
				ltrim(to_char(Rec_Cur.AMOUNT,99999999999.99))			||'|'||
				ltrim(to_char(loc_equi_usd_amt,99999999999.99))		||'|'||
				Rec_Cur.RATE_OF_INTEREST	||'|'||
				ltrim(to_char(Rec_Cur.OTHER_CHRG_USD,99999999999.99))		||'|'||
				ltrim(to_char(Rec_Cur.ALL_IN_COST,99999999999.99))		||'|'||
				Rec_Cur.PERIOD_OF_CREDIT	||'|'||
				Rec_Cur.UNIT_OF_TIME_PERIOD	||'|'||
				Rec_Cur.TYPE_OF_CREDIT1		||'|'||
				Rec_Cur.TYPE_OF_CREDIT2		||'|'||
				Rec_Cur.DESCRIPTION		||'|'||
				Rec_Cur.CATEGORY;

---------------------------------------------------------------------------
        output_table(v_insert_row).Record_output:=v_record_output;
---------------------------------------------------------------------------

-------------------------------------------------------------------------
        END LOOP;           --}
-------------------------------------------------------------------------

                g_mode := 'G';
                g_rowcount := output_table.Count;
                g_current_row := 0;

                ELSIF g_mode = 'G' THEN --}{
                        g_current_row := g_current_row + 1;
                        IF g_current_row > g_rowcount
                        THEN
                                output_table.delete ;
                                g_current_row := 0;
                                g_rowcount := 0;
                                out_retcode := 1;
                                g_mode := 'S' ;
                                Return ;
                        END IF;
                        out_rec := output_table(g_current_row).record_output;
        END IF; --}
-------------------------------------------------------------------------
END tc1_infoProc; --}
END tc1_info; --}
/
DROP  SYNONYM  TBAADM.tc1_info
/
CREATE  SYNONYM  TBAADM.tc1_info FOR  tc1_info
/

DROP  SYNONYM  TBAUTIL.tc1_info
/
CREATE  SYNONYM  TBAUTIL.tc1_info FOR  tc1_info
/
DROP  SYNONYM  TBAGEN.tc1_info
/
CREATE  SYNONYM  TBAGEN.tc1_info FOR  tc1_info
/
GRANT EXECUTE ON  tc1_info TO TBAGEN, TBAUTIL, TBAADM
/
