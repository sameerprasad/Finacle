--===================================================================================================================
--	Filename	     :	hmicz_payeenmici.sql
--      Description          :  To fetch the data from the ICI table            
--      Date                 :  08-Jun-2012
--      Author               :  Apurv Mishra
--      Menu Option          :  HMICZ
--	Modification History
--    Sl. #           Date             Author             Modification                              
--    -----            -----          --------	       ----------------                               
--    01              08-Jun-2012    Apurv Mishra     Original Version                          
--===================================================================================================================
set serveroutput on size 1000000
set feedback off
set verify off
set linesize 500
set trims on
set termout off
set numformat 999D09
spool &1-&2-&3-&7..dat

DECLARE
particular      CTD.TRAN_PARTICULAR%TYPE;
loc_acid        GAM.foracid%TYPE;
custStat        CMG.cust_stat_code%type;
instr           CTD.INSTRMNT_NUM%TYPE;
dummy           number;
solId           ICI.sol_id%type;
tranDate        ICI.zone_date%TYPE;
zoneId          ICI.zone_code%TYPE;
recNotFound     number;
recFnd          number;
dtdFound        number;
dbDate          ICI.zone_date%TYPE;
bank_Id         ICI.bank_Id%TYPE;


CURSOR  CUR_ZONE IS
	SELECT zone_code,to_char(zone_date,'DD-MM-YYYY') ,bank_id,zone_date,acid,zone_srl_num,tran_particulars ,inst_num,inst_amt,tran_rmks
	FROM ICI
	WHERE SOL_ID = solId
	AND ZONE_CODE = zoneId
	AND ZONE_DATE = tranDate
	AND bank_id = bank_Id;


BEGIN--{
                solId := '&5';
                tranDate := to_date('&4','DD-MM-YYYY');
                zoneId := '&6';
                dtdFound :=0;
                recFnd :=0;
		bank_Id := '&8';

        FOR CUR_ZONE_REC in CUR_ZONE
        LOOP--{
                recNotFound := 0;
                loc_acid := '';
                IF( recFnd = 0 ) THEN
	                dbms_output.put_line('PNM');
                END IF;
                recFnd := recFnd + 1;
		
		BEGIN--{
			SELECT gam.foracid, cmg.cust_stat_code
			INTO loc_acid,custStat
			FROM gam,cmg
			WHERE gam.ACID = CUR_ZONE_REC.acid
			AND gam.bank_id = CUR_ZONE_REC.bank_Id
			AND gam.acct_ownership != 'O'
			AND gam.cust_id = cmg.cust_id;
			
			EXCEPTION
                                when no_data_found then
                                recNotFound := 1;
                END;--}

                IF( recNotFound = 0 ) THEN
		dbms_output.put_line(solId||'|'||CUR_ZONE_REC.zone_code||'|'||CUR_ZONE_REC.zone_date||'|'||CUR_ZONE_REC.zone_srl_num||'|'||CUR_ZONE_REC.acid||'|'||loc_acid||'|'||CUR_ZONE_REC.inst_num||'|'||to_char(CUR_ZONE_REC.inst_amt,'99999999999.99')||'|'||CUR_ZONE_REC.tran_particulars||'|'||custStat);
                END IF;
                recNotFound :=0;
       END LOOP;--}

END;--}
/
set termout on
spool off


