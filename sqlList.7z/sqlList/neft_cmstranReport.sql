--===================================================================================================================
--             Filename                :                neft_cmstranReport.sql
--             Description             :                Data where tran is not null and acct no. like HPCL
--             Date                    :                02-08-2012
--             Author                  :		Kumar Vishal
--             Menu Option	       :		NEFTRPT
--             Modification History
--		Sl. #           Date             Author             Modification                              
--		-----           -----           --------          ----------------                               
--		                          
--===================================================================================================================
set pages 0 feedback off echo off verify off trims on lines 2000
spool neft_cmstranReport_&1..txt
SELECT BENF_IFSC||'|'||BENF_BR||'|'||SENDER_IFSC||'|'||TRAN_NO||'|'||VALUE_DATE||'|'||AMOUNT||'|'||SENDER_NAME||'|'||SENDER_ACT_TYPE||'|'||SENDER_ACCT_NO||'|'||BENF_NAME||'|'||BENF_ACT_TYPE||'|'||BENF_ACCT_NO||'|'||FRESH_RETURN_FLG||'|'||REJECT_CODE||'|'||REF_NUM||'|'||TRAN_DATE||'|'||TRAN_ID||'|'||PART_TRAN_SRL_NUM||'|'||NAM_MATCH_PER||'|'||NAM_MATCH_REMKS||'|'||FILE_NAM||'|'||ICORE_NAM||'|'||TRAN_STATUS||'|'||TRAN_USER FROM ICICI_NEFT WHERE FILE_NAM='&1' AND BANK_ID = '&2' AND TRAN_ID IS NOT NULL AND CMS_ACCOUNT_NO LIKE 'HPCL%'
/
spool off
