set feedback off
set termout off
set serveroutput on size 1000000
set verify off
set pagesize 0
set linesize 130
spool $3
declare
CURSOR tran_cur is
select foracid,tran_crncy_code,htd.sol_id sol_id,part_tran_type,tran_amt,tran_particular
from htd,gam where
gam.acid = htd.acid
and tran_date=(to_date('$2','dd-mm-yyyy'))
and tran_id=upper(lpad('$1',9,' '))
and htd.del_flg ='Y'
union all
select foracid,tran_crncy_code,dtd.sol_id sol_id,part_tran_type,tran_amt,tran_particular
from dtd,gam where
gam.acid = dtd.acid
and tran_date=(to_date('$2','dd-mm-yyyy'))
and tran_id=upper(lpad('$1',9,' '))
and dtd.del_flg ='Y';

tran_rec tran_cur%rowtype;

begin
        open tran_cur;
        loop
        fetch tran_cur into tran_rec ;
        exit when tran_cur%notfound;

        DBMS_OUTPUT.PUT_LINE(rpad(tran_rec.foracid,16,' ')||tran_rec.tran_crncy_code||rpad(tran_rec.sol_id,8,' ')||tran_rec.pa
rt_tran_type||to_char(tran_rec.tran_amt,'99999999999.90')||rpad(tran_rec.tran_particular,29,' '));

        end loop;
        close tran_cur;
END;
/
spool off
