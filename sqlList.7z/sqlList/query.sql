#====================================================================
#Source Name            : query.sql
#Description           	 :  
#Input Values           :  None
#Output Values          :  None
#Called Scripts         :  None
#Calling Scripts        :  None
#Modification history   :  None
#Sl. No    Date        Author           Description
#------  ----------  ------------   ---------------------
#1.0     20-09-2012  Manisha Kumra   
#=====================================================================


set pages 0
spool dtd.txt
select dth.init_sol_id,to_char(dtd.tran_date,'DD/MM/YYYY'),ltrim(dtd.tran_id),dtd.tran_particular,dtd.tran_rmks,dtd.tran_amt,dtd.rcre_user_id,dtd.sol_id,dtd.part_tran_srl_num from dtd ,dth where dtd.tran_date = '&1' and dtd.acid in (select acid from gam where foracid ='605605000722') and dth.tran_date=dtd.tran_date and dtd.tran_id=dth.tran_id and dtd.tran_type ='C' and dtd.TRAN_SUB_TYPE='NR' and dtd.part_tran_type ='C' and dtd.del_flg='N' and dtd.BANK_ID = '&1' and dtd.BANK_ID = dth.BANK_ID;
spool off