set serveroutput on size 1000000
set feedback off
set verify off
set linesize 500
set pages 0
set trims on
set termout off
set numformat 999D09
spool &2
select distinct '02^639^'||substr(h.BSR_CODE,length(h.bsr_code)-3,4)||'^639'||'^'||substr(b.BSR_CODE,length(b.bsr_code)-3,4)||'^'||a.MAJOR_TAX_HEAD||'^'||count(*)||'^00^'||sum(a.CHALLAN_AMOUNT)||'^00^'||
decode(a.MAJOR_TAX_HEAD,'0020','C','0021','I','0023','H','0024','N','0028','O','0031','E','0032','W','0033','G','0026','F','0036','B','0034','S',' ')
||c.CBDT_SCROLL||'^'||to_char(a.realisation_date,'ddmmyy')||'^722'||d.ZAO_CODE||'^'||
decode(a.MAJOR_TAX_HEAD,'0020','C','0021','I','0023','H','0024','N','0028','O','0031','E','0032','W','0033','G','0026','F','0036','B','0034','S',' ')
||g.CBDT_SCROLL||'^'||to_char(a.realisation_date,'ddmmyy')
from ici_gbm_challan_master a,ici_gbm_bsrcode b,ICI_GBM_SOL_SCOLL_HISTORY c,icici_gbm_trn_hdr e,ici_gbm_territory f,ICI_GBM_SOL_SCOLL_HISTORY g,ici_gbm_nodal_master d,ici_gbm_bsrcode h
where c.SCR_DATE=a.realisation_date 
and c.sol_id=e.sol_id 
and b.sol_id=e.sol_id 
and h.sol_id=g.sol_id 
and e.tax_tran_id=a.tax_tran_id 
and e.tax_tran_date = a.tax_tran_date 
and (e.tax_type='C' or e.tax_type='c')
and a.realisation_date ='&1' 
and a.del_flg='N' 
and f.STATE_NAME= a.STATE 
and c.COMMI_CODE='000' and g.SCR_DATE=a.realisation_date 
and g.sol_id in (select parent_sol_id from ici_gbm_terminal_master where sol_id=a.sol_id and scheme_code='0004') and g.COMMI_CODE='101' and d.sol_id in (select parent_sol_id from ici_gbm_terminal_master where sol_id=a.sol_id and scheme_code='0004') and  d.scheme_code='0004'
group by substr(h.BSR_CODE,length(h.bsr_code)-3,4),substr(b.BSR_CODE,length(b.bsr_code)-3,4),a.MAJOR_TAX_HEAD,c.CBDT_SCROLL,
to_char(a.realisation_date,'ddmmyy'),d.ZAO_CODE,g.CBDT_SCROLL,to_char(a.realisation_date,'ddmmyy')
/
spool off
