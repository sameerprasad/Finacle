Rem     This file will create ICICI_CIFT_PROCESS
Rem     with the following characteristics.

Rem TABLE NAME: ICICI.ICICI_CIFT_PROCESS_TABLE

Rem SYNONYM: ICICI_CIFT_PROCESS

drop table ICICI.ICICI_CIFT_PROCESS_TABLE
/
drop public synonym ICICI_CIFT_PROCESS
/

create table ICICI.ICICI_CIFT_PROCESS_TABLE
(
 CIF_ID                                            VARCHAR2(9),
 FORACID                                            VARCHAR2(12),
 CUST_TITLE_CODE                                    VARCHAR2(5),
 CUST_NAME                                          VARCHAR2(80),
 DATE_OF_BIRTH                                      DATE,
 CUST_SEX                                           CHAR(1),
 EMAIL_ID                                           VARCHAR2(40),
 CUST_STAT_CODE                                     VARCHAR2(5),
 PAN_GIR_NUM                                        VARCHAR2(5),
 CUST_PAGER_NO                                      VARCHAR2(15),
 PROC_DATE                                          DATE,
 BANK_ID					    VARCHAR2(8)
)
/

create public synonym ICICI_CIFT_PROCESS
    for ICICI.ICICI_CIFT_PROCESS_TABLE
/

create unique index IDX_ICICI_CIFT_PROCESS
on ICICI.ICICI_CIFT_PROCESS_TABLE( FORACID )
storage ( PCTINCREASE 0 )
/

create index IDX_SBY_AC_DTL_CUSTID_TABLE
on ICICI.ICICI_CIFT_PROCESS_TABLE( CIF_ID )
storage ( PCTINCREASE 0 )
/

grant select, insert, update, delete on ICICI.ICICI_CIFT_PROCESS_TABLE to tbagen
/
grant select, insert, update, delete on ICICI.ICICI_CIFT_PROCESS_TABLE to tbautil
/
grant select, insert, update, delete on ICICI.ICICI_CIFT_PROCESS_TABLE to tbaadm
/
