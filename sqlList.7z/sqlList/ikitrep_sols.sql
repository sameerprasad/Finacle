set head off
set feedback off
set verify off
set linesize 5
set pagesi 0
spool ikitrep_sols.txt
select sol_id from sol where bank_id = '&1'
order by sol_id
/
spool off
exit
