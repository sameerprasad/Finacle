
drop table ICICI_CCIL_TABLE
/
drop public synonym ICI_CCIL
/

Create table ICICI_CCIL_TABLE
(
 DRFORACID                                          VARCHAR2(16 CHAR),
 CRFORACID                                          VARCHAR2(16 CHAR),
 CUST_NAME                                          VARCHAR2(80 CHAR),
 OBLIG_AMT                                          NUMBER(20,4),
 EFFECTIVE_AVIL_BAL                                 NUMBER(20,4),
 TRAN_PARTICULAR                                    VARCHAR2(50 CHAR),
 TRAN_TYPE                                          VARCHAR2(1 CHAR),
 TRAN_ID                                            VARCHAR2(9 CHAR),
 FILE_NAME                                          VARCHAR2(100 CHAR),
 TRAN_DATE                                          DATE,
 PROC_FLG                                           VARCHAR2(1 CHAR),
 DEL_FLG                                            VARCHAR2(1 CHAR),
 BANK_ID					    VARCHAR2(8 CHAR)
)
/
create public synonym ICI_CCIL for ICICI_CCIL_TABLE
/
grant select, insert, update, delete on ICICI_CCIL_TABLE to tbagen
/
grant select,insert, update, delete on ICICI_CCIL_TABLE to tbautil
/
grant select,insert, update, delete on ICICI_CCIL_TABLE to tbaadm
/


drop table ICI_CCIL_SHRTFAL
/
drop public synonym ICI_CCIL_SFT
/

Create table ICI_CCIL_SHRTFAL
(
 FORACID                                            VARCHAR2(16 CHAR),
 SFT_AMOUNT                                         NUMBER(20,4),
 FILE_NAME                                          VARCHAR2(100 CHAR),
 TRAN_ID                                            VARCHAR2(9 CHAR),
 TRAN_DATE                                          DATE,
 DEL_FLG                                            CHAR(1),
 BANK_ID                                            VARCHAR2(8 CHAR)
)
/

create public synonym ICI_CCIL_SFT for ICI_CCIL_SHRTFAL
/
grant select, insert, update, delete on ICI_CCIL_SHRTFAL  to tbagen
/
grant select, insert, update, delete on ICI_CCIL_SHRTFAL  to tbautil
/
grant select, insert, update, delete on ICI_CCIL_SHRTFAL  to tbaadm
/


drop table ICICI_CCIL_REP_SEQ
/
drop public synonym ICI_CCIL_REP
/

Create table ICICI_CCIL_REP_SEQ
(
 FILE_NAME                                          VARCHAR2(100 CHAR),
 CCIL_FORACID                                       VARCHAR2(16 CHAR),
 BENF_FORACID                                       VARCHAR2(16 CHAR),
 TRAN_TYPE                                          VARCHAR2(1 CHAR),
 TRAN_DATE                                          DATE,
 OBLIG_AMT                                          NUMBER(20,4),
 CCIL_EFF_BAL                                       NUMBER(20,4),
 TRAN_PARTICULAR                                    VARCHAR2(50 CHAR),
 FILE_SEQ                                           VARCHAR2(10 CHAR),
 TRAN_SEQ                                           VARCHAR2(10 CHAR),
 GEN_FLG                                            CHAR(1),
 MNEMONIC                                           VARCHAR2(4 CHAR),
 SEGMENT                                            VARCHAR2(5 CHAR),
 BANK_ID					    VARCHAR2(8 CHAR)
)
/
create public synonym ICI_CCIL_REP for ICICI_CCIL_REP_SEQ
/
grant select, insert, update, delete on ICICI_CCIL_REP_SEQ to tbagen
/
grant select, insert, update, delete on ICICI_CCIL_REP_SEQ to tbautil
/
grant select, insert, update, delete on ICICI_CCIL_REP_SEQ to tbaadm
/
