alter table ici_ccm_mod add bank_id varchar2(8)
/
update ici_ccm_mod set bank_id = 'ICICI01'
/

alter table ici_ccm add bank_id varchar2(8)
/
update ici_ccm set bank_id = 'ICICI01'
/

DROP INDEX TBAADM.IDX_ICI_CCM_MOD_CHRG
/

CREATE UNIQUE INDEX TBAADM.IDX_ICI_CCM_MOD_CHRG ON TBAADM.ICI_CCM_MOD
(CHRG_CODE, BANK_ID)
/

DROP INDEX TBAADM.IDX_ICI_CCM_CHRG
/
CREATE UNIQUE INDEX TBAADM.IDX_ICI_CCM_CHRG ON TBAADM.ICI_CCM
(CHRG_CODE, BANK_ID)
/