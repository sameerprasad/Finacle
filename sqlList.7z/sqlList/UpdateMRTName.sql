set echo off;
set head off;
update ROT set OPTION_VALUE='fbcsic.mrt' where option_code='FBCS_MRT_FILE'and bank_id='&1';
commit;
quit
/
