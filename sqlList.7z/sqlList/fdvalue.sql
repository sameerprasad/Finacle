clear screen
rem prompt ...WORKING ..WILL TAKE TIME
set echo off
set termout off
set pause off
rem script for  identification of Accounts with value date lower than open date
rem author M K JAIN
rem version 1.0 dated 6 SEP 95  
set verify off
whenever sqlerror exit sql.sqlcode
set feedback off
set linesize 132 
set pages 66
set newpage 0
define all_dashes = '________________________________________________________________________________________________________________________________'
column today new_value today_date
column day new_value day1
column bran new_value br
column bd new_value bod
select to_char(sysdate,'dd/mm/yyyy hh24::mi:ss') today
from dual;
select to_char(sysdate,'yymmddhh24miss') day
from dual;
select to_char(db_stat_date) bd from gct;
select br_name bran from bct
where br_code = (select br_code from sol where sol_id='&1' and bank_id='&2');

ttitle center  'ICICI BANKS LTD.' skip 1 -
center  br skip 2  -
center 'REPORT OF TERM DEPOSIT ACCOUNTS WITH VALUE DATE PRIOR TO ACCOUNT OPEN DATE ON &bod' skip 1 -
left today_date right 'Page :       ' format 999 sql.pno skip 1 -
left all_dashes skip 2
btitle center  'ABOVE TRANSACTIONS CHECKED AND FOUND IN ORDER' skip 1 -
center 'Also check for accounts without balance or balance less than deposit amount' skip 1 -
right 'OFFICER IN CHARGE (OPERATIONS)'
set numf b999,99,99,999.99
col A heading 'CUST_ID' format a9 
col B heading 'PR' format a2 
col C heading 'NUMBER' format a9 
col D heading 'NAME' format a40 
col E heading 'BALANCE' format b999,99,99,999.99  
col F heading 'DEPOSIT|AMOUNT' format b999,99,99,999.99 
col G heading 'VALUE|DATE' format a12 
col H heading 'Days' format 99999
col LEDGER format b99999
break on cust_id skip 1 on report
spool fdvalue.&1
select gam.cust_id A,gam.foracid C,
gam.acct_name D,gam.clr_bal_amt+gam.un_clr_bal_amt E,
tam.deposit_amount F,to_Date(TAM.open_effective_date,'DD-MM-YYYY') G,
to_date(TAM.open_effective_date,'DD-MM-YYYY') - to_date(gam.acct_opn_date,'DD-MM-YYYY') H, ledg_num LEDGER,decode(deposit_status ,NULL,'NEW','R','RENEW','T','TRANSFER','E','EXTEND')
from gam, tam
where gam.sol_id='&1'
and gam.bank_id = '&2' and tam.bank_id = '&2'
and gam.acid = tam.acid
and to_Date(tam.open_effective_date,'DD-MM-YYYY') < to_Date(gam.acct_opn_date,'DD-MM-YYYY')
and gam.acct_cls_flg != 'Y'
and gam.entity_cre_flg = 'Y'
and to_char(gam.acct_opn_date,'DD-MM-YYYY') = (select to_char(db_stat_date,'DD-MM-YYYY') from gct)
order by 8,1
/
rem spool out
spool off
exit
