set serveroutput on size 1000000
set feedback off
set verify off
set linesize 500
set pages 0
set trims on
set termout off
set numformat 9999999D09
spool &1
select '-------------------------------------------------------------------------------------------------------' from dual;
select 'Please find below GBM challan details which are not verified / tran id is not updated ' from dual;
select 'GBM TranDate|GBM TranId|Cin no|Challan Amt|Finacle TranDate|Finacle TranId|TaxType-TranType|Part Tran Num|Reason' from
 dual;
select '-------------------------------------------------------------------------------------------------------' from dual;
select a.tax_tran_date||'|'||a.tax_tran_id||'|'||a.CIN_NO||'|'||a.challan_amount||'|'||a.tran_date||'|'||a.tran_id||'|'||decod
e(b.tax_type,'C','CBDT','CBEC')||'-'||decode(b.tax_tran_type,'C','Cash','T','Trf','L','Clg')||'|'||a.PART_TRAN_SRL_NUM||'|Unve
rified transaction' from ici_gbm_challan_master a ,icici_gbm_trn_hdr b where (a.realisation_date='&2'or
 a.tax_tran_date='&3')and  a.tax_tran_id =b.tax_tran_id and a.tax_Tran_date=b.tax_tran_date and b.sol_id
='&4' and a.del_flg ='N' and a.entity_creation_flg='N';
select a.tax_tran_date||'|'||a.tax_tran_id||'|'||a.CIN_NO||'|'||a.challan_amount||'|'||a.tran_date||'|'||a.tran_id||'|'||decod
e(b.tax_type,'C','CBDT','CBEC')||'-'||decode(b.tax_tran_type,'C','Cash','T','Trf','L','Clg')||'|'||a.PART_TRAN_SRL_NUM||'|Tran
 id is not there' from ici_gbm_challan_master a ,icici_gbm_trn_hdr b where (a.realisation_date='&5' or a
.tax_tran_date=to_date'&6') and  a.tax_tran_id =b.tax_tran_id and a.tax_Tran_date=b.tax_tran_date and b.sol_id=
'&7' and (b.tax_tran_type='C' or b.tax_tran_type='T') and a.del_flg ='N' and a.entity_creation_flg='N' and a.tran_id is null;
select '-------------------------------------------------------------------------------------------------------' from dual;
select '                                                                                         ' from dual;
select '-------------------------------------------------------------------------------------------------------' from dual;
select 'Please find below finacle tran ids for either tran id is not updated or challan details missing in GBM ' from dual;
select 'Tran Date|TranId|Part tran srl num|tran Amount' from dual;
select '-------------------------------------------------------------------------------------------------------' from dual;
select tran_date||'|'||tran_id||'|'||part_tran_srl_num||'|'||tran_amt from dtd where acid in (Select acid from gam where forac
id in('&8'||'SLDIRCSH', '&9'||'SLDIRTAX', '&10'||'SLDIRCLG')) and (tran_date||tran_id||part_tran_srl_num) not in (select tran_
date||tran_id||part_tran_srl_num from ici_gbm_challan_master where (realisation_date=to_date'&11' or tax_tran_d
ate='&12')) and del_flg='N' and PART_TRAN_TYPE='C' ;
select '-------------------------------------------------------------------------------------------------------' from dual;
spool off
~
