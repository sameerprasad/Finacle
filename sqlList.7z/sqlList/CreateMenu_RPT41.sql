-------------------------------------------------------------------------------------------------------------
-- FileName                 : CreateMenu_RPT41.sql
-- Author                   : Khalid Sabeeh
-- Date			    : 16-04-2013
-- Description              : entries in the tables
-- Input                    : --
-- Output                   : --
-- Calling Script           : --
-- Modifications            : None
-------------------------------------------------------------------------------------------------------------


set define off; 
variable mopNum varchar2(5); 
begin 
select nvl(to_char(max(to_number(mop_num))+1), '1') into :mopNum from tbaadm.mno where menu_id = 'FIMNU4'; 
exception when no_data_found then 
	:mopNum := 1; 
end; 
/ 
drop table tbaadm.tmp_mod 
/ 
create table tbaadm.tmp_mod as  
	(select * from tbaadm.mod  
	where mop_id = 'HACM' and bank_id='BM3') 
/ 
update tbaadm.tmp_mod  
	set MOP_ID = 'RPT41', 
	MOP_TYPE = 'U', 
	EXE_NAME='https://$W/finbranch',  
	INPUT_FILENAME = 'Customize/Customize_ctrl.jsp?sessionid=$S', ADDITIONAL_PARAMS='&RPT41=$TRPT41=$SRPT41=$CRPT41=$' 
/ 
delete from tbaadm.mod where MOP_ID='RPT41' 
/ 
insert into tbaadm.mod select * from tbaadm.tmp_mod 
/ 
drop table tbaadm.tmp_mod 
/ 
create table tbaadm.tmp_mod as  
	(select * from tbaadm.mod_txt  
	where MOP_ID = 'HACM' and bank_id='BM3') 
/ 
update tbaadm.tmp_mod  
	set MOP_ID = 'RPT41' ,  
	USER_MOP_ID = 'RPT41',  
	MOP_TEXT = 'PAYMENT OF MATURITY PROCEEDS'  
/ 
delete from tbaadm.mod_txt where MOP_ID='RPT41' 
/ 
insert into tbaadm.mod_txt select * from tbaadm.tmp_mod  
/ 
drop table tbaadm.tmp_mod 
/ 
delete from tbaadm.oat where MOP_ID='RPT41' 
/ 
insert into tbaadm.oat values('RPT41','GU','TBAADM',sysdate,'TBAADM',sysdate,1,'BM3') 
/ 
create table tbaadm.tmp_mod as 	 
	(select * from tbaadm.mno where MOP_ID = 'HACM' and bank_id='BM3') 
/ 
update tbaadm.tmp_mod  
	set MOP_ID = 'RPT41', 
	MOP_NUM=:mopNum,  
	menu_id = 'FIMNU4' 
/ 
delete from tbaadm.mno where MOP_ID='RPT41' 
/ 
insert into tbaadm.mno select * from tbaadm.tmp_mod 
/ 
commit 
/ 

