----------------------------------------------------------------------------------------------------
--   Source Name            : lcrntrpt.sql
--   Description            : Locker Rent Paid Receipt Report.
--   Input Values           : None
--   Output Values          : None
--   Called Script          : N.A
--   Calling Script         : N.A
--   Modification History:
--   Sl No.         Date              Author                     Description
--   --------------------------------------------------------------------------------------
--     01         10-Oct-2012         Priyanka                 Original Version
----------------------------------------------------------------------------------------------------

SET SERVEROUTPUT ON SIZE 1000000;
SET VERIFY OFF
SET TERMOUT OFF
SET TRIMSPOOL ON
SET ECHO OFF
SET FEEDBACK OFF
SET EMBEDDED ON
SET LINES 400
SET HEAD OFF
SET PAGES 0
clear columns
clear breaks
clear computes
set serveroutput on

spool lcrntrpt.lst

declare

v_sol_id                lcpd.sol_id%type;
v_tran_id               lcpd.tran_id%type;
v_tran_date             lcpd.tran_date%type;
v_locker_num            lcpd.locker_number%type;
v_cif_id                lcpd.cif_id%TYPE;
v_remarks               lcpd.remarks%type;
v_paid_amt              lcpd.paid_amount%type;
v_CUST_NAME             cmg.cust_name%type;
v_last_chg_usr          dtd.lchg_user_id%type;
v_issu_date             clmt.issue_date%type;
v_due_date              clmt.due_date%type;
v_lcknum                varchar2(25) ;
--v_lcknum                lcpd.LOCKER_NUMBER%type ;
v_solid                 lcpd.sol_id%type ;
v_date1                 varchar2(25);
v_date2                 varchar2(25) ;
v_tranid                lcpd.tran_id%type ;
v_bankid                clmt.bank_id%type;
v_overDuePrd            number;
v_renewal_date          date;

cursor C1 (v_lcknum  lcpd.LOCKER_NUMBER%type, v_solid lcpd.sol_id%type,  v_date1 varchar2, v_date2 varchar2,
v_tranid lcpd.tran_id%type,bankid varchar2)  is
SELECT  LCPD.SOL_ID,
        LCPD.TRAN_ID,
        LCPD.TRAN_DATE,
        LCPD.LOCKER_NUMBER,
        LCPD.CIF_ID,
        LCPD.REMARKS,
        LCPD.PAID_AMOUNT,
        floor(ABS((due_date - decode(renewal_date,'',(due_date+1),renewal_date))/365)) v_overDuePrd,
        CLMT.renewal_date
FROM    LCPD,CLMT
WHERE   LCPD.LOCKER_NUMBER = CLMT.LOCKER_NUM
AND     CLMT.cif_id= LCPD.cif_id
AND     lcpd.tran_date BETWEEN to_date(V_DATE1,'dd-mm-yyyy') AND to_date(V_DATE2,'dd-mm-yyyy')
AND         trim(lcpd.tran_id) = v_tranid
AND     lcpd.LOCKER_NUMBER like v_lcknum
AND     lcpd.REMARKS like '%LOCKER RENT%'
AND     lcpd.SOL_ID = v_solid
AND     clmt.bank_id = lcpd.bank_id
AND     clmt.bank_id = v_bankid
AND     lcpd.DEL_FLG!='Y'
AND     CLMT.DEL_FLG!='Y';

BEGIN

        v_lcknum := '&1';
        select nvl2(v_lcknum, '%'||v_lcknum, '%') into v_lcknum from dual;
        --dbms_output.put_line(v_lcknum);
        v_solid  := '&2';
        v_date1  := '&3';
        v_date2  := '&4';
        v_tranid := '&5';
    v_bankid := '&6';

 OPEN C1(v_lcknum, v_solid, v_date1, v_date2, v_tranid, v_bankid);
        loop
        --{
                if (C1%ISOPEN) then
                --{
                FETCH C1
                INTO
                        v_sol_id,
                        v_tran_id,
                        v_tran_date,
                        v_locker_num,
                        v_cif_id,
                        v_remarks,
                        v_paid_amt,
                        v_overDuePrd,
                        v_renewal_date;
                        --v_issu_date,
                        --v_due_date;

                BEGIN
                --{
                        --To Arrive From Period
                        IF (v_overDuePrd > 0) THEN
                        --{
                                BEGIN
                                --{
                                        select add_months(v_renewal_date,(-12 * v_overDuePrd))
                                        INTO v_issu_date
                                        FROM dual;
                                        Exception when no_data_found then
                                                v_issu_date := null;
                                --}
                                END;
                        --}
                        ELSIF(v_overDuePrd = 0) THEN
                        --{
                                BEGIN
                                --{
  select add_months(v_renewal_date,-12)
                                        INTO v_issu_date
                                        FROM dual;
                                        Exception when no_data_found then
                                                v_issu_date := null;
                                --}
                                END;
                        --}
                        END IF;
                --}
                END;
                BEGIN
                --{
                        --To Arrive To Period
                        IF (v_overDuePrd > 0) THEN
                        --{
                                BEGIN
                                --{
                                        select (add_months(v_issu_date,(12 * v_overDuePrd)) - 1)
                                        INTO v_due_date
                                        FROM dual;
                                        Exception when no_data_found then
                                                v_due_date := null;
                                --}
                                END;
                        --}
                        ELSIF(v_overDuePrd = 0) THEN
                        --{
                                BEGIN
                                --{
                                        select (add_months(v_issu_date,12) - 1)
                                        INTO v_due_date
                                        FROM dual;
                                        Exception when no_data_found then
                                                v_due_date := null;
                                --}
                                END;
                        --}
                        END IF;
                --}
                END;
  begin
                select cust_name into v_CUST_NAME from cmg where cif_id= v_cif_id;
        Exception when no_data_found then
                v_CUST_NAME:=null;


        end;

        begin
                select distinct PSTD_USER_ID
                into v_last_chg_usr
                from DCTD_ACLI
                where tran_id = lpad(v_tran_id,9,' ')
                and tran_date = v_tran_date
                and sol_id = v_sol_id;
                Exception when no_data_found then
                v_last_chg_usr:=null;
        end;
        --}
        end if;
                 IF (C1%ISOPEN and C1%NOTFOUND) THEN
                        CLOSE C1;
                        EXIT;
                END IF;


dbms_output.enable(buffer_size => NULL);
dbms_output.put_line(   v_sol_id        ||'|'||
                        v_tran_id       ||'|'||
                        v_tran_date     ||'|'||
                        v_locker_num    ||'|'||
                        v_cif_id        ||'|'||
                        v_CUST_NAME     ||'|'||
                        v_remarks       ||'|'||
                        v_paid_amt      ||'|'||
                        v_last_chg_usr  ||'|'||
                        v_issu_date    ||'|'||
                        v_due_date);
end loop;
    --}
end;
/
spool off


