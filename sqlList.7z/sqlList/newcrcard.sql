set head off
set pages 1000
set echo off
set lines 132
set wrap off
set feedback off
set verify off
set pause off
set termout off
alter session set nls_date_format='dd-mm-yyyy';
spool newcrcard
select dtd.sol_id ||'|'||dtd.tran_date||'|'||foracid||'|'||dtd.TRAN_ID||'|'||
part_tran_type||'|'||decode(part_tran_type,'C',1*tran_amt,-1*tran_amt)||'|'||
TRAN_PARTICULAR||'|'||
tran_rmks||'|'||dtd.rcre_user_id||'|'||dth.init_sol_id||'|'
FROM DTD,GAM,DTH
where foracid = '0036CCADVANCE'
and gam.sol_id = '0036'
and gam.acid=dtd.acid
and dtd.tran_date =(select db_stat_date from gct)
and dtd.tran_crncy_code='INR'
and dtd.tran_date=dth.tran_date
and dtd.tran_id=dth.tran_id
and dtd.del_flg!='Y'
and dtd.pstd_flg='Y'
and dth.bank_id = dtd.bank_id 
and dtd.bank_id = gam.bank_id 
and gam.bank_id = '&1'
union
select dtd.sol_id ||'|'||dtd.tran_date||'|'||foracid||'|'||dtd.TRAN_ID||'|'||
part_tran_type||'|'||decode(part_tran_type,'C',1*tran_amt,-1*tran_amt)||'|'||
TRAN_PARTICULAR||'|'||
tran_rmks||'|'||dtd.rcre_user_id||'|'||dth.init_sol_id||'|'
FROM DTD,GAM,DTH
where foracid = '0036CCRECEIT'
and gam.sol_id = '0036'
and gam.acid=dtd.acid
and dtd.tran_date =(select db_stat_date from gct)
and dtd.tran_crncy_code='INR'
and dtd.tran_date=dth.tran_date
and dtd.tran_id=dth.tran_id
and dtd.del_flg!='Y'
and dtd.pstd_flg='Y'
and dth.bank_id = dtd.bank_id
and dtd.bank_id = gam.bank_id
and gam.bank_id = '&1'
union
select dtd.sol_id ||'|'||dtd.tran_date||'|'||foracid||'|'||dtd.TRAN_ID||'|'||
part_tran_type||'|'||decode(part_tran_type,'C',1*tran_amt,-1*tran_amt)||'|'||
TRAN_PARTICULAR||'|'||
tran_rmks||'|'||dtd.rcre_user_id||'|'||dth.init_sol_id||'|'
FROM DTD,GAM,DTH
where foracid = '6235CCRECEIT'
and gam.sol_id = '6235'
and gam.acid=dtd.acid
and dtd.tran_date =(select db_stat_date from gct)
and dtd.tran_crncy_code='INR'
and dtd.tran_date=dth.tran_date
and dtd.tran_id=dth.tran_id
and dtd.del_flg!='Y'
and dtd.pstd_flg='Y'
and dth.bank_id = dtd.bank_id
and dtd.bank_id = gam.bank_id
and gam.bank_id = '&1'
union
select dtd.sol_id ||'|'||dtd.tran_date||'|'||foracid||'|'||dtd.TRAN_ID||'|'||
part_tran_type||'|'||decode(part_tran_type,'C',1*tran_amt,-1*tran_amt)||'|'||
TRAN_PARTICULAR||'|'||
tran_rmks||'|'||dtd.rcre_user_id||'|'||dth.init_sol_id||'|'
FROM DTD,GAM,DTH
where foracid = '6235CCADVANCE'
and gam.sol_id = '6235'
and gam.acid=dtd.acid
and dtd.tran_date =(select db_stat_date from gct)
and dtd.tran_crncy_code='INR'
and dtd.tran_date=dth.tran_date
and dtd.tran_id=dth.tran_id
and dtd.del_flg!='Y'
and dtd.pstd_flg='Y'
and dth.bank_id = dtd.bank_id
and dtd.bank_id = gam.bank_id
and gam.bank_id = '&1'
order by 1
/
spool off
host mailx -s "CREDIT CARD DETAILS OF 0036 and 6235 ACCOUNTS" rajesh.rathod@icicibank.com < newcrcard.lst
host mailx -s "CREDIT CARD DETAILS OF 0036 and 6235 ACCOUNTS" arun.mudaliar@icicibank.com < newcrcard.lst
host mailx -s "CREDIT CARD DETAILS OF 0036 and 6235 ACCOUNTS" cardpaymentquery@icici.com < newcrcard.lst
host mailx -s "CREDIT CARD DETAILS OF 0036 and 6235 ACCOUNTS" creditcardpayment@icici.com < newcrcard.lst
exit
