----------------------------------------------------------------------------------------------------
--   Source Name            : Report_locledger1.sql
--   Description            : Locker Ledger Report.
--   Input Values           : None
--   Output Values          : None
--   Called Script          : N.A
--   Calling Script         : N.A
--   Modification History:
--   Sl No.         Date              Author                     Description
--   --------------------------------------------------------------------------------------
--     01         17-Oct-2012         Priyanka                 Original Version
----------------------------------------------------------------------------------------------------


SET SERVEROUTPUT ON size 1000000
set lines 650
set pages 0
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_locledger1.lst

DECLARE

v_solid                    gam.sol_id%type:='&1';
v_locker_num               wlckm.locker_num%type:='&2';      
DATE1               date := to_date('&3','dd-mm-yyyy');
DATE2               date := to_date('&4','dd-mm-yyyy');
v_bankid        clmt.bank_id%type  := '&5';
v_surstat                  lcsm.SURRENDER_DATE%type; 
V_DISCOUNT        number(10,2);
V_PREMIUM        number(10,2);
v_cif_id        CLMT.cif_id%type;

cursor c1(v_solid varchar2,v_locker_num varchar2,v_cif_id CLMT.cif_id%type,v_bankid varchar2) is 

select  distinct clmt.cif_id,
        cmg.cust_name hirer_name,
        wlckm.status||'-'||wlckm.remarks loc_status,
        clmt.issue_date allot_date,
        clmt.rent_amt actual_rent,
    (clmt.rent_amt - clmt.disc_rent_amt) discount,
        clmt.due_date NEXT_PAYMENT_DATE,
        clmt.disc_rent_amt net_rent,
        clmt.operation_mode,
        '' rent_revision_date,
        clmt.locker_num,
        wlckm.rack_id rack,
        clmt.locker_type type,
        substr(wlckm.SIZE_OF_LOCKER,1,2) hight,
        substr(wlckm.SIZE_OF_LOCKER,4,2) depth,
        substr(wlckm.SIZE_OF_LOCKER,7,2) width,
        wlckm.KEY_NUM
from    clmt,cmg,wlckm
where   clmt.cif_id = cmg.cif_id
and     clmt.locker_num = wlckm.locker_num
and    clmt.sol_id = wlckm.sol_id
and     clmt.locker_num = v_locker_num
and     clmt.sol_id = v_solid
and     clmt.bank_id = wlckm.bank_id
and    clmt.bank_id = v_bankid
and     clmt.cif_id = v_cif_id
and     clmt.ENTITY_CRE_FLG = 'Y'
and     clmt.del_flg !='Y';

BEGIN
    BEGIN
        --To select cust id for the given locker number--------
        SELECT DISTINCT cif_id
        INTO v_cif_id
        FROM CLMT
        WHERE sol_id = v_solid
        AND bank_id = v_bankid
        AND locker_num = v_locker_num
        AND del_flg !='Y';        
    EXCEPTION WHEN NO_DATA_FOUND THEN
        v_cif_id := null;
    END;
        
FOR f1 IN c1(v_solid,v_locker_num,v_cif_id,v_bankid)
LOOP
    BEGIN
        SELECT
                            SUM(AMOUNT)
                    INTO
                v_premium 
                    FROM
                            CLTLG
                    WHERE
                            LOCKER_NUM = v_locker_num
            AND cif_id = v_cif_id
            AND bank_id = v_bankid
            AND PARTICULARS NOT LIKE ('%RENT%') AND PARTICULARS LIKE ('%Prem%')
            AND del_flg!='Y'        
            AND APPLICABLE_DATE = ( select max(applicable_date) from cltlg
                                                where applicable_date <= DATE1
                                                and locker_num = v_locker_num
                        AND cif_id = v_cif_id
                        AND bank_id = v_bankid
                        AND del_flg!='Y');
                    EXCEPTION 
                    WHEN NO_DATA_FOUND THEN
                    V_PREMIUM := 0;
            END;
            
            BEGIN
                    SELECT
                            SUM(AMOUNT)
                    INTO
                            V_DISCOUNT
                    FROM
                            CLTLG
                    WHERE
                            LOCKER_NUM = v_locker_num
            AND cif_id = v_cif_id
            AND bank_id = v_bankid
            AND PARTICULARS NOT LIKE ('%RENT%') AND PARTICULARS NOT LIKE ('%Prem%')
            AND del_flg!='Y'        
            AND APPLICABLE_DATE = ( select max(applicable_date) from cltlg
                                                where applicable_date <= DATE1
                                                and locker_num = v_locker_num
                        AND cif_id = v_cif_id
                        AND bank_id = v_bankid
                        AND del_flg!='Y');
            EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                    V_DISCOUNT := 0;
            END;

            BEGIN
                                select lcsm.SURRENDER_DATE into v_surstat
                                from   lcsm
                                where  LOCK_NO = v_locker_num
                AND cif_id = v_cif_id
                AND bank_id = v_bankid;

                            exception when no_data_found then
                                v_surstat     := '';
            END;    

                 dbms_output.put_line ( f1.cif_id        ||'|'|| 
                    f1.hirer_name        ||'|'|| 
                    v_surstat               ||'|'||
                    f1.loc_status           ||'|'|| 
                    f1.allot_date           ||'|'|| 
                    f1.actual_rent        ||'|'|| 
                    v_discount        ||'|'|| 
                    v_premium        ||'|'|| 
                    f1.NEXT_PAYMENT_DATE    ||'|'|| 
                    f1.net_rent        ||'|'|| 
                    f1.operation_mode    ||'|'|| 
                    f1.rent_revision_date   ||'|'||
                    f1.locker_num           ||'|'|| 
                    f1.rack            ||'|'|| 
                    f1.type            ||'|'|| 
                    f1.hight        ||'|'|| 
                    f1.depth        ||'|'||
                    f1.width        ||'|'||
                    f1.key_num              
                                     );
END LOOP;
END;
/
spool off;

