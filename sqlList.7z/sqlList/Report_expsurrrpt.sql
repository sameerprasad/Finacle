--------------------------------------------
--File Name   : Report_expsurrrpt.sql 
--Description : Exceptional Surrender Report 
--Author      : Priyanka
--Date        : 06-10-2012
------------------------------------------

set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_expsurrrpt.lst

DECLARE

lv_solid        gam.sol_id%type :='&1';
date1		varchar2(25) :='&2';
date2		varchar2(25) :='&3';
lv_bankid       clmt.bank_id%type :='&4';

CURSOR c1 IS

select lcsm.sol_id,
       lcsm.locker_type,
       wlckm.rack_id,
       lcsm.LOCK_NO,
       '',
       lcsm.cust_name,
       clmt.issue_date,
       clmt.due_date,
       lcsm.SURRENDER_DATE,
       clcwt.RENT_WAIVED,
       clcwt.FILE_NO,
       clcwt.WAIVE_REMARKS
from lcsm,wlckm,clcwt,clmt
where  wlckm.LOCKER_NUM = clmt.LOCKER_NUM
and lcsm.sol_id = lv_solid 
and clmt.bank_id = lcsm.bank_id
and wlckm.bank_id = clcwt.bank_id
and clmt.bank_id = lv_bankid
and  clmt.LOCKER_NUM = clcwt.LOCKER_NUMBER 
and lcsm.LOCK_NO = clcwt.LOCKER_NUMBER
and lcsm.LOCK_NO = clmt.LOCKER_NUM
and lcsm.LOCK_NO = wlckm.LOCKER_NUM
and substr(lcsm.SURRENDER_DATE,1,10) between date1 and date2
ORDER by lcsm.lock_no;

BEGIN

    for f1 in c1
    loop
dbms_output.put_line(     f1.sol_id         ||'|'||
                          f1.locker_type    ||'|'||
                          f1.rack_id        ||'|'||
                          f1.lock_no        ||'|'||
                          ''                ||'|'||
                          f1.cust_name      ||'|'|| 
                          f1.issue_date     ||'|'||
                          f1.due_date	    ||'|'||
                          f1.SURRENDER_DATE ||'|'||
                          f1.RENT_WAIVED    ||'|'||  
                          f1.FILE_NO        ||'|'||
                          f1.WAIVE_REMARKS    ); 
   end loop;
   
END;
/
spool off

