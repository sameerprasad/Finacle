--#===================================================================================================================
--#Source Name            :  fsgrewards.sql
--#Description            :  Sql file for generating Report for Payback Numbers
--#Input Values           :  None	   
--#Output Values          :  Validation
--#Called Scripts         :  None
--#Calling Scripts        :  None
--#Modification history   :
--#Instance               :  BBY
--#Menu			:  ICIFSTMT
--#Sl. No            Date                 Author                       Description
--# ---------     --------------    ----------------------        ------------------------------
--#   1.0    	     29-03-2013  Supreeth V  and Pragnya Ghosh              Changes made for 10.x for CR-138-30632
--#=====================================================================================================================

set serveroutput on size 1000000
set head off
set linesize 512
set trims on
set pages 0
set feedback off
set verify off
set termout off
spool &1-&2-&3-&4

DECLARE

stmtReqd			ICICI_CIFT.stmt_reqd%type;
locListId			PSP_TMP.listid%TYPE;
locSolId			PSP_TMP.home_sol_id%TYPE;
locFrDate			date;
locToDate			date;
locLinkedFlg		char(1);
locTranDateBal		EAB.tran_date_bal%TYPE;
locCrncyCode		GAM.crncy_code%TYPE;
--locCustId			PSP_TMP.entity_id%TYPE;
locCifId                     PSP_TMP.entity_id%TYPE;
--locIdType			PSP_TMP.id_type%TYPE;
locIdType			varchar2(2);
locRunId			varchar2(10);
tdtOperAcid			gam.foracid%type;
tdtAcid				TDT.acid%TYPE;
fflAcid				FFL.acid%TYPE;
locOutRec			varchar2(500);
tdtDeposit			TDT.flow_amt%type;
tdtOpenDate			TDT.flow_date%type;
tdtDepMths			tdt.dep_period_mths%type;
tdtDepDays			tdt.dep_period_days%type;
tdtRate				tdt.actual_int_pcnt%type;
tdtRate2			tdt.actual_int_pcnt%type;
tdtMatDate			tdt.flow_date%type;
tdtMatAmt			tdt.flow_amt%type;
gamTxn				number;
fflTxn				number;
numIIflows			number;
flag				varchar2(5);
emailFlg			varchar2(2);
dispMode1			varchar2(2);
nomffdflg			varchar2(2);
nomsumflg			varchar2(2);
opr_bal             varchar2(25);
emailFmt			number;

smtflg				number;
-- VD Starts Here For Rewards Pts

payback_no                     VARCHAR2(20);
ern_pts                        VARCHAR2(20);
pts_flg                        VARCHAR2(1);
opn_pts                        VARCHAR2(20);
pts_ern                        VARCHAR2(20);
pts_reed                       VARCHAR2(20);
pts_bal                        VARCHAR2(20);
rew_cnt                        VARCHAR2(2);
tot_cnt                        VARCHAR2(2);
sav_cnt                        VARCHAR2(2);
prevdate                     VARCHAR2(10);
const                          VARCHAR2(10);
nre_flg                          VARCHAR2(2);



CURSOR	custCursor IS
SELECT	entity_id,home_sol_id
FROM	PSP_TMP
WHERE	listid = locListId
AND		home_sol_id = locSolId
AND     bank_id = '&10';

 -- VD Starts Here for multicurrency stmts

CURSOR	acctCursor IS
SELECT	acid,
		foracid,
		decode(substr(foracid, 5, 2), 
		'01', '1',
		'02', '1',
		'05', '2',
		'06', '2',
		'10', '3',
		'12', '3',
		'14', '3',
		'15', '3',
		'16', '3',
		'25', '3',
		'40', '3',
		'51', '4',
		'52', '4',
		'53', '4',
		'55', '4',
		'60', '4',
		'5') subRecType,
		decode(substr(foracid, 5, 2), 
		'01', 'Savings',
		'02', 'Savings',
		'05', 'Current',
		'06', 'Current',
		'10', 'Deposit',
		'12', 'Deposit',
		'14', 'Deposit',
		'15', 'Deposit',
		'16', 'Deposit',
		'25', 'Deposit',
                '31', 'Deposit',
		'40', 'Deposit',
		'51', 'Advance',
		'52', 'Advance',
		'53', 'Advance',
		'55', 'Advance',
		'60', 'Advance',
		'Other') acctType,
		 acct_cls_flg ,
		 acct_cls_date ,
		 acct_crncy_code, 
                 substr(GL_SUB_HEAD_CODE,1,2) gl_code
FROM	GAM 
WHERE	cif_id = locCifId
AND		((acct_cls_flg = 'N' AND acct_opn_date <= locToDate)
		OR		
		(acct_cls_flg = 'Y' AND acct_cls_date > locToDate))
AND		acct_crncy_code is not null
AND     ( (SCHM_CODE in ('RIDFC','REUSB','RGBSB','RUSSB')) OR (SCHM_TYPE = 'SBA')  OR (ACCT_PREFIX = '05') OR (ACCT_PREFIX = '51') OR (SCHM_TYPE = 'TDA') OR (SCHM_CODE in ('CFDFC', 'CFREU','CFRGB','CFRJY','CFRUS','RFDIS','RFEUD','RFEUH','RFEUH','RFGBH','RFJYD','RFUSD','RFUSH')) ) 
AND		del_flg != 'Y' 
AND		acct_ownership != 'O' 
AND		entity_cre_flg = 'Y'
AND             bank_id = '&10';
-- VD ends Here
BEGIN
	locRunId := '&1';
	locSolId := '&2';
	locIdType := '&4';
	locFrDate := '&5';
	locToDate := '&6';
	locCrncyCode := '&7';
	emailFlg     := '&8';
	dispMode1     := '&9';
	locListId := locRunId||locSolId||locIdType||'C';

	IF custCursor%ISOPEN THEN
		CLOSE custCursor;
	END IF;

	FOR custRec in custCursor 
	LOOP
	BEGIN
		locCifId := custRec.entity_id;
		IF acctCursor%ISOPEN THEN
			CLOSE acctCursor;
		END IF;
        sav_cnt :=0;
		tot_cnt :=0;
		if ( emailFlg = 'z') then 
		emailFlg := 'M';
		 end if;

      begin
--      select add_months(locFrDate,-1) into prevdate from DUAL;
      select add_months(locToDate,-1) into prevdate from DUAL;
	  end;

	 FOR acctRec in acctCursor
        LOOP
        BEGIN

 if (acctRec.acctType = 'Savings') then

-- VD added for rewards pts
  sav_cnt := sav_cnt + 1;
  begin
  const :='';
  nre_flg :=''; 
  select cust_const,CUST_NRE_FLG into const,nre_flg from cmg where cif_id = locCifId and bank_id = '&10';
  end;

 if ( (acctRec.acctType = 'Savings') and ( (const = 'R1') or (const = 'B1') ) and (acctRec.gl_code = '08') and (nre_flg != 'Y')) then

      	begin
 		select PAYBACK_NUMB,POINT_EARNED_SB,POINT_EARNED_DC,BALANCE into payback_no,opn_pts,pts_ern,pts_bal from ICICI_REWARDS_PT where FORACID=acctRec.foracid and 
  		( (POINT_EARNED_SB is not null) or (POINT_EARNED_DC is not null) or (BALANCE is not null) ) and bank_id = '&10';
--		FROM_DATE=locFrDate and TO_DATE=locToDate and ( (POINT_EARNED_SB is not null) or (POINT_EARNED_DC is not null) or (BALANCE is not null) );
        	exception
           	when others then
           	payback_no := 0;
           	opn_pts := 0;
           	pts_ern := 0;
           	pts_bal := 0;
       	end;


      begin
     	select count(*) into rew_cnt from ICICI_REWARDS_PT where PAYBACK_NUMB=payback_no 
		and foracid in (select foracid from gam,cmg where gam.cif_id=cmg.cif_id and gam.cif_id=locCifId 
		and cmg.cust_const in ('R1','B1') and cmg.CUST_NRE_FLG!='Y' and substr(GL_SUB_HEAD_CODE,1,2)='08' and substr(foracid, 5, 2) in ('01','02')
		and ((acct_cls_flg = 'N' AND acct_opn_date <= locToDate) OR (acct_cls_flg = 'Y' AND acct_cls_date > locToDate)) AND  acct_crncy_code is not null
		AND ( (SCHM_CODE in ('RIDFC','REUSB','RGBSB','RUSSB')) OR (SCHM_TYPE = 'SBA')  OR (ACCT_PREFIX = '05') OR (ACCT_PREFIX = '51') OR (SCHM_TYPE = 'TDA') 
		OR (SCHM_CODE in ('CFDFC', 'CFREU','CFRGB','CFRJY','CFRUS','RFDIS','RFEUD','RFEUH','RFEUH','RFGBH','RFJYD','RFUSD','RFUSH')) ) AND gam.del_flg != 'Y'
		AND acct_ownership != 'O' AND  GAM.entity_cre_flg = 'Y' and gam.bank_id = cmg.bank_id and gam.bank_id = '&10') and bank_id = '&10';
        exception
        when others then
        rew_cnt := 0;
      end;
      		if ( rew_cnt > 0) then
     				locOutRec := custRec.home_sol_id||'|'||custRec.entity_id||'|65||'||payback_no
                     ||'|'||acctRec.foracid||'|'||opn_pts||'|'||pts_ern||'|'||pts_bal||'|'||rew_cnt||'|'||prevdate||'| | | | |';
          			DBMS_OUTPUT.PUT_LINE(locOutRec);
				    tot_cnt := tot_cnt + 1;

     	          end if; 
   end if;

end if;

		END;
		END LOOP;


  begin
    const :='';
    nre_flg :='';
    select cust_const,CUST_NRE_FLG into const,nre_flg from cmg where cif_id = locCifId and bank_id = '&10';
  end;
    if ( (sav_cnt > 0) and ( (const = 'R1') or (const = 'B1') ) and  (nre_flg != 'Y')) then
		if ( tot_cnt = 0) then
		locOutRec := custRec.home_sol_id||'|'||custRec.entity_id||'|65||||||||'||prevdate||'|||||';
                DBMS_OUTPUT.PUT_LINE(locOutRec);
		end if;
    end if;


-- VD Ends Here


		EXCEPTION
		WHEN OTHERS THEN
			DBMS_OUTPUT.PUT_LINE('<#ORA-ERROR#>');
			DBMS_OUTPUT.PUT_LINE('Cust Id '||locCifId);
			DBMS_OUTPUT.PUT_LINE('Check SQL error,  and try again');
			DBMS_OUTPUT.PUT_LINE('Sql Error Code is        : ' || SQLCODE );
			DBMS_OUTPUT.PUT_LINE('SQL Error Description is : '|| SQLERRM);
	END;	
	END LOOP;
END;
/
spool off
