set head off
set echo off
set trims on
set pagesize 1000
set feedback off
set pages 0
set verify off

spool BatchJobStatus
select '				Batch Job Execution Status Report as on	'||to_char(sysdate, 'dd-mm-yyyy hh24:mm:ss') from dual 
/
select '				-------------------------------------------------------------' from dual
/
select 'Sol Id	Job Id	Job Description		Job Type	Last Exec Next Exec 	Type of' from dual
/
select '											Date	  Date	batch job' from dual
/
select '------------------------------------------------------------------------------' from dual
/
select sol_id, job_id, job_desc, job_type, lchg_time, next_exec_date,exec_db_stat_code from bjs 
where 
sol_id in (select sol_id from sst where set_id = '&2')
and job_id = lpad('&1', 5, ' ')
and del_flg != 'Y'
and job_active_flg = 'Y'
and next_exec_date <= (select db_stat_date from gct where bank_id='&5')
and exec_stop_date > (select db_stat_date from gct where bank_id='&5')
and bjs.sol_id not between '0101' and '0127' and bank_id='&5'
union all
select sol_id, job_id, job_desc, job_type, lchg_time, next_exec_date,exec_db_stat_code from bjs 
where 
sol_id in (select sol_id from sst where set_id = '&4')
and job_type = lpad('&3', 5, ' ')
and del_flg != 'Y'
and job_active_flg = 'Y'
and next_exec_date <= (select db_stat_date from gct where bank_id='&5')
and exec_stop_date > (select db_stat_date from gct where bank_id='&5')
and bjs.sol_id not between '0101' and '0127' and bank_id='&5' 
/
spool off
