-- #############################################################
-- #	Source Name: pymtDlqHis.sql				   		       #
-- #	Description: This script is used to get the required   #
-- #				 details for ROD payments and delinquency  #
-- #				 history details						   #
-- #				 in ~ seperated format.                    #
-- #############################################################

Set ServerOutPut On Size 1000000
--Set Verify Off
--Set FeedBack off
--set line 80
set trims on

--Spool pymtDlqHis.txt

DECLARE

inpDate				varchar2(25);

-- Temporary variables.
payment				UTL_FILE.FILE_TYPE;
lndlqhis			UTL_FILE.FILE_TYPE;
tmpAcid				GAM.acid%type;
acnum				GAM.foracid%type;
effdate				ROBT.last_adj_value_date%type;
paynumb				number(4) := 1;
det_line1			varchar2(1000) := '';
dayslate			GAC.dpd_cntr%type;
duedate				ROBT.payment_due_date%type;
duebasedt			ROBT.stmt_end_date%type;
effChar				varchar2(10);
dueChar				varchar2(10);
duebaseChar			varchar2(10);
det_line2			varchar2(1000) := '';
l_bank_id			VARCHAR2(8) := '&2';

CURSOR 	RSP_CURSOR IS 
	SELECT 	gam.acid,foracid,gac.dpd_cntr
	FROM 	gam,gac
	WHERE 	gam.acid = gac.acid
	AND		gam.schm_code in (	select 	distinct schm_code 
								from 	RSP 
								where 	entity_cre_flg = 'Y'
								and 	del_flg != 'Y')
	AND		gac.dpd_cntr >= 1
	AND		gam.entity_cre_flg = 'Y'
	AND		gam.del_flg != 'Y'
	AND	        gam.bank_id = l_bank_id
	AND	        gac.bank_id = l_bank_id
	ORDER BY acid;


BEGIN
--{
	inpDate := '&1';

	payment		:= UTL_FILE.FOPEN('/tmp','ex_payment.csv','w');
	lndlqhis	:= UTL_FILE.FOPEN('/tmp','ex_lndlqhis.csv','w');

	OPEN RSP_CURSOR;

	LOOP
	--{
		acnum := NULL;
	
		FETCH RSP_CURSOR into 	tmpAcid,acnum,dayslate;

		EXIT WHEN RSP_CURSOR%NOTFOUND;
		
		IF (acnum is NOT NULL) THEN
		--{
			payNumb := 1;
			effdate := NULL;
			duedate := NULL;
			
			BEGIN
			--{
				SELECT 	stmt_end_date,payment_due_date
				INTO	duebasedt,effdate
				FROM 	ROBT
				WHERE	acid = tmpAcid
				AND		stmt_end_date =(select	max(stmt_end_date)
										from	ROBT
										WHERE	acid = tmpAcid
										AND	bank_id = l_bank_id)
				AND		lchg_time >= to_date(inpDate,'DD-MM-YYYY HH24:MI:SS')
				AND		bank_id = l_bank_id;
			EXCEPTION 
				WHEN OTHERS THEN 
				effdate 	:= NULL;
				duebasedt 	:= NULL;
			--}
			END;
			
			duedate := effdate;

			begin
			--{
				select	to_char(duedate,'mm-dd-yyyy'),to_char(effdate,'mm-dd-yyyy'),to_char(duebasedt,'mm-dd-yyyy')
				into	dueChar,effChar,duebaseChar
				from	DUAL;
			exception
				WHEN OTHERS THEN NULL;
			--}
			end;

--			if (effdate is NOT NULL) then
			--{
				det_line1 := acnum||'~'||duebaseChar||'~'||effChar||'~~5~'||payNumb;
				UTL_FILE.PUT_LINE(payment,det_line1);
			--}
--			end if;

--			if (duedate is NOT NULL) then
			--{
--***		Can display only the latest dayslate
				det_line2 := acnum||'~'||dueChar||'~1~'||dayslate||'~';
				UTL_FILE.PUT_LINE(lndlqhis,det_line2);
			--}
--			end if;
		--}
		END IF;
	--}
	END LOOP;

	UTL_FILE.FCLOSE(payment);
	UTL_FILE.FCLOSE(lndlqhis);
	CLOSE RSP_CURSOR;
--}
END;
/
exit
--spool off
