DROP SEQUENCE ICICI.customsuppcrrefno_seq;

CREATE SEQUENCE ICICI.customsuppcrrefno_seq
  START WITH 8055
  MAXVALUE 999999999
  MINVALUE 8001
;

DROP PUBLIC SYNONYM tba_customsuppcrrefno_seq;

CREATE PUBLIC SYNONYM tba_customsuppcrrefno_seq FOR ICICI.customsuppcrrefno_seq;


GRANT SELECT ON ICICI.customsuppcrrefno_seq TO TBAGEN;

