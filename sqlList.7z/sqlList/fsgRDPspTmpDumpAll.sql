
-- Program Name    : fsgPspTmpDump.sql
-- Author          : Mandar Raddi
-- Date Written	   : 27-Feb-2001
--
-- -----------------------------------------------------------------------------------#   
-- Brief Description :                                                                #
-- -----------------------------------------------------------------------------------#
-- This PL/SQL program is responsible for creating Customer ID and Accout ID lists    #
-- in the PSP_TMP table for the given Sol ID. These two lists are required in the     #
-- Customer Statement generation process. This program creates the List id as         # 
-- Run ID (Input to the program) + 'C' for customer ids and Run ID + 'A' for accounts #
-- for the customers.                                                                 #
-- -----------------------------------------------------------------------------------# 
--                                 Version History                                    #
-- -----------------------------------------------------------------------------------#
--   Ver.No |     Date   |    Author    |           Reason For Change                 #
-- -----------------------------------------------------------------------------------#
--     1    | 27-02-2001 | Mandar Raddi | Initial Release                             #
--     2    | 03-01-2013 | Aneesh S     | Changed table from cmg to cnma              #
-- -----------------------------------------------------------------------------------#

set serveroutput on size 1000000
set feedback off
set verify   off
set termout   off
set pages 0
set linesize 512
set trims on
spool &1-&2-&3-&4

variable maxIdType char(1);
-- -------------------------#
-- Start of DELCARE Section 
-- -------------------------#

DECLARE
cnt					number;
wbgCust				char(1);
firstAcc			GAM.FORACID%Type;
beginCustId			ICICI_CIFT.CIF_ID%Type;
endCustId			ICICI_CIFT.CIF_ID%Type;
ciftCustId			ICICI_CIFT.CIF_ID%Type;
ciftEmailId			ICICI_CIFT.EMAIL_ID%Type;
ciftStmtReqd		ICICI_CIFT.STMT_REQD%Type;
stmtReqd			CHAR;
cmgCustStatCode		CMG.CUST_STAT_CODE%Type;
gamForacid			GAM.FORACID%Type;
gamAcid				GAM.ACID%Type;
custSolId			PSP_TMP.HOME_SOL_ID%Type;
custRecType			VARCHAR(3);
custSubRecType		VARCHAR(3);
pspCustListId		PSP_TMP.LISTID%Type;
pspAcctListId		PSP_TMP.LISTID%Type;
endOfCiftCursor     NUMBER;
endOfGamCursor      NUMBER;
acctFound			NUMBER;
gamTxn				NUMBER;
chooseThisCustId    CHAR;
custStatSelectFlag  CHAR;
-- Sri 3.7.02 begin
stmtFreq			char;
custSel				char;
custStat			CMG.CUST_STAT_CODE%Type;
accExist			number(1);
cfgKeyVal			varchar(5);
-- Sri 3.7.02 end
custStatArr 		iciArray.arrayType;
custStatCodes		VARCHAR2(100);
custStatCnt			NUMBER(5);
commitCnt			NUMBER(5);
step				NUMBER(5);
likeStr				varchar2(25);
likeStrAcc			varchar2(25);
likeStrCus			varchar2(25);
idType				CHAR(1);
dispMode      		CHAR;
-- Changes for custnreflg
cmgCustNreFlag		cmg.cust_nre_flg%type;
	
cmgTitleName		varchar2(200);
--cmgAddr1			CMG.cust_comu_addr1%TYPE;
cmgAddr1			CNMA.ADDRESS1%TYPE;
--cmgAddr2			CMG.cust_comu_addr2%TYPE;
cmgAddr2			CNMA.ADDRESS2%TYPE;
--cmgCityCode			CMG.cust_comu_city_code%TYPE;
cmgCityCode			CNMA.CITY_CODE%TYPE;
--cmgStateCode		CMG.cust_comu_state_code%TYPE;
cmgStateCode		CNMA.STATE_CODE%TYPE;
--cmgCntryCode		CMG.cust_comu_cntry_code%TYPE;
cmgCntryCode		CNMA.CNTRY_CODE%TYPE;
--cmgPinCode			CMG.cust_comu_pin_code%TYPE;
cmgPinCode			CNMA.PIN_CODE%TYPE;
--cmgPhone1			CMG.cust_comu_phone_num_1%TYPE;
cmgPhone1			CNMA.PHONE_NUM1%TYPE;
--cmgPhone2			CMG.cust_comu_phone_num_2%TYPE;
cmgPhone2			CNMA.PHONE_NUM2%TYPE;
cityDesc			RCT.ref_desc%TYPE;
stateDesc			RCT.ref_desc%TYPE;
cntryDesc			RCT.ref_desc%TYPE;

-- Sri 13-01-2003
cmgCustConst		CMG.cust_const%TYPE;
custConst			CMG.cust_const%TYPE;
cmgConstKey			CMG.cust_const%TYPE;
tmpConst			CMG.cust_const%TYPE;
-- Sri 13-01-2003

carRec				varchar2(500);
runId				varchar2(10);

CURSOR ciftCur IS
SELECT  CIF_ID, lower(EMAIL_ID), stmt_reqd
FROM ICICI_CIFT
WHERE   CIF_ID BETWEEN beginCustId AND endCustId
AND HOME_SOL_ID = custSolId
AND STMT_REQD != 'N'
AND BANK_ID = '&13'
ORDER BY cif_id;

CURSOR gamCur IS
SELECT  cif_id,acid,foracid
FROM    GAM A
WHERE   CIF_ID = ciftCustId
AND SCHM_TYPE = 'TDA' AND ACCT_PREFIX = '25'
AND NOT EXISTS 
(
SELECT CIF_ID FROM GAM WHERE   CIF_ID = A.cif_id AND SCHM_TYPE IN ('SBA','CAA','ODA','CCA')
AND ACCT_CLS_FLG = 'N'
)
AND ((ACCT_CLS_FLG = 'N' AND ACCT_OPN_DATE <=to_date('&8','dd-mm-yyyy')) OR
     (ACCT_CLS_FLG = 'Y' AND ACCT_CLS_DATE > to_date('&8','dd-mm-yyyy')))
AND ENTITY_CRE_FLG = 'Y'
and last_any_tran_date >= to_date('&7','dd-mm-yyyy')AND BANK_ID = '&13' order by foracid;


-- --------------------------------------------------------------------------------#
-- PROCEDURE to Select customer details from CMG. The customer id is selected from #
-- ICICI_CIFT for the input SOL ID                                                 #
-- --------------------------------------------------------------------------------#

PROCEDURE getCmgData(dummy NUMBER) IS
BEGIN
	BEGIN
		step := 3;
		SELECT  cmg.cust_title_code || '.' || cmg.cust_name,
                	cnma.ADDRESS1,
                	cnma.ADDRESS2,
                	cnma.CITY_CODE,
                	cnma.STATE_CODE,
                	cnma.CNTRY_CODE,
                	cnma.PIN_CODE,
                	phone_num1,
                	phone_num2,
                	cmg.cust_stat_code,
			cmg.cust_const,
                	cmg.cust_nre_flg
		INTO	cmgTitleName,
				cmgAddr1,
				cmgAddr2,
				cmgCityCode,
				cmgStateCode,
				cmgCntryCode,
				cmgPinCode,
				cmgPhone1,
				cmgPhone2,
				cmgCustStatCode,
				cmgCustConst,
				cmgCustNreFlag
		--FROM	CMG
		--WHERE	CIF_ID = ciftCustId AND BANK_ID = '&13';
		FROM    CRMUSER.CMG,crmuser.cnma
--      WHERE   CIF_ID = custId;
        	WHERE   CIF_ID = ciftCustId
        	AND cnma.ADDR_B2KID=cmg.CIF_ID
        	AND cnma.ADDR_ID = cmg.ADDRESS_TYPE
        	AND CMG.BANK_ID='&13'
        	AND cnma.BANK_ID = '&13';

		if(cmgCustNreFlag = 'Y') then
			cmgCustStatCode := 'NRI';
		end if;

		if(substr(cmgCustStatCode,1,3) = 'HNI') then
				cmgCustStatCode := 'HNI';
		end if;

		if (cmgCityCode is not null) then
			BEGIN
			SELECT	ref_desc
			INTO	cityDesc
			FROM	RCT
			WHERE	ref_rec_type = '01'
			AND		ref_code = cmgCityCode
			AND BANK_ID = '&13';
			EXCEPTION WHEN OTHERS THEN NULL;
			END;
		else
			cityDesc := '';
		end if;

		if (cmgStateCode is not null) then
			BEGIN
			SELECT	ref_desc
			INTO	stateDesc
			FROM	RCT
			WHERE	ref_rec_type = '02'
			AND		ref_code = cmgStateCode
			 AND BANK_ID = '&13';
			EXCEPTION WHEN OTHERS THEN NULL;
			END;
		else
			stateDesc := '';
		end if;

		if (cmgCntryCode is not null) then
			BEGIN
			SELECT	ref_desc
			INTO	cntryDesc
			FROM	RCT
			WHERE	ref_rec_type = '03'
			AND		ref_code = cmgCntryCode
			 AND BANK_ID = '&13';
			EXCEPTION WHEN OTHERS THEN NULL;
			END;
		else
			cntryDesc := '';
		end if;

		EXCEPTION
		WHEN NO_DATA_FOUND THEN 
			chooseThisCustId := 'N';
			RETURN;
	END;

	IF (custStatSelectFlag = 'O') THEN
		chooseThisCustId := 'N';
	ELSE
		chooseThisCustId := 'Y';
	END IF;

	FOR item IN 0..TO_NUMBER(custStatCnt - 1) LOOP
	BEGIN
		IF (custStatSelectFlag = 'E' AND cmgCustStatCode = custStatArr(item)) THEN
			chooseThisCustId := 'N';
			RETURN;
		END IF;
		IF (custStatSelectFlag = 'O' AND cmgCustStatCode = custStatArr(item)) THEN
			chooseThisCustId := 'Y';
			RETURN;
		END IF;
	END;
	END LOOP;

END getCmgData;


PROCEDURE insertPspTmp( pspListId VARCHAR2,
	                pspEntityId VARCHAR2,
	                pspEntityType CHAR,
			pspHomeSolId VARCHAR2) IS
BEGIN
	step := 5;
	INSERT INTO
	PSP_TMP
		(LISTID
		,ENTITY_ID
		,ID_TYPE
		,HOME_SOL_ID,
		 BANK_ID)
	VALUES
		(pspListId
		,pspEntityId
		,pspEntityType
		,pspHomeSolId
		,'&13');
		commit;
END insertPspTmp;


PROCEDURE processGamCursor( dummy NUMBER) IS
BEGIN
step := 4;
FOR gamCur_rec in gamCur
LOOP --{
    begin
	IF( gamCur%NOTFOUND ) then
		endOfGamCursor := 1;
		RETURN;
	END IF; 
	gamTxn := 0;
	begin
       	SELECT	1
		INTO	gamTxn
		FROM	DUAL
		WHERE	EXISTS(	SELECT	*
						FROM	CTD 
						WHERE	acid=gamCur_rec.acid
						AND		tran_date >= '&7'
						AND 	tran_date <= '&8'
						 AND BANK_ID = '&13');
		EXCEPTION
		WHEN NO_DATA_FOUND THEN
			gamTxn := 0;
	end;
	if(gamTxn > 0) then
		acctFound := 1;	
		insertPspTmp(pspAcctListId, gamCur_rec.foracid, idType, custSolId);
	end if;
	if (cnt = 0) then
		firstAcc := gamCur_rec.foracid;
		cnt := 1;
	end if;
    end;
end loop; --}
END processGamCursor;
		

PROCEDURE processCiftCursor( dummy NUMBER ) IS
BEGIN
	step := 2;
	FETCH ciftCur 
	INTO ciftCustId,
		ciftEmailId,
		ciftStmtReqd;

	IF (ciftCur%NOTFOUND) then
		endOfCiftCursor := 1;
		RETURN;
	END IF;

	-- Sri 3.7.02 (begins here)

	if(stmtFreq = 'Q') then

		--
		-- By default select all customers
		--

		custSel := 'Y';

		-- Check for stmt_reqd. If Y / E, select customer

        if(ciftStmtReqd = 'Y' or ciftStmtReqd = 'E') then
            custSel := 'Y';
        end if;

		ciftStmtReqd := 'Y';

		if(custSel = 'N') then
			return;
		end if;

	end if;

	-- Sri 3.7.02 (ends here)

	getCmgData(0);

	IF (chooseThisCustId = 'N') THEN
		RETURN;
	END IF;

	endOfGamCursor := 0;
	acctFound := 0;
	cnt := 0;
	stmtReqd := ciftStmtReqd;
	firstAcc := '';
	processGamCursor(0);

	if((acctFound = 1 or ciftStmtReqd = 'E') and cnt > 0 ) then
		insertPspTmp(pspCustListId, ciftCustId, idType, custSolId);

		if (ciftStmtReqd = 'E' ) then
			dbms_output.put_line(custSolId||'|'||ciftCustId||'|01|0|'||
                                ciftEmailId||'|'||ltrim(rtrim(cmgTitleName))||'|'||
                                ltrim(rtrim(cmgAddr1))||'|'||ciftCustId||'|'||
                                ltrim(rtrim(cityDesc))||'|'||ltrim(rtrim(stateDesc)) ||'|'||
                                ltrim(rtrim(cntryDesc))||' - '||ltrim(rtrim(cmgPinCode)) ||'|'||
                                cmgCustStatCode||'|'||ciftStmtReqd||'|'||firstAcc||'|'||'CustomerStateMent'||'|'||tmpConst);
		else
			carRec := custSolId||'|'||ciftCustId||'|01|0|'||'|'||
			ltrim(rtrim(cmgTitleName))||'|'||ltrim(rtrim(cmgAddr1))||'|'||
			ltrim(rtrim(cmgAddr2))|| '|' ||ltrim(rtrim(cityDesc))||'|'||
			ltrim(rtrim(stateDesc))||'|'||ltrim(rtrim(cntryDesc))||' - '||
			ltrim(rtrim(cmgPinCode))||'|'||cmgCustStatCode||'|'||'Y'||'|'||
			ltrim(rtrim(cmgPhone1))||' - '||ltrim(rtrim(cmgPhone2)) || '||'||tmpConst;

			if(length(carRec) > 255) then
				carRec := custSolId||'|'||ciftCustId||'|01|0|'||'|'||
				ltrim(rtrim(cmgTitleName))||'|'||ltrim(rtrim(cmgAddr1))||'|'||
				ltrim(rtrim(cmgAddr2))|| '|' ||ltrim(rtrim(cityDesc))||'|'||
				ltrim(rtrim(stateDesc))||'|'||ltrim(rtrim(cntryDesc))||' - '||
				ltrim(rtrim(cmgPinCode))||'|'||cmgCustStatCode||'|'||'Y'||'|'||'||'||tmpConst;
				dbms_output.put_line(carRec);
			else
				dbms_output.put_line(carRec);
			end if;
		end if;
	end if;
END processCiftCursor;


BEGIN
	cnt					:= 0;
	runId				:= '&1';
	custSolId			:= '&2';
	idType				:= '&4';
	--beginCustId			:= lpad('&5', 9);
	beginCustId			:= '&5';
	--endCustId			:= lpad('&6', 9);
	endCustId			:= '&6';
	custStatSelectFlag	:= '&9';
	custStatCodes 		:= '&10';
	dispMode 			:= '&11';
	-- Sri 3.7.02
	stmtFreq			:= '&12';

	pspCustListId		:= runId||custSolId||idType||'_C';
	pspAcctListId		:= runId||custSolId||idType||'_A';

	commitCnt := 0;

	custRecType			:= '01';
	custSubRecType		:= '0';

	likeStr		:= runId||custSolId||idType||'_%';

	step := 1;
	iciArray.construct(custStatCodes, ',' , custStatCnt, custStatArr);

	if(idType != '_') then
 		DELETE FROM
 			PSP_TMP
 		WHERE
 			LISTID LIKE likeStr 
 			AND home_sol_id = custSolId AND BANK_ID = '&13';
 	else
 		likeStrAcc := runId||custSolId||idType||'_A';
 		likeStrCus := runId||custSolId||idType||'_C';
 		DELETE FROM PSP_TMP WHERE LISTID = likeStrAcc and home_sol_id = custSolId AND BANK_ID = '&13';
 		DELETE FROM PSP_TMP WHERE LISTID = likeStrCus and home_sol_id = custSolId AND BANK_ID = '&13';
 	end if;
	
 	COMMIT;

	OPEN ciftCur;

	endOfCiftCursor := 0;

	WHILE (endOfCiftCursor = 0) LOOP
		processCiftCursor(0);
		commitCnt := commitCnt + 1;
		IF (commitCnt = 1000) THEN
			COMMIT;
			commitCnt := 0;
		END IF;
	END LOOP;

	CLOSE ciftCur;

	COMMIT;

	EXCEPTION
	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('<#ORA-ERROR#>');
		DBMS_OUTPUT.PUT_LINE('Cust Id/Account Id list creation failed at step...'||step);
		DBMS_OUTPUT.PUT_LINE('Cust Id '||ciftCustId);
		DBMS_OUTPUT.PUT_LINE('Check SQL error,  and try again');
		DBMS_OUTPUT.PUT_LINE('Sql Error Code is        : ' || SQLCODE );
		DBMS_OUTPUT.PUT_LINE('SQL Error Description is : '|| SQLERRM);
		ROLLBACK;
		DBMS_OUTPUT.PUT_LINE('Currenct Chunk rolled back.');
END;
/
spool off
