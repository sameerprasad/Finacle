rem accept solid prompt "ENTER YOUR FOUR DIGIT SOL ID   ::::"
rem accept start_date prompt "ENTER START-DATE IN DD-MM-YYYY FORMAT ::::" 
rem accept end_date prompt   "ENTER TO-DATE IN DD-MM-YYYY FORMAT    ::::" 
set verify off
set echo off
set feedback off
set termout off
rem AUTHOR: BURZIN/IT DEPT/mumbai
rem DATE::  30/07/1999
rem MODIFIED BY : K CHANDRA SEKHAR
rem This sql gives the segregation of regional expenses
rem made by branches on behalf of Regional/corporate office
set linesize 132
set pagesize 66
col bn new_value sld
select br_name bn from bct where br_code=(select br_code from sol where
					  sol_id = '&1');  
break on ACCOUNT on report 
compute sum of TRANAMOUNT on ACCOUNT 
compute sum of TRANAMOUNT on report 
spool &1.rodetail

column TRANAMOUNT format 99999999.99
ttitle center 'DETAILS OF REGIONAL OFFICE EXPENSES' skip 1- 
center 'DEBITED BY '&sld' BRANCH ON BEHALF' skip 1-
center 'OF REGIONAL OFFICE FOR THE PERIOD &2 TO &3' skip 3  

select  gam.foracid ACCOUNT, 
		htd.tran_date TRANDATE,
		htd.tran_id TRANID, 
		htd.tran_amt TRANAMOUNT,
		substr(htd.tran_particular,1,20) PARTICULARS,
		htd.tran_rmks REMARKS 
from htd,gam 
where gam.acid = htd.acid 
and gam.sol_id = '&1'
and htd.sol_id = '&1'
and ltrim(htd.rpt_code)='RO' 
and htd.tran_date between to_date('&2','dd-mm-yyyy')
and to_date('&3','dd-mm-yyyy')
and gam.schm_code='OANDR'
and gam.bank_id ='&4'
order by ACCOUNT
/
spool off
exit

