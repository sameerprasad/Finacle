--STR : 6285/7085
set serveroutput on size 1000000
set feedback off
set verify off
set linesize 500
set trims on
set termout off
set echo off
spool exp_bill_pur_FOBP.lst 

DECLARE
short_realisation gam.clr_bal_amt%type;
tot_nostro gam.clr_bal_amt%type;
date1 fbh.vfd_bod_date%type ; 
solid1 sst.set_id%type :='&1';
regtype varchar(4);
event_amt fbh.event_amt%type;
fr_bank_charge fbh.fr_bank_charge%type;
fb_comm fbh.fb_comm_amt%type;
postage fbh.fb_pnt_charge%type;
trandate fae.tran_date%type;
amt pst.amt_sold%type;
cnt number(2);
baserate pst.base_rate%type;
loc_regsubtype fbm.reg_sub_type%type;
loc_crncy fbm.bill_crncy_code%type;
loc_rate pst.rate%type;
puramt pst.AMT_PURCHSD%type;
billamt fbm.bill_amt%type;
locsol fbm.sol_id%type;
cntr1 number:=0;
nostroref fae.ref_num%type;
valuedate fae.value_date%type;
V_COUNT NUMBER;



CURSOR fbh_cur is
select m.sol_id,m.bill_id,m.reg_type,m.reg_sub_type,m.bill_amt,m.bp_acid,m.oper_acid,m.bill_crncy_code,m.bill_stat,f.event_amt,f.event_rate,f.bill_func,f.vfd_bod_date
from fbm m,fbh f
where
	m.sol_id = f.sol_id
and m.bill_id = f.bill_id
and m.reg_type='FOBP'
and m.bill_stat in ('R','Z','J','P')
and m.entity_cre_flg='Y'
and m.del_flg!='Y'
and m.sol_id in (select sol_id from sst where set_id = upper(solid1))
and f.bill_func='R'
and f.vfd_bod_date = date1 and m.bank_id='&2' and f.bank_id='&2'
and exists (select bill_id from fbh h where h.sol_id = m.sol_id and h.bill_id = m.bill_id and h.bill_func='P' and h.bank_id='&2');


cursor fae_pur (inp_sol fae.sol_id%type,inp_bill fae.bill_id%type) is
select  p.base_rate,p.TREA_REF_NUM,p.amt_purchsd,p.pst_date
from fae x,pst p
where
	x.tran_date =p.tran_date
and	x.tran_id = p.tran_id
and	x.part_tran_srl_num = p.part_tran_srl_num
and x.sol_id = inp_sol
and x.bill_id = inp_bill
and p.crncy_purchsd<> p.crncy_sold
and p.pst_type='BP'
and x.bill_func = 'P'
and x.bank_id='&2' and p.bank_id='&2';


cursor fae_rel (inp_sol fae.sol_id%type,inp_bill fae.bill_id%type) is
select  p.pst_date,p.rate,p.base_rate,p.amt_purchsd
from fae x,pst p
where
        x.tran_date =p.tran_date
and     x.tran_id = p.tran_id
and     x.part_tran_srl_num = p.part_tran_srl_num
and x.sol_id = inp_sol
and x.bill_id = inp_bill
and p.crncy_purchsd<> p.crncy_sold
and p.pst_type='RS'
and x.bill_func = 'R'
and x.bank_id='&2' and p.bank_id='&2';


BEGIN
	select db_stat_date into date1 from gct;
FOR a IN fbh_cur
LOOP

	begin
		SELECT sum(nvl(event_amt,0)),sum(nvl(fr_bank_charge,0)),sum(nvl(fb_comm_amt,0)),sum(nvl(fb_pnt_charge,0))
		INTO event_amt,fr_bank_charge,fb_comm,postage
  		FROM FBH
 		WHERE sol_id = a.sol_id
		AND bill_id = a.bill_id
 		AND bill_func = 'R'
 		AND vfd_bod_date = date1
		AND bank_id='&2'
 		group by bill_id; 
	exception
		when no_data_found then
		event_amt :=0;
		fr_bank_charge :=0;
		fb_comm :=0;
		postage :=0;
	end;
		short_realisation := fr_bank_charge + fb_comm + postage;
		tot_nostro        := event_amt - short_realisation; 

	begin
		select count(*) INTO cnt  from fbh where bill_id=a.bill_id and bill_func='H' and bank_id='&2';
	end;
	begin
		select sol_id,reg_sub_type,bill_crncy_code,bill_amt 
		INTO   locsol,loc_regsubtype,loc_crncy,billamt
		from   fbm 
		where  sol_id = a.sol_id
		AND   bill_id = a.bill_id
		AND   bank_id='&2';
	exception
		when no_data_found then
		billamt := 0;
	end;
			if (loc_regsubtype = 'U' OR loc_regsubtype = 'ULC') then
					regtype := 'FBPU';
			elsif (loc_regsubtype = 'S' OR loc_regsubtype = 'SLC') then
					regtype := 'FBPS';
			end if;
	begin
    	select 	ref_num ,value_date 
		INTO	nostroref,valuedate 
		from 	fae 
		where 	sol_id =a.sol_id 
		and 	bill_id=a.bill_id
    	and bill_func='R' and PTRAN_INDEX='0' and tran_date = date1
    	and rownum<2 and bank_id='&2';
    exception
    when no_data_found then
    	nostroref :=null;
    end;

    for b in fae_pur(a.sol_id,a.bill_id)
    loop
		begin
		V_COUNT :=0;
		for c in fae_rel(a.sol_id,a.bill_id)
		loop
			begin
  				dbms_output.put_line(a.bill_id||'|'||a.bill_crncy_code||'|'||a.bill_amt||'|'||b.AMT_PURCHSD||'|'||short_realisation||'|'||tot_nostro||'|'||b.pst_date||'|'||valuedate||'|'||b.TREA_REF_NUM ||'|'||b.base_rate||'|'||regtype||'|'||c.base_rate||'|'|| nostroref);
				V_COUNT:=NVL(fae_rel%ROWCOUNT,0);
			end;
		end loop;
		if (V_COUNT = 0  ) then
  			dbms_output.put_line(a.bill_id||'|'||a.bill_crncy_code||'|'||a.bill_amt||'|'||b.AMT_PURCHSD||'|'||short_realisation||'|'||tot_nostro||'|'||b.pst_date||'|'||valuedate||'|'||b.TREA_REF_NUM||'|'||b.base_rate||'|'||regtype||'|'||null||'|'||nostroref);
			nostroref:=null;
		end if;
		end;
	end loop;
		nostroref:=null;
END LOOP;

END;
/
spool off
