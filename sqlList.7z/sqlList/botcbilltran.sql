set head off
set feedback off
set termout off
set echo off
set verify off
set serveroutput on
spool botc_trans
declare

cursor billtran (inp_tran_id tbaadm.ctd.tran_id%type, trandate tbaadm.ctd.tran_date%type) is
select foracid,tbaadm.ctd.gl_sub_head_code, tran_crncy_code,tran_amt, part_tran_type, part_tran_srl_num, tran_particular,tbaadm.ctd.rate from gam, tbaadm.ctd where gam.acid=tbaadm.ctd.acid and tbaadm.ctd.tran_id=inp_tran_id and tran_date = trandate and tbaadm.ctd.del_flg!='Y' 
union
select foracid,dtd.gl_sub_head_code, tran_crncy_code,tran_amt, part_tran_type, part_tran_srl_num,
tran_particular,dtd.rate from gam, dtd where gam.acid=dtd.acid and dtd.tran_id=inp_tran_id and tran_date = trandate and dtd.del_flg!='Y'
order by part_tran_srl_num;

cursor hobilltran (inp_ho_tran_id tbaadm.ctd.tran_id%type, ho_trandate tbaadm.ctd.tran_date%type) is
select foracid,tbaadm.ctd.gl_sub_head_code, tran_crncy_code,tran_amt, part_tran_type, part_tran_srl_num, tran_particular,tbaadm.ctd.rate from gam, tbaadm.ctd where gam.acid=tbaadm.ctd.acid and tbaadm.ctd.tran_id=inp_ho_tran_id and tran_date = ho_trandate and tbaadm.ctd.del_flg!='Y' 
union
select foracid,dtd.gl_sub_head_code, tran_crncy_code,tran_amt, part_tran_type, part_tran_srl_num,
tran_particular,dtd.rate from gam, dtd where gam.acid=dtd.acid and dtd.tran_id=inp_ho_tran_id and tran_date = ho_trandate and dtd.del_flg!='Y'
order by part_tran_srl_num;

cursor pstdata (billref tbaadm.pst.bill_ref_num%type, billtrandate tbaadm.pst.tran_date%type) is
select tran_id, tran_date, ho_tran_id, ho_tran_date from tbaadm.pst where bill_ref_num = billref and tran_date = billtrandate and del_flg!='Y' and entity_cre_flg!='N';

cursor pstdata2 (billref tbaadm.pst.bill_ref_num%type, billtrandate tbaadm.pst.tran_date%type) is
select tran_id, tran_date, ho_tran_id, ho_tran_date from tbaadm.pst where tran_id = lpad(billref,9) and tran_date = billtrandate and del_flg!='Y' and entity_cre_flg!='N';

billref tbaadm.pst.bill_ref_num%type;
billtrandate tbaadm.pst.tran_date%type;
choice number(1);

begin

billref:= '&1';
billtrandate:='&2';
choice:='&3';

dbms_output.put_line('B'||'|'||'Ref. No:  '||'|'||billref||'|'||'Tran Date '||'|'||billtrandate||'|'||'0');

if (choice = 1) then
begin


for pstrec in pstdata (billref , billtrandate )
loop --{


dbms_output.put_line('D'||'|'||'Original Tran'||'|'||pstrec.tran_id||'|'||'Tran Date'||'|'||pstrec.tran_date||'|'||'0');
for billrec in billtran(pstrec.tran_id, pstrec.tran_date)

loop
if (billrec.gl_sub_head_code!='69031') then

dbms_output.put_line('O'||'|'||billrec.foracid||'|'||billrec.tran_crncy_code||'|'||billrec.part_tran_type||'|'||billrec.tran_amt||'|'||billrec.rate);

end if;
end loop;

dbms_output.put_line('X'||'|'||'BBOTC Tran'||'|'||pstrec.ho_tran_id||'|'||'Tran Date'||'|'||pstrec.ho_tran_date||'|'||'0');

for hobillrec in hobilltran(pstrec.ho_tran_id, pstrec.ho_tran_date)

loop
if (hobillrec.gl_sub_head_code!='69031') then

dbms_output.put_line('H'||'|'||hobillrec.foracid||'|'||hobillrec.tran_crncy_code||'|'||hobillrec.part_tran_type||'|'||hobillrec.tran_amt||'|'||hobillrec.rate);

end if;
end loop;

end loop; --}
end;
end if;
if (choice = 2) then
begin

dbms_output.put_line('D'||'|'||'Original Tran'||'|'||billref||'|'||'Tran Date'||'|'||billtrandate||'|'||'0');

for pstrec in pstdata2 (billref , billtrandate )
loop --{


for billrec in billtran(pstrec.tran_id, pstrec.tran_date)

loop
if (billrec.gl_sub_head_code!='69031') then

dbms_output.put_line('O'||'|'||billrec.foracid||'|'||billrec.tran_crncy_code||'|'||billrec.part_tran_type||'|'||billrec.tran_amt||'|'||billrec.rate);

end if;
end loop;

dbms_output.put_line('X'||'|'||'BBOTC Tran'||'|'||pstrec.ho_tran_id||'|'||'Tran Date'||'|'||pstrec.ho_tran_date||'|'||'0');

for hobillrec in hobilltran(pstrec.ho_tran_id, pstrec.ho_tran_date)

loop
if (hobillrec.gl_sub_head_code!='69031') then

dbms_output.put_line('H'||'|'||hobillrec.foracid||'|'||hobillrec.tran_crncy_code||'|'||hobillrec.part_tran_type||'|'||hobillrec.tran_amt||'|'||hobillrec.rate);

end if;
end loop;

end loop; --}
end;
end if;
end;
/