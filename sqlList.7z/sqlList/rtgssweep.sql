-- =====================================================================================================================
-- Source Name            :  rtgssweep.sql
-- Description            :  RTGS Report
-- Input Values           :  None
-- Output Values          :  None
-- Called Scripts         :  None
-- Calling Scripts        :  rtgssweep.com
-- Modification history:
-- Sl. No            Date                 Author                      Description
-- ---------     --------------    ----------------------        ------------------------------
-- 1.0             23-03-2013             Gauri                   Ported as per 10.x
-- =====================================================================================================================

set echo off verify off feedback off term off pagesi 0 trims on serveroutput on size 1000000 timing off time off

spool rtgssweep

DECLARE

CURSOR AcctList is
SELECT foracid,clr_bal_amt,decode(sign(clr_bal_amt),-1,'C','D') parttran,sol_id FROM GAM 
WHERE bacid in ( 
'RTGS-STTL-T1',
'RTGS-STTL-T2',
'RTGS-STTL-T3',
'RTGS-STTL-T4',
'RTGS-STTL-T5',
'RTGS-STTL-T6',
'RTGS-STTL-T7',
'RTGS-STTL-T8',
'RTGS-STTL-T9',
'RTGS-STTL-OT')   AND acct_crncy_code = 'INR'
AND acct_cls_flg = 'N'
AND bank_id = '&1';

contratran varchar2(1) := 'D';

BEGIN

for i in AcctList
LOOP
	dbms_output.put_line(i.foracid||'|'||'INR'||'|'||i.sol_id||'|'||i.parttran||'|'||abs(i.clr_bal_amt)||'|'||
							'DAY END BALANCE TRF');
	IF ( i.parttran = 'C' )
	THEN
		contratran := 'D';
	ELSE
		contratran := 'C';
	END IF;

	dbms_output.put_line('0103BKRBIRTGS'||'|'||'INR'||'|'||'0103'||'|'||contratran||'|'||abs(i.clr_bal_amt)||'|'||
							'DAY END BALANCE TRF');

END LOOP;
END;
/

spool off
