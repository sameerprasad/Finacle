----------------------------------------------------------------------------------------------------
--   Source Name            : Report_LCMIG.sql 
--   Description            : Locker Migration Report 
--   Input Values           : None
--   Output Values          : None
--   Called Script          : N.A
--   Calling Script         : N.A
--   Modification History:
--   Sl No.         Date              Author                     Description
--   --------------------------------------------------------------------------------------
--     01         12-Oct-2012         Priyanka                 Original Version
----------------------------------------------------------------------------------------------------

set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_LCMIG.lst

DECLARE

lv_solid         gam.sol_id%type :='&1';
lv_bankid        lcmig.bank_id%type := '&2';
v_cust_name      cmg.cust_name%type;

CURSOR c1 IS
select distinct lcmig.sol_id,
lcmig.rack_id,lcmig.locker_number,
lcmig.key_number,locker_type,
locker_size,lcmig.cif_id,cmg.cust_name,
lcmig.operation_mode,lcmig.no_hirer,lcmig.discount,
decode(lcmig.discount_method,'P','P-PERCENTAGE','A','A-AMOUNT') discount_method,
lcmig.discount_amount,lcmig.dperiod_from,
lcmig.dperiod_to,lcmig.dreason,lcmig.dremarks,
lcmig.issue_date,lcmig.due_date,lcmig.renewal_date,
lcmig.rent_amt,lcmig.disc_rent_amt,
lcmig.arrear_rent,lcmig.last_access_date,
lcmig.jh_cif_id1,lcmig.jh_cif_id2,lcmig.jh_cif_id3,lcmig.jh_cif_id4
from   lcmig,cmg
where    lcmig.sol_id= lv_solid
and    cmg.cif_id = lcmig.cif_id
and     lcmig.bank_id = cmg.bank_id
and     lcmig.bank_id = lv_bankid
order by lcmig.sol_id,lcmig.rack_id,lcmig.locker_number;

BEGIN

    for f1 in c1
    loop

        dbms_output.enable(buffer_size => NULL);
        dbms_output.put_line(    f1.sol_id                     ||'|'||
                                 f1.rack_id                    ||'|'||
                                 lpad(f1.locker_number,5,'0')  ||'|'||
                                 f1.key_number                 ||'|'||
                                 f1.locker_type                ||'|'||
                                 f1.locker_size                ||'|'||
                                 f1.cif_id                     ||'|'||
                                 substr(f1.cust_name,0,25)     ||'|'||
                                 f1.operation_mode             ||'|'||
                                 f1.no_hirer                   ||'|'||
                                 f1.discount                   ||'|'||
                                 f1.discount_method            ||'|'||
                                 f1.discount_amount            ||'|'||
                                 f1.dperiod_from               ||'|'||
                                 f1.dperiod_to                 ||'|'||
                                 f1.dreason                    ||'|'||
                                 f1.dremarks                   ||'|'||
                                 f1.issue_date                 ||'|'||
                                 f1.due_date                   ||'|'||
                                 f1.renewal_date               ||'|'||
                                 f1.rent_amt                   ||'|'||
                                 f1.disc_rent_amt              ||'|'||
                                 f1.arrear_rent                ||'|'||
                                 f1.last_access_date           ||'|'||
                                 f1.jh_cif_id1                 ||'|'||
                                 f1.jh_cif_id2                 ||'|'||
                                 f1.jh_cif_id3                 ||'|'||
                                 f1.jh_cif_id4    );    

   end loop; 
END;
/
spool off

