-----------------------------------------------------------------------------------------------------
--    Name           : ici_EcsData.sql
--    Date           : 11-Dec-2012
--    Author         : Ripal Patel
--    Menu Option    : NMATCH
--    Sl. No            Date                 Author                          Description.
--    ---------     --------------    ----------------------        ------------------------------
--    1.0             11-Dec-2012        Ripal Patel                 TOL - 322650 revadata file renamed
------------------------------------------------------------------------------------------------------
set serveroutput on size 1000000
set feedback off
set verify   off
set termout   off
set head off
set pages 0
set linesize 512
set trims on
--TOL 322650 : Changes start .lst added to the belo file name
spool revdata.lst
--TOL 322650 : Changes end
DECLARE
fora                    GAM.FORACID%Type;
bank_id                 GAM.BANK_ID%Type;
sch_type                GAM.schm_type%Type;

cursor c1 (fora varchar2,bankId varchar2) is
select foracid,cust_name,cust_title_code,decode(schm_type,'SBA','Saving','CAA','Current','TDA','Deposit','ODA','Advance') sch_type from gam g, cmg c where g.cif_id=c.cif_id and g.foracid=fora and g.bank_id=c.bank_id and g.bank_id=bankId;

begin
fora :='&1';
bank_id :='&2';
for i in c1 (fora,bank_id)
loop
dbms_output.put_line(i.foracid||'|'||i.cust_name||'|'||i.cust_title_code||'|'||i.sch_type);
end loop;
end;
/
spool off

