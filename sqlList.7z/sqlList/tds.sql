-- ****************************************************************
-- Filename	: tds.sql
-- Description	: Ported as part of CR-138-30198
-- Date		: 08-04-2013
-- Author	: Pragnya Ghosh
-- Modification History
-- Sl.#       Date           Author         Modification                              
-- -----   ----------   --------------    ----------------                               
--  1.0    08-04-2013    Pragnya Ghosh    Original Version
--  2.0    22-04-2013    Kumar Gandharv   Made changes for variable anchor declaration for proper execution
-- ****************************************************************

CREATE OR REPLACE PACKAGE TBAADM.TDS50000PACK1 AS

PROCEDURE TDS50000Proc( inp_str IN VARCHAR2,
					out_retCode OUT NUMBER,out_rec OUT VARCHAR2);

END TDS50000Pack1;
/
CREATE OR REPLACE PACKAGE BODY TBAADM.TDS50000PACK1 AS
------------------------------------------------------------------------------------------
--what is done ? 	: selecting All service outlets for a given DC
--why is it done ?  : requirement states TDS for a customer to be calculated sol wise to determine
-- where a customer is taxed .
------------------------------------------------------------------------------------------
	CURSOR SolId_TDS50000(setId varchar2) IS

		SELECT  DISTINCT sol_id
		FROM    SST where set_id = setId and bank_id = '&1';

----------------------------------------------------------------------------------------------
-- what is done ? 	: Selecting  customers and their account with the scheme type TDA
--					  (term deposit) in a given sol
--why is it done ? 	: Requirement states that interest on TDA accounts which are non recurring
--						in nature are to be considered for interest calculation .
---------------------------------------------------------------------------------------------

	CURSOR CustId_TDS50000 (in_sol_id varchar2, in_TDS_start_date date) IS
		SELECT 	DECODE(A.TDS_cust_id, '', A.cif_id, A.TDS_cust_id),
				A.cif_id,
				B.acid,
				B.foracid,
				B.wtax_flg,
				B.acct_cls_flg,
				A.tds_cust_id,
				B.clr_bal_amt,
				A.cust_sex
		FROM
				CMG A,
				GAM B
		WHERE
				A.bank_id=B.bank_id and A.bank_id = '&1' and
				B.schm_code IN
								(SELECT schm_code
								 FROM 	TSP
								 WHERE bank_id = '&1' and deposit_type <> 'R'
								 AND  	schm_code in (select 	schm_code
													 from 		CSP
													 where bank_id = '&1' and wtax_flg = 'T'))
		AND 	B.acct_crncy_code = 'INR'
		AND 	A.cif_id = B.cif_id
		AND 	A.entity_cre_flg = 'Y'
		AND 	B.entity_cre_flg = 'Y'
		AND 	B.del_flg		='N'
		 AND     A.primary_sol_id = in_sol_id
		AND     NVL(B.acct_cls_date,'31-03-2099') >= in_TDS_start_date
		ORDER BY 1;


PROCEDURE TDS50000Proc( inp_str IN VARCHAR2,out_retCode OUT NUMBER,
				out_rec OUT VARCHAR2) As

	OutArr 						basp0099.ArrayType;
	in_TDS_start_date 			tbaadm.GCT.TDS_start_date%type;
	in_TDS_end_date 			tbaadm.GCT.TDS_end_date%type;
	GCT_db_stat_date 			tbaadm.GCT.db_stat_date%type;
	in_TDT_start_date 			tbaadm.GCT.TDS_start_date%type;

	in_cust_id 					tbaadm.CMG.cif_id%type;
	in_cust_sex					tbaadm.cmg.cust_sex%type;
	loc_cust_sex				tbaadm.cmg.cust_sex%type;
	loc_cust_sex1               tbaadm.cmg.cust_sex%type;
            start_tds_end_date                      tbaadm.gct.TDS_end_date%type;
        start_tds_end_date1                     tbaadm.gct.TDS_end_date%type;
        sr_tds_end_date                         tbaadm.gct.TDS_end_date%type;
        sr_tds_end_date1                        tbaadm.gct.TDS_end_date%type;
        cust_dob                                tbaadm.CMG.DATE_OF_BIRTH%type;
        cust_dob1                               tbaadm.CMG.DATE_OF_BIRTH%type;

	in_cust_id1 				tbaadm.CMG.cif_id%type;
	in_TDS_cust_id 				tbaadm.CMG.TDS_cust_id%type;
	in_cust_id_real 			tbaadm.CMG.cif_id%type;

	tda_rcre_user_id 			CUST_TDS50000.rcre_user_id%type;
	tda_acid_temp 				CUST_TDS50000.tda_acid%type;

	tda_last_updating_time 		tda_updatetime.lastbatchjob_time%type;
	
	in_sol_id                                       tbaadm.GAM.sol_id%type;
	in_acct_cls_flg 			tbaadm.GAM.acct_cls_flg%type;
	tbl_acct_cls_flg 			tbaadm.GAM.acct_cls_flg%type;
	in_acid 					tbaadm.GAM.acid%type;
	temp_acid					tbaadm.GAM.acid%type;
	in_foracid 					tbaadm.GAM.foracid%type;
	in_wtax_flg 				tbaadm.GAM.wtax_flg%type;
	in_clr_bal_amt              tbaadm.GAM.clr_bal_amt%type;
	prev_tax_flg                tbaadm.GAM.wtax_flg%type;

	in_int_amt 					tbaadm.TDS.int_amt%type;
	in_tran_date 				tbaadm.TDS.tran_date%type;
	max_tran_date 				tbaadm.TDS.tran_date%type;

	n_flow_date					tbaadm.TDT.flow_date%type;
	end_flow_date 				tbaadm.TDT.flow_date%type;
	in_flow_date 				tbaadm.TDT.flow_date%type;
	f_flow_date 				tbaadm.TDT.flow_date%type;
	in_flow_amt 				tbaadm.TDT.flow_amt%type;
	in_flow_amt1 				tbaadm.TDT.flow_amt%type;
	f_flow_amt 					tbaadm.TDT.flow_amt%type;
	dep_per_days 				tbaadm.TDT.dep_period_days%type;
	flow_date_bef_cur_fin_yr    tbaadm.TDT.flow_date%type;
    min_tdt_date                tbaadm.TDT.flow_date%type;
    prev_fin_date               tbaadm.TDT.flow_date%type;

	setId						tbaadm.SST.set_id%type;
	depositAmount				tbaadm.TAM.deposit_amount%type;

	lastFlowInterval            number(6);
	err_msg						varchar(80);
	part_amt					number(20,4);
	prev_flow_amt 				number(20,4);
	tot_period  				number(20,4);
	tot_days					number(20,4);
	flow_amt 					number(20,4);
	lastPartialFlow 			number(20,4);
	in_flow_amt_tot 			number(20,4);
	in_int_amt_tot 				number(20,4);
	estimatedinterest 			number(25,4);
	estimatedDays 				number(6);
	estimatedInterestClosed 	number(20, 4);
    estimatedInterestOpen 		number(20, 4);
	taxLimit					number(20,4);
	taxLimit1					number(20,4);
	countTdsCertNum				integer;
	acctCount 					integer;

	TYPE CustTblItemType IS RECORD (
		cust_custid CMG.cif_id%type,
		cust_tdscustid CMG.tds_cust_id%type,
		cust_acid GAM.acid%type,
		cust_foracid GAM.foracid%type,
		cust_acctclsflg GAM.acct_cls_flg%type,
		cust_sexflg CMG.cust_sex%type);

	TYPE CustTblType IS TABLE OF CustTblItemType;

	custtblitem CustTblItemType;

	custtbl CustTblType;



BEGIN
----------------------------------------------------------------------------------------
--what is done ?  : Hard coding values for Tax limit .
--why it is done ?: Requirement specifies the current tax limit ,above which the customer
--					is to be taxed (INR).
----------------------------------------------------------------------------------------
--	taxLimit := 50000;
----------------------------------------------------------------------------------------------
-- what is done  ?	: Cursor 1 selecting different service outlet's in a given Data center
-- why it is done ? : To calculate total interest from the TD accounts sol wise for a customer.
----------------------------------------------------------------------------------------------
	out_retCode := 0;
	err_msg		:='';
	prev_tax_flg:='';
    custtbl 	:= custTblType();

	IF (NOT SolId_TDS50000%ISOPEN) THEN
--	{
		basp0099.formInputArr(inp_str,OutArr);
		tda_rcre_user_id := OutArr(0);
		setId			 := OutArr(1);

		SELECT 	GCT.tds_start_date,
				GCT.tds_end_date,
				db_stat_date
		INTO 	in_TDS_start_date,
				in_TDS_end_date,
				GCT_db_stat_date
		FROM 	GCT WHERE bank_id='&1' ;
 
		OPEN SolId_TDS50000(setId);
--	}
	END IF;

	LOOP
--      {
                IF ((SolId_TDS50000%ISOPEN) AND (NOT CustId_TDS50000%ISOPEN)) THEN
--              {
                        FETCH   SolId_TDS50000
                        INTO    in_sol_id;

                        IF (SolId_TDS50000%NOTFOUND) THEN
--                      {
                                CLOSE SolId_TDS50000;
                                out_retCode := 1;
                                RETURN;
                                EXIT;
--                      }
                        END IF;
--              }
                END IF;
-----------------------------------------------------------------------------------------------
--what is done ?   : Cursor 2 will select customer and their account for a given service outlet
--why is it done ? : Total interest for TD account of a customer can be calculated for that given sol
---------------------------------------------------------------------------------------
		IF((SolId_TDS50000%ISOPEN) AND (NOT CustId_TDS50000%ISOPEN)) THEN
--		{
			estimatedinterest 		:= 0;
			estimatedInterestOpen 	:= 0;
			estimatedInterestClosed := 0;
			OPEN CustId_TDS50000(in_sol_id, in_TDS_start_date);
--		}
		END IF;

		IF (CustId_TDS50000%ISOPEN) THEN
--		{
			FETCH 	CustId_TDS50000
			INTO	in_cust_id,
					in_cust_id_real,
					in_acid,
					in_foracid,
					in_wtax_flg,
					in_acct_cls_flg,
					in_TDS_cust_id,
					in_clr_bal_amt,
					in_cust_sex;

			IF (CustId_TDS50000%FOUND) THEN
--			{
		BEGIN
				SELECT 	distinct acid
				INTO 	temp_acid
                FROM	TDT
                WHERE	bank_id = '&1' and flow_date >= in_TDS_start_date
            	AND    	flow_code IN ('IO', 'II')
				AND 	acid = in_acid;

			EXCEPTION
            	WHEN NO_DATA_FOUND THEN
					in_int_amt_tot      :=0;
					GOTO FETCHNXT;
		END;
		BEGIN
				SELECT 	deposit_amount
				INTO	depositAmount
				FROM 	TAM
				WHERE	bank_id = '&1' and acid = in_acid;

				IF ((in_clr_bal_amt < depositAmount) AND (in_acct_cls_flg = 'N')) THEN
--              {
                    in_int_amt_tot:=0;
                    GOTO FETCHNXT;
--              }
                END IF;

			EXCEPTION
				WHEN NO_DATA_FOUND THEN
				BEGIN
    	            in_int_amt_tot:=0;
 	                GOTO FETCHNXT;
				END;
		END;


				IF (in_cust_id1 IS NULL ) THEN
--				{
					in_cust_id1 			:=in_cust_id;
					in_flow_amt_tot 		:=0;
					estimatedinterest 		:=0;
					in_int_amt_tot  		:=0;
					acctCount 				:=0;
					estimatedInterestOpen 	:=0;
					estimatedInterestClosed :=0;
--				}
				END IF;
			Begin
			select nvl(cust_sex,'N') into loc_cust_sex from cmg
			where bank_id = '&1' and cif_id = in_cust_id;
			exception
			when no_data_found then
			loc_cust_sex := 'O';
			end;

                        Begin
                        select add_months(TDS_end_date,-720) into start_tds_end_date from gct where bank_id = '&1';
                        end;
                        Begin
                        select add_months(TDS_end_date,-780) into sr_tds_end_date from gct where bank_id = '&1';
                        end;
                        Begin
                        select DATE_OF_BIRTH into cust_dob from cmg
                        where bank_id = '&1' and cif_id = in_cust_id;
                        end;


                IF (loc_cust_sex = 'F') THEN
                    taxLimit := 200000;
                else
                    taxLimit := 200000;
                end if;

                if ((cust_dob > start_tds_end_date) and (cust_dob < sr_tds_end_date)) then
                	taxLimit := 5000000000;
                end if;

--************************************************************************************
--  TAX lIMIT changed asper new Female : 145000 Others : 110000
--************************************************************************************
-------------------------------------------------------------------------------------------
-- what is done ? : to check if the accounts of the Next customer in the same sol are sent
--					for processing
-- why is it done : To ensure that the if the previous customer is taxed and entry for the same is
--					 made in the customised table
-------------------------------------------------------------------------------------------
				IF (in_cust_id1 != in_cust_id ) THEN
--				{
--------------------------------------------------------------------------------------
--what is done ?   : If the previous customer has interest greater then 50K INR then .
--					entered into the customised table
--why it is done ? :  These entries in the customised table can be used later for updating
--					the tax flags in the customer
--------------------------------------------------------------------------------------------
					IF (estimatedinterest > taxLimit1 ) THEN
--					{
						FOR i IN 1 .. custtbl.COUNT
						LOOP
							custtblitem := custtbl(i);

							BEGIN
								SELECT 	TDA_ACID
								INTO	tda_acid_temp
								FROM 	CUST_TDS50000
								WHERE 	bank_id = '&1' and tda_acid = custtblitem.cust_acid
								AND 	update_flag = 'N';

                                UPDATE
                                    CUST_TDS50000
                                SET
                                    RECORD_DATE = GCT_db_stat_date,
                                    SUM_INT_AMT = estimatedInterestClosed,
                                    SUM_FLOW_AMT = estimatedInterestOpen,
                                    ACCT_CLS_FLG = custtblitem.cust_acctclsflg,
                                    LCHG_USER_ID = tda_rcre_user_id,
                                    LCHG_TIME = sysdate,
									cust_sex =custtblitem.cust_sexflg
                                WHERE bank_id = '&1' AND
                                    TDA_ACID = custtblitem.cust_acid AND
                                    UPDATE_FLAG = 'N';

							EXCEPTION
								WHEN NO_DATA_FOUND THEN
									INSERT INTO CUST_TDS50000
--doubt
									VALUES 		(custtblitem.cust_custid,
												in_sol_id,
												custtblitem.cust_tdscustid,
												custtblitem.cust_acid,
												custtblitem.cust_foracid,
												GCT_db_stat_date,
												'N',
												estimatedInterestClosed,
												estimatedInterestOpen,
												custtblitem.cust_acctclsflg,
												prev_tax_flg,
												err_msg,
												tda_rcre_user_id,
												sysdate,
												tda_rcre_user_id,
												sysdate,
												custtblitem.cust_sexflg,
												'&1');
							END;
						END LOOP;
						COMMIT;
--					}
					END IF;
					in_cust_id1 			:= in_cust_id;
					in_flow_amt_tot 		:= 0;
					estimatedinterest 		:= 0;
					in_int_amt_tot 			:= 0;
					estimatedInterestOpen 	:= 0;
					estimatedInterestClosed := 0;

					acctCount := 0;
					custtbl.DELETE;
--				}
				END IF;
--
---------------------------------------------------------------------------------
-- what is done ? 	: Interest calculation for all open and closed term deposits
-- why it is done ? : this gives details about the amount and the date upto which the
--					tax deduction at source is calculated from the beginning of the financial year
---------------------------------------------------------------------------------
				SELECT 	max(tran_date),
						sum(int_amt)
				INTO 	max_tran_date,
						in_int_amt
				FROM 	TDS
				WHERE 	bank_id = '&1' AND tran_date >= in_TDS_start_date
				AND 	tran_date <= in_TDS_end_date
				AND 	tds.acid = in_acid;

				IF  (max_tran_date IS NOT NULL) THEN
--				{
					in_int_amt_tot 		:= in_int_amt_tot + in_int_amt;
					estimatedDays 		:= in_TDS_end_date - max_tran_date;
					in_TDT_start_date 	:= max_tran_date + 1;
				ELSE
					in_int_amt 			:= 0;
					estimatedDays 		:= in_TDS_end_date - in_TDS_start_date + 1;
					in_TDT_start_date 	:= in_TDS_start_date;
--				}
				END IF;

				IF (in_acct_cls_flg = 'Y') THEN
--				{
					estimatedInterestClosed := estimatedInterestClosed + in_int_amt;
				ELSE
					estimatedInterestOpen 	:= estimatedInterestOpen + in_int_amt;
--				}
				END IF;

-----------------------------------------------------------------------------------
--what is done ?   : calculation for open term deposits
--why is it done ? : this will calculate the interest from the date on which TDS was
--					calculated till the financial year end
-----------------------------------------------------------------------------------
				IF (in_acct_cls_flg = 'N' ) THEN
--				{
					SELECT 	max(flow_date),
							sum(flow_amt)
					INTO 	in_flow_date,
							in_flow_amt1
					FROM 	TDT
					WHERE 	bank_id = '&1' AND flow_code IN ('IO', 'II')
					AND 	acid = in_acid
					AND 	flow_date >= in_TDT_start_date
					AND 	flow_date <= in_TDS_end_date;

					IF (in_flow_date IS NULL) THEN
--					{
						in_flow_amt1 	:= 0;
						BEGIN
--						{
							SELECT 	acct_opn_date
							INTO 	n_flow_date
							FROM 	GAM
							WHERE 	acid = in_acid AND bank_id = '&1';

							IF (n_flow_date > in_TDT_start_date) THEN
--							{
								in_flow_date:= n_flow_date;
--							}
							ELSE
--							{
								in_flow_date:= in_TDT_start_date;
--							}
							END IF;

						EXCEPTION
						WHEN NO_DATA_FOUND THEN
							BEGIN
								in_flow_date := in_TDT_start_date;
							END;
--						}
						END;
--					}
					END IF;

					estimatedDays := (in_TDS_end_date - in_flow_date )+1;

					lastPartialFlow := 0;

					IF (in_flow_date < in_TDS_end_date) THEN
--					{
						BEGIN
							SELECT 	flow_amt,
									flow_date
							INTO 	f_flow_amt,
									f_flow_date
							FROM 	TDT
							WHERE 	bank_id = '&1' AND flow_date IN   (SELECT 	min(flow_date)
													FROM 	TDT
													WHERE 	bank_id = '&1' AND flow_date > in_TDS_end_date
													AND 	acid = in_acid
													AND 	flow_code IN ('IO', 'II'))
							AND 	flow_code IN ('IO', 'II')
							AND 	acid = in_acid;

							lastFlowInterval 	:= f_flow_date - in_flow_date;
							lastPartialFlow 	:= estimatedDays * (f_flow_amt / lastFlowInterval);

					EXCEPTION
							WHEN NO_DATA_FOUND THEN

							BEGIN
--							{
								lastPartialFlow := 0;
--							}
							END;

						END;
--					}
					END IF;

					prev_flow_amt := 0;

					IF ( in_TDT_start_date = in_TDS_start_date )  THEN
--					{
						prev_fin_date := in_TDS_start_date - 1;

						select 	max(flow_date )
						into    flow_date_bef_cur_fin_yr
						from 	TDT
						where 	bank_id = '&1' and flow_date <= prev_fin_date
						and 	acid = in_acid
						AND		flow_code in ( 'II','IO')    ;

						IF ( flow_date_bef_cur_fin_yr IS NOT NULL ) THEN
--                      {
                            BEGIN

                                SELECT  flow_amt,
										flow_date
                                INTO    part_amt,
                                        min_tdt_date
                                FROM    TDT
                                WHERE   bank_id = '&1' AND flow_date in (  SELECT	min(flow_date)
                                        	            FROM    TDT
                                            	        WHERE   bank_id = '&1' AND flow_date >= in_TDT_start_date
                                                	    AND     flow_date <= in_TDS_end_date
                                                    	AND 	flow_code in ( 'II','IO')
                                                    	AND 	acid = in_acid )
                                AND    	flow_code in ('II','IO' )
                                AND 	acid =in_acid ;


                                	tot_period  := (min_tdt_date - flow_date_bef_cur_fin_yr);

                                	tot_days    := (prev_fin_date - flow_date_bef_cur_fin_yr);

                               	 	prev_flow_amt   := (part_amt / tot_period ) * tot_days;

						    	EXCEPTION
                                    WHEN NO_DATA_FOUND THEN
                                     BEGIN
                                        prev_flow_amt := 0;
                                    END;
                            END;
                            ELSE
                                BEGIN

									SELECT  acct_opn_date
                                    INTO    n_flow_date
                                    FROM    GAM
                                    WHERE   bank_id = '&1' AND acid = in_acid;

                                    IF (n_flow_date >= in_TDS_start_date) THEN
--                                  {
                                        prev_flow_amt := 0;

                                    ELSE

                                        SELECT  flow_amt,flow_date
                                        INTO    part_amt,
                                                min_tdt_date
                                        FROM    TDT
                                        WHERE   bank_id = '&1' AND flow_date in (	SELECT	min(flow_date)
   																FROM    TDT
 	        													WHERE   bank_id = '&1' AND flow_date >= in_TDT_start_date
    															AND     flow_date <= in_TDS_end_date
																AND 	flow_code in ( 'II','IO')
                                                    			AND 	acid = in_acid )
                        		        AND     flow_code in ('II','IO' )
                                		AND 	acid =in_acid ;

		                                tot_period  := (min_tdt_date - n_flow_date);

        		                        tot_days    := (prev_fin_date - n_flow_date);

                		                prev_flow_amt   := (part_amt / tot_period ) * tot_days;


--                                  }
                                    END IF;
						    	EXCEPTION
                                    WHEN NO_DATA_FOUND THEN
                                     BEGIN
                                        prev_flow_amt := 0;
                                    END;
                                END;

--                      }
                        END IF;
--              }
                END IF;
					in_flow_amt 	:= lastPartialFlow + in_flow_amt1;
					in_flow_amt 	:= in_flow_amt - prev_flow_amt;
					in_flow_amt_tot := in_flow_amt_tot + in_flow_amt;

					estimatedInterestOpen := estimatedInterestOpen + in_flow_amt;
--				}
				END IF;

--------------------------------------------------------------------------------------------
-- what is done ? : Intrest of all Term deposits of a customer summed .
-- why it is done ? : This amount excceds the Tax limit then the customer has to be taxed
--------------------------------------------------------------------------------------------
				estimatedinterest 	:= in_int_amt_tot + in_flow_amt_tot;
				taxLimit1 :=  taxLimit;

				IF ((in_wtax_flg = 'N') OR ( in_wtax_flg = 'E'))THEN
--				{
					acctCount := acctCount + 1;

					custtblitem.cust_custid 	:= in_cust_id_real;
					custtblitem.cust_tdscustid	:= in_TDS_cust_id;
					custtblitem.cust_acid 		:= in_acid;
					custtblitem.cust_foracid 	:= in_foracid;
					custtblitem.cust_acctclsflg := in_acct_cls_flg;
					custtblitem.cust_sexflg := in_cust_sex;

					custtbl.EXTEND;
					custtbl(acctCount) := custtblitem;
				ELSE
					IF (in_wtax_flg = 'T') THEN
--					{
						SELECT 	count(tds_cert_num)
						INTO 	countTdsCertNum
						FROM 	TDS
						WHERE 	bank_id = '&1' AND acid = in_acid
						AND 	tds_flg='N'
						AND     tran_date >= in_TDS_start_date
						AND 	tran_date <= in_TDS_end_date;

						IF (countTdsCertNum > 0) THEN
--						{
							acctCount := acctCount + 1;

							custtblitem.cust_custid 	:= in_cust_id_real;
							custtblitem.cust_tdscustid 	:= in_TDS_cust_id;
							custtblitem.cust_acid 		:= in_acid;
							custtblitem.cust_foracid 	:= in_foracid;
							custtblitem.cust_acctclsflg := in_acct_cls_flg;
							custtblitem.cust_sexflg := in_cust_sex;

							custtbl.EXTEND;
							custtbl(acctCount) := custtblitem;
--						}
						END IF;
--					}
					END IF;
--				}
				END IF;
<<FETCHNXT>>
null;
--			}
			END IF;

			IF (CustId_TDS50000%NOTFOUND) THEN
--			{
				Begin
			 	select nvl(cust_sex,'N') into loc_cust_sex1 from cmg
                where bank_id = '&1' and cif_id = in_cust_id;
				exception
				when no_data_found then
				loc_cust_sex1 := 'O';
				end;

                Begin
                select add_months(TDS_end_date,-720) into start_tds_end_date1 from gct where bank_id = '&1';
                end;
                Begin
                select add_months(TDS_end_date,-780) into sr_tds_end_date1 from gct where bank_id = '&1';
                end;
                Begin
                select DATE_OF_BIRTH into cust_dob1 from cmg
                where bank_id = '&1' AND cif_id = in_cust_id;
                end;

                IF (loc_cust_sex = 'F') THEN
                    taxLimit := 200000;
                else
                    taxLimit := 200000;
                end if;

                if ((cust_dob > start_tds_end_date) and (cust_dob < sr_tds_end_date)) then
                    taxLimit := 5000000000;
                end if;

				IF (estimatedinterest >= taxLimit1) THEN
--				{
					FOR i IN 1 .. custtbl.COUNT
					LOOP
						custtblitem := custtbl(i);
						BEGIN

							SELECT 	TDA_ACID
							INTO	tda_acid_temp
							FROM 	CUST_TDS50000
							WHERE 	bank_id = '&1' and tda_acid = custtblitem.cust_acid
							AND 	update_flag = 'N';

							UPDATE
								CUST_TDS50000
							SET
								RECORD_DATE = GCT_db_stat_date,
								SUM_INT_AMT = estimatedInterestClosed,
								SUM_FLOW_AMT = estimatedInterestOpen,
								ACCT_CLS_FLG = custtblitem.cust_acctclsflg,
								LCHG_USER_ID = tda_rcre_user_id,
								LCHG_TIME = sysdate,
								cust_sex = custtblitem.cust_sexflg
							WHERE bank_id = '&1' and
								TDA_ACID = custtblitem.cust_acid AND
								UPDATE_FLAG = 'N';

						EXCEPTION
							WHEN NO_DATA_FOUND THEN
								INSERT INTO CUST_TDS50000
								VALUES 		(custtblitem.cust_custid,
											in_sol_id,
											custtblitem.cust_tdscustid,
											custtblitem.cust_acid,
											custtblitem.cust_foracid,
											GCT_db_stat_date,
											'N',
											estimatedInterestClosed,
											estimatedInterestOpen,
											custtblitem.cust_acctclsflg,
                                            prev_tax_flg,
                                            err_msg,
											tda_rcre_user_id,
											sysdate,
											tda_rcre_user_id,
											sysdate,
											custtblitem.cust_sexflg,
											'&1');
						END;
					END LOOP;
					COMMIT;
--				}
				END IF;

				custtbl.DELETE;

				CLOSE CustId_TDS50000;

--			}
			END IF;
--		}
		END IF;
--	}
	END LOOP;

END TDS50000Proc;

END TDS50000Pack1;
show err
/

