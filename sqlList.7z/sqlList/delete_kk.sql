DELETE FROM WLCKM
/
commit
/

delete from c_svrsetvar
/
commit
/

delete from clmt
/
commit
/

delete from lcpp
/
commit
/

delete from lcpd
/
commit
/

delete from lcpy
/
commit
/

delete from clcwt
/
commit
/

delete from clrt
/
commit
/

delete from cljh
/
commit
/
