---------------------------------------------------------------------------------
-- Filename         :pbkCurrentDate.sql
-- Description      : Sql File to get current date from gct table 
-- Date             : 27-01-2012
-- Author           : Aparna Ashok
-- Menu Option      : pbkDailyRun.com
-- Modification History
-- Sl.#       Date           Author         Modification                              
-- -----   ----------   --------------    ----------------                               
--  1.0    21-11-2012   Aparna Ashok    Original Version                          
----------------------------------------------------------------------------------------------




set head off
set echo off
set trims on
set pagesize 1000
spool pbkCur
select to_char(DB_STAT_DATE,'DDMMYYYY') FROM GCT;
spool off
