set serveroutput on size 1000000
set feedback off
set verify off
set linesize 500
set pages 0
set trims on
set termout off
set numformat 999D09
spool &1
select USER_ID||','||ACCOUNT_NO||','||PART_TRAN_TYPE||','||PART_TRAN_SRL_NUM||','||TRAN_DATE||','||TRAN_ID||','||TRAN_AMT||','||CNT_RS1000||','||CNT_RS500||','||CNT_RS100||','||CNT_RS50||','||CNT_RS20||','||CNT_RS10||','||CNT_RS5||','||CNT_RS2||','||CNT_RS1||','||CNT_PS50||','||CNT_PS25||','||CNT_PS20||','||CNT_PS10||','||CNT_PS05||','||EXG_AMT||','||TRAN_UPD_FLG||','||SOL_ID||','||RCRE_TIME 
from ICI_CASH_POPUP 
where SOL_ID='&2' and Tran_date='&3' and TRAN_UPD_FLG='T' and bank_id='&4'
--where SOL_ID='&1' and Tran_date='&2' and User_id='&3'and TRAN_UPD_FLG='T'
/
spool off
