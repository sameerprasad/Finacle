set head off
set verify off
set pages 0
set feedback off
set termout off
set colsep "','"
set linesize 400
spool dump.sql
select * from CFDRMAIN where rownum < 25;
spool off
set linesize 100
spool desc.sql
desc CFDRMAIN
exit
