REM AUTHOR "MUKESH KUMAR JAIN"
REM PURPOSE "Details of Accts of a Customer as on a date with Balance"
rem accept id prompt 'ENTER CUST ID                  :: '
rem accept dt prompt 'ENTER DATE (DD-MON-YYYY)	 :: ' 
set feedback off
set verify off
set termout off
set pagesize 60
set linesize 80
alter session set nls_date_format = 'DD-MM-YYYY';
break on Type skip 2 on Name on report 
compute sum of x y on Type report
column Type format a4
column Name format a25
column Account format a12
column x heading 'Credit Balance' format  B99999,99,999.99
column y heading 'Debit Balance' format B99999,99,999.99
Ttitle Center 'Report of Accounts of Cust Id &1 as on &2' skip 2
spool custbal
select substr(g.foracid,5,2) Type,g.foracid Account,g.acct_name NAME,
	decode(sign(e.tran_date_bal),1,e.tran_date_bal,0) x,
	decode(sign(e.tran_date_bal),1,0,e.tran_date_bal) y
from eab e, gam g
	 --where g.cust_id = lpad('&1',9)
        where g.cif_id = '&1'
	and g.acct_ownership='C'
	and g.acct_opn_date <= to_date('&2','dd-mm-yyyy')
	and (g.acct_cls_flg!='Y' or acct_cls_date >to_date('&2','dd-mm-yyyy'))
	and e.acid=g.acid
        and e.bank_id = g.bank_id 
        and e.bank_id = '&3'
	and e.eod_date = (select max(e1.eod_date) from eab e1
                            where e1.acid=g.acid
                            and e1.eod_date <=  to_date('&2','dd-mm-yyyy') and e1.bank_id = '&3')
	order by 1,2
/
spool off
set heading on
set termout on
set verify on
set feedback on
rem exit
