-------------------------------------------------------------------------------------------------------------
-- FileName                 : cpenrpt_mn001.sql
-- Author                   : Chokkalingam Lakshmanan
-- Date                     : 16-12-2005
-- Description              : selects the fields corresponding to the inputs
-- Input1                   : From date
-- Input2                   : To date
-- Output                   :
-- Calling Script           : cpenrpt.com
-- Modifications            : None
-------------------------------------------------------------------------------------------------------------
-- ---------------------------------------------
-- Declaration of the package and the Procedure
-- ---------------------------------------------

CREATE OR REPLACE PACKAGE cpenrptpack AS
    PROCEDURE cpenrptproc(inp_str VARCHAR2,
            out_retCode OUT NUMBER,
            out_rec OUT VARCHAR2);
END cpenrptpack;
/

CREATE OR REPLACE PACKAGE BODY cpenrptpack AS
--{
-------------------------------------------------------------------
--Declaring the variables to be used in the Procedure
-------------------------------------------------------------------
outArr             basp0099.ArrayType; 
from_date       DATE;
to1_date         DATE;
	
cursor getcpenrptAccts(from_date DATE,to_date DATE) is
--{

SELECT	REF_NUMBER,
		DOC_CRE_NUM,
		TOT_AMT_CLAIMED_A2,
		TOT_AMT_CLAIMED_A3,
		ISSU_BANK_A1,
		CLAIM_BANK_REF,
		TOT_AMT_CLAIMED_A1,
		PRIN_AMT_CLAIMED,
		ADDT_AMT_CLM
FROM	C_742
WHERE	(STATUS = 'LODGED' OR (STATUS = 'DISHONOURED' AND VRFD_IND = 'N') OR (STATUS = 'ACCEPTED' AND VRFD_IND = 'N'))
AND TOT_AMT_CLAIMED_A1 >= from_date 
AND TOT_AMT_CLAIMED_A1 <= to1_date;

--}


-- --------------------------------------------------------------------
--Procedure body
-- --------------------------------------------------------------------

PROCEDURE cpenrptproc(	inp_str     IN  VARCHAR2,
                      	out_retCode OUT NUMBER,
                     	out_rec     OUT VARCHAR2) AS

	--outArr iciLongArray.ArrayType;
	outArr basp0099.ArrayType; 
	refNumber				C_742.REF_NUMBER%type;
	docCreNum				C_742.DOC_CRE_NUM%type;
	crncy					C_742.TOT_AMT_CLAIMED_A2%type;
	totAmt					C_742.TOT_AMT_CLAIMED_A3%type;
	issueBank				C_742.ISSU_BANK_A1%type;
	claimBankRefNum			C_742.CLAIM_BANK_REF%type;
	valueDate				C_742.TOT_AMT_CLAIMED_A1%type;
	prn_amt_claim			C_742.PRIN_AMT_CLAIMED%TYPE;
	add_amt_claim			C_742.ADDT_AMT_CLM%TYPE;
	idTypeCnt                       NUMBER(5);	

BEGIN
--{
	out_retCode := 0;
---------------------------------------------
-- Checking whether the cursor is open if not
-- it is opened
---------------------------------------------

	if NOT getcpenrptAccts%ISOPEN then
	--{
		basp0099.formInputArr(inp_str,outArr);
		from_date	:= to_date(outArr(0),'dd-mm-yyyy'); 
		to1_date	    := to_date(outArr(1),'dd-mm-yyyy');
		open getcpenrptAccts(from_date,to1_date);
	--}
	end if;


	if getcpenrptAccts%ISOPEN then
	--{
		fetch getcpenrptAccts into
		    refNumber,
   		 	docCreNum,
			crncy,
			totAmt,
			issueBank,
			claimBankRefNum,
			valueDate,
			prn_amt_claim,
			add_amt_claim;
	--}
	end if;

	totAmt	:=	prn_amt_claim + add_amt_claim;

	if getcpenrptAccts%NOTFOUND then
	--{
		close getcpenrptAccts;
		out_retCode := 1;
		return;
	--}
	end if;

	out_rec := 	
	refNumber			||'|'||
    docCreNum			||'|'||
    crncy				||'|'||
    totAmt				||'|'||
    issueBank			||'|'||
    claimBankRefNum		||'|'||
    valueDate;



END cpenrptproc; 				 --}Procedure ends

END cpenrptpack; 			     --}Package ends

-------------------------------------------------------
-- Execution grants are given to Tbacust Tbautil Tbagen
-------------------------------------------------------
/
DROP PUBLIC SYNONYM cpenrptpack
/
CREATE PUBLIC SYNONYM cpenrptpack FOR cpenrptpack
/
GRANT EXECUTE ON cpenrptpack TO TBAGEN, TBAUTIL
/
show err
