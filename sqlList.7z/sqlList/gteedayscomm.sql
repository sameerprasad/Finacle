rem accept solid prompt 'ENTER FOUR DIGIT SOLID OF REPORT BRANCH : '
rem ACCEPT dt PROMPT 'ENTER REPORT DATE IN DD-MM-YYYY FORMAT  : '
rem AUTHOR :: G.S.Saini, I.T. Deptt.            DATE  ::22-Mar-96
rem modified by shashi for ver 1.6.36.10
rem modified by shashi for DC merger

set echo off 
set termout off
set pause off
set verify off
whenever sqlerror exit sql.sqlcode
set feedback off
set linesize 102
set pagesize 66
set wrap off
set space 1

define all_dashes = '-----------------------------------------------------------------------------'
column today new_value today_date
select to_char(sysdate, 'dd/mm/yyyy') today
from   dual;
column branch new_value br 
select sol_desc branch from sol where sol_id= '&1' and bank_id='&3';
column a heading 'Gtee No.' format a12
column b heading 'Effective|Date' format a10
column c heading 'Claim Exp|Date' format a10
column d heading 'Total No.|Of Days' format 99,99,999
column e heading 'Remaining|Days' format 99,99,990
column f heading 'Commission|Collected' format 9,99,99,990
column g heading 'Commission For|Remaining Perd' format 9,99,99,990
break on report
compute sum of f on report
compute sum of g on report
spool &1.gteedayscomm

ttitle center 'ICICI BANK LIMITED' skip 1 -
center br  skip 2 -
center 'REPORT OF PROPORTIONATE COMMISSION FOR THE PERIOD BEYOND ' &2 SKIP 1 -
center 'FOR GUARANTEES EXCEEDING 18 MONTHS' -
right 'PAGE :   ' format 9999 sql.pno  skip 1 -
right 'DATE :   ' today_date skip 2 -

select bg_srl_num a, effective_date b, claim_expiry_date c, 
(to_char(claim_expiry_date,'J') - to_char(effective_date,'J')) d,
(to_char(claim_expiry_date,'J') - to_char(to_date('&2'),'J')) e, (actual_amt_coll) f, 
(actual_amt_coll)*(to_char(claim_expiry_date,'J') - to_char(to_date('&2'),'J'))/(to_char(claim_expiry_date,'J') - to_char(effective_date,'J')) g from bgm ,cxl
where bgm.sol_id='&1'
and comp_b2kid_type='BNKGR'
and bgm.bg_b2kid=cxl.comp_b2kid
and bg_status in ('A','E','G','O') and 
ceil(months_between((claim_expiry_date+1),effective_date))>18 
and claim_expiry_date>to_date('&2','dd-mm-yyyy') 
and effective_date<=to_date('&2','dd-mm-yyyy')
and bgm.bank_id='&3' and cxl.bank_id='&3'
order by 2
/
ttitle off
ttitle center 'REPORT OF PROPORTIONATE COMMISSION FOR THE PERIOD BEYOND ' &2 SKIP 1 -
center 'FOR GUARANTEES UPTO 18 MONTHS' skip 2 
select bg_srl_num a, effective_date b, claim_expiry_date c, 
(to_char(claim_expiry_date,'J') - to_char(effective_date,'J')) d,
(to_char(claim_expiry_date,'J') - to_char(to_date('&2'),'J')) e, (actual_amt_coll) f, 
(actual_amt_coll)*(to_char(claim_expiry_date,'J') - to_char(to_date('&2'),'J'))/(to_char(claim_expiry_date,'J') - to_char(effective_date,'J')) g from bgm,cxl
where bgm.sol_id='&1'
and comp_b2kid_type='BNKGR'
and bgm.bg_b2kid=cxl.comp_b2kid
and bg_status in ('A','E','G','O') and 
ceil(months_between((claim_expiry_date+1),effective_date))<=18 and
claim_expiry_date>to_date('&2','dd-mm-yyyy') and
effective_date<=to_date('&2','dd-mm-yyyy')
and bgm.bank_id='&3' and cxl.bank_id='&3'
order by 2
/
spool off
whenever sqlerror continue 
set termout on
undefine all_dashes
set feedback on
set verify on
set heading on
clear breaks
exit
