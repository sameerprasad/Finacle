set feedback off
set verify off
set echo off
set head off
spool ReturnChrgFail.lst
select '   Accounts for which Inward/Outward Return charges could not be posted' from dual
/
select '   --------------------------------------------------------------------' from dual
/
select 'Zone Date |Sol Id|Zone Code|Account No |Chq. No.|Chrg. Amount|Service Tax|A/c Balance' from dual
/
select ICICI_CHQRET.zone_date||'|'||ICICI_CHQRET.sol_id||'|'||ICICI_CHQRET.zone_code||'|'||ICICI_CHQRET.foracid||'|'||ICICI_CHQRET.inst_num||'|'||ICICI_CHQRET.chrg_amt||'|'||ICICI_CHQRET.ser_tax_amt||'|'||ICICI_CHQRET.acct_bal 
from ICICI_CHQRET, IZH
where ICICI_CHQRET.sol_id = '&1' 
and ICICI_CHQRET.zone_date = '&2'
and ICICI_CHQRET.zone_code = '&3'
and ICICI_CHQRET.bank_id   = '&4'
and IZH.bank_id = ICICI_CHQRET.bank_id
and IZH.sol_id = ICICI_CHQRET.sol_id
and IZH.zone_date = ICICI_CHQRET.zone_date
and IZH.zone_code = ICICI_CHQRET.zone_code
and IZH.zone_stat = 'Z'
/
spool off
