set serveroutput on
set feedback off
set verify off
set term off
set linesize 100
set page size 0
set linesize 100
spool 0103SL0INEMF_1300.txt
DECLARE
start_date varchar2(20);
end_date varchar2(20);

Cursor c1(st varchar2, en varchar2)  is 
select (select foracid from gam where acid=htd.acid and gam.bank_id = htd.bank_id  and bank_id = '&2') foracid ,tran_date,tran_particular,tran_amt,part_tran_type from htd where (tran_date,tran_id) in (select tran_date,tran_id from htd where acid in (select acid from gam where foracid ='10293563400101' and bank_id = '&2') and rcre_time between to_date(st||'1431','ddmmyyyyhh24mi') and to_date(en||'1300','ddmmyyyyhh24mi') and bank_id = '&2' ) and part_tran_type ='D' and del_flg ='N' and pstd_flg ='Y' and  bank_id = '&2' union select (select foracid from gam where acid=dtd.acid  and gam.bank_id = dtd.bank_id  and bank_id = '&2') foracid,tran_date,tran_particular,tran_amt,part_tran_type from dtd where (tran_date,tran_id) in (select tran_date,tran_id from dtd where acid in (select acid from gam where foracid ='10293563400101'  and bank_id = '&2' ) and rcre_time between to_date(st||'1431','ddmmyyyyhh24mi') and to_date(en||'1300','ddmmyyyyhh24mi') and bank_id = '&2' ) and part_tran_type ='D' and del_flg ='N' and pstd_flg ='Y' and bank_id = '&2';

BEGIN

Select to_char(db_stat_date, 'ddmmyyyy') into end_date from gct where bank_id = '&2';
Select to_char(db_stat_date-1,'ddmmyyyy') into start_date from gct where bank_id = '&2';

--dbms_output.put_line(start_date||'|'||end_date);
start_date:='05032009';
end_date:='04112011';

--dbms_output.put_line(start_date||'|'||end_date);

For c1rec in c1(start_date,end_date)
Loop --{

	dbms_output.put_line(c1rec.foracid||'|'||c1rec.tran_date||'|'||c1rec.tran_particular||'|'||c1rec.tran_amt||'|'||c1rec.part_tran_type);


end Loop; --}

END;
/
spool off
