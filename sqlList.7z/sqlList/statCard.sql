-- #############################################################
-- #	Source Name: statCard.sql				               #
-- #	Description: This script is used to get the required   #
-- #				details for stat card for HOMEOD and CAROD # 
-- #				in ~ seperated format.                     #
-- #############################################################

Set ServerOutPut On Size 1000000
--Set Verify Off
--Set FeedBack off
--set line 80
set trims on

Spool statCard.txt

DECLARE
		
-- Fields to be dumped.
totalDue				GAM.clr_bal_amt%type;
acctOpenChar				varchar2(10);
dobChar					varchar2(10);
endOfDayChar				varchar2(10);
lastPurChar				varchar2(10);
lastPaidChar				varchar2(10);
lastRtdChar				varchar2(10);
cardOpenChar				varchar2(10);
lastDelqChar				varchar2(10);
stmtDueChar				varchar2(10);
billChar				varchar2(10);
acctNumb				GAM.foracid%TYPE;
--customerName				CMG.cust_name%TYPE;
customerName				CRMUSER.ACCOUNTS.name%TYPE;

city     				RCT.ref_desc%TYPE;	
cashLimit				LHT.sanct_lim%TYPE:=0;
openToDraw				LHT.sanct_lim%TYPE;
collector				varchar(2):='';
acctOpenDate				GAM.acct_opn_date%TYPE;
--resiPhoneNo				CMG.cust_comu_phone_num_1%TYPE;
resiPhoneNo				CRMUSER.PHONEEMAIL.phoneno%TYPE;

--offPhoneNo				CMG.cust_emp_phone_num_1%TYPE;
offPhoneNo				CRMUSER.PHONEEMAIL.phoneno%TYPE;

--mobilePhoneNo				CMG.cust_comu_telex_num%TYPE;
mobilePhoneNo				CRMUSER.PHONEEMAIL.phoneno%TYPE;

--dob					CMG.date_of_birth%TYPE;
dob					CRMUSER.ACCOUNTS.cust_dob%TYPE;

--custAddLine1				CMG.cust_comu_addr1%TYPE;
custAddLine1				CRMUSER.ACCOUNTS.address_line1%TYPE;
--custAddLine2				CMG.cust_comu_addr2%TYPE;
custAddLine2				CRMUSER.ACCOUNTS.address_line2%TYPE;

--custAddCity				CMG.cust_comu_city_code%TYPE;
custAddCity				CRMUSER.CORPORATE.city%TYPE;

custAddCt				RCT.ref_desc%TYPE;
--custAddState				CMG.cust_comu_state_code%TYPE;
custAddState				CRMUSER.CORPORATE.state%TYPE;

custAddSt				RCT.ref_desc%TYPE;
--custAddPinCode			CMG.cust_comu_pin_code%TYPE;
custAddPinCode				CRMUSER.CORPORATE.zip%TYPE;

--offAddLine1				CMG.cust_emp_addr1%TYPE;
offAddLine1				CRMUSER.ACCOUNTS.address_line1%TYPE;

--offAddLine2				CMG.cust_emp_addr2%TYPE;
offAddLine2				CRMUSER.ACCOUNTS.address_line2%TYPE;

--offAddCity				CMG.cust_emp_city_code%TYPE;
offAddCity				CRMUSER.CORPORATE.city%TYPE;

offAddCt				RCT.ref_desc%TYPE;

--offAddState				CMG.cust_emp_state_code%TYPE;
offAddState				CRMUSER.CORPORATE.state%TYPE;

offAddSt				RCT.ref_desc%TYPE;

--offAddPinCode				CMG.cust_emp_pin_code%TYPE;
offAddPinCode				CRMUSER.CORPORATE.zip%TYPE;

creditLimit				LHT.sanct_lim%TYPE;
overLimit				ROBT.tod_amt%TYPE;
endOfDayBal				EAB.tran_date_bal%TYPE;
lastPurchaseOn				HTD.tran_date%TYPE;
lastPurchaseAmount			HTD.tran_amt%TYPE;
lastPaidOn				ROBT.last_adj_value_date%TYPE;
lastPaidAmount				ROBT.last_tran_amt%TYPE;
noRtdChq				ATO.num_times_chq_ret_out%TYPE;
lastRtdChqDate				ROBT.last_adj_value_date%TYPE;
lastRtdChqAmount			ATO.chq_ret_amt_out_clg%TYPE;
billCycle				varchar2(3);
currentBucket				varchar2(8);
endBalance				GAM.clr_bal_amt%TYPE;
currentBal				GAM.clr_bal_amt%TYPE;
billAmt					ROBT.bill_amt%TYPE;
currentDue				ROBT.bill_amt%TYPE;
x_days					number:=0;
days_30					number:=0;
days_60					number:=0;
days_90					number:=0;
days_120				number:=0;
days_150				number:=0;
days_180				number:=0;
days_210				number:=0;
mProfiles24				varchar2(200);
blockCode				varchar(2):='';
cardOpenDate				GAM.acct_opn_date%TYPE:='';
lastDelq				DCHT.status_date%TYPE;
minimumDue				ROBT.bill_amt%TYPE;
minAmtDue				ROBT.min_amt_due%TYPE;
lateFee					ROBT.late_fee_amt%TYPE;
stmtDueDate				ROBT.payment_due_date%TYPE;
ytdInterest				EIT.nrml_interest_amount_dr%TYPE;
billDate				ROBT.bill_gen_date%TYPE;
lanNo					varchar(2):='';
contactPer				varchar(2):='';
--nonMailAdd1				CMG.cust_perm_addr1%TYPE;
nonMailAdd1				CRMUSER.ACCOUNTS.address_line1%TYPE;

--nonMailAdd2				CMG.cust_perm_addr2%TYPE;
nonMailAdd2				CRMUSER.ACCOUNTS.address_line2%TYPE;

--nonMailAddCity			CMG.cust_perm_city_code%TYPE;
nonMailAddCity				CRMUSER.CORPORATE.city%TYPE;

nonMailAddCt				RCT.ref_desc%TYPE;

--nonMailAddState			CMG.cust_perm_state_code%TYPE;
nonMailAddState				CRMUSER.CORPORATE.state%TYPE;

nonMailAddSt				RCT.ref_desc%TYPE; 
--nonMailAddPinCode			CMG.cust_perm_pin_code%TYPE;
nonMailAddPinCode			CRMUSER.CORPORATE.zip%TYPE;

dealer					varchar(2):='';
vehicleModel				CVD.vehicle_model%TYPE:='';
regNumb					CVD.vehicle_regn_num%TYPE:='';
make					varchar2(2):='';
engineNumb				CVD.vehicle_engine_num%TYPE:='';
chassisNumb				CVD.vehicle_chassis_num%TYPE:='';
amtFinanced				LHT.sanct_lim%TYPE:=0;
schemePromo				GSP.schm_desc%TYPE;
emi					number:=0;
tenure					number:=0;
pdcStartDate				varchar(2):='';
pdcEndDate				varchar(2):='';
numbOfPDC				number:=0;
invoiceAmt				number:=0;
disbDate				varchar2(2):='';
disbAmt					number:=0;	
numbEmiOsNumb				number:=0;
numbEmiOsAmt				number:=0;
penalCharges				EIT.penal_interest_amount_dr%TYPE;
bounceCharges				number:=0;
noOfChqBounce				number:=0;	
amtOfChqBounce				number:=0;	
agency					varchar2(2):='';
executiveName				varchar2(2):='';
product1				varchar2(2):='';
amtFinanced1				LHT.sanct_lim%TYPE;
product2				varchar2(2):='';
amtFinanced2				number:=0;
product3				varchar2(2):=''; 
amtFinanced3				number:=0;
product4				varchar2(2):=''; 
amtFinanced4				number:=0;
product5				varchar2(2):=''; 
amtFinanced5				number:=0;
product6				varchar2(2):=''; 
amtFinanced6				number:=0;
dma					varchar2(2):=''; 
preEmiOs				number:=0;
dme					varchar2(2):=''; 
bounceChqFlag				varchar2(2):='';
delinqScore				number:=0;

-- Temporary variables.
solId					GAM.sol_id%TYPE;
cityCode				SOL.city_code%TYPE;
schmCode				GAM.schm_code%TYPE;
tmpAcid					ROBT.acid%TYPE;
dummyAcid				ROBT.acid%TYPE;
stmtEndDate				ROBT.stmt_end_date%TYPE;
cycleNo1				DCHT.cycle1%TYPE:=0;
cycleNo2				DCHT.cycle1%TYPE:=0;
cycleNo3				DCHT.cycle1%TYPE:=0;
cycleNo4				DCHT.cycle1%TYPE:=0;
cycleNo5				DCHT.cycle1%TYPE:=0;
cycleNo6				DCHT.cycle1%TYPE:=0;
cycleNo7				DCHT.cycle1%TYPE:=0;
cycleNo8				DCHT.cycle1%TYPE:=0;
cycleNo9				DCHT.cycle1%TYPE:=0;
cycleNo10				DCHT.cycle1%TYPE:=0;
statCard      				UTL_FILE.FILE_TYPE; 
fmode 					varchar2(100);
det_line 				varchar2(500) := '';
det_line1 				varchar2(1000) := '';

monthNumber				number:=1;
displayString				varchar2(500):='';
cycleCounter				number:=0;
startDate				GCT.db_stat_date%TYPE;
mnthStartDate				GCT.db_stat_date%TYPE;
mnthLastDate				GCT.db_stat_date%TYPE;
maxStatusDate				GCT.db_stat_date%TYPE;
dummyCount				number:=0;
tempDate				GCT.db_stat_date%TYPE;
tempDate1				GCT.db_stat_date%TYPE;
dbStatDate				GCT.db_stat_date%TYPE;

dpdCntr					GAC.dpd_cntr%TYPE;
sumBillAmt				ROBT.bill_amt%TYPE;
sumTotAdjAmt				ROBT.tot_adj_amt%TYPE;
countCorp				number(1) := 0;  
l_bank_id				VARCHAR2(8) := '&1';

CURSOR ROM_CURSOR IS SELECT distinct(acid) from ROBT;

CURSOR ROBT_CURSOR IS 
		SELECT nvl(bill_amt,0), nvl(tod_amt,0), bill_gen_date, nvl(last_tran_amt,0), 
			last_adj_tran_date, payment_due_date, stmt_end_date, acid
		FROM ROBT
		WHERE acid = tmpAcid
		AND   bank_id = l_bank_id
		ORDER BY acid, stmt_end_date DESC;	

CURSOR HTD_CURSOR IS
		SELECT tran_date, tran_amt FROM HTD
		WHERE acid = tmpAcid
			AND (TRAN_TYPE != 'T'
			AND TRAN_SUB_TYPE NOT IN ('BI','IC','IP'))
			AND PART_TRAN_TYPE = 'D'
			AND BANK_ID = l_bank_id
		ORDER BY tran_date DESC;
BEGIN
--{
	fmode	 := 'w';

	statCard:=UTL_FILE.FOPEN('/tmp','ex_stat_card.csv','w');

--	det_line1 := 'AccNumb'||'~'||'CustName'||'~'||'City'||'~'||'CashLimit'||'~'||'OpenToDraw'||'~'||'Collector'||'~'||'AccOpenDate'||'~'||'ResiPhNo'||'~'||'OffPhNo'||'~'||'MobilePhNo'||'~'||'DateOfBirth'||'~'||'CustAddLine1'||'~'||'CustAddLine2'||'~'||'CustAddCity'||'~'||'CustAddState'||'~'||'CustAddPinCode'||'~'||'OffAddLine1'||'~'||'OffAddLine2'||'~'||'OffAddCity'||'~'||'OffAddState'||'~'||'OffAddPinCode'||'~'||'CreditLimit'||'~'||'OverLimit'||'~'||'EndOfDayBal'||'~'||'LastPurchaseOn'||'~'||'LastPurchaseAmt'||'~'||'LastPaidOn'||'~'||'LastPaidAmt'||'~'||'NoOfRtdChq'||'~'||'LastRtdChqDate'||'~'||'LastRtdChqAmt'||'~'||'BillCycle'||'~'||'CurrentBucket'||'~'||'EndBal'||'~'||'CurrentBal'||'~'||'billAmt'||'~'||'CurrentDue'||'~'||'X_Days'||'~'||'Days30'||'~'||'Days60'||'~'||'Days90'||'~'||'Days120'||'~'||'Days150'||'~'||'Days180'||'~'||'Days210'||'~'||'24MonthProfiles'||'~'||'BlockCode'||'~'||'CardOpenDate'||'~'||'LastDelq'||'~'||'MinDue'||'~'||'StmtDueDate'||'~'||'YrToDateInt'||'~'||'BillDate'||'~'||'LanNo'||'~'||'ContactPer'||'~'||'NonMailAdd1'||'~'||'NonMailAdd2'||'~'||'NonMailAddCity'||'~'||'NonMailAddState'||'~'||'NonMailAddPinCode'||'~'||'Dealer'||'~'||'VehicleModel'||'~'||'RegNumb'||'~'||'Make'||'~'||'EngineNumb'||'~'||'ChassisNumb'||'~'||'AmtFinanced'||'~'||'SchemePromo'||'~'||'Emi'||'~'||'Tenure'||'~'||'PdcStartDate'||'~'||'PdcEndDate'||'~'||'NumbOfPdc'||'~'||'InvoiceAmt'||'~'||'DisbDate'||'~'||'DisbAmt'||'~'||'NumbOfOSEmi'||'~'||'OSEmiAmt'||'~'||'PenalCharges'||'~'||'BounceCharges'||'~'||'NoOfChqBounce'||'~'||'AmtOfChqBounce'||'~'||'Agency'||'~'||'ExecutiveName'||'~'||'Product1'||'~'||'AmtFinanced1'||'~'||'Product2'||'~'||'AmtFinanced2'||'~'||'Product3'||'~'||'AmtFinanced3'||'~'||'Product4'||'~'||'AmtFinanced4'||'~'||'Product5'||'~'||'AmtFinanced5'||'~'||'Product6'||'~'||'AmtFinanced6'||'~'||'Dma'||'~'||'PreEmiOS'||'~'||'Dme'||'~'||'BounceChqFlag'||'~'||'DelinqScore';
--	UTL_FILE.PUT_LINE(statCard,det_line1);

	OPEN ROM_CURSOR;

	LOOP
	--{
		FETCH ROM_CURSOR into tmpAcid;

		IF ROM_CURSOR%NOTFOUND THEN
			RETURN;
		END IF;

		BEGIN
		--{
			acctNumb 	:= '';
			schmCode 	:= '';
			solId 		:= '';
			currentBal 	:= 0;
			endOfDayBal := 0;

			SELECT foracid, schm_code, sol_id, clr_bal_amt, acct_opn_date
			INTO acctNumb, schmCode, solId, endBalance , cardOpenDate
			FROM GAM
			WHERE acid = tmpAcid
			AND   bank_id = l_bank_id;

			acctOpenDate := cardOpenDate;
			currentBal   := endBalance;
			endOfDayBal  := endBalance;
			totalDue := abs(endBalance);

			EXCEPTION
				WHEN OTHERS THEN NULL;
		--}
		END;

--		NOTE: Please put the valid scheme code to distinguish between HOME OD or CAR OD.
--		Here we have assumed it as HMOAD and CAROD.

		IF ((schmCode = 'HMOAD') OR (schmCode = 'CAROD') OR (schmCode = 'REVOD') OR (schmCode = 'RVOD1') OR (schmCode = 'REVEI')) THEN
		--{
		OPEN HTD_CURSOR;

		FETCH HTD_CURSOR 
		INTO lastPurchaseOn, lastPurchaseAmount;

		IF HTD_CURSOR%NOTFOUND THEN
			NULL;
		END IF;

		CLOSE HTD_CURSOR;

		OPEN ROBT_CURSOR;

		FETCH ROBT_CURSOR 
		INTO billAmt, overLimit, billDate, lastPaidAmount,
			lastPaidOn, stmtDueDate, stmtEndDate, dummyAcid;


		IF ROBT_CURSOR%NOTFOUND THEN
			NULL;
		END IF;

		begin
		--{
			select	nvl(abs(late_fee_amt),0),nvl(abs(min_amt_due),0)
			into	lateFee,minAmtDue
			from	robt
			where	acid = tmpAcid
			and		stmt_end_date=(	select 	max(stmt_end_date)
									from	robt
									where	acid = tmpAcid
									AND   bank_id = l_bank_id)
			AND     bank_id = l_bank_id;
		exception
			when others then
				lateFee := 0;
		--}
		end;

--		minimumDue := ((5*(totalDue))/100);
		minimumDue := minAmtDue + lateFee;
		currentDue := minAmtDue;

		CLOSE ROBT_CURSOR;

		billCycle := substr(stmtDueDate,0,2);

		BEGIN
		--{
			SELECT city_code INTO cityCode
			FROM SOL WHERE sol_id = solId
			AND   bank_id = l_bank_id;

			EXCEPTION
				WHEN OTHERS THEN NULL;
		--}
		END;

		BEGIN
		--{
			SELECT REF_DESC INTO city 
			FROM RCT WHERE ref_rec_type = '01' AND ref_code = cityCode
			AND   bank_id = l_bank_id;

			EXCEPTION
				WHEN OTHERS THEN NULL;
		--}
		END;

		BEGIN
		--{
			SELECT schm_desc INTO schemePromo
			FROM GSP WHERE schm_code = schmCode
			AND   bank_id = l_bank_id;

			EXCEPTION
				WHEN OTHERS THEN NULL;
		--}
		END;

		BEGIN
		--{
			SELECT count(1)
			INTO   countCorp
			FROM CRMUSER.CMG
			WHERE CIF_ID = (SELECT cif_id FROM GAM WHERE acid = tmpAcid)
			AND CORP_ID is NOT NULL
			AND   bank_id = l_bank_id;
			dbms_output.put_line(countCorp);

			EXCEPTION
			when others then NULL;
		--}
		END;

		IF (countCorp > 0) THEN
		--{
			BEGIN
			--{
				--Corporate CIF
				SELECT c.corporate_name, 
					DECODE(ad.ADDRESSCATEGORY,'MAILING',ad.address_line1),
					DECODE(ad.ADDRESSCATEGORY,'MAILING',ad.address_line2),
					DECODE(ad.ADDRESSCATEGORY,'MAILING',ad.city),
					DECODE(ad.ADDRESSCATEGORY,'MAILING',ad.state),
					DECODE(ad.ADDRESSCATEGORY,'MAILING',ad.zip),
					DECODE(p.PHONEEMAILTYPE, 'COMMPH1',p.phonenolocalcode), 
					DECODE(p.PHONEEMAILTYPE, 'WORKPH1',p.phonenolocalcode), 
					DECODE(p.PHONEEMAILTYPE, 'CELLPH', p.phonenolocalcode),
					c.date_of_commencement,
					DECODE(ad.ADDRESSCATEGORY,'HEAD OFFICE',ad.address_line1),
					DECODE(ad.ADDRESSCATEGORY,'HEAD OFFICE',ad.address_line2),
					DECODE(ad.ADDRESSCATEGORY,'HEAD OFFICE',ad.city),
					DECODE(ad.ADDRESSCATEGORY,'HEAD OFFICE',ad.state),
					DECODE(ad.ADDRESSCATEGORY,'HEAD OFFICE',ad.zip),
					DECODE(ad.ADDRESSCATEGORY,'REGISTERED',ad.address_line1),
					DECODE(ad.ADDRESSCATEGORY,'REGISTERED',ad.address_line2),
					DECODE(ad.ADDRESSCATEGORY,'REGISTERED',ad.city),
					DECODE(ad.ADDRESSCATEGORY,'REGISTERED',ad.state),
					DECODE(ad.ADDRESSCATEGORY,'REGISTERED',ad.zip)
				INTO customerName, custAddLine1, custAddLine2, custAddCity, custAddState,
					custAddPinCode,resiphoneNo, offPhoneNo, mobilePhoneNo, dob, offAddLine1, 
					offAddLine2, offAddCity, offAddState, offAddPinCode,
					nonMailAdd1,nonMailAdd2,nonMailAddCity,nonMailAddState,nonMailAddPinCode
				FROM CRMUSER.CORPORATE c, CRMUSER.PHONEEMAIL p , CRMUSER.ADDRESS ad
				WHERE c.corp_id = (SELECT cif_id FROM GAM WHERE acid = tmpAcid)
				AND c.corp_id = p.corp_id
				AND c.corp_id = ad.corp_id
				AND c.entity_create_flg = 'Y'
				AND c.bank_id = l_bank_id
				AND p.bank_id = l_bank_id
				AND ad.bank_id = l_bank_id;
				
				EXCEPTION
				WHEN OTHERS THEN NULL;
			--}
			END;

		--}
		ELSE
		--{
			BEGIN
			--{
				--Retail CIF
				SELECT a.name, 
					DECODE(ad.ADDRESSCATEGORY,'MAILING',ad.address_line1),
					DECODE(ad.ADDRESSCATEGORY,'MAILING',ad.address_line2),
					DECODE(ad.ADDRESSCATEGORY,'MAILING',ad.city),
					DECODE(ad.ADDRESSCATEGORY,'MAILING',ad.state),
					DECODE(ad.ADDRESSCATEGORY,'MAILING',ad.zip),
					DECODE(p.PHONEEMAILTYPE, 'COMMPH1',p.phoneno), 
					DECODE(p.PHONEEMAILTYPE, 'WORKPH1',p.phoneno), 
					DECODE(p.PHONEEMAILTYPE, 'CELLPH',p.phoneno),
					a.cust_dob,
					DECODE(ad.ADDRESSCATEGORY,'WORK',ad.address_line1),
					DECODE(ad.ADDRESSCATEGORY,'WORK',ad.address_line2),
					DECODE(ad.ADDRESSCATEGORY,'WORK',ad.city),
					DECODE(ad.ADDRESSCATEGORY,'WORK',ad.state),
					DECODE(ad.ADDRESSCATEGORY,'WORK',ad.zip),
					DECODE(ad.ADDRESSCATEGORY,'HOME',ad.address_line1),
					DECODE(ad.ADDRESSCATEGORY,'HOME',ad.address_line2),
					DECODE(ad.ADDRESSCATEGORY,'HOME',ad.city),
					DECODE(ad.ADDRESSCATEGORY,'HOME',ad.state),
					DECODE(ad.ADDRESSCATEGORY,'HOME',ad.zip)
				INTO customerName, custAddLine1, custAddLine2, custAddCity, custAddState,
					custAddPinCode,resiphoneNo, offPhoneNo, mobilePhoneNo, dob, offAddLine1, 
					offAddLine2, offAddCity, offAddState, offAddPinCode,
					nonMailAdd1,nonMailAdd2,nonMailAddCity,nonMailAddState,nonMailAddPinCode
				FROM CRMUSER.ACCOUNTS a , CRMUSER.PHONEEMAIL p , CRMUSER.ADDRESS ad
				WHERE a.orgkey = (SELECT cif_id FROM GAM WHERE acid = tmpAcid)
				AND a.orgkey = p.orgid
				AND a.orgkey = ad.orgkey
				AND a.entity_cre_flag = 'Y'
				AND a.bank_id = l_bank_id
				AND p.bank_id = l_bank_id
				AND ad.bank_id = l_bank_id;

				EXCEPTION
				WHEN OTHERS THEN NULL;
			--}
			END;
		--}
		END IF;
				
		BEGIN
		--{
			select	ref_desc
			into	offAddCt
			from	rct
			where	ref_rec_type = '01'
			and		ref_code = offAddCity
			and		del_flg = 'N'
			AND     bank_id = l_bank_id;
		EXCEPTION
			when others then NULL;
		--}
		END;

		BEGIN
		--{
			select	ref_desc
			into	nonMailAddCt
			from	rct
			where	ref_rec_type = '01'
			and		ref_code = nonMailAddCity
			and		del_flg = 'N'
			AND     bank_id = l_bank_id;
		EXCEPTION
			when others then NULL;
		--}
		END;

		BEGIN
		--{
			select	ref_desc
			into	custAddCt
			from	rct
			where	ref_rec_type = '01'
			and		ref_code = custAddCity
			and		del_flg = 'N'
			AND     bank_id = l_bank_id;
		EXCEPTION
			when others then NULL;
		--}
		END;

		BEGIN
		--{
			select	ref_desc
			into	offAddSt
			from	rct
			where	ref_rec_type = '02'
			and		ref_code = offAddState
			and		del_flg = 'N'
			AND     bank_id = l_bank_id;
		EXCEPTION
			when others then NULL;
		--}
		END;

		BEGIN
		--{
			select	ref_desc
			into	nonMailAddSt
			from	rct
			where	ref_rec_type = '02'
			and		ref_code = nonMailAddState
			and		del_flg = 'N'
			AND     bank_id = l_bank_id;
		EXCEPTION
			when others then NULL;
		--}
		END;

		BEGIN
		--{
			select	ref_desc
			into	custAddSt
			from	rct
			where	ref_rec_type = '02'
			and		ref_code = custAddState
			and		del_flg = 'N'
			AND     bank_id = l_bank_id;
		EXCEPTION
			when others then NULL;
		--}
		END;

		BEGIN
		--{
			creditLimit := 0;
			SELECT sanct_lim INTO creditLimit 
			FROM    LHT
            WHERE   acid = tmpAcid
            AND     serial_num = (  SELECT  max(serial_num)
                                    FROM    LHT
                                    WHERE   acid = tmpAcid
                                    and     status = 'A'
                                    AND     entity_cre_flg = 'Y'
                                    AND     del_flg != 'Y'
				    AND     bank_id = l_bank_id)
	    AND   bank_id = l_bank_id;
			EXCEPTION
				WHEN OTHERS THEN 
				creditLimit := 0;
		--}
		END;

		amtFinanced  := creditLimit;
		amtFinanced1 := creditLimit;
		openToDraw   := creditLimit - billAmt;
		if (openToDraw < 0) then
			openToDraw := 0;
		end if;

--		Cheque Details.

--		BEGIN
		--{
			noRtdChq         := 0;
			lastRtdChqDate   := '';
			lastRtdChqAmount := 0;
			noOfChQBounce    := 0;
			amtOfChqBounce   := 0;

--			SELECT sum(num_times_chq_ret_out), sum(chq_ret_amt_out_clg) 
--			INTO noOfChQBounce, amtOfChqBounce 
--			FROM ATO where acid = tmpAcid
--			GROUP BY acid;

--			noRtdChq := noOfChQBounce;
--			lastRtdChqAmount := amtOfChqBounce;

--			EXCEPTION
--				WHEN OTHERS THEN NULL;
		--}
--		END;

		--{ current bucket
        BEGIN
        --{
			cycleNo1 := 0;
			cycleNo2 := 0;
			cycleNo3 := 0;
			cycleNo4 := 0;
			cycleNo5 := 0;
			cycleNo6 := 0;
			cycleNo7 := 0;
			cycleNo8 := 0;
			cycleNo9 := 0;
			cycleNo10 := 0;
            SELECT cycle1, cycle2, cycle3, cycle4, cycle5,
                cycle6, cycle7, cycle8, cycle9, cycle10, status_date
            INTO cycleNo1, cycleNo2, cycleNo3, cycleNo4, cycleNo5, cycleNo6,
                cycleNo7, cycleNo8, cycleNo9, cycleNo10, lastDelq
            FROM DCHT
            WHERE acid = tmpAcid;

            EXCEPTION
                WHEN OTHERS THEN NULL;
        --}
        END;

		IF cycleNo10 > 0 THEN
		--{
			currentBucket := cycleNo10;
		--}
		ELSE
		--{
			IF cycleNo9 > 0 THEN
			currentBucket := cycleNo9;
		ELSE
		--{
			IF cycleNo8 > 0 THEN
			currentBucket := cycleNo8;
		ELSE
		--{
			IF cycleNo7 > 0 THEN
			currentBucket := cycleNo7;
		ELSE
		--{
			IF cycleNo6 > 0 THEN
			currentBucket := cycleNo6;
		ELSE
		--{
			IF cycleNo5 > 0 THEN
			currentBucket := cycleNo5;
		ELSE
		--{
			IF cycleNo4 > 0 THEN
			currentBucket := cycleNo4;
		ELSE
		--{
			IF cycleNo3 > 0 THEN
			currentBucket := cycleNo3;
		ELSE
		--{
			IF cycleNo2 > 0 THEN
			currentBucket := cycleNo2;
		ELSE
		--{
			currentBucket := cycleNo1;
		--}
		END IF;
		--}
		END IF;
		--}
		END IF;
		--}
		END IF;
		--}
		END IF;
		--}
		END IF;
		--}
		END IF;
		--}
		END IF;
		--}
		END IF;
		--} current bucket

		--{ Bucket Amount
		BEGIN
		--{
			SELECT dpd_cntr INTO dpdCntr FROM GAC
			WHERE acid = tmpAcid;

            EXCEPTION
                WHEN OTHERS THEN NULL;
		--}
		END;

		IF (dpdCntr > 0) THEN
		--{
			sumBillAmt := 0;
			sumTotAdjAmt := 0;
			x_days	:=0;
			days_30	:=0;
			days_60	:=0;
			days_90	:=0;
			days_120:=0;
			days_150:=0;
			days_180:=0;
			days_210:=0;

			SELECT to_date(((select db_stat_date from GCT) -dpdCntr), 'DD-MM-YYYY') 
			INTO tempDate from dual;

			IF dpdCntr < 30 THEN
				SELECT to_date((tempDate + dpdCntr), 'DD-MM-YYYY') into tempDate1 from dual;
--			ELSE
--				SELECT to_date((tempDate + 30 - 1), 'DD-MM-YYYY') into tempDate1 from dual;
--			END IF;

			SELECT nvl(sum(bill_amt),0), nvl(sum(tot_adj_amt),0) INTO sumBillAmt, sumTotAdjAmt from ROBT
			WHERE acid = tmpAcid 
				AND	payment_due_date >= tempDate
				AND payment_due_date <= tempDate1
				AND   bank_id = l_bank_id;

			x_days := sumBillAmt - sumTotAdjAmt;
			END IF;

			tempDate1 := '';
			IF ((dpdCntr >= 30) AND (dpdCntr <60)) THEN
				SELECT to_date((tempDate + dpdCntr), 'DD-MM-YYYY') into tempDate1 from dual;
--			ELSE
--				SELECT to_date((tempDate + 60 -1), 'DD-MM-YYYY') into tempDate1 from dual;
--			END IF;

			sumBillAmt := 0;
			sumTotAdjAmt := 0;

			SELECT sum(bill_amt), sum(tot_adj_amt) INTO sumBillAmt, sumTotAdjAmt from ROBT
			WHERE acid = tmpAcid 
				AND	payment_due_date >= tempDate
				AND payment_due_date <= tempDate1
				AND   bank_id = l_bank_id;

			days_30 := sumBillAmt - sumTotAdjAmt;
			END IF;

			tempDate1 := '';
			IF ((dpdCntr >= 60) AND (dpdCntr < 90)) THEN
				SELECT to_date((tempDate + dpdCntr), 'DD-MM-YYYY') into tempDate1 from dual;
--			ELSE
--				SELECT to_date((tempDate + 90 -1), 'DD-MM-YYYY') into tempDate1 from dual;
--			END IF;

			sumBillAmt := 0;
			sumTotAdjAmt := 0;

			SELECT sum(bill_amt), sum(tot_adj_amt) INTO sumBillAmt, sumTotAdjAmt from ROBT
			WHERE acid = tmpAcid 
				AND	payment_due_date >= tempDate
				AND payment_due_date <= tempDate1
				AND   bank_id = l_bank_id;

			days_60 := sumBillAmt - sumTotAdjAmt;
			END IF;

			tempDate1 := '';
			IF ((dpdCntr >= 90) AND (dpdCntr < 120)) THEN
				SELECT to_date((tempDate + dpdCntr), 'DD-MM-YYYY') into tempDate1 from dual;
--			ELSE
--				SELECT to_date((tempDate + 120 - 1), 'DD-MM-YYYY') into tempDate1 from dual;
--			END IF;

			sumBillAmt := 0;
			sumTotAdjAmt := 0;

			SELECT sum(bill_amt), sum(tot_adj_amt) INTO sumBillAmt, sumTotAdjAmt from ROBT
			WHERE acid = tmpAcid 
				AND	payment_due_date >= tempDate
				AND payment_due_date <= tempDate1
				AND   bank_id = l_bank_id;

			days_90 := sumBillAmt - sumTotAdjAmt;
			END IF;

			tempDate1 := '';
			IF ((dpdCntr >= 120) AND (dpdCntr < 150)) THEN
				SELECT to_date((tempDate + dpdCntr), 'DD-MM-YYYY') into tempDate1 from dual;
--			ELSE
--				SELECT to_date((tempDate + 150 -1), 'DD-MM-YYYY') into tempDate1 from dual;
--			END IF;

			sumBillAmt := 0;
			sumTotAdjAmt := 0;

			SELECT sum(bill_amt), sum(tot_adj_amt) INTO sumBillAmt, sumTotAdjAmt from ROBT
			WHERE acid = tmpAcid 
				AND	payment_due_date >= tempDate
				AND payment_due_date <= tempDate1
				AND   bank_id = l_bank_id;

			days_120 := sumBillAmt - sumTotAdjAmt;
			END IF;

			tempDate1 := '';
			IF ((dpdCntr >= 150) AND (dpdCntr < 180)) THEN
				SELECT to_date((tempDate + dpdCntr), 'DD-MM-YYYY') into tempDate1 from dual;
--			ELSE
--				SELECT to_date((tempDate + 180 -1), 'DD-MM-YYYY') into tempDate1 from dual;
--			END IF;

			sumBillAmt := 0;
			sumTotAdjAmt := 0;

			SELECT sum(bill_amt), sum(tot_adj_amt) INTO sumBillAmt, sumTotAdjAmt from ROBT
			WHERE acid = tmpAcid 
				AND	payment_due_date >= tempDate
				AND payment_due_date <= tempDate1
				AND   bank_id = l_bank_id;

			days_150 := sumBillAmt - sumTotAdjAmt;
			END IF;

			tempDate1 := '';
			IF ((dpdCntr >= 180) AND (dpdCntr < 210)) THEN
				SELECT to_date((tempDate + dpdCntr), 'DD-MM-YYYY') into tempDate1 from dual;
--			ELSE
--				SELECT to_date((tempDate + 210 -1), 'DD-MM-YYYY') into tempDate1 from dual;
--			END IF;

			sumBillAmt := 0;
			sumTotAdjAmt := 0;

			SELECT sum(bill_amt), sum(tot_adj_amt) INTO sumBillAmt, sumTotAdjAmt from ROBT
			WHERE acid = tmpAcid 
				AND	payment_due_date >= tempDate
				AND payment_due_date <= tempDate1
				AND   bank_id = l_bank_id;

			days_180 := sumBillAmt - sumTotAdjAmt;
			END IF;

			tempDate1 := '';
			IF (dpdCntr >= 210) THEN
				SELECT to_date((tempDate + dpdCntr), 'DD-MM-YYYY') into tempDate1 from dual;
--			END IF;

			sumBillAmt := 0;
			sumTotAdjAmt := 0;

			SELECT sum(bill_amt), sum(tot_adj_amt) INTO sumBillAmt, sumTotAdjAmt from ROBT
			WHERE acid = tmpAcid 
				AND	payment_due_date >= tempDate
				AND payment_due_date <= tempDate1
				AND   bank_id = l_bank_id;

			days_210 := sumBillAmt - sumTotAdjAmt;
			END IF;
		--}
		END IF;
		--} Bucket Amount

		--{ mProfiles24
		SELECT db_stat_date INTO dbStatDate from GCT;
		startDate := add_months(dbStatDate, -11);

		monthNumber  := 1;
		cycleCounter := 0;
		displayString:='';

		WHILE monthNumber <= 12 LOOP
		--{
			dummyCount	:= 0;
			cycleCounter := 10;

			SELECT to_date('01-'||to_char(startDate,'MM-YYYY')) INTO mnthStartDate from dual;
			mnthLastDate := last_day(startDate);

			SELECT to_date(to_char(max(status_date),'DD-MM-YYYY HH24:MI:SS'),'DD-MM-YYYY HH24:MI:SS')
			INTO maxStatusDate
			FROM DCHT WHERE acid = tmpAcid
			AND status_date <=to_date(mnthStartDate,'DD-MM-YYYY HH24:MI:SS');

			IF maxStatusDate != '' THEN
				mnthStartDate := maxStatusDate;
			END IF;

			WHILE cycleCounter >= 1 LOOP
			--{
				IF cycleCounter = 1 THEN
				--{
					SELECT COUNT(1) INTO dummyCount
					FROM DCHT WHERE cycle1>0
					AND STATUS_DATE >= TO_DATE(mnthStartDate,'DD-MM-YYYY HH24:MI:SS')
					AND STATUS_DATE <= TO_DATE(mnthLastDate,'DD-MM-YYYY HH24:MI:SS')   
					AND acid = tmpAcid
					AND   bank_id = l_bank_id;
				--}
				END IF;

				IF cycleCounter = 2 THEN
				--{
					SELECT COUNT(1) INTO dummyCount
					FROM DCHT WHERE cycle2>0
					AND STATUS_DATE >= TO_DATE(mnthStartDate,'DD-MM-YYYY HH24:MI:SS')
					AND STATUS_DATE <= TO_DATE(mnthLastDate,'DD-MM-YYYY HH24:MI:SS')   
					AND acid = tmpAcid;
				--}
				END IF;

				IF cycleCounter = 3 THEN
				--{
					SELECT COUNT(1) INTO dummyCount
					FROM DCHT WHERE cycle3>0
					AND STATUS_DATE >= TO_DATE(mnthStartDate,'DD-MM-YYYY HH24:MI:SS')
					AND STATUS_DATE <= TO_DATE(mnthLastDate,'DD-MM-YYYY HH24:MI:SS')   
					AND acid = tmpAcid
					AND   bank_id = l_bank_id;
				--}
				END IF;

				IF cycleCounter = 4 THEN
				--{
					SELECT COUNT(1) INTO dummyCount
					FROM DCHT WHERE cycle4>0
					AND STATUS_DATE >= TO_DATE(mnthStartDate,'DD-MM-YYYY HH24:MI:SS')
					AND STATUS_DATE <= TO_DATE(mnthLastDate,'DD-MM-YYYY HH24:MI:SS')   
					AND acid = tmpAcid
					AND   bank_id = l_bank_id;
				--}
				END IF;

				IF cycleCounter = 5 THEN
				--{
					SELECT COUNT(1) INTO dummyCount
					FROM DCHT WHERE cycle5>0
					AND STATUS_DATE >= TO_DATE(mnthStartDate,'DD-MM-YYYY HH24:MI:SS')
					AND STATUS_DATE <= TO_DATE(mnthLastDate,'DD-MM-YYYY HH24:MI:SS')   
					AND acid = tmpAcid
					AND   bank_id = l_bank_id;
				--}
				END IF;

				IF cycleCounter = 6 THEN
				--{
					SELECT COUNT(1) INTO dummyCount
					FROM DCHT WHERE cycle6>0
					AND STATUS_DATE >= TO_DATE(mnthStartDate,'DD-MM-YYYY HH24:MI:SS')
					AND STATUS_DATE <= TO_DATE(mnthLastDate,'DD-MM-YYYY HH24:MI:SS')   
					AND acid = tmpAcid
					AND   bank_id = l_bank_id;
				--}
				END IF;

				IF cycleCounter = 7 THEN
				--{
					SELECT COUNT(1) INTO dummyCount
					FROM DCHT WHERE cycle7>0
					AND STATUS_DATE >= TO_DATE(mnthStartDate,'DD-MM-YYYY HH24:MI:SS')
					AND STATUS_DATE <= TO_DATE(mnthLastDate,'DD-MM-YYYY HH24:MI:SS')   
					AND acid = tmpAcid
					AND   bank_id = l_bank_id;
				--}
				END IF;

				IF cycleCounter = 8 THEN
				--{
					SELECT COUNT(1) INTO dummyCount
					FROM DCHT WHERE cycle8>0
					AND STATUS_DATE >= TO_DATE(mnthStartDate,'DD-MM-YYYY HH24:MI:SS')
					AND STATUS_DATE <= TO_DATE(mnthLastDate,'DD-MM-YYYY HH24:MI:SS')   
					AND acid = tmpAcid
					AND   bank_id = l_bank_id;
				--}
				END IF;

				IF cycleCounter = 9 THEN
				--{
					SELECT COUNT(9) INTO dummyCount
					FROM DCHT WHERE cycle9>0
					AND STATUS_DATE >= TO_DATE(mnthStartDate,'DD-MM-YYYY HH24:MI:SS')
					AND STATUS_DATE <= TO_DATE(mnthLastDate,'DD-MM-YYYY HH24:MI:SS')   
					AND acid = tmpAcid
					AND   bank_id = l_bank_id;
				--}
				END IF;

				IF cycleCounter = 10 THEN
				--{
					SELECT COUNT(10) INTO dummyCount
					FROM DCHT WHERE cycle10>0
					AND STATUS_DATE >= TO_DATE(mnthStartDate,'DD-MM-YYYY HH24:MI:SS')
					AND STATUS_DATE <= TO_DATE(mnthLastDate,'DD-MM-YYYY HH24:MI:SS')   
					AND acid = tmpAcid
					AND   bank_id = l_bank_id;
				--}
				END IF;

				IF dummyCount = 0 THEN
					cycleCounter := cycleCounter - 1;
				ELSE
					exit;
				END IF;
			--}
			END LOOP;
			displayString :=  trim(displayString);

			IF (displayString is not NULL) THEN
				displayString := displayString || cycleCounter;
			ELSE
				displayString := cycleCounter;
			END IF;
		
			monthNumber := monthNumber + 1;

			startDate := add_months(startDate, 1);

		--}
		END LOOP;

		mProfiles24 := displayString;	
		--} mProfiles24

		BEGIN
		--{
			SELECT nrml_interest_amount_dr, penal_interest_amount_dr 
			INTO ytdInterest, penalCharges from EIT
			WHERE entity_id = tmpAcid
				AND entity_type = 'ACCNT'
				AND   bank_id = l_bank_id;

            EXCEPTION
                WHEN OTHERS THEN NULL;
		--}
		END;
		IF (dpdCntr > 0) THEN 
		--{

			begin
				select	to_char(acctOpenDate,'mm-dd-yyyy'),to_char(dob,'mm-dd-yyyy'),
						to_char(lastPurchaseOn,'mm-dd-yyyy'),
						to_char(lastPaidOn,'mm-dd-yyyy'),to_char(lastRtdChqDate,'mm-dd-yyyy'),
						to_char(cardOpenDate,'mm-dd-yyyy'),to_char(lastDelq,'mm-dd-yyyy'),
						to_char(stmtDueDate,'mm-dd-yyyy'),to_char(billDate,'mm-dd-yyyy'),
						to_char(dbStatDate,'mm-dd-yyyy')
				into	acctOpenChar,dobChar,lastPurChar,lastPaidChar,lastRtdChar,
						cardOpenChar,lastDelqChar,stmtDueChar,billChar,endOfDayChar
				from dual;
			exception
				when others then NULL;
			end;

		det_line := acctNumb||'~'||customerName||'~'||city||'~'||cashLimit||'~'||openToDraw||'~'||collector||'~'||acctOpenChar||'~'||resiPhoneNo||'~'||offPhoneNo||'~'||mobilePhoneNo||'~'||dobChar||'~'||custAddLine1||'~'||custAddLine2||'~'||custAddCt||'~'||custAddSt||'~'||custAddPinCode||'~'||offAddLine1||'~'||offAddLine2||'~'||offAddCt||'~'||offAddSt||'~'||offAddPinCode||'~'||creditLimit||'~'||overLimit||'~~'||lastPurChar||'~'||abs(lastPurchaseAmount)||'~'||lastPaidChar||'~'||abs(lastPaidAmount)||'~'||noRtdChq||'~'||lastRtdChar||'~'||lastRtdChqAmount||'~'||billCycle||'~'||currentBucket||'~'||abs(endBalance)||'~'||abs(currentBal)||'~'||abs(billAmt)||'~'||abs(currentDue)||'~'||abs(x_days)||'~'||abs(days_30)||'~'||abs(days_60)||'~'||abs(days_90)||'~'||abs(days_120)||'~'||abs(days_150)||'~'||abs(days_180)||'~'||abs(days_210)||'~'||mProfiles24||'~'||blockCode||'~'||cardOpenChar||'~'||lastDelqChar||'~'||abs(minimumDue)||'~'||stmtDueChar||'~'||abs(ytdInterest)||'~'||billChar||'~'||lanNo||'~'||contactPer||'~'||nonMailAdd1||'~';

		UTL_FILE.PUT(statCard,det_line);
		det_line:=nonMailAdd2||'~'||nonMailAddCt||'~'||nonMailAddSt||'~'||nonMailAddPinCode||'~'||dealer||'~'||vehicleModel||'~'||regNumb||'~'||make||'~'||engineNumb||'~'||chassisNumb||'~'||amtFinanced||'~'||schemePromo||'~'||emi||'~'||tenure||'~'||pdcStartDate||'~'||pdcEndDate||'~'||numbOfPdc||'~'||invoiceAmt||'~'||disbdate||'~'||disbAmt||'~'||numbEmiOsNumb||'~'||numbEmiOsAmt||'~'||abs(penalCharges)||'~'||bounceCharges||'~'||noOfChqBounce||'~'||amtOfChqBounce||'~'||agency||'~'||executiveName||'~'||product1||'~'||amtFinanced1||'~'||product2||'~'||amtFinanced2||'~'||product3||'~'||amtFinanced3||'~'||product4||'~'||amtFinanced4||'~'||product5||'~'||amtFinanced5||'~'||product6||'~'||amtFinanced6||'~'||dma||'~'||preEmiOs||'~'||dme||'~'||bounceChqFlag||'~'||delinqScore;
		UTL_FILE.PUT_LINE(statCard,det_line);
		--}
		END IF;
	--}
	END IF;
	--}
	END LOOP;
	UTL_FILE.FCLOSE(statCard);
	CLOSE ROM_CURSOR;
--}
END;
/
--exit
--spool off
