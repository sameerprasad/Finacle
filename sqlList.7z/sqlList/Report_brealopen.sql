----------------------------------------------------------------------------------------------------
--   Source Name            : Report_brealopen.sql 
--   Description            : Break Open Report.
--   Input Values           : None
--   Output Values          : None
--   Called Script          : N.A
--   Calling Script         : N.A
--   Modification History:
--   Sl No.         Date              Author                     Description
--   --------------------------------------------------------------------------------------
--     01         08-Oct-2012         Priyanka                 Original Version
----------------------------------------------------------------------------------------------------

set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_brealopen.lst

DECLARE

lv_solid         gam.sol_id%type :='&1';
date1         lcbrkop.BREAK_OPEN_DATE%type:= '&2';
date2            lcbrkop.BREAK_OPEN_DATE%type:= '&3';
lv_bankid        lcbrkop.bank_id%type:= '&4';

CURSOR c1 IS


select  lcbrkop.sol_id,
	lcbrkop.locker_type,
	wlckm.rack_id,
	lcbrkop.LOCK_NO,
	clmt.cif_id,
	substr(lcbrkop.cust_name,1,40) cust_name,
	clmt.issue_date,
	clmt.due_date,
	substr(lcbrkop.REASON,1,40) REASON,
	lcbrkop.BREAK_OPEN_DATE,
	substr(lcbrkop.LCHG_TIME,1,10) dateOfUpdate,
	decode(opr_type,'CI','CUSTOMER INDUCED','BI','BANK INDUCED') opr_type
from    lcbrkop,wlckm,clmt
where   wlckm.locker_num = clmt.locker_num
and     lcbrkop.LOCK_NO = clmt.locker_num
and     clmt.cif_id = lcbrkop.cif_id
and     wlckm.del_flg!='Y'
and     clmt.del_flg!='Y'
and     lcbrkop.sol_id = lv_solid
and     lcbrkop.bank_id = clmt.bank_id
and     wlckm.bank_id = clmt.bank_id
and     clmt.bank_id = lv_bankid
and     substr(lcbrkop.BREAK_OPEN_DATE,1,10) between date1 and date2
ORDER by 10,4;

BEGIN

    for f1 in c1
    loop
    dbms_output.enable(buffer_size => NULL);
dbms_output.put_line( f1.sol_id         ||'|'||
                      f1.locker_type    ||'|'||
                      f1.rack_id        ||'|'||
                      f1.lock_no        ||'|'||
                      f1.cif_id        ||'|'||
                      f1.cust_name      ||'|'|| 
                      f1.issue_date     ||'|'||
                      f1.due_date         ||'|'||
                      f1.reason         ||'|'||  
                      f1.BREAK_OPEN_DATE      ||'|'||
                      f1.dateOfUpdate        ||'|'||
                      f1.opr_type); 
           end loop; 
END;
/
spool off

