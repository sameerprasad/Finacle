--
--	File	:	daily_dump_dorma.sql
--	Auth	:	Eldo
--	Modi	:	Ashwani
--	Date	:	28-09-2011
--	Desc	:	SQL to extract the dump of Inactive/Dormant Accts on daily basis. 
--	Modified:	Pradeep Murgod(Modified according to 10x requirements used cnma table to access address details of customer)

set document off
set trimspool on
set serverout on size 1000000
set termout off
set linesize 1000
set head off
set verify off
set feedback off
set pages 0

spool &2

declare 
	custname	cnma.name%type;
	custaddr1	cnma.address1%type;
	custaddr2	cnma.address2%type;
	custpin		cnma.pin_code%type;
	custstcd	cnma.state_code%type;
	custctcd	cnma.city_code%type;
	custcncd	cnma.cntry_code%type;
	custttcd	cnma.cust_title_code%type;
	custstate	rct.ref_desc%type;
	custcity	rct.ref_desc%type;
	custcntry	rct.ref_desc%type;
	soldesc		sol.sol_desc%type;
	fp_opfile	utl_file.file_type;
	opfilename	varchar2(100);
	statdate	date;
	acstat		char(3);
	custid		cmg.cust_id%type;
	fora		gam.foracid%type;
	bankId		cmg.bank_id%type;

    solid       sol.sol_id%type := '&1';
    opdirname   varchar2(100) := '&2';

	prevdate 		date;
	monthyear_date 	varchar2(6);
	prevday 		varchar2(4);
	holiday 		varchar2(4);
	dorDate			date;



	cursor cur_gam(cv_schm varchar2, cv_stat varchar2, cv_statdt date) is
		select foracid, cust_id cid, acct_status_date stdate, decode(acct_status,'I',cv_stat||'INACT','D',cv_stat||'DORMA') stat
		from gam, smt
		where gam.sol_id = solid
		and gam.schm_code = cv_schm
		and gam.acct_cls_flg = 'N'
		and gam.entity_cre_flg = 'Y'
		and gam.del_flg = 'N'
		and nvl(gam.frez_code,'N') != 'D' and nvl(gam.frez_reason_code,'NULL') != 'IKIT'
		and gam.acid = smt.acid
		and smt.acct_status != 'A'
		and round(months_between(cv_statdt,gam.last_tran_date),2) = '21';
--------------------------------------
-- Added BankId		
--------------------------------------
		and smt.bank_id = gam.bank_id
		and smt.bank_id = bankId		

	cursor cur_gam1(cv_schm varchar2, cv_stat varchar2, cv_statdt date) is
		select foracid, cust_id cid, acct_status_date stdate, decode(acct_status,'I',cv_stat||'IDORM','D',cv_stat||'IDORM') stat
		from gam, smt
		where gam.sol_id = solid
		and gam.schm_code = cv_schm
		and gam.acct_cls_flg = 'N'
		and gam.entity_cre_flg = 'Y'
		and gam.del_flg = 'N'
		and nvl(gam.frez_code,'N') != 'D' and nvl(gam.frez_reason_code,'NULL') != 'IKIT'
		and gam.acid = smt.acid
		and smt.acct_status = 'I'
		and round(months_between(cv_statdt,gam.last_tran_date),2) = '21';
--------------------------------------
-- Added BankId		
--------------------------------------
		and smt.bank_id = gam.bank_id
		and smt.bank_id = bankId


	cursor cur_gam2(cv_schm varchar2, cv_stat varchar2, cv_statdt date) is
		select foracid, cust_id cid, acct_status_date stdate, decode(acct_status,'I',cv_stat||'IDORM','D',cv_stat||'IIORM') stat
		from gam, smt
		where gam.sol_id = solid
		and gam.schm_code = cv_schm
		and gam.acct_cls_flg = 'N'
		and gam.entity_cre_flg = 'Y'
		and gam.del_flg = 'N'
		and nvl(gam.frez_code,'N') != 'D' and nvl(gam.frez_reason_code,'NULL') != 'IKIT'
		and gam.acid = smt.acid
		and smt.acct_status = 'I'
		and round(months_between(cv_statdt,gam.last_tran_date),2) = '21';

--------------------------------------
-- Added BankId		
--------------------------------------
		and smt.bank_id = gam.bank_id
		and smt.bank_id = bankId

begin
	select db_stat_date into statdate from gct where bank_id =bankId;
	select db_stat_date - 1 into prevdate from gct where bank_id = bankId;
	select substr(prevdate,4,2)||''||substr(prevdate,7,4) into monthyear_date from gct where bank_id = bankId;
	select substr(prevdate,1,2) into prevday from gct where bank_id = bankId;
	select decode(substr(HLDY_STR,prevday,1),'Y','Y','N') into holiday from hol where CAL_B2K_TYPE = 'DC' and MMYYYY = monthyear_date and bank_id= bankId;
	select sol_desc into soldesc from sol where sol_id = solid and bank_id = bankId;

--==================================================================
-- CR-138-17121
--==================================================================
--============================================
-- Previous Day Not a Haliday
--============================================
    /* Processing Resident Accts */
    for rs1 in (select schm_code schm,schm_type from gsp where schm_type in ('SBA','CAA') and del_flg = 'N' and nre_schm_flg = 'N' and bank_id = bankId order by schm_code)
    loop --{
        begin --{
            acstat := 'RES';
            for rg1 in cur_gam1(rs1.schm, acstat, statdate) loop --{
                begin --{
                    custid := rg1.cid;
                    fora := rg1.foracid;
                    select cnma.name, cnma.address1, cnma.address2, cnma.pin_code, cnma.cust_title_code,
                    nvl(cnma.state_code,'*'), nvl(cnma.city_code,'*'), nvl(cnma.cntry_code,'*')
                    into custname, custaddr1, custaddr2, custpin, custttcd,
                    custstcd, custctcd, custcncd
                    from cnma
                    where cust_id = rg1.cid
			and bank_id = bankId;
                    /* City Code */
                    select ref_desc into custcity from rct
                    where ref_rec_type = '01'
                      and ref_code = custctcd
			and bank_id = bankId;
                    /* State Code */
                    select ref_desc into custstate from rct
                    where ref_rec_type = '02'
                      and ref_code = custstcd
			and bank_id = bankId;
                    /* Country Code */
                    select ref_desc into custcntry from rct
                    where ref_rec_type = '03'
                      and ref_code = custcncd
			and bank_id = bankId;
                    dbms_output.put_line(rs1.schm_type||'|'||to_char(sysdate,'Month DD, YYYY')||'|'||rg1.cid||'|'||custttcd||'|'||trim(custname)||'|'||trim(custaddr1)||'|'||trim(custaddr2)||'|'||custcity||'|'||custpin||'|'||custstate||'|'||custcntry||'|'||rg1.foracid||'|'||rg1.stat||'|'||rg1.stdate||'|'||soldesc);
                exception
                    when no_data_found then
                        null;
                end; --}
            end loop; --}
        end; --}
    end loop; --}
    
--============================================
-- On Previous Day Haliday
--============================================
if (holiday = 'Y') then
--{
   /* Processing Resident Accts */
    for rs2 in (select schm_code schm,schm_type from gsp where schm_type in ('SBA','CAA') and del_flg = 'N' and nre_schm_flg = 'N' bank_id = bankId order by schm_code)
    loop --{
        begin --{
            acstat := 'RES';
            for rg2 in cur_gam2(rs2.schm, acstat, prevdate) loop --{
                begin --{
                    custid := rg2.cid;
                    fora := rg2.foracid;
                   select cnma.name, cnma.address1, cnma.address2, cnma.pin_code, cnma.cust_title_code,
                    nvl(cnma.state_code,'*'), nvl(cnma.city_code,'*'), nvl(cnma.cntry_code,'*')
                    into custname, custaddr1, custaddr2, custpin, custttcd,
                    custstcd, custctcd, custcncd
                    from cnma
                    where cust_id = rg2.cid
		and bank_id = bankId;
                    /* City Code */
                    select ref_desc into custcity from rct
                    where ref_rec_type = '01'
                      and ref_code = custctcd
			and bank_id = bankId;
                    /* State Code */
                    select ref_desc into custstate from rct
                    where ref_rec_type = '02'
                      and ref_code = custstcd
			and bank_id = bankId;
                    /* Country Code */
                    select ref_desc into custcntry from rct
                    where ref_rec_type = '03'
                      and ref_code = custcncd
			and bank_id = bankId;
					dbms_output.put_line(rs2.schm_type||'|'||to_char(sysdate,'Month DD, YYYY')||'|'||rg2.cid||'|'||custttcd||'|'||trim(custname)||'|'||trim(custaddr1)||'|'||trim(custaddr2)||'|'||custcity||'|'||custpin||'|'||custstate||'|'||custcntry||'|'||rg2.foracid||'|'||rg2.stat||'|'||rg2.stdate||'|'||soldesc);
                exception
                    when no_data_found then
                        null;
                end; --}
            end loop; --}
        end; --}
    end loop; --}
--}
end if;

--================================================================================

	/* Processing NRI Accts */
	for rs in (select schm_code schm from gsp where schm_type = 'SBA' and del_flg = 'N' and nre_schm_flg = 'Y'  and bank_id = bankId order by schm_code)
	loop --{
		begin --{
			acstat := 'NRI';
			for rg in cur_gam(rs.schm, acstat, statdate) loop --{
				begin --{
					custid := rg.cid;
					fora := rg.foracid;
						select cnma.name, cnma.address1, cnma.address2, cnma.pin_code, cnma.cust_title_code,
						nvl(cnma.state_code,'*'), nvl(cnma.city_code,'*'), nvl(cnma.cntry_code,'*')
						into custname, custaddr1, custaddr2, custpin, custttcd,
						custstcd, custctcd, custcncd
						from cnma
					where cust_id = rg.cid
					and bank_id = bankId;
					/* City Code */
					select ref_desc into custcity from rct
					where ref_rec_type = '01'
				  	and ref_code = custctcd
					and bank_id = bankId;
					/* State Code */
					select ref_desc into custstate from rct
					where ref_rec_type = '02'
				  	and ref_code = custstcd
					and bank_id = bankId;
					/* Country Code */
					select ref_desc into custcntry from rct
					where ref_rec_type = '03'
				  	and ref_code = custcncd
					and bank_id = bankId;

					dbms_output.put_line(to_char(sysdate,'Month DD, YYYY')||'|'||rg.cid||'|'||custttcd||'|'||trim(custname)||'|'||trim(custaddr1)||'|'||trim(custaddr2)||'|'||custcity||'|'||custpin||'|'||custstate||'|'||custcntry||'|'||rg.foracid||'|'||rg.stat||'|'||rg.stdate||'|'||soldesc||'|'||to_char(sysdate+90,'Month DD, YYYY'));
				exception
					when no_data_found then
						null;
				end; --}
			end loop; --}
		end; --}
	end loop; --}

	/* Processing Resident Accts */
	/* Modified by Radhika for including CAA type a/cs */
	for rs in (select schm_code schm,schm_type from gsp where schm_type in ('SBA','CAA') and del_flg = 'N' and nre_schm_flg = 'N' and bank_id = bankId order by schm_code)
	loop --{
		begin --{
			acstat := 'RES';
			for rg in cur_gam(rs.schm, acstat, statdate) loop --{
				begin --{
					custid := rg.cid;
					fora := rg.foracid;
						select cnma.name, cnma.address1, cnma.address2, cnma.pin_code, cnma.cust_title_code,
						nvl(cnma.state_code,'*'), nvl(cnma.city_code,'*'), nvl(cnma.cntry_code,'*')
						into custname, custaddr1, custaddr2, custpin, custttcd,
						custstcd, custctcd, custcncd
						from cnma
					where cust_id = rg.cid
					and bank_id = bankId;
					/* City Code */
					select ref_desc into custcity from rct
					where ref_rec_type = '01'
					  and ref_code = custctcd
					and bank_id = bankId;
					/* State Code */
					select ref_desc into custstate from rct
					where ref_rec_type = '02'
					  and ref_code = custstcd
					and bank_id = bankId;
					/* Country Code */
					select ref_desc into custcntry from rct
					where ref_rec_type = '03'
					  and ref_code = custcncd
					and bank_id = bankId;
					dbms_output.put_line(rs.schm_type||'|'||to_char(sysdate,'Month DD, YYYY')||'|'||rg.cid||'|'||custttcd||'|'||trim(custname)||'|'||trim(custaddr1)||'|'||trim(custaddr2)||'|'||custcity||'|'||custpin||'|'||custstate||'|'||custcntry||'|'||rg.foracid||'|'||rg.stat||'|'||rg.stdate||'|'||soldesc);
				exception
					when no_data_found then
						null;
				end; --}
			end loop; --}
		end; --}
	end loop; --}
	

exception
	when others then
		dbms_output.put_line('*** ERROR ***');
		dbms_output.put_line(custid||'|'||fora||'|'||custctcd||'|'||custstcd||'|'||custcncd);
		dbms_output.put_line(sqlerrm);
end;
/

spool off

exit

