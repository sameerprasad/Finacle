set serveroutput on size 1000000
set head off
set linesize 512
set trims on
set pages 0
set feedback off
set verify off
set termout off
spool &1-SAR

DECLARE
CURSOR solCur IS
SELECT	sol_id
FROM	SST
WHERE	set_id = '&2'
and bank_id = '&3';

bankCode	sol.bank_code%TYPE;
brCode		sol.bank_code%TYPE;
brPrtcls	varchar2(200);

BEGIN
	for solRec in solCur loop
	BEGIN
		SELECT	bank_code,
				br_code
		INTO	bankCode,
				brCode
		FROM	SOL
		WHERE	sol_id = solRec.sol_id
		AND		del_flg !='Y'
		and bank_id = '&3';

		SELECT	br_name || '|' ||
				br_addr_1 || '|' ||
				br_addr_2 || '|' ||
				br_pin_code || '|' ||
				'CustomerStateMent'
		INTO	brPrtcls
		FROM	BCT  
		WHERE	bct.bank_code = bankCode  
		AND		bct.br_code= brCode
		and bank_id = '&3';

		EXCEPTION
			when NO_DATA_FOUND then NULL;

	END;

	DBMS_OUTPUT.PUT_LINE(solRec.sol_id || '|         |00|0|' || brPrtcls);

	end loop;

END;
/
spool off
