=====================================================================================================================
-- Source Name            :  CUST_TDS50000_alter.sql
-- Description            :  To alter the table CUST_TDS50000
-- Input Values           :  None    
-- Output Values          :  None
-- Called Scripts         :  None   
-- Calling Scripts        :  
-- Modification history:
-- Sl. No            Date                 Author                      Description
-- ---------     --------------    ----------------------        ------------------------------
-- 1.0		 26-03-2012		Ashutosh Naik			Original Version

-- =====================================================================================================================

ALTER TABLE CUST_TDS50000_TBL
 ADD (BANK_ID  VARCHAR2(8 BYTE));
 
alter table ICICI.CUST_TDS50000 rename column CUST_ID to CIF_ID;

DROP INDEX IDX_CUST_TDS50000_KEY;

CREATE INDEX IDX_CUST_TDS50000_KEY ON CUST_TDS50000_TBL(TDA_FORACID,RECORD_DATE);