drop table fxb_orm_custom
/
drop public synonym FXORM
/
create table fxb_orm_custom
(
 BANK_ID             VARCHAR2(8),
 BILL_ID             VARCHAR2(15),
 SOL_ID              VARCHAR2(8),
 BILL_CRNCY_CODE     VARCHAR2(3),
 OPER_ACCT           VARCHAR2(16),
 OPER_CHRG_ACCT      VARCHAR2(16),
 BILL_AMT            NUMBER(20,4),
 BILL_CNTRY_CODE     VARCHAR2(5),
 CORR_COLL_BANK_CODE VARCHAR2(6),
 CORR_COLL_BR_CODE   VARCHAR2(6),
 OTHER_PARTY_NAME    VARCHAR2(80),
 OTHER_PARTY_ADDR_1  VARCHAR2(45),
 OTHER_PARTY_ADDR_2  VARCHAR2(45),
 OTHER_PARTY_ADDR_3  VARCHAR2(45),
 PURPOSE_OF_REM      VARCHAR2(5),
 DRAWEE_BANK_NAME    VARCHAR2(80),
 DRAWEE_BANK_ADDR_1  VARCHAR2(45),
 DRAWEE_BANK_ADDR_2  VARCHAR2(45),
 DRAWEE_BANK_ADDR_3  VARCHAR2(45),
 DETAILS_BEN_OTH     VARCHAR2(10),
 FW_CNTR_DET         VARCHAR2(16),
 CONV_RATE           NUMBER(21,10),
 TRES_RATE           NUMBER(21,10),
 TRES_RATE_CODE      VARCHAR2(16),
 A56                 VARCHAR2(35),
 A57                 VARCHAR2(35),
 A70                 VARCHAR2(35),
 A71                 VARCHAR2(35),
 UPLOAD_STATUS       NUMBER(2),
 INPUT_FILE          VARCHAR2(35),
 SXR_NO              VARCHAR2(15)
)
/
create public synonym FXORM for fxb_orm_custom
/

grant select, insert, update, delete on fxb_orm_custom to tbagen
/
grant select, insert, update, delete on fxb_orm_custom to tbaadm
/
grant select on fxb_orm_custom to tbautil
/

commit
/
