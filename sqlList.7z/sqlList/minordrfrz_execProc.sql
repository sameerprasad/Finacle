--===================================================================================================================
--	Filename	               : minordrfrz_execProc.sql
--      Description		       : This sql script executes the procedure Sp_Minor_To_Major_Customer
--      Date			       : 03-11-2012
--      Author                         : 
--      Menu Option                    : ICIMINDR
--	Modification History           :
--	Sl. #            Date                Author             Modification                              
--	-----            -----              --------	       ----------------                               
--===================================================================================================================
declare

l_error_id varchar2(1000);
l_bank_id GCT.bank_id%TYPE;
out_retcode NUMBER;
begin
out_retcode := 0;
l_bank_id:='&2';
--dbms_output.put_line(l_bank_id);
CRMUSER.Sp_Minor_To_Major_Customer(l_error_id, l_bank_id);

IF (l_error_id != NULL)
then
	out_retcode:=-1;
else
	out_retcode:=1;
end if;
EXCEPTION
WHEN OTHERS THEN
	out_retcode:=-1;
end;

/

