----------------------------------------------------------------------------------------------------
--   Source Name            : Report_allotment.sql
--   Description            : Locker Allotment Report
--   Input Values           : None
--   Output Values          : None
--   Called Script          : N.A
--   Calling Script         : N.A
--   Modification History:
--   Sl No.         Date              Author                     Description
--   --------------------------------------------------------------------------------------
--     01         12-Oct-2012         Priyanka                 Original Version
----------------------------------------------------------------------------------------------------


set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_allotment.lst

DECLARE

lv_solid         gam.sol_id%type :='&1';
date1            clmt.ISSUE_DATE%type := to_date('&2','dd-mm-yyyy');
date2            clmt.ISSUE_DATE%type := to_date('&3','dd-mm-yyyy');
lv_bankid        clmt.bank_id%type := '&4';

CURSOR c1 IS
select clmt.sol_id,
        wlckm.RACK_ID,
        wlckm.LOCKER_TYPE,
        clmt.LOCKER_NUM,
        wlckm.KEY_NUM,
        clmt.cif_id,
        substr(cmg.cust_name,1,40) cust_name,
        clmt.ISSUE_DATE,
        clmt.DUE_DATE,
        clmt.RENEWAL_DATE,
        (lcpp.rent_payable_amount - lcpp.rent_paid_amount) as OVERDUE,
        clmt.rcre_user_id
from    clmt,wlckm,cmg,lcpp
where   clmt.cif_id = cmg.cif_id
and     wlckm.LOCKER_NUM  = clmt.LOCKER_NUM
and     lcpp.locker_number=clmt.locker_num
and     lcpp.cif_id=clmt.cif_id
and     wlckm.sol_id = clmt.sol_id
and     clmt.sol_id = lv_solid
and     clmt.bank_id = wlckm.bank_id
and     wlckm.bank_id = lcpp.bank_id
and     clmt.bank_id = lv_bankid
and     clmt.ISSUE_DATE between date1 and date2
and     clmt.del_flg!='Y'
and     wlckm.del_flg!='Y'
ORDER by 8,4;

BEGIN

    for f1 in c1

    loop
    
    dbms_output.enable(buffer_size => NULL); 
    dbms_output.put_line(     f1.sol_id       ||'|'||
                              f1.rack_id      ||'|'||
                              f1.locker_type  ||'|'||
                              f1.locker_num   ||'|'||
                              f1.KEY_NUM      ||'|'||
                              f1.cif_id       ||'|'||
                              f1.cust_name    ||'|'||
                              f1.ISSUE_DATE   ||'|'||
                              f1.DUE_DATE     ||'|'||
                              f1.RENEWAL_DATE ||'|'||
                              f1.OVERDUE      ||'|'||
                              f1.rcre_user_id
                        ); 
   end loop; 
END;
/
spool off

