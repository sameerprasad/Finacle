set pages 0
set long 1800
set linesize 1800
set verify off
set termout off
set heading off
set echo off
set feedback off




spool &6
select count(*) from tfht where substr(mesg_forward_time,1,10) = '&1' 
and substr(to_char(mesg_forward_time,'DD-MM-YYYY HH24MI'),12,4)  >= '&3'
and substr(to_char(mesg_forward_time,'DD-MM-YYYY HH24MI'),12,4)  < '&4'
/

spool off


spool &5
select document_type||'|'||mesg||'|'||request_num||'|'||
fin_context||'|'||status||'|'||mesg_forward_time||'|'||substr(to_char(mesg_forward_time,'DD-MM-YYYY HH24:MI:SS'),12,8)
from tfht where substr(mesg_forward_time,1,10) = '&1'
and substr(to_char(mesg_forward_time,'DD-MM-YYYY HH24MI'),12,4)  >= '&3'
and substr(to_char(mesg_forward_time,'DD-MM-YYYY HH24MI'),12,4)  < '&4'
order by substr(to_char(mesg_forward_time,'DD-MM-YYYY HH24MI'),12,4) 
/

spool off
-------------------------------------------------------------
