--===================================================================================================================
--  Filename                :   letters_stoplist.sql
--  Description             :
--  Date                    :   29-08-2012
--  Author                  :   Swaroop K Tiruvoipati
--  Menu Option             :
--      Modification History
--    Sl. #           Date           Author                     Modification
--    -----           -----          --------                    ----------------
--    1               29-08-2012     Swaroop K Tiruvoipati      Original Version
--                                                              (Ported from 7.x)
--===================================================================================================================
rem accept dt prompt 'Enter date for which report is to be executed in dd-mm-yyyy::: '
set termout off
set lines 400
set pause off
set feedback off
set verify off
whenever sqlerror exit sql.sqlcode
set pagesize 0
set heading off
set space 0
alter session set nls_date_format='DD-MM-YYYY';
set numformat 999999999999.99
declare
        loc_fp                          utl_file.file_type;
        loc_filename            	varchar2(200);
        loc_filepath            	varchar2(100);
        loc_filemode            	varchar(10);
	sol_id                          gam.sol_id%type;
        schm_type		        gam.schmtype%type;
        cif_id                          gam.cif_id%type;
        cust_name		        cmg.cust_name%type;
        cust_title_code			cmg.cust_title_code%type;
	outname                         varchar2(50);
        address_line1                   CRMUSER.ADDRESS.address_line1%type;
        address_line2                   CRMUSER.ADDRESS.address_line2%type;
        ref_desc                        number;
        ref_desc1                       number;
        zip                             CRMUSER.ADDRESS.zip%type;
        begin_chq_num                   number;
        payee_name                      varchar2(50);
        acceptdate                      date;
	end_chq_num			number;
	chqdate				date;
	chqamt				number;
	chqnumdiff			number;
	schmchqnum			varchar2(50);
	sol_desc			sol.sol_desc%type;
	soladdr1			sol.addr_1%type;
	soladdr2                        sol.addr_2%type;
	rctrefdesc			number;
	rctrefdesc1			number;
	recline				varchar2(500);

cursor stoplist is
select  b.sol_id sol_id,b.schm_type schm_type,a.cif_id cif_id,a.cust_title_code cust_title_code,a.cust_name cust_name,x.ref_desc ref_desc,y.ref_desc ref_desc1,s.BEGIN_CHQ_NUM begin_chq_num,decode(s.payee_name,NULL,'Not Specified',s.payee_name) payee_name ,to_char(s.ACPT_DATE,'dd-MON-yyyy hh24:mi:ss') acceptdate,s.END_CHQ_NUM end_chq_num,s.CHQ_DATE chqdate,s.chq_amt chqamt,b.foracid,(s.end_chq_num - s.begin_chq_num + 1) chqnumdiff,decode(b.schm_type,'SBA',(25 * (s.end_chq_num - s.begin_chq_num + 1)),(50* (s.end_chq_num - s.begin_chq_num + 1))) schmchqnum,l.sol_desc sol_desc,l.ADDR_1 soladdr1,l.ADDR_2 soladdr2,xx.ref_desc rctrefdesc,yy.ref_desc rctrefdesc1 from cmg a, rct x, rct y, gam b, spt s, sol l, rct xx,rct yy where   b.acid = s.acid
and s.rec_type='S'
and s.del_flg!='Y'
and   a.cif_id = b.cif_id
and   b.acct_cls_flg != 'Y'
and   x.ref_rec_type = '01'
and   nvl(a.cust_comu_city_code,'*') = x.ref_code
and   y.ref_rec_type = '02'
and   nvl(a.cust_comu_state_code, '*') = y.ref_code
and   xx.ref_rec_type = '01'
and   nvl(l.city_code,'*') = xx.ref_code
and   yy.ref_rec_type = '02'
and   nvl(l.state_code, '*') = yy.ref_code
and   l.sol_id =b.sol_id
--and   to_char(s.rcre_time,'dd-mm-yyyy')=(select db_stat_date from gct) --N
and   to_char(s.rcre_time,'dd-mm-yyyy')='&1'
and   a.bank_id='&2'
and   x.bank_id='&2'
and   y.bank_id='&2'
and   b.bank_id='&2'
and   s.bank_id='&2'
and   l.bank_id='&2'
and   xx.bank_id='&2'
and   yy.bank_id='&2'
order by b.sol_id,a.cif_id

begin
        loc_fp := utl_file.fopen('&3','&1.spool.lst','w');
	
	select address_line1,address_line2,zip
	from CRMUSER.ADDRESS a where a.orgkey = rec.cif_id and bank_id ='&2';




	for rec in stoplist
	loop
                        begin
			recline := rec.sol_id||'|'||
			   rec.schm_type||'|'||
			   rec.cif_id||'|'||
			   rec.cust_title_code||'|'||
				rec.cust_name||'|'||
				rec.address_line1||'|'||
				rec.address_line2||'|'||
				ref_desc||'|'||
				ref_desc||'|'||
				zip||'|'||          
				begin_chq_num||'|'||
				payee_name||'|'||   
				acceptdate||'|'||   
				end_chq_num||'|'||  
				chqdate||'|'||      
				chqamt||'|'||       
				chqnumdiff||'|'||   
				schmchqnum||'|'||   
				sol_desc||'|'||     
				soladdr1||'|'||     
				soladdr2||'|'||     
				rctrefdesc||'|'||   
				rctrefdesc1||'|'||  
				recline      
	         utl_file.put_line(loc_fp, recline);
        end loop;
        utl_file.fclose(loc_fp);
end;
/

exit


