--=======================================================
-- Author	: SUBHASISH PARAMANIK 
-- 
-- Date		:
-- Source Name  : dccadv_rpt.sql
-- [Author]         [Date]          [Line]      [Desc]
-- Kumar	    19-03-2012			Changes done to make 
--						it compatible with 10x
-- Tejinder         08-11-2012                  Changes Done to correct the address fetch from cnma view
-- Tejinder         21-11-2012                   Added bank id
--=======================================================
CREATE OR REPLACE PACKAGE ICICI.BG_DCC_STAX AS
PROCEDURE BG_DCC_STAXProc(  inp_str         IN VARCHAR2,
                out_retCode         OUT NUMBER,
                out_rec         OUT VARCHAR2) ;
g_mode        Char(1):= 'S';
END BG_DCC_STAX;
/
CREATE OR REPLACE PACKAGE BODY ICICI.BG_DCC_STAX AS--{
------------------------------------------------------------------------------
TYPE rec_output IS RECORD(record_output  VARCHAR2(2000));
TYPE output_type IS TABLE OF rec_output INDEX BY BINARY_INTEGER;
output_table                            OUTPUT_TYPE;
g_number                                NUMBER;
g_current_row                           BINARY_INTEGER;
v_insert_row                            BINARY_INTEGER;
g_rowcount                              NUMBER;
------------------------------------------------------------------------------
-- GLOBAL VARIABLE
Input_bgNum                             BGM.BG_SRL_NUM%type;
Input_From_Date                         DATE;
Input_Bank_Id				varchar(8);
------------------------------------------------------------------------------
CURSOR Cur_bg1(Input_bgNum BGM.BG_SRL_NUM%type,Input_From_Date date , Input_Bank_Id BGM.BANK_ID%type )
    IS
SELECT d.actual_amt_coll, d.chrg_tran_id, d.chrg_tran_date,
NVL (d.ptran_bus_type, '!') ptran_bus_type, d.tran_rmks,
d.event_type, d.event_id
FROM tbaadm.cxl d, tbaadm.bgm a, tbaadm.tfct b, tbaadm.dtd g
WHERE a.bg_srl_num = Input_bgNum
AND a.bg_b2kid = b.b2k_id
AND a.bank_id = b.bank_id
AND a.bank_id = d.bank_id
AND b.chrg_acid = g.acid
AND b.chrg_acid = d.chrg_acid
AND g.tran_id = d.chrg_tran_id
AND d.chrg_tran_date = g.tran_date
--and d.comp_b2kId like '%'||a.BG_B2KID||'%'
and substr(comp_b2kid,1,12) like '%'||a.BG_B2KID||'%'
--AND d.chrg_tran_date >= to_date('07-APR-2012', 'DD-MON-YYYY')
AND d.chrg_tran_date >= to_date(Input_From_Date, 'DD-MM-YYYY')
AND d.bank_id = Input_Bank_Id
--AND d.COMP_B2KID_TYPE='BNKGR'
AND a.oper_acid = d.target_acid 
UNION 
SELECT d.actual_amt_coll, d.chrg_tran_id, d.chrg_tran_date,
NVL (d.ptran_bus_type, '!') ptran_bus_type, d.tran_rmks,
d.event_type, d.event_id
FROM tbaadm.cxl d, tbaadm.bgm a, tbaadm.tfct b, tbaadm.htd g
WHERE a.bg_srl_num = Input_bgNum
AND a.bg_b2kid = b.b2k_id
AND a.bank_id = b.bank_id
AND a.bank_id = d.bank_id
AND b.chrg_acid = g.acid
AND b.chrg_acid = d.chrg_acid
AND g.tran_id = d.chrg_tran_id
AND d.chrg_tran_date = g.tran_date
--AND d.chrg_tran_date >= to_date('07-APR-2012', 'DD-MON-YYYY')
AND d.chrg_tran_date >= to_date(Input_From_Date, 'DD-MM-YYYY')
AND d.bank_id = Input_Bank_Id 
--AND d.COMP_B2KID_TYPE='BNKGR'
AND a.oper_acid = d.target_acid
and substr(comp_b2kid,1,12) like '%'||a.BG_B2KID||'%'; 


PROCEDURE BG_DCC_STAXProc(  inp_str         IN VARCHAR2,
			    out_RetCode         OUT NUMBER,
			    out_rec         OUT VARCHAR2)
IS
OutArr                      basp0099.ArrayType;
v_record_output             VARCHAR2(2000);
-------------------------------------------------------------------
-- Local Variable
v_sol_id			BGM.SOL_ID%TYPE;
v_bg_type			BGM.BG_TYPE%TYPE;
v_bg_class			BGM.BG_CLASS%TYPE;
v_bg_amt			BGM.BG_AMT%TYPE;
v_bg_crncy_code			BGM.CRNCY_CODE%TYPE;
v_cust_id			BGM.CUST_ID%TYPE;
v_bg_exp_date			BGM.BG_EXPIRY_DATE%TYPE;
v_claim_exp_date		BGM.CLAIM_EXPIRY_DATE%TYPE;
v_beneficiary_name		BGM.BENEFICIARY_NAME%TYPE;
v_beneficiary_addr_1		BGM.BENEFICIARY_ADDR_1%TYPE;
v_beneficiary_addr_2		BGM.BENEFICIARY_ADDR_2%TYPE;
v_beneficiary_addr_3		cnma.ADDRESS3%TYPE;
v_other_party_code		BGM.other_party_code%TYPE;
v_city_code			BGM.CITY_CODE%TYPE;
v_city_code_bene		RCT.REF_DESC%TYPE;
v_state_code			BGM.STATE_CODE%TYPE;
v_cntry_code			BGM.CNTRY_CODE%TYPE;
v_cntry_code_bene		RCT.REF_DESC%TYPE; 
v_pin_code			BGM.PIN_CODE%TYPE;
v_oper_acid			BGM.OPER_ACID%TYPE;
v_tax_amt			ICICI_BTX.TAX_AMT%TYPE;
v_foracid			GAM.FORACID%TYPE;

--v_cust_name			crmuser.accounts.name%TYPE;
--v_cust_comu_addr1		crmuser.accounts.ADDRESS_LINE1%TYPE;
--v_cust_comu_addr2		crmuser.accounts.ADDRESS_LINE2%TYPE;
--v_cust_comu_city_code		crmuser.accounts.city%TYPE;
--v_cust_comu_state_code	crmuser.accounts.state%TYPE;
--v_cust_comu_pin_code		crmuser.accounts.zip%TYPE;
--v_cust_comu_cntry_code	crmuser.accounts.country%TYPE;

v_cust_name                     cnma.name%TYPE;
v_cust_comu_addr1               cnma.ADDRESS1%TYPE;
v_cust_comu_addr2               cnma.ADDRESS2%TYPE;
v_cust_comu_city_code           cnma.city_code%TYPE;
v_cust_comu_state_code          cnma.state_code%TYPE;
v_cust_comu_pin_code            cnma.pin_code%TYPE;
v_cust_comu_cntry_code          cnma.cntry_code%TYPE;
v_beneficiary_city		cnma.city_code%TYPE;
v_beneficiary_state		cnma.state_code%TYPE;
v_beneficiary_cntry		cnma.cntry_code%TYPE;
v_beneficiary_pin		cnma.pin_code%TYPE;

v_cust_comu_city		RCT.REF_DESC%TYPE;
v_cust_comu_state		RCT.REF_DESC%TYPE;
v_cust_comu_cntry		RCT.REF_DESC%TYPE;
v_sol_desc			SOL.SOL_DESC%TYPE;
v_addr_1			SOL.addr_1%TYPE;
v_addr_2			SOL.addr_2%TYPE;
v_city				SOL.city_code%TYPE;
v_state				SOL.state_code%TYPE;
v_pin_code_sol			SOL.pin_code%TYPE;

v_sol_city			RCT.REF_DESC%TYPE;
v_sol_state			RCT.REF_DESC%TYPE;

v_loop_cnt			VARCHAR2(1 CHAR);
v_total				NUMBER(20,6) :='0';

v_ect_srl_num			tdcc.TFCT_SRL_NUM%type;
v_dcc_key_srl_num		tdcc.TDCC_KEY_SRL_NUM%type;

v_pstd_flg_cnt			NUMBER(5);
v_tran_stat			VARCHAR2(8);
v_tax_tran_id			CHT.TRAN_ID%TYPE:='';
v_tax_pstd_flg_cnt		NUMBER(5);
------------------------------------------------------------------
BEGIN --{
        out_retCode := 0;
        out_rec := '';

        IF g_mode = 'S'  THEN --{
        basp0099.formInputArr(inp_str,OutArr);

            Input_bgNum         :=      OutArr(0);
         -- Input_From_Date     :=      to_char(to_date(OutArr(1),'DD-MM-YYYY'),'DD-MM-YYYY');
	    Input_From_Date     :=	to_date(OutArr(1),'DD-MM-YYYY');
            dbms_output.put_line('BGNum'||Input_bgNum);
            dbms_output.put_line('FROM_DATE'||Input_From_Date);
	    -- Below Bank Id Line Added - Ranjith
	    Input_Bank_Id       :=      OutArr(2);
------------------------------------------------------------------------------
        v_insert_row := 0;
		v_loop_cnt := 'Y';
		For Cur_bg IN Cur_bg1(Input_bgNum,Input_From_Date,Input_Bank_Id)
        LOOP                --{
			IF(v_loop_cnt = 'Y') THEN
			BEGIN
				BEGIN
				
				SELECT		other_party_code
				INTO		v_other_party_code
				FROM		tbaadm.BGM
				WHERE		BG_SRL_NUM = Input_bgNum
				AND		BANK_ID = Input_Bank_Id;
				EXCEPTION WHEN OTHERS THEN
				v_other_party_code := '';				

				END;
				
				IF(v_other_party_code is not null) THEN
					BEGIN
						SELECT NAME,ADDRESS1,ADDRESS2,ADDRESS3,CITY_CODE,STATE_CODE,CNTRY_CODE,PIN_CODE
						INTO   v_beneficiary_name,v_beneficiary_addr_1,v_beneficiary_addr_2,v_beneficiary_addr_3,v_beneficiary_city,v_beneficiary_state,v_beneficiary_cntry,v_beneficiary_pin
						FROM   tbaadm.cnma
						WHERE  ADDR_B2KID = v_other_party_code
						AND    PREFERREDADDRESS ='Y' 
						AND    BANK_ID = Input_Bank_Id; 
						EXCEPTION       WHEN OTHERS THEN
						v_beneficiary_name := '';
						v_beneficiary_addr_1 := '';
						v_beneficiary_addr_2 := '';
						v_beneficiary_city	:= '';
						v_beneficiary_state	:= '';
						v_beneficiary_cntry	:= '';
						v_beneficiary_pin	:= '';
					END;
				ELSE
					BEGIN
						SELECT NAME,ADDRESS1,ADDRESS2,ADDRESS3,CITY_CODE,STATE_CODE,CNTRY_CODE,PIN_CODE 
						INTO v_beneficiary_name,v_beneficiary_addr_1,v_beneficiary_addr_2,v_beneficiary_addr_3,v_beneficiary_city,v_beneficiary_state,v_beneficiary_cntry,v_beneficiary_pin
						FROM tbaadm.TFAT 
						WHERE ADDR_B2KID = (SELECT bg_b2kId FROM tbaadm.BGM WHERE BG_SRL_NUM=Input_bgNum AND BANK_ID = Input_Bank_Id)
						AND ADDR_ID = 'BGOTPY'
						AND addr_type='S'
						And bank_id= Input_Bank_Id;
						EXCEPTION       WHEN OTHERS THEN
						v_beneficiary_name := '';
						v_beneficiary_addr_1 := '';
						v_beneficiary_addr_2 := '';
						v_beneficiary_city	:= '';
						v_beneficiary_state	:= '';
						v_beneficiary_cntry	:= '';
						v_beneficiary_pin	:= '';
					END;

				END IF;

				SELECT		SOL_ID,	
							BG_TYPE,
							BG_CLASS,	
							BG_AMT,
							CRNCY_CODE,	
							CUST_ID,
							BG_EXPIRY_DATE,
							CLAIM_EXPIRY_DATE,
						--	BENEFICIARY_NAME,
						--	BENEFICIARY_ADDR_1,
						--	BENEFICIARY_ADDR_2,
							CITY_CODE,
							STATE_CODE,	
							CNTRY_CODE,
							PIN_CODE,
							OPER_ACID
				INTO		v_sol_id,	
							v_bg_type,
							v_bg_class,
							v_bg_amt,
							v_bg_crncy_code,
							v_cust_id,
							v_bg_exp_date,
							v_claim_exp_date,
						--	v_beneficiary_name,
						--	v_beneficiary_addr_1,
						--	v_beneficiary_addr_2,
							v_city_code,
							v_state_code,
							v_cntry_code,
							v_pin_code,
							v_oper_acid
				FROM		tbaadm.BGM
				WHERE		BG_SRL_NUM = Input_bgNum
				AND		BANK_ID = Input_Bank_Id;
			EXCEPTION WHEN NO_DATA_FOUND THEN
				v_bg_type := '';
			END;
			
           BEGIN
               SELECT      name,
                           ADDRESS1,
                           ADDRESS2,
                           city_code,
                           state_code,
                           pin_code,
                           cntry_code
               INTO        v_cust_name,
                           v_cust_comu_addr1,
                           v_cust_comu_addr2,
                           v_cust_comu_city_code,
                           v_cust_comu_state_code,
                           v_cust_comu_pin_code,
                           v_cust_comu_cntry_code
               FROM        tbaadm.cnma
               WHERE       ADDR_B2KID = v_cust_id
                AND           PREFERREDADDRESS ='Y' 
                AND             BANK_ID = Input_Bank_Id; 
                EXCEPTION       WHEN NO_DATA_FOUND THEN
               v_cust_name := '';
               v_cust_comu_addr1 := '';
               v_cust_comu_addr2 := '';
               v_cust_comu_city_code := '';
               v_cust_comu_state_code := '';
               v_cust_comu_pin_code := '';
               v_cust_comu_cntry_code := '';
           END;
		   
		    BEGIN
				SELECT		SOL_DESC,
							ADDR_1,
							ADDR_2,
							CITY_CODE,
							STATE_CODE,
							PIN_CODE
				INTO		v_sol_desc,
							v_addr_1,
							v_addr_2,
							v_city,
							v_state,
							v_pin_code_sol
				FROM		tbaadm.SOL
				WHERE		SOL_ID = v_sol_id
				AND             BANK_ID = Input_Bank_Id;
	 		EXCEPTION WHEN NO_DATA_FOUND THEN
				v_sol_desc := '';
				v_addr_1 := '';
				v_addr_2 := '';
				v_city := '';
				v_state := '';
				v_pin_code_sol := '';
			END;
					if(v_city is not null)then
						begin
							select		REF_DESC
							into		v_sol_city
							from 		tbaadm.RCT
							where		REF_CODE = v_city
							and 		REF_REC_TYPE='01'
							AND             BANK_ID = Input_Bank_Id;
						exception WHEN NO_DATA_FOUND then
							v_sol_city := '';
						end;
					end if;
					
                    if(v_state is not null)then
                        begin
                            select      REF_DESC
                            into        v_sol_state
                            from        tbaadm.RCT
                            where       REF_CODE = v_state
			    and 		REF_REC_TYPE='02'
			    AND             BANK_ID = Input_Bank_Id;
                        exception WHEN NO_DATA_FOUND then
                            v_state_code := '';
                        end;
                    end if;
                    
					if(v_cust_comu_state_code is not null)then
                        begin
                            select      REF_DESC
                            into        v_cust_comu_state
                            from        tbaadm.RCT
                            where       REF_CODE = v_cust_comu_state_code
			    AND         BANK_ID = Input_Bank_Id
          		    and 	REF_REC_TYPE='02';
                        exception WHEN NO_DATA_FOUND then
                            v_cust_comu_state := '';
                        end;
                    end if;										

                    if(v_cust_comu_cntry_code is not null)then
                        begin
                            select      REF_DESC
                            into        v_cust_comu_cntry
                            from        tbaadm.RCT
                            where       REF_CODE = v_cust_comu_cntry_code
			    AND         BANK_ID = Input_Bank_Id
							and 		REF_REC_TYPE='03';
                        exception WHEN NO_DATA_FOUND then
                            v_cust_comu_cntry := '';
                        end;
                    end if;					

                    if(v_cust_comu_city_code is not null)then
                        begin
                            select      REF_DESC
                            into       	v_cust_comu_city 
                            from        tbaadm.RCT
                            where       REF_CODE = v_cust_comu_city_code
			    AND         BANK_ID = Input_Bank_Id
							and 		REF_REC_TYPE='01';
                        exception WHEN NO_DATA_FOUND then
                            v_cust_comu_city := '';
                        end;
                    end if;
					if(v_city_code is not null)then
						begin
							select      REF_DESC
							into        v_city_code_bene
							from        tbaadm.RCT
							where       REF_CODE = v_city_code
							AND         BANK_ID = Input_Bank_Id
							and 		REF_REC_TYPE='01';
						exception WHEN NO_DATA_FOUND then
							v_city_code_bene := '';
						end;
					end if;		
					if(v_cntry_code is not null)then
						if(v_cntry_code = 'IN')then
							begin
								select      REF_DESC
								into        v_cntry_code_bene
								from        tbaadm.RCT
								where       REF_CODE = v_cntry_code
								AND         BANK_ID = Input_Bank_Id
								and 		REF_REC_TYPE = '03';
							exception WHEN NO_DATA_FOUND then
								v_cntry_code_bene := '';
							end;
						else
							begin
								select      REF_DESC
								into        v_cntry_code_bene
								from        tbaadm.RCT
								where       REF_CODE = v_cntry_code
								AND         BANK_ID = Input_Bank_Id
								and 		REF_REC_TYPE = '03';
							exception WHEN NO_DATA_FOUND then
                                v_cntry_code_bene := '';
                            end;
						end if;
					end if;
	        END IF;
        	v_loop_cnt := 'N';

			BEGIN
				select	TFCT_KEY_SRL_NUM, tdcc_key_srl_num
				into	v_ect_srl_num,v_dcc_key_srl_num
				from	tbaadm.TFCT,tbaadm.TDCC 
				where TFCT.b2k_id = TDCC.b2k_id
				AND   TFCT.BANK_ID = Input_Bank_Id
				and   TFCT.b2kid_type = TDCC.b2kid_type
				and   TFCT.ptran_bus_type = tdcc.ptran_bus_type
				and   TFCT.tfct_key_srl_num = TDCC.tfct_srl_num
				and   TFCT.b2k_id in (select bg_b2kid from tbaadm.bgm where bg_srl_num = Input_bgNum)
				--and   TFCT.event_id = Cur_bg.event_id
				and   TFCT.event_type = Cur_bg.event_type
				and   TDCC.tran_date =Cur_bg.chrg_tran_date
				and   tdcc.ptran_bus_type = Cur_bg.PTRAN_BUS_TYPE
				and   tdcc.tran_id = lpad(Cur_bg.chrg_tran_id,9,' ')
				and   tdcc.tran_amt = Cur_bg.actual_amt_coll
				and	rownum < 2;
				EXCEPTION WHEN NO_DATA_FOUND THEN
				v_ect_srl_num := '';
				v_dcc_key_srl_num := '';
				when others then
				v_ect_srl_num := '';
				v_dcc_key_srl_num := '';
			END;
			
dbms_output.put_line('ect'||'|'||Input_bgNum||'|'||Cur_bg.chrg_tran_id||'|'||Cur_bg.chrg_tran_date||'|'||Cur_bg.event_id||'|'||Cur_bg.actual_amt_coll||'|'||Cur_bg.event_type||'|'||v_ect_srl_num||'|'||Cur_bg.PTRAN_BUS_TYPE);

if (v_ect_srl_num is null)  then
            BEGIN
                select  tfct_key_srl_num
                into    v_ect_srl_num
                from tbaadm.tfct
                where tfct.b2k_id in (select bg_b2kid from tbaadm.bgm where bg_srl_num = Input_bgNum)
		AND   tfct.BANK_ID = Input_Bank_Id
                --and   tfct.event_id = Cur_bg.event_id
                and   tfct.event_type = Cur_bg.event_type
                and   tfct.ptran_bus_type = Cur_bg.PTRAN_BUS_TYPE
		and   tfct.TTL_CHRG_COLL_AMT = Cur_bg.actual_amt_coll
		and rownum < 1;
                EXCEPTION WHEN NO_DATA_FOUND THEN
                v_ect_srl_num := '';
                when others then
                v_ect_srl_num := '';
            END;
dbms_output.put_line('INNNNNNNN'||'|'||Input_bgNum||'|'||Cur_bg.chrg_tran_id||'|'||Cur_bg.chrg_tran_date||'|'||Cur_bg.event_id||'|'||Cur_bg.actual_amt_coll||'|'||Cur_bg.event_type||'|'||v_ect_srl_num||'|'||Cur_bg.PTRAN_BUS_TYPE);
end if;

    if (v_ect_srl_num is null) then
		BEGIN
			select TFCT_KEY_SRL_NUM 
			into v_ect_srl_num
			from tbaadm.TFCT,tbaadm.TDCC 
			where   tfct.b2k_id in (select bg_b2kid from tbaadm.bgm where bg_srl_num = Input_bgNum)
			AND   tfct.BANK_ID = Input_Bank_Id
			--and   cht.event_id = Cur_bg.event_id
			and   tfct.event_type = Cur_bg.event_type
			and   ((tfct.ptran_bus_type = Cur_bg.ptran_bus_type) OR  (tfct.ptran_bus_type is null)) 
			and   tdcc.tran_date = Cur_bg.chrg_tran_date
			and   tdcc.tran_id = lpad(Cur_bg.chrg_tran_id,9,' ')
			and	tdcc.TFCT_SRL_NUM = tfct.TFCT_KEY_SRL_NUM
			and   rownum < 2;
			EXCEPTION WHEN NO_DATA_FOUND THEN
			v_ect_srl_num := '';
			when others then
			v_ect_srl_num := '';
		END;
    end if;

		
			BEGIN 
				SELECT		FORACID
				INTO		v_foracid
				FROM		tbaadm.GAM
				WHERE		ACID   = v_oper_acid
				AND		BANK_ID = Input_Bank_Id;
			EXCEPTION WHEN NO_DATA_FOUND THEN
				v_foracid := '';
			END;	


			-- this blockis used to check whether the deffered tran is posted ?
			-- If noy posted then v_tran_stat will mafe "F" and the tran would not appear in report
            if(Cur_bg.chrg_tran_id is not null)then
                BEGIN
                    select sum(pstd_flg_cnt) INTO        v_pstd_flg_cnt FROM(
                    SELECT      COUNT(*)    pstd_flg_cnt FROM     tbaadm.DTD
                    WHERE       TRAN_ID   = lpad(Cur_bg.chrg_tran_id,'9',' ')
                    AND         TRAN_DATE = Cur_bg.chrg_tran_date
                    AND         PSTD_FLG !='Y'
		    AND		BANK_ID = Input_Bank_Id
                    and         ACID = (select acid from tbaadm.gam where foracid =v_foracid)
                    union 
                    SELECT      COUNT(*)    pstd_flg_cnt FROM     tbaadm.HTD
                    WHERE       TRAN_ID   = lpad(Cur_bg.chrg_tran_id,'9',' ')
                    AND         TRAN_DATE = Cur_bg.chrg_tran_date
                    AND         PSTD_FLG !='Y'
		    AND		BANK_ID = Input_Bank_Id
                    and         ACID = (select acid from tbaadm.gam where foracid =v_foracid));
                EXCEPTION WHEN NO_DATA_FOUND THEN
                    v_pstd_flg_cnt := '';
                END;
                if(v_pstd_flg_cnt > 0)then
                    v_tran_stat := 'F';
                else
                    v_tran_stat := 'S';
                end if;
            end if;

dbms_output.put_line('N---'||'|'||v_tran_stat);


	if (v_tran_stat = 'S') then 
			BEGIN
				SELECT		TAX_AMT,TAX_TRAN_ID
				INTO		v_tax_amt,v_tax_tran_id
				FROM		ICICI_BTX
				WHERE		BG_SRL_NUM = Input_bgNum
				AND             BANK_ID = Input_Bank_Id
				AND 		TRAN_ID = lpad(Cur_bg.chrg_tran_id,9,' ')
				AND			TRAN_DATE = Cur_bg.chrg_tran_date
				AND			EVENT_ID = Cur_bg.event_id
				AND 		tran_amt =Cur_bg.actual_amt_coll
				AND			EVENT_TYPE = Cur_bg.event_type
				and 		ECT_SRL_NUM = v_ect_srl_num;
			EXCEPTION WHEN NO_DATA_FOUND THEN
				v_tax_amt := 0;
				v_tax_tran_id := '';
				when others then
				v_tax_amt := 0;
				v_tax_tran_id := '';
			END;
		else
			v_tax_amt := 0;
			v_tax_tran_id := '';
		end if;

dbms_output.put_line('N---'||'|'||v_tran_stat||'|'||v_tax_amt||'|'||v_tax_tran_id);
				
            if(v_tax_tran_id is not null)then
                BEGIN
                    select sum(pstd_flg_cnt) INTO        v_tax_pstd_flg_cnt FROM(
                    SELECT      COUNT(*)    pstd_flg_cnt FROM     tbaadm.DTD
                    WHERE       TRAN_ID   = lpad(v_tax_tran_id,'9',' ')
                    AND         TRAN_DATE = Cur_bg.chrg_tran_date
                    AND         PSTD_FLG !='Y'
		    AND		BANK_ID = Input_Bank_Id
                    and         ACID = (select acid from tbaadm.gam where foracid =v_foracid)

                    union
                    SELECT      COUNT(*)    pstd_flg_cnt FROM     tbaadm.HTD
                    WHERE       TRAN_ID   = lpad(v_tax_tran_id,'9',' ')
                    AND         TRAN_DATE = Cur_bg.chrg_tran_date
                    AND         PSTD_FLG !='Y'
		    AND		BANK_ID = Input_Bank_Id
                    and         ACID = (select acid from tbaadm.gam where foracid =v_foracid));
                EXCEPTION WHEN NO_DATA_FOUND THEN
                    v_tax_pstd_flg_cnt := '';
                END;
                if(v_tax_pstd_flg_cnt > 0)then
					-- Tax tran id is not posted Making tax amount zero so that it will not display in report
                    v_tax_amt := 0;
                end if;
            end if;
dbms_output.put_line('N---'||'|'||v_tran_stat||'|'||v_tax_amt||'|'||v_tax_tran_id||'|'||v_tax_pstd_flg_cnt);

dbms_output.put_line('----'||'|'||Input_bgNum||'|'||Cur_bg.chrg_tran_id||'|'||Cur_bg.chrg_tran_date||'|'||Cur_bg.event_id||'|'||Cur_bg.actual_amt_coll||'|'||Cur_bg.event_type||'|'||v_ect_srl_num||'|'||v_tax_amt);
			
			v_total := Cur_bg.actual_amt_coll + v_tax_amt;	
														
--------------------------------------------------------------------------
     v_insert_row:=v_insert_row+1;
---------------------------------------------------------------------------
		
	if (v_tran_stat = 'S') then 
         v_record_output:=	Input_bgNum				||'|'||
                Cur_bg.actual_amt_coll 			||'|'||
				Cur_bg.chrg_tran_id                      ||'|'||
				Cur_bg.chrg_tran_date                    ||'|'||
				Cur_bg.ptran_bus_type               ||'|'||
				Cur_bg.tran_rmks                    ||'|'||
				v_bg_type                           ||'|'||
				v_bg_class              ||'|'||
				v_bg_amt                ||'|'||
				v_bg_crncy_code			||'|'||
				v_cust_id               ||'|'||
				v_bg_exp_date               ||'|'||
				v_claim_exp_date            ||'|'||
				v_beneficiary_name          ||'|'||
				v_beneficiary_addr_1            ||'|'||
				v_beneficiary_addr_2            ||'|'||
				v_beneficiary_addr_3            ||'|'||
				v_beneficiary_city            ||'|'||
				v_beneficiary_state            ||'|'||
				v_beneficiary_cntry            ||'|'||
				v_beneficiary_pin            ||'|'||
				v_city_code_bene             ||'|'||
				v_state_code                ||'|'||
				v_cntry_code_bene                ||'|'||
				v_pin_code              ||'|'||
				v_oper_acid             ||'|'||
				--v_tran_date_head                ||'|'||
				v_cust_name             ||'|'||
				v_cust_comu_addr1           ||'|'||
				v_cust_comu_addr2                   ||'|'||
				v_cust_comu_city           ||'|'||
				v_cust_comu_state          ||'|'||
				v_cust_comu_pin_code            ||'|'||
				v_cust_comu_cntry          ||'|'||
				v_tax_amt               ||'|'||
				v_foracid               ||'|'||
				v_sol_desc    			||'|'||
				v_addr_1      			||'|'||
				v_addr_2      			||'|'||
				v_pin_code_sol			||'|'||
				v_sol_city    			||'|'||
				v_sol_state   			||'|'||
				Input_From_Date			||'|'||
				v_total;			

        output_table(v_insert_row).Record_output:=v_record_output;

	end if;

				dbms_output.put_line('de intial');
				-- re intializing the values
				v_tax_amt	:= '0';
				v_total		:= '0';
				v_ect_srl_num		:='';
				v_dcc_key_srl_num	:= '';
				v_pstd_flg_cnt		:= '';
				v_tran_stat			:= '';			
				v_tax_tran_id		:= '';
				v_tax_pstd_flg_cnt	:= '';

				dbms_output.put_line('end');
---------------------------------------------------------------------------
---------------------------------------------------------------------------
-------------------------------------------------------------------------
        END LOOP;           --}

-------------------------------------------------------------------------

                g_mode := 'G';
                g_rowcount := output_table.Count;
                g_current_row := 0;

                ELSIF g_mode = 'G' THEN --}{
                        g_current_row := g_current_row + 1;
                        IF g_current_row > g_rowcount
                        THEN
                                output_table.delete ;
                                g_current_row := 0;
                                g_rowcount := 0;
                                out_retcode := 1;
                                g_mode := 'S' ;
                                Return ;
                        END IF;
                        out_rec := output_table(g_current_row).record_output;
        END IF; --}
-------------------------------------------------------------------------
END BG_DCC_STAXProc; --}
END BG_DCC_STAX; --}
/
DROP PUBLIC SYNONYM  BG_DCC_STAX
/
CREATE PUBLIC SYNONYM  BG_DCC_STAX FOR  ICICI.BG_DCC_STAX
/
GRANT EXECUTE ON  ICICI.BG_DCC_STAX TO TBAGEN, TBAUTIL, TBAADM
/
COMMIT
/
