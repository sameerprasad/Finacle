--===================================================================================================================
--  Filename                :   letters_bankatcampus.sql
--  Description             :
--  Date                    :   05-09-2012
--  Author                  :   Swaroop K Tiruvoipati
--  Menu Option             :
--  Modification History
--    Sl. #           Date           Author                     Modification
--    -----           -----          --------                    ----------------
--    1               05-09-2012     Swaroop K Tiruvoipati      Original Version
--                                                              (Ported from 7.x)
--===================================================================================================================
set timing on
declare
	loc_fp				utl_file.file_type;
	loc_filename		varchar2(200);
	loc_filepath		varchar2(100);
	loc_filemode		varchar(10);
	outname				varchar2(50):='&2';
	genrep				number;
	repdt				date;
	repdd				number;
	repmmyyyy			char(6);
	hldy				char(1);
	city_desc			varchar2(50);
	state_desc			varchar2(50);
	br_name				varchar2(50);
	recline				varchar2(500);

cursor maj2senior (curdate date) is
select  gam.cif_id,
		foracid,
		sol_id,
		cust_title_code,
		cust_name,
		cust_comu_addr1,
		cust_comu_addr2,
		cust_comu_city_code,
		cust_comu_state_code,
		cust_comu_pin_code,
		substr(cust_name,1,40) cust_name_40
from	cmg,gam
where gam.sol_id='&1'
		and gam.schm_type='SBA'
		and gam.cif_id=cmg.cif_id
		and	cust_stat_code in ('STUDT','STUDN','FTUDT','FTUDN')
		and floor(to_date(curdate) - add_months(date_of_birth,325)) = -61
		and	cust_nre_flg <> 'Y'
		and	acct_cls_flg <> 'Y'
		and	cmg.del_flg <> 'Y'
		and gam.entity_cre_flg = 'Y'
		and	gam.del_flg <> 'Y'
                and cmg.BANK_ID = '&4'
                and gam.BANK_ID = '&4';

begin
	loc_filepath := '/mistmp1/Letters';
	loc_filename := outname;
	loc_filemode := 'w';
	loc_fp := utl_file.fopen(loc_filepath, loc_filename, loc_filemode);

---	select db_stat_date into repdt from gct where BANK_ID = '&4';
    repdt := '&3';

		for rec in maj2senior(repdt)
		loop
			begin
				select ref_desc into city_desc from rct where ref_rec_type = '01' and ref_code = rec.cust_comu_city_code and BANK_ID = '&4';
			exception
			when others then
				city_desc := '';
			end;
			begin
				select ref_desc into state_desc from rct where ref_rec_type = '02' and ref_code = rec.cust_comu_city_code and BANK_ID = '&4';
			exception
			when others then
				state_desc := '';
			end;
			begin
				select substr(sol_desc,1,50) into  br_name from SOL where sol_id = rec.sol_id and BANK_ID = '&4';
			exception
			when others then
				br_name := '';
			end;
			recline	:= rec.cust_title_code 		|| '|' ||
					rec.cust_name 				|| '|' ||
					rec.cust_comu_addr1 		|| '|' ||
					rec.cust_comu_addr2 		|| '|' ||
					city_desc 					|| '|' ||
					state_desc 					|| '|' ||
					rec.cust_comu_pin_code	 	|| '|' ||
					rec.cust_name_40			|| '|' ||
					repdt						|| '|' ||
					rec.foracid					|| '|' ||
					br_name;
			utl_file.put_line(loc_fp, recline);
	end loop;
	utl_file.fclose(loc_fp);
end;
/
