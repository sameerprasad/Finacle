
set echo off head off pagesi 60 verify off feedback off serveroutput on size 1000000 linesi 180

spool &1.sbdrbal.txt

declare

cursor gamsel(gfrdt gam.rcre_time%type) is 
select acid,foracid,cust_id,clr_bal_amt,substr(acct_name,1,50) an from gam where gam.sol_id = '&1' and schm_type = 'SBA' and 
acct_cls_date is null and clr_bal_amt < 0 and acct_opn_date <= gfrdt and bank_id='&3';


ctbal eab.tran_date_bal%type := 0;
dtbal eab.tran_date_bal%type := 0; 
onbal eab.tran_date_bal%type := 0;
ctdt  eab.eod_date%type;
dtdt  eab.eod_date%type;
ondate  eab.eod_date%type;
frdt gam.rcre_time%type;
todate gam.rcre_time%type;
cnt number := 0;
custstat cmg.cust_stat_code%type;

begin

select to_date('&2','dd-mm-yyyy'),to_date('&2','dd-mm-yyyy')-90 into todate,frdt from dual;

for i in gamsel(frdt)
loop

--	dbms_output.put_line(i.foracid||'|'||i.acid);
	begin
		select tran_date_bal,eod_date into onbal,ondate from eab where acid = i.acid and eod_date = (select max(eod_date) 
		from eab where acid = i.acid and eod_date <= to_date('&2','dd-mm-yyyy')) and bank_id='&3';

--		dbms_output.put_line(i.foracid||'|'||onbal||'|'||ondate);
		if ( onbal < 0 )
		then

			begin
				select tran_date_bal,eod_date into ctbal,ctdt from eab where acid = i.acid and 
				tran_date_bal >= 0 and eod_date > to_date('&2','dd-mm-yyyy') and rownum < 2 and bank_id='&3';
			exception
			when no_data_found then


		    if ( cnt = 0 )
      		then
         		dbms_output.put_line( '.                             SB accounts which are in debit from more than 90 days ' );
         		dbms_output.put_line( '.                                          as on ' ||todate);
         		dbms_output.put_line( '------------------------------------------------------------------------------------------------------------------------------');
         		dbms_output.put_line( '   Acct Number                       Acct Name                      Status   Date of debit      Debit bal        Todays Balance');
         		dbms_output.put_line( '------------------------------------------------------------------------------------------------------------------------------');
				cnt := cnt + 5;
      		end if;


				select eod_date,tran_date_bal into dtdt,dtbal from eab where acid = i.acid and eod_date = 
				(select max(end_eod_date)+1 from eab where acid = i.acid and tran_date_bal >= 0) and bank_id='&3';

				select cust_stat_code into custstat from cmg where cust_id = i.cust_id and bank_id='&3';

				dbms_output.put_line( rpad(i.foracid,14)								||' '||
											 rpad(i.an,52)								||' '||
											 rpad(custstat,7)							||' '||
											 rpad(dtdt,10) 								||' '||
											 to_char(dtbal,'99,99,99,999.99')			||' '||
											 to_char(i.clr_bal_amt,'99,99,99,999.99'));
				cnt := cnt + 1;

				if ( cnt > 54 )
				then
					
         		dbms_output.put_line( '------------------------------------------------------------------------------------------------------------------------------');
					cnt := 0;
				end if;


			end;

		end if;

		exception
		when no_data_found then null;
	end;

end loop;

end;
/

spool off

