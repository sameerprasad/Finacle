set head off
set linesize 300
set pages 0
set trims on
set feedback off
set verify off
set termout off
spool  datediff
select	(to_date('&1','dd-mm-yyyy') - db_stat_date)||'|'||
		(to_date('&2','dd-mm-yyyy') - db_stat_date)||'|'||
		decode ( sign(substr('&1',4,2) -3 ),
		1,substr('&1',7,4),
		substr('&1',7,4) - 1 )
from gct where bank_id='&3';
spool off
