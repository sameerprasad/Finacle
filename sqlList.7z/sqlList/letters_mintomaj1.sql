--======================================================================================================
--  Filename                :   letters_mintomaj1.sql
--  Description             :   
--  Date                    :   09-04-2013
--  Author                  :   Vaibhav B and Supreeth
--  Menu Option             :
--  Modification History
--    Sl. #           Date           Author                     Modification
--    -----           -----          --------                    ----------------
--    1               09-04-2013     Vaibhav B and Supreeth      Original Version
--                                                              (Ported from 7.x) for CR-138-29400
--=====================================================================================================
declare
        loc_fp               utl_file.file_type;
        loc_filename         varchar2(200);
        loc_filepath         varchar2(100);
        loc_filemode         varchar(10);
        genrep                                  number;
        repdt                                   date;
        repdd                                   number;
        repmmyyyy                               char(6);
        hldy                                            char(1);
        city_desc            varchar2(50);
        state_desc           varchar2(50);
        recline                                 varchar2(500);
	addr1			cnma.address1%type;
	addr2			cnma.address2%type;
	city_code		cnma.city_code%type;
	state_code		cnma.state_code%type;
	pin_code		cnma.pin_code%type;

cursor min2maj (dt in date) is
select  a.cif_id          cust_id      ,
   cust_title_code,
   cust_name,
   substr(cust_name,1,40) cust_name_40,
   foracid
        from cmg a, cmt c,gam d where
        primary_sol_id in (select sol_id from sol where bank_id = '&1')and
        d.acct_cls_flg = 'N'
        and minor_attain_major_date = (dt+30)
        and a.cust_id=c.cust_id
        and a.cif_id=d.cif_id
        and a.bank_id=d.bank_id
        and c.bank_id = a.bank_id
        and a.bank_id='&1'
        order by a.cif_id;

begin

        loc_filepath := '/tmp';
        loc_filename := 'mintomaj1.lst';
        loc_filemode := 'w';
        loc_fp := utl_file.fopen(loc_filepath, loc_filename, loc_filemode);


        select db_stat_date into repdt from gct where bank_id='&1';

        genrep := 1;
        while (genrep = 1)
        loop
                for rec in min2maj(repdt)
                loop
			begin
				select address1,address2,city_code,state_code,pin_code 
				into addr1,addr2,city_code,state_code,pin_code from cnma
				where addr_b2kid = rec.cust_id and addr_id='Mailing' and bank_id = '&1';
			exception
				when others then
					addr1 := '';
					addr2 := '';
					city_code := '';
					state_code := '';
					pin_code := '';
			end;

                        begin
                                select ref_desc into city_desc from rct where ref_rec_type = '01' and ref_code =
                                                city_code and bank_id='&1';
                        exception
                                when others then
                                        city_desc := '';
                        end;
                        begin
                                select ref_desc into state_desc from rct where ref_rec_type = '02' and ref_code =
                                                state_code and bank_id='&1';
                        exception
                                when others then
                                        state_desc := '';
                        end;
                        recline  := rec.cust_id                                 || '|' ||
                                                        rec.cust_title_code             || '|' ||
                                                        rec.cust_name                           || '|' ||
                                                        addr1             || '|' ||
                                                        addr2             || '|' ||
                                                        city_desc                                       || '|' ||
                                                        state_desc                                      || '|' ||
                                                        pin_code  || '|' ||
                                                        rec.cust_name_40                        || '|' ||
                                                        rec.foracid ;

                        utl_file.put_line(loc_fp, recline);
                end loop;


                repdt := repdt - 1;
                repdd := to_number(to_char(repdt, 'dd'));
                repmmyyyy := to_char(repdt, 'mmyyyy');

                select substr(hldy_str,repdd,1) into hldy from hol where
                cal_b2k_type = 'DC' and mmyyyy = repmmyyyy and bank_id='&1';

                if (hldy = 'Y') then
                        genrep := 1;
                else
                        genrep := 0;
                end if;

        end loop;
        utl_file.fclose(loc_fp);

end;
/
