set head off lines 1000 trims on feedback off verify off 
spool &1..inlandLCIss.txt
select DC_REF_NUM||'|'||to_char(EVENT_DATE,'dd-MON-yyyy')||'|'||to_char(a.EXPIRY_DATE,'dd-MON-yyyy')||'|'||to_char(OPEN_VALUE,'99,99,99,99,99,999.99')||'|'||ADVISING_BANK_CODE||'|'||NAME||'|'||c.CRNCY_CODE||'|'||d.foracid||'|'||OUR_PARTY_ACID||'|'||
case when ALERT_TYPE1 in ('A','F') then MOBILE1||'|'||ALERT_TYPE1 else '|' end||'|'||
case when ALERT_TYPE2 in ('A','F') then MOBILE2||'|'||ALERT_TYPE2 else '|' end||'|'||
case when ALERT_TYPE3 in ('A','F') then MOBILE3||'|'||ALERT_TYPE3 else '|' end||'|'||
case when ALERT_TYPE4 in ('A','F') then MOBILE4||'|'||ALERT_TYPE4 else '|' end||'|'||
case when ALERT_TYPE5 in ('A','F') then MOBILE5||'|'||ALERT_TYPE5 else '|' end
from dcmm a,nma b,dcem c, gam d, icici_sms_reg e
where a.DC_B2KID=b.ADDR_B2KID and a.DC_B2KID=c.DC_B2KID and a.OUR_PARTY_ACID=d.acid and d.foracid=e.foracid 
and ADDR_ID='DCOTPY' and EVENT_DATE=to_date('&2','ddmmyyyy') and a.ENTITY_CRE_FLG='Y' and a.DEL_FLG!='Y' and EVENT_TYPE='S' 
and DC_REG_TYPE='OUTIN' 
and     a.sol_id = '&1'
and     a.lchg_time >= to_date(to_date(sysdate,'DD-MM-YYYY')||' '||to_char(sysdate-2/24,'hh24'), 'dd-mm-yyyy hh24')
AND     a.lchg_time < to_date(to_date(sysdate,'DD-MM-YYYY')||' '||to_char(sysdate,'hh24'), 'dd-mm-yyyy hh24')
AND a.bank_id = '&3'
AND b.bank_id = '&3' 
AND c.bank_id = '&3' 
AND d.bank_id = '&3'
AND e.bank_id = '&3'
/
spool off



set head off lines 1000 trims on feedback off verify off 
spool &1..InlandBGIss.txt
select EVENT_TYPE||'|'||to_char(EVENT_DATE,'dd-MON-yyyy')||'|'||to_char(EVENT_AMT,'99,99,99,99,99,999.99')||'|'||EVENT_CRNCY||'|'||to_char(b.BG_EXPIRY_DATE,'dd-MON-yyyy')||'|'||BG_SRL_NUM||'|'||BENEFICIARY_NAME||'|'||c.foracid||'|'||b.OPER_ACID||'|'||
case when ALERT_TYPE1 in ('B','F') then MOBILE1||'|'||ALERT_TYPE1 else '|' end||'|'||
case when ALERT_TYPE2 in ('B','F') then MOBILE2||'|'||ALERT_TYPE2 else '|' end||'|'||
case when ALERT_TYPE3 in ('B','F') then MOBILE3||'|'||ALERT_TYPE3 else '|' end||'|'||
case when ALERT_TYPE4 in ('B','F') then MOBILE4||'|'||ALERT_TYPE4 else '|' end||'|'||
case when ALERT_TYPE5 in ('B','F') then MOBILE5||'|'||ALERT_TYPE5 else '|' end
from bet a, bgm b,gam c, icici_sms_reg d
where a.BG_B2KID=b.BG_B2KID and b.OPER_ACID=c.acid and c.foracid=d.foracid and EVENT_DATE=to_date('&2','ddmmyyyy') and EVENT_TYPE='A'
and     b.SOL_ID = '&1'
and     a.lchg_time >= to_date(to_date(sysdate,'DD-MM-YYYY')||' '||to_char(sysdate-2/24,'hh24'), 'dd-mm-yyyy hh24')
AND     a.lchg_time < to_date(to_date(sysdate,'DD-MM-YYYY')||' '||to_char(sysdate,'hh24'), 'dd-mm-yyyy hh24')
AND a.bank_id = '&3'
AND b.bank_id = '&3'
AND c.bank_id = '&3'
AND d.bank_id = '&3'

/
spool off



set head off lines 1000 trims on feedback off verify off 
spool &1..Usance_Inland_Bill_Lodgment_LC.txt
select a.SOL_ID||'|'||BILL_ID||'|'||to_char(LODG_DATE,'dd-MON-yyyy')||'|'||to_char(DUE_DATE,'dd-MON-yyyy')||'|'||DC_REF_NUM||'|'||DRAWER_DETAILS||'|'||b.foracid||'|'||a.OPER_ACID||'|'||
case when ALERT_TYPE1 in ('D','F') then MOBILE1||'|'||ALERT_TYPE1 else '|' end||'|'||
case when ALERT_TYPE2 in ('D','F') then MOBILE2||'|'||ALERT_TYPE2 else '|' end||'|'||
case when ALERT_TYPE3 in ('D','F') then MOBILE3||'|'||ALERT_TYPE3 else '|' end||'|'||
case when ALERT_TYPE4 in ('D','F') then MOBILE4||'|'||ALERT_TYPE4 else '|' end||'|'||
case when ALERT_TYPE5 in ('D','F') then MOBILE5||'|'||ALERT_TYPE5 else '|' end
from blt a, gam b, icici_sms_reg c 
where LODG_DATE='&2' and a.OPER_ACID=b.acid  and b.foracid=c.foracid and reg_type='IBC' and reg_sub_type='IBCUB'
and (ALERT_TYPE1 in ('D','F') or ALERT_TYPE2 in ('D','F') or ALERT_TYPE3 in ('D','F') or ALERT_TYPE4 in ('D','F') or ALERT_TYPE5 in ('D','F'))
and     a.sol_id = '&1'
and     a.lchg_time >= to_date(to_date(sysdate,'DD-MM-YYYY')||' '||to_char(sysdate-2/24,'hh24'), 'dd-mm-yyyy hh24')
AND     a.lchg_time < to_date(to_date(sysdate,'DD-MM-YYYY')||' '||to_char(sysdate,'hh24'), 'dd-mm-yyyy hh24')
AND a.bank_id = '&3'
AND b.bank_id = '&3'
AND c.bank_id = '&3'

/
spool off

set head off lines 1000 trims on feedback off verify off 
spool &1..Sight_Inland_Bill_Lodgment_LC.txt
select a.SOL_ID||'|'||BILL_ID||'|'||to_char(LODG_DATE,'dd-MON-yyyy')||'|'||to_char(DUE_DATE,'dd-MON-yyyy')||'|'||DC_REF_NUM||'|'||DRAWER_DETAILS||'|'||b.foracid||'|'||a.OPER_ACID||'|'||
case when ALERT_TYPE1 in ('D','F') then MOBILE1||'|'||ALERT_TYPE1 else '|' end||'|'||
case when ALERT_TYPE2 in ('D','F') then MOBILE2||'|'||ALERT_TYPE2 else '|' end||'|'||
case when ALERT_TYPE3 in ('D','F') then MOBILE3||'|'||ALERT_TYPE3 else '|' end||'|'||
case when ALERT_TYPE4 in ('D','F') then MOBILE4||'|'||ALERT_TYPE4 else '|' end||'|'||
case when ALERT_TYPE5 in ('D','F') then MOBILE5||'|'||ALERT_TYPE5 else '|' end
from blt a, gam b, ICICI_SMS_REG c 
where LODG_DATE='&2' and a.OPER_ACID=b.acid and b.foracid=c.foracid and reg_type='IBC' and reg_sub_type='IBCDB'
and (ALERT_TYPE1 in ('D','F') or ALERT_TYPE2 in ('D','F') or ALERT_TYPE3 in ('D','F') or ALERT_TYPE4 in ('D','F') or ALERT_TYPE5 in ('D','F'))
and     a.sol_id = '&1'
and     a.lchg_time >= to_date(to_date(sysdate,'DD-MM-YYYY')||' '||to_char(sysdate-2/24,'hh24'), 'dd-mm-yyyy hh24')
AND     a.lchg_time < to_date(to_date(sysdate,'DD-MM-YYYY')||' '||to_char(sysdate,'hh24'), 'dd-mm-yyyy hh24')
AND a.bank_id = '&3'
AND b.bank_id = '&3'
AND c.bank_id = '&3'

/
spool off

set head off lines 1000 trims on feedback off verify off 
spool &1..Usance_Import_Bill_Lodgment_LC.txt
select a.SOL_ID||'|'||a.BILL_ID||'|'||LC_NUMBER||'|'||OTHER_PARTY_NAME||'|'||to_char(LODG_DATE,'dd-MON-yyyy')||'|'||to_char(DUE_DATE,'dd-MON-yyyy')||'|'||c.foracid||'|'||a.OPER_ACID||'|'||
case when ALERT_TYPE1 in ('D','F') then MOBILE1||'|'||ALERT_TYPE1 else '|' end||'|'||
case when ALERT_TYPE2 in ('D','F') then MOBILE2||'|'||ALERT_TYPE2 else '|' end||'|'||
case when ALERT_TYPE3 in ('D','F') then MOBILE3||'|'||ALERT_TYPE3 else '|' end||'|'||
case when ALERT_TYPE4 in ('D','F') then MOBILE4||'|'||ALERT_TYPE4 else '|' end||'|'||
case when ALERT_TYPE5 in ('D','F') then MOBILE5||'|'||ALERT_TYPE5 else '|' end
from fbm a,fei b, gam c, icici_sms_reg d
where a.BILL_ID=b.BILL_ID and a.SOL_ID=b.SOL_ID and a.OPER_ACID=c.acid and c.foracid=d.foracid 
and LODG_DATE='&2' and reg_type='ABLC' and reg_sub_type='U'
and (ALERT_TYPE1 in ('D','F') or ALERT_TYPE2 in ('D','F') or ALERT_TYPE3 in ('D','F') or ALERT_TYPE4 in ('D','F') or ALERT_TYPE5 in ('D','F'))
and     a.sol_id = '&1'
and     a.lchg_time >= to_date(to_date(sysdate,'DD-MM-YYYY')||' '||to_char(sysdate-2/24,'hh24'), 'dd-mm-yyyy hh24')
AND     a.lchg_time < to_date(to_date(sysdate,'DD-MM-YYYY')||' '||to_char(sysdate,'hh24'), 'dd-mm-yyyy hh24')
AND a.bank_id = '&3'
AND b.bank_id = '&3'
AND c.bank_id = '&3'
AND d.bank_id = '&3'

/
spool off

set head off lines 1000 trims on feedback off verify off 
spool &1..Sight_Import_Bill_Lodgment_LC.txt
select a.SOL_ID||'|'||a.BILL_ID||'|'||LC_NUMBER||'|'||OTHER_PARTY_NAME||'|'||to_char(LODG_DATE,'dd-MON-yyyy')||'|'||to_char(DUE_DATE,'dd-MON-yyyy')||'|'||c.foracid||'|'||a.OPER_ACID||'|'||
case when ALERT_TYPE1 in ('D','F') then MOBILE1||'|'||ALERT_TYPE1 else '|' end||'|'||
case when ALERT_TYPE2 in ('D','F') then MOBILE2||'|'||ALERT_TYPE2 else '|' end||'|'||
case when ALERT_TYPE3 in ('D','F') then MOBILE3||'|'||ALERT_TYPE3 else '|' end||'|'||
case when ALERT_TYPE4 in ('D','F') then MOBILE4||'|'||ALERT_TYPE4 else '|' end||'|'||
case when ALERT_TYPE5 in ('D','F') then MOBILE5||'|'||ALERT_TYPE5 else '|' end
from fbm a,fei b,gam c, icici_sms_reg d
where a.BILL_ID=b.BILL_ID and a.SOL_ID=b.SOL_ID and a.OPER_ACID=c.acid and c.foracid=d.foracid 
and LODG_DATE='&2' and reg_type='ABLC' and reg_sub_type='S'
and (ALERT_TYPE1 in ('D','F') or ALERT_TYPE2 in ('D','F') or ALERT_TYPE3 in ('D','F') or ALERT_TYPE4 in ('D','F') or ALERT_TYPE5 in ('D','F'))
and     a.sol_id = '&1'
and     a.lchg_time >= to_date(to_date(sysdate,'DD-MM-YYYY')||' '||to_char(sysdate-2/24,'hh24'), 'dd-mm-yyyy hh24')
AND     a.lchg_time < to_date(to_date(sysdate,'DD-MM-YYYY')||' '||to_char(sysdate,'hh24'), 'dd-mm-yyyy hh24')
AND a.bank_id = '&3'
AND b.bank_id = '&3'
AND c.bank_id = '&3'
AND d.bank_id = '&3'

/
spool off

set head off lines 1000 trims on feedback off verify off 
spool &1..Import_Bill_Lodgment_Collection.txt
select a.SOL_ID||'|'||BILL_ID||'|'||OTHER_PARTY_NAME||'|'||to_char(LODG_DATE,'dd-MON-yyyy')||'|'||to_char(DUE_DATE,'dd-MON-yyyy')||'|'||b.foracid||'|'||a.OPER_ACID||'|'||
case when ALERT_TYPE1 in ('D','F') then MOBILE1||'|'||ALERT_TYPE1 else '|' end||'|'||
case when ALERT_TYPE2 in ('D','F') then MOBILE2||'|'||ALERT_TYPE2 else '|' end||'|'||
case when ALERT_TYPE3 in ('D','F') then MOBILE3||'|'||ALERT_TYPE3 else '|' end||'|'||
case when ALERT_TYPE4 in ('D','F') then MOBILE4||'|'||ALERT_TYPE4 else '|' end||'|'||
case when ALERT_TYPE5 in ('D','F') then MOBILE5||'|'||ALERT_TYPE5 else '|' end
from fbm a, gam b, icici_sms_reg c 
where a.OPER_ACID=b.acid and b.foracid=c.foracid and LODG_DATE='&2' and reg_type='FIBC'
and (ALERT_TYPE1 in ('D','F') or ALERT_TYPE2 in ('D','F') or ALERT_TYPE3 in ('D','F') or ALERT_TYPE4 in ('D','F') or ALERT_TYPE5 in ('D','F'))
and     a.sol_id = '&1'
and     a.lchg_time >= to_date(to_date(sysdate,'DD-MM-YYYY')||' '||to_char(sysdate-2/24,'hh24'), 'dd-mm-yyyy hh24')
AND     a.lchg_time < to_date(to_date(sysdate,'DD-MM-YYYY')||' '||to_char(sysdate,'hh24'), 'dd-mm-yyyy hh24')
AND a.bank_id = '&3'
AND b.bank_id = '&3'
AND c.bank_id = '&3'

/
spool off

set head off lines 1000 trims on feedback off verify off 
spool &1..Inland_Bill_Lodgment_Collection.txt
select a.SOL_ID||'|'||BILL_ID||'|'||to_char(LODG_DATE,'dd-MON-yyyy')||'|'||to_char(DUE_DATE,'dd-MON-yyyy')||'|'||DC_REF_NUM||'|'||DRAWER_DETAILS||'|'||b.foracid||'|'||a.OPER_ACID||'|'||
case when ALERT_TYPE1 in ('D','F') then MOBILE1||'|'||ALERT_TYPE1 else '|' end||'|'||
case when ALERT_TYPE2 in ('D','F') then MOBILE2||'|'||ALERT_TYPE2 else '|' end||'|'||
case when ALERT_TYPE3 in ('D','F') then MOBILE3||'|'||ALERT_TYPE3 else '|' end||'|'||
case when ALERT_TYPE4 in ('D','F') then MOBILE4||'|'||ALERT_TYPE4 else '|' end||'|'||
case when ALERT_TYPE5 in ('D','F') then MOBILE5||'|'||ALERT_TYPE5 else '|' end
from blt a, gam b, icici_sms_reg c 
where a.OPER_ACID=b.acid and b.foracid=c.foracid and LODG_DATE='&2' and reg_type='IBC'
and (ALERT_TYPE1 in ('D','F') or ALERT_TYPE2 in ('D','F') or ALERT_TYPE3 in ('D','F') or ALERT_TYPE4 in ('D','F') or ALERT_TYPE5 in ('D','F'))
and     a.sol_id = '&1'
and     a.lchg_time >= to_date(to_date(sysdate,'DD-MM-YYYY')||' '||to_char(sysdate-2/24,'hh24'), 'dd-mm-yyyy hh24')
AND     a.lchg_time < to_date(to_date(sysdate,'DD-MM-YYYY')||' '||to_char(sysdate,'hh24'), 'dd-mm-yyyy hh24')
AND a.bank_id = '&3'
AND b.bank_id = '&3'
AND c.bank_id = '&3'

/
spool off

set head off lines 1000 trims on feedback off verify off
spool &1..Export_Bill_Disc_Pur_Nego.txt
select a.SOL_ID||'|'||a.BILL_ID||'|'||OTHER_PARTY_NAME||'|'||to_char(VFD_BOD_DATE,'dd-MON-yyyy')||'|'||to_char(a.DUE_DATE,'dd-MON-yyyy')||'|'||c.foracid||'|'||e.MSG||'|'||
case when ALERT_TYPE1 in ('D','F') then MOBILE1||'|'||ALERT_TYPE1 else '|' end||'|'||
case when ALERT_TYPE2 in ('D','F') then MOBILE2||'|'||ALERT_TYPE2 else '|' end||'|'||
case when ALERT_TYPE3 in ('D','F') then MOBILE3||'|'||ALERT_TYPE3 else '|' end||'|'||
case when ALERT_TYPE4 in ('D','F') then MOBILE4||'|'||ALERT_TYPE4 else '|' end||'|'||
case when ALERT_TYPE5 in ('D','F') then MOBILE5||'|'||ALERT_TYPE5 else '|' end
from fbm a,fbh b,gam c, icici_sms_reg d, fxm e,
where a.SOL_ID=b.SOL_ID and a.BILL_ID=b.BILL_ID and a.OPER_ACID=c.acid and c.foracid=d.foracid 
--Below changes done by Ripal for TOL 330594
--and a.SOL_ID=e.SOL_ID and a.BILL_ID=e.BILL_ID
and a.BILL_B2K_ID = e.B2K_ID
and VFD_BOD_DATE=to_date('&2','ddmmyyyy') and BILL_FUNC='P' and reg_type in ('FOBP','FBPF') and nvl(a.CORR_COLL_BANK_CODE,'!') != nvl('DEXP','!') and nvl(a.CORR_COLL_BR_CODE,'!') != nvl('DIRECT','!')
and (ALERT_TYPE1 in ('D','F') or ALERT_TYPE2 in ('D','F') or ALERT_TYPE3 in ('D','F') or ALERT_TYPE4 in ('D','F') or ALERT_TYPE5 in ('D','F'))
and d.ENTITY_CREATION_FLG = 'Y'
and d.del_flg = 'N'
and     a.sol_id = '&1'
and     a.lchg_time >= to_date(to_date(sysdate,'DD-MM-YYYY')||' '||to_char(sysdate-2/24,'hh24'), 'dd-mm-yyyy hh24')
AND     a.lchg_time < to_date(to_date(sysdate,'DD-MM-YYYY')||' '||to_char(sysdate,'hh24'), 'dd-mm-yyyy hh24')
AND a.bank_id = '&3'
AND b.bank_id = '&3'
AND c.bank_id = '&3'
AND d.bank_id = '&3'
AND e.bank_id = '&3'
/
spool off

set head off lines 1000 trims on feedback off verify off
spool &1..Inland_outward_Dis_Pur_Nego.txt
select a.SOL_ID||'|'||a.BILL_ID||'|'||to_char(VFD_BOD_DATE,'dd-MON-yyyy')||'|'||to_char(DUE_DATE,'dd-MON-yyyy')||'|'||DC_REF_NUM||'|'||DRAWEE_NAME||'|'||b.foracid||'|'||a.OPER_ACID||'|'||
case when ALERT_TYPE1 in ('D','F') then MOBILE1||'|'||ALERT_TYPE1 else '|' end||'|'||
case when ALERT_TYPE2 in ('D','F') then MOBILE2||'|'||ALERT_TYPE2 else '|' end||'|'||
case when ALERT_TYPE3 in ('D','F') then MOBILE3||'|'||ALERT_TYPE3 else '|' end||'|'||
case when ALERT_TYPE4 in ('D','F') then MOBILE4||'|'||ALERT_TYPE4 else '|' end||'|'||
case when ALERT_TYPE5 in ('D','F') then MOBILE5||'|'||ALERT_TYPE5 else '|' end
from blt a, gam b, icici_sms_reg c, beh d
where a.sol_id=d.sol_id and VFD_BOD_DATE=to_date('&2','ddmmyyyy') and BILL_FUNC='P' and a.OPER_ACID=b.acid and b.foracid=c.foracid
and a.bill_id=d.bill_id and reg_type in ('OBP','OBD')
and (ALERT_TYPE1 in ('D','F') or ALERT_TYPE2 in ('D','F') or ALERT_TYPE3 in ('D','F') or ALERT_TYPE4 in ('D','F') or ALERT_TYPE5 in ('D','F'))
and c.ENTITY_CREATION_FLG = 'Y'
and c.del_flg = 'N'
and     a.sol_id = '&1'
and     a.lchg_time >= to_date(to_date(sysdate,'DD-MM-YYYY')||' '||to_char(sysdate-2/24,'hh24'), 'dd-mm-yyyy hh24')
AND     a.lchg_time < to_date(to_date(sysdate,'DD-MM-YYYY')||' '||to_char(sysdate,'hh24'), 'dd-mm-yyyy hh24')
AND a.bank_id = '&3'
AND b.bank_id = '&3'
AND c.bank_id = '&3'
AND d.bank_id = '&3'

/
spool off

set head off lines 1000 trims on feedback off verify off
spool &1..Export_Bill_Lodgment.txt
select a.SOL_ID||'|'||a.BILL_ID||'|'||OTHER_PARTY_NAME||'|'||to_char(VFD_BOD_DATE,'dd-MON-yyyy')||'|'||to_char(a.DUE_DATE,'dd-MON-yyyy')||'|'||c.foracid||'|'||e.MSG||'|'||to_char(a.LODG_DATE,'dd-MON-yyyy')||'|'||
case when ALERT_TYPE1 in ('D','F') then MOBILE1||'|'||ALERT_TYPE1 else '|' end||'|'||
case when ALERT_TYPE2 in ('D','F') then MOBILE2||'|'||ALERT_TYPE2 else '|' end||'|'||
case when ALERT_TYPE3 in ('D','F') then MOBILE3||'|'||ALERT_TYPE3 else '|' end||'|'||
case when ALERT_TYPE4 in ('D','F') then MOBILE4||'|'||ALERT_TYPE4 else '|' end||'|'||
case when ALERT_TYPE5 in ('D','F') then MOBILE5||'|'||ALERT_TYPE5 else '|' end
from fbm a,fbh b,gam c, icici_sms_reg d, fxm e
where a.SOL_ID=b.SOL_ID and a.BILL_ID=b.BILL_ID and a.OPER_ACID=c.acid and c.foracid=d.foracid
--Below changes done by Ripal for TOL 330594
--and a.SOL_ID=e.SOL_ID and a.BILL_ID=e.BILL_ID 
and a.BILL_B2K_ID = e.B2K_ID
and nvl(a.CORR_COLL_BANK_CODE,'!') != nvl('DEXP','!') and nvl(a.CORR_COLL_BR_CODE,'!') != nvl('DIRECT','!')
and VFD_BOD_DATE=to_date('&2','ddmmyyyy') and BILL_FUNC='G' and reg_type in ('FOBP','FBPF','FOBC')
and (ALERT_TYPE1 in ('D','F') or ALERT_TYPE2 in ('D','F') or ALERT_TYPE3 in ('D','F') or ALERT_TYPE4 in ('D','F') or ALERT_TYPE5 in ('D','F'))
and d.ENTITY_CREATION_FLG = 'Y'
and d.del_flg = 'N'
and     a.sol_id = '&1'
and     a.lchg_time >= to_date(to_date(sysdate,'DD-MM-YYYY')||' '||to_char(sysdate-2/24,'hh24'), 'dd-mm-yyyy hh24')
AND     a.lchg_time < to_date(to_date(sysdate,'DD-MM-YYYY')||' '||to_char(sysdate,'hh24'), 'dd-mm-yyyy hh24')
AND a.bank_id = '&3'
AND b.bank_id = '&3'
AND c.bank_id = '&3'
AND d.bank_id = '&3'
AND e.bank_id = '&3'
/
spool off

set head off lines 1000 trims on feedback off verify off
spool &1..Inland_Bill_lodgement.txt
select a.SOL_ID||'|'||a.BILL_ID||'|'||to_char(VFD_BOD_DATE,'dd-MON-yyyy')||'|'||to_char(DUE_DATE,'dd-MON-yyyy')||'|'||DC_REF_NUM||'|'||DRAWEE_NAME||'|'||b.foracid||'|'||to_char(a.LODG_DATE,'dd-MON-yyyy')||'|'||
case when ALERT_TYPE1 in ('D','F') then MOBILE1||'|'||ALERT_TYPE1 else '|' end||'|'||
case when ALERT_TYPE2 in ('D','F') then MOBILE2||'|'||ALERT_TYPE2 else '|' end||'|'||
case when ALERT_TYPE3 in ('D','F') then MOBILE3||'|'||ALERT_TYPE3 else '|' end||'|'||
case when ALERT_TYPE4 in ('D','F') then MOBILE4||'|'||ALERT_TYPE4 else '|' end||'|'||
case when ALERT_TYPE5 in ('D','F') then MOBILE5||'|'||ALERT_TYPE5 else '|' end
from blt a, gam b, icici_sms_reg c, beh d
where a.sol_id=d.sol_id and VFD_BOD_DATE=to_date('&2','ddmmyyyy') and BILL_FUNC='G' and a.OPER_ACID=b.acid and b.foracid=c.foracid
and a.bill_id=d.bill_id and reg_type in ('OBP','OBD','OBC')
and (ALERT_TYPE1 in ('D','F') or ALERT_TYPE2 in ('D','F') or ALERT_TYPE3 in ('D','F') or ALERT_TYPE4 in ('D','F') or ALERT_TYPE5 in ('D','F'))
and c.ENTITY_CREATION_FLG = 'Y'
and c.del_flg = 'N'
and     a.sol_id = '&1'
and     a.lchg_time >= to_date(to_date(sysdate,'DD-MM-YYYY')||' '||to_char(sysdate-2/24,'hh24'), 'dd-mm-yyyy hh24')
AND     a.lchg_time < to_date(to_date(sysdate,'DD-MM-YYYY')||' '||to_char(sysdate,'hh24'), 'dd-mm-yyyy hh24')
AND a.bank_id = '&3'
AND b.bank_id = '&3'
AND c.bank_id = '&3'
AND d.bank_id = '&3'

/
spool off
