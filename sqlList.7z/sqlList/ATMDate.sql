set head off
set echo off
set trims on
set pagesize 1000
spool atmDt
select to_char(DB_STAT_DATE-1,'DDMMYYYY') FROM GCT;
spool off
