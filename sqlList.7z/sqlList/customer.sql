-- #############################################################
-- #    Source Name: customer.sql                                  #
-- #    Description: This script is used to get the required   #
-- #                 details for customer                      # 
-- #                 in ~ seperated format.                    #
-- #############################################################

Set ServerOutPut On Size 1000000
--Set Verify Off
--Set FeedBack off
--set line 80
set trims on

Spool customer.txt

DECLARE

inpDate                varchar2(25);

-- Temporary variables.
phone			UTL_FILE.FILE_TYPE;
address			UTL_FILE.FILE_TYPE;
relation		UTL_FILE.FILE_TYPE;
personal		UTL_FILE.FILE_TYPE;
portrait		UTL_FILE.FILE_TYPE;
business		UTL_FILE.FILE_TYPE;
portfolio		UTL_FILE.FILE_TYPE;
tmpAcid			GAM.acid%type;
tmpFora			GAM.foracid%type;
tmpCustId		CRMUSER.CMG.cif_id%type;
solId			GAM.sol_id%type;
city			RCT.ref_desc%type;
country			RCT.ref_desc%type;
country_flg		number(1) := 0;
cimnumb			CRMUSER.CMG.cif_id%type;
--frstname		CMG.cust_name%type;
frstname		CRMUSER.ACCOUNTS.name%type;

--busname		CMG.cust_name%type;
busname			CRMUSER.ACCOUNTS.name%TYPE;

--cphone1		CMG.cust_comu_phone_num_1%type;
cphone1			CRMUSER.PHONEEMAIL.phoneno%TYPE;

--cphone2		CMG.cust_comu_phone_num_2%type; 
cphone2			CRMUSER.PHONEEMAIL.phoneno%TYPE;

--pphone1		CMG.cust_perm_phone_num%type; 
pphone1			CRMUSER.PHONEEMAIL.phoneno%TYPE;

--pphone2		CMG.cust_perm_phone_num_2%type; 
pphone2			CRMUSER.PHONEEMAIL.phoneno%TYPE;
			
--ephone1		CMG.cust_emp_phone_num_1%type;     
ephone1			CRMUSER.PHONEEMAIL.phoneno%TYPE;

--ephone2		CMG.cust_emp_phone_num_2%type; 
ephone2			CRMUSER.PHONEEMAIL.phoneno%TYPE;

--pager			CMG.cust_pager_no%type; 
pager			CRMUSER.DEMOGRAPHIC.pagerno%TYPE;

--cfax			CMG.cust_fax_no%type; 
cfax			CRMUSER.ACCOUNTS.fax%type;

--pfax			CMG.cust_perm_fax_num%type; 
pfax			CRMUSER.ACCOUNTS.fax_home%type; 

--efax			CMG.cust_emp_fax_num%type; 
efax			CRMUSER.PHONEEMAIL.phoneno%TYPE;
--ptelex		CMG.cust_perm_telex_num%type; 
ptelex			CRMUSER.PHONEEMAIL.phoneno%TYPE;

--ctelex		CMG.cust_comu_telex_num%type; 
ctelex			CRMUSER.PHONEEMAIL.phoneno%TYPE;

--etelex		CMG.cust_emp_telex_num%type; 
etelex			CRMUSER.PHONEEMAIL.phoneno%TYPE;

paddr			varchar(100); 
caddr			varchar(100); 
eaddr			varchar(100);
addr1			varchar(40);
addr2			varchar(40);
addr3			varchar(40);

--begdate		CMG.cust_opn_date%type; 
begdate			CRMUSER.ACCOUNTS.relationshipopeningdate%type; 

--pcity			CMG.cust_perm_city_code%type; 
pcity			CRMUSER.CORPORATE.city%type;

--ccity			CMG.cust_comu_city_code%type; 
ccity			CRMUSER.CORPORATE.city%type;

--ecity			CMG.cust_emp_city_code%type; 
ecity			CRMUSER.CORPORATE.city%type;

--pcountry		CMG.cust_perm_cntry_code%type; 
pcountry		CRMUSER.ACCOUNTS.country%type;

--ccountry		CMG.cust_comu_cntry_code%type; 
ccountry		CRMUSER.ACCOUNTS.country%type;

--ecountry		CMG.cust_emp_cntry_code%type; 
ecountry		CRMUSER.ACCOUNTS.country%type;

--ppin			CMG.cust_perm_pin_code%type; 
ppin			CRMUSER.CORPORATE.zip%type;

--cpin			CMG.cust_comu_pin_code%type; 
cpin			CRMUSER.CORPORATE.zip%type;

--epin			CMG.cust_emp_pin_code%type; 
epin			CRMUSER.CORPORATE.zip%type;

--pstate		CMG.cust_perm_state_code%type; 
pstate			CRMUSER.CORPORATE.state%type;

--cstate		CMG.cust_comu_state_code%type; 
cstate			CRMUSER.CORPORATE.state%type;

--estate		CMG.cust_emp_state_code%type; 
estate			CRMUSER.CORPORATE.state%type;

--const			CMG.cust_const%type; 
const			CRMUSER.ACCOUNTS.constitution_ref_code%type;

--dob			CMG.date_of_birth%type; 
dob			CRMUSER.ACCOUNTS.cust_dob%type;

--marital		CMG.cust_marital_status%type; 
marital			CRMUSER.DEMOGRAPHIC.marital_status%type;

--prefix		CMG.cust_title_code%type; 
prefix			CRMUSER.ACCOUNTS.salutation_code%type;

--salary		CMG.cust_salary%type; 
salary			CRMUSER.DEMOGRAPHIC.annual_salary_income%type;

--sex			CMG.cust_sex%type; 
sex			CRMUSER.ACCOUNTS.gender%type;

--email			CMG.email_id%type; 
email			CRMUSER.ACCOUNTS.email%type;

--shortname		CMG.cust_short_name%type; 
shortname		CRMUSER.ACCOUNTS.short_name%type;

--typ			CMG.cust_type_code%type; 
typ			CRMUSER.ACCOUNTS.cust_type_code%type;

--occuCatg		CMG.cust_occp_code%type;
occuCatg		CRMUSER.MISCELLANEOUSINFO.strtext2_code%type;

seqnum1			number := 1;
seqnum2			number := 1;
jointNum		number := 0;
stopCnt			number := 0; 
acctrel			number := 1;
yearsEmp		number(2) := 0;
occup			number(4) := 0;
sal			number(1) := 0;
bustype			number(4) := 6;
employer		varchar2(30) := '';
motherMaiden            varchar2(50) := '';
maritalCd		char(1);
abbr			varchar2(5) := 'SOLEO';
descript		varchar2(100) := 'Sole Owner';
bOrp			varchar2(1) := 'P';
branch			varchar2(6);
begChar			varchar2(10);
dobChar			varchar2(10);
det_line1		varchar2(1000) := '';
det_line2		varchar2(1000) := '';
det_line3		varchar2(1000) := '';
det_line4		varchar2(1000) := '';
det_line5		varchar2(1000) := '';
det_line6		varchar2(1000) := '';
det_line7		varchar2(1000) := '';
countCorp		number(1) := 0;  
l_bank_id		VARCHAR2(8) := '&2';

CURSOR     RSP_CURSOR IS 
    SELECT     cust_id,gam.acid,foracid,sol_id
    FROM     gam,gac
    WHERE     gam.acid = gac.acid
    AND        gam.schm_code in (    select     distinct schm_code 
                                --from     RSP 
				from GSP
                                where     entity_cre_flg = 'Y'
                                and     del_flg != 'Y')
   -- AND        gac.dpd_cntr >= 1
    AND        gam.acct_cls_flg != 'Y'
    AND        gam.entity_cre_flg = 'Y'
    AND        gam.del_flg != 'Y'
    AND	       gam.bank_id = l_bank_id
    AND	       gac.bank_id = l_bank_id
    ORDER BY cust_id;

CURSOR     AAS_CURSOR IS 
    SELECT     cust_id
    FROM     aas
    WHERE    acid = tmpAcid
    AND        acct_poa_as_srl_num > '000'
    AND        acct_poa_as_rec_type = 'J'
    AND        lchg_time >= to_date(inpDate,'DD-MM-YYYY HH24:MI:SS')
    AND        bank_id  = l_bank_id;


BEGIN
--{
    inpDate := '&1';

    phone        := UTL_FILE.FOPEN('/tmp','ex_phone.csv','w');
    address       := UTL_FILE.FOPEN('/tmp','ex_address.csv','w');
    relation    := UTL_FILE.FOPEN('/tmp','ex_relation.csv','w');
    personal    := UTL_FILE.FOPEN('/tmp','ex_personal.csv','w');
    portrait    := UTL_FILE.FOPEN('/tmp','ex_portrait.csv','w');
    business    := UTL_FILE.FOPEN('/tmp','ex_business.csv','w');
    portfolio    := UTL_FILE.FOPEN('/tmp','ex_portfoli.csv','w');

    OPEN RSP_CURSOR;

    LOOP
    --{
        FETCH RSP_CURSOR into tmpCustId,tmpAcid,tmpFora,solId;

        EXIT WHEN RSP_CURSOR%NOTFOUND;
        
        IF (tmpCustId is NOT NULL) THEN
        --{
            BEGIN
            --{
                SELECT    1
                INTO    jointNum
                FROM    DUAL
                WHERE    EXISTS (SELECT    cust_id
                                FROM     AAS
                                WHERE    acid = tmpAcid
                                AND        acct_poa_as_srl_num > '000'
                                AND        acct_poa_as_rec_type = 'J'
				AND        bank_id = l_bank_id);
            EXCEPTION WHEN OTHERS THEN
                jointNum := 0;
            --}
            END;
        --}
        END IF;
        
        stopCnt := 1;
        acctrel := 1;
        abbr     := 'SOLEO';
        descript:= 'Sole Owner';

        IF (jointNum != 0) THEN
            OPEN AAS_CURSOR;
            acctrel := 5;
            abbr    := 'JOINT';
            descript:= 'Joint or Other';
        END IF;
        
        LOOP
        --{
            addr1 := '-';
            addr2 := '-';
            addr3 := '-';

            IF (AAS_CURSOR%ISOPEN) THEN
                FETCH AAS_CURSOR into tmpCustId;
                IF (AAS_CURSOR%NOTFOUND) THEN
                    CLOSE AAS_CURSOR;
                    EXIT;
                END IF;
            END IF; 

            cimnumb := NULL;
            paddr := NULL;
            caddr := NULL;
            eaddr := NULL;
            
            BEGIN
            --{
		SELECT count(1)
		INTO   countCorp
		FROM CRMUSER.CMG
		WHERE CIF_ID = lpad(tmpCustId,9)
		AND CORP_ID is NOT NULL
		AND BANK_ID = l_bank_id;
		dbms_output.put_line(countCorp);

                EXCEPTION
                when others then NULL;

            END;
            
      
                IF (countCorp > 0) THEN
                --{
			BEGIN
			--Corporate CIF
				SELECT c.corp_id, SUBSTR (c.corporate_name, 1, 40),
				   SUBSTR (c.corporate_name, 1, 15),
				   DECODE(p.PHONEEMAILTYPE, 'COMMPH1', NVL (TRIM (SUBSTR (LPAD (p.phonenolocalcode, 15), 6)), '0')),
				   DECODE(p.PHONEEMAILTYPE, 'COMMPH2', TRIM (SUBSTR (LPAD (p.phonenolocalcode, 15), 6))),
				   DECODE(p.PHONEEMAILTYPE, 'HOMEPH1', TRIM (SUBSTR (LPAD (p.phonenolocalcode, 15), 6))),
				   DECODE(p.PHONEEMAILTYPE, 'HOMEPH2', TRIM (SUBSTR (LPAD (p.phonenolocalcode, 15), 6))),
				   DECODE(p.PHONEEMAILTYPE, 'WORKPH1', TRIM (SUBSTR (LPAD (p.phonenolocalcode, 15), 6))),
				   DECODE(p.PHONEEMAILTYPE, 'WORKPH2', TRIM (SUBSTR (LPAD (p.phonenolocalcode, 15), 6))),       
				   DECODE(p.PHONEEMAILTYPE, 'CELLPH', TRIM (SUBSTR (LPAD (p.phonenolocalcode, 15), 6))),       
				   DECODE(p.PHONEEMAILTYPE, 'FAX1', TRIM (SUBSTR (LPAD (p.phonenolocalcode, 15), 6))),       
				   DECODE(p.PHONEEMAILTYPE, 'FAX2', TRIM (SUBSTR (LPAD (p.phonenolocalcode, 15), 6))),   
				   DECODE(p.PHONEEMAILTYPE, 'HOMETELEX', TRIM (SUBSTR (LPAD (p.phonenolocalcode, 15), 6))),       
				   DECODE(p.PHONEEMAILTYPE, 'COMMTELEX', TRIM (SUBSTR (LPAD (p.phonenolocalcode, 15), 6))),
				   DECODE(p.PHONEEMAILTYPE, 'WORKTELEX', TRIM (SUBSTR (LPAD (p.phonenolocalcode, 15), 6))),                           
				   DECODE(ad.ADDRESSCATEGORY,'REGISTERED',ad.address_line1) || ' ' || DECODE(ad.ADDRESSCATEGORY,'REGISTERED',ad.address_line2),
				   DECODE(ad.ADDRESSCATEGORY,'MAILING',ad.address_line1) || ' ' || DECODE(ad.ADDRESSCATEGORY,'MAILING',ad.address_line2),
				   DECODE(ad.ADDRESSCATEGORY,'HEAD OFFICE',ad.address_line1) || ' ' || DECODE(ad.ADDRESSCATEGORY,'HEAD OFFICE',ad.address_line2),
				   NVL (c.relationship_startdate, '01-jan-1900'), 
				   DECODE(ad.ADDRESSCATEGORY,'REGISTERED',ad.city),
				   DECODE(ad.ADDRESSCATEGORY,'MAILING',ad.city),
				   DECODE(ad.ADDRESSCATEGORY,'HEAD OFFICE',ad.city),
				   DECODE(ad.ADDRESSCATEGORY,'REGISTERED',ad.country),
				   DECODE(ad.ADDRESSCATEGORY,'MAILING',ad.country),
				   DECODE(ad.ADDRESSCATEGORY,'HEAD OFFICE',ad.country),
				   DECODE(ad.ADDRESSCATEGORY,'REGISTERED',ad.zip),
				   DECODE(ad.ADDRESSCATEGORY,'MAILING',ad.zip),
				   DECODE(ad.ADDRESSCATEGORY,'HEAD OFFICE',ad.zip),
				   DECODE(ad.ADDRESSCATEGORY,'REGISTERED',ad.state),
				   DECODE(ad.ADDRESSCATEGORY,'MAILING',ad.state),
				   DECODE(ad.ADDRESSCATEGORY,'HEAD OFFICE',ad.state),
				   c.cust_const_code, c.date_of_commencement, p.email, c.short_name, c.cust_type_code
				   --,m.strtext2_code
			      INTO cimnumb, busname,
				   frstname,
				   cphone1,
				   cphone2,
				   pphone1,
				   pphone2,
				   ephone1,
				   ephone2,
				   pager,
				   cfax,
				   pfax,
				 --  efax,
				   ptelex,
				   ctelex,
				   etelex,
				   paddr,
				   caddr,
				   eaddr, begdate, pcity, ccity,
				   ecity, pcountry, ccountry, ecountry, ppin, cpin,
				   epin, pstate, cstate, estate, 
				   const, dob, 
				  -- marital, prefix, salary, sex,
				   email,
				   shortname,
				   typ
				  -- ,occucatg
			     FROM CRMUSER.CORPORATE c , CRMUSER.PHONEEMAIL p , CRMUSER.ADDRESS ad--, CRMUSER.MISCELLANEOUSINFO m
			     WHERE c.corp_id = p.corp_id
			     AND   c.corp_id = ad.corp_id
			     AND c.corp_id = tmpcustid
			     --AND lchg_time >= TO_DATE (inpdate, 'DD-MM-YYYY HH24:MI:SS')
			     AND c.entity_create_flg = 'Y'
			     AND c.bank_id = l_bank_id
			     AND p.bank_id = l_bank_id
			     AND ad.bank_id = l_bank_id;
			     --AND m.bank_id = l_bank_id
			     EXCEPTION
				WHEN OTHERS THEN NULL;   
                
			END;
			--}
                else
                --{
			BEGIN
			--Retail CIF
			    SELECT a.orgkey, SUBSTR (a.NAME, 1, 40), SUBSTR (a.NAME, 1, 15),
				   DECODE(p.PHONEEMAILTYPE, 'COMMPH1',NVL (TRIM (SUBSTR (LPAD (p.phoneno, 15), 6)), '0')),
				   DECODE(p.PHONEEMAILTYPE, 'COMMPH2', TRIM (SUBSTR (LPAD (p.phoneno, 15), 6))),
				   DECODE(p.PHONEEMAILTYPE, 'HOMEPH1', TRIM (SUBSTR (LPAD (p.phoneno, 15), 6))),
				   DECODE(p.PHONEEMAILTYPE, 'HOMEPH2', TRIM (SUBSTR (LPAD (p.phoneno, 15), 6))),
				   DECODE(p.PHONEEMAILTYPE, 'WORKPH1', TRIM (SUBSTR (LPAD (p.phoneno, 15), 6))),
				   DECODE(p.PHONEEMAILTYPE, 'WORKPH2', TRIM (SUBSTR (LPAD (p.phoneno, 15), 6))), 
				   d.pagerno, a.fax,
				   a.fax_home, 
				   DECODE(p.PHONEEMAILTYPE, 'HOMETELEX', TRIM (SUBSTR (LPAD (p.phoneno, 15), 6))),
				   DECODE(p.PHONEEMAILTYPE, 'COMMTELEX', TRIM (SUBSTR (LPAD (p.phoneno, 15), 6))),
				   DECODE(p.PHONEEMAILTYPE, 'WORKTELEX', TRIM (SUBSTR (LPAD (p.phoneno, 15), 6))),
				   DECODE(ad.ADDRESSCATEGORY,'HOME',ad.address_line1) || ' ' || DECODE(ad.ADDRESSCATEGORY,'HOME',ad.address_line2),
				   DECODE(ad.ADDRESSCATEGORY,'MAILING',ad.address_line1) || ' ' || DECODE(ad.ADDRESSCATEGORY,'MAILING',ad.address_line2),
				   DECODE(ad.ADDRESSCATEGORY,'WORK',ad.address_line1) || ' ' || DECODE(ad.ADDRESSCATEGORY,'WORK',ad.address_line2),
				   NVL (a.relationshipopeningdate, '01-01-1900'), 
				   DECODE(ad.ADDRESSCATEGORY,'HOME',ad.city),
				   DECODE(ad.ADDRESSCATEGORY,'MAILING',ad.city),
				   DECODE(ad.ADDRESSCATEGORY,'WORK',ad.city),
				   DECODE(ad.ADDRESSCATEGORY,'HOME',ad.country),
				   DECODE(ad.ADDRESSCATEGORY,'MAILING',ad.country),
				   DECODE(ad.ADDRESSCATEGORY,'WORK',ad.country),
				   DECODE(ad.ADDRESSCATEGORY,'HOME',ad.zip),
				   DECODE(ad.ADDRESSCATEGORY,'MAILING',ad.zip),
				   DECODE(ad.ADDRESSCATEGORY,'WORK',ad.zip),
				   DECODE(ad.ADDRESSCATEGORY,'HOME',ad.state),
				   DECODE(ad.ADDRESSCATEGORY,'MAILING',ad.state),
				   DECODE(ad.ADDRESSCATEGORY,'WORK',ad.state),
				   a.constitution_ref_code,
				   a.cust_dob, d.marital_status, a.salutation_code,
				   d.annual_salary_income, a.gender, p.email, a.short_name,
				   a.cust_type_code, m.strtext2_code
			     INTO cimnumb, busname,
				   frstname,
				   cphone1,
				   cphone2,
				   pphone1,
				   pphone2,
				   ephone1,
				   ephone2,
				   pager,
				   cfax,
				   pfax,
				   --efax,
				   ptelex,
				   ctelex,
				   etelex,
				   paddr,
				   caddr,
				   eaddr, begdate, pcity, ccity,
				   ecity, pcountry, ccountry, ecountry, ppin, cpin,
				   epin, pstate, cstate, estate, 
				   const, dob, 
				   marital, prefix, salary, sex,
				   email,
				   shortname,
				   typ,
				   occucatg
			     FROM crmuser.accounts a, crmuser.phoneemail p , CRMUSER.demographic d , CRMUSER.ADDRESS ad , CRMUSER.MISCELLANEOUSINFO m
			     WHERE a.orgkey = p.orgid
			     AND a.orgkey = d.orgkey
			     AND a.orgkey = ad.orgkey
			     AND a.orgkey = m.orgkey
			     AND a.corp_id = tmpcustid
			     --AND lchg_time >= TO_DATE (inpdate, 'DD-MM-YYYY HH24:MI:SS')
			     AND a.entity_cre_flag = 'Y'
			     AND a.bank_id = l_bank_id
			     AND p.bank_id = l_bank_id
			     AND d.bank_id = l_bank_id
			     AND m.bank_id = l_bank_id
			     AND ad.bank_id = l_bank_id;
			     EXCEPTION
				WHEN OTHERS THEN NULL;
                
			--}
			END;
	    --}
            end if;            
            
           
            if (cimnumb is NOT NULL) then
            --{
                seqnum1 := 1;
        
                begin
                --{
                    select    to_char(begdate,'mm-dd-yyyy'),to_char(dob,'mm-dd-yyyy')
                    into    begChar,dobChar
                    from    DUAL;
                exception
                    WHEN OTHERS THEN NULL;
                --}
                end;

                while seqnum1 <= 13 
                loop
                --{
                    if (seqnum1 = 1) then
                        det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||cphone1||'~'||'P'||'~'||seqnum1;
                        UTL_FILE.PUT_LINE(phone,det_line1);
                    elsif (seqnum1 = 2 and cphone2 is NOT NULL) then
                        det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||cphone2||'~'||'P'||'~'||seqnum1;
                        UTL_FILE.PUT_LINE(phone,det_line1);
                    elsif (seqnum1 = 3 and pphone1 is NOT NULL) then
                        det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||pphone1||'~'||'O'||'~'||seqnum1;
                        UTL_FILE.PUT_LINE(phone,det_line1);
                    elsif (seqnum1 = 4 and pphone2 is NOT NULL) then
                        det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||pphone2||'~'||'O'||'~'||seqnum1;
                        UTL_FILE.PUT_LINE(phone,det_line1);
                    elsif (seqnum1 = 5 and ephone1 is NOT NULL) then
                        det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||ephone1||'~'||'B'||'~'||seqnum1;
                        UTL_FILE.PUT_LINE(phone,det_line1);
                    elsif (seqnum1 = 6 and ephone2 is NOT NULL) then
                        det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||ephone2||'~'||'B'||'~'||seqnum1;
                        UTL_FILE.PUT_LINE(phone,det_line1);
                    elsif (seqnum1 = 7 and pager is NOT NULL) then
                        det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||pager||'~'||'M'||'~'||seqnum1;
                        UTL_FILE.PUT_LINE(phone,det_line1);
                    elsif (seqnum1 = 8  and cfax is NOT NULL) then
                        det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||cfax||'~'||'F'||'~'||seqnum1;   
                        UTL_FILE.PUT_LINE(phone,det_line1);
                    elsif (seqnum1 = 9  and pfax is NOT NULL) then
                        det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||pfax||'~'||'F'||'~'||seqnum1;   
                        UTL_FILE.PUT_LINE(phone,det_line1);
                    elsif (seqnum1 = 10  and efax is NOT NULL) then
                        det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||efax||'~'||'F'||'~'||seqnum1;   
                        UTL_FILE.PUT_LINE(phone,det_line1);
                    elsif (seqnum1 = 11  and ctelex is NOT NULL) then
                        det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||ctelex||'~'||'O'||'~'||seqnum1;   
                        UTL_FILE.PUT_LINE(phone,det_line1);
                    elsif (seqnum1 = 12  and ptelex is NOT NULL) then
                        det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||ptelex||'~'||'O'||'~'||seqnum1;   
                        UTL_FILE.PUT_LINE(phone,det_line1);
                    elsif (seqnum1 = 13  and etelex is NOT NULL) then
                        det_line1 := '~'||cimnumb||'~~~'||cphone1||'~'||etelex||'~'||'O'||'~'||seqnum1;   
                        UTL_FILE.PUT_LINE(phone,det_line1);
                    end if;

                    seqnum1 := seqnum1 + 1;
                --}
                end loop;

                seqnum2 := 1;

                while seqnum2 <= 3 
                loop
                --{
                    city := NULL;
                    if (seqnum2 = 1 and (trim(paddr) is NOT NULL)) then
                        addr1 := substr(paddr,1,30);
                        addr2 := substr(paddr,31,30);
                        addr3 := substr(paddr,61,30); 

                        BEGIN
                        --{
                            SELECT     substr(ref_desc,1,26)
                            INTO    city
                            FROM     RCT
                            WHERE     ref_rec_type ='01'
                            AND        ref_code = pcity
                            AND        del_flg != 'Y'
			    AND        bank_id = l_bank_id;

                        EXCEPTION
                            WHEN OTHERS THEN NULL;
                        --}
                        END;

                        BEGIN
                        --{
                            SELECT     substr(ref_desc,1,26)
                            INTO    country
                            FROM     RCT
                            WHERE     ref_rec_type ='03'
                            AND        ref_code = pcountry
                            AND        del_flg != 'Y'
			    AND        bank_id = l_bank_id;

                        EXCEPTION
                            WHEN OTHERS THEN NULL;
                        --}
                        END;
                        
                        if(country = 'INDIA') then
                            country_flg := 0;
                        else
                            country_flg := 1;
                        end if;
                        det_line2 := addr1||'~'||addr2||'~'||addr3||'~'||cimnumb||'~'||begChar||'~'||city||'~'||country||'~'||country_flg||'~~~'||ppin||'~'||pstate||'~~'||'0'||'~'||cimnumb||'~1~';
                        UTL_FILE.PUT_LINE(address,det_line2);
                        paddr := NULL;
                    elsif (seqnum2 = 2 and (trim(caddr) is NOT NULL))then
                        addr1 := substr(caddr,1,30);
                        addr2 := substr(caddr,31,30);
                        addr3 := substr(caddr,61,30); 

                        BEGIN
                        --{
                            SELECT     substr(ref_desc,1,26)
                            INTO    city
                            FROM     RCT
                            WHERE     ref_rec_type ='01'
                            AND        ref_code = ccity
                            AND        del_flg != 'Y'
			    AND        bank_id = l_bank_id;

                        EXCEPTION
                            WHEN OTHERS THEN NULL;
                        --}
                        END;

                        BEGIN
                        --{
                            SELECT     substr(ref_desc,1,26)
                            INTO    country
                            FROM     RCT
                            WHERE     ref_rec_type ='03'
                            AND        ref_code = ccountry
                            AND        del_flg != 'Y'
			    AND        bank_id = l_bank_id;

                        EXCEPTION
                            WHEN OTHERS THEN NULL;
                        --}
                        END;
                        
                        if(country = 'INDIA') then
                            country_flg := 0;
                        else
                            country_flg := 1;
                        end if;

                        det_line2 := addr1||'~'||addr2||'~'||addr3||'~'||cimnumb||'~'||begChar||'~'||city||'~'||country||'~'||country_flg||'~~~'||cpin||'~'||cstate||'~~'||'0'||'~'||cimnumb||'~2~';
                        UTL_FILE.PUT_LINE(address,det_line2);
                        caddr := NULL;  
                    elsif (seqnum2 = 3 and (trim(eaddr) is NOT NULL)) then
                        addr1 := substr(eaddr,1,30);
                        addr2 := substr(eaddr,31,30);
                        addr3 := substr(eaddr,61,30); 

                        BEGIN
                        --{
                            SELECT     substr(ref_desc,1,26)
                            INTO    city
                            FROM     RCT
                            WHERE     ref_rec_type ='01'
                            AND        ref_code = ecity
                            AND        del_flg != 'Y'
			    AND        bank_id = l_bank_id;

                        EXCEPTION
                            WHEN OTHERS THEN NULL;
                        --}
                        END;

                        BEGIN
                        --{
                            SELECT     substr(ref_desc,1,26)
                            INTO    country
                            FROM     RCT
                            WHERE     ref_rec_type ='03'
                            AND        ref_code = ecountry
                            AND        del_flg != 'Y'
			    AND        bank_id = l_bank_id;

                        EXCEPTION
                            WHEN OTHERS THEN NULL;
                        --}
                        END;
                        
                        if(country = 'INDIA') then
                            country_flg := 0;
                        else
                            country_flg := 1;
                        end if;

                        det_line2 := addr1||'~'||addr2||'~'||addr3||'~'||cimnumb||'~'||begChar||'~'||city||'~'||country||'~'||country_flg||'~~~'||epin||'~'||estate||'~~'||'0'||'~'||cimnumb||'~3~';
                        UTL_FILE.PUT_LINE(address,det_line2);
                        eaddr := NULL; 
                    end if;

                    seqnum2 := seqnum2 + 1;
                --}
                end loop;

                det_line3 := abbr||'~'||acctrel||'~'||descript||'~~';
                UTL_FILE.PUT_LINE(relation,det_line3);

--***        Modified to actual typ values at client site
                if (typ = '40' or typ = '41' or typ = '42') then
                    bOrp := 'P';
                else
                    bOrp := 'B';
                end if;

                det_line5 := solId||'~'||cimnumb||'~0~'||email||'~~~~'||begChar||'~'||shortname||'~'||bOrp;
                UTL_FILE.PUT_LINE(portrait,det_line5);

                begin
                --{
                    select    employed_company, mothers_maiden_name,
                            employed_years_of_service
                    into    employer,motherMaiden,yearsEmp
                    from    ICICI_CIFT
                    where   cif_id = lpad(tmpCustId,9)
		    AND     bank_id = l_bank_id;
                exception
                    when others then NULL;
                --}
                end;

--***        Occup changed based on values in icici_cift
                if (occuCatg = '003') then
                    occup := 2;
                elsif (occuCatg = '002') then
                    occup := 3;
                elsif (occuCatg = '500') then
                    occup := 9;
                elsif (occuCatg = 'DOCA') then
                    occup := 11;
                elsif (occuCatg = 'DOCB') then
                    occup := 11;
                elsif (occuCatg = 'DOCC') then
                    occup := 11;
                elsif (occuCatg = 'DOCD') then
                    occup := 11;
                elsif (occuCatg = '363') then
                    occup := 12;
                elsif (occuCatg = '004') then
                    occup := 14;
                elsif (occuCatg = '898') then
                    occup := 15;
                elsif (occuCatg = '008') then
                    occup := 22;
                elsif (occuCatg = '940') then
                    occup := 23;
                elsif (occuCatg = '007') then
                    occup := 26;
                elsif (occuCatg = '006') then
                    occup := 28;
                elsif (occuCatg = '963') then
                    occup := 32;
                else
                    occup := 0;
                end if;

                if (salary >= 10000 and salary <= 25000) then
                    sal := 1;
                elsif (salary >= 25001 and salary <= 50000) then 
                    sal := 2;
                elsif (salary >= 50001 and salary <= 100000) then 
                    sal := 3;
                elsif (salary >= 100001 and salary <= 500000) then 
                    sal := 4;
                elsif (salary >= 500001 and salary <= 1000000) then 
                    sal := 5;
                elsif (salary >= 1000001 and salary <= 2500000) then 
                    sal := 6;
                else
                    sal := 7;
                end if;

                if (marital = 'MARID') then
                    maritalCd := 'M';
                elsif (marital = 'SINGL') then
                    maritalCd := 'S';
                else
                    maritalCd := NULL;
                end if;
                
                if( bOrp = 'P') then
                    det_line4 := cimnumb||'~'||dobChar||'~~~~'||employer||'~~'||frstname||'~-~'||maritalCd||'~~'||motherMaiden||'~'||occup||'~'||prefix||'~'||sal||'~'||sex||'~~~'||yearsEmp;
                    UTL_FILE.PUT_LINE(personal,det_line4);
                end if;

--***        Modified to actual bustype value at client site
                if (typ = 'ASSON') then
                    bustype := 1;
                elsif (typ = '33') then
                    bustype := 3;
--***            elsif (typ = '40') then
--***                bustype := 6;
                elsif (typ = '63' or typ = '70' or typ = 'TRUST') then
                    bustype := 7;
                elsif (typ = '15') then
                    bustype := 10;
                elsif (typ = '32') then
                    bustype := 14;
                elsif (typ = '31') then
                    bustype := 15;
                elsif (typ = '20') then
                    bustype := 16;
                else
                    bustype := 99;
                end if;

                if( bOrp = 'B') then
                    det_line6 := busname||'~'||bustype||'~'||cimnumb||'~0';
                    UTL_FILE.PUT_LINE(business,det_line6);
                end if;

                det_line7 := 'LN~'||tmpFora||'~'||acctrel||'~999~'||cimnumb||'~'||cimnumb||'~0';
                UTL_FILE.PUT_LINE(portfolio,det_line7);
            --}
            end if;

            if(jointNum = 0)then
                EXIT;
            end if;
        --}
        END LOOP;
    --}
    END LOOP;

    UTL_FILE.FCLOSE(phone);
    UTL_FILE.FCLOSE(address);
    UTL_FILE.FCLOSE(relation);
    UTL_FILE.FCLOSE(personal);
    UTL_FILE.FCLOSE(portrait);
    UTL_FILE.FCLOSE(business);
    UTL_FILE.FCLOSE(portfolio);
    CLOSE RSP_CURSOR;
--}
END;
/
exit
--spool off
