CREATE OR REPLACE PACKAGE TamIntRate AS 
-------------------------------------------------------- 
-- Functions are defined here 
-------------------------------------------------------- 
 
FUNCTION TamIntversion(Iacid VARCHAR2,inttblcode VARCHAR2) RETURN VARCHAR2; 
 
PROCEDURE TAMINTTBLCODE(Iacid IN varchar2, 
                        OINT_TBL_CODE OUT varchar2, 
                        OcustCrPrefPcnt OUT number, 
                        OcustDrPrefPcnt OUT number, 
                        OidCrPrefPcnt OUT number, 
                        OidDrPrefPcnt OUT number); 
 
FUNCTION getTamIntRate(Iacid varchar2)  
RETURN NUMBER ; 
 
END TamIntRate; 
/ 
 
CREATE OR REPLACE  PACKAGE BODY TamIntRate AS 
 
PROCEDURE TamIntTblCode(Iacid IN varchar2,OINT_TBL_CODE OUT varchar2, 
OcustCrPrefPcnt OUT number,OcustDrPrefPcnt OUT number, 
OidCrPrefPcnt OUT number,OidDrPrefPcnt OUT number) 
is 
l_INT_TBL_CODE itc.INT_TBL_CODE%type; 
l_OPEN_EFFECTIVE_DATE   date; 
 
l_tamflag char(1):='Y'; 
begin 
  begin 
  select OPEN_EFFECTIVE_DATE into l_OPEN_EFFECTIVE_DATE from tam 
  where acid=Iacid; 
  exception when 
  no_data_found then 
  l_tamflag:='N'; 
  end; 
  if (l_tamflag='Y') then 
  begin 
  select INT_TBL_CODE,CUST_CR_PREF_PCNT,CUST_DR_PREF_PCNT, 
  ID_CR_PREF_PCNT ,ID_DR_PREF_PCNT 
 
  into OINT_TBL_CODE,OcustCrPrefPcnt,OcustDrPrefPcnt, 
  OidCrPrefPcnt,OidDrPrefPcnt from itc a where 
  a.ENTITY_ID=Iacid and a.ENTITY_TYPE='ACCNT' and 
  a.DEL_FLG<>'Y' and a.ENTITY_CRE_FLG='Y' 
  and a.start_date <=l_OPEN_EFFECTIVE_DATE and 
  a.end_date>=l_OPEN_EFFECTIVE_DATE and a.lchg_time = 
  (select max(lchg_time) from itc b where 
  b.entity_id=Iacid and b.ENTITY_TYPE='ACCNT' and 
  b.DEL_FLG<>'Y' and b.ENTITY_CRE_FLG='Y' and 
  b.start_date <=l_OPEN_EFFECTIVE_DATE 
  and b.end_date>=l_OPEN_EFFECTIVE_DATE); 
 
  exception  
  when no_data_found then 
  OINT_TBL_CODE:='*****'; 
  OcustCrPrefPcnt:=0; 
  OcustDrPrefPcnt:=0; 
  OidCrPrefPcnt:=0; 
  OidDrPrefPcnt:=0; 
  end; 
  else 
  l_tamflag:='Y'; 
  OINT_TBL_CODE:='*****'; 
  OcustCrPrefPcnt:=0; 
  OcustDrPrefPcnt:=0; 
  OidCrPrefPcnt:=0; 
 
  OidDrPrefPcnt:=0; 
  end if; 
 
 
end TamIntTblCode; 
 
FUNCTION TamIntVersion(Iacid varchar2,inttblcode varchar2) 
return varchar2 is 
 
l_INT_VERSION icv.INT_VERSION%type; 
l_crncy_code gam.ACCT_CRNCY_CODE%type; 
l_inttblcode itc.INT_TBL_CODE%type; 
l_OPEN_EFFECTIVE_DATE   date; 
begin 
 
  if (inttblcode <> '*****') then 
  select ACCT_CRNCY_CODE into l_crncy_code from gam where acid= Iacid; 
  select OPEN_EFFECTIVE_DATE into l_OPEN_EFFECTIVE_DATE from tam 
  where acid=Iacid; 
  l_inttblcode:=inttblcode; 
		BEGIN 
  select INT_VERSION into l_INT_VERSION 
  from ( select INT_VERSION from icv a  where INT_TBL_CODE=l_inttblcode 
  and a.start_date <=l_OPEN_EFFECTIVE_DATE and 
  a.end_date>=l_OPEN_EFFECTIVE_DATE and 
  a.DEL_FLG<>'Y' and a.ENTITY_CRE_FLG='Y' and 
  a.crncy_code=l_crncy_code 
  and a.base_ind<>'Y' 
 
  order by lchg_time desc) 
  where rownum=1; 
		exception when no_data_found then 
		l_INT_VERSION:='*****'; 
		END; 
--   return l_INT_VERSION; 
  else 
  l_INT_VERSION:='*****'; 
  end if; 
  return l_INT_VERSION; 
end TAMINTVERSION; 
 
FUNCTION getTamIntRate(Iacid varchar2) 
return number is 
l_DEPOSIT_AMOUNT tam.DEPOSIT_AMOUNT%type; 
 
l_crncy_code gam.ACCT_CRNCY_CODE%type; 
l_maturity_date date; 
l_nrml_int_pcnt tvs.nrml_int_pcnt%type; 
l_inttblcode tvs.int_tbl_code%type; 
l_INT_VERSION icv.INT_VERSION%type; 
l_OPEN_EFFECTIVE_DATE   date; 
l_custCrPrefPcnt number; 
l_custDrPrefPcnt number; 
l_idCrPrefPcnt  number; 
l_idDrPrefPcnt number; 
 
begin 
  TamIntTblCode(Iacid,l_inttblcode,l_custCrPrefPcnt, 
  l_custDrPrefPcnt,l_idCrPrefPcnt,l_idDrPrefPcnt); 
          --l_tbl_code:=l_inttblcode; 
          --dbms_output.put_line(Iacid||'|'||l_inttblcode||'|'||l_custCrPrefPcnt||'|'|| 
          --l_custDrPrefPcnt||'|'||l_idCrPrefPcnt||'|'||l_idDrPrefPcnt); 
 
  if (l_inttblcode<>'*****') then 
  l_INT_VERSION:=TamIntVersion(Iacid,l_inttblcode); 
          --dbms_output.put_line(l_INT_VERSION); 
  select DEPOSIT_AMOUNT,add_months(OPEN_EFFECTIVE_DATE,DEPOSIT_PERIOD_MTHS) 
          +DEPOSIT_PERIOD_days,OPEN_EFFECTIVE_DATE 
 
 
  into l_DEPOSIT_AMOUNT,l_maturity_date ,l_OPEN_EFFECTIVE_DATE 
  from tam 
  where acid=Iacid; 
  select ACCT_CRNCY_CODE into l_crncy_code from gam where acid= Iacid; 
  begin 
  select nrml_int_pcnt into l_nrml_int_pcnt from tvs 
  where int_tbl_code=l_inttblcode and 
  int_tbl_ver_num=l_INT_VERSION and 
  int_slab_dr_cr_flg='C' and 
  begin_slab_amount<=l_DEPOSIT_AMOUNT and 
  l_DEPOSIT_AMOUNT<=max_slab_amount and 
  add_months(l_OPEN_EFFECTIVE_DATE,max_contracted_mths + 
  DECODE(max_contracted_days, 999, 1, 0))+ 
 
  DECODE(max_contracted_days, 999, -1,max_contracted_days) 
  >=l_maturity_date and 
  add_months(l_OPEN_EFFECTIVE_DATE,max_period_run_mths + 
  DECODE(max_period_run_days, 999, 1, 0)) + 
  DECODE(max_period_run_days, 999, -1, max_period_run_days) 
  >=l_maturity_date and 
  del_flg <> 'Y' and 
  crncy_code=l_crncy_code and 
  entity_cre_flg='Y' and rownum=1; 
  exception when no_data_found then 
  l_nrml_int_pcnt:=0; 
  end; 
 
    l_nrml_int_pcnt:=l_nrml_int_pcnt+ 
  nvl(l_custCrPrefPcnt,0)+nvl(l_idCrPrefPcnt,0); 
--  -nvl(l_custDrPrefPcnt,0)-nvl(l_idDrPrefPcnt,0); 
    if (l_nrml_int_pcnt is null) then 
    l_nrml_int_pcnt:=0; 
    end if; 
  return l_nrml_int_pcnt; 
  else 
  return 0; 
  end if; 
 
end getTamIntRate; 
 
END TamIntRate; 
/

GRANT EXECUTE ON TamIntRate TO PUBLIC,TBAGEN, TBAUTIL,TBAADM,SYSTEM; 
CREATE SYNONYM TBAADM.TAMINTRATE FOR TAMINTRATE;
CREATE SYNONYM TBAGEN.TAMINTRATE FOR TAMINTRATE;
CREATE SYNONYM TBAUTIL.TAMINTRATE FOR TAMINTRATE;
