-- This sql changes the file name that have been set up in HPTTM menu from MRT based to script based
-- Event type considered are BGADD, BGMOD, BGINV, DCADV, DCAMD and DCISS
----------------------------------------------------------------------------------------------------

spool BG_DC_CHARGE_ALTER
set feedback on
set echo on

select ptt.event_id || '|' || ptt.event_type || '|' || ptt.AMT_DERV_SRL_NUM || '|' || ADM.FILE_NAME || '|' || ADM.AMT_IND
FROM tbaadm.PTT, tbaadm.ADM
where AMT_DRV_SRL_NUM in(select AMT_DERV_SRL_NUM 
		from tbaadm.ptt where EVENT_TYPE
		in('DCISS','DCAMD','BGADD','BGINV','BGMOD','DCADV')) 
and AMT_IND = 'M' 
and ADM.bank_id = '&bank_id' 
and ADM.del_flg !='Y' 
and ADM.ENTITY_CRE_FLG = 'Y'
order by ptt.event_type, ptt.event_id;


update tbaadm.adm set FILE_NAME = (replace(file_name,'.','_') || '.scr'),
AMT_IND = 'S'  
where AMT_DRV_SRL_NUM in(select AMT_DERV_SRL_NUM 
		from tbaadm.ptt where EVENT_TYPE
		in('DCISS','DCAMD','BGADD','BGINV','BGMOD','DCADV')) 
and AMT_IND = 'M' 
and 
bank_id = '&bank_id' 
and del_flg !='Y' 
and ENTITY_CRE_FLG = 'Y';


select ptt.event_id || '|' || ptt.event_type || '|' || ptt.AMT_DERV_SRL_NUM || '|' || ADM.FILE_NAME || '|' || ADM.AMT_IND
FROM tbaadm.PTT, tbaadm.ADM
where AMT_DRV_SRL_NUM in(select AMT_DERV_SRL_NUM 
		from tbaadm.ptt where EVENT_TYPE
		in('DCISS','DCAMD','BGADD','BGINV','BGMOD','DCADV')) 
and AMT_IND = 'S' 
and ADM.bank_id = '&bank_id' 
and ADM.del_flg !='Y' 
and ADM.ENTITY_CRE_FLG = 'Y'
order by ptt.event_type, ptt.event_id;


spool off