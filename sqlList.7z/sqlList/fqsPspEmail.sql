#----------------------------------------------------------------------------------------
#--    Name                : fqsPspEmail.sql
#--    Description         : sql file for selecting statement type and Emails from ICICI_STMT_FRE table
#--    Author              : Amal
#--    Date                : 19-12-2012
#--    Called Menu Option  : Statement Generation
#--    Modification History:
#--
#--     Sl. No       Date           Author              Description
#--    --------     ------      --------------        -------------------------------
#--    1            19-12-2012  Amal                  sql file for selecting statement type and Emails from ICICI_STMT_FRE table
#-----------------------------------------------------------------------------------------
set serveroutput on size 1000000
set feedback off
set verify off
set term off
set pages 0
set trims on
set linesize 400
set head off
spool &1..rpt
	select TYPE_STMT||'|'||EMAIL1||','||EMAIL2||','||EMAIL3||','||EMAIL4||','||EMAIL5 from 
	ICICI_STMT_FRE where FORACID = '&1' and BANK_ID='&2';
spool off;
