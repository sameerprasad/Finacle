set lines 142
set pages 60
set verify off
set feedback off
set termout off
set trims on
spool sxrreport

select  sol_id , FD_REF_NUM as FB_REF_NUM, sxr_no from custom.fxb_upl_custom where FD_REF_NUM = '&1' and BILL_DATE = to_date('&2','dd-mm-yyyy') and bank_id='&3'
/
spool off
set verify on
set feedback on
set termout on

















