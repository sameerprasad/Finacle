--#########################################################################
--#       File Name       : lcovdrpt.sql
--#       Author          : Priyanka
--#       Report          : LOCKER CURRENTLY IN OVERDUE REPORT
--#       Date            : 05-Oct-2012
--#       Module          : LOCKER
--#       Called Menu     : LCRPT
--#       Called Scripts  : lcovdrpt.com
--#Modification History   :
--#
--# <Serial No.>       <Date>           <Author Name>              <Description>
--#      1           12-Mar-2013      Kumar Gandharv           Modified as per CR
--#########################################################################
SET SERVEROUTPUT ON SIZE 1000000;
SET VERIFY OFF
SET TERMOUT OFF
SET TRIMSPOOL ON
SET ECHO OFF
SET FEEDBACK OFF
SET EMBEDDED ON
SET LINES 400
SET HEAD OFF
SET PAGES 0
clear columns
clear breaks
clear computes
set serveroutput on

spool lcovdrpt.lst 

declare

v_lcknum        clmt.locker_num%type := '&1';
v_solid            clmt.sol_id%type := '&2';
v_date            varchar2(25) := '&3';
v_bankid                clmt.bank_id%type := '&4';
v_sol_id        clmt.sol_id%type;
v_due_date        clmt.due_date%type;
v_cif_id        clmt.cif_id%type;
v_rack_id        wlckm.rack_id%type;
v_locker_type        wlckm.locker_type%type;
v_locker_num        clmt.locker_num%type;
v_rent_payable_amount    lcpp.rent_payable_amount%type;
v_renewal_date        clmt.renewal_date%type;
v_prv_renewal_date    clmt.renewal_date%type;
v_cust_name        cmg.cust_name%type;
v_overdue_period    number;
v_nxt_due_date        date;
v_oper_acnt        VARCHAR2(16);
v_ACCT_CLS_FLG        char(1); 
v_balance         number(20,4);
v_FREZ_CODE        CHAR(1); 
v_debit_failed_reason    VARCHAR2(100);

cursor C1 (v_lcknum lcpd.locker_number%type,v_solid lcpd.sol_id%type,v_date varchar2,v_bankid varchar2)  is
SELECT  CLMT.SOL_ID,
        CLMT.DUE_DATE,
        CLMT.CIF_ID,
        WLCKM.RACK_ID,
        WLCKM.LOCKER_TYPE,
        CLMT.LOCKER_NUM,
        (LCPP.RENT_PAYABLE_AMOUNT - LCPP.RENT_PAID_AMOUNT),
        CLMT.RENEWAL_DATE,
    floor(ABS((due_date - decode(renewal_date,'',(due_date+1),renewal_date))/365)),
    OPER_ACNT
FROM    CLMT,WLCKM,LCPP
WHERE   WLCKM.LOCKER_NUM = CLMT.LOCKER_NUM
AND     WLCKM.LOCKER_NUM = LCPP.LOCKER_NUMBER
AND     CLMT.CIF_ID = LCPP.CIF_ID
AND     CLMT.sol_id = LCPP.SOL_ID
AND     WLCKM.sol_id = LCPP.sol_id
AND     CLMT.sol_id = WLCKM.sol_id
AND     CLMT.LOCKER_NUM like nvl2(v_lcknum,'%','%')
AND     CLMT.SOL_ID = v_solid
AND     CLMT.DUE_DATE <= to_date(v_date,'dd-mm-yyyy')
AND     floor(ABS((due_date - decode(renewal_date,'',(due_date+1),renewal_date))/365)) > 0
and     (LCPP.RENT_PAYABLE_AMOUNT - LCPP.RENT_PAID_AMOUNT) > 0
AND     CLMT.DEL_FLG != 'Y'
AND     LCPP.DEL_FLG != 'Y'
AND     WLCKM.DEL_FLG != 'Y'
UNION
SELECT  CLMT.SOL_ID,
        CLMT.DUE_DATE,
        CLMT.CIF_ID,
        WLCKM.RACK_ID,
        WLCKM.LOCKER_TYPE,
        CLMT.LOCKER_NUM,
        (LCPP.RENT_PAYABLE_AMOUNT - LCPP.RENT_PAID_AMOUNT),
    CLMT.renewal_date,
    floor(ABS((due_date - decode(renewal_date,'',(due_date+1),renewal_date))/365)),
    OPER_ACNT
FROM    CLMT,WLCKM,LCPP
WHERE   WLCKM.LOCKER_NUM = CLMT.LOCKER_NUM
AND     WLCKM.LOCKER_NUM = LCPP.LOCKER_NUMBER
AND     CLMT.CIF_ID = LCPP.CIF_ID
AND     CLMT.sol_id = LCPP.SOL_ID
AND     WLCKM.sol_id = LCPP.sol_id
AND     CLMT.sol_id = WLCKM.sol_id
AND     CLMT.LOCKER_NUM like nvl2(v_lcknum,'%','%')
AND     CLMT.SOL_ID = v_solid
AND    CLMT.BANK_ID = WLCKM.BANK_ID
AND    LCPP.BANK_ID = CLMT.BANK_ID
AND    CLMT.BANK_ID = v_bankid
AND     CLMT.ISSUE_DATE <= to_date(v_date,'dd-mm-yyyy')
AND     floor(ABS((due_date - decode(renewal_date,'',(due_date+1),renewal_date))/365)) = 0
and     (LCPP.RENT_PAYABLE_AMOUNT - LCPP.RENT_PAID_AMOUNT) > 0
AND     CLMT.DEL_FLG != 'Y'
AND     LCPP.DEL_FLG != 'Y'
AND     WLCKM.DEL_FLG != 'Y'
ORDER BY 2,6;

BEGIN
    
       --dbms_output.put_line(v_lcknum);
    OPEN C1(v_lcknum,v_solid,v_date,v_bankid);
    loop
    --{
        if (C1%ISOPEN) then
        --{
        FETCH C1
        INTO
        v_sol_id,
                        v_due_date,
                        v_CIF_ID,
                        v_rack_id,
                        v_locker_type,
                        v_locker_num,
                        v_rent_payable_amount,
                        v_renewal_date,
            v_overdue_period,
            v_oper_acnt;
    
            IF (C1%NOTFOUND) THEN
                CLOSE C1;
                EXIT;
            END IF;

            begin
                                select cust_name into v_cust_name from cmg where CIF_ID = v_CIF_ID;
            Exception when no_data_found then
                                v_cust_name:=null;
                        end;
            IF (v_overdue_period > 0) THEN
            --{
                    begin
                        select add_months(to_date(v_renewal_date,'dd-mm-yyyy'),-(12 * v_overdue_period))
                        into v_prv_renewal_date 
                        from dual;
                    Exception when no_data_found then
                        v_prv_renewal_date:=null;
                    end;
            --}
            END IF;
            IF (v_overdue_period = 0) THEN
            --{
                    begin
                        select add_months(to_date(v_renewal_date,'dd-mm-yyyy'),-12)
                        into v_prv_renewal_date 
                        from dual;
                    Exception when no_data_found then
                        v_prv_renewal_date:=null;
                    end;
            --}
            END IF;
            IF (v_overdue_period > 0) THEN
            --{
                begin
                    select (add_months(to_date(v_prv_renewal_date,'dd-mm-yyyy'),+(12 * v_overdue_period)) - 1)
                    into v_nxt_due_date 
                    from dual;
                Exception when no_data_found then
                    v_nxt_due_date:=null;
                end;
            --}
            END IF;        
            IF (v_overdue_period = 0) THEN
            --{
                    begin
                        v_nxt_due_date := v_due_date;
                    end;
            --}
            END IF;
            --------------------Check The Account details from gam----------------
            IF (v_oper_acnt IS NOT NULL) THEN
            --{
                BEGIN
                --{
                    SELECT ACCT_CLS_FLG,(CLR_BAL_AMT + UN_CLR_BAL_AMT)balance,FREZ_CODE
                    INTO    v_ACCT_CLS_FLG,v_balance,v_FREZ_CODE
                    FROM GAM
                    WHERE foracid = v_oper_acnt;
                EXCEPTION WHEN NO_DATA_FOUND THEN
                    v_ACCT_CLS_FLG := null;
                    v_balance := null;
                    v_FREZ_CODE := null;
                --}
                END;
                IF (v_ACCT_CLS_FLG = 'Y') THEN
                --{
                    v_debit_failed_reason := 'ACCOUNT IS CLOSED';
                --}
                ELSIF(v_balance < v_rent_payable_amount) THEN
                --{        
                    v_debit_failed_reason := 'INSUFFICIENT BALANCE';
                --}
                ELSIF(v_FREZ_CODE = 'D') THEN
                --{
                    v_debit_failed_reason := 'ACCOUNT DEBIT FROZEN';
                --}
                ELSE
                --{
                    v_debit_failed_reason := '';
                --}
                END IF;
            ELSE
                v_debit_failed_reason := 'NO OPERATIVE ACCOUNT';
            --}
            END IF;
        --}
        end if;

dbms_output.enable(buffer_size => NULL);
dbms_output.put_line(   v_sol_id                ||'|'||
                        v_date              ||'|'||
                        v_CIF_ID               ||'|'||
                        v_cust_name             ||'|'||
                        v_rack_id               ||'|'||
                        v_locker_type           ||'|'||
                        v_locker_num            ||'|'||
                        v_rent_payable_amount   ||'|'||
                        v_prv_renewal_date   ||'|'||
                        v_nxt_due_date        ||'|'||
            v_debit_failed_reason);

end loop;
    --}
end;
/
spool off

