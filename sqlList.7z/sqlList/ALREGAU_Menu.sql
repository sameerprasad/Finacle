set define off; 
variable mopNum varchar2(5); 
begin 
select nvl(to_char(max(to_number(mop_num))+1), '1') into :mopNum from tbaadm.mno where menu_id = 'FIMNU3'; 
exception when no_data_found then 
	:mopNum := 1; 
end; 
/ 
drop table tbaadm.tmp_mod 
/ 
create table tbaadm.tmp_mod as  
	(select * from tbaadm.mod  
	where mop_id = 'HACM' and bank_id ='ICICI01') 
/ 
update tbaadm.tmp_mod  
	set MOP_ID = 'ALREGAU', 
	MOP_TYPE = 'U', 
	EXE_NAME='https://$W/finbranch',  
	INPUT_FILENAME = 'Customize/Customize_ctrl.jsp?sessionid=$S', ADDITIONAL_PARAMS='&ALREGAU=$TALREGAU=$SALREGAU=$CALREGAU=$' 
/ 
commit 
/ 
delete from tbaadm.mod where MOP_ID='ALREGAU' 
/ 
insert into tbaadm.mod select * from tbaadm.tmp_mod 
/ 
commit 
/ 
drop table tbaadm.tmp_mod 
/ 
create table tbaadm.tmp_mod as  
	(select * from tbaadm.mod_txt  
	where MOP_ID = 'HACM' and bank_id ='ICICI01') 
/ 
update tbaadm.tmp_mod  
	set MOP_ID = 'ALREGAU' ,  
	USER_MOP_ID = 'ALREGAU',  
	MOP_TEXT = 'ALERT AUTHORIZATION' 
/ 
commit 
/ 
delete from tbaadm.mod_txt where MOP_ID='ALREGAU' 
/ 
insert into tbaadm.mod_txt select * from tbaadm.tmp_mod 
/ 
commit 
/ 
drop table tbaadm.tmp_mod 
/ 
delete from tbaadm.oat where MOP_ID='ALREGAU' 
/ 
insert into tbaadm.oat values('ALREGAU','GU','TBAADM',sysdate,'TBAADM',sysdate,1,'ICICI01') 
/ 
commit 
/ 
create table tbaadm.tmp_mod as 	 
	(select * from tbaadm.mno where MOP_ID = 'HACM' and bank_id ='ICICI01') 
/ 
update tbaadm.tmp_mod  
	set MOP_ID = 'ALREGAU', 
	MOP_NUM=:mopNum,  
	menu_id = 'FIMNU3' 
/ 
commit 
/ 
delete from tbaadm.mno where MOP_ID='ALREGAU' 
/ 
insert into tbaadm.mno select * from tbaadm.tmp_mod 
/ 
commit 
/ 


