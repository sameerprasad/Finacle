#=========================================================================================================
#       Script Name			:	getboddate.sql
#       Description                     :	creates lst file with the bod date
#       Author				: 	Anna Alexander
#       Date				:	31-Oct-2012			
#       Input Values			:   	-
#       Output Values			: 	.lst file
#       Called Scripts                  :   	-
#       Calling Scripts                 :   	-
#       Reference						:	-
#       Modification History
#       S.No            Date            	Author					Description
#       ----            ------				------          		-----------
#       1.00            31-Oct-2012			Anna Alexander			Changes made for 10X
#=========================================================================================================
set pagesize 0
set feedback off
set termout off
col a format A6
spool boddt.lst
select to_char(db_stat_date,'YYMMDD') a from gct;
exit;
