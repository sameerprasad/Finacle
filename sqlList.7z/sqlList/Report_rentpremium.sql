--------------------------------------------
--File Name   : Report_rentpremium.sql
--Description : Locker Rent Premium Report
--Author      : Priyanka
--Date        : 04-10-2012
------------------------------------------

set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_rentpremium.lst

DECLARE

lv_solid    gam.sol_id%type :='&1';
lv_date	    varchar2(30) :='&2';
lv_bankid   varchar2(30) :='&3';

CURSOR c1 IS
SELECT  
	WLPM.SOL_ID,
	WLCKM.RACK_ID,
	WLPM.LOCKER_TYPE,
	WLPM.LOCKER_NUM,
	WLPM.CIF_ID,
	substr(CMG.CUST_NAME,1,25) CUST_NAME,
	CLMT.RENT_AMT,
	WLPM.PREMIUM_METHOD,
	WLPM.PREMIUM_AMOUNT,
	WLPM.REASON,
	WLPM.REMARKS
FROM 
	CLMT,WLPM,WLCKM,CMG
WHERE 
	CLMT.LOCKER_NUM = WLPM.LOCKER_NUM
AND	CLMT.LOCKER_NUM = WLCKM.LOCKER_NUM
AND	WLPM.CIF_ID = CMG.CIF_ID
AND	WLPM.CIF_ID = CLMT.CIF_ID
AND	CLMT.SOL_ID = WLPM.SOL_ID
AND     CLMT.BANK_ID = WLPM.BANK_ID
AND     WLCKM.BANK_ID = CMG.BANK_ID
AND	CLMT.BANK_ID = CMG.BANK_ID
AND	CLMT.BANK_ID = lv_bankid
AND	WLPM.SOL_ID= lv_solid
AND	PREMIUM_AMOUNT IS NOT NULL
AND	to_date(lv_date,'dd-mm-yyyy') BETWEEN PERIOD_FROM AND PERIOD_TO
and	CLMT.DEL_FLG != 'Y'
AND	WLPM.DEL_FLG != 'Y'
AND	WLCKM.DEL_FLG != 'Y'
AND	CLMT.ENTITY_CRE_FLG = 'Y'
AND	WLPM.ENTITY_CRE_FLG = 'Y'
AND	WLCKM.ENTITY_CRE_FLG = 'Y'
ORDER BY clmt.LOCKER_NUM;

BEGIN

    for f1 in c1

    loop
      
dbms_output.put_line( 	f1.sol_id         ||'|'||
		      	f1.rack_id        ||'|'||
		      	f1.locker_type    ||'|'||
		      	f1.locker_num     ||'|'||
		      	f1.cif_id	  ||'|'||
			f1.cust_name	  ||'|'||
		      	f1.rent_amt       ||'|'||
                      	f1.premium_method ||'|'||
                      	f1.premium_amount ||'|'||
		      	f1.reason         ||'|'|| 
		      	f1.remarks
					);
	       	     
   
    end loop; 
END;
/
spool off


