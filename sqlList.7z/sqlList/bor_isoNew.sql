set head off
set pages 0
set echo off
set verify off
set feedback off
set termout off
--Commented as records are getting truncated
--set wrap off
set linesize 150
set space 0
set colsep |
whenever sqlerror exit sql.sqlcode
spool &2-&1..txt
select FORACID,TRAN_DATE, TRAN_PARTICULAR, INSTRMNT_NUM, PART_TRAN_TYPE, TRAN_AMT,decode(TRAN_TYPE,'T','Transfer','L','Clearing','C','Cash'), TRAN_RMKS
from gam, htd
where gam.acid = htd.acid
and foracid ='&2'
--and foracid in
--('675405000020',
--'675405000011',
--'675405600001',
--'675405600002',
--'675405600003',
--'675405600004',
--'675405600005',
--'675405600006',
--'675405600007',
--'675405600008')
and htd.del_flg!='Y'
and htd.pstd_flg = 'Y'
and tran_date = to_date('&1','dd-mm-yyyy')
and gam.bank_id = '&3'
and htd.bank_id ='&3'
/
spool off
exit
