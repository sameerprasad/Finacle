----------------------------------------------------------------------------------------------------
--   Source Name            : Report_EqvRent.sql
--   Description            : Locker Type Wise Vacancy and Equivalent Rent Report.
--   Input Values           : None
--   Output Values          : None
--   Called Script          : N.A
--   Calling Script         : N.A
--   Modification History:
--   Sl No.         Date              Author                     Description
--   --------------------------------------------------------------------------------------
--     01         16-Oct-2012         Priyanka                 Original Version
----------------------------------------------------------------------------------------------------

set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_EqvRent.lst

DECLARE

lv_solid         gam.sol_id%type :='&1';
lv_bod_date      varchar2(30):='&2';
lv_bankid     gam.bank_id%type := '&3';

CURSOR c1 IS

SELECT 
        SOL_ID,
        LOCKER_TYPE,
        SIZE_OF_LOCKER,
        COUNT(LOCKER_NUM) v_count
FROM 
        WLCKM
WHERE 
           SOL_ID = lv_solid
AND        BANK_ID = lv_bankid
AND        STATUS = 'A'
AND        DEL_FLG != 'Y'
AND        ENTITY_CRE_FLG = 'Y'
GROUP BY SOL_ID,LOCKER_TYPE,SIZE_OF_LOCKER;

cursor c2(v_locker_type WLCKM.LOCKER_TYPE%type) is

select 
    a.rent_amt,a.RENT_VERSION_CODE,a.RENT_EFFECTIVE_DATE
from 
    lclrm a,sst c
WHERE 
       a.sol_id = c.set_id
and    a.location_code = c.set_id
and    c.set_id like 'LOC%'
and    c.sol_id = lv_solid
and    a.bank_id = c.bank_id
and    a.bank_id = lv_bankid
and    a.locker_type = v_locker_type
and    a.RENT_PERIOD='1'
and    a.Rent_Version_Code = (    select max(b.Rent_Version_Code) 
                            from 
                                lclrm b 
                            where 
                                   a.location_code = b.location_code
                            and    a.locker_type = b.locker_type
                            and    a.RENT_PERIOD = b.RENT_PERIOD
                            and    a.sol_id = b.sol_id
                            and    b.rent_effective_date <= to_date(lv_bod_date,'dd-mm-yyyy')
                        )
and    a.del_flg != 'Y'
and    a.entity_cre_flg != 'N';


BEGIN

    for f1 in c1
    loop
        for f2 in c2(f1.LOCKER_TYPE)
        loop
                    
        dbms_output.put_line(    f1.sol_id                 ||'|'||
				f1.locker_type             ||'|'||
				f1.SIZE_OF_LOCKER          ||'|'||
				f1.v_count                 ||'|'||
				f2.RENT_AMT                ||'|'||
                                f2.RENT_VERSION_CODE       ||'|'||
                                f2.RENT_EFFECTIVE_DATE
                            );     
        end loop;
       end loop; 
END;
/
spool off

