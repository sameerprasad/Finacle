CREATE OR REPLACE PACKAGE TBAADM.MIS AS
TYPE rct_desc_tab IS TABLE OF TBAADM.RCT.ref_desc%TYPE INDEX BY VARCHAR2(5);
TYPE sol_desc_tab IS TABLE OF TBAADM.SOL.sol_desc%TYPE INDEX BY VARCHAR2(4);
TYPE region_desc_tab IS TABLE OF TBAADM.SOL.region_name%TYPE INDEX BY VARCHAR2(4);
TYPE schm_desc_tab IS TABLE OF TBAADM.gsp.schm_desc%TYPE INDEX BY VARCHAR2(5);
TYPE rate_tab IS TABLE OF number(21,10) INDEX BY VARCHAR2(3);

FUNCTION getEabBalance(Iacid	gam.acid%type,Idate date) RETURN NUMBER;
FUNCTION getNORRate(Icrncy gam.acct_crncy_code%type,Idate date) RETURN NUMBER;
FUNCTION getSanctLimit(Iacid  gam.acid%type,Idate date) RETURN NUMBER;
FUNCTION GetDrawingPower(Iacid gam.acid%TYPE,Idate  DATE) RETURN NUMBER ;
FUNCTION GetRctDesc(Iref_rec_type rct.ref_rec_type%type) RETURN rct_desc_tab;
FUNCTION GetSolDesc RETURN sol_desc_tab;
FUNCTION GetRegionName RETURN region_desc_tab;
FUNCTION GetSchmDesc RETURN schm_desc_tab;
FUNCTION GetNORRate(Idate date , Isol_id sol.sol_id%type) RETURN rate_tab;
FUNCTION GetAcctStatus(Iacid gam.acid%TYPE) RETURN varchar2;
FUNCTION GetAcctStatusDt(Iacid gam.acid%TYPE) RETURN Date;
FUNCTION GetffpFlag(Iacid gam.acid%TYPE) RETURN varchar2;
FUNCTION Getfffdacid(Iacid gam.acid%TYPE) RETURN varchar2;
FUNCTION GetTamMaturityDt(Iacid gam.acid%TYPE) RETURN DATE;
FUNCTION GetTamOpenEffDt(Iacid gam.acid%TYPE) RETURN DATE;
FUNCTION GetTamMaturityAmt(Iacid gam.acid%TYPE) RETURN NUMBER;
FUNCTION GetTamDepositAmt(Iacid gam.acid%TYPE) RETURN NUMBER;
FUNCTION GetTdtIntRate(Iacid gam.acid%TYPE) RETURN NUMBER;
FUNCTION GetLastIntCrDt(Iacid gam.acid%TYPE) RETURN DATE;
FUNCTION GetTamDetails(Iacid gam.acid%TYPE) RETURN varchar2;
FUNCTION GetLhtDetails(Iacid gam.acid%TYPE,Idate date) RETURN varchar2;
FUNCTION GetGlSubHeadCode(Iacid gam.acid%TYPE,Idate date) RETURN varchar2;
FUNCTION GetAvgBal(Iacid gam.acid%TYPE,date1 DATE,date2 DATE) RETURN NUMBER;
FUNCTION getConvRate(fxdCrncyCode varchar2,varCrncyCode varchar2,rateCode varchar2,rptDate date) RETURN NUMBER;
PROCEDURE GETINT(Iacid IN gam.acid%type,Icrncy IN gam.acct_crncy_code%TYPE,Idate IN DATE,
Orate OUT ivs.nrml_int_pcnt%TYPE,Oint_tbl_code OUT itc.int_tbl_code%TYPE) ;

PROCEDURE SBINT(Iacid IN gam.acid%type,Icrncy IN gam.acct_crncy_code%TYPE,Idate IN DATE,
IDrCR  IN ivs.INT_SLAB_DR_CR_FLG%type,
Orate OUT ivs.nrml_int_pcnt%TYPE,Oint_tbl_code OUT itc.int_tbl_code%TYPE);
PROCEDURE TamIntTblcode(Iacid IN varchar2,OINT_TBL_CODE OUT varchar2,OcustCrPrefPcnt OUT number,
OcustDrPrefPcnt OUT number,
OidCrPrefPcnt OUT number,OidDrPrefPcnt OUT number);
FUNCTION TamIntversion(Iacid VARCHAR2,inttblcode VARCHAR2) RETURN VARCHAR2;
FUNCTION TamIntRate(Iacid varchar2) RETURN NUMBER;
PROCEDURE GETINT_BILL(Isol_id IN gam.sol_id%type,Ibill_id fbm.bill_id%type,Idate IN DATE,
Orate OUT ivs.nrml_int_pcnt%TYPE,Oint_tbl_code OUT itc.int_tbl_code%TYPE) ;

END;
/
CREATE OR REPLACE PACKAGE BODY MIS AS

FUNCTION getEabBalance(Iacid  gam.acid%type,Idate date) RETURN NUMBER IS
balance		NUMBER;
BEGIN
	BEGIN
	SELECT tran_date_bal INTO balance FROM eab WHERE acid=Iacid
	AND eod_date<=Idate AND end_eod_date>=Idate;
	EXCEPTION WHEN NO_DATA_FOUND THEN
	balance:=0;
	END;
	RETURN balance;
END;
FUNCTION getNORRate(Icrncy gam.acct_crncy_code%type,Idate date) RETURN NUMBER IS
l_rtlist_date				rth.rtlist_date%TYPE;
l_rtlist_num				rth.rtlist_num%TYPE;
l_rate						rth.fxd_crncy_units%type;
BEGIN
	BEGIN
	SELECT NVL(var_crncy_units/fxd_crncy_units,1)
	INTO l_rate
	FROM
	(SELECT var_crncy_units,fxd_crncy_units
	FROM rth
	WHERE var_crncy_code = 'INR'
	AND ratecode = 'NOR'
	AND rtlist_date<=Idate
	AND fxd_crncy_code =Icrncy
	ORDER BY rtlist_date DESC,lchg_time desc)
	WHERE rownum=1;
	EXCEPTION WHEN NO_DATA_FOUND THEN
	l_rate:=1;
	END;
	RETURN l_rate;

END;
--==================
FUNCTION GetSanctLimit(Iacid IN gam.acid%TYPE,Idate IN DATE) RETURN NUMBER IS
l_sanct_lim    lht.sanct_lim%TYPE;
BEGIN
   BEGIN
   SELECT sanct_lim INTO l_sanct_lim FROM
	  (SELECT sanct_lim
	  FROM lht
   WHERE acid=Iacid
   AND APPLICABLE_DATE<=Idate
	  AND entity_cre_flg='Y'
	  AND del_flg='N'
	  ORDER BY APPLICABLE_DATE desc , lchg_time desc, SERIAL_NUM desc)
	  WHERE rownum=1;
   EXCEPTION WHEN NO_DATA_FOUND THEN
   l_sanct_lim:=0;
   END;
   RETURN l_sanct_lim;
END;
--==================
FUNCTION GetDrawingPower(Iacid IN gam.acid%TYPE,Idate IN DATE) RETURN NUMBER IS
l_DRWNG_POWER  dht.DRWNG_POWER%type;
BEGIN
   BEGIN
   SELECT DRWNG_POWER INTO l_DRWNG_POWER FROM dht
   WHERE acid=Iacid
   AND SERIAL_NUM=(SELECT MAX(serial_num) FROM dht WHERE
   acid=Iacid and APPLICABLE_DATE<=Idate AND entity_cre_flg='Y' AND del_flg='N');
   EXCEPTION WHEN NO_DATA_FOUND THEN
   l_DRWNG_POWER:=0;
   END;
   RETURN l_DRWNG_POWER;
END;
--==================
FUNCTION GetRctDesc(Iref_rec_type rct.ref_rec_type%type) RETURN rct_desc_tab IS
l_rct_desc_tab					rct_desc_tab;
BEGIN
	FOR i in (SELECT ref_code,ref_desc FROM rct where ref_rec_type=Iref_rec_type AND del_flg='N') LOOP
	l_rct_desc_tab(i.ref_code):=i.ref_desc;
	END LOOP;
	RETURN l_rct_desc_tab;

END;
--==================
FUNCTION GetSolDesc RETURN sol_desc_tab IS
l_sol_desc_tab					sol_desc_tab;
BEGIN
	FOR i in (SELECT sol_id,sol_desc FROM sol) LOOP
	l_sol_desc_tab(i.sol_id):=i.sol_desc;
	END LOOP;
	RETURN l_sol_desc_tab;

END;
--==================
FUNCTION GetRegionName RETURN region_desc_tab IS
l_region_desc_tab					region_desc_tab;
BEGIN
	FOR i in (SELECT sol_id,region_name FROM sol) LOOP
	l_region_desc_tab(i.sol_id):=i.region_name;
	END LOOP;
	RETURN l_region_desc_tab;

END;
--==================
FUNCTION GetSchmDesc RETURN schm_desc_tab IS
l_schm_desc_tab					schm_desc_tab;
BEGIN
	FOR i in (SELECT distinct schm_code,schm_desc FROM gsp) LOOP
	l_schm_desc_tab(i.schm_code):=i.schm_desc;
	END LOOP;
	RETURN l_schm_desc_tab;

END;
--==================
FUNCTION GetNORRate(Idate date,Isol_id sol.sol_id%type) RETURN rate_tab IS
l_rate_tab			 rate_tab;
BEGIN
	FOR i IN (SELECT DISTINCT crncy_code FROM gsh WHERE sol_id=Isol_id ) LOOP
		IF (i.crncy_code != 'INR') THEN
			l_rate_tab(i.crncy_code):=GetNORRate(i.crncy_code,Idate);
		END IF;
	END LOOP ;
	l_rate_tab('INR'):=1;
	RETURN l_rate_tab;
END;
--==================
FUNCTION GetAcctStatus(Iacid gam.acid%TYPE) RETURN varchar2 IS
l_acct_status		varchar2(1);
BEGIN
	BEGIN
		SELECT DECODE(acct_status,'I','I','D','D','A') INTO l_acct_status
 	FROM smt WHERE acid=Iacid ;
		EXCEPTION WHEN NO_DATA_FOUND THEN
		l_acct_status:='A';
	END;
	RETURN l_acct_status;

END;
--==================
FUNCTION GetAcctStatusDt(Iacid gam.acid%TYPE) RETURN Date IS
l_Date			DATE;
BEGIN
	BEGIN
		SELECT acct_status_date INTO l_Date
		FROM smt WHERE acid=Iacid ;
		EXCEPTION WHEN NO_DATA_FOUND THEN
		SELECT acct_opn_date INTO l_Date FROM gam WHERE acid=Iacid;
	END;
	RETURN l_Date;
END;
--==================
FUNCTION GetffpFlag(Iacid gam.acid%TYPE) RETURN varchar2 IS
l_flag				varchar2(1);
l_schm_type			gam.schm_type%TYPE;
BEGIN
	SELECT schm_type into l_schm_type FROM gam WHERE acid=Iacid;
	IF l_schm_type = 'TDA' THEN
		l_flag:='N';
	ELSE
		BEGIN
			SELECT ffp.auto_cr_from_oper_acct_flg INTO l_flag
			FROM ffp WHERE acid=Iacid and del_flg='N';
			EXCEPTION WHEN NO_DATA_FOUND THEN
			l_flag:='N';
		END;
		IF l_flag ='N' THEN
			BEGIN
				SELECT DECODE(COUNT(tam.acid),1,'Y','N') INTO l_flag
				FROM gam,tam
				WHERE tam.link_oper_account=Iacid
				AND gam.acid=tam.acid
				AND nvl(gam.acct_cls_flg,'N') !='Y'
				AND rownum < 2;
			END;
		END IF;
	END IF;
	RETURN l_flag;
END;
--==================
FUNCTION Getfffdacid(Iacid gam.acid%TYPE) RETURN varchar2 IS
l_foracid			varchar2(16);
l_schm_type   gam.schm_type%TYPE;
BEGIN
	SELECT schm_type into l_schm_type FROM gam WHERE acid=Iacid;
	IF l_schm_type != 'TDA' THEN
		l_foracid := 'N' ;
	ELSE
		BEGIN
			SELECT foracid into l_foracid FROM gam WHERE acid =
			(  SELECT link_oper_account FROM tam WHERE acid = Iacid AND link_oper_account IS NOT NULL) ;
			EXCEPTION WHEN NO_DATA_FOUND THEN
			l_foracid := 'N' ;
		END;
	END IF;
	RETURN l_foracid;
END;
--==================
FUNCTION GetTamMaturityDt(Iacid gam.acid%TYPE) RETURN DATE IS
l_date				date;
BEGIN
	BEGIN
		SELECT maturity_date INTO l_date FROM TAM WHERE acid=Iacid;
		EXCEPTION WHEN NO_DATA_FOUND THEN
		l_date:=NULL;
	END;
	RETURN l_date;
END;
--==================
FUNCTION GetTamOpenEffDt(Iacid gam.acid%TYPE) RETURN DATE IS
l_date  date;
BEGIN
	BEGIN
		SELECT open_effective_date INTO l_date FROM TAM WHERE acid=Iacid;
		EXCEPTION WHEN NO_DATA_FOUND THEN
		l_date:=NULL;
	END;
	RETURN l_date;
END;
--==================
FUNCTION GetTamMaturityAmt(Iacid gam.acid%TYPE) RETURN NUMBER IS
l_maturity_amount			NUMBER;
BEGIN
	BEGIN
		SELECT maturity_amount INTO l_maturity_amount FROM TAM WHERE acid=Iacid;
		EXCEPTION WHEN NO_DATA_FOUND THEN
		l_maturity_amount:=0;
	END;
	RETURN  l_maturity_amount;
END;
--==================
FUNCTION GetTamDepositAmt(Iacid gam.acid%TYPE) RETURN NUMBER IS
l_deposit_amount			NUMBER;
BEGIN
	BEGIN
		SELECT deposit_amount INTO l_deposit_amount FROM TAM WHERE acid=Iacid;
		EXCEPTION WHEN NO_DATA_FOUND THEN
		l_deposit_amount:=0;
	END;
	RETURN  l_deposit_amount;
END;
--==================
FUNCTION GetTdtIntRate(Iacid gam.acid%TYPE) RETURN NUMBER IS
l_rate				NUMBER(9,6);
l_schm_type   gam.schm_type%TYPE;
BEGIN
	SELECT schm_type INTO l_schm_type FROM gam WHERE acid=Iacid;
	BEGIN
		IF l_schm_type = 'TDA' THEN
			BEGIN
				SELECT int_pcnt INTO l_rate
				FROM tdt WHERE acid = Iacid
				AND srl_num = ( SELECT max(srl_num)
				FROM tdt WHERE acid = Iacid AND flow_code IN ('II','IO')) ;
				EXCEPTION WHEN NO_DATA_FOUND THEN
				l_rate:= 0 ;
			END;
		END IF;
	END;
	RETURN l_rate;
END;
--==================
FUNCTION GetLastIntCrDt(Iacid gam.acid%TYPE) RETURN DATE IS
l_date					DATE;
BEGIN
	BEGIN
		SELECT last_int_cr_tran_date into l_date FROM eit WHERE entity_id=Iacid
		and ENTITY_TYPE='ACCNT';
		EXCEPTION WHEN NO_DATA_FOUND THEN
		l_date:=NULL;
	END;
	RETURN l_date ;
END;
--==================
FUNCTION GetTamDetails(Iacid gam.acid%TYPE) RETURN varchar2 is
l_str				   varchar2(1000);
BEGIN
	BEGIN
		SELECT open_effective_date||'|'||maturity_date||'|'||deposit_amount||'|'||maturity_amount
		into l_str from tam where acid=Iacid;
		EXCEPTION WHEN NO_DATA_FOUND THEN
		l_str:='|||';
	END;
	RETURN l_str;
END;
--==================
FUNCTION GetLhtDetails(Iacid gam.acid%TYPE,Idate date) RETURN varchar2 is
l_str   varchar2(1000);
BEGIN
	BEGIN
		SELECT SANCT_LIM||'|'||LIM_SANCT_DATE||'|'||LIM_EXP_DATE
		INTO l_str FROM lht
		WHERE acid=Iacid
	 AND serial_num=(SELECT MAX(serial_num) FROM lht WHERE
	 acid=Iacid and APPLICABLE_DATE<=Idate AND entity_cre_flg='Y' AND del_flg='N');
		EXCEPTION WHEN NO_DATA_FOUND THEN
		l_str:='||';
	END;
	RETURN l_str;
END;
--==================
FUNCTION GetGlSubHeadCode(Iacid gam.acid%TYPE,Idate date) RETURN varchar2 is
l_gl_sub_head_code		gam.gl_sub_head_code%type;
BEGIN
	BEGIN
		SELECT GL_SUB_HEAD_CODE into l_gl_sub_head_code FROM amht
		WHERE acid=Iacid and Idate BETWEEN fromdate AND todate;
		EXCEPTION WHEN NO_DATA_FOUND THEN
		BEGIN
			SELECT GL_SUB_HEAD_CODE into l_gl_sub_head_code FROM gam
			WHERE acid=Iacid;
			EXCEPTION WHEN NO_DATA_FOUND THEN
			l_gl_sub_head_code:=null;
		END;
	END;
	RETURN l_gl_sub_head_code;
END;
--==================
FUNCTION GetAvgBal(Iacid gam.acid%TYPE,date1 DATE,date2 DATE) RETURN NUMBER IS
avgbal NUMBER ;
BEGIN
	BEGIN
   	SELECT (SUM( value_date_bal *
   (((LEAST(to_date(nvl(end_eod_date,'31-DEC-2099')),date2) - (GREATEST(to_date(eod_date),date1))
)+1)))

   / ((date2-date1)+1))
   INTO avgbal
   FROM eab
   WHERE acid = Iacid
   AND ((NVL(end_eod_date,TO_DATE('31-DEC-2099')) >= date1) AND (eod_date <= date2)) ;
   EXCEPTION WHEN NO_DATA_FOUND THEN
   avgbal := 0 ;
	END ;
   RETURN avgbal ;
END;
--==================
--{
FUNCTION getConvRate
(
	fxdCrncyCode 	varchar2,
	varCrncyCode 	varchar2,
	rateCode 		varchar2,
	rptDate 		date
)
RETURN NUMBER 	is
ExRate 			NUMBER:= 0;
lv_rateCode		gct.report_rate_code%type;

cursor 	c1(rtcd rth.ratecode%type) is
select 	(to_number(nvl(var_crncy_units,'0')))/(to_number(nvl(fxd_crncy_units,'1'))) finalrate
from 	rth r1
		where r1.fxd_crncy_code = fxdCrncyCode
		and r1.var_crncy_code = varCrncyCode
		and r1.ratecode = rtcd
		and r1.del_flg != 'Y'
		and r1.rtlist_date = (  select max(r2.rtlist_date)
								from rth r2
								where r2.fxd_crncy_code = fxdCrncyCode
								and r2.var_crncy_code = varCrncyCode
								and r2.ratecode = rtcd
								and r2.rtlist_date <= (to_date(rptDate))
								and r2.del_flg  != 'Y')
		order by r1.rtlist_num desc;
cursor 	c2(rtcd rth.ratecode%type) is
select 	(to_number(nvl(var_crncy_units,'0')))/(to_number(nvl(fxd_crncy_units,'1'))) finalrate
from 	rth r1
		where r1.fxd_crncy_code = varCrncyCode
		and r1.var_crncy_code = fxdCrncyCode
		and r1.ratecode = rtcd
		and r1.del_flg != 'Y'
		and r1.rtlist_date = (  select max(r2.rtlist_date)
								from rth r2
								where r2.fxd_crncy_code = varCrncyCode
								and r2.var_crncy_code = fxdCrncyCode
								and r2.ratecode = rtcd
								and r2.rtlist_date <= (to_date(rptDate))
								and r2.del_flg  != 'Y')
		order by r1.rtlist_num desc;
i  c1%rowtype;
j  c2%rowtype;

begin
	lv_rateCode := rateCode;
	ExRate := 0;
	IF varCrncyCode = fxdCrncyCode then
		ExRate := 1;
		return(ExRate);
	END if;
	for i in c1(lv_rateCode)
	loop
		ExRate := i.finalrate;
		exit;
	END loop;
	IF ExRate = 0 then
		begin
			for j in c2(lv_rateCode)
			loop
				ExRate := 1/j.finalrate;
				exit;
			END loop;
		END;
	END if;
	IF ExRate = 0 then
		ExRate := 1;
	END if;
	return(ExRate);
END getConvRate;

PROCEDURE GETINT(Iacid IN gam.acid%type,Icrncy IN gam.acct_crncy_code%TYPE,Idate IN DATE,
Orate OUT ivs.nrml_int_pcnt%TYPE,Oint_tbl_code OUT itc.int_tbl_code%TYPE) IS
l_int_tbl_code			itc.int_tbl_code%type;
l_dr_pref				itc.id_dr_pref_pcnt%type;
l_cr_pref				itc.id_dr_pref_pcnt%type;
l_int_version			icv.int_version%type;
l_base_pcnt				icv.base_pcnt%type;
l_base_int_tbl_code		icv.base_int_tbl_code%type;
l_nrml_int_pcnt		ivs.nrml_int_pcnt%type;
l_base_pcnt_dr			icv.base_pcnt_dr%type;
l_base_pcnt_cr			icv.base_pcnt_cr%type;
BEGIN

	BEGIN
		 SELECT int_tbl_code,nvl(id_dr_pref_pcnt,0)+nvl(CUST_DR_PREF_PCNT,0) dr_pref,
		 nvl(ID_cr_PREF_PCNT,0)+nvl(CUST_cr_PREF_PCNT,0) cr_pref
		 INTO l_int_tbl_code,l_dr_pref,l_cr_pref
		 FROM
		 (SELECT int_tbl_code,id_dr_pref_pcnt,CUST_DR_PREF_PCNT,ID_cr_PREF_PCNT,CUST_cr_PREF_PCNT
		 FROM itc
		 WHERE entity_id = Iacid
		 AND del_flg = 'N'
		 AND entity_type = 'ACCNT'
		 AND start_date <= Idate
		 ORDER BY INT_TBL_CODE_SRL_NUM DESC)
		 WHERE rownum=1;
		 exception when no_data_found then
		 l_int_tbl_code:=null;
		 l_dr_pref:=null;
		 l_cr_pref:=null;
	END;

	IF l_int_tbl_code IS NOT NULL THEN
		BEGIN
			SELECT int_version,base_pcnt,base_int_tbl_code ,base_pcnt_dr,base_pcnt_cr
			INTO l_int_version,l_base_pcnt,l_base_int_tbl_code,l_base_pcnt_dr,l_base_pcnt_cr
			FROM (
			SELECT int_version,base_pcnt,base_int_tbl_code,BASE_PCNT_DR,BASE_PCNT_CR
			FROM icv WHERE
			int_tbl_code =l_int_tbl_code
			AND Idate BETWEEN START_DATE AND END_DATE
			AND CRNCY_CODE=Icrncy
			AND DEL_FLG='N'
			ORDER BY INT_TBL_VER_NUM DESC)
			WHERE rownum=1;
			EXCEPTION WHEN NO_DATA_FOUND THEN
			l_int_version:=NULL;
			l_base_pcnt:=NULL;
			l_base_int_tbl_code:=NULL;
			l_base_pcnt_dr:=0;
			l_base_pcnt_cr:=0;
		END;
		IF l_int_version IS NOT NULL THEN
			BEGIN
				SELECT nrml_int_pcnt INTO  l_nrml_int_pcnt
				FROM (SELECT nrml_int_pcnt
				FROM ivs
				WHERE int_tbl_code=l_int_tbl_code
				AND int_tbl_ver_num =l_int_version
				AND INT_SLAB_DR_CR_FLG='D'
				AND   crncy_code = Icrncy
				AND DEL_FLG='N'
				AND ENTITY_CRE_FLG='Y'
				ORDER BY INT_SLAB_SRL_NUM desc)
				WHERE rownum=1;
				EXCEPTION WHEN NO_DATA_FOUND THEN
				l_nrml_int_pcnt:=0;
			END;
		ELSE
			l_nrml_int_pcnt:=0;
		END IF;
	ELSE
		l_nrml_int_pcnt:=0;
	END IF;

	IF  l_base_int_tbl_code IS NOT NULL THEN
  BEGIN
   SELECT int_version,base_pcnt,base_int_tbl_code ,base_pcnt_dr,base_pcnt_cr
   INTO l_int_version,l_base_pcnt,l_base_int_tbl_code,l_base_pcnt_dr,l_base_pcnt_cr
   FROM (
   SELECT int_version,base_pcnt,base_int_tbl_code,BASE_PCNT_DR,BASE_PCNT_CR
   FROM icv WHERE
   int_tbl_code =l_base_int_tbl_code
   AND Idate BETWEEN START_DATE AND END_DATE
   AND CRNCY_CODE=Icrncy
   AND DEL_FLG='N'
   ORDER BY INT_TBL_VER_NUM DESC)
   WHERE rownum=1;
   EXCEPTION WHEN NO_DATA_FOUND THEN
   l_int_version:=NULL;
   l_base_pcnt:=NULL;
   l_base_int_tbl_code:=NULL;
   l_base_pcnt_dr:=0;
   l_base_pcnt_cr:=0;
  END;
	ELSE
		l_base_pcnt_dr:=0;
		l_base_pcnt_cr:=0;
	END IF;

	l_nrml_int_pcnt:=l_nrml_int_pcnt+l_dr_pref-l_cr_pref+l_base_pcnt_dr;
	Orate:=l_nrml_int_pcnt;
	Oint_tbl_code:=l_int_tbl_code;

	IF  l_base_pcnt <> 0 OR l_base_int_tbl_code IS NOT NULL THEN
		dbms_output.put_line(Iacid||'|'||l_base_pcnt	||'|'||l_base_int_tbl_code);
	END IF;
END getint;
--}

PROCEDURE SBINT(Iacid IN gam.acid%type,Icrncy IN gam.acct_crncy_code%TYPE,Idate IN DATE,
IDrCR  IN ivs.INT_SLAB_DR_CR_FLG%type,
Orate OUT ivs.nrml_int_pcnt%TYPE,Oint_tbl_code OUT itc.int_tbl_code%TYPE) IS
l_int_tbl_code			itc.int_tbl_code%type;
l_dr_pref				itc.id_dr_pref_pcnt%type;
l_cr_pref				itc.id_dr_pref_pcnt%type;
l_int_version			icv.int_version%type;
l_base_pcnt				icv.base_pcnt%type;
l_base_int_tbl_code		icv.base_int_tbl_code%type;
l_nrml_int_pcnt		ivs.nrml_int_pcnt%type;
l_base_pcnt_dr			icv.base_pcnt_dr%type;
l_base_pcnt_cr			icv.base_pcnt_cr%type;
BEGIN

	BEGIN
		 SELECT int_tbl_code,nvl(id_dr_pref_pcnt,0)+nvl(CUST_DR_PREF_PCNT,0) dr_pref,
		 nvl(ID_cr_PREF_PCNT,0)+nvl(CUST_cr_PREF_PCNT,0) cr_pref
		 INTO l_int_tbl_code,l_dr_pref,l_cr_pref
		 FROM
		 (SELECT int_tbl_code,id_dr_pref_pcnt,CUST_DR_PREF_PCNT,ID_cr_PREF_PCNT,CUST_cr_PREF_PCNT
		 FROM itc
		 WHERE entity_id = Iacid
		 AND del_flg = 'N'
		 AND entity_type = 'ACCNT'
		 AND start_date <= Idate
		 ORDER BY start_date DESC)
		 WHERE rownum=1;
		 exception when no_data_found then
		 l_int_tbl_code:=null;
		 l_dr_pref:=null;
		 l_cr_pref:=null;
	END;

	IF l_int_tbl_code IS NOT NULL THEN
		BEGIN
			SELECT int_version,base_pcnt,base_int_tbl_code ,base_pcnt_dr,base_pcnt_cr
			INTO l_int_version,l_base_pcnt,l_base_int_tbl_code,l_base_pcnt_dr,l_base_pcnt_cr
			FROM (
			SELECT int_version,base_pcnt,base_int_tbl_code,BASE_PCNT_DR,BASE_PCNT_CR
			FROM icv WHERE
			int_tbl_code =l_int_tbl_code
			AND Idate BETWEEN START_DATE AND END_DATE
			AND CRNCY_CODE=Icrncy
			AND DEL_FLG='N'
			ORDER BY INT_TBL_VER_NUM DESC)
			WHERE rownum=1;
			EXCEPTION WHEN NO_DATA_FOUND THEN
			l_int_version:=NULL;
			l_base_pcnt:=NULL;
			l_base_int_tbl_code:=NULL;
			l_base_pcnt_dr:=0;
			l_base_pcnt_cr:=0;
		END;
		IF l_int_version IS NOT NULL THEN
			BEGIN
				SELECT nrml_int_pcnt INTO  l_nrml_int_pcnt
				FROM (SELECT nrml_int_pcnt
				FROM ivs
				WHERE int_tbl_code=l_int_tbl_code
				AND int_tbl_ver_num =l_int_version
				AND INT_SLAB_DR_CR_FLG=IDrCR
				AND   crncy_code = Icrncy
				AND DEL_FLG='N'
				AND ENTITY_CRE_FLG='Y'
				ORDER BY INT_SLAB_SRL_NUM desc)
				WHERE rownum=1;
				EXCEPTION WHEN NO_DATA_FOUND THEN
				l_nrml_int_pcnt:=0;
			END;
		ELSE
			l_nrml_int_pcnt:=0;
		END IF;
	ELSE
		l_nrml_int_pcnt:=0;
	END IF;

	IF  l_base_int_tbl_code IS NOT NULL THEN
  BEGIN
   SELECT int_version,base_pcnt,base_int_tbl_code ,base_pcnt_dr,base_pcnt_cr
   INTO l_int_version,l_base_pcnt,l_base_int_tbl_code,l_base_pcnt_dr,l_base_pcnt_cr
   FROM (
   SELECT int_version,base_pcnt,base_int_tbl_code,BASE_PCNT_DR,BASE_PCNT_CR
   FROM icv WHERE
   int_tbl_code =l_base_int_tbl_code
   AND Idate BETWEEN START_DATE AND END_DATE
   AND CRNCY_CODE=Icrncy
   AND DEL_FLG='N'
   ORDER BY INT_TBL_VER_NUM DESC)
   WHERE rownum=1;
   EXCEPTION WHEN NO_DATA_FOUND THEN
   l_int_version:=NULL;
   l_base_pcnt:=NULL;
   l_base_int_tbl_code:=NULL;
   l_base_pcnt_dr:=0;
   l_base_pcnt_cr:=0;
  END;
	ELSE
		l_base_pcnt_dr:=0;
		l_base_pcnt_cr:=0;
   END IF;

   l_nrml_int_pcnt:=l_nrml_int_pcnt+l_dr_pref-l_cr_pref+l_base_pcnt_dr;
   Orate:=l_nrml_int_pcnt;
   Oint_tbl_code:=l_int_tbl_code;

   IF  l_base_pcnt <> 0 OR l_base_int_tbl_code IS NOT NULL THEN
   dbms_output.put_line(Iacid||'|'||l_base_pcnt ||'|'||l_base_int_tbl_code);
   END IF;
END ;

PROCEDURE TamIntTblCode(Iacid IN varchar2,OINT_TBL_CODE OUT varchar2,
OcustCrPrefPcnt OUT number,OcustDrPrefPcnt OUT number,
OidCrPrefPcnt OUT number,OidDrPrefPcnt OUT number)
is
l_INT_TBL_CODE itc.INT_TBL_CODE%type;
l_OPEN_EFFECTIVE_DATE   date;
l_tamflag char(1):='Y';
begin
  begin
  select OPEN_EFFECTIVE_DATE into l_OPEN_EFFECTIVE_DATE from tam
  where acid=Iacid;
  exception when
  no_data_found then
  l_tamflag:='N';
  end;
  if (l_tamflag='Y') then
  begin
  select INT_TBL_CODE,CUST_CR_PREF_PCNT,CUST_DR_PREF_PCNT,
  ID_CR_PREF_PCNT ,ID_DR_PREF_PCNT
  into OINT_TBL_CODE,OcustCrPrefPcnt,OcustDrPrefPcnt,
  OidCrPrefPcnt,OidDrPrefPcnt from itc a where
  a.ENTITY_ID=Iacid and a.ENTITY_TYPE='ACCNT' and
  a.DEL_FLG<>'Y' and a.ENTITY_CRE_FLG='Y'
  and a.start_date <=l_OPEN_EFFECTIVE_DATE and
  a.end_date>=l_OPEN_EFFECTIVE_DATE and a.lchg_time =
  (select max(lchg_time) from itc b where
  b.entity_id=Iacid and b.ENTITY_TYPE='ACCNT' and
  b.DEL_FLG<>'Y' and b.ENTITY_CRE_FLG='Y' and
  b.start_date <=l_OPEN_EFFECTIVE_DATE
  and b.end_date>=l_OPEN_EFFECTIVE_DATE);

  exception when
  no_data_found then
  OINT_TBL_CODE:='*****';
  OcustCrPrefPcnt:=0;
  OcustDrPrefPcnt:=0;
  OidCrPrefPcnt:=0;
  OidDrPrefPcnt:=0;
  end;
  else
  l_tamflag:='Y';
  OINT_TBL_CODE:='*****';
  OcustCrPrefPcnt:=0;
  OcustDrPrefPcnt:=0;
  OidCrPrefPcnt:=0;
  OidDrPrefPcnt:=0;
  end if;


end;
FUNCTION TamIntVersion(Iacid varchar2,inttblcode varchar2)
return varchar2 is

l_INT_VERSION icv.INT_VERSION%type;
l_crncy_code gam.ACCT_CRNCY_CODE%type;
l_inttblcode itc.INT_TBL_CODE%type;
l_OPEN_EFFECTIVE_DATE   date;
begin
  if (inttblcode <> '*****') then
  select ACCT_CRNCY_CODE into l_crncy_code from gam where acid= Iacid;
  select OPEN_EFFECTIVE_DATE into l_OPEN_EFFECTIVE_DATE from tam
  where acid=Iacid;
  l_inttblcode:=inttblcode;
		BEGIN
  select INT_VERSION into l_INT_VERSION
  from ( select INT_VERSION from icv a  where INT_TBL_CODE=l_inttblcode
  and a.start_date <=l_OPEN_EFFECTIVE_DATE and
  a.end_date>=l_OPEN_EFFECTIVE_DATE and
  a.DEL_FLG<>'Y' and a.ENTITY_CRE_FLG='Y' and
  a.crncy_code=l_crncy_code
  and a.base_ind<>'Y'
  order by lchg_time desc)
  where rownum=1;
		exception when no_data_found then
		l_INT_VERSION:='*****';
		END;
--   return l_INT_VERSION;
  else
  l_INT_VERSION:='*****';
  end if;
  return l_INT_VERSION;
end;

PROCEDURE GETINT_BILL(Isol_id IN gam.sol_id%type,Ibill_id fbm.bill_id%type,Idate IN DATE,
Orate OUT ivs.nrml_int_pcnt%TYPE,Oint_tbl_code OUT itc.int_tbl_code%TYPE) IS
l_int_tbl_code       itc.int_tbl_code%type;
l_dr_pref            itc.id_dr_pref_pcnt%type;
l_cr_pref            itc.id_dr_pref_pcnt%type;
l_int_version        icv.int_version%type;
l_base_pcnt          icv.base_pcnt%type;
l_base_int_tbl_code     icv.base_int_tbl_code%type;
l_nrml_int_pcnt      ivs.nrml_int_pcnt%type;
l_base_pcnt_dr       icv.base_pcnt_dr%type;
l_base_pcnt_cr       icv.base_pcnt_cr%type;
l_entity_id          itc.entity_id%type;
l_entity_type        itc.entity_type%type;
l_bill_crncy_code    fbm.bill_crncy_code%type;
BEGIN
   BEGIN
      SELECT BILL_B2K_ID,'FBILL',bill_crncy_code  INTO l_entity_id,l_entity_type,l_bill_crncy_code
      FROM fbm
      WHERE bill_id=Ibill_id
      AND sol_id=Isol_id;
      EXCEPTION WHEN NO_DATA_FOUND THEN
      BEGIN
         SELECT BILL_B2K_ID,'IBILL','INR'  INTO l_entity_id,l_entity_type,l_bill_crncy_code
         FROM blt
         WHERE bill_id=Ibill_id
         AND sol_id=Isol_id;
         EXCEPTION WHEN NO_DATA_FOUND THEN
         l_entity_id:=null;
         l_entity_type:=null;
      END;
   END;
   BEGIN
       SELECT int_tbl_code,nvl(id_dr_pref_pcnt,0)+nvl(CUST_DR_PREF_PCNT,0) dr_pref,
       nvl(ID_cr_PREF_PCNT,0)+nvl(CUST_cr_PREF_PCNT,0) cr_pref
       INTO l_int_tbl_code,l_dr_pref,l_cr_pref
       FROM
       (SELECT int_tbl_code,id_dr_pref_pcnt,CUST_DR_PREF_PCNT,ID_cr_PREF_PCNT,CUST_cr_PREF_PCNT
       FROM itc
       WHERE entity_id = l_entity_id
       AND del_flg = 'N'
       AND entity_type = l_entity_type
       AND start_date <= Idate
       ORDER BY INT_TBL_CODE_SRL_NUM DESC)
       WHERE rownum=1;
       exception when no_data_found then
       l_int_tbl_code:=null;
       l_dr_pref:=null;
       l_cr_pref:=null;
   END;

   IF l_int_tbl_code IS NOT NULL THEN
      BEGIN
         SELECT int_version,base_pcnt,base_int_tbl_code ,base_pcnt_dr,base_pcnt_cr
         INTO l_int_version,l_base_pcnt,l_base_int_tbl_code,l_base_pcnt_dr,l_base_pcnt_cr
         FROM (
         SELECT int_version,base_pcnt,base_int_tbl_code,BASE_PCNT_DR,BASE_PCNT_CR
         FROM icv WHERE
         int_tbl_code =l_int_tbl_code
         AND Idate BETWEEN START_DATE AND END_DATE
         AND CRNCY_CODE=l_bill_crncy_code
         AND DEL_FLG='N'
         ORDER BY INT_TBL_VER_NUM DESC)
         WHERE rownum=1;
         EXCEPTION WHEN NO_DATA_FOUND THEN
         l_int_version:=NULL;
         l_base_pcnt:=NULL;
         l_base_int_tbl_code:=NULL;
         l_base_pcnt_dr:=0;
         l_base_pcnt_cr:=0;
      END;
      IF l_int_version IS NOT NULL THEN
         BEGIN
            SELECT nrml_int_pcnt INTO  l_nrml_int_pcnt
            FROM (SELECT nrml_int_pcnt
            FROM ivs
            WHERE int_tbl_code=l_int_tbl_code
            AND int_tbl_ver_num =l_int_version
            AND INT_SLAB_DR_CR_FLG='D'
            AND   crncy_code = l_bill_crncy_code
            AND DEL_FLG='N'
            AND ENTITY_CRE_FLG='Y'
            ORDER BY INT_SLAB_SRL_NUM desc)
            WHERE rownum=1;
            EXCEPTION WHEN NO_DATA_FOUND THEN
            BEGIN
               SELECT nrml_int_pcnt INTO  l_nrml_int_pcnt
               FROM lavs
               WHERE int_tbl_code=l_int_tbl_code
               AND int_tbl_ver_num =l_int_version
               AND del_flg='N'
               AND entity_cre_flg='Y'
               AND int_slab_dr_cr_flg='D'
               AND crncy_code= l_bill_crncy_code
               AND rownum<2;
               EXCEPTION WHEN NO_DATA_FOUND THEN
               l_nrml_int_pcnt:=0;
            END;

         END;
      ELSE
         l_nrml_int_pcnt:=0;
      END IF;
   ELSE
      l_nrml_int_pcnt:=0;
   END IF;
   IF  l_base_int_tbl_code IS NOT NULL THEN
        BEGIN
            SELECT int_version,base_pcnt,base_int_tbl_code ,base_pcnt_dr,base_pcnt_cr
            INTO l_int_version,l_base_pcnt,l_base_int_tbl_code,l_base_pcnt_dr,l_base_pcnt_cr
            FROM (
            SELECT int_version,base_pcnt,base_int_tbl_code,BASE_PCNT_DR,BASE_PCNT_CR
            FROM icv WHERE
            int_tbl_code =l_base_int_tbl_code
            AND Idate BETWEEN START_DATE AND END_DATE
            AND CRNCY_CODE=l_bill_crncy_code
            AND DEL_FLG='N'
            ORDER BY INT_TBL_VER_NUM DESC)
            WHERE rownum=1;
            EXCEPTION WHEN NO_DATA_FOUND THEN
            l_int_version:=NULL;
            l_base_pcnt:=NULL;
            l_base_int_tbl_code:=NULL;
            l_base_pcnt_dr:=0;
            l_base_pcnt_cr:=0;
        END;
   ELSE
      l_base_pcnt_dr:=0;
      l_base_pcnt_cr:=0;
   END IF;

   l_nrml_int_pcnt:=l_nrml_int_pcnt+l_dr_pref-l_cr_pref+l_base_pcnt_dr;
   Orate:=l_nrml_int_pcnt;
   Oint_tbl_code:=l_int_tbl_code;

   IF  l_base_pcnt <> 0 OR l_base_int_tbl_code IS NOT NULL THEN
      dbms_output.put_line(Ibill_id||'|'||l_base_pcnt ||'|'||l_base_int_tbl_code);
   END IF;
END getint_bill;



FUNCTION TamIntRate(Iacid varchar2)
return number is
l_DEPOSIT_AMOUNT tam.DEPOSIT_AMOUNT%type;
l_crncy_code gam.ACCT_CRNCY_CODE%type;
l_maturity_date date;
l_nrml_int_pcnt tvs.nrml_int_pcnt%type;
l_inttblcode tvs.int_tbl_code%type;
l_INT_VERSION icv.INT_VERSION%type;
l_OPEN_EFFECTIVE_DATE   date;
l_custCrPrefPcnt number;
l_custDrPrefPcnt number;
l_idCrPrefPcnt  number;
l_idDrPrefPcnt number;

begin


  TamIntTblCode(Iacid,l_inttblcode,l_custCrPrefPcnt,
  l_custDrPrefPcnt,l_idCrPrefPcnt,l_idDrPrefPcnt);
		  --l_tbl_code:=l_inttblcode;
		  --dbms_output.put_line(Iacid||'|'||l_inttblcode||'|'||l_custCrPrefPcnt||'|'||
		  --l_custDrPrefPcnt||'|'||l_idCrPrefPcnt||'|'||l_idDrPrefPcnt);

  if (l_inttblcode<>'*****') then
  l_INT_VERSION:=TamIntVersion(Iacid,l_inttblcode);
		  --dbms_output.put_line(l_INT_VERSION);
  select DEPOSIT_AMOUNT,add_months(OPEN_EFFECTIVE_DATE,DEPOSIT_PERIOD_MTHS)
		  +DEPOSIT_PERIOD_days,OPEN_EFFECTIVE_DATE

  into l_DEPOSIT_AMOUNT,l_maturity_date ,l_OPEN_EFFECTIVE_DATE
  from tam
  where acid=Iacid;
  select ACCT_CRNCY_CODE into l_crncy_code from gam where acid= Iacid;
  begin
  select nrml_int_pcnt into l_nrml_int_pcnt from tvs
  where int_tbl_code=l_inttblcode and
  int_tbl_ver_num=l_INT_VERSION and
  int_slab_dr_cr_flg='C' and
  begin_slab_amount<=l_DEPOSIT_AMOUNT and
  l_DEPOSIT_AMOUNT<=max_slab_amount and
  add_months(l_OPEN_EFFECTIVE_DATE,max_contracted_mths +
  DECODE(max_contracted_days, 999, 1, 0))+
  DECODE(max_contracted_days, 999, -1,max_contracted_days)
  >=l_maturity_date and
  add_months(l_OPEN_EFFECTIVE_DATE,max_period_run_mths +
  DECODE(max_period_run_days, 999, 1, 0)) +
  DECODE(max_period_run_days, 999, -1, max_period_run_days)
  >=l_maturity_date and
  del_flg <> 'Y' and
  crncy_code=l_crncy_code and
  entity_cre_flg='Y' and rownum=1;
  exception when
  no_data_found then
  l_nrml_int_pcnt:=0;
  end;
	l_nrml_int_pcnt:=l_nrml_int_pcnt+
  nvl(l_custCrPrefPcnt,0)+nvl(l_idCrPrefPcnt,0);
--  -nvl(l_custDrPrefPcnt,0)-nvl(l_idDrPrefPcnt,0);
	if (l_nrml_int_pcnt is null) then
	l_nrml_int_pcnt:=0;
	end if;
  return l_nrml_int_pcnt;
  else
  return 0;
  end if;

end;
END;
