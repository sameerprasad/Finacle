set serveroutput on size 1000000
set head off
set linesize 512
set trims on
set pages 0
set feedback off
set verify off
set termout off
spool icivr.txt

declare

loc_fp                  utl_file.file_type;
loc_filename            varchar2(200);
loc_filepath            varchar2(100);
loc_filemode            varchar2(100);
outLine                 varchar2(10000);
tdacid             	varchar2(12);
cust_stat           	varchar2(9);
clsflg              	varchar2(9);
CDDRIND                 varchar2(2);
fromdat                 date;
todat                   date;

cursor g_cur (fromdat varchar2,todat varchar2) is
select h.acid,h.tran_date,h.VALUE_DATE,to_char(h.tran_amt,'9999999999.99') amt,h.part_tran_type,h.TRAN_PARTICULAR,g.foracid,h.ENTRY_DATE
from gam g,htd h where 
--h.tran_date=(select sysdate - 1 from dual) 
h.tran_date between fromdat and todat
and g.acid=h.acid
--and g.sol_id=h.sol_id
and g.schm_type='SBA'
and g.schm_code='ICIVR'
and g.del_flg='N'
and h.del_flg='N'
and h.PSTD_FLG='Y'
and g.bank_id='&3'
and h.bank_id='&3';


Begin
--{
    fromdat := '&1';
    todat := '&2';
    loc_filepath := '/mistmp';
--  loc_filepath := '/tmp';

    loc_filename := 'VRDDailyTranFile'||replace('&2','-','')||'.txt';
    loc_filemode := 'w';
    loc_fp := utl_file.fopen(loc_filepath, loc_filename, loc_filemode);


    outLine := 'SYSTEM DATE'||'|'||'TRAN DATE'||'|'||'VALUE DATE'||'|'||'ACCOUNT NO'||'|'||'TRAN AMT'||'|'||'FLAG'||'|'||'DESCRIPTION'||'|'||'STATUS';
    utl_file.put_line(loc_fp,outLine);

    FOR A0 IN g_cur(fromdat,todat) LOOP

         

              begin
              clsflg := '';
              select decode(acct_cls_flg,'Y','Closed','N','Active') into clsflg from gam where foracid=A0.foracid and bank_id='&3';
              end;


              begin
              CDDRIND := '';
              select decode(A0.part_tran_type,'C','D','D','W') into CDDRIND from gam where foracid=A0.foracid and bank_id='&3';
              end;


--      	outLine := to_date(sysdate,'DDMMYYYY')||'|'||A0.tran_date||'|'||A0.VALUE_DATE||'|'||forac||'|'||A0.part_tran_type||'|'||A0.TRAN_PARTICULAR||'|'||clsflg; 
             outLine := to_char(A0.ENTRY_DATE,'DDMMYYYY')||'|'||to_char(A0.tran_date,'DDMMYYYY')||'|'||to_char(A0.VALUE_DATE,'DDMMYYYY')||'|'||A0.foracid||'|'||replace(A0.amt,' ','')||'|'||CDDRIND||'|'||A0.TRAN_PARTICULAR||'|'||clsflg;


    		utl_file.put_line(loc_fp,outLine);
       END LOOP;
   utl_file.fclose(loc_fp);
End;
/
spool off
