drop table ici_charge_fall_history 
/
drop public synonym ici_charge_fall_history 
/
create table ici_charge_fall_history(
ACCOUNT_NO     VARCHAR2(16),
TRAN_DATE      DATE,
TOD_AMT        NUMBER(15,2),
TXN_AMT        NUMBER(15,2),
PRIORITY       VARCHAR2(2),
TYPE           VARCHAR2(2),
TOD_DESC       VARCHAR2(50),
PROCESS_ID     VARCHAR2(100),
TRAN_ID        VARCHAR2(9),
BANK_ID        VARCHAR2(8)
)
/
create public synonym ici_charge_fall_history for ici_charge_fall_history 
/
grant select, insert, update, delete on ici_charge_fall_history to tbagen
/
grant select, insert, update, delete on ici_charge_fall_history to tbautil
/
grant select, insert, update, delete on ici_charge_fall_history to tbaadm
/
