--===================================================================================================================
--Filename             :  crt_flt_file.sql
--Description          :  sql to select foracid from gam,tdt table.             
--Date                 :  12-09-2012
--Author               :  Amal,Vaibhav Bansal
--Menu Option          :  EXECOM1,BJSTM20
--Modification History
--    Sl. #             Date             Author             Modification                              
--    -----            -----            --------           ---------------- 
--    01	      30-08-2012	Amal			                              
--    02              12-09-2012       Vaibhav Bansal       Coding Standard Changes                          
--===================================================================================================================
set transaction use rollback segment dcm_rollback;
set head off
set pages 0
set lines 255
set trimspool on
set feedback off
set verify off
set colsep '|'
spool brtrustacct_{&1}
SELECT GAM.foracid
FROM tbaadm.GAM, tbaadm.TDT
WHERE GAM.acid = TDT.acid
AND GAM.sol_id = '&1'
AND GAM.schm_type = 'TDA'
AND GAM.schm_code NOT IN ('RBHAL','RBCFD')
AND GAM.acct_cls_flg ! = 'Y'
AND TDT.flow_code IN ('II', 'IO')
AND GAM.bank_id = '&2' AND TDT.bank_id = '&2'
/
spool off
quit


