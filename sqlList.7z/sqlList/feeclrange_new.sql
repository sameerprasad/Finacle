host \rm -f FEECLNEW*lst 2>/dev/null
set pagesize 80
set feedback on
set numformat 99,99,99,999.99
column DC new_value dcalias
select dc_alias DC from gct;
column D new_value dt
define sep = :
select db_stat_date D from gct;
set head off
set linesize 500
set trims on
set verify off
break on report skip 1
select 'ZONE_DATE:TRAN_DATE:ZONE_CODE:SOL_ID:TRAN_ID:AMT:DR_OR_CR:INST_CODE:ROLL:CLASS:REF_NUM:STUDENT NAME:COURSE' from dual;
spool feeclnew1
select 
ocp.clg_zone_date,'&sep',
ocp.tran_date,'&sep',
ocp.clg_zone_code,'&sep',
ocp.sol_id,'&sep',
ocp.tran_id, '&sep',
ocp.tran_amt AMT, '&sep',
oci.instrmnt_amt AMT, '&sep',  
ocp.part_tran_type, '&sep',
ocp.partcls, '&sep',
' ', '&sep',
ocp.tran_rmks, '&sep',
oci.instrmnt_id, '&sep', 
oci.bank_code, '&sep',  
substr(rct.ref_desc,1,35), '&sep',  
bct.br_name 
from gam,ocp,ott, oci, bct ,rct
where gam.acid=ocp.acid
and ott.acid=ocp.acid
and ocp.del_flg!='Y'
and gam.foracid = '0036SLFCSCOL'
and ocp.clg_zone_date between to_date('&1','dd-mm-yyyy')  and to_date('&2','dd-mm-yyyy')
--and ocp.clg_zone_code in ('FM','FU')
and ocp.status_flg='G'
and shd_bal_rem_amt=0
and ocp.tran_id=ott.tran_id
and ocp.tran_date=ott.tran_date
and ocp.part_tran_srl_num=ott.part_tran_srl_num
and ott.del_flg!='Y'
and ott.org_tran_amt<>ott.total_offset_amt
and oci.sol_id = ocp.sol_id
and oci.clg_zone_date = ocp.clg_zone_date 
and oci.clg_zone_code = ocp.clg_zone_code
and oci.set_num = ocp.set_num 
and oci.bank_code = bct.bank_code
and oci.br_code = bct.br_code
and trim(oci.bank_code) = rct.ref_code
and rct.ref_rec_type = '47'
and bct.bank_id = ott.bank_id
and ott.bank_id = ocp.bank_id 
and ocp.bank_id = oci.bank_id
and rct.bank_id = gam.bank_id
and gam.bank_id = '&3'
/
spool off
host chmod 777 feeclnew1.lst
host cp feeclnew1.lst feeclrange_new.lst
host cp feeclnew1.lst FEECLNEWR&dcalias&dt..lst 2>/dev/null
host chmod 777 FEECLNEW*.lst
host mailx -s FEECLNEWR&dcalias&dt..lst -s "Fee Coll CLG-Range for &dcalias " feecollection@icicibank.com < /dev/null
host mailx -s FEECLNEWR&dcalias&dt..lst -s "Fee Coll CLG-Range for &dcalias " feecollection@icicibank.com < /dev/null
host mailx -s FEECLNEWR&dcalias&dt..lst -s "Fee Coll CLG-Range for &dcalias " ctu@icicibank.com < /dev/null
host mailx -s FEECLNEWR&dcalias&dt..lst -s "Fee Coll CLG-Range for &dcalias " ctu@icicibank.com < /dev/null
