REM 'SCRIPT FOR FINDING ACCOUNT with 0 balance but not closed'
REM 'AUTHOR :: Mukesh Kumar Jain""
set pages 60
set lines 132
set echo off
set feedback off
set termout off
set verify off
col subgl format a5
set newpage 0
define all_dashes = '___________________________________________________________________________'
column today new_value today_date
column bran new_value br
select to_char(sysdate,'dd/mm/yyyy:hh24:mi:ss') today
from dual;
select br_name bran from bct
where br_code = (select br_code from sol where sol_id = '&1' and bank_id='&2');

ttitle center  'ICICI BANK LTD.' skip 1 -
center br skip 1 -
center ' REPORT of 0 BALANCE Accounts pending closure/transacations' today_date skip 1 - 
left all_dashes skip 2
break on subgl skip 2 on report
spool zerobal
select gam.gl_sub_head_code subgl,
gsh.gl_sub_head_desc SUB_HEAD,
foracid acct_no,substr(acct_name,1,35) NAME,ledg_num
from gsh,gam
where gam.sol_id = '&1'
and acct_cls_flg != 'Y'
and clr_bal_amt+un_clr_bal_amt = 0
and acct_ownership = 'C'
and gsh.sol_id = '&1'
and gam.bank_id='&2'
and gsh.gl_sub_head_code = gam.gl_sub_head_code
and gsh.crncy_code = gam.acct_crncy_code
order by 1,3
/
set feedback on
set feedback on
set verify on
set heading on
clear breaks
clear computes
spool out
set echo on
exit
