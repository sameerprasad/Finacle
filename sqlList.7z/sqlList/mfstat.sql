set verify off
set heading off
set serveroutput on SIZE 1000000
set feedback off
set termout off
set pagesize 0
spool mfstat.lst

DECLARE
dbStatDate			varchar2(15);
dcAlias				GCT.dc_alias%type;
tmpCnt              number := 0;
dummyCnt            number := 0;
Cnt            		number := 0;
sweepStat			varchar(25);
dpStat				varchar(25);
lienStat				varchar(25);
dbName				varchar(25);
clrBalAmt			GAM.clr_bal_amt%type;
solId				SOL.sol_id%type;
titleCnt			number := 0;
netTotAmtWithMf		number(20,4) := 0;

CURSOR  solCursor is
SELECT  sol_id
FROM    SOL
WHERE  del_flg = 'N' 
and    bank_id = '&1';

CURSOR acctCursor is
SELECT 
	acct_num, tot_amt_with_mf
FROM ICICI_MF_ACCT
WHERE
sol_id = solId
and acct_stat_in_mf = 'O' 
and    bank_id = '&1';
BEGIN

SELECT TO_CHAR(TO_DATE(db_stat_date,'DD-MM-YY'),'DD-MM-YYYY'), dc_alias
--SELECT TO_DATE(db_stat_date,'DD-MM-YY'), dc_alias
INTO dbStatDate, dcAlias
FROM GCT
WHERE
bank_id = '&1';

SELECT SUM(TOT_AMT_WITH_MF)
INTO
netTotAmtWithMf
FROM ICICI_MF_ACCT
WHERE 
ACCT_STAT_IN_MF = 'O'
and    bank_id = '&1';

IF dcAlias = 'M3' THEN
dbName := 'BBY01';
else
dbName := dcAlias;
END IF;

DBMS_OUTPUT.PUT_LINE('-----------------------------------------------------------------');
DBMS_OUTPUT.PUT_LINE('REPORT AS ON' ||'     '||dbStatDate ||'    '||'FOR  '||'   '||dbName);
DBMS_OUTPUT.PUT_LINE('-----------------------------------------------------------------');
DBMS_OUTPUT.PUT_LINE('PART 1 ');
DBMS_OUTPUT.PUT_LINE('TOTAL AMOUNT WITH MUTUAL FUND IS ' || '		' || netTotAmtWithMf);
DBMS_OUTPUT.PUT_LINE('-----------------------------------------------------------------');
DBMS_OUTPUT.PUT_LINE('.');
DBMS_OUTPUT.PUT_LINE('.');
DBMS_OUTPUT.PUT_LINE('-----------------------------------------------------------------');
DBMS_OUTPUT.PUT_LINE('PART 2 ');
DBMS_OUTPUT.PUT_LINE('   LIST OF SOLS/ACCOUNTS FOR WHICH ');
DBMS_OUTPUT.PUT_LINE('1> SWEEP IS PENDING ');
DBMS_OUTPUT.PUT_LINE('2> DP UPDATE IS PENDING/ACCOUNT IS IN DEBIT BALANCE');
DBMS_OUTPUT.PUT_LINE('.');
DBMS_OUTPUT.PUT_LINE('.');


for solRec in solCursor LOOP
BEGIN
sweepStat := ' ';
solId := solRec.sol_id;


	BEGIN
	SELECT 'SWEEP PENDING' 
	into sweepStat
	FROM ICICI_LDTT
	WHERE DC_ALIAS = dcAlias
	AND DRIVER_ID = 'MFT'
	AND SER_NUM = 0
	AND SOL_ID = solRec.sol_id
	AND LAST_SENT_DATE < TO_DATE(dbStatDate , 'DD-MM-YYYY')
	AND BANK_ID = '&1';

	EXCEPTION
		when no_data_found then null;
		when others then NULL;
	END;

	if(sweepStat != ' ') THEN
		tmpCnt := tmpCnt + 1;
		DBMS_OUTPUT.PUT_LINE('SOL ID       SWEEP STATUS   ');
		DBMS_OUTPUT.PUT_LINE('-------------------------');

		DBMS_OUTPUT.PUT_LINE(solRec.sol_id  || '         ' || lpad(sweepStat,13, ' ' )); 
	end if;

	titleCnt := 0;
	dpStat := ' ';
	lienStat := ' ';
	clrBalAmt := 0;
	for acctRec in acctCursor LOOP
	BEGIN

	dpStat := ' ';
	lienStat := ' ';
	clrBalAmt := 0;
			BEGIN
				SELECT 
					clr_bal_amt
				INTO
					clrBalAmt
				FROM GAM
				WHERE
					FORACID = acctRec.acct_num
				AND ( (CLR_BAL_AMT < 0) or (CLR_BAL_AMT > 500000) )
				AND BANK_ID = '&1';

			EXCEPTION
				when no_data_found then null;
				when others then NULL;
			END;

		BEGIN
			SELECT 
				'DP PENDING'
			INTO
				dpStat
			FROM ICICI_MF_ACCT
			WHERE
				acct_num = acctRec.acct_num
			AND MFDP_STAT_FLG = 'P'
			AND BANK_ID = '&1';

		if(sqlcode != 0) then
			dpStat := ' ';
		end if;

		EXCEPTION
			when no_data_found then NULL;
			when others then NULL;
		END;

		BEGIN
			SELECT 
				'LIEN EXISTS'
			INTO
				lienStat
			FROM GAM
			WHERE
				foracid = acctRec.acct_num
			AND LIEN_AMT > 0
			AND BANK_ID = '&1';

		if(sqlcode != 0) then
			lienStat := ' ';
		end if;

		EXCEPTION
			when no_data_found then NULL;
			when others then NULL;
		END;


	if(dpStat != ' ' or clrBalAmt != 0 or lienStat != ' ') THEN
		if(titleCnt = 0 and sweepStat != ' ') then
			DBMS_OUTPUT.PUT_LINE('.');
			DBMS_OUTPUT.PUT_LINE('.');
		end if;
		if(titleCnt = 0) then
			titleCnt := 1;
			DBMS_OUTPUT.PUT_LINE('SOL ID       	   ACCOUNT NUMBER   	DP STATUS/DBT BAL VALUE/LIEN');
			DBMS_OUTPUT.PUT_LINE('---------------------------------------------------------------');
		end if;
	end if;

	if(dpStat != ' ' ) THEN
		tmpCnt := tmpCnt + 1;
		DBMS_OUTPUT.PUT_LINE(solRec.sol_id  || '         ' || '        ' || acctRec.acct_num || '       ' || dpStat );
	end if;

	if(clrBalAmt != 0) THEN
		tmpCnt := tmpCnt + 1;
		DBMS_OUTPUT.PUT_LINE(solRec.sol_id  || '         ' || '        ' || acctRec.acct_num || '       ' || clrBalAmt);
	end if;

	if(lienStat != ' ') THEN
		tmpCnt := tmpCnt + 1;
		DBMS_OUTPUT.PUT_LINE(solRec.sol_id  || '         ' || '        ' || acctRec.acct_num || '       ' || lienStat);
	end if;

	END;
	END LOOP;


	if(sweepStat != ' ' or dpStat != ' ' or clrBalAmt != 0 or lienStat != ' ') then
		DBMS_OUTPUT.PUT_LINE('.');
		DBMS_OUTPUT.PUT_LINE('.');
	end if;

END;
END LOOP;

DBMS_OUTPUT.PUT_LINE('-----------------------------------------------------------------');

if(tmpCnt = 0) then
    DBMS_OUTPUT.PUT_LINE('No Record Found');
end if;
END;
/
spool off
--exit
