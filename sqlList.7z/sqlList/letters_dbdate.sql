--===================================================================================================================
--  Filename                :   letters_dbdate.sql
--  Description             :
--  Date                    :   06-09-2012
--  Author                  :   Swaroop K Tiruvoipati
--  Menu Option             :
--  Modification History
--    Sl. #           Date           Author                     Modification
--    -----           -----          --------                    ----------------
--    1               06-09-2012     Swaroop K Tiruvoipati      Original Version
--                                                              (Ported from 7.x)
--===================================================================================================================
set head off
set pages 0
set feedback off
spool dbdate
select (db_stat_date ) from gct where BANK_ID = '&1';
spool off
exit
