rem accept dt Prompt  'ENTER CLEARING ZONE  DATE :: '
rem accept sol Prompt  'ENTER SOL_ID :: '
set numf b99999,99,999.99
set newp
set pages 60
set lines 80
set feedback off
set termout off
set verify off
col cheques format b9999
break on BANK skip page on report
compute sum label 'Total' of amount on BANK 
compute count label 'Number Of Instruments' of chq_num on BANK 
col br_name new_value branch
select ltrim(rtrim(sol_desc)) br_name from sol where ltrim(rtrim(sol_id))='&2';
ttitle center 'ICICI BANK LTD.,' branch skip 1 -
center 'CLEARING CHEQUES FOR  CLEARING FOR &1'
spool clearing
select
br_name BANK, 
instrmnt_id chq_num,
instrmnt_amt Amount
from bct,oci
where to_date(clg_zone_date) = to_date('&1','dd-mm-yyyy')
and oci.del_flg != 'Y'
and bct.bank_code = oci.bank_code
and bct.br_code = oci.br_code
and bct.bank_id='&3'
and oci.sol_id='&2'
order by 1,3
/
break on report
compute sum label 'Grand Total' of cheques amount on report
ttitle center 'ICICI BANK LTD.,' branch skip 1 -
center 'REPORT OF CHEQUES IN CLEARING for &1'
select ref_desc BANK,count(instrmnt_amt) Cheques, sum(instrmnt_amt) AMOUNT
from rct,oci
where  
--to_date(clg_zone_date) = to_date('&1','dd-mm-yyyy')
--and 
oci.del_flg != 'Y'
and rct.ref_rec_type = '47'
and rct.bank_id='&3'
and rct.ref_code = oci.rep_code
and oci.sol_id='&2'
group by ref_desc
order by 1
/
spool off
exit
