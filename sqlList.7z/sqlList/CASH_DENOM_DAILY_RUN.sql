set head off
set trims on
set verify off
set linesize 100
set pagesize 0
set echo off
spool CASH_DENOM_BBY_&1

select ACCOUNT_NO||'|'||TRAN_DATE||'|'||lpad(TRAN_ID,9)||'|'||PART_TRAN_TYPE||'|'||PART_TRAN_SRL_NUM||'|'||CNT_RS1000||'|'|
|CNT_RS500||'|'||CNT_RS100||'|'||CNT_RS50||'|'||CNT_RS20||'|'||CNT_RS10||'|'||TRAN_AMT from ici_cash_popup where tran_date=to_date('&2','dd-mm-yyyy') and PART_TRAN_TYPE
='C'
/
spool off

