rem set echo off
rem author S.Ramaswamy
rem Input Parameters   Date
rem Tables accessed
rem GAM, TAM, SCT, TDT
rem THIS SCRIPT GIVES THE MATURITY DETAILS OF FCNR ACCOUNT  (STAT 5 return)
set pause off
set heading off
set feedback off
set termout off
set verify off
set lines 132
set pages 0
set numformat 9999999999.99
SET VERIFY OFF 
SET FEEDBACK OFF 
SET TRIMS ON 
SET LINES 132 
SET HEAD OFF 
SET SERVEROUTPUT ON SIZE 999999
column code new_value br
col count(*) format 99999
col sum(deposit_amount) format 999999999999.99
col sum(deposit_amount)  format 999999999999.99
col sum(e.tran_date_bal)  format 999999999999.99
col sum(f.tran_date_bal)  format 999999999999.99
alter session set nls_date_format = 'DD-MON-YYYY';
spool &3.stat5.&2
select '			STAT5 ' from dual;
select ' ' from dual;
select 'Statement showing the inflow / outflow of deposits under ' from dual;
select 'Foreign Currency (Non-resident) Bank scheme between' from dual;
select '		&1 and &2' from dual;
select '_________________________________________________________' from dual;
select ' ' from dual;
select ' ' from dual;
select 'A) OPENING BALANCE :' from dual;
select '    i) Principal ' from dual;
select '1. 6 Months and above less than 1 year',g.crncy_code, sum(t.deposit_amount) 
from tam t, gam g ,tdt d
where  t.acid = g.acid
and  d.acid = g.acid
and d.bank_id = g.bank_id
and t.bank_id = g.bank_id
and g.gl_sub_head_code != '05060'
and  d.flow_code = 'PI'
and  d.flow_Date < '&1' 
and  t.maturity_date >= '&1'
and  (t.maturity_date - open_effective_date >= 181)
and  (t.maturity_date - open_effective_date <= 365)
and  (g.acct_cls_flg != 'Y'  or g.acct_cls_date > '&1')
and  g.acct_prefix = '31'
and  g.sol_id = '&3'
and  g.bank_id = '&4'
group by g.crncy_code
union
select '2. 1 year and above less than 2 year', g.crncy_code,sum(t.deposit_amount) 
from tam t, gam g ,tdt d
where  t.acid = g.acid
and  d.acid = g.acid
and d.bank_id = g.bank_id
and t.bank_id = g.bank_id
and g.gl_sub_head_code != '05060'
and  d.flow_code = 'PI'
and  d.flow_Date < '&1' 
and  t.maturity_date >= '&1'
and  (t.maturity_date - open_effective_date >= 366)
and  (t.maturity_date - open_effective_date <= 730)
and  (g.acct_cls_flg != 'Y'  or g.acct_cls_date > '&1')
and  g.acct_prefix = '31'
and g.sol_id = '&3'
and  g.bank_id = '&4'
group by g.crncy_code
union
select '3. 2 years and above less than 3 year', g.crncy_code,sum(t.deposit_amount) 
from tam t, gam g ,tdt d
where  t.acid = g.acid
and  d.acid = g.acid
and d.bank_id = g.bank_id
and t.bank_id = g.bank_id
and g.gl_sub_head_code != '05060'
and  d.flow_code = 'PI'
and  d.flow_Date < '&1' 
and  t.maturity_date >= '&1'
and  (t.maturity_date - open_effective_date >= 731)
and  (t.maturity_date - open_effective_date <= 1095)
and  (g.acct_cls_flg != 'Y'  or g.acct_cls_date > '&1')
and  g.acct_prefix = '31'
and  g.sol_id = '&3'
and  g.bank_id = '&4'
group by g.crncy_code
union
select '4. 3 years only', g.crncy_code,sum(t.deposit_amount) 
from tam t, gam g ,tdt d
where  t.acid = g.acid
and d.bank_id = g.bank_id
and t.bank_id = g.bank_id
and g.gl_sub_head_code != '05060'
and  d.acid = g.acid
and  d.flow_code = 'PI'
and  d.flow_Date < '&1' 
and  t.maturity_date > '&1'
and  (t.maturity_date - open_effective_date >= 1096)
and  (g.acct_cls_flg != 'Y'  or g.acct_cls_date > '&1')
and  g.acct_prefix = '31'
and  g.sol_id = '&3'
and  g.bank_id = '&4'
group by g.crncy_code
/
select '___________________________________________________________' from dual;
select ' B) INFLOW' from dual;
select '01. Inflow Less than six months ',g.crncy_code, sum(deposit_amount) 
from tam t, gam g ,tdt d
where  t.acid = g.acid
and  t.acid = d.acid
and d.bank_id = g.bank_id
and t.bank_id = g.bank_id
and g.gl_sub_head_code != '05060'
and  d.flow_code = 'PI'
and  d.flow_date between '&1' and '&2'
and  (g.acct_cls_flg != 'Y'  or g.acct_cls_date > '&2')
and  (t.maturity_date - open_effective_date <= 180)
and  substr(foracid,5,2) = '31'
and g.sol_id = '&3'
and  g.bank_id = '&4'
group by g.crncy_code
union all
select '02. inflow above 6 months less than 1 year', g.crncy_code, sum(deposit_amount)  
from tam t, gam g ,tdt d
where  t.acid = g.acid
and  t.acid = d.acid
and d.bank_id = g.bank_id
and t.bank_id = g.bank_id
and  d.flow_code = 'PI'
and  d.flow_date between '&1' and '&2'
and  (g.acct_cls_flg != 'Y'  or g.acct_cls_date > '&2')
and  (t.maturity_date - open_effective_date >= 181)
and  (t.maturity_date - open_effective_date <= 365)
and  substr(foracid,5,2) = '31'
and g.sol_id = '&3'
and  g.bank_id = '&4'
group by g.crncy_code
union all
select '03. inflow above 1 year less than 2 year' part,g.crncy_code, sum(deposit_amount)  
from tam t, gam g , tdt d
where  t.acid = g.acid
and  t.acid = d.acid
and d.bank_id = g.bank_id
and t.bank_id = g.bank_id
and g.gl_sub_head_code != '05060'
and  d.flow_code = 'PI'
and  d.flow_date between '&1' and '&2'
and  (g.acct_cls_flg != 'Y'  or g.acct_cls_date > '&2')
and  (t.maturity_date - open_effective_date >= 366)
and  (t.maturity_date - open_effective_date <= 730)
and  substr(foracid,5,2) = '31'
and  g.sol_id = '&3'
and  g.bank_id = '&4'
group by g.crncy_code
union all
select '04. inflow above 2 year less than 3 year' part,g.crncy_code, sum(deposit_amount) from
tam t, gam g ,tdt d
where  t.acid = g.acid
and  t.acid = d.acid
and d.bank_id = g.bank_id
and t.bank_id = g.bank_id
and g.gl_sub_head_code != '05060'
and  d.flow_code = 'PI'
and  d.flow_date between '&1' and '&2'
and  (g.acct_cls_flg != 'Y'  or g.acct_cls_date > '&2')
and  (t.maturity_date - open_effective_date >= 731)
and  (t.maturity_date - open_effective_date <= 1095)
and  g.acct_prefix = '31'
and  g.sol_id = '&3'
and  g.bank_id = '&4'
group by g.crncy_code
union all
select '05. inflow above 3 year' part,g.crncy_code, sum(deposit_amount) from
tam t, gam g ,tdt d
where  t.acid = g.acid
and  t.acid = d.acid
and d.bank_id = g.bank_id
and t.bank_id = g.bank_id
and g.gl_sub_head_code != '05060'
and  d.flow_code = 'PI'
and  d.flow_date between '&1' and '&2'
and  (g.acct_cls_flg != 'Y'  or g.acct_cls_date > '&2')
and  (t.maturity_date - open_effective_date >= 1096)
and  g.acct_prefix = '31'
and  g.sol_id = '&3'
and  g.bank_id = '&4'
group by g.crncy_code
/
select '06. Interest Credited                  ', g.crncy_code,sum(t.deposit_amount) 
from tam t, gam g ,tdt d
where  t.acid = g.acid
and  d.acid = g.acid
and d.bank_id = g.bank_id
and t.bank_id = g.bank_id
and g.gl_sub_head_code != '05060'
and  d.flow_code = 'II'
and  d.flow_Date between '&1' and '&2'
and  (g.acct_cls_flg != 'Y'  or g.acct_cls_date > '&1')
and  g.acct_prefix = '31'
and  g.sol_id = '&3'
and  g.bank_id = '&4'
group by g.crncy_code
order by 1
/
select '___________________________________________________________' from dual;
select ' B) OUTFLOW' from dual;
select '01. outflow Less than six months ',g.crncy_code, sum(deposit_amount) 
from tam t, gam g ,tdt d
where  t.acid = g.acid
and d.bank_id = g.bank_id
and t.bank_id = g.bank_id
and g.gl_sub_head_code != '05060'
and  t.acid = d.acid
and  d.flow_code = 'TO'
and  d.flow_date between '&1' and '&2'
and  (g.acct_cls_flg != 'Y'  or g.acct_cls_date > '&1')
and  (t.maturity_date - open_effective_date <= 180)
and  g.acct_prefix = '31'
and g.sol_id = '&3'
and  g.bank_id = '&4'
group by g.crncy_code
union all
select '02. outflow above 6 months less than 1 year', g.crncy_code, sum(deposit_amount)  
from tam t, gam g, tdt d 
where  t.acid = g.acid
and  t.acid = d.acid
and d.bank_id = g.bank_id
and t.bank_id = g.bank_id
and g.gl_sub_head_code != '05060'
and  d.flow_code = 'TO'
and  d.flow_date between '&1' and '&2'
and  (g.acct_cls_flg != 'Y'  or g.acct_cls_date > '&1')
and  (t.maturity_date - open_effective_date >= 181)
and  (t.maturity_date - open_effective_date <= 365)
and  g.acct_prefix = '31'
and g.sol_id = '&3'
and  g.bank_id = '&4'
group by g.crncy_code
union all
select '03. outflow above 1 year less than 2 year' ,g.crncy_code, sum(deposit_amount)  
from tam t, gam g ,tdt d
where  t.acid = g.acid
and  t.acid = d.acid
and d.bank_id = g.bank_id
and t.bank_id = g.bank_id
and g.gl_sub_head_code != '05060'
and  d.flow_code = 'TO'
and  d.flow_date between '&1' and '&2'
and  (g.acct_cls_flg != 'Y'  or g.acct_cls_date > '&1')
and  (t.maturity_date - open_effective_date >= 366)
and  (t.maturity_date - open_effective_date <= 730)
and  g.acct_prefix = '31'
and  g.sol_id = '&3'
and  g.bank_id = '&4'
group by g.crncy_code
union all
select '04. outflow above 2 year less than 3 year' ,g.crncy_code, sum(deposit_amount) from
tam t, gam g, tdt d 
where  t.acid = g.acid
and  t.acid = d.acid
and d.bank_id = g.bank_id
and t.bank_id = g.bank_id
and g.gl_sub_head_code != '05060'
and  d.flow_code = 'TO'
and  d.flow_date between '&1' and '&2'
and  (g.acct_cls_flg != 'Y'  or g.acct_cls_date > '&1')
and  (t.maturity_date - open_effective_date >= 731)
and  (t.maturity_date - open_effective_date <= 1095)
and  g.acct_prefix = '31'
and   g.sol_id = '&3'
and  g.bank_id = '&4'
group by g.crncy_code
union all
select '05. outflow above 3 year' part,g.crncy_code, sum(deposit_amount) from
tam t, gam g , tdt d 
where  t.acid = g.acid
and  t.acid = d.acid
and d.bank_id = g.bank_id
and t.bank_id = g.bank_id
and g.gl_sub_head_code != '05060'
and  d.flow_code = 'TO'
and  d.flow_date between '&1' and '&2'
and  (g.acct_cls_flg != 'Y'  or g.acct_cls_date > '&1')
and  (t.maturity_date - open_effective_date >= 1096)
and  g.acct_prefix = '31'
and  g.sol_id = '&3'
and  g.bank_id = '&4'
group by g.crncy_code
/
select '___________________________________________________________' from dual;
select 'D) Closing Balance' from dual;
select '    i) Principal ' from dual;
select '1. 6 Months and above less than 1 year',g.crncy_code, sum(t.deposit_amount) 
from tam t, gam g ,tdt d
where  t.acid = g.acid
and  d.acid = g.acid
and d.bank_id = g.bank_id
and t.bank_id = g.bank_id
and g.gl_sub_head_code != '05060'
and  d.flow_code = 'PI'
and  d.flow_Date < '&2' 
and  t.maturity_date >= '&2'
and  (t.maturity_date - open_effective_date >= 181)
and  (t.maturity_date - open_effective_date <= 365)
and  (g.acct_cls_flg != 'Y'  or g.acct_cls_date > '&2')
and  g.acct_prefix = '31'
and  g.sol_id = '&3' 
and  g.bank_id = '&4'
group by g.crncy_code
union
select '2. 1 year and above less than 2 year', g.crncy_code,sum(t.deposit_amount) 
from tam t, gam g ,tdt d
where  t.acid = g.acid
and  d.acid = g.acid
and d.bank_id = g.bank_id
and t.bank_id = g.bank_id
and g.gl_sub_head_code != '05060'
and  d.flow_code = 'PI'
and  d.flow_Date < '&2' 
and  t.maturity_date >= '&2'
and  (t.maturity_date - open_effective_date >= 366)
and  (t.maturity_date - open_effective_date <= 730)
and  (g.acct_cls_flg != 'Y'  or g.acct_cls_date > '&2')
and  g.acct_prefix = '31'
and  g.sol_id = '&3'
and  g.bank_id = '&4'
group by g.crncy_code
union
select '3. 2 years and above less than 3 year', g.crncy_code,sum(t.deposit_amount) 
from tam t, gam g ,tdt d
where  t.acid = g.acid
and  d.acid = g.acid
and d.bank_id = g.bank_id
and t.bank_id = g.bank_id
and g.gl_sub_head_code != '05060'
and  d.flow_code = 'PI'
and  d.flow_Date < '&2' 
and  t.maturity_date >= '&2'
and  (t.maturity_date - open_effective_date >= 731)
and  (t.maturity_date - open_effective_date <= 1095)
and  (g.acct_cls_flg != 'Y'  or g.acct_cls_date > '&2')
and  g.acct_prefix = '31'
and g.sol_id = '&3'
and  g.bank_id = '&4'
group by g.crncy_code
union
select '4. 3 years only', g.crncy_code,sum(t.deposit_amount) 
from tam t, gam g ,tdt d
where  t.acid = g.acid
and  d.acid = g.acid
and d.bank_id = g.bank_id
and t.bank_id = g.bank_id
and g.gl_sub_head_code != '05060'
and  d.flow_code = 'PI'
and  d.flow_Date < '&2' 
and  t.maturity_date >= '&2'
and  (t.maturity_date - open_effective_date >= 1096)
and  (g.acct_cls_flg != 'Y'  or g.acct_cls_date > '&2')
and  g.acct_prefix = '31'
and   g.sol_id = '&3'
and  g.bank_id = '&4'
group by g.crncy_code
/
ttitle off

whenever sqlerror continue
spool off
set pause off
set feedback on
set verify on
set heading on
set echo on
clear breaks
exit