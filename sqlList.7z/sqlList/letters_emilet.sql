--===================================================================================================================
--  Filename                :   letters_emilet.sql
--  Description             :
--  Date                    :   05-09-2012
--  Author                  :   Swaroop K Tiruvoipati
--  Menu Option             :
--  Modification History
--    Sl. #           Date           Author                     Modification
--    -----           -----          --------                    ----------------
--    1               05-09-2012     Swaroop K Tiruvoipati      Original Version
--                                                              (Ported from 7.x)
--===================================================================================================================
set verify off
set wrap on
set feedback off
set linesize 400
set space 1
set heading off
---alter session set optimizer_goal = rule ;
alter session set nls_date_format='DD-MON-YYYY';
set serveroutput on size 1000000;
declare
facid gam.acid%type;
itcint itc.int_tbl_code%type;
ccustid gam.cust_id%type;
ccifid cmg.cif_id%type;
c1title1 cmg.cust_title_code%type;
c1name  cmg.cust_name%type;
c1addr1 CRMUSER.ADDRESS.address_line1%type;
c1addr2 CRMUSER.ADDRESS.address_line2%type;
c1addr3 CRMUSER.ADDRESS.address_line3%type;
cpin CRMUSER.ADDRESS.zip%type;
c1title2 cmg.cust_title_code%type;
c1title3 cmg.cust_name%type;
ccity CRMUSER.ADDRESS.city_code%type;
cstate CRMUSER.ADDRESS.state_code%type;
ccntry  CRMUSER.ADDRESS.country_code%type;
sstatec varchar2(12);
scityc varchar2(20);
scntryc varchar2(5);
gacid  gam.foracid%type;
acctopndate gam.acct_opn_date%type;
flowamt lrs.flow_amt%type;
loanamt lht.sanct_lim%type;
emistartdate lrs.flow_start_date%type;
loanmths lam.rep_perd_mths%type;
loandays lam.rep_perd_days%type;
dt varchar2(11);
aref_desc rct.ref_desc%type;
bref_desc rct.ref_desc%type;
cref_desc rct.ref_desc%type;
dref_desc rct.ref_desc%type;
eref_desc rct.ref_desc%type;
branchname varchar2(25);
saddr1 varchar2(40);
saddr2 varchar2(40);
spin varchar2(7);
roi itc.int_tbl_code%type;
step number ;
dbsdate gct.db_stat_date%type;
loc_fp                          utl_file.file_type;
loc_filename                    varchar2(200);
loc_filepath                    varchar2(100);
loc_filemode                    varchar(10);

cursor cmgcur is
select g.acid, g.foracid,
	y.cif_id,
	decode(y.cust_title_code,NULL,'',y.cust_title_code),
	decode(y.cust_name,NULL,'',y.cust_name),
	--decode(y.address_line1,NULL,'',y.address_line1),
 	--decode(y.address_line2,NULL,'',y.address_line2),
	--decode(y.address_line3,NULL,'',y.address_line3),
	--decode(y.zip,NULL,'',y.zip),
	decode(y.cust_title_code, 'M/S', 'Sirs',y.cust_title_code),
	decode(y.cust_title_code, 'M/S', '',y.cust_name),
	--y.city_code,
	--y.state_code,
	--y.cntry_code,
	lht.sanct_lim,
	lrs.flow_amt, lrs.flow_start_date,
	lam.rep_perd_mths,
	lam.rep_perd_days,
	acct_opn_date
from gam g, cmg y,lht,lrs,lam where
g.acct_cls_flg!='Y'
--and to_date ( g.acct_opn_date, 'DD-MON-YYYY' ) = (select db_stat_date from gct where BANK_ID = '&3') --N
--and to_char(to_date ( g.acct_opn_date), 'DD-MON-YYYY' ) = to_char(to_date ('&2'), 'DD-MON-YYYY' )
and to_date(g.acct_opn_date,'DD-MM-YYYY') = to_date('&2','DD-MM-YYYY')
--and g.schm_code='EMPPA'
and g.cif_id = y.cif_id
and g.acid=lam.acid
and g.acid =lht.acid
and g.acid=lrs.acid
and g.BANK_ID = '&3'
and y.BANK_ID = '&3'
and lht.BANK_ID = '&3'
and lrs.BANK_ID = '&3'
and lam.BANK_ID = '&3';

cursor itcsel is
select int_tbl_code tblcode from itc where int_tbl_code_srl_num = (select max(int_tbl_code_srl_num
) from itc where entity_id=facid and BANK_ID = '&3') and entity_id=facid and BANK_ID = '&3';

cursor intcur is
select nrml_int_pcnt from ivs where int_tbl_ver_num =(select max (int_tbl_ver_num) from ivs where
int_tbl_code = itcint and BANK_ID = '&3') and int_tbl_code=itcint and BANK_ID = '&3';

begin 
step:=1;

open cmgcur;
loc_filepath := '&1';
        loc_filename := 'emilet.lst';
        loc_filemode := 'w';
        loc_fp := utl_file.fopen(loc_filepath, loc_filename, loc_filemode);
loop

step:=2;
--fetch cmgcur into facid,gacid,ccifid,c1title1,c1name,c1addr1,c1addr2,c1addr3,c1title2,c1title3,ccity,cstate,ccntry,loanamt, flowamt, emistartdate, loanmths, loandays,acctopndate;
fetch cmgcur into facid,gacid,ccifid,c1title1,c1name,c1title2,c1title3,loanamt, flowamt, emistartdate, loanmths, loandays,acctopndate;
exit when cmgcur%notfound;



begin
select   address_line1,
         address_line2,
         address_line3,
         city_code,
         state_code,
         zip,
         country_code
        INTO c1addr1,c1addr2,c1addr3,ccity,cstate,cpin,ccntry
        FROM  CRMUSER.ADDRESS
        where orgkey=ccifid
        and addresscategory = 'Mailing'
        AND start_date = (SELECT max(start_date) FROM CRMUSER.ADDRESS
        WHERE ORGKEY = ccifid AND addresscategory = 'Mailing' and bank_id = '&3')
        and bank_id = '&3';
        exception when no_data_found then
        null;
end;


step:=3;
begin 
branchname := 'LOAN OPERATIONS CENTRE';

begin
select decode(a.ref_desc,NULL,' ',a.ref_desc) into aref_desc
from rct a
where   a.ref_rec_type = '01'
and     a.ref_code = ccity
and     a.del_flg = 'N'
and a.BANK_ID = '&3';
exception 
when no_data_found then
aref_desc:='*';
end;

step:=4;
begin
select decode(b.ref_desc,NULL,' ',b.ref_desc) into bref_desc
from rct b
where   b.ref_rec_type = '02'
and     b.ref_code = cstate
and     b.del_flg = 'N'
and     b.BANK_ID = '&3';
exception 
when no_data_found then
bref_desc:='*';
end;


step:=5;
begin
select decode(c.ref_desc,NULL,' ',c.ref_desc) into cref_desc
from rct c
where   c.ref_rec_type = '03'
and     c.ref_code = ccntry
and     c.del_flg = 'N'
and     c.BANK_ID = '&3';
step := 100;
exception
when no_data_found then
cref_desc:='*';
end;

step:=6;
begin
saddr1 := 'LOAN OPERATIONS CENTRE';
saddr2 := 'ZENITH HOUSE, KESHAVRAO KHADYE MARG' ;
spin := '400 034';
scityc := 'MUMBAI - 400 034';
sstatec := 'MAHARASHTRA';
scntryc := 'INDIA';
end;

step:=7;
begin
select to_char(db_stat_date,'DD-MON-YYYY') into dt
from gct c where c.BANK_ID = '&3';
exception
when no_data_found then
dt:=NULL;
end;

step:=8;
begin

open itcsel;
fetch itcsel into itcint;

open intcur;
begin
fetch intcur into roi;
end;
close intcur;

close itcsel;
end;

step:=9;
utl_file.put_line(loc_fp,c1title1||'|'||c1name||'|'||c1addr1||'|'||c1addr2||'|'||c1addr3||'|'||aref_desc||'|'||bref_desc||'|'||cref_desc||'|'||cpin||'|'||branchname||'|'||saddr1||'|'||saddr2||'|'||spin||'|'||scityc||'|'||sstatec||'|'||gacid||'|'||flowamt||'|'||loanamt||'|'||emistartdate||'|'||loanmths||'|'||loandays||'|'||roi||'%'||'|'||acctopndate);

end;

end loop; 

close cmgcur;
exception 

when no_data_found then 
dbms_output.put_line('STEP IS ' || step ) ;
dbms_output.put_line('ERROR IS '||SQLCODE);
dbms_output.put_line('MESG IS '||SQLERRM);

when others then 
dbms_output.put_line('STEP IS ' || step ) ;
dbms_output.put_line('ERROR IS '||SQLCODE);
dbms_output.put_line('MESG IS '||SQLERRM);

end; 
/
