------------------------------------------------------------------------------------------------
-- Filename : infop.sql
-- Description : This sql file is for downloading rct codes to infopool
-- Date  : 24-09-2012
-- Author  : Pradeep Murgod
-- Menu Option : info25s.com
-- Modification History
-- Sl.#       Date           Author         Modification                              
-- -----   ----------   --------------    ----------------                               
--  1.0    24-09-2012    Pradeep Murgod    Original Version                          
------------------------------------------------------------------------------------------------

--
-- SQL for downloading rct codes to infopool
--
set serveroutput on size 1000000
set termout off
set feedback off
set head off
set pages 0
set trims on
--
spool &1
--
select ref_rec_type||'|'||ref_code||'|'||ref_desc||'|'||del_flg
from rct where ref_rec_type = '25' and del_flg='N'
union
select '25'||'|'||EMPLOYER_ID||'|'||EMPLOYER_NAME||'|'||del_flg
from emrm where del_flg='N'
/
--
spool off