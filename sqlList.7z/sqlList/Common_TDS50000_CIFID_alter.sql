--REM####################################################################
--REM File Name   : Common_CIFID_alter.sql
--REM Description : To Alter for Cust_id to Cif_id
--REM Author      : Pragnya Ghosh
--REM Date        : 08-04-2013
--REM####################################################################

ALTER TABLE TBAADM.CUST_TDS50000_TBL RENAME COLUMN CUST_ID TO CIF_ID; 
ALTER TABLE TBAADM.CUST_TDS50000_TBL MODIFY(CIF_ID VARCHAR2(50 CHAR));