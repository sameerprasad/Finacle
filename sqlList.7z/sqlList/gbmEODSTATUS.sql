set head off
set feedback off
set echo off
set verify off
set trims on
set pagesize 1000
spool &1
select SOL_ID,decode(EOD_STATUS,'','Not Started','ES','EOD STARTED','EE','EOD ENDED','CS','CEOD STARTED','CE','CEOD ENDED','Undefind:'||EOD_STATUS) from ici_gbm_eod_ceod where EOD_DATE='&2'
/
spool off
