--===================================================================================================================
--	Filename	               : ServiceTaxCustAccounts.sql
--      Description		       : This sql script dumps both customer communication details and accounts list 
--					 into accts_for_cust.lst file.If the accounts list required flag is "Y" then 
--					 all accounts for this customer will be dumped. Else, if it is "N" only customer 
--					 communication details are dumped.
--      Date			       : 
--      Author                         : 
--      Menu Option                    : <The menu option from which this sql file is invoked>
--	Modification History           :
--	Sl. #            Date                Author             Modification                              
--	-----            -----              --------	       ----------------                               
--	1.              19/03/2012	    Ranjith	        Changed the usage of CUST_ID to CIF_ID
--	2.		19/03/2012	    Ranjith	        Included a new parameter(BANK_ID) for use in queries.
--	3.		19/03/2012	    Ranjith		Changed the queries to take address details from 
--								NMA and CNMA tables.
--===================================================================================================================
set serveroutput ON size 1000000
set lines 500
set echo off
set trims on
set feedback off
set termout off
set verify off
spool accts_for_cust.lst

DECLARE

	LOC_CIF_ID			GAM.CIF_ID%TYPE;
	LOC_ACCT_ID			GAM.FORACID%TYPE;
	V_CIF_ID			GAM.CIF_ID%TYPE;
	V_CUST_TITLE_CODE	CMG.CUST_TITLE_CODE%TYPE;
	V_CUST_NAME			CMG.CUST_NAME%TYPE;
	V_ADDR_TYPE			CMG.ADDRESS_TYPE%TYPE;

--	V_ADDR_LINE_1		CMG.CUST_COMU_ADDR1%TYPE;
--	V_ADDR_LINE_2		CMG.CUST_COMU_ADDR2%TYPE;
--	V_CITY_CODE			CMG.CUST_COMU_CITY_CODE%TYPE;
--	V_STATE_CODE		CMG.CUST_COMU_STATE_CODE%TYPE;
--	V_PIN_CODE			CMG.CUST_COMU_PIN_CODE%TYPE;
--	V_CNTRY_CODE		CMG.CUST_COMU_CNTRY_CODE%TYPE;

	V_ADDR_LINE_1		NMA.ADDRESS1%TYPE;
	V_ADDR_LINE_2		NMA.ADDRESS2%TYPE;
	V_CITY_CODE		NMA.CITY_CODE%TYPE;
	V_STATE_CODE		NMA.STATE_CODE%TYPE;
	V_PIN_CODE		NMA.PIN_CODE%TYPE;
	V_CNTRY_CODE		NMA.CNTRY_CODE%TYPE;

	V_REF_DESC_01		RCT.REF_DESC%TYPE;
	V_REF_DESC_02		RCT.REF_DESC%TYPE;
	V_REF_DESC_03		RCT.REF_DESC%TYPE;

	I_FIRST_ARG		VARCHAR2 (16);
	I_BANK_ID		VARCHAR2 (16);
	I_ACCT_LIST_REQ		GAM.DEL_FLG%TYPE;
	I_FROM_DATE		GAM.ACCT_OPN_DATE%TYPE;
	I_TO_DATE		GAM.ACCT_OPN_DATE%TYPE;

	CURSOR GAM_CUST_ACCTS (LOC_CIF_ID CMG.CIF_ID%TYPE,LOC_BANK_ID VARCHAR2) IS
		SELECT
			FORACID
		FROM
			GAM
		WHERE
			CIF_ID = LOC_CIF_ID AND
			ENTITY_CRE_FLG = 'Y' AND
			SCHM_TYPE <> 'TDA' AND 
			BANK_ID = LOC_BANK_ID AND
			(ACCT_CLS_FLG <> 'Y' OR
			 ACCT_CLS_DATE >= TO_DATE (I_FROM_DATE, 'DD-MM-YYYY HH24:MI:SS')) AND
			ACCT_OPN_DATE <= TO_DATE (I_TO_DATE, 'DD-MM-YYYY HH24:MI:SS');
BEGIN
--{
	I_FIRST_ARG := '&1';
	I_ACCT_LIST_REQ := '&2';
	I_FROM_DATE := '&3';
	I_TO_DATE := '&4';
	I_BANK_ID := '&5';

	IF (I_ACCT_LIST_REQ = 'A') THEN
----{
		SELECT
			CIF_ID, CUST_TITLE_CODE, CUST_NAME, ADDRESS_TYPE INTO V_CIF_ID, V_CUST_TITLE_CODE, V_CUST_NAME, V_ADDR_TYPE
		FROM
			CMG
		WHERE
			CIF_ID = (SELECT CIF_ID FROM GAM WHERE FORACID = I_FIRST_ARG AND BANK_ID = I_BANK_ID) AND BANK_ID = I_BANK_ID;
----}
	ELSE
----{
		SELECT
			CIF_ID, CUST_TITLE_CODE, CUST_NAME, ADDRESS_TYPE INTO V_CIF_ID, V_CUST_TITLE_CODE, V_CUST_NAME, V_ADDR_TYPE
		FROM
			CMG
			
		WHERE
			CIF_ID = I_FIRST_ARG AND BANK_ID = I_BANK_ID;

----}
	END IF;

-----New Part Added-START

		SELECT
			ADDRESS1,ADDRESS2,PIN_CODE,CITY_CODE,STATE_CODE,CNTRY_CODE
		INTO
			V_ADDR_LINE_1, V_ADDR_LINE_2, V_PIN_CODE, V_CITY_CODE, V_STATE_CODE, V_CNTRY_CODE
		FROM
			CNMA
		WHERE
			ADDR_B2KID = V_CIF_ID AND BANK_ID = I_BANK_ID AND ADDR_ID = V_ADDR_TYPE AND PIN_CODE IS NOT NULL AND CITY_CODE IS NOT NULL AND STATE_CODE IS NOT NULL AND CNTRY_CODE IS NOT NULL;


		-- SELECTING REF DESCRIPTION FOR ADDRESS CODES.

		BEGIN
			SELECT REF_DESC INTO V_REF_DESC_01 FROM RCT
			WHERE REF_REC_TYPE = '01' AND REF_CODE = V_CITY_CODE AND DEL_FLG <> 'Y' AND BANK_ID = I_BANK_ID;
		EXCEPTION
			WHEN OTHERS THEN V_REF_DESC_01 := '*';
		END;

		BEGIN
			SELECT REF_DESC INTO V_REF_DESC_02 FROM RCT
			WHERE REF_REC_TYPE = '02' AND REF_CODE = V_STATE_CODE AND DEL_FLG <> 'Y' AND BANK_ID = I_BANK_ID;
		EXCEPTION
			WHEN OTHERS THEN V_REF_DESC_02 := '*';
		END;

		BEGIN
			SELECT REF_DESC INTO V_REF_DESC_03 FROM RCT
			WHERE REF_REC_TYPE = '03' AND REF_CODE = V_CNTRY_CODE AND DEL_FLG <> 'Y' AND BANK_ID = I_BANK_ID;
		EXCEPTION
			WHEN OTHERS THEN V_REF_DESC_03 := '*';
		END;

		DBMS_OUTPUT.PUT_LINE (V_CIF_ID||'|'||V_CUST_TITLE_CODE||'|'||V_CUST_NAME||'|'||V_ADDR_LINE_1||'|'||V_ADDR_LINE_2||'|'||V_REF_DESC_01||'|'||V_REF_DESC_02||'|'||V_REF_DESC_03||'|'||V_PIN_CODE||'|');

-----New Part Added-END

	IF (I_ACCT_LIST_REQ = 'Y') THEN
	--{
		FOR C1A IN GAM_CUST_ACCTS (V_CIF_ID,I_BANK_ID)
		LOOP
		--{
			DBMS_OUTPUT.PUT_LINE (C1A.FORACID);
		--}
		END LOOP;
	--}
	END IF;
--}
END;
/
spool off

