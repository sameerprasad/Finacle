--===================================================================================================================
--             Filename                :                ccifdownload.sql
--             Description             :                to get data related to customer and cif for downloading
--             Date                    :                23-08-2012
--             Author                  :		Kumar Vishal
--             Menu Option	       :		CAR download
--             Modification History
--		Sl. #           Date             Author             Modification                              
--		-----           -----           --------          ----------------                               
--		   1.0		19/11/2012	Nivedhitha.S	   Chnages for cifdata cron job                       
--===================================================================================================================
rem PAN Number added on 15.06.06 as per ICI5334 by Lalitha R
set serveroutput on size 1000000
set pagesi 0
set linesize 150  
set termout off 
set verify off
set feedback off 
spool ccif.lst

SELECT dc_alias FROM GCT
/
SELECT ltrim(CMG.cif_id)||'|'||
ICICI_AIFT.foracid||'|'||
CMG.cust_name||'|'||
icici_aift.status_flg||'|'||
icici_aift.acct_opn_date||'|'||
GAM.schm_code||'|'|| 
CMG.cust_const||'|'||
GAM.sol_id ||'|'||    
CMG.pan_gir_num
FROM CMG,GAM,ICICI_AIFT
WHERE GAM.cif_id = CMG.cif_id
AND GAM.foracid = ICICI_AIFT.foracid
AND CMG.bank_id = ICICI_AIFT.bank_id 
AND ICICI_AIFT.bank_id = GAM.bank_id 
AND GAM.bank_id = '&1'
/
spool off
