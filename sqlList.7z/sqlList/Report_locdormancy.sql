--------------------------------------------
--File Name   : Report_locdormancy.sql 
--Description : Locker Dormancy report 
--Author      : Priyanka
--Date        : 08-10-2012
------------------------------------------

set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_locdormancy.lst

DECLARE

lv_solid         gam.sol_id%type :='&1';
date1           varchar2(25) := '&2';
date2           varchar2(25) := '&3';
lv_bankid     clmt.bank_id%type := '&4';
v_riskprofile  rct.ref_desc%type;

CURSOR c1 IS

select distinct clmt.sol_id,
       clmt.CIF_ID ref_no,
       wlckm.rack_id,
       clmt.LOCKER_TYPE,
       clmt.locker_num,
       substr(cmg.CUST_NAME,1,40) Hirer_name,
       decode(cmg.CUST_HLTH_CODE , '03', '03', '02' ,'02', '01', '01', '03') risk_profile,
       --(case when cmg.CUST_HLTH_CODE in ('03','02','01') then cmg.CUST_HLTH_CODE else '03' end) risk_profile,
       lcops.CHECK_DATE last_acces_Date,
       substr(wlckm.LCHG_TIME,1,10) Dormant_Since
from   clmt,cmg,wlckm,lcops
where  clmt.sol_id=wlckm.sol_id
and	wlckm.sol_id = lcops.sol_id
and    wlckm.LOCKER_NUM=CLMT.LOCKER_NUM
and    lcops.LOCKER_NO = CLMT.LOCKER_NUM
and     wlckm.LOCKER_NUM = lcops.LOCKER_NO
and    lcops.CIF_ID = CLMT.CIF_ID
and    clmt.CIF_ID = cmg.CIF_ID
and    clmt.sol_id = lv_solid
and    clmt.bank_id = wlckm.bank_id
and    cmg.bank_id = lcops.bank_id
and    clmt.bank_id = lv_bankid
and    wlckm.status='D'
and    wlckm.LCHG_TIME between to_date(date1,'dd-mm-yyyy') and to_date(date2,'dd-mm-yyyy')
and    clmt.del_flg != 'Y'
and    wlckm.del_flg != 'Y'
and    clmt.ENTITY_CRE_FLG = 'Y'
and    wlckm.ENTITY_CRE_FLG = 'Y'
order by 9,8,5;

BEGIN

    for f1 in c1
    loop
        BEGIN
        --{
            SELECT REF_DESC 
            into v_riskprofile 
            FROM RCT 
            WHERE REF_REC_TYPE = '24' 
            AND REF_CODE = f1.risk_profile
            AND DEL_FLG!='Y';
        EXCEPTION WHEN NO_DATA_FOUND THEN
            v_riskprofile := NULL;
        --}
        END;
        v_riskprofile := f1.risk_profile ||'-'||v_riskprofile;
        dbms_output.enable(buffer_size => NULL);    
        dbms_output.put_line(     f1.sol_id             ||'|'||
                                    f1.ref_no             ||'|'||
                                    f1.rack_id            ||'|'||    
                                    f1.LOCKER_TYPE        ||'|'||    
                                    f1.locker_num         ||'|'||
                                    f1.Hirer_name         ||'|'|| 
                                    v_riskprofile       ||'|'||    
                                    f1.last_acces_Date     ||'|'||
                                    f1.Dormant_Since     
                               ); 
   end loop; 
END;
/
spool off

