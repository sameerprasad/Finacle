--=======================================================
-- Author :  Paresh Maru
-- Date   :
-- [Author]         [Date]          [Line]      [Desc]
--=======================================================
--==================================================================================*
-- Source Name       : TradeCreditReport2.sql
-- Author            : Paresh Maru
-- Date              : 
-- Description       : procedure tc2_infoProc_Disb and  tc2_infoProc_Repay   
-- Calling Script    : TradeCreditReport2.com
-- Modification History
--    Sl. --            Date              Author                Modification
--    -----         -----------     ---------------          ----------------
--    01            28-Mar-2012       Swapna Gholap         Added bank id as input
--*==================================================================================*

CREATE OR REPLACE PACKAGE tc2_info AS
PROCEDURE tc2_infoProc_Disb(  inp_str         IN VARCHAR2,
                out_retCode         OUT NUMBER,
                out_rec         OUT VARCHAR2) ;
g_mode_disb        Char(1):= 'S';
PROCEDURE tc2_infoProc_Repay(  inp_str         IN VARCHAR2,
                out_retCode         OUT NUMBER,
                out_rec         OUT VARCHAR2) ;
g_mode_repay        Char(1):= 'S';
END tc2_info;
/
CREATE OR REPLACE PACKAGE BODY tc2_info AS--{
------------------------------------------------------------------------------
TYPE rec_output IS RECORD(record_output  VARCHAR2(2000));
TYPE output_type IS TABLE OF rec_output INDEX BY BINARY_INTEGER;
output_table                            OUTPUT_TYPE;
g_number                                NUMBER;
g_current_row                           BINARY_INTEGER;
v_insert_row                            BINARY_INTEGER;
g_rowcount                              NUMBER;
------------------------------------------------------------------------------
-- GLOBAL VARIABLE
Input_tcno                              VARCHAR2(10);
Input_From_Date                         VARCHAR2(15);
Input_To_Date                           VARCHAR2(15);
Input_Bank_Id				VARCHAR2(8);
------------------------------------------------------------------------------
CURSOR Cur_tc2_disb(Input_tcno number,Input_From_Date VARCHAR2,Input_To_Date VARCHAR2,Input_Bank_Id VARCHAR2)
    IS
SELECT
    SUPPLIERS_CREDIT_REF_NO,
    DC_REF_NO,
    DC_SOL_ID,
    APP_AMT,       
    CRNCY,         
    OPENING_BAL,   
    DISB_AMT,      
    DISB_DATE,     
    BILL_NO,       
    SHIP_DATE,     
    FR_DATE        
FROM    spctc2_disb
where   DISB_DATE between to_date(Input_From_Date,'dd-mm-yyyy') AND to_date(Input_To_Date,'dd-mm-yyyy')
	and bank_id=Input_Bank_Id
	order by to_number(trim(substr(SUPPLIERS_CREDIT_REF_NO,23,9))), DISB_DATE, OPENING_BAL;

CURSOR Cur_tc2_repay(Input_tcno number,Input_From_Date VARCHAR2,Input_To_Date VARCHAR2,Input_Bank_Id VARCHAR2)
    IS
SELECT
    SUPPLIERS_CREDIT_REF_NO,
    DC_REF_NO,              
    DC_SOL_ID,              
    APP_AMT,                
    CRNCY,                  
    OPENING_BAL,            
    REPAY_AMT,              
    REPAY_DATE,                    
    BILL_NO,                
    SHIP_DATE,              
    FR_DATE                
FROM    spctc2_repay
where   REPAY_DATE between to_date(Input_From_Date,'dd-mm-yyyy') AND to_date(Input_To_Date,'dd-mm-yyyy')
	and bank_id=Input_Bank_Id
order by to_number(trim(substr(SUPPLIERS_CREDIT_REF_NO,23,9))), REPAY_DATE;

PROCEDURE tc2_infoProc_Disb(  inp_str         IN VARCHAR2,
                out_RetCode         OUT NUMBER,
                out_rec         OUT VARCHAR2)
IS
OutArr                      basp0099.ArrayType;
v_record_output             VARCHAR2(2000);
-------------------------------------------------------------------
-- Local Variable
loc_srno    VARCHAR2(10);
loc_bor_cat VARCHAR2(5 CHAR);
loc_ship_date	date;
loc_fr_date	date;
loc_princ	VARCHAR2(5 CHAR);
loc_int		VARCHAR2(5 CHAR);
loc_oc		VARCHAR2(5 CHAR);
loc_total	VARCHAR2(5 CHAR);
loc_outstand	VARCHAR2(5 CHAR);
loc_conv_rate	NUMBER(21,10);
loc_APP_AMT		VARCHAR2(20 CHAR);
loc_OPENING_BAL VARCHAR2(20 CHAR);
loc_DISB_AMT	VARCHAR2(20 CHAR);
------------------------------------------------------------------
BEGIN --{
        out_retCode := 0;
        out_rec := '';

        IF g_mode_disb = 'S'  THEN --{
        basp0099.formInputArr(inp_str,OutArr);

            Input_tcno            :=      OutArr(0);
            Input_From_Date     :=      OutArr(1);
            Input_To_Date       :=      OutArr(2);
	    Input_Bank_Id       :=  OutArr(3);
            dbms_output.put_line('TCNO'||Input_tcno);
            dbms_output.put_line('FROM_DATE'||Input_From_Date);
            dbms_output.put_line('TO_DATE'||Input_To_Date);

------------------------------------------------------------------------------

        v_insert_row := 0;

    loc_srno := 0;
    loc_bor_cat := 'PVT';
    loc_princ:= '';
    loc_int:= '';
    loc_oc:= '';
    loc_total:= '';
    loc_outstand:= '';
	loc_conv_rate:= 0;
	loc_APP_AMT:= 0;
	loc_OPENING_BAL:= 0;
	loc_DISB_AMT:= 0;

    For Rec_Cur_Disb    IN Cur_tc2_Disb(Input_tcno,Input_From_Date,Input_To_Date,Input_Bank_Id)
        LOOP                --{

    if(Rec_Cur_Disb.OPENING_BAL is NULL) then
        Rec_Cur_Disb.OPENING_BAL := '0.00';
    end if;

	BEGIN
		SELECT
			CONV_RATE
		INTO
			loc_conv_rate
		FROM
			SPCTC1
		WHERE
			SUPPLIERS_CREDIT_REF_NO = Rec_Cur_Disb.SUPPLIERS_CREDIT_REF_NO;
		EXCEPTION
			when others then
				loc_conv_rate:= 0;
	END;

	BEGIN
	if(Rec_Cur_Disb.CRNCY = 'JPY' ) then
		loc_APP_AMT:= round((to_number(to_char(Rec_Cur_Disb.APP_AMT)) / to_number(to_char(loc_conv_rate))),2);
		if((Rec_Cur_Disb.OPENING_BAL is not null) and (Rec_Cur_Disb.OPENING_BAL != '0')) then
        loc_OPENING_BAL:= round((to_number(to_char(Rec_Cur_Disb.OPENING_BAL)) / to_number(to_char(loc_conv_rate))),2);
		else
		loc_OPENING_BAL:= '0.00';
		end if;
        loc_DISB_AMT:= round((to_number(to_char(Rec_Cur_Disb.DISB_AMT)) / to_number(to_char(loc_conv_rate))),2);
	else
		loc_APP_AMT:= round((to_number(to_char(Rec_Cur_Disb.APP_AMT)) * to_number(to_char(loc_conv_rate))),2);
		loc_OPENING_BAL:= round((to_number(to_char(Rec_Cur_Disb.OPENING_BAL)) * to_number(to_char(loc_conv_rate))),2);
		loc_DISB_AMT:= round((to_number(to_char(Rec_Cur_Disb.DISB_AMT)) * to_number(to_char(loc_conv_rate))),2);
	end if;
	END;

	BEGIN
	if((loc_OPENING_BAL != '0.00') and (loc_OPENING_BAL != '0') and (loc_OPENING_BAL is not NULL)) then
		loc_OPENING_BAL := ltrim(to_char(loc_OPENING_BAL,99999999999.99));
	else
		loc_OPENING_BAL := '0.00';
	end if;
	END;

	BEGIN
		SELECT
			SHPMNT_DATE
		INTO
			loc_ship_date
		FROM
			FEI
		WHERE	BILL_ID = Rec_Cur_Disb.BILL_NO;
	EXCEPTION
		when others then
			loc_ship_date:= '';
	END;
	
	BEGIN
		SELECT
			DUE_DATE
		INTO
			loc_fr_date
		FROM
			FBM
		WHERE	BILL_ID = Rec_Cur_Disb.BILL_NO;
	EXCEPTION
		when others then
			loc_fr_date:= '';
	END;


    loc_srno := loc_srno + 1;

----------------------------------------------------------------------
     v_insert_row:=v_insert_row+1;
---------------------------------------------------------------------------
         v_record_output:=  loc_srno								||'|'||
                            Rec_Cur_Disb.SUPPLIERS_CREDIT_REF_NO	||'|'||
                            ltrim(to_char(loc_APP_AMT,99999999999.99))								||'|'||
			    			loc_OPENING_BAL							||'|'||
			    			ltrim(to_char(loc_DISB_AMT,99999999999.99))							||'|'||
			    			loc_princ								||'|'||
			    			loc_int									||'|'||
			    			loc_oc									||'|'||
			    			loc_total								||'|'||
			    			loc_outstand							||'|'||
			    			loc_ship_date							||'|'||
			    			loc_fr_date;

---------------------------------------------------------------------------
        output_table(v_insert_row).Record_output:=v_record_output;
---------------------------------------------------------------------------

-------------------------------------------------------------------------
        END LOOP;           --}
-------------------------------------------------------------------------

                g_mode_disb := 'G';
                g_rowcount := output_table.Count;
                g_current_row := 0;

                ELSIF g_mode_disb = 'G' THEN --}{
                        g_current_row := g_current_row + 1;
                        IF g_current_row > g_rowcount
                        THEN
                                output_table.delete ;
                                g_current_row := 0;
                                g_rowcount := 0;
                                out_retcode := 1;
                                g_mode_disb := 'S' ;
                                Return ;
                        END IF;
                        out_rec := output_table(g_current_row).record_output;
        END IF; --}
-------------------------------------------------------------------------
END tc2_infoProc_DISB; --}

PROCEDURE tc2_infoProc_Repay(  inp_str         IN VARCHAR2,
                out_RetCode         OUT NUMBER,
                out_rec         OUT VARCHAR2)
IS
OutArr                      basp0099.ArrayType;
v_record_output             VARCHAR2(2000);
-------------------------------------------------------------------
-- Local Variable
loc_srno    VARCHAR2(10);
loc_flno	VARCHAR2(10);
loc_bor_cat VARCHAR2(5 CHAR);
loc_rship_date	date;
loc_rfr_date	date;
loc_rprinc	VARCHAR2(5 CHAR);
loc_rint	VARCHAR2(5 CHAR);
loc_roc		 NUMBER(10,2);
loc_rtotal	VARCHAR2(5 CHAR);
loc_routstand	VARCHAR2(5 CHAR);
loc_disb	VARCHAR2(5 CHAR);
loc_r_conv_rate NUMBER(21,10);
loc_r_APP_AMT	 NUMBER(10,2);
loc_r_OPENING_BAL	 NUMBER(10,2);
loc_r_REPAY_AMT	 NUMBER(10,2);
loc_r_rint	 NUMBER(10,2);
loc_r_rtotal	NUMBER(10,2);
loc_r_routstand	NUMBER(10,2);
------------------------------------------------------------------
BEGIN --{
        out_retCode := 0;
        out_rec := '';

        IF g_mode_repay = 'S'  THEN --{
        basp0099.formInputArr(inp_str,OutArr);

            Input_tcno            :=      OutArr(0);
            Input_From_Date     :=      OutArr(1);
            Input_To_Date       :=      OutArr(2);
	    Input_Bank_Id       :=  OutArr(3);
            dbms_output.put_line('TCNO'||Input_tcno);
            dbms_output.put_line('FROM_DATE'||Input_From_Date);
            dbms_output.put_line('TO_DATE'||Input_To_Date);

------------------------------------------------------------------------------

        v_insert_row := 0;

    loc_srno := 0;
	loc_flno := 1;
    loc_bor_cat := 'PVT';
    loc_disb := '';
    loc_rint := '0.00';
    loc_roc := '0.00';
    loc_routstand := '0.00';
	loc_r_conv_rate := 1;
	loc_r_APP_AMT	:= 0;
	loc_r_OPENING_BAL	:= 0;
	loc_r_REPAY_AMT	:= 0;
	loc_r_rint	:= 0;
	loc_r_rtotal	:= 0;
	loc_r_routstand	:= 0;
	

    For Rec_Cur_Repay    IN Cur_tc2_Repay(Input_tcno,Input_From_Date,Input_To_Date,Input_Bank_Id)
        LOOP                --{

	BEGIN
        SELECT
            CONV_RATE
        INTO
            loc_r_conv_rate
        FROM
            SPCTC1
        WHERE
            SUPPLIERS_CREDIT_REF_NO = Rec_Cur_Repay.SUPPLIERS_CREDIT_REF_NO;
        EXCEPTION
            when others then
                loc_r_conv_rate:= 1;
    END;


	if(Rec_Cur_Repay.OPENING_BAL is NULL) then
		Rec_Cur_Repay.OPENING_BAL := '0.00';
	end if;
	
	BEGIN
		SELECT
			SHPMNT_DATE
		INTO
			loc_rship_date
		FROM
			FEI
		WHERE	BILL_ID = Rec_Cur_Repay.BILL_NO;
	EXCEPTION
		when others then
			loc_rship_date:= '';
	END;
	
	BEGIN
		SELECT
			DUE_DATE
		INTO
			loc_rfr_date
		FROM
			FBM
		WHERE	BILL_ID = Rec_Cur_Repay.BILL_NO;
	EXCEPTION
		when others then
			loc_rfr_date:= '';
	END;

	BEGIN
		SELECT
			sum(INT_AMT)
		INTO
			loc_rint
		FROM
			spctc2_int
		WHERE	INT_BILL_REF_NO = Rec_Cur_Repay.BILL_NO;
	EXCEPTION
		when others then
			loc_rint:= '0.00';
	END;

	BEGIN
		SELECT
			to_number(Rec_Cur_Repay.REPAY_AMT) + to_number(loc_rint) + to_number(loc_roc)
		INTO
			loc_rtotal
		FROM
			DUAL;
	EXCEPTION
		when others then
			loc_rtotal:= '0.00';
	END;

	if((Rec_Cur_Repay.OPENING_BAL = '0.00') or (Rec_Cur_Repay.OPENING_BAL = '0') or (Rec_Cur_Repay.OPENING_BAL is NULL)) then
		BEGIN
			SELECT
				to_number(Rec_Cur_Repay.APP_AMT) - to_number(Rec_Cur_Repay.REPAY_AMT)
			INTO
				loc_routstand
			FROM
				DUAL;
		EXCEPTION
			when others then
				loc_routstand:= '0.00';
		END;
	else
		BEGIN
			SELECT
				to_number(Rec_Cur_Repay.OPENING_BAL) - to_number(Rec_Cur_Repay.REPAY_AMT)
			INTO
				loc_routstand
			FROM
				DUAL;
		EXCEPTION
			when others then
				loc_routstand:= '0.00';
		END;
	end if;

	BEGIN
		if(Rec_Cur_Repay.CRNCY = 'JPY' ) then
			loc_r_APP_AMT:= round((to_number(to_char(Rec_Cur_Repay.APP_AMT)) / to_number(to_char(loc_r_conv_rate))),2);
			if((Rec_Cur_Repay.OPENING_BAL is not null) and (Rec_Cur_Repay.OPENING_BAL != '0')) then
            loc_r_OPENING_BAL:= round((to_number(to_char(Rec_Cur_Repay.OPENING_BAL)) / to_number(to_char(loc_r_conv_rate))),2);
			else
			loc_r_OPENING_BAL:= '0.00';
			end if;
            loc_r_REPAY_AMT:= round((to_number(to_char(Rec_Cur_Repay.REPAY_AMT)) / to_number(to_char(loc_r_conv_rate))),2);
			if(loc_rint is not null) then
            loc_r_rint:= round((to_number(to_char(loc_rint)) / to_number(to_char(loc_r_conv_rate))),2);
			else
			loc_r_rint:= '0.00';
			end if;
			if(loc_rtotal is not null) then
            loc_r_rtotal:= round((to_number(to_char(loc_rtotal)) / to_number(to_char(loc_r_conv_rate))),2);
			else
			loc_r_rtotal:= '0.00';
			end if;
			if(loc_routstand is not null) then
            loc_r_routstand:= round((to_number(to_char(loc_routstand)) / to_number(to_char(loc_r_conv_rate))),2);
			else
			loc_r_routstand:= '0.00';
			end if;
		else
			loc_r_APP_AMT:= round((to_number(to_char(Rec_Cur_Repay.APP_AMT)) * to_number(to_char(loc_r_conv_rate))),2);
			loc_r_OPENING_BAL:= round((to_number(to_char(Rec_Cur_Repay.OPENING_BAL)) * to_number(to_char(loc_r_conv_rate))),2); 
			loc_r_REPAY_AMT:= round((to_number(to_char(Rec_Cur_Repay.REPAY_AMT)) * to_number(to_char(loc_r_conv_rate))),2);
			loc_r_rint:= round((to_number(to_char(loc_rint)) * to_number(to_char(loc_r_conv_rate))),2);
			loc_r_rtotal:= round((to_number(to_char(loc_rtotal)) * to_number(to_char(loc_r_conv_rate))),2);
			loc_r_routstand:= round((to_number(to_char(loc_routstand)) * to_number(to_char(loc_r_conv_rate))),2);
		end if;
	END;

	BEGIN
    if((loc_r_OPENING_BAL != '0.00') and (loc_r_OPENING_BAL != '0') and (Rec_Cur_Repay.OPENING_BAL is not NULL)) then
        loc_r_OPENING_BAL := ltrim(to_char(loc_r_OPENING_BAL,99999999999.99));
    else
        loc_r_OPENING_BAL := '0.00';
    end if;
    END;	

	BEGIN
    if((loc_r_rint != '0.00') and (loc_r_rint != '0') and (loc_r_rint is not NULL)) then
        loc_r_rint := ltrim(to_char(loc_r_rint,99999999999.99));
    else
        loc_r_rint := '0.00';
    end if;
    END;

	BEGIN
    if((loc_r_rtotal != '0.00') and (loc_r_rtotal != '0') and (loc_r_rtotal is not NULL)) then
        loc_r_rtotal := ltrim(to_char(loc_r_rtotal,99999999999.99));
    else
        loc_r_rtotal := '0.00';
    end if;
    END;

	BEGIN
    if((loc_r_routstand != '0.00') and (loc_r_routstand != '0') and (loc_r_routstand is not NULL)) then
        loc_r_routstand := ltrim(to_char(loc_r_routstand,99999999999.99));
    else
        loc_r_routstand := '0.00';
    end if;
    END;

	
    BEGIN
        SELECT
            to_number(loc_r_REPAY_AMT) + to_number(loc_r_rint) + to_number(loc_roc)
        INTO
            loc_r_rtotal
        FROM
            DUAL;
    EXCEPTION
        when others then
            loc_r_rtotal:= '0.00';
    END;

	if((loc_r_OPENING_BAL = '0.00') or (loc_r_OPENING_BAL = '0') or (loc_r_OPENING_BAL is NULL)) then
        BEGIN
            SELECT
                to_number(loc_r_APP_AMT) - to_number(loc_r_REPAY_AMT)
            INTO
                loc_r_routstand
            FROM
                DUAL;
        EXCEPTION
            when others then
                loc_r_routstand:= '0.00';
        END;
    else
        BEGIN
            SELECT
                to_number(loc_r_OPENING_BAL) - to_number(loc_r_REPAY_AMT)
            INTO
                loc_r_routstand
            FROM
                DUAL;
        EXCEPTION
            when others then
                loc_r_routstand:= '0.00';
        END;
    end if;
		

    loc_srno := loc_srno + 1;
	loc_flno := loc_flno + 1;
	BEGIN
		if((loc_r_OPENING_BAL = '0') or (loc_r_OPENING_BAL = '0.00')) then
			loc_flno := 1;
		end if;
	END;
----------------------------------------------------------------------
     v_insert_row:=v_insert_row+1;
---------------------------------------------------------------------------
          v_record_output:= loc_flno								||'|'|| 
							loc_srno								||'|'||
                            Rec_Cur_Repay.SUPPLIERS_CREDIT_REF_NO	||'|'||
                            ltrim(to_char(loc_r_APP_AMT,99999999999.99))							||'|'||
			    			ltrim(to_char(loc_r_OPENING_BAL,99999999999.99))						||'|'||
			    			loc_disb								||'|'||
			    			ltrim(to_char(loc_r_REPAY_AMT,99999999999.99))							||'|'||
			    			ltrim(to_char(loc_r_rint,99999999999.99))								||'|'||
			    			loc_roc									||'|'||
			    			ltrim(to_char(loc_r_rtotal,99999999999.99))							||'|'||
			    			ltrim(to_char(loc_r_routstand,99999999999.99))							||'|'||
			    			loc_rship_date							||'|'||
			    			loc_rfr_date;
---------------------------------------------------------------------------
        output_table(v_insert_row).Record_output:=v_record_output;
---------------------------------------------------------------------------

-------------------------------------------------------------------------
        END LOOP;           --}
-------------------------------------------------------------------------

                g_mode_repay := 'G';
                g_rowcount := output_table.Count;
                g_current_row := 0;

                ELSIF g_mode_repay = 'G' THEN --}{
                        g_current_row := g_current_row + 1;
                        IF g_current_row > g_rowcount
                        THEN
                                output_table.delete ;
                                g_current_row := 0;
                                g_rowcount := 0;
                                out_retcode := 1;
                                g_mode_repay := 'S' ;
                                Return ;
                        END IF;
                        out_rec := output_table(g_current_row).record_output;
        END IF; --}
-------------------------------------------------------------------------
END tc2_infoProc_Repay; --}
END tc2_info; --}
/
DROP SYNONYM  tbaadm.tc2_info
/
CREATE SYNONYM  tbaadm.tc2_info FOR  tc2_info
/
DROP SYNONYM  tbagen.tc2_info
/
CREATE SYNONYM  tbagen.tc2_info FOR  tc2_info
/
DROP SYNONYM  tbautil.tc2_info
/
CREATE SYNONYM  tbautil.tc2_info FOR  tc2_info
/
GRANT EXECUTE ON  tc2_info TO TBAGEN, TBAUTIL, TBAADM
/
