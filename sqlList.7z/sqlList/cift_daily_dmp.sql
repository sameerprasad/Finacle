--===================================================================================================================
--             Filename                :                cif_daily_dmp.sql
--             Description             :                to keep the data in icici-cift-daily before downloading
--             Date                    :                23-08-2012
--             Author                  :		Kumar Vishal
--             Menu Option	       :		CAR download
--             Modification History
--		Sl. #           Date             Author             Modification                              
--		-----           -----           --------          ----------------                               
--		1.0		19/11/2012	Nivedhitha S	    changes for cifdata cron job                          
--===================================================================================================================
rem This sql is written to keep the data in icici-cift-daily before downloading

column suffix new_value suffix

set head off
set feedback off
set trims on
set linesize 1000
set pages 0

SELECT TO_CHAR(sysdate,'ddmmyyyyHH24:MI:SS') suffix FROM dual;

spool &2/cift&1&suffix

SELECT
	cif_id||'|'||
	cust_const||'|'||
	cust_title_code	||'|'||
	cust_name||'|'||
	date_of_birth||'|'||
	minor_flg||'|'||
	guardian_name	||'|'||
	cust_sex||'|'||
	cust_comu_addr1||'|'||
	cust_comu_addr2||'|'||
	cust_comu_city_code||'|'||
	cust_comu_pin_code||'|'||
	cust_comu_phone_num_1||'|'||
	cust_comu_phone_num_2||'|'||
	cust_fax_no||'|'||
	cust_perm_addr1||'|'||
	cust_perm_addr2||'|'||
	cust_perm_city_code||'|'||
	cust_perm_pin_code||'|'||
	cust_perm_phone_num||'|'||
	mothers_maiden_name||'|'||
	household_own_code||'|'||
	number_of_years_at_residence||'|'||
	household_income||'|'||
	occupation_category||'|'||
	employer_category||'|'||
	employed_company||'|'||
	employed_designation||'|'||
	employed_years_of_service||'|'||
	professional_details||'|'||
	nature_of_business||'|'||
	industry_sector||'|'||
	qualification||'|'||
	preference_for_contact||'|'||
	address1_fax_2||'|'||
	address2_telephone_2||'|'||
	address2_fax_1||'|'||
	address2_fax_2||'|'||
	address3_line_1||'|'||
	address3_line_2||'|'||
	address3_city_code||'|'||
	address3_pin_code||'|'||
	address3_telephone_1||'|'||
	address3_telephone_2||'|'||
	address3_fax_1||'|'||
	address3_fax_2 ||'|'||
	email_id||'|'||
	cust_stat_code||'|'||
	cust_pager_no||'|'
FROM ICICI_CIFT_DAILY 
WHERE BANK_ID = '&3'
/
spool off
/
