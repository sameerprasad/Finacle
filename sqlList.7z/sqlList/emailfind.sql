--===================================================================================================================
--Filename             :  emailfind.sql
--Date                 :  04-04-2013
--Author               :  Vaibhav
--Menu Option          :  Cron Job
--Modification History
--    Sl. #             Date             Author             Modification
--    -----            -----            --------           ----------------
--    01              04-04-2013       Vaibhav         Added Bank Id condition
--    02              22-04-2013    Seemantini DOra    BBY CR change(cust_id field changed)
--===================================================================================================================
set head off
set verify off
set feedback off
set trimspool on
set pages 0
set termout off
set lines 320
spool emailid.lst

SELECT email1||','||email2||','||email3||','||email4||','||email5 FROM ICICI_TF_ADVICE WHERE cif_id='&1' AND bank_id='&2'
/
spo off
exit


