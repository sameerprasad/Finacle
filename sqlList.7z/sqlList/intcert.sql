set head off
set pages 0
set trims on
set feedback off
set termout off
set verify off
set serveroutput on size 1000000;
set linesize 500;
spool intcert.&1
declare
	loc_fp                          utl_file.file_type;
	loc_filename                    varchar2(200);
	loc_filepath                    varchar2(100);
	loc_filemode                    varchar(10);
	state_code                      varchar2(50);
	city_code                       varchar2(50);
	cnt                             varchar(1);
    br_name                         varchar(80);
    addr_1						    varchar(50);
    addr_2 							varchar(50);
    city_code1					    varchar(50);
    state_code1 					    varchar(50);
    pin_code					    varchar(6);
	v_check			varchar2(2);

--   CURSOR acct_cur is 
--	select cmg.cust_id,foracid,cust_name,cust_comu_addr1,
--	cust_comu_addr2,cust_comu_city_code, cust_comu_state_code,
--	cust_comu_pin_code,cust_comu_cntry_code,substr(schm_type,1,2) schm_type,primary_sol_id
-- from tbaadm.gam gam,tbaadm.cmg cmg where cmg.cust_id=lpad('&1',9) and gam.cust_id=cmg.cust_id 
-- and gam.acct_crncy_code='INR';

CURSOR acct_cur is 
select c.ADDR_B2KID cust_id,foracid,name,ADDRESS1,
ADDRESS2, CITY_CODE, STATE_CODE,
PIN_CODE,CNTRY_CODE,substr(schm_type,1,2) schm_type,primary_sol_id
from tbaadm.gam g,tbaadm.cnma c, tbaadm.cmg cmg 
where c.ADDR_B2KID='&1' 
and g.cif_id=c.ADDR_B2KID 
and g.cif_id = cmg.cif_id
and g.acct_crncy_code='INR';

CURSOR int_cert(acct tbaadm.gam.foracid%type)  is
select foracid,sum(int_amt) int_amt,sum(recommended_tds_amt) tds_amt
from tbaadm.tds tds, tbaadm.gam gam
where   tds.acid    = gam.acid
and gam.foracid=acct
and tds_cert_num  not like 'DUMMY%'
and processed_flg = 'Y'
and tran_date between '&2' and '&3'
group by foracid
UNION 
	SELECT foracid,sum(I.BASE_AMOUNT) int_amt,
	sum(T.BASE_AMOUNT) tds_amt
	FROM tbaadm.INT_ADM I, tbaadm.INT_ADM T, tbaadm.GAM GAM
	WHERE foracid= acct
	AND T.ACID = I.ACID
	AND I.ACID = GAM.ACID
	AND T.TRAN_ID = I.TRAN_ID
	AND T.TRAN_DATE = I.TRAN_DATE
	AND I.RECORD_TYPE = 'I'
	AND T.RECORD_TYPE = 'T'
	AND I.ENTITY_CRE_FLG = 'Y'
	AND T.ENTITY_CRE_FLG = 'Y'
	AND I.DEL_FLG = 'N'
	AND T.DEL_FLG = 'N'
	and I.tran_date between '&2' and '&3'
	group by foracid
UNION
	SELECT foracid,sum(decode(cr_or_dr_amt_ind,'C',base_amount,0)) int_amt,sum(decode(cr_or_dr_amt_ind,'D',base_amount,0)) tds_amt
	FROM tbaadm.INT_ADM I, tbaadm.GAM GAM,tbaadm.tds tds
	where  foracid=acct
	AND I.ACID = GAM.ACID
	and gam.acid=tds.acid(+)
	AND I.ENTITY_CRE_FLG = 'Y'
	and  not exists(select distinct 1 from tbaadm.int_adm where acid=
	(select acid from tbaadm.gam where foracid=acct)  and record_type='T')
	and not exists(select 1 from tbaadm.tds where acid=(
	select acid from tbaadm.gam where foracid=acct))
	and cr_or_dr_amt_ind in('C','D')
	and record_type='I'
	AND I.DEL_FLG = 'N'
	and I.tran_date between '&2' and '&3'
	and schm_type='SBA'
	group by foracid
 UNION
	SELECT foracid,sum(decode(cr_or_dr_amt_ind,'C',base_amount,base_amount * -1)) int_amt,sum(0) tds_amt
	FROM tbaadm.INT_ADM I, tbaadm.GAM GAM,tbaadm.tds tds
	where  foracid=acct
	AND I.ACID = GAM.ACID
	and gam.acid=tds.acid(+)
	AND I.ENTITY_CRE_FLG = 'Y'
	and  not exists(select distinct 1 from tbaadm.int_adm where acid=
	(select acid from tbaadm.gam where foracid=acct)  and record_type='T')
	and not exists(select 1 from tbaadm.tds where acid=(
	select acid from tbaadm.gam where foracid=acct))
	and cr_or_dr_amt_ind in('C','D')
	and record_type='I'
	AND I.DEL_FLG = 'N'
	and I.tran_date between '&2' and '&3'
	and schm_type='TDA'
	group by foracid
 UNION
	SELECT foracid,sum(decode(cr_or_dr_amt_ind,'C',base_amount,0)) int_amt,sum(decode(cr_or_dr_amt_ind,'D',base_amount,0))tds_amt
	FROM tbaadm.INT_ADM I, tbaadm.GAM GAM
	where  foracid=acct
	AND I.ACID = GAM.ACID(+)
	AND I.ENTITY_CRE_FLG = 'Y'
	and cr_or_dr_amt_ind in('C','D')
	and record_type='I'
	AND I.DEL_FLG = 'N'
	and I.tran_date between '&2' and '&3'
	and schm_type not in('SBA','TDA')
	group by foracid;

BEGIN

	--loc_filepath := '.';
	--	loc_filename := &1||'.dat';
	--	loc_filemode := 'w';
	--loc_fp := utl_file.fopen(loc_filepath, loc_filename, loc_filemode);
	state_code:='';
	city_code:='';
	br_name:='';
	v_check := 'N';
     
	for i in acct_cur
	loop --{ 
		for j in  int_cert(i.foracid)
		loop --{

			v_check := 'Y';
			state_code:='';
			city_code:='';
			br_name:='';

			begin
			select substr(sol_desc,1,80),addr_1,addr_2,city_code,state_code,pin_code into 
			br_name ,addr_1,addr_2,city_code1,state_code1,pin_code 
			from tbaadm.sol where sol_id=i.primary_sol_id;
		        exception when no_data_found then
			br_name := '';
			addr_1 := '';
			addr_2 := '';
			city_code1 := '';
			state_code1 := '';
			pin_code := '';
			end;

			begin
			select ref_desc into state_code from tbaadm.rct where ref_rec_type='02' and ref_code=i.STATE_CODE;
		        exception when no_data_found then
			state_code := '';
			end;
			
			begin
			select ref_desc into state_code1 from tbaadm.rct where ref_rec_type='02' and ref_code=state_code1;
		        exception when no_data_found then
			state_code1 := '';
			end;


			begin
			select ref_desc into city_code from tbaadm.rct where ref_rec_type='01' and ref_code=i.city_code;
		        exception when no_data_found then
			city_code := '';
			end;

			begin
			select ref_desc into city_code1 from tbaadm.rct where ref_rec_type='01' and ref_code=city_code1;
		        exception when no_data_found then
			city_code1 := '';
			end;

			dbms_output.put_line(i.foracid||'|'||i.name||'|'||i.address1||'|'||i.address2);
			dbms_output.put_line('|'||city_code||'|'||state_code||'|'||i.pin_code||'|'||j.tds_amt||'|'||j.int_amt||'|'||i.cust_id||'|'||'&2'||'|'||'&3'||'|'||i.schm_type||'|'||br_name);
			dbms_output.put_line('|'||addr_1||'|'||addr_2||'|'||city_code1||'|'||state_code1||'|'||pin_code); 
			--		dbms_output.put_line(i.foracid||'|'||i.name||'|'||i.address1||'|'||i.address2||'|'||city_code||'|'||state_code||'|'||i.cust_comu_pin_code||'|'||'04-04-2012'||'|'||j.int_amt||'|'||j.tds_amt||'|'||i.cust_id); 
			--		utl_file.put_line(loc_fp, i.foracid||'|'||i.name||'|'||i.address1||'|'||i.address2||'|'||city_code||'|'||state_code||'|'||i.cust_comu_pin_code||'|'||'04-04-2012'||'|'||j.int_amt||'|'||j.tds_amt||'|'||i.cust_id); 
		end loop; --}
	end loop; --}

if ( v_check != 'Y' ) then
dbms_output.put_line('||||||||||||||||||');
end if;



end;
/
spool off
!cp intcert.&1 intcert2.&1
!paste -s -d"\t \n" intcert2.&1 >intcert.&1
!rm intcert2.&1
