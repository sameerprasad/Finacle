--===================================================================================================================
--  Filename                :   smsnewrdacct.sql
--  Description             :
--  Date                    :   06-09-2012
--  Author                  :   Swaroop K Tiruvoipati
--  Menu Option             :
--  Modification History
--    Sl. #           Date           Author                     Modification
--    -----           -----          --------                    ----------------
--    1               06-09-2012     Swaroop K Tiruvoipati      Original Version
--                                                              (Ported from 7.x)
--===================================================================================================================
var solid varchar2(10);

Begin
    :solid := '&1';
End;
/

spool sms_newrdaccount
set serveroutput on size 1000000
declare cursor c1 is
select foracid,acid,schm_code,acct_opn_date,gam.cif_id,clr_bal_amt
from gam 
where sol_id = :solid
and schm_type ='TDA' and schm_code in (select schm_code from tsp where deposit_type = 'R' and del_flg = 'N' and BANK_ID = '&2')
and gam.entity_cre_flg ='Y' and gam.del_flg = 'N' and gam.acct_cls_flg !='Y' 
and acct_opn_date = (select db_stat_date from gct where BANK_ID = '&2') 
and gam.BANK_ID = '&2';


v_repayment_acid	tam.REPAYMENT_ACID%type;
v_deposit_type		tam.deposit_type%type;
v_ffp_acid			tam.REPAYMENT_ACID%type;
v_link_oper_account tam.link_oper_account%type;
mob_num         	ICICI_ALERT_REG.MODE_ID%TYPE;
v_foracid			gam.foracid%type;
v_deposit_amount	tam.deposit_amount%type;

loc_fp utl_file.file_type;
loc_filename                    varchar2(200);
loc_filepath                    varchar2(100);
loc_filemode                    varchar(10);



begin
        loc_filepath := '/mistmp1/Letters';
		loc_filename := 'sms_newrdaccount_'||:solid||'.txt';
		loc_filemode := 'w';
		loc_fp := utl_file.fopen(loc_filepath, loc_filename, loc_filemode);
-- UTL_FILE.PUT_LINE(loc_fp,'DEPT,APPID,MOBILE,DEPTMSGID,FROMDATETIME,TODATETIME,NODELIVERYTIMEFROM,NODELIVERYTIMETO,HTTPMODE,MESSAGE');
for rec in c1
loop
	BEGIN
	BEGIN
		select nvl(REPAYMENT_ACID,'X'),deposit_amount,nvl(link_oper_account,'XX'),deposit_type 
			into v_REPAYMENT_ACID,v_deposit_amount,v_link_oper_account , v_deposit_type
		from tam 
		where acid =rec.acid 
                and BANK_ID = '&2';
	dbms_output.put_line(v_REPAYMENT_ACID||'|'||v_deposit_amount||'|'||v_link_oper_account||'|'||v_deposit_type||'|'||v_deposit_type);
				EXCEPTION WHEN NO_DATA_FOUND THEN
						goto NEXTREC;
		END;
		 if (v_link_oper_account !='XX') then
			dbms_output.put_line(v_link_oper_account);
    				BEGIN
    					select count(acid) into v_ffp_acid from ffp where acid = v_link_oper_account and BANK_ID = '&2';
       				EXCEPTION
       					when no_data_found then
           				v_REPAYMENT_ACID := 'X';
				END;
    				if (v_ffp_acid >=1) then
    					goto NEXTREC;
    				end if;
			dbms_output.put_line(v_ffp_acid);
   		end if;
		if ((v_deposit_type = 'R') or (v_deposit_type = 'T'))  then
			if (v_REPAYMENT_ACID = 'X') then
				BEGIN
					select  acid into v_REPAYMENT_ACID from gam where cif_id = rec.cif_id and schm_type='SBA' and
					entity_cre_flg ='Y' and acct_cls_flg !='Y' and del_flg = 'N' and BANK_ID = '&2' and rownum <2;
					EXCEPTION
						when no_data_found then
							v_REPAYMENT_ACID :='X';
		END;
		end if;
		if ( v_REPAYMENT_ACID  = 'X') then
	  	BEGIN
			select distinct pagerno  INTO mob_num   FROM CRMUSER.DEMOGRAPHIC where orgkey = rec.cif_id and BANK_ID = '&2';
	dbms_output.put_line(v_REPAYMENT_ACID||'|'||v_deposit_amount||'|'||v_link_oper_account||'|'||v_deposit_type);

			EXCEPTION
				when no_data_found then
					mob_num :='AA';
		dbms_output.put_line(rec.schm_code||'|'||rec.foracid||'|'||v_link_oper_account||'|'||v_repayment_acid||'|'||mob_num);
		END;
		end if;
		if ( v_REPAYMENT_ACID != 'X') then
		BEGIN
		     select distinct pagerno  INTO mob_num   FROM CRMUSER.DEMOGRAPHIC where orgkey = rec.cif_id and BANK_ID = '&2';
 dbms_output.put_line(v_REPAYMENT_ACID||'|'||v_deposit_amount||'|'||v_link_oper_account||'|'||v_deposit_type);

       EXCEPTION
               when no_data_found then
                   mob_num :='AA';
       dbms_output.put_line(rec.schm_code||'|'||rec.foracid||'|'||v_link_oper_account||'|'||v_repayment_acid||'|'||mob_num);
       END;
       end if;

	if (mob_num !='AA') then
--	dbms_output.put_line(v_REPAYMENT_ACID||'|'||v_deposit_amount||'|'||v_link_oper_account||'|'||v_deposit_type);
--	dbms_output.put_line(RPVMG,'||'SALFD,'||mob_num||',,,,,,,'||'"Dear Customer, Welcome to ICICI Bank. As requested , your Fixed Deposit Account XXXXXXXX'||substr(rec.foracid,9,4)||' for Rs.'||v_deposit_amount||' has been activated");
-- UTL_FILE.PUT_LINE(loc_fp,'RPVMG,'||'SALFD,'||mob_num||',,,,,,,'||'"Dear Customer, Welcome to ICICI Bank. As applied for, your Recurring Deposit Account XXXXXXXX'||substr(rec.foracid,9,4)||' for Rs.'||v_deposit_amount||' has been activated on '||rec.acct_opn_date||'. TnC apply."');
	if(v_deposit_type = 'R') then
	UTL_FILE.PUT_LINE(loc_fp,'RPVMG,'||'SALFD,'||mob_num||',,,,,,,'||'"Dear Customer, Welcome to ICICI Bank. As applied for, your Recurring Deposit Account XXXXXXXX'||substr(rec.foracid,9,4)||' for Rs.'||v_deposit_amount||' has been activated on '||rec.acct_opn_date||'. TnC apply."');
	end if;
	if(v_deposit_type = 'T') then
	UTL_FILE.PUT_LINE(loc_fp,'RPVMG,'||'SALFD,'||'mob_num'||',,,,,,,'||'"Dear Customer, Welcome to ICICI Bank. As applied for, your Recurring Deposit Account XXXXXXXX'||substr(rec.foracid,9,4)||' for Rs.'||v_deposit_amount||' has been activated on '||rec.acct_opn_date||'. TnC apply."');
	end if;
		end if;
		mob_num := null;
	end if;
	END;
<<NEXTREC>>
	null;
end loop;
end;
/
spool off
