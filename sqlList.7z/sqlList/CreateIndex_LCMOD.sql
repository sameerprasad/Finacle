--Index creation
drop index idx_lcmod
/
create index idx_lcmod
on icici.LOCKER_MODIFICATION
(BANK_ID, SOL_ID,LOCKER_NUM)
storage ( PCTINCREASE 0 )
TABLESPACE ICICI_CUST
/
