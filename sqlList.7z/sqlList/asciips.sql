REM 'THIS SCRIPT CAN BE USED TO GENERATE AN ASCII FILE FOR TRANSACTIONS' 
REM 'PERTAINING TO A PARTY. CAN BE USED BY THE CUSTOMER FOR BANK RECONCILATION'
REM ' ETC. - ALSO ENSURE TO GIVE FORMAT OF ASCII FILE TO CUSTOMER'
REM ' TABLES ACCESSED - EAB AND CTD '
REM ' AUTHOR - M K JAIN, OFFICER, B/O PARLIAMENT STREET, NEW DLEHI'
REM ' DATE - NOV 1992' 
SET PAGESIZE 0
SET LINESIZE 132
SET HEADING OFF
SET FEEDBACK OFF
SET ECHO OFF
SET VERIFY OFF
alter session set nls_date_format = 'DD-MM-YYYY';
rem ACCEPT SOL_ID 	CHAR PROMPT    "ENTER  SOL_ID		      	    : "
rem ACCEPT ACCT_PREFIX CHAR PROMPT "ENTER  ACCT_PREFIX      	    : "
rem ACCEPT ACCT_NUM	   CHAR PROMPT "ENTER  ACCT_NUM         	    : "
rem ACCEPT BEGIN_DATE  CHAR	PROMPT "ENTER  BEGINING DATE (DD-MON-YYYY)  : "
rem ACCEPT END_DATE	   CHAR PROMPT "ENTER  END DATE      (DD-MON-YYYY)  : "
SET TERMOUT OFF
DELETE FROM system.DUMMY
/
DECLARE
	counter         number(5);
	BEGIN_BAL 	NUMBER(14,2);
	TRAN_DATE 	DATE;
	TRAN_PARTICULAR CHAR(50);
	INSTRMNT_NUM    CHAR(8);
	PART_TRAN_TYPE  CHAR;
	TRAN_AMT        NUMBER(14,2);
	PRINT_AMT 	NUMBER(14,2);
	CURSOR GETCTDAMT IS
	SELECT TRAN_DATE,TRAN_PARTICULAR,INSTRMNT_NUM,PART_TRAN_TYPE,TRAN_AMT
	FROM CTD,GAM
	WHERE GAM.foracid = '&1'||'&2'||lpad('&3',6,0) 
	and ctd.ACID = GAM.ACID
	AND   CTD.DEL_FLG       != 'Y'
	AND   TRAN_DATE BETWEEN to_date('&4','dd-mm-yyyy') AND to_date('&5','dd-mm-yyyy') and ctd.bank_id = gam.bank_id and gam.bank_id = '&6'
        ORDER BY 1,2;
BEGIN
BEGIN
	SELECT TRAN_DATE_BAL INTO BEGIN_BAL
	FROM EAB,GAM
	WHERE GAM.foracid = '&1'||'&2'||lpad('&3',6,0) 
	and EAB.ACID = GAM.ACID
        and EAB.bank_ID = GAM.bank_id 
        and bank_id = '&6' 
	AND     EOD_DATE = (
				SELECT 	MAX(EOD_DATE)  
				FROM 	EAB
	WHERE GAM.foracid = '&1'||'&2'||lpad('&3',6,0) 
				and EAB.ACID = GAM.ACID
			        AND 	EOD_DATE <  to_date('&4','dd-mm-yyyy') );
EXCEPTION
	WHEN NO_DATA_FOUND THEN
	BEGIN_BAL := 0 ;
END;
	OPEN GETCTDAMT;
        PRINT_AMT := BEGIN_BAL;
        counter   := 0;
	LOOP
		FETCH GETCTDAMT INTO 
             	TRAN_DATE,TRAN_PARTICULAR,
		INSTRMNT_NUM,PART_TRAN_TYPE,TRAN_AMT;
		EXIT  WHEN GETCTDAMT%NOTFOUND;
                IF PART_TRAN_TYPE = 'C' THEN
                	PRINT_AMT := PRINT_AMT + TRAN_AMT;
                ELSE 
		    	PRINT_AMT := PRINT_AMT - TRAN_AMT;
                END IF;
                counter := counter + 1 ;
		INSERT 	INTO SYSTEM.DUMMY VALUES
		( replace(to_char(counter,'99999'),' ','0') ||
                 TO_CHAR(TO_DATE(TRAN_DATE,'DD-MM-YYYY'),'YYYYMMDD') ||
	  	  NVL(RPAD(TRAN_PARTICULAR,20),'                    ') ||
	  	  NVL(LPAD(INSTRMNT_NUM,8),'        ') ||
	    	  PART_TRAN_TYPE ||
	  	  REPLACE( TO_CHAR (TRAN_AMT,'99999999999.99'),' ','0') ||
	  	  TO_CHAR (PRINT_AMT, '09999999999.99MI')
	 	) ;
	END LOOP;
END; 
/
SPOOL asciips
set pagesize 0
SET LINESIZE 80
set trimspool on
ttitle 'ASCII FILE OF TRANS FOR &2/&3 FROM &4 TO &5'
btitle 'end of file'
SELECT substr(DUMMY,7) FROM SYSTEM.DUMMY 
ORDER BY TO_number(SUBSTR(DUMMY,1,6))
/
SET HEADING ON
SET FEEDBACK ON
SET VERIFY ON
SPOOL OFF
exit
                                                                                                                                                    
