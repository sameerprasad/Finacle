set serveroutput on size 1000000
set verify off
set feedback off
set head off
set termout on
set echo off
--set trims on
set linesize 127

spool SIttumupl1
declare

locTranAmt    NUMBER(20,4) := 0;

Cursor si_reversal_accts is
        select acid,foracid from gam where acid in (select acid from icici_sirev) ;
si_reversal_acctsrec si_reversal_accts%rowtype;

cursor htd_tranid is
select tran_id,tran_date from htd where tran_date = '&1' and acid = si_reversal_acctsrec.acid
and tran_type = 'T' and tran_sub_type = 'SI' and del_flg <> 'Y' and pstd_flg = 'Y' and rpt_code is null;
htd_tranidrec htd_tranid%rowtype;


Cursor si_reversal_trans is
        SELECT rpad(gam.foracid, 16) foracid,
            gam.acct_crncy_code ,
            rpad(htd.sol_id, 8) sol_id,
            decode(sign(0-sum(decode(htd.part_tran_type,'C', -1*htd.tran_amt, htd.tran_amt))), -1,'C','D') part_tran_type,
            lpad(abs(sum(decode(htd.part_tran_type,'C', -1*htd.tran_amt, htd.tran_amt))), 15) tran_amt,
            'REVERSAL OF SI                                                                      ' tran_part
        FROM
            htd, gam
        WHERE
            gam.acid = htd.acid
            and gam.entity_cre_flg = 'Y'
            and gam.del_flg <> 'Y'
            and htd.tran_type = 'T'
            and htd.tran_sub_type = 'SI'
            and htd.rpt_code ='SISO'
            and htd.tran_date = '&1' 
			and htd.tran_id = htd_tranidrec.tran_id
--			and htd.acid =si_reversal_acctsrec.acid
        group by gam.foracid,gam.acct_crncy_code,htd.sol_id;
si_reversal_transrec si_reversal_trans%rowtype;

begin

open si_reversal_accts;
loop
fetch si_reversal_accts into si_reversal_acctsrec;
exit when si_reversal_accts%notfound;


open htd_tranid;
loop
fetch htd_tranid into htd_tranidrec;
exit when htd_tranid%notfound;


	open si_reversal_trans;
	loop
	fetch si_reversal_trans into si_reversal_transrec;
	exit when si_reversal_trans%notfound;

locTranAmt := locTranAmt + si_reversal_transrec.tran_amt;


	end loop;
	close si_reversal_trans; 


	end loop;
	close htd_tranid;

if (locTranAmt >0) THEN
BEGIN
            dbms_output.put_line(rpad(si_reversal_acctsrec.foracid,16)||
							si_reversal_transrec.acct_crncy_code||
							si_reversal_transrec.sol_id||
							'D'||
							lpad(locTranAmt,15)||
							si_reversal_transrec.tran_part);
							END;
							END IF;
locTranAmt :=0;


end loop;
close si_reversal_accts;


end;
/
spool off


