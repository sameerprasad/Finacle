-- #############################################################
-- #	Source Name: charge.sql				   		           #
-- #	Description: This script is used to get the required   #
-- #				 details for ROD related charges           #
-- #				 in ~ seperated format.                    #
-- #############################################################

Set ServerOutPut On Size 1000000
--Set Verify Off
--Set FeedBack off
--set line 80
set trims on

--Spool charge.txt

DECLARE

inpDate				varchar2(25);

-- Temporary variables.
charges				UTL_FILE.FILE_TYPE;
tmpAcid				GAM.acid%type;
acnum				GAM.foracid%type;
clrBal				GAM.clr_bal_amt%type;
principal			GAM.clr_bal_amt%type;
effdate				ROBT.last_adj_value_date%type;
interest			EIT.nrml_interest_amount_dr%type;
penalInt			EIT.penal_interest_amount_dr%type;
latefee				ROBT.late_fee_amt%type;
billAmt				ROBT.bill_amt%type;
stDate				ROBT.stmt_end_date%type;
det_line1			varchar2(1000) := '';
l_bank_id			VARCHAR2(8) := '&2';

CURSOR 	RSP_CURSOR IS 
	SELECT 	gam.acid,foracid,clr_bal_amt
	FROM 	gam,gac
	WHERE 	gam.acid = gac.acid
	AND		gam.schm_code in (	select 	distinct schm_code 
								from 	RSP 
								where 	entity_cre_flg = 'Y'
								and 	del_flg != 'Y')
	AND		gac.dpd_cntr >= 1
	--AND		gam.acct_cls_flg != 'Y'
	AND		gam.entity_cre_flg = 'Y'
	AND		gam.del_flg != 'Y'
	AND	        gam.bank_id = l_bank_id
	AND	        gac.bank_id = l_bank_id
	ORDER BY acid;

BEGIN
--{
	inpDate := '&1';

	charges		:= UTL_FILE.FOPEN('/tmp','ex_breakup_charges.csv','w');

	OPEN RSP_CURSOR;

	LOOP
	--{
		acnum := NULL;
	
		FETCH RSP_CURSOR into tmpAcid,acnum,clrBal;

		EXIT WHEN RSP_CURSOR%NOTFOUND;
		
		IF (acnum is NOT NULL) THEN
		--{
			latefee := 0;
			billAmt := 0;
			interest := 0;
			penalInt := 0;
			stDate := '01-JAN-1900';

			BEGIN
			--{
				SELECT 	stmt_end_date,late_fee_amt,bill_amt
				INTO	stDate,latefee,billAmt
				FROM 	ROBT
				WHERE	acid = tmpAcid
				AND		stmt_end_date =(select	max(stmt_end_date)
										from	ROBT
										WHERE	acid = tmpAcid
										AND	bank_id = l_bank_id)
				AND		lchg_time >= to_date(inpDate,'DD-MM-YYYY HH24:MI:SS')
				AND		bank_id = l_bank_id;
			EXCEPTION 
				WHEN OTHERS THEN 
				latefee := 0;
				billAmt := 0;
				stDate := '01-JAN-1900';
			--}
			END;

			IF (stDate != '01-JAN-1900') THEN
			--{
				BEGIN
				--{
					SELECT 	nvl(nrml_interest_amount_dr,0),nvl(penal_interest_amount_dr,0)
					INTO	interest,penalInt
					FROM 	EIT
					WHERE	entity_id = tmpAcid
					AND		entity_type = 'ACCNT'
					AND		bank_id = l_bank_id;

				EXCEPTION
					WHEN OTHERS THEN 
						interest := 0;
						penalInt := 0;
				--}
				END;

--		***		principal := abs(clrBal) - abs(interest);
				principal := abs(billAmt) - abs(interest) - abs(penalInt);

				det_line1 := acnum||'~~'||abs(latefee)||'~~~'||abs(interest)||'~~~~~~~~~~~~~~~~~~'||abs(principal)||'~~~'||abs(penalInt)||'~~~~';
				UTL_FILE.PUT_LINE(charges,det_line1);
			--}
			END IF;
		--}
		END IF;
	--}
	END LOOP;

	UTL_FILE.FCLOSE(charges);
	CLOSE RSP_CURSOR;
--}
END;
/
exit
--spool off
