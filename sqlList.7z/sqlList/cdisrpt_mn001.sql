-------------------------------------------------------------------------------------------------------------
-- FileName                 : cdisrpt_mn001.sql
-- Author                   : Chokkalingam Lakshmanan
-- Date                     : 16-12-2005
-- Description              : selects the fields corresponding to the inputs
-- Input1                   : From date
-- Input2                   : To date
-- Output                   :
-- Calling Script           : cdisrpt.com
-- Modifications            : None
-------------------------------------------------------------------------------------------------------------
-- ---------------------------------------------
-- Declaration of the package and the Procedure
-- ---------------------------------------------

CREATE OR REPLACE PACKAGE cdisrptpack AS
    PROCEDURE cdisrptproc(inp_str VARCHAR2,
            out_retCode OUT NUMBER,
            out_rec OUT VARCHAR2);

END cdisrptpack;

/

CREATE OR REPLACE PACKAGE BODY cdisrptpack AS
--{
-------------------------------------------------------------------
--Declaring the variables to be used in the Procedure
-------------------------------------------------------------------
outArr          basp0099.ArrayType;
from_date       DATE;
to1_date         DATE;
	
cursor getcdisrptAccts(from_date DATE,to1_date DATE) is
--{

SELECT	REF_NUMBER,
		DOC_CRE_NUM,
		TOT_AMT_CLAIMED_A2,
		TOT_AMT_CLAIMED_A3,
		ISSU_BANK_A1,
		CLAIM_BANK_REF,
		TOT_AMT_CLAIMED_A1,
		RCRE_TIME,
		PRIN_AMT_CLAIMED,
		ADDT_AMT_CLM
FROM	C_742
WHERE	STATUS = 'DISHONOURED'
AND		VRFD_IND = 'Y'
AND		TOT_AMT_CLAIMED_A1 >= from_date 
AND		TOT_AMT_CLAIMED_A1 <= to1_date;

--}


-- --------------------------------------------------------------------
--Procedure body
-- --------------------------------------------------------------------

PROCEDURE cdisrptproc(	inp_str     IN  VARCHAR2,
                      	out_retCode OUT NUMBER,
                     	out_rec     OUT VARCHAR2) AS


	out_arr 				basp0099.ArrayType;
	refNumber				C_742.REF_NUMBER%TYPE;
	docCreNum				C_742.DOC_CRE_NUM%TYPE;
	crncy					C_742.TOT_AMT_CLAIMED_A2%TYPE;
	totAmt					C_742.TOT_AMT_CLAIMED_A3%TYPE;
	issueBank				C_742.ISSU_BANK_A1%TYPE;
	claimBankRefNum			C_742.CLAIM_BANK_REF%TYPE;
	valueDate				C_742.TOT_AMT_CLAIMED_A1%TYPE;
	rcre_date				C_742.RCRE_TIME%TYPE;
	dc_open_bank			C_740.LC_NUM%TYPE;
	prn_amt_claim			C_742.PRIN_AMT_CLAIMED%TYPE;
	add_amt_claim			C_742.ADDT_AMT_CLM%TYPE;

BEGIN
--{
	out_retCode := 0;

---------------------------------------------
-- Checking whether the cursor is open if not
-- it is opened
---------------------------------------------

	IF NOT getcdisrptAccts%ISOPEN THEN
	--{
		basp0099.formInputArr(inp_str,out_arr);
		from_date	:=  to_date(out_arr(0),'dd-mm-yyyy'); 
		to1_date	    :=  to_date(out_arr(1),'dd-mm-yyyy'); 
		OPEN getcdisrptAccts(from_date,to1_date);
	--}
	END IF;


	IF getcdisrptAccts%ISOPEN THEN
	--{
		FETCH	getcdisrptAccts
		INTO	refNumber,
   		 		docCreNum,
				crncy,
				totAmt,
				issueBank,
				claimBankRefNum,
				valueDate,
				rcre_date,
				prn_amt_claim,
				add_amt_claim;
	--}
	END IF;

	totAmt	:=	prn_amt_claim + add_amt_claim;

	IF getcdisrptAccts%NOTFOUND THEN
	--{
		CLOSE getcdisrptAccts;
		out_retCode := 1;
		RETURN;
	--}
	END IF;

	BEGIN
	--{
		SELECT	SWIFT_CODE
		INTO	dc_open_bank
		FROM	C_740
		WHERE	LC_NUM	=	docCreNum
		AND		ROWNUM	<	2;
	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			dc_open_bank	:=	'';
	--}
	END;

	out_rec := 	
	refNumber			||'|'||
    docCreNum			||'|'||
    crncy				||'|'||
    totAmt				||'|'||
    issueBank			||'|'||
    claimBankRefNum		||'|'||
    valueDate			||'|'||
	rcre_date			||'|'||
	dc_open_bank;



END cdisrptproc; 				 --}Procedure ends

END cdisrptpack; 			     --}Package ends

-------------------------------------------------------
-- Execution grants are given to Tbacust Tbautil Tbagen
-------------------------------------------------------
/
DROP PUBLIC SYNONYM cdisrptpack
/
CREATE PUBLIC SYNONYM cdisrptpack FOR cdisrptpack
/
GRANT EXECUTE ON cdisrptpack TO TBAGEN, TBAUTIL, TBACUST
/
show err
