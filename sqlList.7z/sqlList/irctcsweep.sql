-- =====================================================================================================================
-- Source Name            :  irctcsweep.sql
-- Description            :  IRCTC Sweep report
-- Input Values           :  None
-- Output Values          :  None
-- Called Scripts         :  None
-- Calling Scripts        :  irctcsweep.com
-- Modification history:
-- Sl. No            Date                 Author                      Description
-- ---------     --------------    ----------------------        ------------------------------
-- 1.0             23-03-2013             Gauri                   Ported as per 10.x
-- =====================================================================================================================

set echo off verify off feedback off term off pagesi 0 trims on serveroutput on size 1000000 timing off time off
spool irctcsweep 
declare 

cursor AcctList is
SELECT foracid,clr_bal_amt,decode(sign(clr_bal_amt),-1,'C','D') parttran,sol_id FROM GAM 
WHERE sol_id = '0018'
AND bacid IN (
'SLIRCTC0',
'SLIRCTC1',
'SLIRCTC2',
'SLIRCTC3',
'SLIRCTC4',
'SLIRCTC5',
'SLIRCTC6',
'SLIRCTC7',
'SLIRCTC8',
'SLIRCTC9')   AND acct_crncy_code = 'INR'
AND acct_cls_flg = 'N'
AND bank_id = '&1';

contratran varchar2(1) := 'D';

BEGIN

for i in AcctList
LOOP


    dbms_output.put_line(i.foracid||'|'||'INR'||'|'||i.sol_id||'|'||i.parttran||'|'||abs(i.clr_bal_amt)||'|'||
                            'DAY END BALANCE TRF');

    IF ( i.parttran = 'C' )
    THEN
        contratran := 'D';
    ELSE
        contratran := 'C';
    END IF;

    dbms_output.put_line('000705004422'||'|'||'INR'||'|'||'0007'||'|'||contratran||'|'||abs(i.clr_bal_amt)||'|'||
                            'DAY END BALANCE TRF');

END LOOP;
END;
/
spool off
