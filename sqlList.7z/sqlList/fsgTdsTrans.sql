-- -----------------------------------------------------------------------------------#
-- Program Name    : fsgTdsTrans.sql                                                  #
-- Author          : Mandar Raddi                                                     #
-- Date Written	   : 28-Feb-2001                                                      #
--                                                                                    #
-- -----------------------------------------------------------------------------------#
--                                 Version History                                    #
-- -----------------------------------------------------------------------------------#
--   Ver.No |     Date   |    Author    |           Reason For Change                 #
-- -----------------------------------------------------------------------------------#
--     1    | 28-02-2001 | Mandar Raddi | Initial Release                             #
--     2    | 21-01-2013 |Aneesh S      | Changed cif id to cust id                   #
-- -----------------------------------------------------------------------------------#

set serveroutput on size 1000000
set linesize 512
set trims    on
set feedback off
set verify   off
set termout   off
set head     off

alter session set nls_date_format = 'DD-MM-YYYY';

spool &1-&2-&3-&4


DECLARE
	pspListId				PSP_TMP.LISTID%Type;
	--pspIdType				PSP_TMP.ID_TYPE%Type;
	pspIdType				varchar2(2);
	tdsAcid					TDS.ACID%Type;
	tdsCustId				TDS.CUST_ID%Type;
	tdsIntAmt				VARCHAR2(20);
	tdsTdsAmt				VARCHAR2(20);
	tdsTranDate				TDS.TRAN_DATE%Type;
	custSolId				TDS.SOL_ID%Type;
	gamForacid				GAM.FORACID%Type;
	recordType				VARCHAR2(3);
	subRecordType			VARCHAR2(3);
	out_record				VARCHAR2(300);
    endOfPspCursor          NUMBER;
    endOfTdsCursor          NUMBER;
	locFrDate				DATE;
	locToDate				DATE;
	locFinYr 				DATE;
	pspRunId				varchar2(10);

	
	CURSOR PSP_TMP_CURSOR IS
		SELECT
			ENTITY_ID
		FROM
			PSP_TMP
		WHERE
			HOME_SOL_ID = custSolId
		AND LISTID     	= pspListId AND bank_id ='&8';
		--AND ID_TYPE		= pspIdType;


    CURSOR TDS_CURSOR IS
        SELECT
			 ACID
            ,NVL(LTRIM(TO_CHAR(INT_AMT)), '0.00') 
            ,NVL(LTRIM(TO_CHAR(tds_from_org_acct + tds_from_op_acct + tds_from_suspense_acct)), '0.00')
            ,TO_CHAR(TRAN_DATE, 'DD-MM-YYYY')
        FROM
            TDS
        WHERE
            CUST_ID = tdsCustId AND bank_id ='&8'
        AND TRAN_DATE BETWEEN locFrDate AND locToDate
        ORDER BY TRAN_DATE;


    PROCEDURE writeTdsRec( dummy NUMBER ) IS
    BEGIN
		out_record := custSolId||'|'||
                      tdsCustId||'|'||
                      recordType||'|'||
                      subRecordType||'|'||
                      tdsTranDate||'|'||
                      gamForacid||'|'||
                      tdsIntAmt||'|'||
                      tdsTdsAmt;

		DBMS_OUTPUT.PUT_LINE(out_record);
    END;

	PROCEDURE getGamDetails( dummy NUMBER ) IS
	BEGIN
		
		SELECT
			FORACID
		INTO
			gamForacid
		FROM
			GAM
		WHERE
			ACID = tdsAcid AND bank_id ='&8';

		EXCEPTION
			WHEN NO_DATA_FOUND THEN
				NULL;

	END;

	PROCEDURE processTdsCursor( dummy NUMBER ) IS
	BEGIN
       	FETCH TDS_CURSOR
		INTO
		 	 tdsAcid
			,tdsIntAmt
			,tdsTdsAmt
			,tdsTranDate;

		if( TDS_CURSOR%NOTFOUND ) then
			endOfTdsCursor := 1;
			RETURN;
		end if;

		getGamDetails(0);

		writeTdsRec(0);
	END;

	PROCEDURE processPspCursor( dummy NUMBER ) IS
	BEGIN

		FETCH PSP_TMP_CURSOR INTO
			 tdsCustId;

		if( PSP_TMP_CURSOR%NOTFOUND ) then
			endOfPspCursor := 1;
			RETURN;
		end if; 

		OPEN TDS_CURSOR;

		endOfTdsCursor := 0;

		while endOfTdsCursor = 0 LOOP
			processTdsCursor(0);
		END LOOP;

		CLOSE TDS_CURSOR;
	END;

BEGIN
	pspRunId         := '&1';
	custSolId        := '&2';
	pspIdType        := '&4';
	locFrDate        := TO_DATE('&5', 'DD-MM-YYYY');
	locToDate        := TO_DATE('&6', 'DD-MM-YYYY');
	locFinYr         := TO_DATE('&7', 'DD-MM-YYYY');

	pspListId        := pspRunId||custSolId||pspIdType||'C';
	recordType       := '25';
	subRecordType    := '1';

	OPEN PSP_TMP_CURSOR;

    endOfPspCursor := 0;

    WHILE endOfPspCursor = 0 LOOP
        processPspCursor(0);
    END LOOP;

    CLOSE PSP_TMP_CURSOR;

	EXCEPTION
	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('<#ORA-ERROR#>');
		DBMS_OUTPUT.PUT_LINE('Check SQL error,  and try again');
		DBMS_OUTPUT.PUT_LINE('Sql Error Code is        : ' || SQLCODE );
		DBMS_OUTPUT.PUT_LINE('SQL Error Description is : '|| SQLERRM);
END;
/
spool off
