REM####################################################################
REM File Name   : SPCTC2_INT.sql
REM Description : Suppliers Credit Interest Info for TC-2
REM Author      : Paresh Maru
REM Date        : 19-05-2011
REM Module	: Trade Credit
REM####################################################################

REM TABLE NAME: SUP_CR_TC2_INT

REM SYNONYM:    SPCTC2_INT

drop table icici.SUP_CR_TC2_INT
/
drop public synonym SPCTC2_INT
/
create table icici.SUP_CR_TC2_INT
(
Int_Bill_no         VARCHAR2(16 CHAR),
crncy               VARCHAR2(3 CHAR),
Int_Amt             VARCHAR2(30 CHAR),
Int_Rate			VARCHAR2(15 CHAR),
Int_Date            DATE,
Int_Bill_ref_no     VARCHAR2(16 CHAR),
Int_Bill_ref_amt	VARCHAR2(30 CHAR),
ENTITY_CRE_FLG      CHAR(1),
DEL_FLG             CHAR(1),
LCHG_USER_ID        VARCHAR2(15 CHAR),
LCHG_TIME           DATE,
RCRE_USER_ID        VARCHAR2(15 CHAR),
RCRE_TIME           DATE,
bank_id                 VARCHAR2(8 CHAR)
)
/* STORE_START */
TABLESPACE ICICI_CUST_SMALL
/* STORE_END */
/
create public synonym SPCTC2_INT for icici.SUP_CR_TC2_INT
/
grant select, insert, update, delete on SPCTC2_INT to tbagen
/
grant select on SPCTC2_INT to tbacust
/
grant select on SPCTC2_INT to tbautil
/
grant all on SPCTC2_INT to tbaadm
/
