--------------------------------------------
--File Name   : Report_predtallot.sql 
--Description : Pre Dated Allotment Report 
--Author      : Priyanka
--Date        : 06-10-2012
------------------------------------------

set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_predtallot.lst 

DECLARE

lv_solid    gam.sol_id%type := '&1';
fromdate    varchar2(25) := '&2';
todate        varchar2(25) := '&3';
lv_bankid    clmt.bank_id%type :='&4';
hirer_name    varchar2(80);

CURSOR c1 IS
select      clmt.sol_id,
            wlckm.RACK_ID,
            wlckm.LOCKER_TYPE,
            clmt.LOCKER_NUM,
            wlckm.KEY_NUM,
            clmt.CIF_ID,
            clmt.ISSUE_DATE,
            substr(clmt.RCRE_TIME,1,10) upd_date,
            clmt.DUE_DATE,
            clmt.REMARKS remarks
from        clmt,wlckm,cmg
where       clmt.CIF_ID = cmg.CIF_ID
and         wlckm.LOCKER_NUM = clmt.LOCKER_NUM
and         to_date(clmt.ISSUE_DATE) != to_date(substr(clmt.RCRE_TIME,1,10))
and         clmt.RCRE_USER_ID != 'SYSTEM'
and clmt.sol_id = wlckm.sol_id
and         clmt.sol_id = lv_solid
and        clmt.bank_id = wlckm.bank_id
and         cmg.bank_id = clmt.bank_id
and         clmt.bank_id  = lv_bankid
and        to_date(substr(clmt.RCRE_TIME,1,10)) between to_date(fromdate,'dd-mm-yyyy') and to_date(todate,'dd-mm-yyyy')
and        clmt.Del_flg!='Y'
and        wlckm.Del_flg!='Y'
and        cmg.Del_flg!='Y'
ORDER by    7,8,4;

BEGIN

    for f1 in c1

    loop
        BEGIN
    --{
        Select substr(cust_name,1,40) 
        into hirer_name 
        from cmg 
        where CIF_ID = f1.CIF_ID;
        Exception when no_data_found then
        hirer_name:=null;
    --}
    END;
    dbms_output.enable(buffer_size => NULL);    
    dbms_output.put_line( f1.sol_id         ||'|'||
                  f1.rack_id        ||'|'||
                  f1.locker_type    ||'|'||
                  f1.locker_num     ||'|'||
                  f1.KEY_NUM        ||'|'||
                  hirer_name        ||'|'||
                  f1.CIF_ID        ||'|'||
                  f1.ISSUE_DATE        ||'|'||
                f1.upd_date        ||'|'||
                  f1.DUE_DATE        ||'|'||
                  f1.remarks
            ); 
   end loop; 
END;
/
spool off

