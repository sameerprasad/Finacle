-- #############################################################
-- #	Source Name: acctLnMast.sql				   		       #
-- #	Description: This script is used to get the required   #
-- #				 details for ROD account                   # 
-- #				 in ~ seperated format.                    #
-- #############################################################

Set ServerOutPut On Size 1000000
--Set Verify Off
--Set FeedBack off
--set line 80
set trims on

--Spool acctLnMast.txt

DECLARE

-- Temporary variables.
acctmast			UTL_FILE.FILE_TYPE;
lnmaster			UTL_FILE.FILE_TYPE;
tmpAcid				GAM.acid%type;
acnum				GAM.foracid%type;
solId				GAM.sol_id%type;
cimnumb				CRMUSER.CMG.cif_id%type;
begdybal			EAB.tran_date_bal%type;
origbal				EAB.tran_date_bal%type;
acClsDt				GAM.acct_cls_date%type;
colbal				GAM.clr_bal_amt%type;
acCrncy				GAM.acct_crncy_code%type;
acOpnDt				GAM.acct_opn_date%type;
asOnDt				GAM.acct_opn_date%type;
accrDr				EIT.nrml_accrued_amount_dr%type;
totAccr				EIT.nrml_accrued_amount_dr%type;
ntdintpd			EIT.nrml_interest_amount_dr%type;
accttype			number := 999;
collflg				number := 0;
crncy				number(1) := 1;
cyclecode   		varchar2(2) := '00';
det_line1			varchar2(1000) := '';
schmCode			GAM.schm_code%type;
duedate				ROBT.payment_due_date%type;
intbilled			ROBT.accr_int_amt%type;
lstpayamt			ROBT.last_tran_amt%type;
lstpibilled			ROBT.bill_amt%type;
ntdprnpd 			ROBT.tot_adj_amt%type;
lastpaydt 			ROBT.last_adj_value_date%type;
ntdlatpd 			ROBT.late_fee_amt%type;
nxtbillDt			ROBT.bill_gen_date%type;
matdate				LHT.lim_exp_date%type;
limit				LHT.sanct_lim%type;
appDate				LHT.applicable_date%type;
accrustat			number := 0;
class				number := 0;
extncnt				number := 0;
renewcnt			number := 0;
termdays			number := 0;
term				number := 0;
loanpurp			number := 0;
branch				varchar2(6);
acClsCh				varchar2(10);
acOpnCh				varchar2(10);
dueChar				varchar2(10);
matChar				varchar2(10);
appChar				varchar2(10);
lstpayChar			varchar2(10);
nxtbillChar			varchar2(10);
det_line2			varchar2(1000) := '';
l_bank_id			VARCHAR2(8) := '&1';

CURSOR 	RSP_CURSOR IS 
	SELECT 	gam.acid,cust_id,foracid,sol_id,
			acct_cls_date,clr_bal_amt,acct_crncy_code,
			acct_opn_date,gam.schm_code
	FROM 	gam,gac
	WHERE 	gam.acid = gac.acid
	AND		gam.schm_code in (	select 	distinct schm_code 
								from 	RSP 
								where 	entity_cre_flg = 'Y'
								and 	del_flg != 'Y')
	AND		gac.dpd_cntr >= 1
	AND		gam.entity_cre_flg = 'Y'
	AND		gam.del_flg != 'Y'
	AND	        gam.bank_id = l_bank_id
	AND	        gac.bank_id = l_bank_id;


BEGIN
--{
	acctmast		:= UTL_FILE.FOPEN('/tmp','ex_acctmast.csv','w');
	lnmaster		:= UTL_FILE.FOPEN('/tmp','ex_lnmaster.csv','w');

	OPEN RSP_CURSOR;

	LOOP
	--{
		acnum := NULL;
		cimnumb := NULL;
		solId := NULL;
		acClsDt := NULL;
		acCrncy := NULL;
		acOpnDt := NULL;
		cyclecode := '00';
		collflg := 0;
		colbal := 0;
		origbal := 0;
		accrDr := 0;
		totAccr:= 0;
	
		FETCH RSP_CURSOR into 	tmpAcid,cimnumb,acnum,
								solId,acClsDt,colbal,
								acCrncy,acOpnDt,schmCode;

		EXIT WHEN RSP_CURSOR%NOTFOUND;
		
		BEGIN
		--{
			SELECT 	db_stat_date
			INTO	asOnDt
			FROM 	GCT
			WHERE	BANK_ID = l_bank_id;

		EXCEPTION
			WHEN OTHERS THEN NULL;
		--}
		END;
	
		IF (acnum is NOT NULL) THEN
		--{	
			BEGIN
			--{
				SELECT 	tran_date_bal
				INTO	begdybal
				FROM 	EAB
				WHERE	acid = tmpAcid
				AND		eod_date <= asOnDt
				AND		end_eod_date >= asOnDt
				AND		BANK_ID = l_bank_id;

			EXCEPTION
				WHEN OTHERS THEN begdybal := 0;
			--}
			END;

			BEGIN
			--{
				SELECT 	tran_date_bal
				INTO	origbal
				FROM 	EAB
				WHERE	acid = tmpAcid
				AND		eod_date <= acOpnDt
				AND		end_eod_date >= acOpnDt
				AND		BANK_ID = l_bank_id;

			EXCEPTION
				WHEN OTHERS THEN origbal := 0;
			--}
			END;

			BEGIN
			--{
				SELECT 	1
				INTO	collflg
				FROM	DUAL
				WHERE	EXISTS(	SELECT 	acid
								FROM 	SDR
								WHERE	secu_linkage_type = 'A'
								AND		acid = tmpAcid
								AND		entity_cre_flg = 'Y'
								AND		del_flg != 'Y');

			EXCEPTION
				WHEN OTHERS THEN collflg := 0;
			--}
			END;

			BEGIN
			--{
				SELECT 	nrml_accrued_amount_dr,(nrml_accrued_amount_dr + penal_accrued_amount_dr),nrml_interest_amount_dr
				INTO	accrDr,totAccr,ntdintpd
				FROM 	EIT
				WHERE	entity_id = tmpAcid
				AND		entity_type = 'ACCNT'
				AND		BANK_ID = l_bank_id;

			EXCEPTION
				WHEN OTHERS THEN 
					accrDr := 0;
					totAccr:= 0;
					ntdintpd := 0;
			--}
			END;

			BEGIN
			--{
				SELECT 	nvl(to_char(status_date,'dd'),'00')
				INTO	cyclecode
				FROM 	DCHT
				WHERE	acid = tmpAcid
				AND		status_date = (	SELECT 	max(status_date)
										FROM	DCHT 
										WHERE	acid = tmpAcid
										AND	bank_id = l_bank_id)
				AND	BANK_ID = l_bank_id;

			EXCEPTION
				WHEN OTHERS THEN 
					cyclecode := '00';
			--}
			END;

			if (acCrncy = 'INR') then
				crncy := 1;
			elsif (acCrncy = 'USD') then
				crncy := 2;
			elsif (acCrncy = 'GBP') then
				crncy := 3;
			elsif (acCrncy = 'DEM') then
				crncy := 4;
			end if;
	
			begin
			--{
				select	to_char(acOpnDt,'mm-dd-yyyy'),to_char(acClsDt,'mm-dd-yyyy')
				into	acOpnCh,acClsCh
				from	DUAL;
			exception
				WHEN OTHERS THEN NULL;
			--}
			end;

--		Schm code changed to HMOAD ... onsite 
			if (schmCode = 'HMOAD') then
				class := 1;
			elsif (schmCode = 'CAROD') then
				class := 2;
			elsif (schmCode = 'REVOD') then
				class := 3;
			elsif (schmCode = 'RVOD1') then
				class := 4;
			elsif (schmCode = 'REVEI') then 
				class := 5;
			else
				class := 6;
			end if;
			
--***		det_line1 := acnum||'~'||accttype||'~~'||begdybal||'~'||solId||'~'||cimnumb||'~'||class||'~'||acClsCh||'~'||colbal||'~'||collflg||'~0~'||crncy||'~'||acOpnCh||'~'||accrDr||'~0~'||origbal||'~~1~0~'||totAccr||'~'||cyclecode;
			det_line1 := acnum||'~'||accttype||'~~'||abs(begdybal)||'~'||solId||'~'||cimnumb||'~'||class||'~'||acClsCh||'~'||abs(colbal)||'~'||collflg||'~'||crncy||'~'||acOpnCh||'~'||abs(accrDr)||'~0~'||abs(origbal)||'~~1~0~'||abs(totAccr)||'~'||cyclecode;
			UTL_FILE.PUT_LINE(acctmast,det_line1);

--  	***	Confirmed accrustat = 0 ***

			duedate := NULL;
			intbilled := 0;
			lstpayamt := 0;
			lstpibilled := 0;
			ntdprnpd := 0;
			extncnt := 0;
			matdate := NULL;
			limit := 0;
			termdays := 0;
			ntdlatpd := 0;
			appDate := NULL;
			lastpaydt := NULL;
			
			BEGIN
			--{
				SELECT 	payment_due_date,abs(nvl(accr_int_amt,0)),last_tran_amt,nvl(bill_amt,0),nvl(tot_adj_amt,0),last_adj_value_date
				INTO	duedate,intbilled,lstpayamt,lstpibilled,ntdprnpd,lastpaydt
				FROM 	ROBT
				WHERE	acid = tmpAcid
				AND		stmt_end_date =(SELECT	max(stmt_end_date)
										FROM    ROBT
										WHERE   acid = tmpAcid
										AND	bank_id = l_bank_id)
				AND	bank_id = l_bank_id;

			EXCEPTION
				WHEN OTHERS THEN 
					duedate := NULL;
					intbilled := 0;
					lstpayamt := 0;
					lstpibilled := 0; 
					ntdprnpd := 0;
					lastpaydt := NULL;
			--}
			END;

			BEGIN
			--{
				SELECT 	serial_num,lim_exp_date,sanct_lim,applicable_date
				INTO	extncnt,matdate,limit,appDate
				FROM 	LHT
				WHERE	acid = tmpAcid
				AND		serial_num = (	SELECT 	max(serial_num)
										FROM	LHT
										WHERE   acid = tmpAcid
										and     status = 'A'
										AND     entity_cre_flg = 'Y'
										AND     del_flg != 'Y'
										AND	bank_id = l_bank_id
				AND	bank_id = l_bank_id);
			EXCEPTION
				WHEN OTHERS THEN NULL;
			--}
			END;

			BEGIN
			--{
				SELECT 	to_date(matdate,'dd-mm-yyyy') - to_date(acOpnDt,'dd-mm-yyyy')
				INTO	termdays
				FROM 	DUAL;
			EXCEPTION
				WHEN OTHERS THEN termdays := 0;
			--}
			END;

			term := round(termdays/30);

			BEGIN
			--{
				SELECT 	nvl(sum(late_fee_amt),0),max(bill_gen_date)
				INTO	ntdlatpd,nxtbillDt
				FROM 	ROBT
				WHERE	acid = tmpAcid
				AND	bank_id = l_bank_id;
			EXCEPTION
				WHEN OTHERS THEN 
					ntdlatpd := 0;
					nxtbillDt := NULL;
			--}
			END;

--		Purpose of OD is assumed to be HOUSE(HMOAD)...to be modified if reqd 
			loanpurp := 2;
			
			renewcnt := extncnt;

			begin
			--{
				select	to_char(duedate,'mm-dd-yyyy'),to_char(matdate,'mm-dd-yyyy'),to_char(appDate,'mm-dd-yyyy'),to_char(lastpaydt,'mm-dd-yyyy'),to_char(nxtbillDt,'mm-dd-yyyy')
				into	dueChar,matChar,appChar,lstpayChar,nxtbillChar
				from	DUAL;
			exception
				WHEN OTHERS THEN NULL;
			--}
			end;

			det_line2 := accrustat||'~'||acnum||'~'||abs(colbal)||'~'||class||'~2~~~'||dueChar||'~'||extncnt||'~'||intbilled||'~'||limit||'~'||loanpurp||'~'||abs(lstpayamt)||'~'||lstpayChar||'~'||lstpibilled||'~'||appChar||'~'||matChar||'~'||abs(ntdintpd)||'~'||abs(ntdlatpd)||'~'||abs(ntdprnpd)||'~'||nxtbillChar||'~~~~'||renewcnt||'~'||appChar||'~'||term||'~'||termdays||'~0';
			UTL_FILE.PUT_LINE(lnmaster,det_line2);
		--}
		END IF;
	--}
	END LOOP;

	UTL_FILE.FCLOSE(acctmast);
	UTL_FILE.FCLOSE(lnmaster);
	CLOSE RSP_CURSOR;
--}
END;
/
--exit
--spool off
