set serveroutput on size 1000000
set feedback off
set verify   off
set termout   off
set pages 0
set linesize 512
set trims on
spool /tmp/&1


DECLARE

acid			gam.acid%type;
foracid			gam.foracid%type;
cust_id			gam.cust_id%type;
custid			gam.cust_id%type;
subRecType		varchar(30);
acctType		varchar(30);
acct_cls_flg 		gam.acct_cls_flg%type;
acct_cls_date 		gam.acct_cls_date%type;
acct_crncy_code		gam.acct_crncy_code%type;
ciftEmailId		ICICI_CIFT.EMAIL_ID%type;
locTranDateBal      	EAB.tran_date_bal%TYPE;
nomsumflg               varchar2(2);
smtflg                  number;
trfInDt			varchar(20);
cityDesc                RCT.ref_desc%TYPE;
stateDesc               RCT.ref_desc%TYPE;
cntryDesc               RCT.ref_desc%TYPE;
email_id                VARCHAR2(50);
phone_num1 	        VARCHAR2(15);
phone_num2		VARCHAR2(15);
homeSol                	PSP_TMP.home_sol_id%TYPE;
entity_id               PSP_TMP.entity_id%TYPE;
hcmgCustStatCode	cmg.cust_stat_code%type;
PAN_GIR_NUM		cmg.PAN_GIR_NUM%type;
rmname            	varchar2(50);
rmemail           	varchar2(70);
rmmob             	varchar2(12);
csmname            	varchar2(50);
csmemail           	varchar2(70);
csmmob             	varchar2(12);
cnt1               	varchar2(2);
mulcnt             	varchar2(2);
lacid			gam.acid%type;
dbforAcid          	varchar2(16);
dbcrncy            	varchar2(10);
cnt                	number;
cramt              	number;
dramt              	number;
balAmt			number;
recCnt			varchar2(7);
tamt               	varchar2(32);
TRAN_PARTICULAR		htd.TRAN_PARTICULAR%type;
TRAN_DATE		htd.TRAN_DATE%type;
VALUE_DATE		htd.VALUE_DATE%type;
part_type		htd.PART_TRAN_TYPE%type;
TRAN_AMT		htd.TRAN_AMT%type;
tran_type		htd.TRAN_AMT%type;
INSTRMNT_NUM		htd.INSTRMNT_NUM%type;
TRAN_ID			htd.TRAN_ID%type;
loc_fp          	utl_file.file_type;
loc_filename    	varchar2(200);
loc_filepath    	varchar2(100);
loc_filemode    	varchar2(100);
outLine         	varchar2(20000);
opBal              	number;
bankCode    		sol.bank_code%TYPE;
brCode      		sol.bank_code%TYPE;
brPrtcls    		varchar2(400);
f_date			date;		
t_date			date;	
segment                 icici_cust_seg.SEGEMENT%TYPE;
htdCnt			number;
trfFlg 			varchar2(4);
tmpDt 			date;
opnDt 			date;
br_sol_id  		sol.STATE_CODE%TYPE;
br_name			bct.br_name%type;
br_addr_1		bct.br_addr_1%type;
br_addr_2		bct.br_addr_2%type;
br_pin_code		bct.br_pin_code%type;
br_city_code		sol.CITY_CODE%TYPE;
br_state_code		sol.STATE_CODE%TYPE;
br_cityDesc		RCT.ref_desc%TYPE;
br_stateDesc		RCT.ref_desc%TYPE;


CURSOR gamCur IS
SELECT  gam.acid,foracid,sol_id,cust_id,decode(substr(foracid, 5, 2),'18', '2','5') subRecType,decode(substr(foracid, 5, 2),'18', 'Public Provident Fund (PPF)Scheme,1968','Other') acctType,acct_cls_flg ,acct_cls_date ,acct_crncy_code,NOM_AVAILABLE_FLG,acct_opn_date,clr_bal_amt
FROM    GAM,PPFCFG
WHERE   SOL_ID = '&1'
AND     ACCT_PREFIX = '18'
AND     SCHM_CODE = 'SBPPF' and GAM.SCHM_CODE = PPFCFG.PPFSBAPRODUCT_CODE
AND     ((ACCT_CLS_FLG = 'N' AND ACCT_OPN_DATE <= '&3') OR
         (ACCT_CLS_FLG = 'Y' AND ACCT_CLS_DATE > '&3'))
AND     acct_crncy_code is not null
AND     del_flg != 'Y'
AND     acct_ownership != 'O'
and     GAM.bank_id='&4'
and     PPFCFG.bank_id='&4'
AND     ENTITY_CRE_FLG = 'Y' order by foracid;


CURSOR cmgCur (cust_id in varchar2) IS
SELECT  CMG.CUST_TITLE_CODE || '.' || NAME cname,
		ADDRESS1,
		ADDRESS2,
		CITY_CODE,
		STATE_CODE,
		CNTRY_CODE,
		PIN_CODE,
		PHONE_NUM1,
		PHONE_NUM2,
		EMAIL_ID,
		CUST_STAT_CODE,
		CUST_CONST,
		CUST_NRE_FLG,
		PAN_GIR_NUM
FROM	CMG,CNMA
WHERE	cust_id = custid
AND ADDR_B2KID=CIF_ID
and cmg.bank_id='&4'
and cnma.bank_id='&4';

CURSOR htdCur(acid in GAM.foracid%TYPE) is 

SELECT 	TRAN_ID,NVL(to_char(TRAN_DATE),'*') tran_date ,NVL(to_char(VALUE_DATE),'*') VALUE_DATE,NVL(to_char(TRAN_AMT),'0.00') tran_amt,NVL(to_char(TRAN_PARTICULAR),'*') TRAN_PARTICULAR,NVL(to_char(INSTRMNT_NUM),'*') INSTRMNT_NUM,NVL(PART_TRAN_TYPE,' ') part_type
from 	HTD 
where 	acid = lacid 
and 	DEL_FLG= 'N' 
and 	tran_date between '&2' and '&3'
and     bank_id='&4' 
order by to_date(tran_date,'DD-MM-YYYY'),pstd_date,tran_id;



BEGIN


--f_date := &2;
--t_date := &3;

 	loc_filepath := '/mistmp';
  	--loc_filename := 'PPFSTMT.txt';
  	loc_filename := 'PPF-'||'&1'||'.lst';
   	loc_filemode := 'w';
        loc_fp := utl_file.fopen(loc_filepath, loc_filename, loc_filemode);


	--utl_file.put_line(loc_fp,'starts');

cnt := 0;

			begin
	 		SELECT  sol_id, br_name, br_addr_1 , br_addr_2 , br_pin_code, sol.CITY_CODE, sol.STATE_CODE
			INTO	br_sol_id , 
					br_name,
					br_addr_1,
					br_addr_2,
					br_pin_code,
					br_city_code,
					br_state_code
		   	FROM    BCT,SOL
		    	WHERE   sol_id = '&1'
			AND     bct.bank_code = SOL.bank_code
			AND     bct.br_code= sol.br_code
			AND     sol.del_flg !='Y'
			and     sol.bank_id='&4'
		        and	BCT.bank_id='&4';

			EXCEPTION
		    		when NO_DATA_FOUND then NULL;
			end;

		--DBMS_OUTPUT.PUT_LINE(br_city_code);
		--DBMS_OUTPUT.PUT_LINE(br_state_code);
		begin

         		if (br_city_code is not null) then
         		BEGIN
                		SELECT  ref_desc
                		INTO    br_cityDesc
                		FROM    RCT
                		WHERE   ref_rec_type = '01'
				and     bank_id='&4'	
                		AND     ref_code = br_city_code;
                		EXCEPTION WHEN OTHERS THEN NULL;
        		END;
        		else br_cityDesc := '';
        		end if;


        		if (br_state_code is not null) then
        		BEGIN
                		SELECT  ref_desc
                		INTO    br_stateDesc
                		FROM    RCT WHERE   ref_rec_type = '02'
                		AND     ref_code = br_state_code
				and     bank_id='&4';
                		EXCEPTION WHEN OTHERS THEN NULL;
        		END;
        		else br_stateDesc := '';
        		end if;
 		end;


			outLine := br_sol_id|| '|         |00|0|' || 
					   br_name || '|' ||
					   br_addr_1 || '|' ||
					   br_addr_2 || '|' ||
					   br_pin_code || '|' ||
					   'CustomerStateMent |' ||
						br_cityDesc|| '|' ||
						br_stateDesc|| '| ||||'; 

		--		--DBMS_OUTPUT.PUT_LINE(outLine);



			utl_file.put_line(loc_fp,outLine);

	for g1 in gamCur
	loop
	--{

		custid := g1.cust_id;
		lacid  := g1.acid;
		locTranDateBal := 0;

		begin
			SELECT  tran_date_bal INTO    locTranDateBal FROM    EAB WHERE   acid = g1.acid AND     eod_date <= '&3'  AND     end_eod_date >= '&3' and bank_id='&4';
			EXCEPTION  When no_data_found Then
			locTranDateBal := 0;
		end;

		begin
			SELECT  count(1) INTO    htdCnt FROM    HTD WHERE   acid = g1.acid AND   tran_date between '&2' and '&3' and bank_id='&4';
			EXCEPTION  When no_data_found Then
			htdCnt := 0;
		end;	

--DBMS_OUTPUT.PUT_LINE(locTranDateBal);
--DBMS_OUTPUT.PUT_LINE(htdCnt);

if  ( (locTranDateBal != 0 )  and (htdCnt != 0) ) then
--{
		

		begin
			select HOME_SOL_ID,EMAIL_ID  into homeSol,ciftEmailId  from icici_cift where cust_id = g1.cust_id and bank_id='&4';
			EXCEPTION WHEN OTHERS THEN NULL;
		end;

		begin
			select NVL(to_char(TRANSFER_IN_DATE),'NA') into trfInDt from pfam where foracid=g1.foracid and TRFS_MODE_FLG = 'Y' and bank_id='&4';
			 EXCEPTION  When no_data_found Then
			 trfInDt := 'NA';
		end; 
		----DBMS_OUTPUT.PUT_LINE(trfInDt);


		
		for c1 in cmgCur(custid)
		loop
		--{


			begin 

				 if (c1.CITY_CODE is not null) then
				 BEGIN
				 	SELECT  ref_desc 
					INTO    cityDesc
					FROM    RCT
					WHERE   ref_rec_type = '01' 
					AND     ref_code = c1.CITY_CODE
					and bank_id='&4';
					EXCEPTION WHEN OTHERS THEN NULL; 
				END; 
				else cityDesc := ''; 
				end if; 


				if (c1.STATE_CODE is not null) then 
				BEGIN 
					SELECT  ref_desc 
					INTO    stateDesc 
					FROM    RCT WHERE   ref_rec_type = '02' 
					AND     ref_code = c1.STATE_CODE
					and bank_id='&4'; 
					EXCEPTION WHEN OTHERS THEN NULL;
				END; 
				else stateDesc := ''; 
				end if; 
				
				if (c1.CNTRY_CODE is not null) then 
				BEGIN 
					SELECT  ref_desc 
					INTO    cntryDesc 
					FROM    RCT 
					WHERE   ref_rec_type = '03' 
					and bank_id='&4'
					AND     ref_code = c1.CNTRY_CODE; 
					EXCEPTION WHEN OTHERS THEN NULL; 
				END; 
				else 
				cntryDesc := ''; 
				end if; 
			end;

			if (c1.phone_num1 is not null) then
				phone_num1 := c1.phone_num1;
			else
				phone_num1 := '*';
			end if;

			if (c1.phone_num2 is not null) then
				phone_num2 := c1.phone_num2;
			else
				phone_num2 := '*';
			end if;


			begin
			    --select substr(SEGEMENT,instr(SEGEMENT,'|')+1) into segment from ICICI_CUST_SEG where CUST_ID = g1.cust_id;
				 select SEGEMENT into segment from ICICI_CUST_SEG where CUST_ID = g1.cust_id and bank_id='&4';
				 	exception
				 	when no_data_found THEN
				 	segment := 'GB';
			end;

			if ( (segment = 'PB|GS') or (segment = 'Z|GS') or (segment = 'Z|TS') or (segment = 'PB|TS')) then
			    segment := 'PB';
			else

				if ((segment = 'GPC|GPC') or (segment = 'Z|GPC')) then
		        	segment := 'GPC';
			else

				if (( segment = 'WM|WS') or (segment = 'WM|Z')) then
		        	segment := 'WM';
			else
	        		segment := 'GB';
			end if;
			end if;
			end if;


			--DBMS_OUTPUT.PUT_LINE(g1.cust_id);
			--DBMS_OUTPUT.PUT_LINE(segment);

			--final


			outLine := g1.sol_id||	'|'
				|| g1.cust_id||	'|'	
				||'01|0|'	|| 
				ciftEmailId||	'|'	
				|| c1.cname||		'|'	
				|| c1.ADDRESS1||	'|'	
				|| c1.ADDRESS2
				||	'|'	|| cityDesc||		'|'		
				|| stateDesc||	'|'	
				|| cntryDesc||	'|'	
				|| c1.PIN_CODE||'|'	
				|| c1.cust_stat_code
				||  '|'     || PHONE_NUM1|| '-' ||PHONE_NUM2 || '|'     || g1.foracid|| '|'     ||segment;

			utl_file.put_line(loc_fp,outLine);



			-- RMCSM
				hcmgCustStatCode := c1.cust_stat_code;
				--DBMS_OUTPUT.PUT_LINE(hcmgCustStatCode);

				if  (hcmgCustStatCode = 'HNI' or hcmgCustStatCode = 'HNM'  or hcmgCustStatCode = 'HNIMUL' or hcmgCustStatCode = 'HNMMUL') then
				--{
					begin
						select rm_name,rm_email,rm_mobile,csm_name,csm_email,csm_mobile into rmname,rmemail,rmmob,csmname,csmemail,csmmob
						from ici_wm_map
						where cust_id=g1.cust_id
						and bank_id='&4';
					Exception
					When no_data_found Then
						rmname := 'NA';
						rmemail := 'NA';
						rmmob := 'NA';
						csmname := 'NA';
						csmemail := 'NA';
						csmmob := 'NA';
					end;

					begin
					     select count(*) into cnt1 from ici_wm_map where cust_id=lpad(g1.cust_id,9) and bank_id='&4';
					end;
						
						if (cnt1 > 0) then

							--DBMS_OUTPUT.PUT_LINE('inside if of HNI cust id' ||g1.cust_id);

					     		outLine := g1.sol_id||'|'||g1.cust_id||'|01|1|'||ltrim(rtrim(rmname))||'|'||
					     		ltrim(rtrim(rmemail))||'|'||ltrim(rtrim(rmmob))||'|'||ltrim(rtrim(csmname))
					     		||'|'||ltrim(rtrim(csmemail))||'|'||ltrim(rtrim(csmmob))||' | | | | |  | ';

						 	--dbms_output.put_line(outLine);
						 	utl_file.put_line(loc_fp,outLine);
						end if;
				--}
				end if;

			-- RMCSM


					opnDt := g1.acct_opn_date;
			begin
				select TRFS_MODE_FLG into trfFlg from pfam where foracid=g1.foracid and bank_id='&4';
			end; 

			if (trfFlg = 'Y') then
				tmpDt := trfInDt;
				trfInDt := g1.acct_opn_date ;
				opnDt := tmpDt ;
			end if;

				if (g1.acct_opn_date is null) then
					opnDt := 'NA';
				end if;

				--DBMS_OUTPUT.PUT_LINE(opnDt);
				--DBMS_OUTPUT.PUT_LINE(g1.acct_opn_date);
				--DBMS_OUTPUT.PUT_LINE(trfInDt);


				outLine := g1.sol_id||'|'||g1.cust_id||'|02|'|| '2'||'|'||g1.foracid||'|'||g1.acct_crncy_code||'??'||locTranDateBal||'|'||g1.acctType||'|'||
				'N'|| '|'     ||
				'|'	||
				g1.NOM_AVAILABLE_FLG|| '|'     ||
				--g1.acct_opn_date|| '|'     ||
				opnDt|| '|'     ||
				trfInDt|| '|'     ||
				c1.PAN_GIR_NUM||'|' || '&2' ||'|' || '&3' ||'|'; 

				--c1.PAN_GIR_NUM||'|'     ||(to_char(to_date('&2','DD-MM-YYYY'),'Month DD, YYYY'))|| '|' || (to_char(to_date('&3','DD-MM-YYYY'),'Month DD, YYYY')) || '|'; 

				utl_file.put_line(loc_fp,outLine);


				begin
				    SELECT tran_date_bal INTO opBal
				    FROM EAB
				    WHERE acid = g1.acid AND eod_date <= (to_date('&2'))
				    AND end_eod_date >= (to_date('&2')) and bank_id='&4';
				    exception
				    when no_data_found then
				    opBal := 0;
				    balAmt := 0;
				end;

				
				balAmt := opBal;
				dramt := 0;
				cramt := 0;

			    for h1 in htdCur(lacid)
				--{
				loop
					begin
					    SELECT foracid,acct_crncy_code INTO dbforAcid, dbcrncy from gam where acid = lacid and bank_id='&4';
					end;

					begin
						cnt := cnt + 1;
					    select lpad(cnt,6,0) into recCnt  from dual;
					end;


					if (h1.part_type= 'D') then
						--DBMS_OUTPUT.PUT_LINE('inside debit');

						--dramt := 0;
						dramt := h1.tran_amt;
						--DBMS_OUTPUT.PUT_LINE(dramt);
						tamt := dramt;

					    balAmt := balAmt - tamt;
						--DBMS_OUTPUT.PUT_LINE(dramt);
						--DBMS_OUTPUT.PUT_LINE(balAmt);
						--DBMS_OUTPUT.PUT_LINE('debit ends');
					else
						--DBMS_OUTPUT.PUT_LINE('inside credit');
						cramt := h1.tran_amt;
					         tamt := cramt;
					         balAmt := balAmt + tamt;
						 --DBMS_OUTPUT.PUT_LINE(cramt);
						 --DBMS_OUTPUT.PUT_LINE(balAmt);
						DBMS_OUTPUT.PUT_LINE('credit ends');
					end if;

					--	DBMS_OUTPUT.PUT_LINE(h1.part_type);
					--	DBMS_OUTPUT.PUT_LINE(dramt);
					--	DBMS_OUTPUT.PUT_LINE(cramt);
					--	DBMS_OUTPUT.PUT_LINE('final balance' ||balAmt);

				  		lacid := g1.acid;
					--DBMS_OUTPUT.PUT_LINE(lacid);
					--outLine := g1.sol_id|| '|'||g1.cust_id|| '|' ||'15|0|'||dbforAcid||'??'||g1.acct_crncy_code|| '|' ||recCnt||'|'|| h1.tran_date||'|'||
					--		h1.TRAN_PARTICULAR|| '|'||h1.INSTRMNT_NUM|| '|'||dramt|| '|'|| crAmt || '|'||balAmt || '| | |'||h1.VALUE_DATE || '|';

					outLine := g1.sol_id|| '|'||g1.cust_id|| '|' ||'15|0|'||dbforAcid||'??'||g1.acct_crncy_code|| '|' ||recCnt||'|'|| h1.tran_date||'|'||
								h1.TRAN_PARTICULAR|| '|'||h1.INSTRMNT_NUM|| '|' ||  dramt||'|'|| cramt || '|'||balAmt || '| | |'||h1.VALUE_DATE || '|';

					utl_file.put_line(loc_fp,outLine);
					dramt := 0;
					cramt := 0;

				--}
			    	end loop;
		--}
		end loop;
--}end of balance and htd count if
end if;

	--}
	end loop;

END;
/
spool off
