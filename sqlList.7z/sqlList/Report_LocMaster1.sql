----------------------------------------------------------------------------------------------------
--   Source Name            : Report_LocMaster1.sql
--   Description            : Report of Masters.
--   Input Values           : None
--   Output Values          : None
--   Called Script          : N.A
--   Calling Script         : N.A
--   Modification History:
--   Sl No.         Date              Author                     Description
--   --------------------------------------------------------------------------------------
--     01         17-Oct-2012         Priyanka                 Original Version
----------------------------------------------------------------------------------------------------

set serveroutput on size 1000000
set lines 2000 
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_LocMaster1.lst

Declare
v_sol_id        wlckm.sol_id%type:='&1';
v_bankid	wlckm.bank_id%type := '&2';
v_rack_id       varchar2(15);    
v_locker_type   wlckm.locker_type%type;
v_locker_count  number;
v_locker_amt    clmt.RENT_AMT%type;



cursor t2 is
            select a.sol_id,a.rack_id,a.locker_type,count(1),b.rent_amt
            from wlckm a,lclrm b
            where 'LOC'||a.sol_id = b.sol_id
            and a.locker_type = b.locker_type
            and a.sol_id = v_sol_id
            and a.bank_id = b.bank_id
            and a.bank_id = v_bankid
            and a.del_flg = b.del_flg
            and b.del_flg = 'N'
            and a.del_flg <>'Y'
            and b.rent_version_code = (select max(c.rent_version_code) from lclrm c where b.SOL_ID = c.sol_id
            and b.locker_type = c.locker_type and c.del_flg ='N')
            group by a.sol_id,a.rack_id,a.locker_type,b.rent_amt
            union
            select substr(b.sol_id,4,4),'Not Mapped',b.locker_type,to_number('0'),b.rent_amt
            from lclrm b
            where b.locker_type not in (select distinct locker_type from wlckm where sol_id = v_sol_id 
            and del_flg = 'N')
            and substr(b.sol_id,4,4) = v_sol_id 
            and b.bank_id = v_bankid
            and b.del_flg = 'N'
            and b.rent_version_code = (select max(c.rent_version_code) from lclrm c where b.SOL_ID = c.sol_id
            and b.locker_type = c.locker_type and c.del_flg ='N')
            group by b.sol_id,b.locker_type,b.rent_amt; 
	    
begin
open t2;
loop
--{
    fetch t2 into v_sol_id,v_rack_id,v_locker_type,v_locker_count,v_locker_amt;

    if t2%NOTFOUND then
    --{
        close t2;
        exit;
    --}
    end if;


            dbms_output.enable(buffer_size => NULL);
            dbms_output.put_line(    v_sol_id       ||'|'||
                                     v_rack_id          ||'|'||
                                     v_locker_type      ||'|'||
                                     v_locker_count     ||'|'||
				     v_locker_amt);

--}
end loop;
end;
/
spool off


