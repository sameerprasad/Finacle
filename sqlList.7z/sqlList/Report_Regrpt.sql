----------------------------------------------------------------------------------------------------
--   Source Name            : Report_Regrpt.sql 
--   Description            : Key Register Report.
--   Input Values           : None
--   Output Values          : None
--   Called Script          : N.A
--   Calling Script         : N.A
--   Modification History:
--   Sl No.         Date              Author                     Description
--   --------------------------------------------------------------------------------------
--     01         16-Oct-2012         Priyanka                 Original Version
----------------------------------------------------------------------------------------------------

set serveroutput on size 1000000
set head off
set pau off
set echo off
set lines 250
set pages 0
set termout off
set verify off
set feedback off
spool Report_Regrpt.lst

DECLARE

        v_solid            	wlckm.sol_id%type  :='&1';
	v_bankid		wlckm.bank_id%type := '&2';
	v_RACK_ID          	wlckm.RACK_ID%type;
	v_LOCKER_NUM       	clnd.LOCKER_NUM%type;
	v_locker_type           wlckm.locker_type%type;	
	v_key1      	        wlckm.key_num%type;
	v_Prevkey      	        lcks.KEY_NUM1%type;
    	v_status                varchar2(20);

cursor c1(v_solid varchar2) is 

SELECT  wlckm.sol_id,
	wlckm.rack_id,
        wlckm.locker_type,
        wlckm.locker_num,
        wlckm.key_num key1,
	wlckm.status||'-'||wlckm.remarks status
        from wlckm
        where wlckm.sol_id = v_solid
	and wlckm.bank_id = v_bankid
        and wlckm.ENTITY_CRE_FLG = 'Y'
        and wlckm.del_flg !='Y';
      
BEGIN
	OPEN c1(v_solid);
	LOOP
		FETCH c1 INTO 	v_solid,  
				v_rack_id,
				v_locker_type,
				v_locker_num,
				v_key1,
				v_status;
			      
				
			
		IF c1%NOTFOUND THEN
			CLOSE c1;
			EXIT;
		END IF;
			
			BEGIN
                        	select  lcks.KEY_NUM1  
	                	into   v_Prevkey           
			 	from   lcks 
			 	where  lcks.LOCKER_NUM1 = v_locker_num 
				and lcks.sol_id = v_solid
				and lcks.bank_id = v_bankid
				and lcks.ENTITY_CRE_FLG = 'Y'
				and lcks.DEL_FLG='N';

			exception 
				when no_data_found then
			        v_Prevkey := '';	
			END;
			
		dbms_output.enable(buffer_size => NULL);						
		dbms_output.put_line (  v_solid            ||'|'||
       		                        v_RACK_ID          ||'|'||	
                                        v_LOCKER_TYPE      ||'|'||
                                        v_LOCKER_NUM       ||'|'||
                                        v_key1     	   ||'|'||
                                        v_Prevkey  	   ||'|'||
                                        v_status); 
			
END LOOP;
END;	   			
/
spool off

