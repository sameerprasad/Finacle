CREATE OR REPLACE TRIGGER "TBAADM"."ICICI_REFERENCE_CODE_TBL_TRG"
AFTER UPDATE OR INSERT OR DELETE ON  ICICI.ICICI_REFERENCE_CODE_TBL for each row
declare
        new_table_key
TBAADM.SOL_DATA_DISTRBTN_TABLE.TABLE_KEY%TYPE;
        old_table_key
TBAADM.SOL_DATA_DISTRBTN_TABLE.TABLE_KEY%TYPE;
        num_of_recs NUMBER;
        loc_func_code CHAR(1);
        sod_func_code CHAR(1);
        sol_id TBAADM.SOL_DATA_DISTRBTN_TABLE.CONTEXT_SOLID%TYPE;
    bank_id TBAADM.SOL_DATA_DISTRBTN_TABLE.BANK_ID%TYPE;
BEGIN --{
        SELECT 'ICIRCT|2|4|'||:old.ref_rec_type || '|' || :old.ref_code into old_table_key from dual;
        SELECT 'ICIRCT|2|4|'||:new.ref_rec_type || '|' || :new.ref_code into new_table_key from dual;
    SELECT :new.bank_id INTO bank_id from dual;

        IF INSERTING THEN --{
                old_table_key := new_table_key;
                loc_func_code := 'A';
        ELSIF DELETING THEN
                new_table_key := old_table_key;
                loc_func_code := 'D';
        ELSE
                new_table_key := old_table_key;
                loc_func_code := 'M';
        END IF; --}
        sol_id := 'ALL';
        BEGIN  --{
                SELECT TABLE_FUNC,1 INTO sod_func_code,num_of_recs FROM
                        TBAADM.SOL_DATA_DISTRBTN_TABLE
                        WHERE CONTEXT_SOLID = sol_id
                        AND TABLE_KEY=old_table_key AND
                        TABLE_ABBR='CUSTOM';
                EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                                num_of_recs := 0;
                                sod_func_code := 'A';
                        WHEN OTHERS THEN
                                num_of_recs := 0;
                                sod_func_code := 'A';
        END; --}
        IF num_of_recs = 1 THEN --{

                IF (new_table_key <> old_table_key) THEN  --{

                        UPDATE TBAADM.SOL_DATA_DISTRBTN_TABLE SET
                                TABLE_FUNC = 'D'
                        WHERE CONTEXT_SOLID = sol_id AND
                                TABLE_KEY=old_table_key AND
                                TABLE_ABBR='CUSTOM';


                        INSERT INTO TBAADM.SOL_DATA_DISTRBTN_TABLE VALUES
                                (sol_id,'CUSTOM',new_table_key,loc_func_code,bank_id,1);

                ELSIF (loc_func_code <> sod_func_code) THEN

                        UPDATE TBAADM.SOL_DATA_DISTRBTN_TABLE SET
                                CONTEXT_SOLID = sol_id,TABLE_KEY=new_table_key,
                                TABLE_ABBR='CUSTOM',TABLE_FUNC=loc_func_code
                        WHERE CONTEXT_SOLID = sol_id AND
                                TABLE_KEY = old_table_key AND
                                TABLE_ABBR='CUSTOM';

                END IF; --}
                ELSE

                        INSERT INTO TBAADM.SOL_DATA_DISTRBTN_TABLE VALUES
                                (sol_id,'CUSTOM',new_table_key,loc_func_code,bank_id,1);

                        IF (new_table_key <> old_table_key) THEN  --{
                                INSERT INTO TBAADM.SOL_DATA_DISTRBTN_TABLE VALUES
                                (sol_id,'CUSTOM',old_table_key,'D',bank_id,1);
                        END IF; --}

                END IF; --}
END; --}
/
ALTER TRIGGER "TBAADM"."ICICI_REFERENCE_CODE_TBL_TRG" ENABLE
/
