--===================================================================================================================
--  Filename                :   letters_gradkit.sql
--  Description             :   To generate dump of the details of kit accounts that have
--                              been activated for graded customers on a daily basis.
--  Date                    :   05-09-2012
--  Author                  :   Swaroop K Tiruvoipati
--  Menu Option             :
--  Modification History
--    Sl. #           Date           Author                     Modification
--    -----           -----          --------                    ----------------
--    1               05-09-2012     Swaroop K Tiruvoipati      Original Version
--                                                              (Ported from 7.x)
--===================================================================================================================
--  Input           :   letters_gradkit.com
--  Output          :   /tmp/gradkit.txt

DECLARE
	loc_foracid					gam.foracid%type;
	loc_cust_name				cmg.cust_name%type;
	loc_cust_comu_addr1			cmg.cust_comu_addr1%type;
	loc_cust_comu_addr2			cmg.cust_comu_addr2%type;
	loc_cust_comu_city_code 	cmg.cust_comu_city_code%type;    
	loc_cust_comu_state_code 	cmg.cust_comu_state_code%type;
	loc_cust_comu_pin_code		cmg.cust_comu_pin_code%type;    
	loc_cust_comu_cntry_code	cmg.cust_comu_cntry_code%type;
	loc_acct_opn_date			gam.acct_opn_date%type;
	loc_cust_stat_code			cmg.cust_stat_code%type;
	loc_cust_comu_phone_num_1	cmg.cust_comu_phone_num_1%type;
	loc_cust_comu_phone_num_2	cmg.cust_comu_phone_num_2%type;

	loc_city_desc         		varchar2(50);
	loc_state_desc      		varchar2(50);
	loc_cntry_desc     			varchar2(50);

	loc_fp               		utl_file.file_type;
	loc_filename         		varchar2(200);
	loc_filemode         		varchar(10);
	loc_filepath         		varchar2(100);

	outpt           			varchar2(1000);
	download					char(1);

CURSOR kitcur IS
SELECT
	cif_id
FROM
	ICICI_KIT
WHERE
	ACTIVE_FLG = 'Y'
AND
        BANK_ID = '&3'
AND
to_date (LCHG_TIME,'DD-MM-YYYY') = (select db_stat_date from gct);

BEGIN
	loc_filepath := '&1';
	loc_filename := '&2';
	loc_filemode := 'w';
	loc_fp := utl_file.fopen(loc_filepath, loc_filename, loc_filemode);

	FOR rec in kitcur
	LOOP
		download :=  'Y';
		BEGIN
			SELECT 
				g.foracid,
				c.cust_name,
				a.address_line1,
				a.address_line2,
				a.city_code,
				a.state_code,
				a.zip,
				a.country_code
				p.phoneno1,
				p.phoneno2,
				g.acct_opn_date,
				ac.status_code	 	
			INTO
				loc_foracid,
				loc_cust_name,
				loc_cust_comu_addr1,
				loc_cust_comu_addr2,
				loc_cust_comu_city_code,    
				loc_cust_comu_state_code,
				loc_cust_comu_pin_code,    
				loc_cust_comu_cntry_code,
				loc_cust_comu_phone_num_1,
				loc_cust_comu_phone_num_2,
				loc_acct_opn_date,
				loc_cust_stat_code
			FROM
				CMG c,CRMUSER.ADDRESS a,CRMUSER.phoneemail p,CRMUSER.ACCOUNTS ac, GAM g
			WHERE
				c.cif_id = rec.cif_id
			AND
				((ac.status_code like '1%') OR (ac.status_code like '2%') OR 
			(cmg.cust_stat_code in ('HH1', 'HH2', 'SRC1', 'SRC2', 'HH3', 'SRC3', 'HBRK1', 'HBRK2', 'HBRK3', 'EASY1', 'EASY2', 'EASY3', 'WMN1', 'WMN2', 'WMN3', 'ALSA1', 'ALSA2', 'ALSA3', '1RDA1', '1RDA2', '1RDA3', '1RDA4', '1RDB1', '1RDB2', '1RDB3', '1RDB4', '1RDC1', '1RDC2', '1RDC3', '1RDC4', '1RDD1', '1RDD2', '1RDD3', '1RDD4', '1RDE1', '1RDE2', '1RDE3', '1RDE4', '1RDF1', '1RDF2', '1RDF3', '1RDF4', '2RDA1', '2RDA2', '2RDA3', '2RDA4', '2RDB1', '2RDB2', '2RDB3', '2RDB4', '2RDC1', '2RDC2', '2RDC3', '2RDC4', '2RDD1', '2RDD2' ,'2RDD3', '2RDD4', '2RDE1' ,'2RDE2', '2RDE3', '2RDE4', '2RDF1', '2RDF2', '2RDF3', '2RDF4', '3RDA1', 'HRTD1', 'HANG1', 'HKAR1', 'HRTD2', 'HSHR1', 'HSHR2', 'HKAR2', 'HIDR1', 'HIDR2', 'HUTI1', 'HUTI2', 'HIND1', 'ALS21','ALSP1','HANG2', 'HIND2', 'ALS22', 'ALSP2')))
			AND
				c.cif_id = g.cif_id
			AND
				acct_cls_flg <> 'Y'
                        AND     c.BANK_ID = '&3'
                        AND     g.BANK_ID = '&3';
		EXCEPTION
			when others then
				download := 'N';
		END;

		if (download = 'Y') then
			BEGIN
				SELECT
					ref_desc
				INTO
					loc_city_desc
				FROM
					RCT
				WHERE
					 ref_rec_type = '01'
				AND
					ref_code = loc_cust_comu_city_code 
                                AND     
                                        BANK_ID = '&3';
			 EXCEPTION
				when others then
					loc_city_desc := '';
			END;

			BEGIN
				SELECT
					ref_desc
				INTO
					loc_state_desc
				FROM
					rct
				WHERE
					ref_rec_type = '02'
				AND
					ref_code = loc_cust_comu_city_code 
                                AND     
                                        BANK_ID = '&3';
			EXCEPTION
				when others then
					loc_state_desc := '';
			END;

			BEGIN
				SELECT
					ref_desc
				INTO
					loc_cntry_desc
				FROM
					rct
				WHERE
					ref_rec_type = '03'
				AND
					ref_code = loc_cust_comu_cntry_code 
                                AND     
                                        BANK_ID = '&3';
			EXCEPTION
				when others then
					loc_cntry_desc := '';
			END;

			outpt  := loc_foracid                || '|' ||
                      loc_cust_name              || '|' ||
                      loc_cust_comu_addr1        || '|' ||
                      loc_cust_comu_addr2        || '|' ||
                      loc_city_desc              || '|' ||
                      loc_cust_comu_pin_code     || '|' ||
                      loc_state_desc             || '|' ||
                      loc_cntry_desc             || '|' ||
                      loc_cust_comu_phone_num_1  || '|' ||
                      loc_cust_comu_phone_num_2  || '|' ||
                      rec.cif_id                 || '|' ||
                      loc_acct_opn_date          || '|' ||
                      loc_cust_stat_code; 

			utl_file.put_line(loc_fp, outpt);
		 END IF;
	END LOOP;
   utl_file.fclose(loc_fp);    
END;
/
