set verify off
set serveroutput on
set feedback off
spool todDayEnd.txt
DECLARE

gam_balance number(21,2);
table_balance number(21,2);
diff number(21,2);
txn_amt number(21,2);
coll_amt number(21,2);
tod_amt number(21,2);

cursor c1 is
select tran_date,tran_id,tran_particular,tran_amt from dtd where acid in (select acid from gam where foracid in ('0017SLMINTOD','0036SLMINTOD','6044SLMINTOD') and bank_id = '&1') and part_tran_type='D' and tran_particular like 'TOD%' and bank_id ='&1';

BEGIN

	select sum(clr_bal_amt+un_clr_bal_amt) into gam_balance  from gam where foracid in ('0017SLMINTOD','0036SLMINTOD','6044SLMINTOD') and bank_id ='&1';

	select sum(tod_amt-nvl(regularised_amt,0)) into table_balance from ici_charge_tod where priority||type not in ('0103','0104','0105') and bank_id='&1';

	diff:=gam_balance-table_balance;
	
	dbms_output.put_line('GAM BALANCE'||'|'||'TABLE BALANCE'||'|'||'DIFFERENCE');
	dbms_output.put_line(gam_balance||'|'||table_balance||'|'||diff);

	dbms_output.put_line('*************** Recovery Transactions in SLMINTOD Account *****************');
	dbms_output.put_line('TRAN_DATE|TRAN_ID|TRAN_PARTICULAR|TRAN_AMT');

for c1rec in c1
loop
	dbms_output.put_line(c1rec.tran_date||'|'||c1rec.tran_id||'|'||c1rec.tran_particular||'|'||c1rec.tran_amt);
end loop;

END;
/
