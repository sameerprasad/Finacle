#================================================================================================
#Source Name            :  INT_IN_MSG_MAS_ADT
#Description            :  ICSWIFT.INT_IN_MSG_MAS_ADT Trigger Creation
#Input Values           :  None
#Output Values          :  None
#Called Scripts         :  None
#Calling Scripts        :  None
#Modification history:
#    Sl. No       Date        Author                   Description
#    ------   ----------   -----------        ----------------------------------------------
#	1     18/10/2012   Mangala Priya      ICSWIFT.INT_IN_MSG_MAS_ADT Trigger Creation
#=================================================================================================
CREATE OR REPLACE TRIGGER "ICSWIFT"."INT_IN_MSG_MAS_ADT"
before UPDATE  OF IC_RECV_BRANCH ON INT_IN_MSG_MAS
FOR EACH ROW
DECLARE
CNTR number;
BEGIN
BEGIN

IF UPDATING THEN
INSERT INTO INT_IN_MSG_MAS_AUDT VALUES
(
:old.IC_TRANS_NO       ,
:old.IC_SENDER_INFO    ,
:old.IC_SENDER_LT      ,
:old.IC_SENDER_BRANCH  ,
:old.IC_MSG_TYPE       ,
:old.IC_APPL_ID        ,
:old.IC_SENT_DT        ,
:old.IC_SENT_TM        ,
:old.IC_RECV_DT        ,
:old.IC_RECV_TM       ,
:old.IC_SENT_FLAG     ,
:old.IC_REF_NO       ,
:old.IC_MIR            ,
:old.IC_STATUS         ,
:old.IC_PRIORITY       ,
:old.IC_HEADER_DETAILS ,
:old.IC_FILE_NAME      ,
:old.IC_DIR_PATH       ,
:old.IC_RECV_INFO       ,
:old.IC_RECV_LT         ,
:old.IC_RECV_BRANCH     ,
:old.IC_OMH_TRANS_NO    ,
:old.IC_FUNCTION        ,
:old.IC_MOD_NO          ,
:old.IC_BR_CODE         ,
:old.IC_INIT_USER       ,
:old.IC_AUTH_USER       ,
:old.IC_DUPLICATE       ,
:old.IC_PREV_TRANS_NO   ,
:old.IC_MOR             ,
:old.IC_TRAILER         ,
:old.IC_P_FLG           ,
:old.IC_P_DT            ,
:old.IC_PRINT           ,
:old.IC_MOD_USER        ,
:old.IC_RETURN_FLG       ,
SYSDATE,
:NEW.IC_MOD_USER ) ;
END IF;


END;
END;
ALTER TRIGGER "ICSWIFT"."INT_IN_MSG_MAS_ADT" ENABLE
