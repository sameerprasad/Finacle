--------------------------------------------------------------------------------------
-- Created for		:   Overdue Bills Report
-- Created By   	:   Archana
-- Created On       :   14-Jan-2005
-- MRT File Name    :   rbrptmn001.mrt
-- INPUT            :   set_id, bill_id
--------------------------------------------------------------------------------------- 

-- ---------------------------------------------
-- Declaration of the package and the Procedure
-- ---------------------------------------------

CREATE OR REPLACE PACKAGE rbrptmn001_pack AS --{
    PROCEDURE rbrptmn001_proc	(inp_str IN VARCHAR2,
                             out_retCode OUT NUMBER,
                             out_rec OUT VARCHAR2);
END rbrptmn001_pack; --}
/

CREATE OR REPLACE PACKAGE BODY rbrptmn001_pack AS
--{
-------------------------------------------------------------------
--Declaring the variables to be used in the Procedure
-------------------------------------------------------------------

    outArr              basp0099.ArrayType;
	dStartDate			date;
	dEndDate			date;
	
	cursor cur_main (dStartDate IN date, dEndDate IN date) is
	--{
        SELECT
			C_740.REF_NUMBER,
			C_740.SWIFT_CODE,
			C_740.LC_NUM,
			C_740.CREDIT_CRNCY,
			C_740.CREDIT_AMT,
			C_740.RCRE_TIME
        FROM C_740
        WHERE
                C_740.RCRE_TIME >= dStartDate
        AND		C_740.RCRE_TIME <= dEndDate
;
	--}
-- --------------------------------------------------------------------
--Procedure body
-- --------------------------------------------------------------------

PROCEDURE rbrptmn001_proc(inp_str   IN  VARCHAR2,
                      	out_retCode OUT NUMBER,
                     	out_rec     OUT VARCHAR2) AS
	out_arr basp0099.ArrayType;
	refNumber			C_740.REF_NUMBER%type;
	swiftCode			C_740.SWIFT_CODE%type;
	lcNum				C_740.LC_NUM%type;
	crCrncy				C_740.CREDIT_CRNCY%type;
	crAmt				C_740.CREDIT_AMT%type;
	rCreTime			C_740.RCRE_TIME%type;
	sStartDate			date;	
	sEndDate			date;	

BEGIN
    --{
    out_retCode := 0;

	if (NOT cur_main%ISOPEN) then
		basp0099.formInputArr(inp_str,out_arr);
		sStartDate		:= to_date(out_arr(0),'dd-mm-yyyy'); 
		sEndDate		:=  to_date(out_arr(1),'dd-mm-yyyy'); 
--		select to_date(sStartDate, 'dd-mm-yyyy') into dStartDate from dual;
--		select to_date(sEndDate, 'dd-mm-yyyy') into dEndDate from dual;
--		open cur_main(to_date(sStartDate,'dd-mm-yyyy'), to_date(sEndDate,'dd-mm-yyyy'));
		open cur_main(sStartDate,sEndDate);
	end if;

	fetch cur_main into
			refNumber,
			swiftCode,
			lcNum,
			crCrncy,
			crAmt,
			rCreTime;

	if ((cur_main%ISOPEN) and (cur_main%NOTFOUND)) then
    --{
        close cur_main;
        out_retCode := 1;
    --}
	end if;

	out_rec := 	
			refNumber		||'|'||
			swiftCode		||'|'||
			lcNum			||'|'||
			crCrncy			||'|'||
			crAmt			||'|'||
			rCreTime;

END; --}Procedure ends
END rbrptmn001_pack;
/
DROP PUBLIC SYNONYM rbrptmn001_pack 
/
CREATE PUBLIC SYNONYM rbrptmn001_pack FOR rbrptmn001_pack
/
GRANT EXECUTE ON rbrptmn001_pack TO TBAGEN, TBAUTIL, TBACUST
/
