Rem     This file will create INT_IN_MSG_MAS_AUDT
Rem     with the following characteristics.

Rem TABLE NAME: ICSWIFT.INT_IN_MSG_MAS_AUDT

drop table ICSWIFT.INT_IN_MSG_MAS_AUDT
/
create table ICSWIFT.INT_IN_MSG_MAS_AUDT
(
 IC_AUDT_TRANS_NO                          VARCHAR2(16) NOT NULL,
 IC_AUDT_SENDER_INFO                                VARCHAR2(11),
 IC_AUDT_SENDER_LT                                  VARCHAR2(1),
 IC_AUDT_SENDER_BRANCH                              VARCHAR2(15),
 IC_AUDT_MSG_TYPE                                   CHAR(3),
 IC_AUDT_APPL_ID                                    VARCHAR2(6),
 IC_AUDT_SENT_DT                                    VARCHAR2(8),
 IC_AUDT_SENT_TM                                    VARCHAR2(8),
 IC_AUDT_RECV_DT                                    VARCHAR2(8),
 IC_AUDT_RECV_TM                                    VARCHAR2(8),
 IC_AUDT_SENT_FLAG                                  CHAR(5),
 IC_AUDT_REF_NO                                     NUMBER,
 IC_AUDT_MIR                                        VARCHAR2(100),
 IC_AUDT_STATUS                                     VARCHAR2(5),
 IC_AUDT_PRIORITY                                   VARCHAR2(2),
 IC_AUDT_HEADER_DETAILS                             VARCHAR2(300),
 IC_AUDT_FILE_NAME                                  VARCHAR2(30),
 IC_AUDT_DIR_PATH                                   VARCHAR2(100),
 IC_AUDT_RECV_INFO                                  VARCHAR2(11),
 IC_AUDT_RECV_LT                                    VARCHAR2(1),
 IC_AUDT_RECV_BRANCH                                VARCHAR2(15),
 IC_AUDT_OMH_TRANS_NO                               VARCHAR2(16),
 IC_AUDT_FUNCTION                                   VARCHAR2(50),
 IC_AUDT_MOD_NO                                     NUMBER(38),
 IC_AUDT_BR_CODE                                    VARCHAR2(8),
 IC_AUDT_INIT_USER                                  VARCHAR2(16),
 IC_AUDT_AUTH_USER                                  VARCHAR2(16),
 IC_AUDT_DUPLICATE                                  CHAR(1),
 IC_AUDT_PREV_TRANS_NO                              VARCHAR2(32),
 IC_AUDT_MOR                                        VARCHAR2(100),
 IC_AUDT_TRAILER                                    VARCHAR2(2000),
 IC_AUDT_P_FLG                                      CHAR(1),
 IC_AUDT_P_DT                                       DATE,
 IC_AUDT_PRINT                                      VARCHAR2(1),
 IC_AUDT_MOD_USER                                   VARCHAR2(16),
 IC_AUDT_ROUTE_FLG                          VARCHAR2(1) NOT NULL,
 IC_AUDT_AUD_TIME                                   DATE,
 IC_AUDT_AUD_USER                                   VARCHAR2(100)
)
/

grant select, insert, update, delete on ICSWIFT.INT_IN_MSG_MAS_AUDT to tbagen, tbaadm
/
grant select on ICSWIFT.INT_IN_MSG_MAS_AUDT to tbacust
/
grant select on ICSWIFT.INT_IN_MSG_MAS_AUDT to tbautil
/
