---------------------------------------------------------------------------------
-- Filename         : gamtotbal.sql
-- Description      : This sql file spools out sum of clr_bal_amt and un_clr_bal_amt  
--                    from gam table
-- Date             : 10-10-2012
-- Author           : Aparna Ashok
-- Menu Option      : gamtotbal.com
-- Modification History
-- Sl.#       Date           Author         Modification                              
-- -----   ----------   --------------    ----------------                               
--  1.0   10-10-2012   Aparna Ashok    Original Version                          
----------------------------------------------------------------------------------------------





set head off
set pages 0
set termout off
set feedback off
spool gamtotbal
select sum(clr_bal_amt+un_clr_bal_amt) from gam; 
spool off
exit
