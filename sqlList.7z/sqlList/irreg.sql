rem ****************************************************************
rem *THIS SCRIPT GIVES THE LIST OF ACCOUNTS WHERE BALANCE EXCEEDS  *
rem *DRAWING POWER OR SANCTION LIMIT                               *
rem *                                                              *
rem * 	AUTHOR 		 : S.RAMASWAMY                             *
rem *	DATE  		 : 05-AUG-97                               *
rem *	TABLES ACCESSED  : GAM                                     *
rem *   MODIFIED ON      :02-SEP-1998                              *
rem *   MODIFIED ON      :12-09-1998 ..... A Muralidhar            *
rem ****************************************************************
rem The report takes set_id as inputs
set echo off
set feedback off
set termout off
set newpage 0
set verify off
set pagesize 60
set lines 132

column dates new_value date1
column soldesc new_value solname
column setid new_value solset

rem break on facility skip 1 on prefix skip 1

column A heading 'LIABILITY' format b999,99,99,999.99
column B heading 'IRREGULARITY' format b999,99,99,999.99
column C heading 'DRAWING POW.' format b999,99,99,999.99
column D heading 'SANCT. LIMIT' format b999,99,99,999.99

select db_stat_date dates from gct;
select sol.sol_id solid, sol.sol_desc soldesc, sst.set_id setid
from sol, sst
where sol.sol_id=sst.sol_id
and set_id='&1' and sol.bank_id='&2';
 
break on soldesc skip page on report
spool irreg.&1

ttitle center 'ICICI BANKING CORPORATION LTD., ' skip 1 -
center ' SOLSET - ' solset skip 1 -
center ' SOLNAME - 'solname skip 1 -
center ' -------------------- ' skip 1 -
center 'REPORT OF ACCOUNTS HAVING BALANCES MORE THAN DP or Sanction Limit ON '&date1 skip 2 -

select s.sol_desc soldesc,g.schm_code facility,g.foracid,substr(acct_name,1,20) Name,drwng_power C,sanct_lim D,(clr_bal_amt+un_clr_bal_amt) A,
((clr_bal_amt+un_clr_bal_amt) + least(drwng_power,sanct_lim+adhoc_lim)) B
from sol s, gam g
where g.sol_id=s.sol_id
and g.sol_id in (select sol_id from sst where set_id = '&1')
and ((g.clr_bal_amt+g.un_clr_bal_amt)<(g.drwng_power* -1)
or  (g.clr_bal_amt+g.un_clr_bal_amt)<((g.sanct_lim* -1) + (g.adhoc_lim* -1)))
and substr(g.foracid,5,2) in ('01','05','06','51','52','55','56','60')
and (g.clr_bal_amt+g.un_clr_bal_amt) <0
and g.bank_id='&2'
order by g.sol_id,schm_code,g.foracid
/
spool off
exit
