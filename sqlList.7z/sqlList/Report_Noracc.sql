----------------------------------------------------------------------------------------------------
--   Source Name            : Report_Noracc.sql 
--   Description            : Locker Normal Access Report.
--   Input Values           : None
--   Output Values          : None
--   Called Script          : N.A
--   Calling Script         : N.A
--   Modification History:
--   Sl No.         Date              Author                     Description
--   --------------------------------------------------------------------------------------
--     01         11-Oct-2012         Priyanka                 Original Version
----------------------------------------------------------------------------------------------------

set serveroutput on size 1000000
set lines 650
set pages100
set echo off
set termout off
set head off
set verify off
set embedded on
set numf 999999999999999.99
set trimspool on
set feedback off

spool Report_Noracc.lst

DECLARE

lv_solid         gam.sol_id%type :='&1';
date1            varchar2(30) :='&2';
date2            varchar2(30) :='&3';
lv_bankid        clmt.bank_id%type := '&4';


CURSOR c1 IS
select 	lcops.sol_id,
        wlckm.RACK_ID,
	lcops.cif_id,
        wlckm.LOCKER_TYPE,
        lcops.locker_no,
	lcops.check_date||'/'||lcops.CHECK_IN_TIME checkintime,
	JH_ID_1,
        JH_ID_2,
        JH_ID_3,
        JH_ID_4,
        JH_ID_5,
        JH_ID_6,
        LOA_ID_1,
        LOA_ID_2,
        LOA_ID_3,
        LOA_ID_4,
        LOA_ID_5,
        LOA_ID_6,
	substr(CUST_NAME,1,40) CUST_NAME,
	substr(JH_NAME_1,1,40) JH_NAME_1,
	substr(JH_NAME_2,1,40) JH_NAME_2,
	substr(JH_NAME_3,1,40) JH_NAME_3,
	substr(JH_NAME_4,1,40) JH_NAME_4,
	substr(JH_NAME_5,1,40) JH_NAME_5,
	substr(JH_NAME_6,1,40) JH_NAME_6,
	substr(LOA_NAME_1,1,40) LOA_NAME_1,
	substr(LOA_NAME_2,1,40) LOA_NAME_2,
	substr(LOA_NAME_3,1,40) LOA_NAME_3,
	substr(LOA_NAME_4,1,40) LOA_NAME_4,
	substr(LOA_NAME_5,1,40) LOA_NAME_5,
	substr(LOA_NAME_6,1,40) LOA_NAME_6
from 	lcops,wlckm,clmt
where 	wlckm.LOCKER_NUM = lcops.LOCKER_NO
and 	wlckm.LOCKER_NUM = clmt.LOCKER_NUM
and 	clmt.LOCKER_NUM = lcops.LOCKER_NO
and 	wlckm.sol_id = lcops.sol_id
and 	wlckm.sol_id = clmt.sol_id
and 	lcops.CHECK_DATE between to_date(date1,'dd-mm-yyyy') and to_date(date2,'dd-mm-yyyy')
and 	lcops.sol_id = lv_solid
and     lcops.bank_id = wlckm.bank_id
and     clmt.bank_id = wlckm.bank_id
and     clmt.bank_id = lv_bankid
and     wlckm.del_flg!='Y'
and     lcops.del_flg!='Y'
and     clmt.del_flg!='Y'
order by 1;

BEGIN

    for f1 in c1
    loop
dbms_output.enable(buffer_size => NULL);

dbms_output.put_line(     f1.sol_id           ||'|'||
            f1.rack_id          ||'|'||
            f1.cif_id        ||'|'|| 
            f1.locker_type      ||'|'||
            f1.locker_no        ||'|'||
            f1.CHECKINTIME      ||'|'||
            f1.JH_ID_1        ||'|'||
            f1.JH_ID_2        ||'|'||
            f1.JH_ID_3        ||'|'||
            f1.JH_ID_4        ||'|'||
            f1.JH_ID_5        ||'|'||
            f1.JH_ID_6        ||'|'||
            f1.LOA_ID_1        ||'|'||
            f1.LOA_ID_2        ||'|'||
            f1.LOA_ID_3        ||'|'||
            f1.LOA_ID_4        ||'|'||
            f1.LOA_ID_5        ||'|'||
            f1.LOA_ID_6        ||'|'||
            f1.CUST_NAME        ||'|'||
            f1.JH_NAME_1        ||'|'||
            f1.JH_NAME_2        ||'|'||
            f1.JH_NAME_3        ||'|'||
            f1.JH_NAME_4        ||'|'||
            f1.JH_NAME_5        ||'|'||
            f1.JH_NAME_6        ||'|'||
            f1.LOA_NAME_1        ||'|'||
            f1.LOA_NAME_2        ||'|'||
            f1.LOA_NAME_3        ||'|'||
            f1.LOA_NAME_4        ||'|'||
            f1.LOA_NAME_5        ||'|'||
            f1.LOA_NAME_6        
        ); 
   end loop; 
END;
/
spool off

