--##############################################################################################
--#                     File Name       : iciLongArray.sql
--#                     Author 		: 
--#                     Report 		: 
--#                     Date   		:
--#                     Module  	: 
--#                     Called Menu     : ICISOLST
--#                     Called By       : 
--##############################################################################################
CREATE OR REPLACE PACKAGE ICICI.iciLongArray
AS                                                         
                                                                                
	TYPE ArrayType IS TABLE OF VARCHAR2(128) INDEX BY BINARY_INTEGER;               
	PROCEDURE construct (outCnt    OUT   NUMBER, outArr    OUT   ArrayType);
                                                                                
END iciLongArray;
/
CREATE OR REPLACE PACKAGE BODY ICICI.iciLongArray 
AS
        
PROCEDURE construct ( outCnt    OUT   NUMBER, outArr    OUT   ArrayType) 
IS
	locArr                          ArrayType;
	locCnt                          NUMBER := 0;
BEGIN

	--  By Santosh                                                                  
	-- For Array a0 to z9                                                    
        for i in 97..122                                                        
        LOOP                                                                    
               for j in 0..9                                                    
                    LOOP                                                        
                       locArr(locCnt) := chr(i)||j;                             
                       locCnt := locCnt + 1;                                    
                    END LOOP;                                                   
        END LOOP;                                                               
                                                                                
        -- For Array A0 to Z9                                                   
                                                                                
            for i in 65..92                                                     
            LOOP                                                                
                    for j in 0..9                                               
                    LOOP                                                        
                        locArr(locCnt) := chr(i)||j;                            
                        locCnt := locCnt + 1;                                   
                    END LOOP;                                                   
            END LOOP;                                                           
                                                                                
            outCnt := locCnt;                                                   
            outArr := locArr;                                                   
                                                                                
--  End Santosh                                                                 
                                                                                
END construct;
                                                                                
-- ***********************************************************                  
END iciLongArray ;
/
sho err
/
create or replace public synonym iciLongArray for ICICI.iciLongArray
/
grant all on iciLongArray to tbautil,tbagen,tbaadm,icici
/
