----------------------------------------------------------------------------------------------------
--   Source Name            : Report_rentrebate.sql 
--   Description            : Rent Rebate Report.
--   Input Values           : None
--   Output Values          : None
--   Called Script          : N.A
--   Calling Script         : N.A
--   Modification History:
--   Sl No.         Date              Author                     Description
--   --------------------------------------------------------------------------------------
--     01         12-Oct-2012         Priyanka                 Original Version
----------------------------------------------------------------------------------------------------

set serveroutput on size 1000000
set head off
set pau off
set echo off
set lines 250
set pages 0
set termout off
set verify off
set feedback off
set trim on

spool Report_rentrebate.lst 


DECLARE
    v_solid                    clmt.sol_id%type := '&1';
    date1                  clmt.issue_date%type := to_date('&2','dd-mm-yyyy'); 
    v_bankid                clmt.bank_id%type := '&3';
    v_sol_id                clmt.sol_id%type;       
    v_refno                    clmt.cif_id%type;
    v_cust_name                cmg.cust_name%type;
    v_locker_type            clmt.locker_type%type;
    v_locker_num            clmt.locker_num%type;
    v_issue_date            clmt.issue_date%type;
    v_rent_amt                 clmt.rent_amt%type;
    v_disc_rent_amt            clmt.disc_rent_amt%type;
     v_rack_id               wlckm.rack_id%type;
    v_prev_due                 clmt.due_date%type;
    v_next_due                 clmt.due_date%type;
    v_due_date                 clmt.due_date%type;
    v_no_of_days            number;
    v_elapsed_days          number;
    v_unelapsed_days        number;
    v_elapsed_rent          clmt.rent_amt%type := 0;
    v_unelapsed_rent        clmt.rent_amt%type := 0; 
    v_status                varchar2(20); 
    v_RentPaid              lcpd.paid_amount%type;
    v_RentPayable            lcpy.payable_amount%type;
    v_overDuePrd            number;
    v_last_demand_date        date;
    v_last_demand_amt        clmt.disc_rent_amt%type;
    v_FinYr                    date;
    v_OverdueAmt            clmt.disc_rent_amt%type; 
    v_AdvanceRent            clmt.disc_rent_amt%type;
    v_totalunelapsed_rent    clmt.disc_rent_amt%type;
    v_totalOverdueAmt        clmt.disc_rent_amt%type;
    v_rntRecovforCurrYr        clmt.disc_rent_amt%type;
    v_prvOverdueAmt            clmt.disc_rent_amt%type;
    v_RentAdjusted            clmt.disc_rent_amt%type;
    v_unelapsed_days1        number;
    v_unelapsed_rent1          number;
    v_totalunelapsedrent1     number;
    
        
cursor c1(v_solid varchar2,date1 varchar2,v_bankid varchar2) is 
select  clmt.sol_id,
        clmt.cif_id,
        cmg.cust_name,
        clmt.locker_type,
        clmt.locker_num,
        wlckm.rack_id,
        clmt.due_date v_due_date,
        (clmt.due_date + 1) v_prev_due,
        (clmt.renewal_date) v_next_due,
        add_months(clmt.renewal_date,-12) v_last_demand_date,
        clmt.disc_rent_amt    v_last_demand_amt,
        floor(ABS((due_date - decode(renewal_date,'',(due_date+1),renewal_date))/365)) v_overDuePrd
from    clmt,wlckm,cmg
where   wlckm.locker_num = clmt.locker_num
and       wlckm.sol_id = clmt.sol_id
and     cmg.cif_id  = clmt.cif_id
and       wlckm.status NOT IN ('S','A')
and        floor(ABS((due_date - decode(renewal_date,'',(due_date+1),renewal_date))/365)) > 0
and     clmt.del_flg!='Y'
and     wlckm.del_flg!='Y'
and      clmt.sol_id = v_solid
and      clmt.bank_id = wlckm.bank_id
and      wlckm.bank_id = v_bankid
and      clmt.disc_rent_amt > 0
UNION
select clmt.sol_id,
        clmt.cif_id,
        cmg.cust_name,
        clmt.locker_type,
        clmt.locker_num,
        wlckm.rack_id,
        clmt.due_date v_due_date,
        clmt.issue_date v_prev_due,
        clmt.renewal_date  v_next_due,
        add_months(clmt.renewal_date,-12) v_last_demand_date,
        clmt.disc_rent_amt    v_last_demand_amt,
        floor(ABS((due_date - decode(renewal_date,'',(due_date+1),renewal_date))/365)) v_overDuePrd
from    clmt,wlckm,cmg
where   wlckm.locker_num = clmt.locker_num
and     wlckm.sol_id = clmt.sol_id
and     cmg.cif_id  = clmt.cif_id
and     wlckm.status NOT IN ('S','A')
and        floor(ABS((clmt.due_date - decode(renewal_date,'',(due_date+1),renewal_date))/365)) = 0
and     clmt.del_flg!='Y'
and     wlckm.del_flg!='Y'
and      clmt.sol_id = v_solid
and      clmt.bank_id = wlckm.bank_id
and      wlckm.bank_id = v_bankid
and      clmt.disc_rent_amt > 0
and     date1 >= clmt.issue_date
order by 6,4;

BEGIN
--{
    OPEN c1(v_solid,date1,v_bankid);
    --{    
    LOOP
    --{ 
    
        FETCH c1 INTO v_sol_id,
                v_refno,
                v_cust_name,
                v_locker_type,
                v_locker_num,
                v_rack_id,            
                v_due_date,
                v_prev_due,
                v_next_due,
                v_last_demand_date,
                v_last_demand_amt,
                v_overDuePrd;
                 
        IF c1%NOTFOUND THEN
        --{
            CLOSE c1;
            EXIT;
        --}
        END IF;
        

        --------------------------------------------------------
        --To Arrive the Demand For current Financial Year
        --And Rent Recovered for Current Year
        --------------------------------------------------------- 
            BEGIN
            --{
                v_last_demand_amt := v_last_demand_amt;
                /**dbms_output.put_line(v_last_demand_amt);**/
                --To Arrive Over due Amount And Advance Amount--
                BEGIN
                --{
                    select (CASE WHEN (rent_payable_amount - rent_paid_amount) > 0
                    THEN (rent_payable_amount - rent_paid_amount)
                    ELSE 0
                    END),
                    (CASE WHEN (rent_payable_amount - rent_paid_amount) < 0
                    THEN ABS(rent_payable_amount - rent_paid_amount)
                    ELSE 0
                    END),
                    rent_payable_amount
                    INTO v_OverdueAmt,v_AdvanceRent,v_RentAdjusted
                    FROM LCPP
                    WHERE locker_number = v_locker_num
                    AND  cif_id = v_refno
                    AND sol_id = v_sol_id
                    AND bank_id = v_bankid
                    AND del_flg!='Y';
                EXCEPTION WHEN NO_DATA_FOUND THEN
                    v_OverdueAmt := NULL;
                    v_AdvanceRent := NULL;
                    v_RentAdjusted  := NULL;
                --}
                END;
        
                -------------------------------------------------------
                --To Arrive Total Rent Paid in Current Financial Period
                -------------------------------------------------------
                BEGIN
                --{
                    select nvl(sum(PAID_AMOUNT),0)
                    INTO v_RentPaid
                    FROM LCPD
                    WHERE TRAN_DATE between to_date(v_last_demand_date,'dd-mm-yyyy') AND
                    to_date(date1,'dd-mm-yyyy')    
                    AND    LOCKER_NUMBER = v_locker_num
                    AND cif_id = v_refno
                    AND substr(REMARKS,1,11) = 'LOCKER RENT'
                    AND sol_id = v_sol_id
                    AND bank_id = v_bankid
                    AND del_flg!='Y';
                EXCEPTION WHEN NO_DATA_FOUND THEN
                        IF (v_RentAdjusted = 0) THEN
                        --{    
                            v_RentPaid := v_last_demand_amt;
                        --}
                        ELSE
                        --{
                            v_RentPaid := 0;
                        --}
                        END IF;
                --}
                END;

                ------------------------------------------------------
                --To Arrive Total Rent Payable in Current Financial Period
                -----------------------------------------------------
                BEGIN
                --{

                    select nvl(sum(PAYABLE_AMOUNT),0)
                    into v_rentpayable
                    from lcpy
                    where to_date(ENTERED_TIME,'dd-mm-yyyy') between
                    to_date(v_last_demand_date,'dd-mm-yyyy') AND
                    to_date(date1,'dd-mm-yyyy')
                    AND LOCKER_NUMBER = v_locker_num
                    AND cif_id = v_refno
                    AND sol_id = v_sol_id
                    AND bank_id = v_bankid
                    AND del_flg!='Y';
                --}
                END;    

                --------------------------------------------------------
                --To Arrive Elapsed Days and UnElapsed Days based
                --On Report Date
                --------------------------------------------------------


                BEGIN
                --{
                        ---------------------------------------------------
                        --To Arrive the Demand For current Financial Year
                        --Here Next_due(Renewal date) should  be greater
                        --than the report date
                        ---------------------------------------------------

                        IF( v_next_due > date1 ) THEN
                        --{        
                              BEGIN
                              --{
                              while ( v_last_demand_date  > date1 )
                              loop
                              v_last_demand_date := add_months (v_last_demand_date,-12);
                              end loop;
                              
    
                            v_no_of_days := ABS(to_date(v_last_demand_date) - to_date(add_months(v_last_demand_date,12)-1));
                            --v_last_demand_date1 :=   substr(to_date(v_last_demand_date,'dd-mm-yyyy'),1,6) || substr(to_date(date1,'dd-mm-yyyy'),-4);
                            v_elapsed_days := ABS(to_date(date1) - to_date(v_last_demand_date));
                            v_unelapsed_days := ABS((v_no_of_days) - (v_elapsed_days));
                            v_unelapsed_days1 := ABS(to_date(date1) - (to_date(v_next_due,'dd-mm-yyyy')-1));
                            v_elapsed_rent  := (nvl(v_elapsed_days,0) * ((nvl(v_last_demand_amt,0))/(nvl(v_no_of_days,0))));
                            v_unelapsed_rent := ABS(v_last_demand_amt - v_elapsed_rent);
                            v_unelapsed_rent1 := (nvl(v_unelapsed_days1,0) * ((nvl(v_last_demand_amt,0))/(nvl(v_no_of_days,0))));
                            --v_totalunelapsed_rent := nvl(v_unelapsed_rent1,0) + nvl(v_AdvanceRent,0);
                             --}
                             END;
                              
                            
                        --}
                        ELSE
                        --{
                            v_no_of_days := ABS(to_date(v_last_demand_date) - to_date(add_months(v_last_demand_date,12)-1));
                            v_elapsed_days :=0;
                            v_unelapsed_days :=0;
                            v_elapsed_rent  :=0;
                            v_unelapsed_rent :=0;
                            v_totalunelapsed_rent :=0;
                            v_status := 'ARREARS';
                        --}
                        END IF;
                  --}
                  END;


                IF (NVL(v_OverdueAmt,0) > 0) THEN
                --{
                        IF ( NVL(v_OverdueAmt,0) < nvl(v_last_demand_amt,0)) THEN
                        --{
                            v_rntRecovforCurrYr := nvl(v_last_demand_amt,0) - nvl(v_OverdueAmt,0);
                        --}
                        ELSE
                        --{
                             v_rntRecovforCurrYr := 0;
                        --}
                        END IF;

                        IF ( NVL(v_rntRecovforCurrYr,0) > 0) THEN
                        --{
                            v_elapsed_rent := v_rntRecovforCurrYr;
                            v_unelapsed_rent := 0;
                            v_totalunelapsed_rent := 0;
                            v_status := 'ARREARS';
                        --}
                        ELSE
                        --{
                            v_elapsed_rent  :=0;
                            v_unelapsed_rent :=0;
                            v_totalunelapsed_rent :=0;
                            v_status := 'ARREARS';
                        --}
                        END IF;
                --}
                ELSE
                --{
                        v_elapsed_rent := v_elapsed_rent;
                        v_unelapsed_rent := v_unelapsed_rent;
                        v_totalunelapsed_rent := nvl(v_unelapsed_rent1,0) + nvl(v_AdvanceRent,0);
                        v_status := NULL;
                --}
                END IF;
                        
            --}
            END;

            
            dbms_output.enable(buffer_size => NULL);
            dbms_output.put_line (v_refno              ||'|'||
                    substr(v_cust_name,0,25)            ||'|'||
                    lpad(v_locker_type,5,' ')        ||'|'||
                    lpad(rpad(v_rack_id,5,' '),8,' ')            ||'|'||
                    rpad(lpad(v_locker_num,13,' '),14,' ')         ||'|'||
                    v_prev_due           ||'|'||
                    v_due_date             ||'|'||
                    v_next_due          ||'|'||
                    lpad(abs(v_last_demand_amt),13,' ')           ||'|'||
                    lpad(abs(v_no_of_days),12,' ')         ||'|'||
                    lpad(abs(v_elapsed_days),12,' ')       ||'|'||
                    lpad(abs(v_unelapsed_days),14,' ')     ||'|'||
                    lpad(round(abs(v_elapsed_rent),2),14,' ')       ||'|'||
                    lpad(round(abs(v_unelapsed_rent),2),16,' ')     ||'|'||
                    lpad(round(abs(v_AdvanceRent),2),14,' ')     ||'|'||
                    lpad(round(abs(v_totalunelapsed_rent),2),25,' ')     ||'|'||
                    v_status);
    --}    
    END LOOP;
    --}
--}
END;
/
spool off

