-- #############################################################
-- #	Source Name: asset.sql				   		           #
-- #	Description: This script is used to get the required   #
-- #				 details for ROD assets                    # 
-- #				 in ~ seperated format.                    #
-- #############################################################

Set ServerOutPut On Size 1000000
--Set Verify Off
--Set FeedBack off
--set line 80
set trims on

--Spool asset.txt

DECLARE

inpDate				varchar2(25);

-- Temporary variables.
building			UTL_FILE.FILE_TYPE;
vehicle				UTL_FILE.FILE_TYPE;
lncolltr			UTL_FILE.FILE_TYPE;
tmpAcid				GAM.acid%type;
cacid				GAM.acid%type;
acnum				GAM.foracid%type;
schmCode			GAM.schm_code%type;
cimnumb				CRMUSER.CMG.cif_id%type;
acCrncy				GAM.acct_crncy_code%type;
asOnDt				GAM.acct_opn_date%type;
addrtype			CRMUSER.CMG.address_type%type := 'X';
years				number := 0;
crncy				number(1) := 1;
tiebreak			number := 0;
yrbuilt				varchar2(4) := '';
det_line1			varchar2(1000) := '';
model				CVD.vehicle_model%type;
vehileId			CVD.vehicle_regn_num%type;
lstSix				CVD.vehicle_regn_num%type;
engine				CVD.vehicle_engine_num%type;
chassis				CVD.vehicle_chassis_num%type;
tibreak				CVD.secu_srl_num%type;
det_line2			varchar2(1000) := '';
effDate				CLD.life_insu_risk_cover_start%type;
tbreak 				CLD.secu_srl_num%type;
colltyp				number(1) := 6;
effChar				varchar2(10);
det_line3			varchar2(1000) := '';
l_bank_id			VARCHAR2(8) := '&2';

CURSOR 	RSP_CURSOR IS 
	SELECT 	gam.acid,cif_id,foracid,acct_crncy_code
	FROM 	gam,gac
	WHERE 	gam.acid = gac.acid
	AND		gam.schm_code in (	select 	distinct schm_code 
								from 	RSP 								
								where 	entity_cre_flg = 'Y'
								and 	del_flg != 'Y')
	AND		gac.dpd_cntr >= 1
	AND		gam.entity_cre_flg = 'Y'
	AND		gam.del_flg != 'Y'
	AND	        gam.bank_id = l_bank_id
	AND	        gac.bank_id = l_bank_id;

CURSOR C_CVD IS
	SELECT 	vehicle_model,vehicle_regn_num,trim(substr(lpad(vehicle_regn_num,20),15)),vehicle_engine_num,vehicle_chassis_num,secu_srl_num
	FROM 	CVD
	WHERE	secu_linkage_type ='A'
	AND		acid = tmpAcid
	AND		lchg_time >= to_date(inpDate,'DD-MM-YYYY HH24:MI:SS')
	AND		del_flg != 'Y'
	AND		bank_id = l_bank_id;

CURSOR C_CLD IS
	SELECT 	life_insu_risk_cover_start,secu_srl_num
	FROM 	CLD
	WHERE	secu_linkage_type ='A'
	AND		acid = tmpAcid
	AND		lchg_time >= to_date(inpDate,'DD-MM-YYYY HH24:MI:SS')
	AND		del_flg != 'Y'
	AND		bank_id = l_bank_id;


BEGIN
--{
	inpDate := '&1';

	building		:= UTL_FILE.FOPEN('/tmp','ex_building.csv','w');
	vehicle			:= UTL_FILE.FOPEN('/tmp','ex_vehicle.csv','w');
	lncolltr		:= UTL_FILE.FOPEN('/tmp','ex_lncolltr.csv','w');

	OPEN RSP_CURSOR;

	LOOP
	--{
		acnum := NULL;
		cimnumb := NULL;
		acCrncy := NULL;
	
		FETCH RSP_CURSOR into 	tmpAcid,cimnumb,acnum,acCrncy;

		EXIT WHEN RSP_CURSOR%NOTFOUND;
		
		BEGIN
		--{
			SELECT 	db_stat_date
			INTO	asOnDt
			FROM 	TBAADM.GCT
			WHERE	BANK_ID = l_bank_id;

		EXCEPTION
			WHEN OTHERS THEN NULL;
		--}
		END;
	
		IF (acnum is NOT NULL) THEN
		--{	
			BEGIN
			--{
				SELECT 	address_type
				INTO	addrtype
				FROM 	CRMUSER.CMG
				WHERE	cif_id = cimnumb
				AND		entity_cre_flg = 'Y'
				AND		del_flg != 'Y'
				AND		bank_id = l_bank_id;

			EXCEPTION
				WHEN OTHERS THEN addrtype := 'X';
			--}
			END;

			if ((addrtype = 'Home')or(addrtype = 'Registered'))then
				tiebreak := 1;
			elsif (addrtype = 'Mailing') then
				tiebreak := 2;
			elsif ((addrtype = 'Work')or(addrtype = 'Head Office')) then
				tiebreak := 3;
			else
				tiebreak := 4;
			end if;

			if (acCrncy = 'INR') then
				crncy := 1;
			elsif (acCrncy = 'USD') then
				crncy := 2;
			elsif (acCrncy = 'GBP') then
				crncy := 3;
			elsif (acCrncy = 'DEM') then
				crncy := 4;
			end if;
			
			BEGIN
			--{
				SELECT 	age_of_bulding_years,acid
				INTO	years,cacid
				FROM 	CID
				WHERE	secu_linkage_type ='A'
				AND		acid = tmpAcid
				AND		secu_srl_num = (select	max(secu_srl_num)
										from	CID
										where	secu_linkage_type ='A' 
										and		acid = tmpAcid
										and		del_flg != 'Y'
										and		bank_id = l_bank_id)
				AND		lchg_time >= to_date(inpDate,'DD-MM-YYYY HH24:MI:SS')
				AND		bank_id = l_bank_id;

			EXCEPTION
				WHEN OTHERS THEN 
					years := 0;
					cacid := NULL;
			--}
			END;

			IF (years != 0 and cacid is NOT NULL) THEN
			--{
				BEGIN
				--{
					SELECT 	to_char(asOnDt,'YYYY') - to_char(years)
					INTO	yrbuilt
					FROM	DUAL;

				EXCEPTION WHEN OTHERS THEN
					yrbuilt := '';
				--}
				END;

				det_line1 := acnum||'~'||cimnumb||'~1~~0~~~~'||yrbuilt||'~'||tiebreak;
				UTL_FILE.PUT_LINE(building,det_line1);

			--}
			END IF;

			OPEN C_CVD;

			LOOP
			--{
				model := NULL;
				vehileId := NULL;
				lstSix := NULL;
				engine := NULL;
				chassis := NULL;
				tibreak := NULL;

				FETCH C_CVD into model,vehileId,lstSix,engine,chassis,tibreak;

				EXIT WHEN C_CVD%NOTFOUND;
				
				if (tibreak is NOT NULL) then
					det_line2 := acnum||'~~~-~'||model||'~~'||tibreak||'~1~'||vehileId||'~'||lstSix||'~1900~'||engine||'~'||chassis;
					UTL_FILE.PUT_LINE(vehicle,det_line2);
				end if;
			--}
			END LOOP;

			CLOSE C_CVD;

			OPEN C_CLD;

			LOOP
			--{
				effDate := NULL;
				tbreak := NULL;

				FETCH C_CLD into effDate,tbreak;

				EXIT WHEN C_CLD%NOTFOUND;
				
				if (tbreak is NOT NULL) then
				--{
					if (schmCode = 'HMOAD') then
						colltyp := 1;
					elsif (schmCode = 'CAROD') then
						colltyp := 4;
					else
						colltyp := 6;
					end if;

					begin
					--{
						select	to_char(effDate,'mm-dd-yyyy')
						into	effChar
						from	DUAL;
					exception
						WHEN OTHERS THEN NULL;
					--}
					end;

					det_line3 := acnum||'~~0~'||cimnumb||'~'||colltyp||'~~'||crncy||'~0~~~~~'||effChar||'~0~0~~~~'||tbreak;
					UTL_FILE.PUT_LINE(lncolltr,det_line3);
				--}
				end if;
			--}
			END LOOP;

			CLOSE C_CLD;
		--}
		END IF;
	--}
	END LOOP;

	UTL_FILE.FCLOSE(building);
	UTL_FILE.FCLOSE(vehicle);
	UTL_FILE.FCLOSE(lncolltr);
	CLOSE RSP_CURSOR;
--}
END;
/
exit
spool off
