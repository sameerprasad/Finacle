rem Accept solid prompt " Enter the SolId :"
rem Accept fromdate prompt " Enter the FromDate :"
rem Accept todate prompt " Enter the Todate :"
SET SERVEROUTPUT ON SIZE 1000000
SET PAGESIZE 64
SET LINESIZE 132
SET HEADING ON
SET FEEDBACK OFF
SET VERIFY OFF
SET TERM  OFF
spool tdsip
break on CustId skip 2 on report
compute sum of INT on report
compute sum of STFL_AMT on report
compute sum of TDS_AMT on report
compute sum of INT on CustId
compute sum of STFL_AMT on CustId
compute sum of TDS_AMT on CustId
select substr(foracid,1,12) AcctNum ,'|',
		TDS.cust_id CustId ,'|',
		substr(gam.acct_name,1,35) ACCT, '|',
		to_char(TDS.tran_date,'DD-MM-YYYY') TRANDATE , '|',
		int_amt INT ,'|',shortfall_amt STFL_AMT ,'|' ,
		(tds_from_org_acct+tds_from_op_acct+tds_from_suspense_acct) TDS_AMT ,'|',
		substr(tds.tds_rate,1,5) RATE, '|',
		tds_cert_num 
from gam,tds
where
tds.sol_id = '&1' and
tds.tran_date >= to_date('&2','dd-mm-yyyy') and
tds.tran_date <= to_date('&3','dd-mm-yyyy') and
tds.acid = gam.acid 
and tds.sol_id = gam.sol_id
and (tds.tds_from_org_acct+tds.tds_from_op_acct+tds.tds_from_suspense_acct) > 0
and tds_cert_num not like 'TDSCESSCORR%'
and gam.bank_id = '&4' and tds.bank_id = '&4'
order by tds.cust_id , tds.tran_date,foracid
/
spool off
SET TERM  ON
