REM 'SCRIPT FOR FINDING ACCOUNT with 0 balance but not closed'
REM 'AUTHOR :: Mukesh Kumar Jain""
rem accept solid prompt 'ENTER THE SOL_ID OF YOUR BRANCH : '
set pages 60
set lines 132
set echo off
set feedback off
set termout off
set verify off
col subgl format a5
set newpage 0
define all_dashes = '___________________________________________________________________________'
column today new_value today_date
column bran new_value br
select to_char(sysdate,'dd-mm-yyyy:hh24:mi:ss') today
from dual;
select br_name bran from bct
where br_code = (select br_code from sol where sol_id = '&1' and bank_id='&2');

ttitle center  'ICICI BANK LTD.' skip 1 -
center br skip 1 -
center ' REPORT of 0 BALANCE Accounts pending closure/transacations' today_date skip 1 - 
left all_dashes skip 2
break on cust_stat_code skip 2 on report
spool ppazero
select cust_stat_code,gam.cust_id,
foracid acct_no,acct_name NAME
from CRMUSER.cmg,gsh,gam
where gam.sol_id = '&1'
and acct_cls_flg != 'Y'
and clr_bal_amt+un_clr_bal_amt = 0
and acct_ownership = 'C'
and gsh.sol_id = '&1'
and gsh.gl_sub_head_code = gam.gl_sub_head_code
and gsh.crncy_code = gam.acct_crncy_code
and cmg.cust_id=gam.cust_id
and gam.bank_id='&2'
order by 1,3
/
set feedback on
set feedback on
set verify on
set heading on
clear breaks
clear computes
spool off
set echo on
exit
