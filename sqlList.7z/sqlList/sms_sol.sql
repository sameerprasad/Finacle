--===================================================================================================================
--  Filename                :   sms_sol.sql
--  Description             :
--  Date                    :   06-09-2012
--  Author                  :   Swaroop K Tiruvoipati
--  Menu Option             :
--  Modification History
--    Sl. #           Date           Author                     Modification
--    -----           -----          --------                    ----------------
--    1               06-09-2012     Swaroop K Tiruvoipati      Original Version
--                                                              (Ported from 7.x)
--===================================================================================================================
--/* set id ,begin sol id ,end sol id */ of 15
set serveroutput on
set pages 0
set feedback off
set echo off
spool brlist.txt
declare
id number :=1;
rang number :=25;
cnt number :=0;
startsol varchar2(4);
endsol varchar2(4);
cursor sollst is select sol_id from sol where sol_id > '0027' and BANK_ID = '&1' order by sol_id;
--cursor sollst is select sol_id from sol where set_id=1 and BANK_ID = '&1' order by sol_id;
begin
dbms_output.put_line('"0001|0010');
dbms_output.put_line('"0011|0020');
dbms_output.put_line('"0021|0027');
        for solrec in sollst
        loop
                if(cnt=0)then
                 startsol := solrec.sol_id;
                end if;
                cnt := cnt + 1;
                endsol := solrec.sol_id;
                if(cnt=rang)then
                 cnt := 0;
                 dbms_output.put_line('"'||startsol||'|'||endsol);
                 id := id + 1;
                end if;
        end loop;
                 dbms_output.put_line('"'||startsol||'|'||endsol);
end;
/
spool off
