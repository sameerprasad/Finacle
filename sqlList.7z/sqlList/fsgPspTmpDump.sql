
-- Program Name    : fsgPspTmpDump.sql
-- Author          : Mandar Raddi
-- Date Written	   : 27-Feb-2001
--
-- -----------------------------------------------------------------------------------#   
-- Brief Description :                                                                #
-- -----------------------------------------------------------------------------------#
-- This PL/SQL program is responsible for creating Customer ID and Accout ID lists    #
-- in the PSP_TMP table for the given Sol ID. These two lists are required in the     #
-- Customer Statement generation process. This program creates the List id as         # 
-- Run ID (Input to the program) + 'C' for customer ids and Run ID + 'A' for accounts #
-- for the customers.                                                                 #
-- -----------------------------------------------------------------------------------# 
--                                 Version History                                    #
-- -----------------------------------------------------------------------------------#
--   Ver.No |     Date   |    Author    |           Reason For Change                 #
-- -----------------------------------------------------------------------------------#
--     1    | 27-02-2001 | Mandar Raddi | Initial Release                             #
--     2    | 28-02-2013 | Anish Ravi Kumar  | Table schema and Query tuning.	      #
-- -----------------------------------------------------------------------------------#

set serveroutput on size 1000000
set feedback off
set verify   off
set termout   off
set pages 0
set linesize 512
set trims on
spool &1-&2-&3-&4

variable maxIdType char(1);
-- -------------------------#
-- Start of DELCARE Section 
-- -------------------------#

DECLARE
cnt				number;
firstAcc			GAM.FORACID%Type;
beginCustId			ICICI_CIFT.CIF_ID%Type;
endCustId			ICICI_CIFT.CIF_ID%Type;
ciftCustId			ICICI_CIFT.CIF_ID%Type;
ciftEmailId			ICICI_CIFT.EMAIL_ID%Type;
ciftStmtReqd			ICICI_CIFT.STMT_REQD%Type;
cmgCustStatCode		CMG.CUST_STAT_CODE%Type;
gamForacid			GAM.FORACID%Type;
gamAcid			GAM.ACID%Type;
custSolId			TBAADM.PSP_TMP.HOME_SOL_ID%Type;
custRecType			VARCHAR(3);
custSubRecType		VARCHAR(3);
pspCustListId		TBAADM.PSP_TMP.LISTID%Type;
pspAcctListId		TBAADM.PSP_TMP.LISTID%Type;
endOfCiftCursor     NUMBER;
endOfGamCursor      NUMBER;
acctFound      NUMBER;
gamTxn      NUMBER;
stmtReqd	CHAR;
chooseThisCustId    CHAR;
custStatSelectFlag  CHAR;
custStatArr 		iciArray.arrayType;
custStatCodes		VARCHAR2(100);
custStatCnt			NUMBER(5);
commitCnt			NUMBER(5);
step				NUMBER(5);
likeStr				varchar2(25);
idType				CHAR(2);
idTypeOld				CHAR(1);
dispMode      		CHAR;
dispMode1      		CHAR;
	
cmgTitleName		varchar2(200);
cmgAddr1			CMG.cust_comu_addr1%TYPE;
cmgAddr2			CMG.cust_comu_addr2%TYPE;
cmgCityCode			CMG.cust_comu_city_code%TYPE;
cmgStateCode		CMG.cust_comu_state_code%TYPE;
cmgCntryCode		CMG.cust_comu_cntry_code%TYPE;
cmgPinCode			CMG.cust_comu_pin_code%TYPE;
cmgPhone1			CNMA.phone_num1%TYPE;
cmgPhone2			CNMA.phone_num2%TYPE;
cityDesc			RCT.ref_desc%TYPE;
stateDesc			RCT.ref_desc%TYPE;
cntryDesc			RCT.ref_desc%TYPE;

carRec				varchar2(500);
runId				varchar2(10);

CURSOR ciftCur IS
SELECT	
	CIF_ID,
	lower(EMAIL_ID),
	stmt_reqd
FROM	
	ICICI_CIFT
WHERE	
	CIF_ID BETWEEN beginCustId AND endCustId
AND	HOME_SOL_ID = custSolId
AND	STMT_REQD = dispMode 
AND bank_id='&13'
ORDER BY cif_id;


CURSOR gamCur IS 
SELECT	
	acid,foracid
FROM	
	GAM
WHERE	
	CIF_ID = ciftCustId
AND	(SCHM_TYPE = 'SBA' OR ACCT_PREFIX = '05' OR ACCT_PREFIX = '51')
AND	((ACCT_CLS_FLG = 'N' AND ACCT_OPN_DATE <= '&8') OR
	 (ACCT_CLS_FLG = 'Y' AND ACCT_CLS_DATE > '&8'))
AND	ENTITY_CRE_FLG = 'Y'  AND bank_id='&13'
and     last_any_tran_date >= '&7' order by foracid ;
-- --------------------------------------------------------------------------------#
-- PROCEDURE to Select customer details from CMG. The customer id is selected from #
-- ICICI_CIFT for the input SOL ID                                                 #
-- --------------------------------------------------------------------------------#

PROCEDURE getCmgData(dummy NUMBER) IS
BEGIN
	BEGIN
		step := 3;
	-- Code changed by Anish on 27-Feb-2013 for TOL
	--	SELECT  CMG.cust_title_code || '.' || cust_name,
        --                        cust_comu_addr1,
        --                        cust_comu_addr2,
        --                        cust_comu_city_code,
        --                        cust_comu_state_code,
        --                        cust_comu_cntry_code,
        --                        cust_comu_pin_code,
        --                        phone_num1,
        --                        phone_num2,
        --                        cust_stat_code

	-- Changed SQL.
		SELECT  CMG.cust_title_code || '.' || cust_name,
			 	cnma.ADDRESS1,
				cnma.ADDRESS2,
				cnma.CITY_CODE,
				cnma.STATE_CODE,
				cnma.CNTRY_CODE,
				cnma.PIN_CODE,
				phone_num1,
				phone_num2,
				cust_stat_code
                INTO    cmgTitleName,
                                cmgAddr1,
                                cmgAddr2,
                                cmgCityCode,
                                cmgStateCode,
                                cmgCntryCode,
                                cmgPinCode,
                                cmgPhone1,
                                cmgPhone2,
                                cmgCustStatCode
                FROM    CMG, CNMA
                WHERE   CIF_ID = ciftCustId  
                AND 	cnma.ADDR_B2KID=cmg.CIF_ID
        	AND 	cnma.ADDR_ID = cmg.ADDRESS_TYPE
	        AND 	CMG.BANK_ID='&13'
	        AND 	cnma.BANK_ID = '&13';

		if (cmgCityCode is not null) then
			BEGIN
			SELECT	ref_desc
			INTO	cityDesc
			FROM	RCT
			WHERE	ref_rec_type = '01'
			AND		ref_code = cmgCityCode  AND bank_id='&13';
			EXCEPTION WHEN OTHERS THEN NULL;
			END;
		else
			cityDesc := '';
		end if;

		if (cmgStateCode is not null) then
			BEGIN
			SELECT	ref_desc
			INTO	stateDesc
			FROM	RCT
			WHERE	ref_rec_type = '02'
			AND		ref_code = cmgStateCode  AND bank_id='&13';
			EXCEPTION WHEN OTHERS THEN NULL;
			END;
		else
			stateDesc := '';
		end if;

		if (cmgCntryCode is not null) then
			BEGIN
			SELECT	ref_desc
			INTO	cntryDesc
			FROM	RCT
			WHERE	ref_rec_type = '03'
			AND		ref_code = cmgCntryCode  AND bank_id='&13';
			EXCEPTION WHEN OTHERS THEN NULL;
			END;
		else
			cntryDesc := '';
		end if;

		EXCEPTION
		WHEN NO_DATA_FOUND THEN 
			chooseThisCustId := 'N';
			RETURN;
	END;

	IF (custStatSelectFlag = 'O') THEN
		chooseThisCustId := 'N';
	ELSE
		chooseThisCustId := 'Y';
	END IF;

	FOR item IN 0..TO_NUMBER(custStatCnt - 1) LOOP
	BEGIN
		IF (custStatSelectFlag = 'E' AND cmgCustStatCode = custStatArr(item)) THEN
			chooseThisCustId := 'N';
			RETURN;
		END IF;
		IF (custStatSelectFlag = 'O' AND cmgCustStatCode = custStatArr(item)) THEN
			chooseThisCustId := 'Y';
			RETURN;
		END IF;
	END;
	END LOOP;

END getCmgData;


PROCEDURE insertPspTmp( pspListId VARCHAR2,
	                pspEntityId VARCHAR2,
	                pspEntityType CHAR,
			pspHomeSolId VARCHAR2) IS
BEGIN
	step := 5;
	INSERT INTO
	TBAADM.PSP_TMP
		(LISTID
		,ENTITY_ID
		,ID_TYPE
		,HOME_SOL_ID,bank_id)
	VALUES
		(pspListId
		,pspEntityId
		,pspEntityType
		,pspHomeSolId,'&13');
END insertPspTmp;


PROCEDURE processGamCursor( dummy NUMBER) IS
BEGIN
step := 4;
FOR gamCur_rec in gamCur
LOOP --{
    begin
	IF( gamCur%NOTFOUND ) then
		endOfGamCursor := 1;
		RETURN;
	END IF; 
	gamTxn := 0;
	begin
       	SELECT	1
		INTO	gamTxn
		FROM	DUAL
		WHERE	EXISTS(	SELECT	*
						FROM	CTD 
						WHERE	acid=gamCur_rec.acid
						AND		tran_date >= '&7'
						AND 	tran_date <= '&8'  AND bank_id='&13');
		EXCEPTION
		WHEN NO_DATA_FOUND THEN
			gamTxn := 0;
	end;
	if(gamTxn > 0) then
		acctFound := 1;	
        	if (substr(gamCur_rec.foracid,5,2) != '51') then
			insertPspTmp(pspAcctListId, gamCur_rec.foracid, idTypeOld, custSolId);
        	else
           		if (stmtReqd = 'E' and dispMode1 != 'X' ) then
				insertPspTmp(pspAcctListId, gamCur_rec.foracid, idTypeOld, custSolId);
           		end if;
        	end if;
	end if;
	if (cnt = 0) then
		firstAcc :=  gamCur_rec.foracid;
		cnt := 1;
	end if;
    end;
end loop;
END processGamCursor;
		

PROCEDURE processCiftCursor( dummy NUMBER ) IS
BEGIN
	step := 2;
	FETCH ciftCur 
	INTO ciftCustId,
		ciftEmailId,
		ciftStmtReqd;

	IF (ciftCur%NOTFOUND) then
		endOfCiftCursor := 1;
		RETURN;
	END IF;

	getCmgData(0);

	IF (chooseThisCustId = 'N') THEN
		RETURN;
	END IF;

	endOfGamCursor := 0;
	acctFound := 0;
	cnt := 0;
	stmtReqd :=ciftStmtReqd;
	firstAcc := '';
	processGamCursor(0);

	if( (acctFound = 1 or (ciftStmtReqd = 'E' and dispMode1 != 'X') ) and cnt > 0 ) then
	insertPspTmp(pspCustListId, ciftCustId, idTypeOld, custSolId);

	  if ( ciftStmtReqd = 'E'  and dispMode1 != 'X' ) then
               dbms_output.put_line(    custSolId               || '|' ||
                                ciftCustId              || '|01|0|' ||
                                ciftEmailId             || '|' ||
                                ltrim(rtrim(cmgTitleName))    || '|' ||
                                ltrim(rtrim(cmgAddr1))                || '|' ||
                                ciftCustId               || '|' ||
                                ltrim(rtrim(cityDesc))              || '|' ||
                                ltrim(rtrim(stateDesc)) || '|' ||
                                ltrim(rtrim(cntryDesc)) || ' - ' ||
                                ltrim(rtrim(cmgPinCode)) || '|' ||
                                cmgCustStatCode || '|' ||
                  ciftStmtReqd ||'|'||firstAcc|| '|' ||'CustomerStateMent');
                        else
								ciftStmtReqd := 'Y';
                                dbms_output.put_line(    custSolId               ||
'|' ||
                                ciftCustId              || '|01|0|' ||
                                ''             || '|' ||
                                ltrim(rtrim(cmgTitleName))    || '|' ||
                                ltrim(rtrim(cmgAddr1))                || '|' ||
                                ltrim(rtrim(cmgAddr2))               || '|' ||
                                ltrim(rtrim(cityDesc))              || '|' ||
                                ltrim(rtrim(stateDesc))             || '|' ||
                                ltrim(rtrim(cntryDesc))            || ' - ' ||
                                ltrim(rtrim(cmgPinCode   ))           || '|' ||
                                cmgCustStatCode || '|' ||
                                ciftStmtReqd ||'|' ||
								ltrim(rtrim(cmgPhone1)) || ' - '||
								ltrim(rtrim(cmgPhone2)) || '|');
                         end if;
	end if;
END processCiftCursor;


BEGIN
	cnt				:= 0;
	runId				:= '&1';
	custSolId			:= '&2';
	idType              := substr('&4',1,2);
   idTypeOld           := substr('&4',1,1);
	beginCustId			:= lpad('&5', 9);
	endCustId			:= lpad('&6', 9);
	custStatSelectFlag	:= '&9';
	custStatCodes 		:= '&10';
	dispMode 			:= '&11';
	dispMode1 			:= '&12';

	pspCustListId		:= runId||custSolId||idType||'C';
	pspAcctListId		:= runId||custSolId||idType||'A';

	commitCnt := 0;

	custRecType			:= '01';
	custSubRecType		:= '0';

	likeStr		:= runId||custSolId||idType||'%';

	step := 1;
	iciArray.construct(custStatCodes, ',' , custStatCnt, custStatArr);

	DELETE FROM
		TBAADM.PSP_TMP
	WHERE
		LISTID LIKE likeStr 
		AND home_sol_id = custSolId  AND bank_id='&13';
	
	COMMIT;

	OPEN ciftCur;

	endOfCiftCursor := 0;

	WHILE (endOfCiftCursor = 0) LOOP
		processCiftCursor(0);
		commitCnt := commitCnt + 1;
		IF (commitCnt = 1000) THEN
			COMMIT;
			commitCnt := 0;
		END IF;
	END LOOP;

	CLOSE ciftCur;

	COMMIT;

	EXCEPTION
	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('<#ORA-ERROR#>');
		DBMS_OUTPUT.PUT_LINE('Cust Id/Account Id list creation failed at step...'||step);
		DBMS_OUTPUT.PUT_LINE('Cust Id '||ciftCustId);
		DBMS_OUTPUT.PUT_LINE('Check SQL error,  and try again');
		DBMS_OUTPUT.PUT_LINE('Sql Error Code is        : ' || SQLCODE );
		DBMS_OUTPUT.PUT_LINE('SQL Error Description is : '|| SQLERRM);
		ROLLBACK;
		DBMS_OUTPUT.PUT_LINE('Currenct Chunk rolled back.');
END;
/
spool off
