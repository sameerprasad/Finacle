REM####################################################################
REM File Name   : SPCTC2_REPAY.sql
REM Description : Suppliers Credit Repayment Info for TC-2
REM Author      : Paresh Maru
REM Date        : 24-04-2011
REM Module	: Trade Credit
REM####################################################################

REM TABLE NAME: SUP_CR_TC2_REPAY

REM SYNONYM:    SPCTC2_REPAY

drop table icici.SUP_CR_TC2_REPAY
/
drop public synonym SPCTC2_REPAY
/
create table icici.SUP_CR_TC2_REPAY
(
suppliers_credit_ref_no     VARCHAR2(30 CHAR),
dc_ref_no           VARCHAR2(16 CHAR),
dc_sol_id           VARCHAR2(8 CHAR),
App_Amt             VARCHAR2(30 CHAR),
crncy               VARCHAR2(3 CHAR),
Opening_Bal         VARCHAR2(30 CHAR),
Disb_Amt            VARCHAR2(30 CHAR),
Disb_Date           DATE,
Repay_Amt           VARCHAR2(30 CHAR),
Repay_Date          DATE,
Int_Amt             VARCHAR2(30 CHAR),
Int_Date            DATE,
Int_Bill_ref_no     VARCHAR2(16 CHAR),
ENTITY_CRE_FLG      CHAR(1),
DEL_FLG             CHAR(1),
LCHG_USER_ID        VARCHAR2(15 CHAR),
LCHG_TIME           DATE,
RCRE_USER_ID        VARCHAR2(15 CHAR),
RCRE_TIME           DATE,
bill_no				VARCHAR2(15 CHAR),
ship_date           DATE,
fr_date             DATE,
bank_id                 VARCHAR2(8 CHAR)
)
/* STORE_START */
TABLESPACE ICICI_CUST_SMALL
/* STORE_END */
/
create public synonym SPCTC2_REPAY for icici.SUP_CR_TC2_REPAY
/
grant select, insert, update, delete on SPCTC2_REPAY to tbagen
/
grant select on SPCTC2_REPAY to tbacust
/
grant select on SPCTC2_REPAY to tbautil
/
grant all on SPCTC2_REPAY to tbaadm
/
