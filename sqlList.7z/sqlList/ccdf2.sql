set feed off head off verify off
set colsep '|'
set line 2000
set pages 0
set trims on
spool ccdf2
select * from (select gam.foracid||'|'|| substr(gam.acct_name,1,30) ||'|'|| substr(rct.ref_desc,1,10) ||'|'|| gam.DRWNG_POWER ||'|'|| (gam.clr_bal_amt) ||'|'|| (gam.un_clr_bal_amt) ||'|'|| ((clr_bal_amt+drwng_power)-(lien_amt+system_reserved_amt))  
from cmg,gam,sol,rct
where gam.sol_id=sol.sol_id
and cmg.cust_id=gam.cust_id
and cmg.cust_stat_code=upper('&1')
and gam.schm_code='CCDF2'
and gam.acct_cls_flg!='Y'
and gam.del_flg!='Y'
and rct.ref_rec_type='01'
and nvl(sol.city_code,'*')=rct.ref_code
and rct.bank_id = sol.bank_id
and sol.bank_id = cmg.bank_id 
and cmg.bank_id = gam.bank_id 
and gam.bank_id = '&2'
order by gam.foracid)
/
spool off
host cp ccdf2.lst ccdf2&1..lst 2>/dev/null
host mailx -s ccdf2&1..lst -s "REPORT OF LIMIT AND LIABILITY IN CCDF2 ACCOUNTS FOR &1" charudatta.patwardhan@icicibank.com < /dev/null
host mailx -s ccdf2&1..lst -s "REPORT OF LIMIT AND LIABILITY IN CCDF2 ACCOUNTS FOR &1" lorraine.misquita@icicibank.com < /dev/null
host mailx -s ccdf2&1..lst -s "REPORT OF LIMIT AND LIABILITY IN CCDF2 ACCOUNTS FOR &1" ritu.malhotra@icicibank.com < /dev/null
host mailx -s ccdf2&1..lst -s "REPORT OF LIMIT AND LIABILITY IN CCDF2 ACCOUNTS FOR &1" cops-inventoryfunding@icici.com < /dev/null
host mailx -s ccdf2&1..lst -s "REPORT OF LIMIT AND LIABILITY IN CCDF2 ACCOUNTS FOR &1" anil.ahuja@icicibank.com < /dev/null
host mailx -s ccdf2&1..lst -s "REPORT OF LIMIT AND LIABILITY IN CCDF2 ACCOUNTS FOR &1" mandar.mithbawkar@icicibank.com < /dev/null
host mailx -s ccdf2&1..lst -s "REPORT OF LIMIT AND LIABILITY IN CCDF2 ACCOUNTS FOR &1" sanjay.saboo@icicibank.com < /dev/null
host mailx -s ccdf2&1..lst -s "REPORT OF LIMIT AND LIABILITY IN CCDF2 ACCOUNTS FOR &1" mitul.parekh@icicibank.com < /dev/null
host mailx -s ccdf2&1..lst -s "REPORT OF LIMIT AND LIABILITY IN CCDF2 ACCOUNTS FOR &1" shekhar.v@icicibank.com < /dev/null
host mailx -s ccdf2&1..lst -s "REPORT OF LIMIT AND LIABILITY IN CCDF2 ACCOUNTS FOR &1" raghavan.ck@icicibank.com < /dev/null
host mailx -s ccdf2&1..lst -s "REPORT OF LIMIT AND LIABILITY IN CCDF2 ACCOUNTS FOR &1" vinod.thembari@icicibank.com < /dev/null
host mailx -s ccdf2&1..lst -s "REPORT OF LIMIT AND LIABILITY IN CCDF2 ACCOUNTS FOR &1" ashok.rajoria@icicibank.com < /dev/null
host mailx -s ccdf2&1..lst -s "REPORT OF LIMIT AND LIABILITY IN CCDF2 ACCOUNTS FOR &1" pratik.bugade@icicihfc.com < /dev/null
exit
