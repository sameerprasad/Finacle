set feedback off
set echo off
set head off


/*
!rm -f /tmp/lienRESFC.lst
!touch /tmp/lienRESFC.lst
!chmod 777 /tmp/lienRESFC.lst  
*/
set serveroutput on size 1000000
set trimspool on
set lines 250
set pages 0
set feedback off
spool lienRESFC.lst

select 'SRLNO|ACCOUNT NO|CUSTOMER NAME    |LIEN AMOUNT|LIEN DATE|EXPIRY DATE|LIEN REASON CODE|REMARKS |MAKER|CHECKER|' from dual   
/
declare
/*
	loc_fp         		utl_file.file_type;
	loc_filename  		varchar2(200);
	loc_filepath 		varchar2(100);
	loc_filemode 		varchar(10);
*/
	genrep 			number;
	repdt  			date;
	crepdt  		date;
	repdd  			number;
	repmmyyyy 		char(6);
	hldy 			char(1);
	recline			varchar2(500);
	reccnt			number;

cursor lien1 (dt in date) is
select 
	foracid, 
	acct_name, 
	alt.lien_amt lien_amt, 
	alt.rcre_time lien_created_date, 
	lien_expiry_date, 
	lien_reason_code,
	lien_remarks, 
	alt.rcre_user_id lien_maker, 
	alt.lchg_user_id lien_checker
from alt, gam 
where 
	alt.acid = gam.acid and 
	lien_reason_code = 'RESFC' and 
	alt.del_flg = 'N' and 
	alt.entity_cre_flg = 'Y' and
	lien_expiry_date <= dt;

begin
/*
	loc_filepath := '/tmp';
	loc_filename := 'lienRESFC.lst';
	loc_filemode := 'w';
	loc_fp := utl_file.fopen(loc_filepath, loc_filename, loc_filemode);
*/

	select db_stat_date into repdt from gct;

	crepdt := repdt;
	genrep := 0;
	while (genrep = 1)
	loop
		crepdt := repdt;
		repdt := repdt + 1;
		repdd := to_number(to_char(repdt, 'dd'));
		repmmyyyy := to_char(repdt, 'mmyyyy');

		select substr(hldy_str,repdd,1) into hldy from hol where 
		cal_b2k_type = 'DC' and mmyyyy = repmmyyyy ;

		if (hldy = 'Y') then
			genrep := 1;
		else
			genrep := 0;
		end if;
	end loop;

	reccnt := 0;
	for rec in lien1(crepdt)
	loop
		reccnt  := reccnt + 1;
		recline := 	
			to_char(reccnt)		|| '|' || 
			rec.foracid 		|| '|' ||
			rec.acct_name 		|| '|' ||
			rec.lien_amt 		|| '|' ||
			rec.lien_created_date 	|| '|' ||
			rec.lien_expiry_date 	|| '|' ||
			rec.lien_reason_code	|| '|' ||
			rec.lien_remarks 	|| '|' ||
			rec.lien_maker 		|| '|' ||
			rec.lien_checker ;

			--utl_file.put_line(loc_fp, recline);
			dbms_output.put_line(recline);
	end loop;

	--utl_file.fclose(loc_fp);
				
end;
/
spool off
