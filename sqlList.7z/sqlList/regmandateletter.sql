--===================================================================================================================
--  Filename                :   regmandateletter.sql
--  Description             :
--  Date                    :   05-09-2012
--  Author                  :   Swaroop K Tiruvoipati
--  Menu Option             :
--  Modification History
--    Sl. #           Date           Author                     Modification
--    -----           -----          --------                    ----------------
--    1               05-09-2012     Swaroop K Tiruvoipati      Original Version
--                                                              (Ported from 7.x)
--===================================================================================================================
Set ServerOutPut On Size 1000000
set pagesize 0  linesize 500  trims on echo off termout off pause off feedback off verify off heading off space 0
spool  amitabh.lst

declare
fp              utl_file.file_type;
out_rec         varchar2(1000);
repdt                   date;
foracid_nri		varchar2(15);
schm_code		VARCHAR2(5);
MANDATE_HOLDER		varchar2(15);
mandate_cust_id1		 varchar2(15);
mandate_CUST_NAME	 VARCHAR2(80);
mandate_CUST_PERM_ADDR1  varchar2(45);
mandate_CUST_PERM_ADDR2		varchar2(45);
mandate_CUST_PERM_CITY_CODE	varchar2(5);
mandate_CUST_PERM_STATE_CODE	varchar2(5);
mandate_CUST_PERM_PIN_CODE	varchar2(6);
mandate_CUST_PERM_CNTRY_CODE	varchar2(5);
mandate_CUST_PERM_PHONE_NUM	varchar2(15);
CUST_Email			VARCHAR2(50);
CUST_PERM_CITY_CODE1		varchar2(50);
CUST_PERM_STATE_CODE1        varchar2(50);
CUST_PERM_CNTRY_CODE1		varchar2(50);
mandate_CUST_PERM_CITY_CODE1	varchar2(50);
mandate_CUST_PERM_STATE_CODE1    varchar2(50);
mandate_CUST_PERM_CNTRY_CODE1	varchar2(50);

cursor	mandate(date varchar) is
--{
select
                I.FORACID_NRI                   foracid_nri,
                I.CUST_ID_MANDATE_HOLDER        MANDATE_HOLDER,
                G.CIF_ID                       cust,
                CF.CIF_ID                      cf_cust,
				nvl(CF.EMAIL_ID,' ')			mail
from      ICICI_MANDATE_HOLDER I,ICICI_CIFT CF,GAM G
where   G.foracid       =  I.FORACID_NRI
and     G.CIF_ID       =  CF.CIF_ID
and       G.CIF_ID       =  CF.CIF_ID
and	nvl(CF.EMAIL_ID,' ') = ' '
--and       to_date(I.LCHG_TIME) = '04-01-2010';
and       to_date(I.LCHG_TIME,'dd-mm-yyyy') = repdt
and     I.BANK_ID = '&2'
and     CF.BANK_ID = '&2'
and     G.BANK_ID = '&2';
--};

cursor	main_details(foracidnri varchar) is
select 
	G.foracid			foracid_nre,
	G.SCHM_CODE			schm_code,
	C.cif_id 			cif_id,
	C.CUST_NAME			CUST_NAME,
	a.address_line1			CUST_PERM_ADDR1,
	a.address_line2			CUST_PERM_ADDR2,
	a.city_code			CUST_PERM_CITY_CODE,
	a.zip				CUST_PERM_PIN_CODE,
	a.country_code			CUST_PERM_CNTRY_CODE,
	a.state_code			CUST_PERM_STATE_CODE,
	p.phoneno1			CUST_PERM_PHONE_NUM,
	nvl(p.email,' ')			CUST_Email
from	cmg C,gam G,CRMUSER.ADDRESS a,CRMUSER.phoneemail p
where    G.foracid 	=  foracidnri
and nvl(p.email,' ') = ' '
and 	C.cif_id	= G.cif_id
and	a.orgkey = G.cif_id
and 	p.orgkey = G.cif_id
and     C.BANK_ID = '&2'
and 	a.BANK_ID = '&2'
and 	p.BANK_ID = '&2'
and     G.BANK_ID = '&2';
begin
--{
	fp :=  utl_file.fopen('/mistmp1/Letters','Mandate.lst','w');
--	select db_stat_date into repdt from gct where BANK_ID = '&2'; --N
    repdt := '&1';
	for rec in mandate(repdt)
	loop
	--{
		for main in main_details(rec.foracid_nri)
		loop
		--{
			BEGIN
				--{
				select distinct  REF_DESC into CUST_PERM_CITY_CODE1 from rct 
				where REF_CODE = main.CUST_PERM_CITY_CODE AND ref_rec_type = '01' and BANK_ID = '&2';
				EXCEPTION
				WHEN NO_DATA_FOUND THEN
				CUST_PERM_CITY_CODE1 := '';
				--}
			END;
			BEGIN
				--{
				select distinct  REF_DESC into CUST_PERM_STATE_CODE1 from rct
				where REF_CODE = main.CUST_PERM_STATE_CODE AND ref_rec_type = '02' and BANK_ID = '&2';
				EXCEPTION
				WHEN NO_DATA_FOUND THEN
				CUST_PERM_STATE_CODE1 := '';
				--}
				END;
			BEGIN
				--{
				select distinct  REF_DESC into CUST_PERM_CNTRY_CODE1 from rct
				where REF_CODE = main.CUST_PERM_CNTRY_CODE AND ref_rec_type = '03' AND BANK_ID = '&2';
				EXCEPTION 
				 WHEN NO_DATA_FOUND THEN
				 CUST_PERM_CNTRY_CODE1 := '';
				  --}
			  END;

			 select	  C.cif_id,            
					  C.CUST_NAME,	
					  a.address_line1,
					  a.address_line2,
					  a.city_code,
					  a.state_code,
					  a.zip,	
					  a.country_code,
					  p.phoneno1        
				into
					 mandate_cust_id1,
					 mandate_CUST_NAME,
					 mandate_CUST_PERM_ADDR1,
					 mandate_CUST_PERM_ADDR2,
					 mandate_CUST_PERM_CITY_CODE,
					mandate_CUST_PERM_STATE_CODE,
					mandate_CUST_PERM_PIN_CODE,
					mandate_CUST_PERM_CNTRY_CODE,
					mandate_CUST_PERM_PHONE_NUM
				from    cmg C,CRMUSER.ADDRESS a,CRMUSER.phoneemail p where    
					C.cif_id  = rec.MANDATE_HOLDER
                                	a.orgkey  = rec.MANDATE_HOLDER
					p.orgkey  = rec.MANDATE_HOLDER
					AND  a.BANK_ID = '&2'
					AND  p.BANK_ID = '&2'
					AND  C.BANK_ID = '&2';
			 BEGIN
				--{ CITY CODE
		 		select distinct  REF_DESC into mandate_CUST_PERM_CITY_CODE1 from rct
				 where REF_CODE = mandate_CUST_PERM_CITY_CODE AND ref_rec_type = '01' AND BANK_ID = '&2';
			 	EXCEPTION
				 WHEN NO_DATA_FOUND THEN
				 mandate_CUST_PERM_CITY_CODE1 := '';
				 --}
			 END;
			   BEGIN
			   --{ STATE CODE
			   select distinct  REF_DESC into mandate_CUST_PERM_STATE_CODE1 from rct
				where REF_CODE = mandate_CUST_PERM_STATE_CODE AND ref_rec_type = '02' AND BANK_ID = '&2';
				EXCEPTION
				 WHEN NO_DATA_FOUND THEN
		  		mandate_CUST_PERM_STATE_CODE1 := '';
			   --}
				END;
			 BEGIN
		 		--{
				select distinct  REF_DESC into mandate_CUST_PERM_CNTRY_CODE1 from rct
			 	where REF_CODE = mandate_CUST_PERM_CNTRY_CODE AND ref_rec_type = '03' AND BANK_ID = '&2';
				 EXCEPTION
			  WHEN NO_DATA_FOUND THEN
				   mandate_CUST_PERM_CNTRY_CODE1 := '';
				 --}
			   END;



				out_rec:= 
					 -- rpad(repdt,12)            ||'|'||
					rec.foracid_nri			   	||'|'||
					main.schm_code                ||'|'||
					main.cif_id		||'|'||
					main.CUST_NAME        	||'|'||
					main.CUST_PERM_ADDR1        	||'|'||
					main.CUST_PERM_ADDR2        	||'|'||
					--rpad(main.CUST_PERM_CITY_CODE        	||'|'||
					CUST_PERM_CITY_CODE1          ||'|'||
					CUST_PERM_STATE_CODE1          ||'|'||
					main.CUST_PERM_PIN_CODE		||'|'||
					--rpad(main.CUST_PERM_CNTRY_CODE		||'|'||
					CUST_PERM_CNTRY_CODE1		||'|'||
					main.CUST_PERM_PHONE_NUM		||'|'||

					mandate_cust_id1		||'|'||      
					mandate_CUST_NAME		||'|'||
					mandate_CUST_PERM_ADDR1		||'|'||      
					mandate_CUST_PERM_ADDR2		||'|'||      
					--rpad(mandate_CUST_PERM_CITY_CODE		||'|'||      
					mandate_CUST_PERM_CITY_CODE1       ||'|'||
					 mandate_CUST_PERM_STATE_CODE1       ||'|'||
					mandate_CUST_PERM_PIN_CODE			||'|'||      
					--rpad(mandate_CUST_PERM_CNTRY_CODE		||'|'||      
					mandate_CUST_PERM_CNTRY_CODE1      ||'|'||
					mandate_CUST_PERM_PHONE_NUM;
			if (CUST_Email is  null) then 
				utl_file.put_line(fp,out_rec);
			 end if;

			 CUST_PERM_CITY_CODE1 := '';
			 CUST_PERM_STATE_CODE1 := '';
			 CUST_PERM_CNTRY_CODE1   := '';

			 mandate_CUST_PERM_CITY_CODE1 := '';
			 mandate_CUST_PERM_STATE_CODE1   := '';
			 mandate_CUST_PERM_CNTRY_CODE1  := '';


		--}
		end loop;
	--}
	end loop;
	utl_file.fclose(fp);
--}
end;
/
spo off
exit

