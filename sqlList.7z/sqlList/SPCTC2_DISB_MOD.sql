REM####################################################################
REM File Name   : SPCTC2_DISB_MOD.sql
REM Description : Trade Credit Disbursement Info for TC-2
REM Author      : Paresh Maru
REM Date        : 24-04-2011
REM Module  : Supplier Credit
REM####################################################################

REM TABLE NAME: SUP_CR_TC2_DISB_MOD

REM SYNONYM:    SPCTC2_DISB_MOD

drop table icici.SUP_CR_TC2_DISB_MOD
/
drop public synonym SPCTC2_DISB_MOD
/
create table icici.SUP_CR_TC2_DISB_MOD
(
suppliers_credit_ref_no     VARCHAR2(30 CHAR),
dc_ref_no           VARCHAR2(16 CHAR),
dc_sol_id           VARCHAR2(8 CHAR),
App_Amt             VARCHAR2(30 CHAR),
crncy               VARCHAR2(3 CHAR),
Opening_Bal         VARCHAR2(30 CHAR),
DISB_Amt            VARCHAR2(30 CHAR),
DISB_Date           DATE,
ENTITY_CRE_FLG      CHAR(1),
DEL_FLG             CHAR(1),
LCHG_USER_ID        VARCHAR2(15 CHAR),
LCHG_TIME           DATE,
RCRE_USER_ID        VARCHAR2(15 CHAR),
RCRE_TIME           DATE,
bill_no				VARCHAR2(15 CHAR),
ship_date           DATE,
fr_date             DATE,
bank_id                 VARCHAR2(8 CHAR)
)
/* STORE_START */
TABLESPACE ICICI_CUST_SMALL
/* STORE_END */
/
create public synonym SPCTC2_DISB_MOD for icici.SUP_CR_TC2_DISB_MOD
/
grant select, insert, update, delete on SPCTC2_DISB_MOD to tbagen
/
grant select on SPCTC2_DISB_MOD to tbacust
/
grant select on SPCTC2_DISB_MOD to tbautil
/
grant all on SPCTC2_DISB_MOD to tbaadm
/
