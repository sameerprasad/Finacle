--#==========================================================================================
--# File Name : PPF_EBANK_VAL_FUN.sql
--# Description : This Function is Return a Value of Validation PPF E-bank Transaction
--# Menu Option :
--# Called by   :
--# Author      : BBSSL
--# Date        :
--# Module      : PPF
--#ModIFication history:
--#
--#  Sl. No      Date		   Author			Description
--# --------- --------------	-----------		  ------------------------------
--#   1	     12-12-2011     		                  Original
--#   2        12-03-2013      Seemantini Dora        Changes done for BBY CR
--#==========================================================================================

CREATE OR REPLACE FUNCTION ICICI.PPF_EBANK_VAL_FUN (ppf_foracid IN pfam.foracid%type,ppf_depamt IN number,ppf_bankId IN pfam.bank_id%type) 
											 RETURN varchar2 as


ppf_count					number;

ERROR						varchar2(1000);
SUCCESS						varchar2(100);

p_fine_amt                  pfam_arr.FINE_AMT%type;
p_arre_amt					pfam_arr.ARREAR_AMT%type;

v_no_cr_count				pfah.CREDIT_TRAN_COUNT%type;
v_tot_prin_amt_fy			pfah.TOTAL_PRINCIPAL_FY%type;
v_ppf_status				pfam.PPF_STATUS%type;

v_bod_date					gct.db_stat_date%type;
v_cr_cnt_permon				number;
v_crppfocl_tranCount		number;
v_totcr_Count				number;
v_Return_tranCount			number;

v_dep_amt_val				number;
v_tot_dep_amt				number;
v_minimumDepositAmt         number;

v_trfsflg					pfam.trfs_mode_flg%type;
v_clrbalamt					gam.clr_bal_amt%type;

---------------------------------------------------------------------
--This Cursor is used for configuring PPF Setup Parameters
---------------------------------------------------------------------

CURSOR c1 is 
select * from ppfcfg;

BEGIN

for i in c1

loop

begin

	SELECT 	count(1) into ppf_count 
	FROM 	pfam
 	WHERE	foracid = ppf_foracid 
	AND     bank_id = ppf_bankId
	AND		del_flg ='N';

	exception when no_data_found then
	 	ppf_count := 0;

end;

  IF (ppf_count =0) THEN

	     	ERROR :='Enter Valid PPF Account Number:PPFMSG001';

  ELSE 

		------------------------------------------------------------------------------------------------------
		--if the PPF Account has Penalty then Penalty has to be paid first before Credit/Debit Transaction
		------------------------------------------------------------------------------------------------------

		begin
		 	SELECT 	nvl(FINE_AMT,0),
					nvl(ARREAR_AMT,0) 
			INTO	p_fine_amt,
					p_arre_amt
  		 	FROM    pfam_arr 
  		 	WHERE 	foracid = ppf_foracid 
			AND     bank_id = ppf_bankId
  		 	AND   	DEL_FLG !='Y' 
  		 	AND   	FINANCIAL_YEAR_END = (select max(FINANCIAL_YEAR_END) from pfam_arr 
  									where foracid = ppf_foracid AND bank_id = ppf_bankId and del_flg <> 'Y');
		
			exception when no_data_found then
					p_fine_amt :=0;
					p_arre_amt :=0;
		end;
			if (p_fine_amt > 0) or (p_arre_amt >0) then
				v_minimumDepositAmt :=  i.min_dep_amt + p_fine_amt;
			end if;
			if ( ppf_depamt < v_minimumDepositAmt ) then

		 			--	ERROR :='Penalty Amount is Rs.<'||p_fine_amt ||'> for this Account <' ||ppf_foracid ||'> :PPFMSG002';
		 			ERROR :='Minimum Deposit Amt Rs.<'||i.min_dep_amt ||'>+Fine Amt Rs.<'||p_fine_amt ||'>should be Paid :PPFMSG002';
				 	GOTO RETURN;
			end if;

		--------------------------------------------------------------------------------------
		--Fetch PPF Ac Details
		--------------------------------------------------------------------------------------
		begin
			SELECT 	nvl(CREDIT_TRAN_COUNT,0),
  					nvl(TOTAL_PRINCIPAL_FY,0),
  					PPF_STATUS
			INTO	v_no_cr_count,
					v_tot_prin_amt_fy, 
					v_ppf_status
  			from  	pfam,pfah 
  			where 	pfam.foracid = pfah.foracid 
  			and   	pfam.foracid = ppf_foracid 
			AND     pfam.bank_id = ppf_bankId
			AND     pfah.bank_id = ppf_bankId
  			and   	pfam.DEL_FLG !='Y' 
  			and   	pfah.DEL_FLG !='Y' 
  			and   	pfah.FINANCIAL_YEAR_END = (select max(FINANCIAL_YEAR_END) from pfah 
  											   where pfah.foracid = ppf_foracid AND bank_id = ppf_bankId  and del_flg <> 'Y'); 
	
			exception when no_data_found then
					v_no_cr_count		:=0;
					v_tot_prin_amt_fy	:=0;
					v_ppf_status		:=' ';
		end;

			if (v_ppf_status ='C') then
				 ERROR :='Credit Not Allowed For Continued A/c.:PPFMSG003';
				 GOTO RETURN;
			elsif (v_ppf_status ='M') then
				 ERROR :='Credits No Allowed for Matured A/c.:PPFMSG004';
				 GOTO RETURN;
			end if;
	
		--------------------------------------------------------------------------------------
        -- Validate for No of Cr. Tran for Current Month
		--------------------------------------------------------------------------------------
		begin
			select 	db_stat_date
			into 	v_bod_date
			from	tbaadm.gct;
		end;

		begin
        	select 	sum((select count(1)
						from 	tbaadm.htd,tbaadm.gam 
       					where 	gam.acid = htd.acid 
       					--and 	gam.sol_id = htd.sol_id 
       					and 	gam.foracid = ppf_foracid 
					AND     gam.bank_id = ppf_bankId
       					and		PART_TRAN_TYPE='C' and tran_type in ('C','T','L')  
       					and		TRAN_SUB_TYPE in ('NR','CI','O','SI')  
       					and		tran_date between last_day(add_months(v_bod_date,-1))+1  and last_day(v_bod_date)
       					and		htd.del_flg!='Y') +
						--and 	dctd_acli.PSTD_FLG = 'Y' 
					(select count(1) from tbaadm.dtd,tbaadm.gam
					where	gam.acid=dtd.acid
					and		gam.foracid = ppf_foracid
					AND     gam.bank_id = ppf_bankId
					and 	PART_TRAN_TYPE='C' and tran_type in ('C','T','L')
					and		TRAN_SUB_TYPE in ('NR','CI','O','SI') AND dtd.del_flg !='Y' ))
			into	v_cr_cnt_permon 
			from 	dual;	

			exception when no_data_found then
					v_cr_cnt_permon :=0;

		end;

		begin
			select 	count(1) 
			into	v_crppfocl_tranCount
			from 	ppfocl
			where	foracid = ppf_foracid
			AND     bank_id = ppf_bankId
			and		to_date(ppfocl.RCRE_TIME) = v_bod_date  
			and		ppfocl.del_flg ='N';

			exception when no_data_found then
					v_crppfocl_tranCount :=0;
		end;

		begin
			 select	count(1) 
			 into	v_Return_tranCount 
			 from 	tbaadm.crt
       		 where  crt.acid in (select acid from tbaadm.gam where foracid = ppf_foracid AND     bank_id = ppf_bankId) 
      		 and    REJECTED_DATE between last_day(add_months(v_bod_date,-1))+1 and last_day(v_bod_date) 
		 AND     bank_id = ppf_bankId
       		 and    crt.del_flg ='N'; 
 
			exception when no_data_found then
					v_Return_tranCount :=0;
		end;	


		 v_totcr_Count := v_cr_cnt_permon + v_crppfocl_tranCount;
		 v_totcr_Count := v_totcr_Count - v_Return_tranCount;

			if (v_totcr_Count > i.MAX_NO_MONTH_CRTRAN) then

				 ERROR :='No. Of Credit Transaction Limit for Current Month Exceeded.:PPFMSG005';
				 GOTO RETURN;

			end if;	
			----------------------------------------------------------
    		-- Validate for No of Cr. Tran in FY
			----------------------------------------------------------
			if (v_no_cr_count > i.MAX_NO_YEAR_TRAN) then

				 ERROR :='No. Of Credit Transaction Limit for Current FY Exceeded.:PPFMSG006';
				 GOTO RETURN;

			end if;
			
			----------------------------------------------------------
    		-- Validate whether minimum deposit amount is 500
			----------------------------------------------------------
			if (ppf_depamt < i.MIN_DEP_AMT) then
		
				 ERROR :='Minimum Deposit Amount Should be Rs.500.:PPFMSG007';
				 GOTO RETURN;

			end if;

			----------------------------------------------------------
    		-- Validate whether deposit amount is in multiples of
    		-- 5
			----------------------------------------------------------

			begin
				select 	mod(ppf_depamt,5)
				into	v_dep_amt_val
				from	dual;

				exception when no_data_found then
						v_dep_amt_val := 0;
			end;

				if (v_dep_amt_val <> 0) then
					
					 ERROR :='Deposit Amount Should be in multiples of Rs.5.:PPFMSG008';
					 GOTO RETURN;

				end if;

			----------------------------------------------------------
    		-- Validate for Sum Of Cr. in FY
			----------------------------------------------------------
			
			v_tot_dep_amt := v_tot_prin_amt_fy + ppf_depamt;	
			
			if (v_tot_prin_amt_fy > i.MAX_DEP_AMT_LMT) then

				 ERROR := 'Sum Of Credits for Current FY Exceeded.:PPFMSG009';

				GOTO RETURN;

			  elsif (v_tot_dep_amt > i.MAX_DEP_AMT_LMT) then
			
					 ERROR := 'Sum Of Credits for Current FY Exceeded.:PPFMSG009';

			GOTO RETURN;

			end if;

			----------------------------------------------------------------
    		-- Validate for Transfer in account when Clear Bal is zero 
			----------------------------------------------------------------
			begin
					select	trfs_mode_flg,clr_bal_amt
					into	v_trfsflg,
							v_clrbalamt
					from 	tbaadm.gam,pfam
					where	gam.foracid = pfam.foracid 
					AND     gam.bank_id = ppf_bankId
					AND     pfam.bank_id = ppf_bankId
					and		pfam.foracid = ppf_foracid 
					and		pfam.del_flg = 'N'
					and		gam.del_flg = 'N'
					and		gam.acct_cls_flg ='N';

					exception when no_data_found then
							v_trfsflg 	:='';
							v_clrbalamt :=0;
			end;

			if (v_trfsflg ='Y') and (v_clrbalamt =0) then
	
				 ERROR :='Transfer Amount not Credited to PPF A/C yet. :PPFMSG010';
--				 ERROR :='Transfer Accounts FIRst Transaction Should not Allowed through Online :PPFMSG010';
				 GOTO RETURN;
			end if;
			
  END IF;

end loop;

<<RETURN>>

	IF (ERROR is NOT null) THEN
		RETURN('N|'||ERROR);
	ELSE
		RETURN('Y|SUCCESS:PPFMSG000');
	END IF;

end PPF_EBANK_VAL_FUN;
/
drop public synonym PPF_EBANK_VAL_FUN
/
create public synonym PPF_EBANK_VAL_FUN for ICICI.PPF_EBANK_VAL_FUN
/
--grant execute on PPF_EBANK_VAL_FUN to TBACUST,TBAGEN,TBAUTIL
grant execute on PPF_EBANK_VAL_FUN to TBAGEN,TBAUTIL
/
