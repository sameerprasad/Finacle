Rem accept solid prompt "ENTER SOL ID::::"
Rem accept lowdate prompt "Enter Low Date in DD-MM-YYYY format:"
Rem accept highdate prompt "Enter High Date in DD-MM-YYYY format: "
Rem Modofied to have bind variables and pass only start date - sanjay jain - 26-09-2008
set echo off
set verify off
set termout off
set feedback off
set pages 66
set lines 132
var solid varchar2(4);
var stdt varchar2(10);
var bankid varchar2(10);
begin
    :solid := '&1';
    :stdt  := '&2';
    :bankid := '&3';
end;
/


column BOD new_value Statusdate
column br new_value bname
column brc new_value code

select br_code brc from sol where sol_id = :solid and bank_id= :bankid ;

select br_name br from bct where br_code = (select br_code from sol where sol_id = :solid and bank_id= :bankid);
select to_Date(db_stat_date,'DD-MM-YYYY') BOD from gct; 

break on CUST_ID 
compute sum of balance on CUST_ID
column SCHEME format a5
column ACCNO format a12
column name format a25 trunc
column MATURITY format a10
column days format a5
column scheme format a5
column BALANCE format 99,99,99,999.99
column AGE format 999
column SFCUST format a1
column TEL format a15


ttitle center ' ICICI BANK LTD ' &bname skip 2-
center ' List of deposits maturing in the branch from  &2 to next 15 days'  skip 2-

spool overduedep

select 
	gam.cust_id CUST_ID,
	gam.schm_code SCHM,
	gam.foracid ACCNO,
	substr(gam.acct_name,1,25) name,
	to_char(tam.maturity_date,'DD-MM-YYYY') MATURITY,
	deposit_period_mths||'/'||deposit_period_days DAYS,
	(clr_bal_amt + un_clr_bal_amt) BALANCE,
	(sysdate - maturity_Date) AGE,
	tam.safe_custody_flg, 
	nvl(cmg.phone,'*') TEL
from gam,tam,cmg
where tam.sol_id = :solid
and gam.acid = tam.acid
and gam.acct_cls_flg != 'Y'
and tam.maturity_date between to_date(:stdt,'dd-mm-yyyy') and to_date(:stdt,'dd-mm-yyyy')+15
and cmg.cust_id=gam.cust_id
and cmg.bank_id = :bankid
and gam.bank_id = :bankid and tam.bank_id = :bankid
order by gam.cust_id,tam.maturity_date, safe_custody_flg
/
spool off
exit
