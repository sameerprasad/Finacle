var err = new ErrObject("","");

function fnOnLoad(){
    initFocusHandler();
    if (navigator.appName == "Netscape") {
        secondPartRef=eval("document.getElementById('secondPartLayer')");
    }else{
        secondPartRef=eval("document.all.secondPartLayer");
    }
		setValue("instrStat", instrstat);
		document.forms[0].zoneCode.focus();
				
  }

function fnValidateForm(){


	var objForm = document.forms[0];

	if(!fnValidateMandatoryFields()){
		err.displayErr()
		return false;
	}

	if(!validateTypes(objForm)){
		err.displayErr()
		return false;
	}
	if((objForm.setId.value == "ALL") &&
			(objForm.zoneDate.value == "" ) &&
			(objForm.zoneCode.value == "" ) &&
			(objForm.acNum.value == "" ) )
	{
			err.setErr(objForm.setId, finbranchResource.FAT000689);
			err.displayErr();
			return false;
	}

	disableButtons();
	return true;
}
function fnOnButtonClick(btnObj){

convertToCaps();
if(btnObj.id == 'Cancel'){
	formReset(document.forms[0]);
	document.forms[0].submitform.value = btnObj.id;
	document.forms[0].submit();
	return;
	
	
}
//if(!fnValidateForm()) return false;

objForm = document.forms[0];
var setId1 = objForm.setId.value.toUpperCase();
if (objForm.setId.value == "")
{
alert("setId must be entered");
objForm.setId.focus();
return false;
}
if (setId1 == "ALL")
{
alert("ALL set id is not allowed, please enter another");
objForm.setId.focus();
objForm.setId.value = "";
return false;
}
if (objForm.zoneDate.value == "")
{
alert("Zone Date must be entered");
objForm.zoneDate.focus();
return false;
}

document.forms[0].submitform.value = "Submit";
disableHyperLnks(5);
document.forms[0].submit();

return true;

}

function writeOutclgPartStatus()
{
	with(document) {
	write('<OPTION VALUE=""></OPTION>');
	write('<OPTION VALUE="E">E-ENTERED ONLY</OPTION>');
	write('<OPTION VALUE="G">G-REGULARISED </OPTION>');
	write('<OPTION VALUE="N">N-PARTLY REGULARISED</OPTION>');
	write('<OPTION VALUE="P">P-PENDING</OPTION>');
	write('<OPTION VALUE="R">R-RELEASED TO SHD. BALANCE</OPTION>');
	}
}
