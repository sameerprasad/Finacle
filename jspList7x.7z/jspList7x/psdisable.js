/**
 * This script provides functions to enable/disable printscreen key. This can be used to 
 * nullify chances of printscreen key being used to copy and print images while being displayed.
 * The higher level functions provide 2 ways of achieving this namely through JS and ActiveX.
 */
window.cbeBasePath = "../";	

var iTimerID = -1;

if(navigator.appName.indexOf('Internet Explorer')==-1||(navigator.userAgent.indexOf('MSIE')!=-1&&document.all.length!=0))
{
  if(document.all&&navigator.userAgent.indexOf('Opera')==-1)
  {
    document.write('<div style="position:absolute;left:-1000px;top:-1000px"><input type="textarea" name="hp_ta" value=" " style="visibility:hidden"></div>');
  }
}

function EnablePrntScrn()
{
	EnablePrntScrn_JS();
	//EnablePrntScrn_ActiveX();
}

function DisablePrntScrn()
{
	//if(0 == DisablePrntScrn_ActiveX())
	//alert("psdisable | DisablePrntScrn | ");
    if(0 == DisablePrntScrn_JS())
	{
		//alert("psdisable | DisablePrntScrn | ");
        document.BancsApplet.setPSDisabled(true); //Success
	}
    else
        document.BancsApplet.setPSDisabled(false); //Failure
}


//PrintScreen related JavaScript functions
function DisablePrntScrn_JS()
{
  try{
  	  //alert("psdisable | DisablePrntScrn_JS | ");
	  //disableRightClick();
	  hp_ta.createTextRange().execCommand("Copy");
	  //hp_ta.clearData();
	  iTimerID = setTimeout("DisablePrntScrn_JS()",20)
  } catch(e){
  	  return 1; //failure
  }
  return 0; //Success
}
function EnablePrntScrn_JS()
{
	while(iTimerID != -1) {
		clearTimeout(iTimerID); 
		iTimerID = -1;
        document.BancsApplet.setPSDisabled(false); //PS back to enabled
	}
}

//PrintScreen related ActiveX functions
//for the following functions a tag as follows should be included in HTML
//<OBJECT id="psdisabler" name="psdisabler" classid="clsid:847E86D6-8F8C-407E-92DB-BA66D72D0013" codebase="ClipBoard.ocx"/>
function DisablePrntScrn_ActiveX()
{
	return document.psdisabler.DisablePrntScrn();
}
function EnablePrntScrn_ActiveX()
{
	document.psdisabler.EnablePrntScrn();
}
//Function to handle Ctrl, Shift and Alt keys on this page.
//This function can be modified to take care of any key press event.
//event.keyCode == 17 --> Ctrl Key 
//making modfications on vasista
function keyPress() 
{
	if (event.ctrlKey && event.keyCode >= 65 && event.keyCode <= 90) {
        event.keyCode = 0;
        event.returnValue = false;
    }
}
