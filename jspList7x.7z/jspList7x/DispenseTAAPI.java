import nci.cash.api.APIFactory;
import nci.cash.api.HLAPI;
import nci.cash.api.TAAPI;  
import javax.swing.*;
import java.awt.*;
import nci.cash.data.NCI_CurrencyDataWithCoins;
import nci.cash.data.NCI_BasicEventData;
import nci.cash.data.NCI_BasicCoinEventData;
import java.lang.*;
import java.net.*;
import java.io.*;

public class DispenseTAAPI extends JApplet
{
	public void init() 
	{
        TAAPI T = APIFactory.getTAAPI();
        HLAPI H = APIFactory.getHLAPI();
        if ((T==null)||(H==null)) 
		{
        	System.out.println("Error: Not possible to load TCC classes.");
        }
        else 
		{
	        String tellerID, workstnID, additionalText;
			NCI_CurrencyDataWithCoins CDWC = new NCI_CurrencyDataWithCoins();
			NCI_BasicEventData BED = new NCI_BasicEventData();
			NCI_BasicCoinEventData BCED = new NCI_BasicCoinEventData();
	        short reply;
	        short i;
	        tellerID = getParameter("uid");
	        workstnID = "PC_2";
	        additionalText = getParameter("tid");
	        CDWC.szCurrencyCode = "00356";
	        CDWC.TotalAmount = Integer.parseInt(getParameter("amt"));
	        reply = T.NCIT_WithdrawalWithCoins (0,tellerID,workstnID,additionalText,CDWC,BED,BCED);
			String Result1;
			Result1 = "" + reply;
			for (i=0;i<8;i++) {
				if(CDWC.RsmData.Notes[i]!=0)
				Result1 = Result1 + "|" + CDWC.RsmData.Denom[i] + "X" + CDWC.RsmData.Notes[i];
			}
			if(CDWC.Coins!=0)
				Result1 = Result1 + "|CX" + CDWC.Coins;
			System.out.println("Result1:" + Result1);
			try{
					URL url = new URL(getParameter("url")+"?result1=" + Result1);
					getAppletContext().showDocument(url);
				}
				catch(Exception e)
				{
					System.out.println("Error : "+ e);
				}

		}
	}
}
