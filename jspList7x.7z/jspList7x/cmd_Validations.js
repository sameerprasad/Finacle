var numb = '0123456789';
var lwr = 'abcdefghijklmnopqrstuvwxyz';
var upr = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

function isValid(parm,val) {
if (parm == "") return true;
for (i=0; i<parm.length; i++) {
if (val.indexOf(parm.charAt(i),0) == -1) return false;
}
return true;
}

function isNum(parm) {return isValid(parm,numb);}
function isLower(parm) {return isValid(parm,lwr);}
function isUpper(parm) {return isValid(parm,upr);}
function isAlpha(parm) {return isValid(parm,lwr+upr);}
function isAlphanum(parm) {return isValid(parm,lwr+upr+numb);} 

//Added on 04-10-2008 
function getCMDNo(idLen,cmdwithex,fetchedval)
{	
	//alert("in javascript file")
	var cmdwithex=cmdwithex;
	var idLen =idLen;
	var fetchedval=fetchedval;
			switch(idLen)
									{
											case  5:
												cmdid = cmdwithex+""+fetchedval;
											break;
											case  4:
												cmdid = cmdwithex+"0"+fetchedval;
											break;
											case  3:
												cmdid = cmdwithex+"00"+fetchedval;
											break;
											case  2:
												cmdid = cmdwithex+"000"+fetchedval;
											break;
											case  1:
												cmdid = cmdwithex+"0000"+fetchedval;
											break;
											default:			
												cmdid = "CMD000000";
											break;
									}	//switch ends
	return cmdid;
}

//Added on 04-10-2008 
function gotoPage(page)
{
	//alert("In gotoPage");
	document.frm2.method="post";
	document.frm2.action= page;    //	The format is	"jsp/cmd_Home.jsp";
	document.frm2.submit();			
}


///////////11-05-2007//////////////
////Added by shailesh
function isAlphaNumeric_gbm2333(pfield,pfieldName,pfieldfocus)
{
	//alert("in func isAlphaNumeric_gbm2");
	for (var i = 1; i < pfield.length; i++) 
	{
		var ch = pfield.substring(i, i + 1);
		if(((ch < "a" || "z" < ch) && (ch < "A" || "Z" < ch)) && (ch < "0" || "9" < ch) && (ch!=" ")  && (ch!=",") && (ch!=".")) 
		{
			alert("The "+pfieldName+ " field  accepts letters, numbers only. \nPlease re-enter your "+pfieldName);
			eval(pfieldfocus+".focus()");
			return false;
		}
	}
	return true;
}
/////For date object
function fnCalReqLst(dateobj,inpDate)
{
        var date = "";
        if (inpDate == null)
        inpDate = '';
        date = popModalWindowVar("/finbranch/arjspmorph/INFENG/date.jsp?txtDate="+dateobj.id+"&date="+inpDate,"Calendar",250,350,15,20);
        if(date != null)
        {
                dateobj.value = date;
        }
}
function ddboxIsNotEmpty(pfield, pfieldName, pfieldfocus)
{
	if(pfield == '0')
	{
		alert("The " + pfieldName + " field is empty. Please enter the " + pfieldName + ".");
		eval(pfieldfocus+".focus()");
		return false;
    }
	return true;
}
//Added on 25-06-2007
/*function isAlphaNumeric_gbm(pfieldName,pfieldfocus) 
{
	var pfield = pfieldfocus.value;
	//alert(pfield);
	for (var i = 1; i < pfield.length; i++) 
	{
		var ch = pfield.substring(i, i + 1);
		if(((ch < "a" || "z" < ch) && (ch < "A" || "Z" < ch)) && (ch < "0" || "9" < ch)) 
		{
			alert("The "+pfieldName+ " field  accepts letters, numbers only. \nPlease re-enter your "+pfieldName);
			eval(pfieldfocus+".focus()");
			return false;
		}
	}
	return true;
}//*/

//Added on 25-06-2007
function isAlphaNumeric_gbm2(pfieldName,pfieldfocus)
{
    var pfield = pfieldfocus.value;
    //alert(pfield);
    for (var i = 0; i < pfield.length; i++)
    {
        var ch = pfield.substring(i, i + 1);
        if(((ch < "a" || "z" < ch) && (ch < "A" || "Z" < ch)) && (ch < "0" || "9" < ch) && (ch!=" ") && (ch!="#") && (ch!=".")  && (ch!="&") && (ch!="/") && (ch!="-"))
        {            
            alert("The "+pfieldName+ " field  accepts letters, numbers only. \nPlease re-enter your "+pfieldName);
            //eval(pfieldfocus+".focus()");
            return false;
        }
    }
    return true;
}

function isAlphaNumeric_address(pfield,pfieldName,pfieldfocus)
{
    //alert(pfield +"|"+pfield.length);
    for (var i = 0; i < pfield.length; i++)
    {
        var ch = pfield.substring(i, i + 1);
        if(((ch < "a" || "z" < ch) && (ch < "A" || "Z" < ch)) && (ch < "0" || "9" < ch) && (ch!=" ") && (ch!="#") && (ch!=",") && (ch!=".") && (ch!="&") && (ch!="/") && (ch!="-"))
        {            
            alert("The "+pfieldName+ " field  accepts letters, numbers only. \nPlease re-enter your "+pfieldName);
            //eval(pfieldfocus+".focus()");
            return false;
        }
    }
    return true;
}

function isAlphabetic_gbm3(pfieldName,pfieldfocus)
{
    var pfield = pfieldfocus.value;
    //alert(pfield);
    for (var i = 1; i < pfield.length; i++)
    {
        var ch = pfield.substring(i, i + 1);
        if(((ch < "a" || "z" < ch) && (ch < "A" || "Z" < ch)) && (ch!=" "))
        {            
            alert("The "+pfieldName+ " field  accepts letters, numbers only. \nPlease re-enter your "+pfieldName);
            //eval(pfieldfocus+".focus()");
            return false;
        }
    }
    return true;
}

function isAlphaNumeric_gbmNm(pfieldName,pfieldfocus)
{
    var pfield = pfieldfocus.value;
    //alert(pfield);
    for (var i = 1; i < pfield.length; i++)
    {
        var ch = pfield.substring(i, i + 1);
        if(((ch < "a" || "z" < ch) && (ch < "A" || "Z" < ch)) && (ch < "0" || "9" < ch) && (ch!=" "))
        {
            alert("The "+pfieldName+ " field  accepts letters, numbers only. \nPlease re-enter your "+pfieldName);
            eval(pfieldfocus+".focus()");
            return false;
        }
    }
    return true;
}

function isAlphaNumeric_gbmNm27(pfield,pfieldName,pfieldfocus)
{
    for (var i = 1; i < pfield.length; i++)
    {
        var ch = pfield.substring(i, i + 1);
        if(((ch < "a" || "z" < ch) && (ch < "A" || "Z" < ch)) && (ch < "0" || "9" < ch) && (ch!=" "))
        {
            alert("The "+pfieldName+ " field  accepts letters, numbers only. \nPlease re-enter your "+pfieldName);
            eval(pfieldfocus+".focus()");
            return false;
        }
    }
    return true;
}


//Added on 030507 by Mandar 
function isAlphaNumeric_gbm(pfieldName,pfieldfocus) 
{
	var pfield = pfieldfocus.value;
	//alert(pfield);
	for (var i = 1; i < pfield.length; i++) 
	{
		var ch = pfield.substring(i, i + 1);
		if(((ch < "a" || "z" < ch) && (ch < "A" || "Z" < ch)) && (ch < "0" || "9" < ch)) 
		{
			alert("The "+pfieldName+ " field  accepts letters, numbers only. \nPlease re-enter your "+pfieldName);
			eval(pfieldfocus+".focus()");
			return false;
		}
	}
	return true;
}

function isNumericOnly_gbmRP(pfieldName,pfieldfocus) 
{
	var pfield = pfieldfocus.value;
	for (var i = 1; i < pfield.length; i++) 
	{
		var ch = pfield.substring(i, i + 1);
		if(ch < "0" || "9" < ch) 
		{
			alert("The "+pfieldName+ " field accepts numbers only. \nPlease re-enter "+pfieldName);				
			eval(pfieldfocus+".focus()");
			return false;
		}
	}
	return true;
}


function isNumericOnly(pfield,pfieldName,pfieldfocus) 
{
	for (var i = 1; i < pfield.length; i++) 
	{
		var ch = pfield.substring(i, i + 1);
		if(ch < "0" || "9" < ch) 
		{
			alert("The "+pfieldName+ " field accepts numbers only. \nPlease re-enter "+pfieldName);				
			//eval(pfieldfocus+".focus()");				
			eval(pfieldfocus+".focus()");		
			return false;
		}
	}
	return true;
}
function isInteger(pfield,pfieldName,pfieldfocus)
{
	if (pfield!="" )
	{
		thisNumber = new Number(pfield);
		if (pfield != Math.floor(thisNumber))
		{
			alert(pfieldName+ " should be an Integer");
			eval(pfieldfocus+".focus()");
			return false;
		}
	
		if (pfield < 0 ) 
		{
			alert(pfieldName+ " cannot be negative. Please enter a valid value");
			eval(pfieldfocus+".focus()");
			return false;
		}		
	}
	return true;
}

function isInteger_gbm(pfield,pfieldName,pfieldfocus)
{
	if (pfield!="" )
	{
		thisNumber = new Number(pfield);
		if (pfield != Math.floor(thisNumber))
		{
			alert(pfieldName+ " should be numeric only.");
			eval(pfieldfocus+".focus()");
			return false;
		}
	
		if (pfield < 0 ) 
		{
			alert(pfieldName+ " cannot be negative. Please enter a valid value");
			eval(pfieldfocus+".focus()");
			return false;
		}		
	}
	return true;
}
function isNotEmpty(pfield, pfieldName, pfieldfocus)
{
	if(pfield == "")
	{
		alert("The " + pfieldName + " field is empty. Please enter the " + pfieldName + ".");
		//eval(pfieldfocus+".focus()");
		return false;
    }
 
	for (var i=0;i < pfield.length; i++)
	{
		if (pfield.substring(i,i+1) != " ")
		{
			return true;
		}
	}
	alert("The " + pfieldName + " field is empty. Please enter the " + pfieldName + ".");
	//eval(pfieldfocus+".focus()");
	return false;
}
//Added on 29-09-2007
function finDateNotEmpty(pfield, pfieldName, pfieldfocus)
{
	if(pfield == "")
	{
		alert("The " + pfieldName + " is empty.");
		return false;
    }
 
	for (var i=0;i < pfield.length; i++)
	{
		if (pfield.substring(i,i+1) != " ")
			return true;
	}
	alert("The " + pfieldName + " is empty.");
	return false;
}

function amountFields(pfield,pfieldName,pfieldfocus)
	{
		if(!isDigit(pfield))
		{
			alert("Amount should be greater than zero.");
			//pfield ="";
			eval(pfieldfocus+".focus()");
			return false;
		}
		else
			return true;
	}
function isAlphaNumeric(pfield,pfieldName,pfieldfocus) 
{
	for (var i = 1; i < pfield.length; i++) 
	{
		var ch = pfield.substring(i, i + 1);
		if(((ch < "a" || "z" < ch) && (ch < "A" || "Z" < ch)) && (ch < "0" || "9" < ch)) 
		{
			alert("The "+pfieldName+ " field  accepts letters, numbers only. \nPlease re-enter your "+pfieldName);
			eval(pfieldfocus+".focus()");
			return false;
		}
	}
	return true;
}

function isAlphaBeticOnly(pfield,pfieldName,pfieldfocus) 
{
	for(var i = 0; i < pfield.length; i++) 
	{
		var ch = pfield.substring(i, i + 1);
		if (((ch < "a" || "z" < ch) && (ch < "A" || "Z" < ch)) && (ch!=" "))
		{
			alert("The "+pfieldName+ " field accepts letters only.\nPlease re-enter the "+pfieldName+".");
			eval(pfieldfocus+".focus()");
		    return false;
		}
	}	
	return true;
}

	function isPinCode(sText2)
	{
		if(sText2!="")
		{
			//	alert(sText2);
			if(sText2.length < 6)
			{
				alert("Pin code should be 6 digit number. \nPlease re-enter your Pin code");
				return false;
			}
		}
		return true;
	}

	function isInstrNo(sText2)
	{
		if(sText2!="")
		{
			//	alert(sText2);
			if(sText2.length < 6)
			{
				alert("Instrument number should not be less than 6 digits.");
				return false;
			}
		}
		return true;
	}

function isGreatersDate_gbm(pselectedDate,curDate)
{
	selectdate=pselectedDate.split("-");
	currentdate=curDate.split("-");
	pselectedMonth=selectdate[0];
	pselectedDay=selectdate[1];
	pselectedYear=selectdate[2];
	curMonth=currentdate[0];
	curDay=currentdate[1];
	curYear=currentdate[2];

	//alert("curDay"+curDay+"|curMonth: "+curMonth+"|curYear: "+curYear)
	if (curMonth < 10)
		curMonth=0+curMonth;
	if (curDay < 10)
		curDay=0+curDay;
	if (pselectedMonth < 10)
		pselectedMonth=0+pselectedMonth;
	if (pselectedDay < 10)
		pselectedDay=0+pselectedDay;

	if (parseInt(pselectedYear) == parseInt(curYear))
	{
		if(pselectedMonth > curMonth)
		{
			alert("The Date can not be more than today's date.")
			return false;
		}
	}
	if (parseInt(pselectedYear) == parseInt(curYear))
	{
		if(parseInt(pselectedMonth)== parseInt(curMonth))  //&&(parseInt(pselectedDay)> parseInt(curDay)))
		{
		  if((parseInt(pselectedDay))>(parseInt(curDay)))
		  {
			  alert("The Date can not be more than today's date.")
				return false;
		  }
		}
	}
	if (parseInt(pselectedYear) > parseInt(curYear))
	{
			alert("The Date can not be more than today's date.")
			return false;
	}
	return true;
}
function isGreatersDate(pselectedDate,pfieldName,curDate)
{
	selectdate=pselectedDate.split("-");
	currentdate=curDate.split("-");
	pselectedMonth=selectdate[0];
	pselectedDay=selectdate[1];
	pselectedYear=selectdate[2];
	curMonth=currentdate[0];
	curDay=currentdate[1];
	curYear=currentdate[2];
	if (curMonth < 10)
	{
		curMonth=0+curMonth;
	}
	if (curDay < 10)
	{
		curDay=0+curDay;
	}
	if (pselectedMonth < 10)
	{
		pselectedMonth=0+pselectedMonth;
	}
	if (pselectedDay < 10)
	{
		pselectedDay=0+pselectedDay;
	}
	/*if ((parseInt(pselectedDay) == parseInt(curDay))&&(parseInt(pselectedMonth) == parseInt(curMonth))&&(parseInt(pselectedYear) == parseInt(curYear)))
	{
		alert("The Passport expiry date can not be today's date.")
		document.form1.submit1.disabled=false;
		pfieldName.focus();
		return false;
	}*/
	if (parseInt(pselectedYear) == parseInt(curYear))
	{
		if(pselectedMonth > curMonth)
		{
			alert("The Date can not be more than today's date.")
			//document.form1.submit1.disabled=false;
			pfieldName.value=curDate;
			eval(pfieldName+".focus()");
			return false;
		}
	}
	if (parseInt(pselectedYear) == parseInt(curYear))
	{
		if(parseInt(pselectedMonth)== parseInt(curMonth))  //&&(parseInt(pselectedDay)> parseInt(curDay)))
		{
		  if((parseInt(pselectedDay))>(parseInt(curDay)))
		  {	alert("The Date can not be more than today's date.")
			//document.form1.submit1.disabled=false;
		    pfieldName.value=curDate;
			eval(pfieldName+".focus()");
			return false;
		  }
		}
	}
	if (parseInt(pselectedYear) > parseInt(curYear))
	{
			alert("The Date can not be more than today's date.")
			//document.form1.submit1.disabled=false;
			pfieldName.value=curDate;
			eval(pfieldName+".focus()");
			return false;
	}
	return true;
}


//dd/mm/yyyy
function isDate(expression)
{
	
	if(expression.length == 0) return false;
	var arr = new Array();
	arr = expression.split("/");
	if(arr.length != 3) return false;
	if(!isPositive(arr[0]) || !isPositive(arr[1]) || !isPositive(arr[2])) return false;
	if(parseInt(arr[0]) > 31 || parseInt(arr[0],10) == 0) return false;
	if(parseInt(arr[1]) > 12 || parseInt(arr[1]) == 0) return false;
	if(arr[2].length != 4 || parseInt(arr[2]) <= 1970) return false;
	return true;
}

function disableElement(Obj,state)
{
	if(state){
		Obj.disabled=true;
		Obj.style.backgroundColor="#d3d3d3";
	}else if(!state){
		Obj.disabled=false;
		Obj.style.backgroundColor="#ffffff";	
	}
}


	
	function numValidation(input)
	{
		var inp= input.value;
		if(isDigit(inp))
		{
			if(inp.length<5)
			{
				alert("Please enter valid Id");
				inp ="";
				input.focus();
				return false;
			}
		}
		else
			return true;
	}
///////////////////////////////////////////////
function isAlphaNum(pfield,pfieldName,pfieldfocus) 
{
	for (var i = 1; i < pfield.length; i++) 
	{
		var ch = pfield.substring(i, i + 1);
		if(((ch < "a" || "z" < ch) && (ch < "A" || "Z" < ch)) && (ch < "0" || "9" < ch)) 
		{
			alert("The "+pfieldName+ " field  accepts letters, numbers only. \nPlease re-enter your "+pfieldName);
			eval(pfieldfocus+".focus()");
			return false;
		}
	}
	return true;
}
	
	function isDigit(num)
	{
		var checkOK = "0123456789";
		var checkStr = num;
		var allValid = true;
		var decPoints = 0;
		var allNum = "";
		
		for (i = 0;i < checkStr.length;  i++)
		{
			ch = checkStr.charAt(i);
			for (j = 0;  j < checkOK.length;  j++)
				if (ch == checkOK.charAt(j))
					break;
				if (j == checkOK.length)
				{
					allValid = false;
					break;
				}
				if (ch != ",")
					allNum += ch;
		}
		if (allValid)
			return true;
	}
	function isAlphabetic(myChar)
	{
		var checkOK = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
		var checkStr = myChar;
		var allValid = true;
		var decPoints = 0;
		var allNum = "";
		
		for (i = 0;i < checkStr.length;  i++)
		{
			ch = checkStr.charAt(i);
			for (j = 0;  j < checkOK.length;  j++)
				if (ch == checkOK.charAt(j))
					break;
				if (j == checkOK.length)
				{
					allValid = false;
					break;
				}
				if (ch != ",")
					allNum += ch;
		}
		if (allValid)
			return true;
	}
	//Added on 31-05-2007
	function isAlphaNumSp(myChar)
	{
		var checkOK = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		var checkStr = myChar;
		var allValid = true;
		var decPoints = 0;
		var allNum = "";
		
		for (i = 0;i < checkStr.length;  i++)
		{
			ch = checkStr.charAt(i);
			for (j = 0;  j < checkOK.length;  j++)
				if (ch == checkOK.charAt(j))
					break;
				if (j == checkOK.length)
				{
					allValid = false;
					break;
				}
				if (ch != ",")
					allNum += ch;
		}
		if (allValid)
			return true;
	}
		///////////////////////
		function openstmt(s)
		{
			window.open(s,'GBM','fullscreen=no, toolbar=no, location=no, titlebar=no, status=no, menubar=no, scrollbars=no, resizable=no, width=800,height=500');
		}

		//Added on 16-05-2007
		function amtGreater(amount2,amtField)
		{
			//;alert(amount2);
			if(parseInt(amount2) <= 0)
			{
				alert("Amount should be greater than zero.");
				eval(amtField+".focus()");
				return false;
			}
			else
				return true;
		}

		function showMenuit(f)
		{
			if(f)
				visi="visible";
			else
				visi="hidden";
			
			if(document.layers)
				document.menuit.visibility=visi;
			if(document.all)
				document.all.menuit.style.visibility=visi;
			if(document.getElementById)
				document.getElementById("menuit").style.visibility=visi;
		} 
//Added on 15-06-07
function PAN_TAN_Validn_5(pan)
{	
	//alert("PAN Number: "+pan);
	if(pan.length < 10)
	{
		alert("Invalid PAN/TAN Number.");
		pan_tan_flg="n";
		return pan_tan_flg;
	}
	else(pan.length == 10)
	{
		var pan_tan_flg="";
		//alert("Validating PAN no.");				
		var cnr1=0, cnr2=0;
		//PAN Number 1 2 3 4   5   6 7 8 9 10
		//			 C C C C (C/N) N N N N C						
		var pan11= pan.substring(0,4);
		var pan12= pan.substring(4,5);
		var pan13= pan.substring(5,9);//
		var pan14= pan.substring(9,pan.length);
		//alert(pan11+"|"+pan12 +"|"+pan13+"|"+pan14);
		
		if(isAlphabetic(pan11) && isAlphabetic(pan14))
			cnr1++;
		else
			cnr2++;
		
		if(isAlphaNumSp(pan12))
			cnr1++;
		else
			cnr2++;

		if(isDigit(pan13))
			cnr1++;
		else
			cnr2++;
		//alert(cnr1+"|"+cnr2);
		if(cnr2>0)
		{
			//It's definitely not a PAN.
			//Validate for TAN
			cnr1=0, cnr2=0;
			//TAN Number 1 2 3   4   5 6 7 8 9 10
			//			 C C C (C/N) N N N N N C
			var tan11= pan.substring(0,3);
			var tan12= pan.substring(3,4);
			var tan13= pan.substring(4,9);//
			var tan14= pan.substring(9,pan.length);
			//alert(tan11+"|"+tan12 +"|"+tan13+"|"+tan14);
			
			if(isAlphabetic(tan11) && isAlphabetic(tan14))
				cnr1++;
			else
				cnr2++;
			
			if(isAlphaNumSp(tan12))
				cnr1++;
			else
				cnr2++;

			if(isDigit(tan13))
				cnr1++;
			else
				cnr2++;
			//alert(cnr1+"|"+cnr2);
			if(cnr2>0)
			{
				alert("This is neither PAN nor TAN.");
				pan_tan_flg="n";
				return pan_tan_flg;
			}
			else
			{
				alert("TAN Number validated successfully.");
				pan_tan_flg="t";
				return pan_tan_flg;
			}					
		}
		else 
		{
			alert("PAN Number validated successfully.");
			pan_tan_flg="p";
			return pan_tan_flg;
		}//*/
	}
}
function extractNumber(obj, decimalPlaces, allowNegative)
{
	var temp = obj.value;
	
	// avoid changing things if already formatted correctly
	var reg0Str = '[0-9]*';
	if (decimalPlaces > 0) {
		reg0Str += '\\.?[0-9]{0,' + decimalPlaces + '}';
	} else if (decimalPlaces < 0) {
		reg0Str += '\\.?[0-9]*';
	}
	reg0Str = allowNegative ? '^-?' + reg0Str : '^' + reg0Str;
	reg0Str = reg0Str + '$';
	var reg0 = new RegExp(reg0Str);
	if (reg0.test(temp)) return true;

	// first replace all non numbers
	var reg1Str = '[^0-9' + (decimalPlaces != 0 ? '.' : '') + (allowNegative ? '-' : '') + ']';
	var reg1 = new RegExp(reg1Str, 'g');
	temp = temp.replace(reg1, '');

	if (allowNegative) {
		// replace extra negative
		var hasNegative = temp.length > 0 && temp.charAt(0) == '-';
		var reg2 = /-/g;
		temp = temp.replace(reg2, '');
		if (hasNegative) temp = '-' + temp;
	}
	
	if (decimalPlaces != 0) {
		var reg3 = /\./g;
		var reg3Array = reg3.exec(temp);
		if (reg3Array != null) {
			// keep only first occurrence of .
			//  and the number of places specified by decimalPlaces or the entire string if decimalPlaces < 0
			var reg3Right = temp.substring(reg3Array.index + reg3Array[0].length);
			reg3Right = reg3Right.replace(reg3, '');
			reg3Right = decimalPlaces > 0 ? reg3Right.substring(0, decimalPlaces) : reg3Right;
			temp = temp.substring(0,reg3Array.index) + '.' + reg3Right;
		}
	}
	
	obj.value = temp;
}
function blockNonNumbers(obj, e, allowDecimal, allowNegative)
{
	var key;
	var isCtrl = false;
	var keychar;
	var reg;
		
	if(window.event) {
		key = e.keyCode;
		isCtrl = window.event.ctrlKey
	}
	else if(e.which) {
		key = e.which;
		isCtrl = e.ctrlKey;
	}
	
	if (isNaN(key)) return true;
	
	keychar = String.fromCharCode(key);
	
	// check for backspace or delete, or if Ctrl was pressed
	if (key == 8 || isCtrl)
	{
		return true;
	}

	reg = /\d/;
	var isFirstN = allowNegative ? keychar == '-' && obj.value.indexOf('-') == -1 : false;
	var isFirstD = allowDecimal ? keychar == '.' && obj.value.indexOf('.') == -1 : false;
	
	return isFirstN || isFirstD || reg.test(keychar);
}


function setVisibility(id, visibility) 
{
	document.all[id].style.display = visibility;
}

// Removes leading whitespaces
function LTrim( value ) {
	
	var re = /\s*((\S+\s*)*)/;
	return value.replace(re, "$1");
	
}

// Removes ending whitespaces
function RTrim( value ) {
	
	var re = /((\s*\S+)*)\s*/;
	return value.replace(re, "$1");
	
}

// Removes leading and ending whitespaces
function trim( value ) {
	
	return LTrim(RTrim(value));
	
}


//GBM reports
function goAhead_gbmReports(page)
{
// 	alert(page)
	var gbmRpform  = document.forms["gbmRepForm"];
	gbmRpform.method="post";
	gbmRpform.action=page;
	gbmRpform.submit();			
}
function goAhead_gbmMasters(page)
{
	var gbmMastform  = document.forms["gbmMstform"];
	gbmMastform.method="post";
	gbmMastform.action=page;
	gbmMastform.submit();			
}



function gbmScript_reports(input1,scrName1)
{
	var tblIndx =  document.forms["gbmRepForm"].elements["gbmMasterTbl"].value;
	var output1 = "";
	//alert(scrName1 + " " + input1 + " " + output1 );
	var retVal1 = fnExecuteScript(input1,output1,scrName1,false);
	if(retVal1 ==undefined)
		retVal1 ="N|There was an internal error.";
	else
	{
		//alert(retVal1);
		arr1 =retVal1.split("|");	

		if(arr1[1]=="N")
			retVal1 ="N|No Data Found.";				
	}
//		alert("Final ResultString: "+retVal1);
	return retVal1;
}

function get_days_in_month(mon, yr)
{
	var monDays =0;
	var month = new Number(mon);
	var year  = new Number(yr);
	//var mdays = [ [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
	//if(month)
	var isleap =  (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)) ? 1 : 0;
	//alert("Check Leap: "+isleap +" Month: "+month)
	if(isleap==0 && month ==2)
		monDays = 28;
	else if(isleap==1 && month ==2)
		monDays = 29;
	else if(month ==4 || month ==6 || month ==9 || month ==11)	
		monDays = 30;
	else if(month ==1 || month ==3 || month ==5 || month ==7 || month ==8 || month ==10 || month ==12)
		monDays = 31;
	else
		monDays = 0;
	//alert("Days in month: "+monDays)
	return monDays;
}
function date1(input)
{
	var inp=input;
	if(!isGreaterThanToday(inp))	
	{
		alert("Date should not be greater than today");
		inp="";
		return false;
	}
	else
	{
		return true;//		alert("Done...");
	}
}
function isGreaterThanToday(value1) 
{   
	var sd1= document.forms["gbmRepForm"].elements["sysDate"].value;
	//alert("Server side Date:"+sd1);

   var d1, d2;
   var m1, m2;
   var y1, y2;
	
   d1 = value1.substring (0, value1.indexOf ("-"));   
   m1 = value1.substring (value1.indexOf ("-")+1, value1.lastIndexOf ("-")); 
   y1 = value1.substring (value1.lastIndexOf ("-")+1, value1.length); 

   d2 = sd1.substring (0,sd1.indexOf ("-"));   
   m2 = sd1.substring (sd1.indexOf ("-")+1, sd1.lastIndexOf ("-")); 
   y2 = sd1.substring (sd1.lastIndexOf ("-")+1, sd1.length); 
   
	var myDate = new Date; 
	myDate.setDate(d1);
	myDate.setMonth(m1-1); // January = 0
	myDate.setFullYear(y1); 

	var sysDate2 = new Date; 
	sysDate2.setDate(d2);
	sysDate2.setMonth(m2-1); // January = 0
	sysDate2.setFullYear(y2); 

	var today = new Date;	
	//alert("Date given:"+myDate+"\nToday is:"+sysDate2);
	if (myDate > sysDate2)//today)
		return false;
	else
		return true;
}
function toDateNotGreater(value1, value2) 
{   
	var sd1= value2;
	//alert("Server side Date:"+sd1);

   var d1, d2;
   var m1, m2;
   var y1, y2;
	
   d1 = value1.substring (0, value1.indexOf ("-"));   
   m1 = value1.substring (value1.indexOf ("-")+1, value1.lastIndexOf ("-")); 
   y1 = value1.substring (value1.lastIndexOf ("-")+1, value1.length); 

   d2 = sd1.substring (0,sd1.indexOf ("-"));   
   m2 = sd1.substring (sd1.indexOf ("-")+1, sd1.lastIndexOf ("-")); 
   y2 = sd1.substring (sd1.lastIndexOf ("-")+1, sd1.length); 
   
	var myDate = new Date; 
	myDate.setDate(d1);
	myDate.setMonth(m1-1); // January = 0
	myDate.setFullYear(y1); 

	var sysDate2 = new Date; 
	sysDate2.setDate(d2);
	sysDate2.setMonth(m2-1); // January = 0
	sysDate2.setFullYear(y2); 

	var today = new Date;	//	alert("Date given:"+myDate+"\nToday is:"+today);
	if (myDate < sysDate2)//today)
		return false;
	else
		return true;
}
function frTodate(input, input2)
{
	var inp=input;
	if(!toDateNotGreater(inp,input2))	
	{
		alert("To Date should not be less than from Date");
		inp="";
		return false;
	}
	else
	{
		return true;//		alert("Done...");
	}
}

function getFinDate(headCtxSol,headDate,reportForm)
{
	//alert(headCtxSol+" , "+headDate);
	var day   = headDate.substring(0,2);
	var yr    = headDate.substring(headDate.length-4,headDate.length);
	var month = headDate.substring(2,headDate.length-4);//" June, ";//

	var mm = "";
	switch(month)
	{
		case " January, ":
			mm="01";
			break;
		case " February, ":
			mm="02";
			break;
		case " March, ":
			mm="03";
			break;
		case " April, ":
			mm="04";
			break;
		case " May, ":
			mm="05";
			break;
		case " June, ":
			mm="06";
			break;
		case " July, ":
			mm="07";
			break;
		case " August, ":
			mm="08";
			break;
		case " September, ":
			mm="09";
			break;
		case " October, ":
			mm="10";
			break;
		case " November, ":
			mm="11";
			break;
		case " December, ":
			mm="12";
			break;
		default:
			break;
	}
	//alert("Challan Entry Date: "+day+"-"+mm+"-"+yr);
	//reportForm.elements["gbm_dt2"].value= day+"-"+mm+"-"+yr;
	document.forms["gbmRepForm"].elements["gbmSolId"].value = headCtxSol;
	//alert(reportForm.elements["gbm_dt2"].value);
}


//gbm_Link.jsp
//Added on 12-09-2007
function getSolId(sol)
{	
	var idLen = sol.length;
	switch(idLen)
	{
		case  3:
			sol = "0"+sol;
			break;
		case  2:
			sol = "00"+sol;
			break;
		case  1:
			sol = "000"+sol;
			break;
	}	
	//alert(sol)
	return sol;
}
function isValidSol(obj)
{
	var solLen = obj.value.length;
	//alert("Sol Id: "+obj.value +" | Length:"+solLen)
	if(solLen < 4)
	{
		alert("Invalid Sol Id.");
		obj.value = "";
		obj.focus();
		return false;
	}
	return true;
}
//********************************************/

//**********************Added by Rakesh

function isGreatersDate(pselectedDate,curDate)
{
	selectdate=pselectedDate.split("-");
	currentdate=curDate.split("-");
	pselectedMonth=selectdate[0];
	pselectedDay=selectdate[1];
	pselectedYear=selectdate[2];
	curMonth=currentdate[0];
	curDay=currentdate[1];
	curYear=currentdate[2];
	if (curMonth < 10)
	{
		curMonth=0+curMonth;
	}
	if (curDay < 10)
	{
		curDay=0+curDay;
	}
	if (pselectedMonth < 10)
	{
		pselectedMonth=0+pselectedMonth;
	}
	if (pselectedDay < 10)
	{
		pselectedDay=0+pselectedDay;
	}
	if (parseInt(pselectedYear) == parseInt(curYear))
	{
		if(pselectedMonth > curMonth)
		{
			alert("The Date can not be more than today's date.")
			return false;
		}
	}
	if (parseInt(pselectedYear) == parseInt(curYear))
	{
		if(parseInt(pselectedMonth)== parseInt(curMonth)) 
		{
		  if((parseInt(pselectedDay))>(parseInt(curDay)))
		  {	alert("The Date can not be more than today's date.")
			return false;
		  }
		}
	}
	if (parseInt(pselectedYear) > parseInt(curYear))
	{
			alert("The Date can not be more than today's date.")
			return false;
	}
	return true;
}

